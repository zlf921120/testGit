-- EnemyBase = class("EnemyBase", CCSprite)

