TaskText = {}

TaskText[1] = "第一次出任务，务必完美\n\n完成任务！并安全归来！"