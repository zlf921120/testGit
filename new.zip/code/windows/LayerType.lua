LayerType = {}

LayerType.frist = 1
LayerType.second = 2
LayerType.three = 3