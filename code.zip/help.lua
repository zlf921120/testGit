require "config"
require "init"

function test(aa)
	print("test params=",aa)
end