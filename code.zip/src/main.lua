
cc.FileUtils:getInstance():setPopupNotify(false)
cc.FileUtils:getInstance():addSearchPath("src/")
cc.FileUtils:getInstance():addSearchPath("res/")

require "Utils"
require "ComName"
require "ComMgr"
require "SceneCtrl"
require "ComRes"
require "Notifier"
require "TimerMgr"
require "StartView"

local function main()
    local _start = StartView:create()
    local _cs = display.newScene()
    _cs:addChild(_start)
    SceneCtrl:getInstance():gotoScene(_cs)
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    print(msg)
end