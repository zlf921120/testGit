StartView = class("StartView", function()
	return display.newLayer()
end)

function StartView:ctor()
	print("bbbb")
end

function StartView:create()
	local ret = StartView.new()
	ret:init()
	return ret
end

function StartView:init()
	ComRes:getInstance():loadArmRes("res/fj010.png", "res/fj010.plist", "res/fj01.ExportJson")
	self.change = function(armature,movementType,movementID)
		if movementType == ComName.ActionFinish then
			if movementID == "bianshen2" then
				armature:getAnimation():play("putong")
				self.isChange = false
			elseif movementID == "bianshen" then
				armature:getAnimation():play("baozou")
			end
		end
	end
	self.armature = ComMgr:getInstance():createArm("fj01", self.change)
	self.armature:setPosition(cc.p(display.cx, display.cy*0.5))
	self:addChild(self.armature)
	self.armature:getAnimation():play("putong")
	self:addTouch()
	self.isChange = false

	local function btn_event(sender, event_type)
		if event_type == ComName.TouchEnd then
			if not self.isChange then
				self.isChange = true
				self.armature:getAnimation():play("bianshen")
				Timer.start(3.0, function()
					print("putong")
					self.armature:getAnimation():play("bianshen2")
					self.isChange = false
					Timer.stop("aaaa")
				end, "aaaa")
			end
		end
	end

	local info = {}
	info.nor = "res/1.png"
	info.press = "res/1.png"
	info.func = btn_event
	local btn = ComMgr:getInstance():createBtn(info)
	btn:setPosition(cc.p(550, 500))
	self:addChild(btn)
end

function StartView:addTouch()
	local listenner = cc.EventListenerTouchOneByOne:create()
	-- listenner:setSwallowTouches(true)
	listenner:registerScriptHandler(function(touch, event)    
   		self.location = touch:getLocation()  
   		return true    
	end, cc.Handler.EVENT_TOUCH_BEGAN )  
  
	listenner:registerScriptHandler(function(touch, event)  
   		local locationInNodeX = self:convertToNodeSpace(touch:getLocation()).x     
   		local subX = self.location.x - locationInNodeX
   		
   		if subX < 0 then
   			if self.isChange then
   				self.armature:getAnimation():play("bzright")
   			else
   				self.armature:getAnimation():play("ptright")
   			end
   		elseif subX > 0 then
   			if self.isChange then
   				self.armature:getAnimation():play("bzleft")
   			else
   				self.armature:getAnimation():play("ptleft")
   			end
   		end   
	end, cc.Handler.EVENT_TOUCH_MOVED )    
  
	listenner:registerScriptHandler(function(touch, event)    
   		local locationInNodeX = self:convertToNodeSpace(touch:getLocation()).x    
   		if self.isChange then
   			self.armature:getAnimation():play("baozou")
   		else
   			self.armature:getAnimation():play("putong")
   		end
	end, cc.Handler.EVENT_TOUCH_ENDED )    
      
	local eventDispatcher = self:getEventDispatcher()    
	eventDispatcher:addEventListenerWithSceneGraphPriority(listenner, self) 
end