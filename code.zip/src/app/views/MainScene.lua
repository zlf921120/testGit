
local MainScene = class("MainScene", cc.load("mvc").ViewBase)

function MainScene:onCreate()
    -- add background image
    display.newSprite("MainSceneBg.jpg")
        :move(display.center)
        :addTo(self)

    -- add play button
    local playButton = cc.MenuItemImage:create("PlayButton.png", "PlayButton.png")
        :onClicked(function()
            if cc.Application:getInstance():getTargetPlatform() == cc.PLATFORM_OS_ANDROID then
                local luaj = require "cocos.cocos2d.luaj" --获取lua虚拟机
                local className = "org/cocos2dx/lua/AppActivity"--类名
                local methodName = "aaa" --方法名
                local args = {"lua调用java", MainScene.callback} --传进java方法的参数
                local signs = "(Ljava/lang/String;I)V" --方法参数返回值类型
                luaj.callStaticMethod(className, methodName, args, signs)
            end
            -- self:getApp():enterScene("PlayScene")
        end)
    cc.Menu:create(playButton)
        :move(display.cx, display.cy - 200)
        :addTo(self)
end

MainScene.callback = function(params)
    print("java to lua test", params)
    print("java to lua test", params)
    print("java to lua test", params)
    print("java to lua test", params)
end

return MainScene
