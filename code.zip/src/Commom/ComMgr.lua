ComMgr = class("ComMgr")

local allMgr = {}

local _instacne = nil

function ComMgr:getInstance()
	if not _instacne then
		_instacne = ComMgr.new()
	end
	return _instacne
end

function ComMgr:addInstance(instance)
	print("add instance")
	table.insert(allMgr, instance)
end

function ComMgr:clear()
	for k,v in pairs(allMgr) do
		if v then
			v = nil
		end
	end
	_instance = nil
end

function ComMgr:createArm(arm_name, callback)
	local arm = ccs.Armature:create(arm_name)
	if callback then
		arm:getAnimation():setMovementEventCallFunc(callback)
	end
	return arm
end

function ComMgr:createNodes(csb_name)
	cc.CSLoader:setCsbUseType(true)
    local node = cc.CSLoader:createNode(csb_name)
    return node
end

function ComMgr:createBtn(info)
	if not info then
		print("缺少必要参数")
		return 
	end
	local btn = ccui.Button:create()
	if info.useType then
		if info.dis then
			btn:loadTextureDisabled(info.dis, info.useType)
		end
		btn:loadTextureNormal(info.nor, info.useType)
		btn:loadTexturePressed(info.press, info.useType)
	else
		if info.dis then
			btn:loadTextureDisabled(info.dis)
		end
		btn:loadTextureNormal(info.nor)
		btn:loadTexturePressed(info.press)
	end
	if info.func then
		btn:addTouchEventListener(info.func)
	end
	
	return btn
end