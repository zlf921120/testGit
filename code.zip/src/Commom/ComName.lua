ComName = {}

ComName.TouchEnd = 2
ComName.ActionFinish = 2
ComName.UsePlist = 1
ComName.UseLocal = 0