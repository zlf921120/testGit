ComRes = class("ComRes")

local _instance = nil
local _allRes = {}
local _allJson = {}

function ComRes:getInstance()
	if not _instance then
		_instance = ComRes.new()
		print("addddd")
		ComMgr:getInstance():addInstance(_instance)
	end
	return _instance
end

function ComRes:addRes(resPath)
	if cc.FileUtils:getInstance():isFileExist(resPath) == false then
        print("error:加载不存在的配置文件", resPath)
        return
    end
	if _allRes[resPath] then
		print(resPath.."已经加载过")
		return
	end
	print("加载纹理",resPath)
	cc.SpriteFrameCache:getInstance():addSpriteFrames(resPath)
	_allRes[resPath] = resPath
end

function ComRes:removeRes(resPath)
	if not _allRes[resPath] then
		print(resPath.."已经被删除")
		return
	end
	print("删除纹理",resPath)
	cc.SpriteFrameCache:getInstance():removeSpriteFrameByName(resPath)
	_allRes[resPath] = nil
end

function ComRes:clear()
	for k,v in pairs(_allRes) do
		_instance:removeRes(k)
	end
	cc.TextureCache:getInstance():removeAllTextures()
end

function ComRes:loadArmRes(pngPath, plistPtah, jsonPath)
	if _allJson[jsonPath] then
		print(jsonPath.."已经加载过")
		return
	end
	_allJson[jsonPath] = jsonPath
	ccs.ArmatureDataManager:getInstance():addArmatureFileInfo(pngPath, plistPtah, jsonPath)
end

function ComRes:removeArmRes()
	if not _allJson[jsonPath] then
		print(jsonPath.."已经被删除")
		return
	end
	ccs.ArmatureDataManager:getInstance():removeArmatureFileInfo(_allJson[jsonPath])
	cc.Director:getInstance():getTextureCache():removeUnusedTextures();
	_allJson[jsonPath] = nil
end