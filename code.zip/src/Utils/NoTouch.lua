NoTouch = class("NoTouch", function()
	return display.newLayer()
end)

function NoTouch:create()
	local  ret = Awew.new()
	ret:init()
	return ret
end

function NoTouch:init()
	local listenner = cc.EventListenerTouchOneByOne:create()
	listenner:setSwallowTouches(true)
	listenner:registerScriptHandler(function(touch, event)    
   		return true    
	end, cc.Handler.EVENT_TOUCH_BEGAN )  

	listenner:registerScriptHandler(function(touch, event)  
	end, cc.Handler.EVENT_TOUCH_MOVED )    
  
	listenner:registerScriptHandler(function(touch, event)    
	end, cc.Handler.EVENT_TOUCH_ENDED )    
      
	local eventDispatcher = self:getEventDispatcher()    
	eventDispatcher:addEventListenerWithSceneGraphPriority(listenner, self) 
end