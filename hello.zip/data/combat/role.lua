Role = class("Role", EntityBase:create())

function Role:create(argAttackType, heroInfo)
	local r = Role.new()
	r:init(argAttackType, heroInfo)
	return r
end

function Role:init(argAttackType, heroInfo)
	
	self:initBase()

	self.roundMgr = nil

	self.isDead = false

	--敏捷度
	self.attackSpeed = math.random(10, 100)
	self._baseInfo = heroInfo
	self._avatorId = heroInfo.base_id
	if heroInfo.sex then
		self.enemysex = heroInfo.sex
	end
	print("xingbie = ", heroInfo.sex)
	print("xingbie = ", heroInfo.sex)
	print("xingbie = ", heroInfo.sex)
	print("xingbie = ", heroInfo.sex)

	self:setModel(heroInfo:getModelId())
	
	--角色人物
	--战斗方,分为攻击方和受击方	
	self:setEntityType(argAttackType)

	--设置本次攻击额外属性	
	self._curAttackExtraArgs = nil

	self._fighterType = BattleType.ROLE

end

-- function Role:uninit()
-- 	self.super:uninit()
-- end

--[[
    设置模型
    @param modelId 模型ID
]]
function Role:setModel(modelId)
	if self._modelId == modelId then
		return
	end

	self._modelId = modelId
	local actionData
	if self.enemysex then
		actionData = EffectManager:getInstance():getActionData(self._modelId, self.enemysex)
	else
		actionData = EffectManager:getInstance():getActionData(self._modelId)
	end
	if not actionData then
		cclog("////////////////戰鬥無發現此動畫模型:%d", self._modelId)
	end

	if self._armaturePath then
		AnimateManager:getInstance():releaseArmature(self._armaturePath)
	end

	self._actionData = actionData

	self._armaturePath = actionData:getFileFullPathName()

	--人物模型
	self._armature = AnimateManager:getInstance():getArmature(
		self._armaturePath, 
		actionData:getFileName()
	)

end

--[[
    设置基础属性
]]
function Role:setBaseAttr(heroAttr)

	self._atkBaseArgs = heroAttr
	self.attackSpeed = self._atkBaseArgs.atk_speed

	--设置人物的最大血值
	self:setTotalHp(heroAttr.hp)

end

function Role:setBaseAttrData(value)

	self._attrData = value

	-- self.attackSpeed = self._atkBaseArgs.atk_speed

	--设置人物的最大血值
	self:setTotalHp(self._attrData:getAttr(AttrHelper.attr_flag.hp))

end

-- --角色攻击属性值
-- function Role:getAttackBaseArgs()
-- 	return self._atkBaseArgs
-- end

--[[
    绑定头像显示节点
]]
function Role:setAvatarNode(avatarNode)

	self._avatarNode = avatarNode
	self._avatarNode:initHp(self:getCurrentHp(), self:getTotalHp())
	
end

function Role:getAvatarNode()
	return self._avatarNode
end