EntityBase = class("EntityBase")

EntityBase._actionData = nil

EntityBase._minHp = 0

EntityBase._isFlee = false

--是否已经出局
EntityBase._isOut = false

--队伍中的顺序
EntityBase._teamIndex = 0

--清除显示对象
EntityBase._isClearNode = false

--参战者类型
EntityBase._fighterType = 0

EntityBase._modelId = 0

EntityBase._attrData = nil

EntityBase._skillHaloOffset = nil

function EntityBase:ctor()	

end

function EntityBase:create()

	local eb = EntityBase.new()
	-- eb:initBase()
	return eb
end

function EntityBase:initBase()

	self.stateMachine = StateMachine:create(self)

	self.battleFieldPosition = nil
	self.entityId = nil
	self.entityTypeId = nil	--战斗方
	self.tagId = nil
	
	self._avatorId = 0
	
	self.isDead = false	--是否死亡,true:亡,false:活

	self._currentHp = -1 --当前血值
	
	self._totalHp = 0 --总血值

	self._currentShieldHp = 0 --护盾当前值
	self._shieldHp = 0  --护盾抵挡总值
	
	self.bIsRole = false --是否人物

	--强制攻击目标ID
	self.forceAttackEntityId = nil

	self._armaturePath = nil

	self._hideHpBarFunc = function()
	    self:hideHpBar()
	end

	self._phaseIndex = 0

end

function EntityBase:uninit()

	TimerManager.removeTimer(self._hideHpBarFunc)

	AnimateManager:getInstance():stopAnimationWithFrame(
		self._renderNode:getAnimation()
	)

	self._renderNode:uninit()
	self._renderNode:release()
	self._renderNode = nil

	if self._isClearNode == false then
		AnimateManager:getInstance():releaseArmature(self._armaturePath)
	end
	-- self._armature:stopAllActions()

end

--[[
    设置参战者唯一ID
]]
function EntityBase:setFighterId(value)

	self.entityId = value
end

function EntityBase:setModel(modelId)
end

--[[
    设置战场位置
]]
function EntityBase:setBattleFieldPosition(battleFieldId)
	self.battleFieldPosition = battleFieldId
end

function EntityBase:getBattleFieldPosition()
	return self.battleFieldPosition	
end

function EntityBase:getEntityID()
	return self.entityId
end

function EntityBase:update()
	
end

function EntityBase:handleMessage(state_msg)
	return false	
end

function EntityBase:update()
	self.stateMachine:update()
end

function EntityBase:handleMessage(state_msg)
	self.stateMachine:handleMessage(state_msg)
end

function EntityBase:getStateMachine()
	return self.stateMachine
end

function EntityBase:setEntityType(entityType)
	self.entityTypeId = entityType
end

function EntityBase:getEntityType()
	return self.entityTypeId
end

function EntityBase:getRenderNode()
	return self._renderNode
end

function EntityBase:setRenderNode(argRenderNode)
	self._renderNode = argRenderNode
	self._renderNode:retain()
	-- self._renderNode:initHp(self._currentHp, self._totalHp)
	self._renderNode:initHp(self:getCurrentHp(), self:getTotalHp())
end

function EntityBase:setAvatorId(avatorId)
	self._avatorId = avatorId
end

function EntityBase:getAvatorId()
	return self._avatorId
end

--[[
    设置最小血值
]]
function EntityBase:setMinHp(value)
	self._minHp = value
end

--[[
    设置当前血值
    @param hp
    @param isUseShield 是否使用护盾血值
    @param isBattleInit 是否战斗初始化
]]
function EntityBase:setCurrentHp(hp, isUseShield, isBattleInit)

	if isBattleInit == nil then
		isBattleInit = false
	end

	--死亡状态
	if self.isDead == true then
		return
	end

	local currentHp = 0

	if isBattleInit == false then
		currentHp = BattleManager:getInstance():getDecryptValue(self._currentHp)
	end

	if currentHp == hp then
		return
	end

	if isUseShield == nil then
		isUseShield = true
	end

	repeat
		if self._shieldHp <=0 then
			break
		end

		if not isUseShield then
			break
		end

		if hp > currentHp then
			break
		end

		--更新护盾血值
		self._currentShieldHp = self._currentShieldHp - (currentHp - hp)

		if self._currentShieldHp < 0 then
			hp = currentHp + self._currentShieldHp
			self._currentShieldHp = 0
		else
			hp = currentHp
		end
		
	until true

	currentHp = hp

	--设置最低血值
	if currentHp < self._minHp then
		currentHp = self._minHp
	end

	local totalHp = self:getTotalHp()

	if currentHp <= 0 then
		
		currentHp = 0
		self.isDead = true

		EntityManager:getInstance():setEntityDead(self.entityId)

		BattleStatisticManager:getInstance():setDead(self.entityId, true)

		self._currentHp = BattleManager:getInstance():getEncryptValue(currentHp)

	else
		if currentHp > totalHp then
		    currentHp = totalHp
		end

		self._currentHp = BattleManager:getInstance():getEncryptValue(currentHp)
		
		if not isBattleInit then
			local pass20020
			--血量低于某值时获得被动buff
			if BattleManager:getInstance():getIsOB() == false then
				pass20020 = PassiveSkillManager:getInstance():generate20020(self)
				if pass20020 then
					local roundData = BattleController:getInstance():getRoundManager():getRoundData()
					for entityId, buffList in pairs(pass20020) do
						roundData:addBuff(
							entityId,
							buffList
						)
					end

					BattleReportManager:getInstance():addPassiveSkill(
						self.entityId, 
						1, 
						{
							[self.entityId] = 
							{
								{
								    [1] = 0,
								    [2] = PassiveSkillScriptType.SCRIPT_TYPE_20020,
								    [3] = currentHp,
								    [4] = pass20020
								}
							}
						}
					)
				end
			else
				local reportData = BattleManager:getInstance():getReportData()
				pass20020 = reportData:getPassiveSkill({
				    atkerId = self.entityId,
				    attackTimes = 1,
				    entityId = self.entityId,
				    scriptId = PassiveSkillScriptType.SCRIPT_TYPE_20020
				})

				if pass20020 then
					if tostring(pass20020.hp) == tostring(currentHp) then
						local tempBuffDict = reportData:handleBuff(pass20020.buffDict)

						local roundData = BattleController:getInstance():getRoundManager():getRoundData()
						for entityId, buffList in pairs(tempBuffDict) do
							roundData:addBuff(
								entityId,
								buffList
							)
						end
					end
				end
			end
		end
	end

	--更新头像血值
	if self._avatarNode then
	    self._avatarNode:updateShieldHp(self._currentShieldHp)
		self._avatarNode:setHp(currentHp)
	end

	--更新身上血条
	if self._renderNode then
		self._renderNode:updateShieldHp(self._currentShieldHp)
		self._renderNode:updateHp(currentHp)
		self:showHpBar()
	end

end

--[[
    更新当前血值
    @param value 变化量
    @param isUseShield 是否使用护盾值
]]
function EntityBase:updateCurrentHp(value, isUseShield)

	if value == nil or value == 0 then
		return
	end

	local currentHp = BattleManager:getInstance():getDecryptValue(self._currentHp) + value

	self:setCurrentHp(currentHp, isUseShield)

end

--[[
    设置护盾吸收伤害
]]
function EntityBase:setShieldHp(value)
	self._currentShieldHp = value
	self._shieldHp = value

	if self._renderNode then
		self._renderNode:initShieldHp(value)
	end

	if self._avatarNode then
		self._avatarNode:initShieldHp(value)
	end

end

--[[
    获取当前血值
]]
function EntityBase:getCurrentHp()
	return BattleManager:getInstance():getDecryptValue(self._currentHp)
end

function EntityBase:setTotalHp(hp)
	self._totalHp = BattleManager:getInstance():getEncryptValue(hp)
end

function EntityBase:getTotalHp()
	return BattleManager:getInstance():getDecryptValue(self._totalHp)
end

function EntityBase:updateTotalHp(hp)
	local totalHp = self:getTotalHp()
	if totalHp == hp then
		return
	end

	self:setTotalHp(totalHp)

	--更新头像血值
	if self._avatarNode then
		self._avatarNode:initHp(self:getCurrentHp(), totalHp)
	end

	--更新身上血条
	if self._renderNode then
		self._renderNode:initHp(self:getCurrentHp(), totalHp)
	end

end

function EntityBase:getTotalShieldHp()

	return self._shieldHp
end

--[[
    获取当前护盾血值
]]
function EntityBase:getCurrentShieldHp()
	return self._currentShieldHp
end

function EntityBase:setIsRole(bRole)
	self.bIsRole = bRole
end

function EntityBase:isRole()
	return self.bIsRole
end

--是否可以行动
function EntityBase:canAction()

	if self:getIsOut() then
		return false
	end

	local buffList = BattleController:getInstance():getEntityBuffList(self.entityId)

	if buffList then

		for i, v in ipairs(buffList) do

			if BuffType.prohibitAction[v.id] == true then
				return false
			end
		end
	end

	return true

end

--是否可以使用技能
function EntityBase:canUseSkill()

	if self:canAction() == false then
		return false
	end

	local buffList = BattleController:getInstance():getEntityBuffList(self.entityId)

	if buffList then

		for i, v in ipairs(buffList) do

			if BuffType.prohibitUseSkill[v.id] == true then
				return false
			end
		end
	end

	return true

end

--[[
    显示血条
]]
function EntityBase:showHpBar()

	self._renderNode:setHpVisible(true)

	TimerManager.addTimer(4000, self._hideHpBarFunc, false)
end

function EntityBase:hideHpBar()

	self._renderNode:setHpVisible(false)
end

--[[
    设置强制攻击目标
]]
function EntityBase:setForceAttackTarget(entityId)
	
	self.forceAttackEntityId = entityId
end

--[[
    获取强制攻击的目标
    @return int or nil
]]
function EntityBase:getForceAttackTarget()
	return self.forceAttackEntityId
end

--[[
    设置方向
]]
function EntityBase:setDirection(direction)

	self._renderNode:setDirection(direction)
end

function EntityBase:getDirection()
	return self._renderNode:getDirection()
end

--[[
    获取身体骨骼
]]
function EntityBase:getBodyArmature()
	return self._armature
end

function EntityBase:getAnimation()
	return self._renderNode:getAnimation()
	-- return self._armature:getAnimation()
end

function EntityBase:setPhaseIndex(value)
	self._phaseIndex = value
end

--[[
	在战斗的哪个阶段(1-3场景)
]]
function EntityBase:getPhaseIndex()
	return self._phaseIndex
end

function EntityBase:setIsDead(value)
	self.isDead = value
end

--[[
    是否死亡
]]
function EntityBase:getIsDead()
	return self.isDead
end

--[[
    清除显示节点
]]
function EntityBase:clearDisplayNode()

	if self._isClearNode == true then
		return
	end

	self._isClearNode = true

    self._renderNode:removeFromParentAndCleanup(true)

    AnimateManager:getInstance():releaseArmature(self._armaturePath)

	TimerManager.removeTimer(self._hideHpBarFunc)

end

function EntityBase:getActionData()
	return self._actionData
end

function EntityBase:getModelId()
	return self._modelId
end

--[[
    是否混乱状态
]]
function EntityBase:getIsChaos()

	local buffList = BattleController:getInstance():getEntityBuffList(self.entityId)

	if buffList then
		for i, v in ipairs(buffList) do
			if v.id == BuffType.CHAOS then
			   return true
			end
		end
	end

	return false

end

--[[
    是否只有沉默状态
]]
function EntityBase:getOnlyHasSilent()

	local buffList = BattleController:getInstance():getEntityBuffList(self.entityId)

	if not buffList then
		return false
	end

	local other = false
	local silent = false

	for i, v in ipairs(buffList) do

		if BuffType.prohibitUseSkill[v.id] == true then
			if v.id == BuffType.SILENCE then
				silent = true
			else
				other = true
			end
		end
	end

	if other == false and silent == true then
		return true
	end

	return false

end

function EntityBase:setIsFlee(value)
	self._isFlee = value
end

--[[
    是否逃跑
]]
function EntityBase:getIsFlee()
	return self._isFlee
end

--[[
    是否出局
]]
function EntityBase:getIsOut()
	return self.isDead or self._isFlee
end

function EntityBase:setTeamIndex(value)
	self._teamIndex = value
end

--[[
    战队中的位置
]]
function EntityBase:getTeamIndex()
	return self._teamIndex
end

--战斗属性值
function EntityBase:getAttackBaseArgs()
	return self._atkBaseArgs
end

function EntityBase:getAttrData()
	return self._attrData
end

--设置本次攻击额外属性
function EntityBase:setCurAttackExtraArgs(params)
	self._curAttackExtraArgs = params
end

function EntityBase:getCurAttackExtraArgs()
	return self._curAttackExtraArgs
end

function EntityBase:getBaseInfo()
	return self._baseInfo
end

function EntityBase:getFighterType()
	return self._fighterType
end

function EntityBase:getAgility()
	return self._attrData:getAttr(AttrHelper.attr_flag.atk_speed)
end


--复制的参战者
CloneBaseEntity = class("CloneBaseEntity", DisplayUtil.newNode)

CloneBaseEntity._modelId = 0

CloneBaseEntity._armature = nil
CloneBaseEntity._armaturePath = nil

function CloneBaseEntity:ctor()

end

function CloneBaseEntity:setModel(modelId)

	if self._modelId == modelId then
		return
	end

	self._modelId = modelId

	local actionData = EffectManager:getInstance():getActionData(self._modelId)

	if self._armaturePath then
		AnimateManager:getInstance():releaseArmature(self._armaturePath)
	end

	self._actionData = actionData

	self._armaturePath = actionData._fileFullPathName

	--模型
	self._armature = AnimateManager:getInstance():getArmature(
		actionData._fileFullPathName, 
		actionData._fileName
	)

	self:addChild(self._armature)

end

function CloneBaseEntity:dispose()
	if self._armaturePath then
		AnimateManager:getInstance():releaseArmature(self._armaturePath)
	end
end

function CloneBaseEntity:getArmature()
	return self._armature
end

function CloneBaseEntity:getAnimation()
	return self._armature:getAnimation()
end

function CloneBaseEntity:create()
	return CloneBaseEntity.new()
end
