--
-- Author: thisgf
-- Date: 2014-09-03 12:14:18
-- 战斗控制器

BattleController = class("BattleController")

BattleController._battleScene = nil
BattleController._roundManager = nil
--调度器
BattleController._battleSche = nil

BattleController._openStatisticFunc = nil

local _instance

function BattleController:ctor()

	self._openStatisticFunc = function()
	    self._battleScene:showStatisticView(BattleStatisticManager:getInstance():getHurtSummaryData())
	end

end

function BattleController:getInstance()

	if not _instance then
		_instance = BattleController.new()
	end

	return _instance
end

function BattleController:setBattleScene(value)

	self._battleScene = value
end

function BattleController:setRoundManager(value)

	self._roundManager = value
end

function BattleController:setBattleSche(value)
	self._battleSche = value
end

--[[
    开始新阶段愉快的玩耍
]]
function BattleController:newPhaseAndPlay()

	self._battleScene:showNewPhase()
	self._battleScene:showRoundView()

end

--[[
    更新回合
]]
function BattleController:updateRound(value)

	self._battleScene:updateRound(value)
end

function BattleController:clearBattle()

	self._battleScene = nil
	self._roundManager = nil
end

function BattleController:beginBattle()

	Notifier.regist(CmdName.BATTLE_OPEN_STATISTIC_VIEW, self._openStatisticFunc)
end

function BattleController:endBattle()

    Notifier.remove(CmdName.BATTLE_OPEN_STATISTIC_VIEW, self._openStatisticFunc)
end

--[[
    前置攻击者在目标
]]
function BattleController:setAttackerFront(attackId, targetId)

	local attacker = self:_getEntity(attackId)
	local targeter = self:_getEntity(targetId)

	if not attacker or not targeter then
		return
	end

	local attackerZ = attacker:getRenderNode():getZOrder()
	local targetZ = targeter:getRenderNode():getZOrder()
	--比他大就不管了
	if attackerZ > targetZ then
		return
	end

	attacker:getRenderNode():setZOrder(targetZ + 1)

end

--[[
    重置参战者显示深度
]]
function BattleController:resetFighterDepth(attackId)
	
	local attacker = self:_getEntity(attackId)

	if not attacker then
		return
	end

	local z = BATTLE_LAYER_Z.normalFighter[attacker:getBattleFieldPosition()]
	if attacker:getRenderNode() then
		attacker:getRenderNode():setZOrder(z)
	end

end

--[[
    设置攻击者的方向
]]
function BattleController:setAttackerDirection(attakerId, targetId)

	local attacker = self:_getEntity(attakerId)
	if not attacker then
		return
	end

	local target = self:_getEntity(targetId)
	if not target then
		return
	end

	local attackPos = ccp(attacker:getRenderNode():getPosition())
	local targetPos = ccp(target:getRenderNode():getPosition())

	if targetPos.x >= attackPos.x then
		attacker:setDirection(BattleType.directionType.RIGHT)
	else
		attacker:setDirection(BattleType.directionType.LEFT)
	end

end

--[[
    播放攻击动作
    @param entityId 攻击者ID
    @param attackType 攻击类型
    @param triggerCallback 中间触发回调
    @param callback 动作完成回调
    @param isClone
]]
function BattleController:playAttackAction(entityId, attackType, callback, triggerCallback, isClone)

	if not isClone then
		isClone = false
	end

	local entity
	if isClone then
		entity = EntityManager:getInstance():getCloneEntity(entityId)
	else
		entity = self:_getEntity(entityId)
	end
	if not entity then
		return
	end

	local animation = entity:getAnimation()

	local function movementCallback(armature, movementType, movementID)

		if movementType == ComConstTab.MovementEventType.COMPLETE then

			animation:setMovementEventCallFunc(Helper.tempAction)

			if callback then
				callback()
			end
		end
	end

	if triggerCallback then

		local function frameCallFunc(bone, frameEventName, originFrameIndex, currentFrameIndex)

			animation:setFrameEventCallFunc(Helper.tempAction)
			triggerCallback()
		end

		animation:setFrameEventCallFunc(frameCallFunc)
	end

	local strSkillName = string.format("attack0%d", attackType)

	animation:setMovementEventCallFunc(movementCallback)
	animation:play(strSkillName, -1, -1, 0)

end

--[[
    播放跳入入场动作
]]
function BattleController:playJumpEnterAction(entityId, delayTime, targetPos, callback)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local animation = entity:getAnimation()
	local node = entity:getRenderNode()
	local bodyArmature = node:getBodyArmature()

	node:setVisible(true)

	node:getBodyContainer():setVisible(false)

	local endCount = 0

	local function endFunc()
		endCount = endCount + 1

		if endCount < 1 then
			return
		end

		if callback then
			callback(entityId)
		end

	end

	local function jumpFunc()

		node:getBodyContainer():setVisible(true)

		local function movementCallback(armature, movementType, movementID)

			if movementType == ComConstTab.MovementEventType.COMPLETE then

				animation:setMovementEventCallFunc(Helper.tempAction)

				endFunc()

			end
		end

		animation:setMovementEventCallFunc(movementCallback)
		animation:play(Helper.ModelActionType.ENTER, -1, -1, 0)

	end

	local function delayCallFunc()

		EffectManager:getInstance():playEffect(node:getEffectContainer(), 25001, nil, 0, false, 1)
	end

	local actionArray = CCArray:create()
	local delayAction = CCDelayTime:create(delayTime * 0.001)
	actionArray:addObject(delayAction)
	local callAction = CCCallFunc:create(delayCallFunc)
	actionArray:addObject(callAction)
	delayAction = CCDelayTime:create(0.2)
	actionArray:addObject(delayAction)
	callAction = CCCallFunc:create(jumpFunc)
	actionArray:addObject(callAction)

	node:runAction(CCSequence:create(actionArray))

end

--[[
    播放闪入入场动作
    @param entityId
    @param enterType 进入类型
    @param delayTime 延迟时间
    @param callback
]]
function BattleController:playFlashEnterAction(entityId, delayTime, callback)

	-- callback()

	-- return

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local node = entity:getRenderNode()
	node:setVisible(false)

	local flashCount = 0
	local function flashFunc()

		flashCount = flashCount + 1

		if flashCount < 2 then
			return
		end

		if callback then
			callback(entityId)
		end

	end

	local function delayCallFunc()
		--特效
		EffectManager:getInstance():playEffect(node:getEffectContainer(), 25000, flashFunc, 0, false, 1)
	end

	local function delayCallFunc2()

		node:setVisible(true)

		local actionData = EffectManager:getInstance():getActionData(entity:getBaseInfo():getModelId())

		if actionData.enterFromFrame == nil then
			flashFunc()
		else
			--动作
			AnimateManager:getInstance():playAnimationWithFrame(
				entity:getAnimation(), 
				Helper.ModelActionType.ENTER, 
				actionData.enterFromFrame, 
				actionData.enterToFrame, 
				1, 
				flashFunc
			)
		end

	end

	local actionArray = CCArray:create()
	local delayAction = CCDelayTime:create(delayTime * 0.001)
	actionArray:addObject(delayAction)
	actionArray:addObject(CCCallFunc:create(delayCallFunc))
	local delayAction2 = CCDelayTime:create(0.3)
	actionArray:addObject(delayAction2)
	actionArray:addObject(CCCallFunc:create(delayCallFunc2))

	node:runAction(CCSequence:create(actionArray))
	
end

--[[
    播放跑入入场动作
    @param entityId
    @param time
    @param startPos
    @param targetPos
    @param callback
]]
function BattleController:playRunEnterAction(entityId, time, startPos, targetPos, callback)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local node = entity:getRenderNode()

	node:setPosition(startPos)

	local function moveFunc()
		callback(entityId)
	end

	local moveAction = CCMoveTo:create(time, targetPos)
	local callAction = CCCallFunc:create(moveFunc)

	local animation = entity:getAnimation()
	animation:play(Helper.ModelActionType.RUN)

	node:runAction(CCSequence:createWithTwoActions(moveAction, callAction))

end

--[[
    站立入场
]]
function BattleController:playStandEnterAction(entityId, pos, callback)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local node = entity:getRenderNode()
	node:setPosition(pos)

	callback(entityId)

end


--[[
    播放受伤动作
    @param entityId
    @param isMove 是否移动
]]
function BattleController:playHurtAction(entityId, isMove)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local animation = entity:getAnimation()

	animation:stop()
	animation:play(Helper.ModelActionType.HURT, -1, -1, 1)

	if isMove == true then

		local entityType = entity:getEntityType()

		local xDist = 0
		if entityType == BattleType.ATTACKER then
			xDist = -30
		else
			xDist = 30
		end

		local mainContainer = entity:getRenderNode():getMainContainer()

		mainContainer:setPosition(ccp(xDist, 0))

	end

end

--[[
    复位受伤动作
]]
function BattleController:resetHurtAction(entityId, time, callback)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local mainContainer = entity:getRenderNode():getMainContainer()

	local moveAction = CCMoveTo:create(time, ccp(0, 0))
	local callAction = CCCallFunc:create(function() 
		if callback then 
			callback(entityId)
		end 
	end)

	-- mainContainer:setPosition(ccp(0, 0))
	mainContainer:runAction(CCSequence:createWithTwoActions(moveAction, callAction))

end

--[[
    播放受伤震动
    @param entityId
    @param shakeLevel 震动等级
]]
function BattleController:playHurtShakeAction(entityId, shakeLevel)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local shakeX = 0
	local shakeNum = 0

	if shakeLevel == 0 then
		shakeX = 4
		shakeNum = 7
	else
		shakeX = 2
		shakeNum = 3
	end

	local mainContainer = entity:getRenderNode():getMainContainer()

	local rawPos = ccp(mainContainer:getPosition())


	local actionArray = CCArray:create()

	local function shakeFunc()
		mainContainer:setPosition(rawPos.x + shakeX, rawPos.y)
		shakeX = shakeX * -1
	end

	for i = 1, shakeNum do

		local delayAction = CCDelayTime:create(0.04)
		local shakeAction = CCCallFunc:create(shakeFunc)

		actionArray:addObject(delayAction)
		actionArray:addObject(shakeAction)
	end

	actionArray:addObject(CCCallFunc:create(function()
			mainContainer:setPosition(rawPos)
		end))

	mainContainer:runAction(CCSequence:create(actionArray))

end

function BattleController:playMissAction(entityId, callback)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local actionArray = CCArray:create()

	local xDist = 0
	local duration = 0.25
	if entity:getEntityType() == BattleType.ATTACKER then
		xDist = -40
	else
		xDist = 40
	end

	local mainContainer = entity:getRenderNode():getMainContainer()

	local moveAction = CCMoveTo:create(duration, ccp(xDist, 0))
	actionArray:addObject(moveAction)
	local resetAction = CCMoveTo:create(0.1, ccp(0, 0))
	actionArray:addObject(resetAction)
	actionArray:addObject(CCCallFunc:create(function() mainContainer:setPosition(ccp(0, 0)); callback() end))
	mainContainer:runAction(CCSequence:create(actionArray))

end

--[[
    播放站立动作
]]
function BattleController:playStandAction(entityId)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	if entity:getIsDead() == true then
		return
	end

	local animation = entity:getAnimation()
	if animation:getCurrentMovementID() == Helper.ModelActionType.STAND then
		return
	end

	animation:play(Helper.ModelActionType.STAND, -1, -1, 1)

end

--[[
    播放站立动作2
]]
function BattleController:playStandAction2(entityId)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	if entity:getIsDead() == true then
		return
	end

	local animation = entity:getAnimation()
	if animation:getCurrentMovementID() == Helper.ModelActionType.STAND_2 then
		return
	end

	animation:play(Helper.ModelActionType.STAND_2, -1, -1, 1)

end

--[[
    播放死亡动作
]]
function BattleController:playDeadAction(entityId, callback)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	--播放死亡音效
	local baseInfo = entity:getBaseInfo()
	local deadAudioId = baseInfo.dead_audio_id
	if entity:isRole() then
		if baseInfo.base_id == HeroManager.LEADING_HERO_ID then
			local sex = CharacterManager:getInstance():getBaseData():getSex()
			if sex == Helper.sex.male then
				deadAudioId = 10012
			else
				deadAudioId = 10013
			end
		end
	end

	self:playAudio(deadAudioId, 0)
	

	--是否有复活
	local reviveHp
	if BattleManager:getInstance():getIsOB() then
		local psData = BattleManager:getInstance():getReportData():getPassiveSkill({
		    atkerId = entityId,
		    attackTimes = 1,
		    entityId = entityId,
		    scriptId = PassiveSkillScriptType.SCRIPT_TYPE_20010
		})

		if psData then
			reviveHp = psData.reviveHp
			self:addReviveEntity(entityId, psData.reviveHp)
		end

	else
		reviveHp = PassiveSkillManager:getInstance():generate20010(entity)
		if reviveHp then
			self:addReviveEntity(entityId, reviveHp)
			BattleReportManager:getInstance():addPassiveSkill(
				entityId, 
				1, 
				{
				    [entityId] = {
				        {
				            [2] = PassiveSkillScriptType.SCRIPT_TYPE_20010, 
				            [3] = reviveHp
				        }
				    }
			    }
			)
		end

	end

	local function fadeFunc()

		self._roundManager:removeDeadProcessEntity(entityId)
		self:removeEntity(entityId)
	end

	--死亡移除buff
	self._roundManager:getRoundData():clearEntityBuff(entityId)
	self._roundManager:getRoundData():removeHalo(entityId)

	entity:getRenderNode():clearAllEffect()

	local animation = entity:getAnimation()

	local function movementCallback(armature, movementType, movementID)

		if movementType == ComConstTab.MovementEventType.COMPLETE then

			animation:setMovementEventCallFunc(Helper.tempAction)

			if reviveHp then
				-- fadeFunc()
				self._roundManager:removeDeadProcessEntity(entityId)
			else
				self:playEntityFade(entityId, 0.3, 0.5, fadeFunc)
			end

			-- self:playEntityFade(entityId, 0.3, 0.5, fadeFunc)

		end
	end

	self._roundManager:addDeadProcessEntity(entityId)

	TimerManager.addTimer(500, 
		function() 
			if callback then 
				callback(entityId) 
			end 
		end, 
		false)

	animation:setMovementEventCallFunc(movementCallback)
	animation:play(Helper.ModelActionType.DEAD, -1, -1, 0)

end

--[[
    播放参战者透明
]]
function BattleController:playEntityFade(entityId, delayTime, time, callback)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local actionArray = CCArray:create()

	local function fadeFunc()
		if callback then
			callback()
		end
	end

	local delayAction = CCDelayTime:create(delayTime)
	actionArray:addObject(delayAction)
	local fadeAction = CCFadeTo:create(time, 0)
	actionArray:addObject(fadeAction)
	local callAction = CCCallFunc:create(fadeFunc)
	actionArray:addObject(callAction)

	local body = entity:getBodyArmature()

	body:runAction(CCSequence:create(actionArray))

end

--[[
    播放复活动作
]]
function BattleController:playReviveAction(entityId, callback)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local function animateFunc()
		if callback then
			callback(entityId)
		end
	end

	if entity:getIsDead() == false then
		
		animateFunc()
		return
	end

	local animation = entity:getAnimation()

	local function movementFunc(armature, movementType, movementID)
		if movementType == ComConstTab.MovementEventType.COMPLETE then
			animation:setMovementEventCallFunc(Helper.tempAction)
			animateFunc()
		end
	end
	
	animation:setMovementEventCallFunc(movementFunc)
	animation:play(Helper.ModelActionType.REVIVE, -1, -1, 0)

	-- AnimateManager:getInstance():playAnimationWithFrame(
	-- 	animation, 
	-- 	Helper.ModelActionType.DEAD,
	-- 	22,
	-- 	1,
	-- 	1,
	-- 	animateFunc
	-- )

end

--[[
    设置成站立状态
]]
function BattleController:setStandState(entityId)

	self:playStandAction(entityId)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	if entity:getEntityType() == BattleType.ATTACKER then
		entity:setDirection(BattleType.directionType.RIGHT)
	else
		entity:setDirection(BattleType.directionType.LEFT)
	end

end

function BattleController:playEntityAction(name, loopCount, completeFunc, triggerFunc)


end

function BattleController:playRunAction(entityId)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local animation = entity:getAnimation()
	animation:play(Helper.ModelActionType.RUN)

end

--[[
    播放群体特效
    @param effectIds 特效id列表
    @param targetList 目标列表
    @param callback
]]
function BattleController:playGroupEffect(effectIds, targetList, callback)

	-- local effectContainer = self._battleScene:getEffectContainer()

	local effectLen = #effectIds

	local entity

	local xpos = 0
	local ypos = 0

	local len = 0

	local entityType = 0

	for i, entityId in ipairs(targetList) do
		entity = self:_getEntity(entityId)
		if entity then

			entityType = entity:getEntityType()

			local entityX, entityY = entity:getRenderNode():getPosition()

			xpos = xpos + entityX
			ypos = ypos + entityY

			len = len + 1
		end
	end

	local function effectFunc()

		effectLen = effectLen - 1
		if effectLen <= 0 then
			callback()
		end
	end

	xpos = xpos / len
	ypos = ypos / len

	local em = EffectManager:getInstance()
	for _, id in ipairs(effectIds) do

		local effectData = em:getEffectData(id)

		if effectData:getHierarchy() == EffectHierarchyType.BOTTOM then
			container = self._battleScene:getBottomEffectContainer()
		else
			container = self._battleScene:getEffectContainer()
		end

		local effect = EffectManager:getInstance():playEffect(container, id, effectFunc, 0, true)
		effect:setPosition(ccp(xpos, ypos))

		if entityType == BattleType.ATTACKER then
			if effectData:needFlip() == true then
				effect:setScaleX(-1)
			else
				effect:setScaleX(1)
			end
		end

	end

end

--[[
    播放阵营技能光环
]]
function BattleController:playCampSkillHonor(entityType)

	local roundData = self._roundManager:getRoundData()

	local fighterTeam = nil

	local skillIndex

	if entityType == BattleType.ATTACKER then
		fighterTeam = roundData.attackerTeam
		skillIndex = roundData:getGemColor()
	else
		fighterTeam = roundData.strikerTeam

		skillIndex = roundData:getEnemyGemColor()
	end

	local effectId

	if skillIndex == BattleStoneType.colorType.RED then
		effectId = 10001
	elseif skillIndex == BattleStoneType.colorType.BLUE then
		effectId = 10002
	else
		effectId = 10003
	end

	roundData:setSkillHonor(entityType, effectId)
	local entity
	for i, entityId in ipairs(fighterTeam) do
		entity = EntityManager:getInstance():getEntityWithID(entityId)
		self:playEffectWithEntity(
			entityId, 
			{effectId}, 
			0, 
			nil, 
			entity:getActionData().skillHaloOffset
		)
	end

end

function BattleController:stopCampSkillHonor(entityType)

	local roundData = self._roundManager:getRoundData()

	local fighterTeam = nil

	local effectId = roundData:getSkillHonor(entityType)

	if entityType == BattleType.ATTACKER then
		fighterTeam = roundData.attackerTeam
	else
		fighterTeam = roundData.strikerTeam
	end

	for i, entityId in ipairs(fighterTeam) do
		self:removeEffectWithEntity(entityId, effectId)
	end

end

--[[
    播放参战者特效
    @param entityId
    @param effectIds
    @param loopType
    @param callFunc
]]
function BattleController:playEffectWithEntity(entityId, effectIds, loopType, callFunc, pos)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	if not effectIds then
		return
	end

	local effectLen = 0

	effectLen = #effectIds

	local function effectFunc()
		effectLen = effectLen - 1
		if effectLen > 0 then
			return
		end
		if callFunc then
			callFunc()
		end
	end

	if effectLen == 0 then
		effectFunc()
		return
	end

	local em = EffectManager:getInstance()

	for _, effectId in ipairs(effectIds) do

		if effectId == 0 then
			effectFunc()
		else
			local effectData = em:getEffectData(effectId)

			local container

			if effectData:getHierarchy() == EffectHierarchyType.BOTTOM then
				container = entity:getRenderNode():getBottomEffectContainer()
			else
				container = entity:getRenderNode():getEffectContainer()
			end

			local effect = EffectManager:getInstance():playEffect(
				container, 
				effectId, 
				effectFunc, 
				0, 
				false, 
				loopType
			)

			if effect then
				self:setEffectDirection(effect, entityId)
				if pos then
					effect:setPosition(pos)
				end
			end
		end
		
	end

end

--[[
    移除容器特效
]]
function BattleController:removeEffectWithEntity(entityId, effectId)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local em = EffectManager:getInstance()
	local effectData = em:getEffectData(effectId)

	local container

	if effectData:getHierarchy() == EffectHierarchyType.BOTTOM then
		container = entity:getRenderNode():getBottomEffectContainer()
	else
		container = entity:getRenderNode():getEffectContainer()
	end

	EffectManager:getInstance():removeEffect(container, effectId)

end

--[[
    播放播报特效
]]
function BattleController:playBroadcastEffect(entityId, effectId, pos, playTimes)

	


end

function BattleController:stopBroadcastEffect(entityId)

end

--[[
    设置特效方向
]]
function BattleController:setEffectDirection(effect, entityId)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	if entity:getEntityType() == BattleType.STRIKER then
		return
	end

	if not effect then
		return
	end

	local data = effect:getData()
	if data:needFlip() == true then
		effect:setScaleX(1)
	else
		effect:setScaleX(-1)
	end

end

--[[
    移除参战者
]]
function BattleController:removeEntity(entityId)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	-- EntityManager:getInstance():removeEntity(entity)

	-- entity:getRenderNode():setVisible(false)

	entity:clearDisplayNode()

end

--[[
    播放奥义特效
]]
function BattleController:playUpanisadEffect(callback)

	local effectContainer = self._battleScene:getUILayer()

	local armature = AnimateManager:getInstance():getArmature("ui/effects/aoyibisha/aoyibisha.ExportJson", "aoyibisha")
	local animation = armature:getAnimation()

	local sex = CharacterManager:getInstance():getBaseData():getSex()

	local function movementCallback(armature, movementType, movementID)

		if movementType == ComConstTab.MovementEventType.COMPLETE then

			animation:setMovementEventCallFunc(Helper.tempAction)

			if callback then
				callback()
			end
		end
	end

	animation:setMovementEventCallFunc(movementCallback)

	if sex == Helper.sex.female then
		animation:play("nv", -1, -1, 0)
	else
		animation:play("nan", -1, -1, 0)
	end

	armature:setPosition(ccp(DisplayUtil.visibleSize.width*0.5, DisplayUtil.visibleSize.height*0.5))
	effectContainer:addChild(armature)
	armature:setZOrder(10)
	local sameScale = DisplayUtil.getNoBorderScaleValue(1600, 560)
	armature:setScaleX(1 / DisplayUtil.viewScale.x * sameScale)
	armature:setScaleY(1 / DisplayUtil.viewScale.y * sameScale)

	-- local effect = EffectManager:getInstance():playEffect(effectContainer, 10000, callback)
	-- effect:setPosition(ccp(DisplayUtil.visibleSize.width*0.5, DisplayUtil.visibleSize.height*0.5))
	-- effect:setZOrder(10)
	-- local sameScale = DisplayUtil.getNoBorderScaleValue(1600, 560)

	-- --根据屏幕缩放
	-- effect:setScaleX(1 / DisplayUtil.viewScale.x * sameScale)
	-- effect:setScaleY(1 / DisplayUtil.viewScale.y * sameScale)

end

function BattleController:showUpanisadShadow(value)
	self._battleScene:showUpanisadShadow(value)
end

--[[
    播放目标触发文本
    @param textType miss or block
]]
function BattleController:playTargetTriggerText(entityId, textType)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	self._battleScene:displayTriggerText(entity:getRenderNode(), textType)

end

function BattleController:displayTreasureText(entityId, num)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	self._battleScene:displayTreasureText(entity:getRenderNode(), num)

end

--只是显示地图
function BattleController:showMapOnly(value)
	self._battleScene:showMapOnly(value)
end

function BattleController:moveMapBy(xDist, callback, time)

	self._battleScene:moveMapBy(xDist, callback, time)
end

function BattleController:jumpMapTo(x)
	self._battleScene:jumpMapTo(x)
end

--[[
    移动地图到下一张
]]
function BattleController:moveMapToNext()

	self._battleScene:moveMapToNext()
end

--[[
    显示战斗结果
]]
function BattleController:showBattleResult()
	self._battleSche:showBattleResult()
end

--[[
    显示攻击次数
]]
function BattleController:showHitsTimes(currentTimes, totalTimes)
	self._battleScene:showHitsView(currentTimes, totalTimes)
end

--[[
    移除buff
]]
function BattleController:removeBuff(entityId, buffId)

	self._roundManager:getRoundData():removeBuff(entityId, buffId)
end

--[[
    计算地图移动
]]
function BattleController:calcMapMovePos(rawDist)
	return self._battleScene:calcMapMovePos(rawDist)
end

--[[
    添加动画到地图
]]
function BattleController:addAnimationToMap(animation)
	self._battleScene:addAnimationToMap(animation)
end

--[[
    播放buff添加的特效
]]
function BattleController:playEntityBuffAddEffect(entityId)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local buffList = self._roundManager:getRoundData():getTempBuff(entityId)

	if not buffList then
		return
	end

	for _, buffData in ipairs(buffList) do

		if buffData.addEffectId ~= 0 then

			self._battleScene:displayAddBuffEffect(entity:getRenderNode(), buffData)
		end
	end

end

--[[
    设置参战者在下层容器
]]
function BattleController:setFighterDownDepth(entityId)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local node = entity:getRenderNode()
	node:setZOrder(BATTLE_LAYER_Z.downFighter[entity:getBattleFieldPosition()])

end

--[[
    设置地图处于哪个场景
]]
function BattleController:setMapIndex(value)
	self._battleScene:getMapNode():setSceneIndex(value)
end

--[[
    在targetList里面获取符合目标类型的目标字典
    @param targetType
    @param targetNum
    @param targetList
]]
function BattleController:getAccordTarget(targetType, numTarget, targetList, attacker)

	local targeterList = {}

	for _, entityId in ipairs(targetList) do
		local entity = self:_getEntity(entityId)
		if entity and entity:getIsDead() == false then
			table.insert(targeterList, entity)
		end
	end

	local params = {}
	params.targetType = targetType
	params.numTarget = numTarget
	params.targetList = targeterList
	params.attackerId = attacker:getEntityID()

	return PassiveSkillManager:getInstance():validTarget(params)

end

--[[
    移动战斗ui
]]
function BattleController:moveUI()
	self._battleScene:moveUIWithStart()
end

function BattleController:playAudio(audioId, delayTime)
	
	if audioId == 0 then
		return
	end

	if delayTime > 0 then
		TimerManager.addTimer(
			delayTime, 
			function()
				AudioEngine.playEffect(audioId, false)
			end, 
			false
		)
	else
		AudioEngine.playEffect(audioId, false)
	end

end

--[[
    播放特效飞行
]]
function BattleController:playEffectFlyTo(params)

	local traceType = params.traceType
	local effectId = params.effectId
	local attacker = params.attacker
	local target = params.target
	local callback = params.callback
	local callParam = params.callParam

	local em = EffectManager:getInstance()

	if traceType then

		local effectData = em:getEffectData(effectId)

		local moveSpeed = effectData:getMoveSpeed()
		if moveSpeed == 0 then
			moveSpeed = 3000
		end

		local effectContainer = self._battleScene:getEffectContainer()

		local effect = em:playEffect(
			effectContainer,
			effectId, 
			nil, 
			0, 
			true, 
			-1, 
			false
		)

		local attackPos = ccp(attacker:getRenderNode():getPosition())
		local targetPos = ccp(target:getRenderNode():getPosition())

		local effectSize = effect:getContent():getContentSize()
		local fromPos = ccp(0, 0)
		local toPos = ccp(0, 0)

		local addDegree = 0
		local curveDegree = 180
		local initScale = 1
		local offsetX = 0
		local offsetY = 0

		local targetOffsetX = 0
		local targetOffsetY = 0

		local moveAction = nil


		local worldPos = DisplayUtil.getWorldPos(effect)

		local distPos = ccp(0, 0)

		if traceType == EffectMoveTraceType.DOWN then

			distPos.y = DisplayUtil.visibleSize.height - worldPos.y

			fromPos.y = distPos.y + 50

		elseif traceType == EffectMoveTraceType.OBLIQUE45 then

			distPos.y = DisplayUtil.visibleSize.height - worldPos.y

			fromPos.y = distPos.y
			fromPos.x = distPos.y / math.sin(math.pi/4)

			if effectActionArgs.atkDirectionType ~= BattleType.ATTACKER then
				fromPos.x = fromPos.x * -1
			end

		else

			if effectData:getFlyStartPos() then
				offsetX = effectData:getFlyStartPos().x
				offsetY = effectData:getFlyStartPos().y
			end

			if effectData:getFlyTargetPos() then

				targetOffsetX = effectData:getFlyTargetPos().x
				targetOffsetY = effectData:getFlyTargetPos().y

				toPos.y = targetPos.y + targetOffsetY
			else
				toPos.y = targetPos.y + target:getRenderNode():getBodySize().height * 0.5
			end

			fromPos.y = attackPos.y + offsetY

			if traceType == EffectMoveTraceType.CURVE then

				toPos.x = targetPos.x
				if target:getEntityType() == BattleType.ATTACKER then
					fromPos.x = attackPos.x + offsetX
				else
					fromPos.x = attackPos.x - offsetX
					-- curveDegree = 180
				end

				effect:setVisible(false)

			else

				if target:getEntityType() == BattleType.ATTACKER then

					fromPos.x = attackPos.x + offsetX
					toPos.x = targetPos.x + effectSize.width * 0.25

					addDegree = 180

				else

					fromPos.x = attackPos.x - offsetX
					toPos.x = targetPos.x - effectSize.width * 0.25

					initScale = -1

				end

				local angle = MathUtil.getAngleWithTwoPoint(fromPos, toPos)
				--因为特效默认是向左的
				effect:setRotation(MathUtil.rad2deg(angle) + addDegree)

				effect:setScaleX(initScale)

			end

		end

		effect:setPosition(fromPos)

		local len = MathUtil.getDistance(fromPos, toPos)

		local flyTime = len / moveSpeed
		-- flyTime = flyTime * 20
		
		local flyComplete = function(effect)
			EffectManager:getInstance():removeEffect(effect:getContainer(), effect:getEffectId(), effect:getSameUnique())
			callback(target:getEntityID(), callParam)
		end

		if traceType == EffectMoveTraceType.CURVE then

			local point1 = ccp(0, 0)
			point1.x = (fromPos.x + toPos.x) * math.random(3, 4)*0.1
			point1.y = toPos.y + 200 + math.random(50, 80)

			local point2 = ccp(0, 0)
			point2.x = (fromPos.x + toPos.x) * math.random(6, 7)*0.1
			point2.y = toPos.y + 200 + math.random(50, 80)

			local bezierConfig = ccBezierConfig()

			if attacker:getEntityType() == BattleType.ATTACKER then
				bezierConfig.controlPoint_1 = point1
				bezierConfig.controlPoint_2 = point2
			else
				bezierConfig.controlPoint_1 = point2
				bezierConfig.controlPoint_2 = point1
			end
			bezierConfig.endPosition.x = toPos.x
			bezierConfig.endPosition.y = toPos.y
			moveAction = CCBezierToWithAngle:create(flyTime, bezierConfig)
			moveAction:setInitAngle(curveDegree)

		else

			moveAction = CCMoveTo:create(flyTime, toPos)
		end

		local animateArray = CCArray:create()
		animateArray:addObject(CCShow:create())
		animateArray:addObject(moveAction)
		animateArray:addObject(CCCallFuncN:create(flyComplete))
		local action = CCSequence:create(animateArray)
		effect:runAction(action)

	else

		EffectManager:getInstance():playEffect(
			effectContainer,
			effectActionArgs.effectId,
			callback,
			0,
			false,
			-1
		)
	end

end

--[[
    闪烁参战者到目标
    @param entityId
    @param targetId
    @param callback
]]
function BattleController:blinkEntityTo(entityId, targetId, blinkDist, callback)

	local attacker = self:_getEntity(entityId)
	local targeter = self:_getEntity(targetId)

	if not attacker or not targeter then
		return
	end

	local animation = attacker:getAnimation()

	local function movementCallback(armature, movementType, movementID)

		if movementType == ComConstTab.MovementEventType.COMPLETE then

			animation:setMovementEventCallFunc(Helper.tempAction)

			local entityPos = ccp(attacker:getRenderNode():getPosition())
			local targetPos = ccp(targeter:getRenderNode():getPosition())

			local offsetX
			if targetPos.x > entityPos.x then
				offsetX = -blinkDist
			else
				offsetX = blinkDist
			end

			attacker:getRenderNode():setPosition(
				ccp(
					targetPos.x + offsetX, 
					targetPos.y
				)
			)

			if callback then
				callback()
			end
		end
	end

	animation:setMovementEventCallFunc(movementCallback)
	animation:play(Helper.ModelActionType.BLINK, -1, -1, 0)

end

--[[
    闪烁回去
]]
function BattleController:blinkEntityBack(entityId, callback)

	local attacker = self:_getEntity(entityId)
	if not attacker then
		return
	end

	local pos = self._battleScene:getFighterPos(entityId)
	attacker:getRenderNode():setPosition(pos.x, pos.y)

	if callback then
		callback()
	end

end

--[[
    播放逃跑动作
]]
function BattleController:playFleeAction(entityId, callback)

	local entity = self:_getEntity(entityId)
	if not entity then
		return
	end

	local targetPos

	if entity:getEntityType() == BattleType.ATTACKER then
		targetPos = ccp(-100, entity:getRenderNode():getPositionY())
	else
		targetPos = ccp(960 + 100, entity:getRenderNode():getPositionY())
	end

	self._battleScene:moveFighter(entity, targetPos, 0.2, callback, entityId)

end

function BattleController:_getEntity(id)
	return EntityManager:getInstance():getEntityWithID(id)
end

function BattleController:getHurtGroup(curEntId)
	local roundData = self._roundManager:getRoundData()
	local hurtGroup = roundData:getRoundAttackTargets(curEntId)
	return hurtGroup
end

function BattleController:getAttackSkillData(curEntId)
	local roundData = self._roundManager:getRoundData()
	local attackSkillData = roundData:getRoundAttackSkillData(curEntId)
	return attackSkillData
end

function BattleController:addBuffToEntity(entityId)

	self._roundManager:addBuffToEntity(entityId)
end

--[[
    更新参战者的血值
    @param entityId
    @param changeHp
    @param isPlayDeadAction
]]
function BattleController:updateEntityHp(entityId, changeHp, isPlayDeadAction, actionCallback, isUseShield)

	local entity = EntityManager:getInstance():getEntityWithID(entityId)

	if not entity then
		return
	end

	--死亡了不用变血
	if entity:getIsDead() == true then
		return
	end

	if changeHp == 0 or changeHp == nil then
		return
	end

	if isPlayDeadAction == nil then
		isPlayDeadAction = true
	end

	if isUseShield == nil then
		isUseShield = true
	end

	local lastHp = entity:getCurrentHp()
	entity:updateCurrentHp(changeHp, isUseShield)
	local hpGap = entity:getCurrentHp() - lastHp

	--发生变化
	if changeHp > 0 or hpGap ~= 0 then
		local param = {}
		param.node = entity:getRenderNode()
		param.hurtNum = changeHp
		param.delayTime = 0
		self:displayHurtNum(param)
	end

	if isPlayDeadAction and entity:getIsDead() == true then

		BattleController:getInstance():playDeadAction(entityId, actionCallback)

		return true
	end

end

--[[
    播放被动技能效果
]]
function BattleController:playPasSkillEffect(entityId, scriptId)

	local pasData = SkillManager:getInstance():getPasEffectData(scriptId)
	if not pasData then
		return
	end

	self:playEffectWithEntity(entityId, {pasData.effectId}, 1, nil)

end

--[[
    显示血值飘动
]]
function BattleController:displayHurtNum(param)

	self._battleScene:displayHurtNum(param)
end

function BattleController:addReviveEntity(entityId, reviveHp)
	local roundData = self._roundManager:getRoundData()
	roundData:addReviveEntity(entityId, reviveHp)
end

--[[
    播放精灵入场效果
    @param camp 阵营
    @param star 阶数
]]
function BattleController:playDemonEnter(camp, star, callback)

	if star < 1 then
		return
	end

	local petData = PetDataProxy:getInstance():getUpgradeCostVoById(star)
	local armature = AnimateManager:getInstance():getArmatureFromEffectId(petData.action_id)
	if not armature then
		return
	end

	local pArmature

	local animation = armature:getAnimation()

	local function movementCallback(armature, movementType, movementID)
		if movementType == ComConstTab.MovementEventType.COMPLETE then
			animation:setMovementEventCallFunc(Helper.tempAction)
			armature:removeFromParentAndCleanup(true)
			pArmature:removeFromParentAndCleanup(true)

			if callback then
				callback()
			end
		end
	end

	animation:setMovementEventCallFunc(movementCallback)
	animation:play(Helper.ModelActionType.ENTER, -1, -1, 0)

	pArmature = AnimateManager:getInstance():getArmatureFromEffectId(25003)

	local sx = 255
	local sy = 300

	local container = self._battleScene:getEffectContainer()
	if camp == BattleType.ATTACKER then
		armature:setPosition(ccp(sx, sy))
		armature:setScaleX(-1)
		pArmature:getAnimation():play("zuo", -1, -1, 0)
		pArmature:setPosition(ccp(armature:getPosition()))
	else
		armature:setPosition(
			ccp(
			    DisplayUtil.visibleSize.width - sx, 
			    sy
			)
		)
		pArmature:getAnimation():play("you", -1, -1, 0)
		pArmature:setPosition(ccp(armature:getPosition()))
	end

	container:addChild(armature)
	
	container:addChild(pArmature)

end

--[[
    小精灵添加的战斗力
]]
function BattleController:playDemonAddFC(camp, fc)

	if fc <= 0 then
		return
	end

	local container = self._battleScene:getEffectContainer()

	local sx = 235
	local sy = 540

	local armature
	local animation

	local function frameFunc(bone, frameEventName, originFrameIndex, currentFrameIndex)

		local labelNum = CCLabelAtlas:create(
			tostring(fc), 
			"ui/digit/fc_addition_num.png", 
			24, 
			34, 
			48
		)

		labelNum:setAnchorPoint(ccp(0.5, 0.5))
		labelNum:setPosition(ccp(0, -40))
		armature:addChild(labelNum, 10)

		labelNum:setScale(3)
		local scaleAction = CCScaleTo:create(0.2, 1)
		labelNum:runAction(scaleAction)

	end

	local function movementFunc(armature, movementType, movementID)

		if movementType == ComConstTab.MovementEventType.COMPLETE then

			armature:removeFromParentAndCleanup(true)
		end
	end

	local function playFunc()
		armature = EffectManager:getInstance():createUIAnimate("XJLzhanlitisheng")

		if camp == BattleType.ATTACKER then
			armature:setPosition(ccp(sx, sy))
		else
			armature:setPosition(ccp(
			    DisplayUtil.visibleSize.width - sx, 
			    sy
			))
		end

		container:addChild(armature)
		animation = armature:getAnimation()
		animation:playWithIndex(0, -1, -1, 0)
		animation:setFrameEventCallFunc(frameFunc)
		animation:setMovementEventCallFunc(movementFunc)
	end

	TimerManager.addTimer(2500, playFunc, false)

end

--[[
    更新参战者模型
]]
function BattleController:updateEntityModel(id, modelId, ft)

	ft = ft or BattleType.ROLE

	local entity = EntityManager:getInstance():getEntityWithBaseId(ft, id)
	if not entity then
		return
	end

	entity:setModel(modelId)
	entity:getRenderNode():setBodyModel(entity:getBodyArmature())

	self:playStandAction(entity:getEntityID())

end

--[[
    变身
]]
function BattleController:transformEntity(id, modelId)

	local entity = EntityManager:getInstance():getEntityWithBaseId(BattleType.ROLE, id)
	if not entity then
		return
	end

	--攻击, 气血乘2
	local attrData = entity:getAttrData()
	local attack = attrData:getAttr(AttrHelper.attr_flag.atk)
	attack = attack * 2
	attrData:setAttr(AttrHelper.attr_flag.atk, attack)

	local hp = attrData:getAttr(AttrHelper.attr_flag.hp)
	local curHp = entity:getCurrentHp()
	local percent = curHp/hp

	hp = hp * 2
	attrData:setAttr(AttrHelper.attr_flag.hp, hp)

	entity:updateTotalHp(hp)
	curHp = math.floor(hp * percent)
	entity:setCurrentHp(curHp)

	self:updateEntityModel(id, modelId)

end

--[[
    添加复制的参战者
]]
function BattleController:addCloneEntity(entityId, pos, zOrder)

	local rawEntity = self:_getEntity(entityId)
	if not rawEntity then
		return
	end

	local renderNode = rawEntity:getRenderNode()

	local cloneEntity = CloneBaseEntity:create()
	cloneEntity:setModel(rawEntity:getModelId())

	cloneEntity:setPosition(pos)
	cloneEntity:setScaleX(renderNode:getBodyScaleX())
	cloneEntity:setZOrder(zOrder)

	local fighterLayer = self._battleScene:getFighterLayer()
	fighterLayer:addChild(cloneEntity)

	EntityManager:getInstance():addCloneEntity(entityId, cloneEntity)

end

function BattleController:removeCloneEntity(entityId)

	local cloneEntity = EntityManager:getInstance():getCloneEntity(entityId)
	if not cloneEntity then
		return
	end

	EntityManager:getInstance():removeCloneEntity(entityId)
	cloneEntity:dispose()
	cloneEntity:removeFromParentAndCleanup(true)

end

--[[
    移除复制的参战者
]]
function BattleController:removeCopyEntity(entityId)

end

function BattleController:getEntityBuffList(entityId)

	return self._roundManager:getRoundData():getBuff(entityId)
end

function BattleController:getCurrentActionId()
	return self._roundManager:getRoundData():getCurrentActionId()
end

function BattleController:getBattleScene()
	return self._battleScene
end

function BattleController:getRoundManager()
	return self._roundManager
end

function BattleController:getPlotLayer()
	return self._battleScene:getPlotLayer()
end

function BattleController:getHeroAnimLayer()
	return self._battleScene:getHeroAnimLayer()
end