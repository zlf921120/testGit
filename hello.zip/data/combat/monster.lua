Monster = class("Monster", EntityBase:create())

function Monster:create(camp, avatorId)
	local objMonster = Monster.new()	
	objMonster:init(camp, avatorId)
	return objMonster
end

function Monster:init(camp, avatorId)

	self:initBase()

	-- local masterEntity = self
	-- self.stateMachine = StateMachine:create(masterEntity)
	self.hp = 100

	--round manager
	self.roundMgr = nil
	
	--死亡状态
	self.isDead = false
	--敏捷度
	self.attackSpeed = math.random(10, 100)
	
	local monsterBaseInfo = MonsterManager:getInstance():getBaseInfo(avatorId)

	self._modelId = monsterBaseInfo:getModelId()

	self._baseInfo = monsterBaseInfo
	local actionData = EffectManager:getInstance():getActionData(self._modelId)

	self._actionData = actionData
	
	self._avatorId = avatorId

	self._armaturePath = actionData:getFileFullPathName()

	self._armature = AnimateManager:getInstance():getArmature(
		self._armaturePath, 
		actionData:getFileName()
	)
	
	--boss放大1.2倍
	if self._baseInfo.monsterType == Helper.monsterType.BOSS then
		self._armature:setScale(1.2)
	end
	
	--怪物
	--战斗方,分为攻击方和受击方，怪物只可能为受击方
	self:setEntityType(camp)

	self.buffNode = nil
	
	--设置本次攻击额外属性	
	self._curAttackExtraArgs = nil

	self._fighterType = BattleType.MONSTER

end

-- function Monster:uninit()

-- 	self.super:uninit()
-- end

--角色攻击属性值
function Monster:setAttackBaseArgs()
	
	-- self._atkBaseArgs = {}
	
	-- MonsterManager:getInstance():setMonsterAtkAttr(self._avatorId, self._atkBaseArgs)

	-- --设置怪物的最大血值
	-- self:setTotalHp(self._atkBaseArgs.hp)

	-- --设置怪物当前血值
	-- self:setCurrentHp(self._atkBaseArgs.hp)

	-- self.attackSpeed = self._atkBaseArgs.atk_speed

	local attrs = {}
	MonsterManager:getInstance():setMonsterAtkAttr(self._avatorId, attrs)

	self._attrData = BattleEncryptAttrData:create()
	self._attrData:setIsEncrypt(false)
	self._attrData:setClientAttrs(attrs)

	--设置怪物的最大血值
	self:setTotalHp(self._attrData:getAttr(AttrHelper.attr_flag.hp))

	--设置怪物当前血值
	self:setCurrentHp(self._attrData:getAttr(AttrHelper.attr_flag.hp), false, true)

	-- self.attackSpeed = self._atkBaseArgs.atk_speed

end

