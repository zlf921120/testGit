--
-- Author: thisgf
-- Date: 2014-08-11 17:16:02
-- 被动技能管理器

require "HeroManager"
require "SkillManager"
require "BuffManager"
require "combatConfig"

--被动技能阵营区分
local PASSIVE_SKILL_CAMP = {}
--全部
PASSIVE_SKILL_CAMP.ALL = 0
--主动方
PASSIVE_SKILL_CAMP.ATTACK = 1
--被动方
PASSIVE_SKILL_CAMP.STRIKE = 2

--被动技能目标位置
local PASSIVE_SKILL_TARGET_POSITION = {}
PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_0] = {BattlePosType.FRONT_1, BattlePosType.FRONT_2}
PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_1] = {BattlePosType.MIDDLE_1, BattlePosType.MIDDLE_2}
PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_2] = {BattlePosType.BACK_1, BattlePosType.BACK_2}
PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_3] = {BattlePosType.FRONT_1, BattlePosType.FRONT_2, BattlePosType.MIDDLE_1, BattlePosType.MIDDLE_2}
PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_4] = {BattlePosType.MIDDLE_1, BattlePosType.MIDDLE_2, BattlePosType.BACK_1, BattlePosType.BACK_2}
PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_5] = {
	BattlePosType.FRONT_1,
	BattlePosType.FRONT_2,
	BattlePosType.MIDDLE_1,
	BattlePosType.MIDDLE_2,
	BattlePosType.BACK_1,
	BattlePosType.BACK_2
}

PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_6] = PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_0]
PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_7] = PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_1]
PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_8] = PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_2]
PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_9] = PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_3]
PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_10] = PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_4]
PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_11] = PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_5]

PASSIVE_SKILL_TARGET_POSITION[SkillTargetType.targetType_16] = {
	BattlePosType.FRONT_1,
	BattlePosType.MIDDLE_1,
	BattlePosType.BACK_1,
	BattlePosType.FRONT_2,
	BattlePosType.MIDDLE_2,
	BattlePosType.BACK_2
}

--被动技能阵营
local PASSIVE_SKILL_CAMP_LIST = {}
PASSIVE_SKILL_CAMP_LIST[PASSIVE_SKILL_CAMP.ATTACK] = {
	SkillTargetType.targetType_6,
	SkillTargetType.targetType_7,
	SkillTargetType.targetType_8,
	SkillTargetType.targetType_9,
	SkillTargetType.targetType_10,
	SkillTargetType.targetType_11,
	SkillTargetType.targetType_14,
	SkillTargetType.targetType_15,
	SkillTargetType.targetType_17,
	SkillTargetType.targetType_19
}

PASSIVE_SKILL_CAMP_LIST[PASSIVE_SKILL_CAMP.STRIKE] = {
	SkillTargetType.targetType_0,
	SkillTargetType.targetType_1,
	SkillTargetType.targetType_2,
	SkillTargetType.targetType_3,
	SkillTargetType.targetType_4,
	SkillTargetType.targetType_5,
	SkillTargetType.targetType_12,
	SkillTargetType.targetType_13,
	SkillTargetType.targetType_16,
	SkillTargetType.targetType_18
}

--技能作用类型
local SKILL_EFFECT_TYPE = {}
--群体攻击
SKILL_EFFECT_TYPE.ATTACK_GROUP = 1
--单体攻击
SKILL_EFFECT_TYPE.ATTACK_SINGLE = 2
--群体治疗
SKILL_EFFECT_TYPE.TREAT_GROUP = 3
--单体治疗
SKILL_EFFECT_TYPE.TREAT_SINGLE = 4


--溅射的目标范围
local SPURT_TARGET_SCOPE = {}
SPURT_TARGET_SCOPE[BattlePosType.FRONT_1] = {BattlePosType.FRONT_2, BattlePosType.MIDDLE_1, BattlePosType.MIDDLE_2}
SPURT_TARGET_SCOPE[BattlePosType.FRONT_2] = {BattlePosType.FRONT_1, BattlePosType.MIDDLE_1, BattlePosType.MIDDLE_2}
SPURT_TARGET_SCOPE[BattlePosType.MIDDLE_1] = {BattlePosType.FRONT_1, BattlePosType.MIDDLE_2, BattlePosType.BACK_1}
SPURT_TARGET_SCOPE[BattlePosType.MIDDLE_2] = {BattlePosType.FRONT_2, BattlePosType.MIDDLE_1, BattlePosType.BACK_2}
SPURT_TARGET_SCOPE[BattlePosType.BACK_1] = {BattlePosType.MIDDLE_1, BattlePosType.MIDDLE_2, BattlePosType.BACK_2}
SPURT_TARGET_SCOPE[BattlePosType.BACK_2] = {BattlePosType.MIDDLE_1, BattlePosType.MIDDLE_2, BattlePosType.BACK_1}



local PERCENT_BASE = 10000



PassiveSkillManager = class("PassiveSkillManager")


local _instance

function PassiveSkillManager:ctor()


end

function PassiveSkillManager:getInstance()

	if not _instance then
		_instance = PassiveSkillManager.new()
	end

	return _instance
end


--损失生命每加/减一个万分比,获得数值万分比
--@return isTrigger, attrType, addPercent
function PassiveSkillManager:_script20000(entity, scriptArgs)

	local isTrigger = false

	local lostPercent = scriptArgs[1]
	local attrType = scriptArgs[2]
	local attrPercent = scriptArgs[3]

	local currentHp = entity:getCurrentHp()
	local totalHp = entity:getTotalHp()

	local currentPercent = (totalHp - currentHp) / totalHp


	local addAttr = math.floor((currentPercent*100)/((lostPercent/PERCENT_BASE)*100)) * attrPercent/PERCENT_BASE

	if addAttr > 0 then
		isTrigger = true
	end

	return {isTrigger, AttrHelper:getAttrStrFlag(attrType), addAttr}

end

--生命减少到一个万分比,获得数值万分比
--@return isTrigger, attrType, addPercent
function PassiveSkillManager:_script20001(entity, scriptArgs)

	local isTrigger = false

	local criticalPercent = scriptArgs[1]
	local attrType = scriptArgs[2]
	local attrPercent = scriptArgs[3]

	local currentHp = entity:getCurrentHp()
	local totalHp = entity:getTotalHp()

	local currentPercent = currentHp / totalHp

	local addAttr = 0
	if currentPercent <= criticalPercent/PERCENT_BASE then

		addAttr = attrPercent/PERCENT_BASE

		isTrigger = true
	end

	return {isTrigger, AttrHelper:getAttrStrFlag(attrType), addAttr}

end

--受到近程攻击,一定几率反弹万分比伤害
--@return isTrigger, or reboundPercent
function PassiveSkillManager:_script20002(scriptArgs)

	local isTrigger = false

	local triggerPercent = scriptArgs[1]
	local percent = math.random(1, PERCENT_BASE)

	if percent <= triggerPercent then
		isTrigger = true
	end

	local damagePercent = nil

	if isTrigger then
		damagePercent = scriptArgs[2] / PERCENT_BASE
	end

	return {isTrigger, damagePercent}

end

--主动攻击时,对目标类型增加额外万分比伤害
--@return {isTrigger, targetList, damagePercent}
function PassiveSkillManager:_script20003(scriptArgs, attacker, targetList)

	local targetType = scriptArgs[1]
	local numTarget = scriptArgs[2]
	local damagePercent = scriptArgs[3] / PERCENT_BASE

	local hitTargetDict = {}

	local camp = getSkillTargetCamp(targetType)
	if camp ~= BattleType.SKILL_ENEMY then
		return {false}
	end

	local params = {}
	params.targetType = targetType
	params.numTarget = numTarget
	params.targetList = targetList
	params.attackerId = attacker:getEntityID()
	hitTargetDict = self:validTarget(params)

	return {true, hitTargetDict, damagePercent}


end

--受到近程攻击,一定几率反击一下
function PassiveSkillManager:_script20004(scriptArgs)

	local isTrigger = false

	local fbPercent = scriptArgs[1]

	if math.random(1, PERCENT_BASE) <= fbPercent then
		isTrigger = true
	end

	return {isTrigger}

end

--主动群攻时，随机对一个被攻击对象增加额外万分比伤害
function PassiveSkillManager:_script20005(scriptArgs, targetList)

	local damagePercent = scriptArgs[1] / PERCENT_BASE

	local entity = targetList[math.random(1, #targetList)]

	return {true, {[entity:getEntityID()] = entity}, damagePercent}

end

--主动治疗时，额外恢复目标生命上限万分比的治疗量
--@return {true, hitTargetDict, treatPercent}
function PassiveSkillManager:_script20006(scriptArgs, targetList)

	local treatPercent = scriptArgs[1] / PERCENT_BASE

	local hitTargetDict = {}

	for i, entity in ipairs(targetList) do
		hitTargetDict[entity:getEntityID()] = entity
	end

	return {true, hitTargetDict, treatPercent}

end

--受到治疗时，额外恢复治疗量万分比
function PassiveSkillManager:_script20007(scriptArgs)

	local treatPercent = scriptArgs[1] / PERCENT_BASE

	return {true, treatPercent}

end

--主动治疗时，对生命减少到一个万分比值的对象，额外增加治疗量
function PassiveSkillManager:_script20008(scriptArgs, targetList)

	local isTrigger = false

	local criticalPercent = scriptArgs[1] / PERCENT_BASE
	local hitTargetDict = {}

	local isHit = false

	for i, entity in ipairs(targetList) do

		if entity:getCurrentHp() / entity:getTotalHp() <= criticalPercent then
			hitTargetDict[entity:getEntityID()] = entity

			isHit = true
		end
	end

	if isHit == false then
		return {isTrigger}
	end

	isTrigger = true

	local treatPercent = scriptArgs[2] / PERCENT_BASE

	return {isTrigger, hitTargetDict, treatPercent}

end

--主动攻击时，有万分比概率对附近随机一个目标造成额外伤害
--@return {isTrigger, spurtTargetDict, hurtPercent}
function PassiveSkillManager:_script20009(scriptArgs, atker, targetList)

	local isTrigger = false

	local spurtTargetDict = {}

	local triggerPercent = scriptArgs[1]
	local hurtPercent = scriptArgs[2] / PERCENT_BASE
	local spurtTimes = scriptArgs[3]

	repeat

		if BattleUtil:checkPercent(triggerPercent) == false then
			break
		end

		if #targetList > 1 then
			break
		end

		local target = targetList[1]

		local targetPos = target:getBattleFieldPosition()

		local targetTeam

		if atker:getEntityType() == BattleType.ATTACKER then
			targetTeam = EntityManager:getInstance():getEnemyAliveEntityDict()
		else
			targetTeam = EntityManager:getInstance():getAllyAliveEntityDict()
		end

		local scopeList = SPURT_TARGET_SCOPE[targetPos]
		local spurtList = {}

		for entityId, entity in pairs(targetTeam) do
			if entityId ~= target:getEntityID() then
				for _, pos in ipairs(scopeList) do
					if entity:getBattleFieldPosition() == pos then
						table.insert(spurtList, entity)
						break
					end
				end
			end
		end

		if #spurtList == 0 then
			break
		end

		local i = 1
		while i <= spurtTimes do

			if #spurtList == 0 then
				break
			end

			local suprtIndex = math.random(1, #spurtList)

			local spurtEntity = table.remove(spurtList, suprtIndex)

			i = i + 1

			spurtTargetDict[spurtEntity:getEntityID()] = spurtEntity

		end

		isTrigger = true
		
	until true

	return {isTrigger, spurtTargetDict, hurtPercent}

end

--死亡后下一回合会原地复活, 恢复x血量, 每场战斗只能触发1次
function PassiveSkillManager:_script20010(scriptArgs, atkerId)

	local entityManager = EntityManager:getInstance()

	local reviveTimes = entityManager:getPassTriggerTimes(atkerId, PassiveSkillScriptType.SCRIPT_TYPE_20010)
	-- print("//////////////////////特麼你復活了", atkerId, reviveTimes)

	if reviveTimes and reviveTimes >= SkillScriptType.MAX_REVIVE then
		return {false}
	end

	entityManager:addPassTriggerTimes(atkerId, PassiveSkillScriptType.SCRIPT_TYPE_20010)

	return {true, scriptArgs[2]}

end

--主动攻击后，概率产生buff
--@return {isTrigger, buffDict}
function PassiveSkillManager:_script20011(scriptArgs, atker, targetList)

	local isTrigger = false

	local generatePercent = scriptArgs[1]

	if BattleUtil:checkPercent(generatePercent) == false then
		return {isTrigger}
	end

	local scriptId = scriptArgs[2]
	local buffArgs = {{scriptArgs[3], scriptArgs[4]}}

	local buffDict = BuffManager:getInstance():generateBuffWithPassiveSkill(
		scriptId, 
		buffArgs, 
		atker, 
		targetList
	)

	if buffDict then
		isTrigger = true
	end

	return {isTrigger, buffDict}

end

--主动攻击时，目标生命减少到一个万分比,攻击者获得数值绝对值，且损失生命每加/减一个万分比,攻击者获得数值绝对值
--@return {isTrigger, {attrType, attrValue}, ...}
function PassiveSkillManager:_script20012(scriptArgs, target)

	local isTrigger = false

	local currentHp = target:getCurrentHp()
	local totalHp = target:getTotalHp()

	local hpPercent = currentHp * PERCENT_BASE / totalHp

	local criticalPercent = scriptArgs[1]
	local attrType = scriptArgs[2]
	local attrValue = scriptArgs[3]

	
	local everyPercent = scriptArgs[4]
	local everyAttrType = scriptArgs[5]
	local everyAttrValue = scriptArgs[6]

	local result = {}
	result[1] = false

	if hpPercent <= criticalPercent then
		isTrigger = true

		result[2] = {}
		
		table.insert(result[2], AttrHelper:getAttrStrFlag(attrType))
		table.insert(result[2], attrValue)

		local everyMulti = math.floor((criticalPercent - hpPercent) / everyPercent)

		if everyMulti > 0 then
			result[3] = {}
			table.insert(result[3], AttrHelper:getAttrStrFlag(everyAttrType))
			table.insert(result[3], everyMulti * everyAttrValue)
		end
	end

	result[1] = isTrigger

	return result

end

--主动攻击时，对某一种族敌人增加额外伤害万分比
--{isTrigger, hitTargetDict, damagePercent}
function PassiveSkillManager:_script20013(scriptArgs, targetList)
	
	local isTrigger = false

	local hitTargetDict = {}

	local races = scriptArgs[1]
	local entityRace = 0


	local isHit = false

	for i, entity in ipairs(targetList) do

		entityRace = entity:getBaseInfo().race

		for _, race in ipairs(races) do
			if entityRace == race then
				hitTargetDict[entity:getEntityID()] = entity

				isHit = true
				break
			end
		end

	end

	if isHit == false then
		return {isTrigger}
	end

	isTrigger = true

	local damage
	if scriptArgs[2] == BattleType.numberType.PERCENT then
		damage = scriptArgs[3]/PERCENT_BASE
	else
		damage = scriptArgs[3]
	end

	return {isTrigger, hitTargetDict, scriptArgs[2], damage}

end

--只要该单位存活于战场,每回合结束时,目标群体会自动加减生命绝对值
function PassiveSkillManager:_script20014(scriptArgs, attacker, attackerTeam, strikerTeam)

	local targetType = scriptArgs[1]
	local numTarget = scriptArgs[2]
	local hp = scriptArgs[3]

	local targetList = nil

	local atkEntityType = attacker:getEntityType()

	local camp = getSkillTargetCamp(targetType)
	if camp == BattleType.SKILL_ALLY then
		if atkEntityType == BattleType.ATTACKER then
			targetList = attackerTeam
		else
			targetList = strikerTeam
		end
	else
		if atkEntityType == BattleType.ATTACKER then
			targetList = strikerTeam
		else
			targetList = attackerTeam
		end
	end

	local hitTargetDict

	if targetList then
		local params = {}
		params.targetType = targetType
		params.numTarget = numTarget
		params.targetList = targetList
		params.attackerId = attacker:getEntityID()
		hitTargetDict = self:validTarget(params)
	end

	hitTargetDict = hitTargetDict or {}

	return {hitTargetDict, hp}

end

--有x%的几率不受沉默效果影响，依旧可以施法
function PassiveSkillManager:_script20015(scriptArgs)
	return {BattleUtil:checkPercent(scriptArgs[1])}
end

--该角色触发格挡时,有X%几率完全免疫伤害和一切负面,控制效果
function PassiveSkillManager:_script20016(scriptArgs)
	return {BattleUtil:checkPercent(scriptArgs[1])}
end

--增加毒伤害x点
function PassiveSkillManager:_script20017(scriptArgs)
	return {true, scriptArgs[1]}
end

--每次攻击如果不被闪避/格挡,都有X%几率追加额外连击
function PassiveSkillManager:_script20018(scriptArgs)
	return BattleUtil:checkPercent(scriptArgs[1])
end

--受到群攻时,有一定几率保护自己,免疫x%伤害,免疫几率随技能等级提升
function PassiveSkillManager:_script20019(scriptArgs)

	local isTrigger = BattleUtil:checkPercent(scriptArgs[1])

	return {isTrigger, scriptArgs[2] / PERCENT_BASE}
end

--当血量低于某个数值时,获得buff(可多个)
function PassiveSkillManager:_script20020(scriptArgs, entityId)

	local entity = EntityManager:getInstance():getEntityWithID(entityId)

	local triggerTimes = EntityManager:getInstance():getPassTriggerTimes(entityId, PassiveSkillScriptType.SCRIPT_TYPE_20020)
	--最大次数
	if triggerTimes and triggerTimes >= 1 then
		return {false}
	end

	local currentHp = entity:getCurrentHp()
	local totalHp = entity:getTotalHp()

	local hpPercent = currentHp * PERCENT_BASE / totalHp

	if hpPercent > scriptArgs[1] then
		return {false}
	end

	local buffArgs = {}

	for i = 2, #scriptArgs do
		buffArgs[i - 1] = {scriptArgs[i][1], scriptArgs[i][2]}
	end

	local buffDict = BuffManager:getInstance():generateBuffWithPassiveSkill(
		PassiveSkillScriptType.SCRIPT_TYPE_20020, 
		buffArgs, 
		entity, 
		{entity}
	)

	if buffDict then
		isTrigger = true
	end

	EntityManager:getInstance():addPassTriggerTimes(entityId, PassiveSkillScriptType.SCRIPT_TYPE_20020)

	return {isTrigger, buffDict}

end

--只要该单位存活于战场,目标类型的英雄都会在战斗中 +/- 某种数值绝对值
--@return {targetDict, valueType, value}
function PassiveSkillManager:_script20021(scriptArgs, entityType)

	local targetType = scriptArgs[1]
	local valueType = scriptArgs[2]
	local value = scriptArgs[3]

	return {targetType, AttrHelper:getAttrStrFlag(valueType), value}

end

--当自身进入被控制状态后，有20%的几率立刻解除控制
function PassiveSkillManager:_script20022(scriptArgs)

	return BattleUtil:checkPercent(scriptArgs[1])
end

--自身死亡时,对杀死自己的敌方单位施加强大的灼烧法术,每回合受到200点伤害,持续5回合
function PassiveSkillManager:_script20023(entityId, attackerId, scriptArgs)

	local  isTrigger = false

	local entity = EntityManager:getInstance():getEntityWithID(entityId)
	local attacker = EntityManager:getInstance():getEntityWithID(attackerId)

	local buffDict = BuffManager:getInstance():generateBuffWithPassiveSkill(
		PassiveSkillScriptType.SCRIPT_TYPE_20023, 
		{scriptArgs}, 
		entity, 
		{attacker}
	)

	if buffDict then
		isTrigger = true
	end

	return {isTrigger, buffDict}

end

--被敌方攻击时,一定概率最多只产生X点的伤害(无论是否暴击,破甲等)
function PassiveSkillManager:_script20024(scriptArgs)
	return {BattleUtil:checkPercent(scriptArgs[1]), scriptArgs[2]}
end

--在每场战斗不同回合的时候, 场中目标增加一个BUFF
function PassiveSkillManager:_script20025(numWave, numRound, scriptArgs, attacker, attackerTeam, strikerTeam)

	local waves = scriptArgs[1]
	local wave
	local round
	local condList
	local hit = false
	for i, v in ipairs(waves) do
		wave = v [1]
		round = v [2]
		if wave == numWave and round == numRound then
			hit = true
			break
		end
	end

	if not hit then
		return {false}
	end

	local atkEntityType = attacker:getEntityType()

	local targetType = scriptArgs[2]
	local numTarget = scriptArgs[3]

	local targetList = nil

	local camp = getSkillTargetCamp(targetType)
	if camp == BattleType.SKILL_ALLY then
		if atkEntityType == BattleType.ATTACKER then
			targetList = attackerTeam
		else
			targetList = strikerTeam
		end
	else
		if atkEntityType == BattleType.ATTACKER then
			targetList = strikerTeam
		else
			targetList = attackerTeam
		end
	end

	local hitTargetDict

	if targetList then
		local params = {}
		params.targetType = targetType
		params.numTarget = numTarget
		params.targetList = targetList
		params.attackerId = attacker:getEntityID()
		hitTargetDict = self:validTarget(params)
	end

	if not hitTargetDict then
		return {false}
	end

	targetList = {}
	for _, v in pairs(hitTargetDict) do
		table.insert(targetList, v)
	end

	local buffArgs = {{scriptArgs[4], scriptArgs[5]}}

	local buffDict = BuffManager:getInstance():generateBuffWithPassiveSkill(
		PassiveSkillScriptType.SCRIPT_TYPE_20025, 
		buffArgs, 
		attacker, 
		targetList
	)

	if not buffDict then
		return {false}
	end

	return {true, buffDict}

end

--在敌方触发了反震效果之后,有X的概率抵抗反震(不触发反震)
function PassiveSkillManager:_script20026(scriptArgs)
	return BattleUtil:checkPercent(scriptArgs[1])
end

--该单位存活于战场,每回合结束时,目标群体会有概率+/-目标单位自身最大血量的万分比数值
function PassiveSkillManager:_script20027(scriptArgs, attacker, attackerTeam, strikerTeam)

	local triggerPercent = scriptArgs[1]
	local hit = BattleUtil:checkPercent(triggerPercent)
	if not hit then
		return nil
	end

	local targetType = scriptArgs[2]
	local numTarget = scriptArgs[3]
	local hpPercent = scriptArgs[4]/10000

	local targetList = nil

	local atkEntityType = attacker:getEntityType()

	local camp = getSkillTargetCamp(targetType)
	if camp == BattleType.SKILL_ALLY then
		if atkEntityType == BattleType.ATTACKER then
			targetList = attackerTeam
		else
			targetList = strikerTeam
		end
	else
		if atkEntityType == BattleType.ATTACKER then
			targetList = strikerTeam
		else
			targetList = attackerTeam
		end
	end

	local hitTargetDict

	if targetList then
		local params = {}
		params.targetType = targetType
		params.numTarget = numTarget
		params.targetList = targetList
		params.attackerId = attacker:getEntityID()
		hitTargetDict = self:validTarget(params)
	end

	hitTargetDict = hitTargetDict or {}

	return {hitTargetDict, hpPercent}
end

--校验目标类型
--@return 合格的目标字典
function PassiveSkillManager:validTarget(params)

	local targetType = params.targetType
	local numTarget = params.numTarget
	local targetList = params.targetList
	local attackerId = params.attackerId


	local hitTargetDict = {}

	local hitNum = 0

	local posList = PASSIVE_SKILL_TARGET_POSITION[targetType]
	if posList then

		hitNum = 0

		--一列
		if targetType == SkillTargetType.targetType_16 then

			local beginPos = 0
			if math.random(1, 10) <= 5 then
				beginPos = 1
			else
				beginPos = 4
			end

			-- beginPos = 4

			local tempPosList = {}
			for i = beginPos, beginPos + 2 do
				table.insert(tempPosList, posList[i])
			end

			posList = tempPosList
			
		end

		--对应位置
		for k, entity in pairs(targetList) do

			for i, pos in ipairs(posList) do
				if entity:getBattleFieldPosition() == pos then

					hitTargetDict[entity:getEntityID()] = entity

					hitNum = hitNum + 1

					break
				end
			end

			if hitNum >= numTarget then
				break
			end
		end
	else

		hitNum = 0

		--敌/我方血最少
		if targetType == SkillTargetType.targetType_12 or 
			targetType == SkillTargetType.targetType_14 then

			local cloneTargetList = clone(targetList)

			local hp = math.huge
			local tempEntity
			local tempKey

			for k, entity in pairs(targetList) do

				tempKey = nil
				for k1, entity1 in pairs(cloneTargetList) do

					if entity1:getCurrentHp() < hp then
						hp = entity:getCurrentHp()

						tempKey = k1
					end
				end

				if tempKey then

					hitTargetDict[cloneTargetList[tempKey]:getEntityID()] = cloneTargetList[tempKey]
					cloneTargetList[tempKey] = nil

					hitNum = hitNum + 1
				end

				if hitNum >= numTarget then
					break
				end
			end

		--敌/我方血最多
		elseif targetType == SkillTargetType.targetType_13 or 
				targetType == SkillTargetType.targetType_15 then

			hitNum = 0

			local cloneTargetList = clone(targetList)

			local hp = -math.huge
			local tempEntity
			local tempKey

			for k, entity in pairs(targetList) do

				tempKey = nil

				for k1, entity1 in pairs(cloneTargetList) do

					if entity1:getCurrentHp() > hp then
						hp = entity:getCurrentHp()

						tempKey = k1
					end
				end

				if tempKey then
					hitTargetDict[cloneTargetList[tempKey]:getEntityID()] = cloneTargetList[tempKey]
					cloneTargetList[tempKey] = nil

					hitNum = hitNum + 1
				end

				if hitNum >= numTarget then
					break
				end
			end

		--敌/我方完全随机
		elseif targetType == SkillTargetType.targetType_18 or 
				targetType == SkillTargetType.targetType_19 then

			hitNum = 0

			local entityKeyList = {}
			for k, entity in pairs(targetList) do

				entityKeyList[#entityKeyList + 1] = k
			end

			local entity
			local tempIndex = 0

			for i = 1, numTarget do

				if #entityKeyList == 0 then
					break
				end

				tempIndex = math.random(1, #entityKeyList)

				entity = targetList[entityKeyList[tempIndex]]
				table.remove(entityKeyList, tempIndex)

				hitTargetDict[entity:getEntityID()] = entity

			end

		--自己
		elseif targetType == SkillTargetType.targetType_17 then

			for k, entity in pairs(targetList) do
				if entity:getEntityID() == attackerId then
					hitTargetDict[entity:getEntityID()] = entity
					break
				end
			end
		end

	end

	return hitTargetDict

end

function PassiveSkillManager:_getEntityOpenPassiveSkill(entity, scriptId)

	local atkPasSkillList
	
	if entity:isRole() then
		atkPasSkillList = entity:getBaseInfo().pas_skills
	else
		atkPasSkillList = entity:getBaseInfo():getPasSkillDataList()
	end

	local passiveSkillList = {}

	if not atkPasSkillList then
		return passiveSkillList
	end

	for i, v in ipairs(atkPasSkillList) do

		if v.is_open then
			if v:getSkillId() > 0 then
				skillData = SkillManager:getInstance():getPassiveSkillData(
					v:getSkillId(), 
					v:getSkillLevel()
				)

				if skillData.scriptId ~= 0 then
					table.insert(passiveSkillList, skillData)
				end
			end
		end
	end

	if scriptId then
		for _, v in ipairs(passiveSkillList) do
			if v.scriptId == scriptId then
				return v
			end
		end
	else
		return passiveSkillList
	end

end

--[[
    生成被动技能
    @param skillData 技能数据
    @param atker 攻击者
    @param targetList 目标列表
    @return {entityId:{{skillId, scriptId, params}, ...} ...}
]]
function PassiveSkillManager:generatePassiveSkill(skillData, atker, targetList)

	local scriptId = skillData._atkScriptId
	local targetNum = skillData._targetNum
	local nearFarType = skillData._nearFarType

	local skillEffectType = self:_getSkillEffectType(scriptId, targetNum)

	local triggerPassiveSkillList = {}

	local heroInfo

	local function insertTriggerPassiveSkill(psArgs, entityId, skillId, scriptId)

		if not psArgs then
			return
		end

		isTrigger = table.remove(psArgs, 1)

		if isTrigger == true then

			table.insert(psArgs, 1, skillId)
			table.insert(psArgs, 2, scriptId)

			if not triggerPassiveSkillList[entityId] then
				triggerPassiveSkillList[entityId] = {}
			end

			table.insert(triggerPassiveSkillList[entityId], psArgs)
		end
	end

	local skillData
	local scriptId
	local scriptArgs
	local atkPasSkillList = self:_getEntityOpenPassiveSkill(atker)

	local isTrigger
	local entityId = atker:getEntityID()

	local psArgs = nil

	--攻击者的被动技能
	for i, skillData in ipairs(atkPasSkillList) do

		scriptId = skillData.scriptId
		scriptArgs = skillData.scriptArgs

		psArgs = nil

		if scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20000 then
			psArgs = self:_script20000(atker, scriptArgs)
		elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20001 then
			psArgs = self:_script20001(atker, scriptArgs)
		elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20003 then

			if skillEffectType == SKILL_EFFECT_TYPE.ATTACK_GROUP or 
				skillEffectType == SKILL_EFFECT_TYPE.ATTACK_SINGLE then
				psArgs = self:_script20003(scriptArgs, atker, targetList)
			end

		elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20005 then

			if skillEffectType == SKILL_EFFECT_TYPE.ATTACK_GROUP then
				psArgs = self:_script20005(scriptArgs, targetList)
			end

		elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20006 then

			if skillEffectType == SKILL_EFFECT_TYPE.TREAT_GROUP or 
				skillEffectType == SKILL_EFFECT_TYPE.TREAT_SINGLE then
				psArgs = self:_script20006(scriptArgs, targetList)
			end

		elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20008 then

			if skillEffectType == SKILL_EFFECT_TYPE.TREAT_GROUP or 
				skillEffectType == SKILL_EFFECT_TYPE.TREAT_SINGLE then
				psArgs = self:_script20008(scriptArgs, targetList)
			end

		elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20009 then

			if skillEffectType == SKILL_EFFECT_TYPE.ATTACK_GROUP or 
				skillEffectType == SKILL_EFFECT_TYPE.ATTACK_SINGLE then
				psArgs = self:_script20009(scriptArgs, atker, targetList)
			end

		elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20011 then

			if skillEffectType == SKILL_EFFECT_TYPE.ATTACK_GROUP or 
				skillEffectType == SKILL_EFFECT_TYPE.ATTACK_SINGLE then
				psArgs = self:_script20011(scriptArgs, atker, targetList)
			end

		elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20012 then

			if skillEffectType == SKILL_EFFECT_TYPE.ATTACK_SINGLE then

				psArgs = self:_script20012(scriptArgs, targetList[1])
			end

		elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20013 then

			if skillEffectType == SKILL_EFFECT_TYPE.ATTACK_SINGLE or 
				skillEffectType == SKILL_EFFECT_TYPE.ATTACK_GROUP then

				psArgs = self:_script20013(scriptArgs, targetList)
			end
		end

		insertTriggerPassiveSkill(psArgs, entityId, skillData.id, scriptId)

	end

	--目标的被动技能
	for k, entity in ipairs(targetList) do

		entityId = entity:getEntityID()

		atkPasSkillList = self:_getEntityOpenPassiveSkill(entity)

		for i, skillData in ipairs(atkPasSkillList) do

			scriptId = skillData.scriptId
			scriptArgs = skillData.scriptArgs

			psArgs = nil

			if scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20000 then
				psArgs = self:_script20000(entity, scriptArgs)
			elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20001 then
				psArgs = self:_script20001(entity, scriptArgs)
			elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20002 then
				
				if nearFarType == SkillDataCfg.NEAR_SKILL and 
					(skillEffectType == SKILL_EFFECT_TYPE.ATTACK_GROUP or 
					 skillEffectType == SKILL_EFFECT_TYPE.ATTACK_SINGLE) then
					psArgs = self:_script20002(scriptArgs)
					if psArgs[1] then
						--抗反震
						local passiveSkill = self:_getEntityOpenPassiveSkill(
							atker, 
							PassiveSkillScriptType.SCRIPT_TYPE_20026
						)

						if passiveSkill then
							local antiShock = self:_script20026(
								passiveSkill.scriptArgs
							)
							if antiShock then
								psArgs[1] = false
							end
						end
					end
				end
			elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20004 then

				if nearFarType == SkillDataCfg.NEAR_SKILL and 
					(skillEffectType == SKILL_EFFECT_TYPE.ATTACK_GROUP or 
					 skillEffectType == SKILL_EFFECT_TYPE.ATTACK_SINGLE) then
					psArgs = self:_script20004(scriptArgs)
				end

			elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20007 then

				if skillEffectType == SKILL_EFFECT_TYPE.TREAT_GROUP or 
					skillEffectType == SKILL_EFFECT_TYPE.TREAT_SINGLE then
					psArgs = self:_script20007(scriptArgs)
				end
			elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20016 then

				if skillEffectType == SKILL_EFFECT_TYPE.ATTACK_GROUP or 
					skillEffectType == SKILL_EFFECT_TYPE.ATTACK_SINGLE then
					psArgs = self:_script20016(scriptArgs)
				end

			elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20017 then

				psArgs = self:_script20017(scriptArgs)

			elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20019 then

				if skillEffectType == SKILL_EFFECT_TYPE.ATTACK_GROUP then
					psArgs = self:_script20019(scriptArgs)
				end
			elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20024 then
				
				if skillEffectType == SKILL_EFFECT_TYPE.ATTACK_SINGLE or 
					skillEffectType == SKILL_EFFECT_TYPE.ATTACK_GROUP then

					psArgs = self:_script20024(scriptArgs)
				end
			end

			insertTriggerPassiveSkill(psArgs, entityId, skillData.id, scriptId)

	    end
	end

	return triggerPassiveSkillList

end

function PassiveSkillManager:_getSkillEffectType(scriptId, targetNum)

	local skillEffectType = nil

	if scriptId == SkillScriptType.NONE or
	   scriptId == SkillScriptType.ATTACK_EXTRA_DAMAGE or
	   scriptId == SkillScriptType.BATTER or
	   scriptId == SkillScriptType.DARTLE or 
	   scriptId == SkillScriptType.BUFF_FOR_TARGET or
	   scriptId == SkillScriptType.ATTACK_PHANTOM then

	   if targetNum > 1 then
	       skillEffectType = SKILL_EFFECT_TYPE.ATTACK_GROUP
	   else
	       skillEffectType = SKILL_EFFECT_TYPE.ATTACK_SINGLE
	   end

	elseif scriptId == SkillScriptType.TREAT or 
	       scriptId == SkillScriptType.DISPERSE_AND_TREAT or 
	       scriptId == SkillScriptType.TREAT_AND_BUFF then

		if targetNum > 1 then
	       skillEffectType = SKILL_EFFECT_TYPE.TREAT_GROUP
	   	else
	       skillEffectType = SKILL_EFFECT_TYPE.TREAT_SINGLE
	   	end
	end

	return skillEffectType

end

--[[
    @return nil or reviveHp
]]
function PassiveSkillManager:generate20010(entity)

	local passiveSkill = self:_getEntityOpenPassiveSkill(
		entity, 
		PassiveSkillScriptType.SCRIPT_TYPE_20010
	)

	local reviveArgs

	if passiveSkill then

		reviveArgs = self:_script20010(passiveSkill.scriptArgs, entity:getEntityID())
	end

	if not reviveArgs or reviveArgs[1] == false then
		return nil
	end

	return reviveArgs[2]

end

--[[
    回合结束前处理
	@param attackerTeam 攻击者列表
	@param strikerTeam 受击者列表
	@return {{targetDict, hp}, ...}
]]
function PassiveSkillManager:generate20014(attackerTeam, strikerTeam)

	local function handlePassiveSkill(entity, ps)

		for i, skillData in ipairs(ps) do

			scriptId = skillData.scriptId
			scriptArgs = skillData.scriptArgs

			if scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20014 then

				return self:_script20014(
					scriptArgs, 
					entity, 
					attackerTeam, 
					strikerTeam
				)
			end

		end
	end

	local passiveSkill = {}
	local hitTargetDictList = {}
	local hitTargetDict

	for k, entity in pairs(attackerTeam) do

		passiveSkill = self:_getEntityOpenPassiveSkill(entity)

		hitTargetDict = handlePassiveSkill(entity, passiveSkill)

		if hitTargetDict then
			--先放入加血的
			if hitTargetDict[2] > 0 then
				table.insert(hitTargetDictList, 1, hitTargetDict)
			else
				table.insert(hitTargetDictList, hitTargetDict)
			end
		end

	end

	return hitTargetDictList

end

function PassiveSkillManager:generate20015(entity)

	local passiveSkill = self:_getEntityOpenPassiveSkill(
		entity, 
		PassiveSkillScriptType.SCRIPT_TYPE_20015
	)

	local isTrigger = false

	if passiveSkill then
		isTrigger = self:_script20015(passiveSkill.scriptArgs)
	end

	return isTrigger

end

function PassiveSkillManager:generate20018(acSkillData, entity)

	local isTrigger = false

	local skillEffectType = self:_getSkillEffectType(
		acSkillData._atkScriptId, 
		acSkillData._targetNum
	)
	if skillEffectType == SKILL_EFFECT_TYPE.ATTACK_SINGLE then
		local passiveSkill = self:_getEntityOpenPassiveSkill(
			entity, 
			PassiveSkillScriptType.SCRIPT_TYPE_20018
		)

		if passiveSkill then

			isTrigger = self:_script20018(passiveSkill.scriptArgs)
		end

	end

	return isTrigger

end

--[[
    20020被动技能
    @return nil or 产生的buff
]]
function PassiveSkillManager:generate20020(entity)

	local passiveSkill = self:_getEntityOpenPassiveSkill(
		entity, 
		PassiveSkillScriptType.SCRIPT_TYPE_20020
	)

	local passArgs

	if passiveSkill then

		passArgs = self:_script20020(passiveSkill.scriptArgs, entity:getEntityID())
	end

	if not passArgs or passArgs[1] == false then
		return nil
	end

	return passArgs[2]

end

--[[
    计算20021的被动技能
]]
function PassiveSkillManager:generate20021(entity)

	local passiveSkill = self:_getEntityOpenPassiveSkill(
		entity, 
		PassiveSkillScriptType.SCRIPT_TYPE_20021
	)

	if passiveSkill then
		return self:_script20021(passiveSkill.scriptArgs, entity:getEntityType())
	end

	return nil

end

function PassiveSkillManager:generate20022(entity)

	local passiveSkill = self:_getEntityOpenPassiveSkill(
		entity, 
		PassiveSkillScriptType.SCRIPT_TYPE_20022
	)

	if passiveSkill then
		return self:_script20022(passiveSkill.scriptArgs)
	end

	return false

end

function PassiveSkillManager:generate20023(entity, attackerId)

	local passiveSkill = self:_getEntityOpenPassiveSkill(
		entity, 
		PassiveSkillScriptType.SCRIPT_TYPE_20023
	)

	local buffDict

	if passiveSkill then
		buffDict = self:_script20023(
			entity:getEntityID(), 
			attackerId, 
			passiveSkill.scriptArgs
		)
	end

	if not buffDict or not buffDict[1] then
		return nil
	end

	return buffDict[2]

end

--[[
    回合开始处理
    return buffDict
]]
function PassiveSkillManager:generate20025(entity, numWave, numRound, attackerTeam, strikerTeam)

	local passiveSkill = self:_getEntityOpenPassiveSkill(
		entity, 
		PassiveSkillScriptType.SCRIPT_TYPE_20025
	)

	local buffDict

	if passiveSkill then
		buffDict = self:_script20025(
			numWave, 
			numRound, 
			passiveSkill.scriptArgs, 
			entity, 
			attackerTeam, 
			strikerTeam
		)
	end

	if not buffDict or not buffDict[1] then
		return nil
	end

	return buffDict[2]

end

--[[
    回合结束前处理
	@param attackerTeam 攻击者列表
	@param strikerTeam 受击者列表
	@return {{targetDict, hpPercent}, ...}
]]
function PassiveSkillManager:generate20027(attackerTeam, strikerTeam)

	local function handlePassiveSkill(entity, ps)

		for i, skillData in ipairs(ps) do

			scriptId = skillData.scriptId
			scriptArgs = skillData.scriptArgs

			if scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20027 then

				return self:_script20027(
					scriptArgs, 
					entity, 
					attackerTeam, 
					strikerTeam
				)
			end

		end
	end

	local passiveSkill = {}
	local hitTargetDictList = {}
	local hitTargetDict

	for k, entity in pairs(attackerTeam) do

		passiveSkill = self:_getEntityOpenPassiveSkill(entity)

		hitTargetDict = handlePassiveSkill(entity, passiveSkill)

		if hitTargetDict then
			--先放入加血的
			if hitTargetDict[2] > 0 then
				table.insert(hitTargetDictList, 1, hitTargetDict)
			else
				table.insert(hitTargetDictList, hitTargetDict)
			end
		end
	end

	return hitTargetDictList
end
