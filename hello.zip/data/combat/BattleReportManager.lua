--
-- Author: thisgf
-- Date: 2014-12-09 21:24:58
-- 战报管理器

local function _getNumberKey(id)
    return string.format("[%d]", id)
end

BattleReportManager = class("BattleReportManager")

--录像版本
BattleReportManager.VERSION = "1.0"

BattleReportManager._battleType = 0
BattleReportManager._pvType = 0

BattleReportManager._reportStr = nil

BattleReportManager._reportData = nil
BattleReportManager._isUpdate = false

BattleReportManager._waveAction = nil
BattleReportManager._roundAction = nil
BattleReportManager._attackerAction = nil


local _instance

function BattleReportManager:ctor()
end

function BattleReportManager:getInstance()

    if not _instance then
        _instance = BattleReportManager.new()
    end

    return _instance
end

function BattleReportManager:reset()
    
    self._reportStr = nil

    self._reportData = {}
    self._currentWave = 0

    self._isUpdate = true

end

function BattleReportManager:setInitData(params)

    self._reportData.version = BattleReportManager.VERSION
    self._reportData.id = params.id
    self._reportData.subId = params.subId
    self._reportData.pvType = params.pvType
    self._reportData.resDungeonStatus = params.resDungeonStatus

end

--[[
    添加角色信息
]]
function BattleReportManager:addRole(params)

    local role = self._reportData.role
    if not role then
        role = {}
        self._reportData.role = role
    end

    local camp = _getNumberKey(params.camp)
    role[camp] = params.info

end

--[[
    添加参战者
]]
function BattleReportManager:addFighter(params)

    if not self._reportData.fighter then
        self._reportData.fighter = {}
    end

    local camp = _getNumberKey(params.camp)
    local waveIndex = params.waveIndex

    local campData = self._reportData.fighter[camp]
    if not campData then
        campData = {}
        self._reportData.fighter[camp] = campData
    end

    local waveData = campData[waveIndex]

    if not waveData then
        waveData = {}
        waveData.fighterList = {}
        campData[waveIndex] = waveData
    end


    local fighter = {}
    fighter.id = params.id
    if params.fighterType == BattleType.ROLE or 
        params.fighterType == BattleType.GUARD then
        fighter.baseInfo = params.baseInfo
    else
        fighter.baseId = params.baseId
    end
    fighter.position = params.position

    table.insert(waveData.fighterList, fighter)

end

--[[
    设置当前波数
]]
function BattleReportManager:setCurrentWave(value)

    if not self._reportData.action then
        self._reportData.action = {}
    end

    if not self._reportData.action[value] then
        self._reportData.action[value] = {}
    end

    self._waveAction = self._reportData.action[value]

end

--[[
    添加回合数据
    @param round 回合
    @param campData 阵营数据
]]
function BattleReportManager:addRoundAction(params)

    local roundAction = self._waveAction[params.round]
    if not roundAction then
        roundAction = {}
        roundAction.campData = {}
        for camp, gemData in ipairs(params.campData) do
            roundAction.campData[_getNumberKey(camp)] = gemData
        end
        -- roundAction.campData = params.campData
        roundAction.attackerList = {}
        self._waveAction[params.round] = roundAction
    end

    self._roundAction = roundAction

end

--[[
    添加攻击者行动
    @param fighterId 行动者
    @param skillId 技能ID
    @param skillLev 技能等级
    @param target 目标数据
    @param skillIndex 使用技能索引
]]
function BattleReportManager:addAttackerAction(params)

    local attacker = {}
    attacker.id = params.fighterId
    attacker.skillId = params.skillId
    attacker.skillLev = params.skillLev
    attacker.target = params.target
    attacker.skillIndex = params.skillIndex

    table.insert(self._roundAction.attackerList, attacker)

    self._currentAttackAction = attacker

end

--[[
    添加连射目标
]]
function BattleReportManager:addDartleTarget(attackTimes, target)

    if not self._currentAttackAction.dartleTarget then
        self._currentAttackAction.dartleTarget = {}
    end

    self._currentAttackAction.dartleTarget[attackTimes] = target

end

--[[
    添加伤害数据
]]
function BattleReportManager:addHurtData(attackTimes, targetId, targetParam)

    local hurtData = self._currentAttackAction.hurtData
    if not hurtData then
        hurtData = {}
        self._currentAttackAction.hurtData = hurtData
    end

    if not hurtData[attackTimes] then
        hurtData[attackTimes] = {}
    end

    table.insert(hurtData[attackTimes], {targetId, targetParam})

end

--[[
    添加溅射伤害数据
]]
function BattleReportManager:addSpurtHurtData(attackTimes, spurtParam)

    local spurtData = self._currentAttackAction.spurtData
    if not spurtData then
        spurtData = {}
        self._currentAttackAction.spurtData = spurtData
    end

    if not spurtData[attackTimes] then
        spurtData[attackTimes] = {}
    end

    for entityId, shn in pairs(spurtParam) do
        spurtData[attackTimes][_getNumberKey(entityId)] = shn
    end

end

--[[
    添加buff播报
]]
function BattleReportManager:addBuff(buffDict, attackTimes)

    local buff = self._currentAttackAction.buff
    if not buff then
        buff = {}
        self._currentAttackAction.buff = buff
    end

    if not buff[attackTimes] then
        buff[attackTimes] = {}
    end

    for entityId, buffList in pairs(buffDict) do

        local reportList = self:_convertBuffList(buffList)

        buff[attackTimes][_getNumberKey(entityId)] = reportList
    end

end

function BattleReportManager:_convertBuffList(buffList)

    local reportList = {}

    for _, buffData in ipairs(buffList) do

        local buffReport = {}
        buffReport.id = buffData.id
        buffReport.round = buffData.round
        buffReport.attrType = buffData.attrType
        buffReport.attrArg = buffData.attrArg
        buffReport.attackerId = buffData.attackerId

        table.insert(reportList, buffReport)
    end

    return reportList

end

--[[
    添加被动技能播报
]]
function BattleReportManager:addPassiveSkill(entityId, attackTimes, psDict)

    if not self._roundAction then
        return
    end

    local ps = self._roundAction.ps
    if not ps then
        ps = {}
        self._roundAction.ps = ps
    end

    local scriptId

    for fid, psList in pairs(psDict) do

        local entityKey = _getNumberKey(entityId)

        if not ps[entityKey] then
            ps[entityKey] = {}
        end

        local times = ps[entityKey][attackTimes]
        if not times then
            times = {}
            ps[entityKey][attackTimes] = times
        end

        local fKey = _getNumberKey(fid)
        times[fKey] = {}

        for i, v in ipairs(psList) do

            scriptId = v[2]

            local scriptKey = _getNumberKey(scriptId)
            times[fKey][scriptKey] = {}

            local scriptData = times[fKey][scriptKey]

            if scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20003 or 
                scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20005 or
                scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20006 or 
                scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20008 or
                scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20013 then

                scriptData.targetList = {}

                for sid, _ in pairs(v[3]) do
                    table.insert(scriptData.targetList, sid)
                end

            elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20009 then
                scriptData.hurtPercent = v[4]
                scriptData.targetList = {}
                for sid, _ in pairs(v[3]) do
                    table.insert(scriptData.targetList, sid)
                end
            elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20010 then
                scriptData.reviveHp = v[3]
            elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20020 then

                scriptData.hp = v[3]
                scriptData.buffDict = {}
                for beId, buffList in pairs(v[4]) do
                    scriptData.buffDict[_getNumberKey(beId)] = self:_convertBuffList(buffList)
                end
            elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20023 then
                scriptData.buffDict = {}
                for beId, buffList in pairs(v[3]) do
                    scriptData.buffDict[_getNumberKey(beId)] = self:_convertBuffList(buffList)
                end
            end

        end
    end

end

--[[
    添加回合结束之前的被动技能
]]
function BattleReportManager:addPassiveSkillRoundEnd(scriptId, psData)

    local psEnd = self._roundAction.psEnd
    if not psEnd then
        psEnd = {}
        self._roundAction.psEnd = psEnd
    end

    local scriptKey = _getNumberKey(scriptId)
    local scriptData

    if scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20014 then
        psEnd[scriptKey] = {}
        scriptData = psEnd[scriptKey]
        for i, v in ipairs(psData) do

            scriptData[i] = {}
            scriptData[i].hp = v[2]
            scriptData[i].targetList = {}

            for k, _ in pairs(v[1]) do

                table.insert(scriptData[i].targetList, k)
            end
        end
    elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20017 then

        psEnd[scriptKey] = psData
    elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20027 then
        psEnd[scriptKey] = {}
        scriptData = psEnd[scriptKey]
        for i, v in ipairs(psData) do

            scriptData[i] = {}
            scriptData[i].hpPercent = v[2]
            scriptData[i].targetList = {}

            for k, _ in pairs(v[1]) do

                table.insert(scriptData[i].targetList, k)
            end
        end
    end

end

function BattleReportManager:addGemHp(entityId, value)

    local gemHp = self._roundAction.gemHp
    if not gemHp then
        gemHp = {}
        self._roundAction.gemHp = gemHp
    end

    gemHp[_getNumberKey(entityId)] = value
    
end

function BattleReportManager:addHurtStatistic(hurtDict)
    self._reportData.hurtDict = {}
    for entityId, hurt in pairs(hurtDict) do
        self._reportData.hurtDict[_getNumberKey(entityId)] = hurt
    end
end

function BattleReportManager:addResult(value)
    self._reportData.result = value
end


--[[
    生成战报
    @return string
]]
function BattleReportManager:generateReport()
    
    self._isUpdate = false
    
    if not self._reportStr then
        self._reportStr = Utils.serializeTable("reportData", self._reportData)

        -- test
        -- do
        --     local file = io.open("battle_report.txt", "w+")
        --     if not file then
        --         print("can't open file")
        --     else
        --         file:write(self._reportStr)
        --         file:close()
        --     end
        -- end
    end

    return self._reportStr
end

function BattleReportManager:getReportData()

    if self._isUpdate then
        self:generateReport()
    else
        --test
        -- do
        --     local file = io.open("battle_report.txt", "r")
        --     if file then
        --         self._reportStr = file:read()
        --         file:close()
        --     else
        --         return nil
        --     end
        -- end
    end

    -- self:generateReport()

    return loadstring(self._reportStr)()
end

