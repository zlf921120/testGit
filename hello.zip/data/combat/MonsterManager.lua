--
-- Author: lvgansheng
-- Date: 2014-07-18 16:36:51
-- 怪物数据管理

require("MonsterInfo")
require("MonsterAttr")
require("fnt_monster_data_pb")
require("AttrHelper")

MonsterManager = class("MonsterManager")

MonsterManager.base_info_dic = nil -- 怪物基础信息
MonsterManager.attr_dic = nil --怪物属性

local _instance = nil
local _allowInstance = false

local is_read = false
local is_load_Monster_plist = false

function MonsterManager:init()
    if not _allowInstance then
        error("MonsterManager is a singleton class,please call getInstance method")
    end

    self.base_info_dic = {}
    self.attr_dic = {}
end

function MonsterManager:getInstance()
    if _instance == nil then
        _allowInstance = true
        _instance = MonsterManager.new()
        _instance:init()
        _allowInstance = false
    end
    return _instance
end

--读取怪物数据
function MonsterManager:readData()
    require "AttrHelper"
    if is_read then
        cclog ("monster_data had already read,don't call this method again")
        return
    end

    print("   -------------------------  MonsterManager:readData -------------------------  ")

    --[[local dataFile = CCFileUtils:sharedFileUtils():fullPathForFilename("fnt_monster_data.dat")
    datafile_handle = io.open(dataFile, "rb")
    pbdata = datafile_handle:read("*a")
    datafile_handle:close()--]]
	local pbdata = FileUtils.readConfigFile("fnt_monster_data.dat")
    
    local msg = fnt_monster_data_pb.fnt_monster_data()
    msg:ParseFromString(pbdata)

    --读取怪物信息
    local base_info_rows = msg.base_info_rows
    local one_monseter_info = nil
    for i, v in pairs(base_info_rows) do
        if v.base_id~=nil then 
            one_monseter_info = MonsterInfo.new()
            one_monseter_info:setBaseData(v.base_id, v.level, v.animat_res_id, v.icon_res_id, v.img_res_id, 
                                      v.name, v.type, 0, v.race,v.atk_type)
            one_monseter_info.dead_audio_id = v.dead_audio_id
            one_monseter_info.desc = v.desc
            one_monseter_info:setDefaultSkill(v.act_skill1, v.act_skill2, v.act_skill3, v.pas_skill1, v.pas_skill2, v.pas_skill3)
            one_monseter_info:setAtkAction(v.atk_action1, v.atk_action2, v.atk_action3)
            one_monseter_info.despot_effect = tonumber(v.battle_despot_effect)

            self.base_info_dic[one_monseter_info.base_id] = one_monseter_info
        end
    end

    --读取怪物基础属性
    local base_attr_rows = msg.base_attr_rows
    local one_attr_data = nil

    for i, v in pairs(base_attr_rows) do
        if v.base_id~=nil then 

             one_attr_data = MonsterAttr:create()
             one_attr_data:setData(AttrHelper.attr_flag.hp,v.hp_max)
             one_attr_data:setData(AttrHelper.attr_flag.atk,v.atk)
             one_attr_data:setData(AttrHelper.attr_flag.pdef,v.pdef)
             one_attr_data:setData(AttrHelper.attr_flag.crit,v.crit)
             one_attr_data:setData(AttrHelper.attr_flag.block,v.block)
             one_attr_data:setData(AttrHelper.attr_flag.def_break,v.def_break)
             one_attr_data:setData(AttrHelper.attr_flag.evasion,v.evasion)
             one_attr_data:setData(AttrHelper.attr_flag.atk_speed,v.atk_speed)

             one_attr_data:setData(AttrHelper.attr_flag.fight_back,v.fight_back)
             one_attr_data:setData(AttrHelper.attr_flag.reduce_harm,v.reduce_harm)
             one_attr_data:setData(AttrHelper.attr_flag.real_harm,v.real_harm)
             one_attr_data:setData(AttrHelper.attr_flag.anti_stun,v.anti_stun)
             one_attr_data:setData(AttrHelper.attr_flag.anti_silent,v.anti_silent)
             one_attr_data:setData(AttrHelper.attr_flag.anti_chaos,v.anti_chaos)
             one_attr_data:setData(AttrHelper.attr_flag.anti_stone,v.anti_stone)
             one_attr_data:setData(AttrHelper.attr_flag.anti_polymorph,v.anti_polymorph)
             one_attr_data:setData(AttrHelper.attr_flag.anti_taunt,v.anti_taunt)
             one_attr_data:setData(AttrHelper.attr_flag.anti_sleep,v.anti_sleep)

             one_attr_data:setData(AttrHelper.attr_flag.tought,v.tought)
             one_attr_data:setData(AttrHelper.attr_flag.break_atk,v.break_atk)
             one_attr_data:setData(AttrHelper.attr_flag.suck_blood,v.suck_blood)
             one_attr_data:setData(AttrHelper.attr_flag.stare,v.stare)

             --配置表用千分比, 代码计算用万分比
             one_attr_data:setData(AttrHelper.attr_flag.anti_breakarmour, v.anti_breakarmour*10)
             one_attr_data:setData(AttrHelper.attr_flag.anti_poisoning, v.anti_poisoning*10)
             one_attr_data:setData(AttrHelper.attr_flag.anti_burn, v.anti_burn*10)
             one_attr_data:setData(AttrHelper.attr_flag.anti_bleed, v.anti_bleed*10)
             one_attr_data:setData(AttrHelper.attr_flag.anti_sacred_burn, v.anti_sacred_burn*10)

             self.attr_dic[v.base_id] = one_attr_data
        end
    end 
end

--获取怪物基础信息
function MonsterManager:getBaseInfo(base_id)
    return self.base_info_dic[base_id]
end

--获取属性
function MonsterManager:getBaseAttr(base_id)
    return self.attr_dic[base_id].attrs
end


function MonsterManager:setMonsterAtkAttr( baseId, atkBaseArgs )
    local attrInfo = self:getBaseAttr(baseId)
    
    local flag_name = nil
    for flag,value in pairs(attrInfo) do
    	flag_name = AttrHelper:getAttrStrFlag(flag)
    	atkBaseArgs[flag_name] = value
    end
       
end

