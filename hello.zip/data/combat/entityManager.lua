EntityManager = class("EntityManager")
EntityManager.__instance = nil

--所有的参战者字典
EntityManager._entityDict = nil

--友方的所有参战者字典
EntityManager._allyEntityDict = nil

--敌方的所有参战者字典
EntityManager._enemyEntityDict = nil

--敌方每波的参战者
EntityManager._enemyWaveEntityDict = nil

--友方存活的参战者
EntityManager._allyAliveEntityDict = nil
--敌方存活的参战者
EntityManager._enemyAliveEntityDict = nil

--被动技能触发次数
EntityManager._passTriggerTimesDict = nil

--复制的参战者字典
EntityManager._copyEntityDict = nil


function EntityManager:create()
	local objEntityManager = EntityManager.new()	
	objEntityManager:init()
	return objEntityManager
end

function EntityManager:init()

	self:_resetData()

end

function EntityManager:_resetData()

	self.entityContainers = {}
	self._entityDict = {}

	self._allyEntityDict = {}
	self._enemyEntityDict = {}
	self._enemyWaveEntityDict = {}

	self._allyAliveEntityDict = {}
	self._enemyAliveEntityDict = {}

	self._reviveEntityTimesDict = {}

	self._passTriggerTimesDict = {}

	self._copyEntityDict = {}

end

function EntityManager:uninit()
	
end

function EntityManager:getInstance()

	if self.__instance==nil then
		self.__instance = EntityManager:create()
	end
	
	return self.__instance
end

function EntityManager:registerEntity(entityId, entity)

	self._entityDict[entityId] = entity

	if entity:getEntityType() == BattleType.ATTACKER then
		self._allyEntityDict[entityId] = entity
		
		self._allyAliveEntityDict[entityId] = entity
	else
		self._enemyEntityDict[entityId] = entity

		self._enemyAliveEntityDict[entityId] = entity

		local waveDict = self._enemyWaveEntityDict[entity:getPhaseIndex()]
		if not waveDict then
			waveDict = {}
			self._enemyWaveEntityDict[entity:getPhaseIndex()] = waveDict
		end

		waveDict[entityId] = entity

	end

end

function EntityManager:getEntityWithID(entityId)
	
	return self._entityDict[entityId]
end

--[[
    通过baseId获取参战者
    @param ft fightType
    @param id baseId
]]
function EntityManager:getEntityWithBaseId(ft, id)

	for eId, entity in pairs(self._entityDict) do
		if ft == entity:getFighterType() then
			if entity:getAvatorId() == id then
				return entity
			end
		end
	end

	return nil

end

function EntityManager:removeEntity(entity)

	self._entityDict[entity:getEntityID()] = nil
end

function EntityManager:reset()

	for _, entity in pairs(self._entityDict) do
		entity:uninit()
	end

	self:_resetData()

end

function EntityManager:generateNewRoundData(roundData)

	for entityId, entity in pairs(self._allyEntityDict) do
		if not entity:getIsOut() or 
			roundData:isReviveEntity(entityId) then
			roundData:pushAttackerTeam(entityId)
		end
	end

	local waveIndex = BattleManager:getInstance():getWaveIndex()
	local waveDict = self._enemyWaveEntityDict[waveIndex]
	if waveDict then
		for entityId, entity in pairs(waveDict) do
			if not entity:getIsOut() or 
				roundData:isReviveEntity(entityId) then
				roundData:pushStrikerTeam(entityId)
			end
		end
	end

end

function EntityManager:isDead(entId)
	local ent = self:getEntityWithID(entId)
	if ent and ent:getIsDead() == true then
		return true
	end

	return false
end

--[[
    获取队伍统计信息(待搬)
    @return selfHeros{heroId = {hp, totalHp}}, targetHeros
]]
function EntityManager:getTeamCountInfo()

	local selfHeros = {}
	local targetHeros = {}

	for _, entity in pairs(self._entityDict) do
		if entity:getEntityType() == BattleType.ATTACKER then
			--攻击方
			selfHeros[entity:getAvatorId()] = {entity:getCurrentHp(), entity:getTotalHp()}
		elseif entity:getEntityType() == BattleType.STRIKER then
			--受击方
			targetHeros[entity:getAvatorId()] = {entity:getCurrentHp(), entity:getTotalHp()}
		end
	end

	return selfHeros, targetHeros

end

function EntityManager:getEntityDict()
	return self._entityDict
end

function EntityManager:getAllyEntityDict()
	return self._allyEntityDict
end

function EntityManager:getEnemyWaveEntityDict(waveIndex)
	return self._enemyWaveEntityDict[waveIndex]
end

--[[
    当前波敌人
]]
function EntityManager:getEnemyCurWaveDict()
	return self._enemyWaveEntityDict[BattleManager:getInstance():getWaveIndex()]
end

--[[
    设置参战者死亡
]]
function EntityManager:setEntityDead(entityId)

	self._allyAliveEntityDict[entityId] = nil
	self._enemyAliveEntityDict[entityId] = nil

end

--[[
    设置参战者复活
]]
function EntityManager:setEntityRevive(entityId)

	local entity = self._entityDict[entityId]
	entity:setIsDead(false)
	if entity:getEntityType() == BattleType.ATTACKER then
		self._allyAliveEntityDict[entityId] = entity
	else
		self._enemyAliveEntityDict[entityId] = entity
	end

end

--[[
    己方剩余参战者
]]
function EntityManager:getAllyAliveEntityDict()

	return self._allyAliveEntityDict

end

--[[
    敌方剩余参战者
]]
function EntityManager:getEnemyAliveEntityDict()

	return self._enemyAliveEntityDict
end

--[[
    添加被动技能触发次数
]]
function EntityManager:addPassTriggerTimes(entityId, scriptId)

	local passTimesDict = self._passTriggerTimesDict[entityId]
	if not passTimesDict then
		passTimesDict = {}
		self._passTriggerTimesDict[entityId] = passTimesDict
	end
	if not passTimesDict[scriptId] then
		passTimesDict[scriptId] = 0
	end

	passTimesDict[scriptId] = passTimesDict[scriptId] + 1

end

--[[
    获取被动技能触发次数
]]
function EntityManager:getPassTriggerTimes(entityId, scriptId)

	local passTimesDict = self._passTriggerTimesDict[entityId]
	if not passTimesDict then
		return nil
	end

	return passTimesDict[scriptId]

end

--[[
    获取目标列表
    @param targetType 目标类型
    @param entityType 参战者类型
    @return
]]
function EntityManager:getTargetList(targetType, entityType)

	local attackerList = {}
	local strikerList = {}

	for _, entity in pairs(self:getAllyAliveEntityDict()) do
		table.insert(attackerList, entity)
	end

	for _, entity in pairs(self:getEnemyAliveEntityDict()) do
		table.insert(strikerList, entity)
	end

	local targetList

	local camp = getSkillTargetCamp(targetType)
	if camp == BattleType.SKILL_ALLY then
		if entityType == BattleType.ATTACKER then
			targetList = attackerList
		else
			targetList = strikerList
		end
	else
		if entityType == BattleType.ATTACKER then
			targetList = strikerList
		else
			targetList = attackerList
		end
	end

	return targetList

end

function EntityManager:_getCloneEntityId(entityId)
	return string.format("clone_%d", entityId)
end

function EntityManager:addCloneEntity(entityId, value)
	self._copyEntityDict[self:_getCloneEntityId(entityId)] = value
end

function EntityManager:getCloneEntity(entityId)
	return self._copyEntityDict[self:_getCloneEntityId(entityId)]
end

function EntityManager:removeCloneEntity(entityId)
	self._copyEntityDict[self:_getCloneEntityId(entityId)] = nil
end
