--
-- Author: thisgf
-- Date: 2014-11-01 21:05:15
-- 战斗工具类

local PERCENT_BASE = 10000

BattleUtil = class("BattleUtil")

--根据比例值检测是否触发
function BattleUtil:checkPercent(triggerPercent)

	local percent = math.random(1, PERCENT_BASE)

	if percent <= triggerPercent then
		return true
	end

	return false
end

--[[
    获取多次血值
    @param times 次数
    @param rawNumber 原数值
    @return showNumberList, realNumberList
]]
function BattleUtil:getMultiTimesHp(times, rawNumber)

    local numberList = {}
    local realNumberList = {}

    if rawNumber ~= 0 then

        if times > 1 then
            local ratio = 1
            if rawNumber < 0 then
                ratio = -1
            end
            local subNumber = tonumber(rawNumber/times)
            local realNumber
            for i = 1, times - 1 do
                numberList[i] = subNumber
                realNumber = math.floor(math.abs(subNumber)) * ratio
                rawNumber = rawNumber - realNumber
                realNumberList[i] = realNumber
            end
        end

        numberList[#numberList + 1] = rawNumber
        realNumberList[#realNumberList + 1] = rawNumber
    end

    return numberList, realNumberList

end
