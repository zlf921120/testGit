RoundManager = class("RoundManager", EntityBase)

RoundManager._bm = nil

RoundManager._onEntityDeadFunc = nil

--回合结束前需要处理的角色列表
RoundManager._needHandleRoleList = nil

--攻击阵营类型
RoundManager._attackCampType = -1

--额外攻击比例
RoundManager._additionAtkPercent = 0

--回合更新监听
RoundManager._onUpdateRoundFunc = nil

--参战者播报监听
RoundManager._onBroadcastFighterFunc = nil

--播报攻击者列表
RoundManager._broadcastAttackerDict = nil
--播报目标者列表
RoundManager._broadcastTargetDict = nil


--受到额外伤害的目标数据
RoundManager._extraDamageTargetData = nil


function RoundManager:create(battleSched)
	local objRoundManager = RoundManager.new()
	objRoundManager:init(battleSched)
	return objRoundManager
end

function RoundManager:init(battleSched)
	--战斗调度器
	self.battleSched = battleSched

	self._bm = BattleManager:getInstance()
	
	self._entityMgr = EntityManager:getInstance()

	
	self.roundData = RoundData:create()

	--ai管理器
	self._aiManager = AIManager:getInstance()
	self._aiManager:initBattleData(self)

	self._onEntityDeadFunc = function(entityId)
	    self:_handleEntityDead(entityId)
	end

	self._onUpdateRoundFunc = function()
	    self:_newRoundBegin()
	end

	self._onBroadcastFighterFunc = function(param)

		local bcType = param.bcType
		local entityId = param.entityId
		local attackerId

		local printInfo

		if bcType == BattleType.BROADCAST_ATTACKER then
			self._broadcastAttackerDict[entityId] = true
			attackerId = entityId

			printInfo = "攻擊者"

		else
			self._broadcastTargetDict[entityId] = true
			attackerId = param.attackerId

			printInfo = "目標者"

		end

		local targetGroup = self.roundData:getRoundAttackTargets(attackerId)

		local isAttackerEnd = true
		local isTargetEnd = true

		if not self._broadcastAttackerDict[attackerId] then
			isAttackerEnd = false
		end

		for i, v in ipairs(targetGroup.attackTargetGroup) do
			if not self._broadcastTargetDict[v] then
				isTargetEnd = false
				break
			end
		end

		cclog("//////////////////////%s 播報完成:%d", printInfo, entityId)

		if isAttackerEnd and isTargetEnd then
			self:_broadcastComplete()
		end

	end

end

function RoundManager:uninit()
	self:unscheduleUpdate()
	self.roundData:uninit()
	self.roundData = nil
	self.battleSched = nil
	self._aiManager = nil

	-- Notifier.removeByName(CmdRegist.ATTACK_NEXT_PLAYER)

	Notifier.removeByName(CmdName.BATTLE_FIGHTER_BROADCAST_END)

	Notifier.remove(CmdName.BATTLE_UPDATE_ROUND, self._onUpdateRoundFunc)

end


function RoundManager:scheduleUpdate()
	if(self.hFunc ~= nil)then
		return
	end
	
	local updateTick = function()
		self:update()
	end
	self.hFunc = CCDirector:sharedDirector():getScheduler():scheduleScriptFunc(updateTick, 0, false)
end


function RoundManager:unscheduleUpdate()
	if(self.hFunc ~= nil)then
		CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(self.hFunc)
		self.hFunc = nil
	end
end

--回合调度
function RoundManager:roundSchedule()
	
	--调度开始
	self:scheduleUpdate()

	Notifier.regist(CmdName.BATTLE_UPDATE_ROUND, self._onUpdateRoundFunc)
	
	--回合正式开始
	self:_newRoundBegin()

end

function RoundManager:hasSelfHurtTarget(atkEntId)
	local bRet = false
	local hurtGroup = self:getHurtGroup(atkEntId)
	local hurtGroupNum = #hurtGroup.attackTargetGroup
	for idx = 1, hurtGroupNum do
		local targetId = hurtGroup.attackTargetGroup[idx]
		
		--攻击目标是否自己
		if targetId==atkEntId then
			bRet = true
			break
		end
	end
	
	return bRet
end

--update state
function RoundManager:update()
	
	local roundNSUEntityOrder = self.roundData:getNSUEntityOrder()
	local totalSize = roundNSUEntityOrder.size
	for i = 1, totalSize do
		local entityId = roundNSUEntityOrder:at(i)
		local entityRole = self._entityMgr:getEntityWithID(entityId)

		if entityRole then
			entityRole:update()
		end
	end

end


--新回合开始
function RoundManager:_newRoundBegin()

	if self._bm:getAutoPlay() == false then
		self._bm:pauseAccelerate()
	end

	self.roundData:updateRound(self._bm:getRoundIndex())
	BattleController:getInstance():updateRound(self._bm:getRoundIndex())

	--站立动作
	local entity
	for _, entityId in ipairs(self.roundData.attackerTeam) do
		entity = self._entityMgr:getEntityWithID(entityId)
		entity:getStateMachine():changeState(FighterStandState:create(), true)
	end

	for _, entityId in ipairs(self.roundData.strikerTeam) do
		entity = self._entityMgr:getEntityWithID(entityId)
		entity:getStateMachine():changeState(FighterStandState:create(), true)
	end

	self:_newRoundAction()

end

--新回合开始行动
function RoundManager:_newRoundAction()
	--初始化新一回合数据
	self:_initNewRoundEntity()

	--更新回合
	self:_updateRound()

	self:_innerRoundCombat()
end

--接收到宝石消除系统的技能
function RoundManager:roundInvoke(argGemClearSys)
	--
	-- cclog( "get gemclear color:%d, nums:%d", argGemClearSys.gemColor, argGemClearSys.gemNums )
	--根据宝石颜色和消除数量确定回合技能

	--设置启动过消除系统
	self.roundData:setInvokedGemSys(argGemClearSys)

	--后ai
	local waveData = self._bm:getStartData():getWaveDataWithIndex(
		self._bm:getWaveIndex()
	)
	if waveData.aiOppotunity == AIConfigType.oppotunityType.AFTER_SELECT_SKILL then
		self.roundData:generateEnemySkill()
		--播放对方的光环
		BattleController:getInstance():playCampSkillHonor(BattleType.STRIKER)
	end

	local addHpDict = {}

	--加成球
	if argGemClearSys.additionPercent > 0 then

		if argGemClearSys.gemColor == BattleStoneType.colorType.BLUE then

			local entity

			for i, entityId in ipairs(self.roundData:getAttackerTeam()) do

				entity = self._entityMgr:getEntityWithID(entityId)

				local addHp = entity:getTotalHp() * argGemClearSys.additionPercent / 100

				BattleController:getInstance():updateEntityHp(entityId, addHp)

				addHpDict[entityId] = addHp

			end

		elseif argGemClearSys.gemColor == BattleStoneType.colorType.RED then

			self._additionAtkPercent = argGemClearSys.additionPercent / 100

		end
	end

	--播放阵营光环
	BattleController:getInstance():playCampSkillHonor(BattleType.ATTACKER)

	if self._bm:getIsOB() == false then
		
		BattleReportManager:getInstance():addRoundAction({
		    round = self._bm:getRoundIndex(),
		    campData = {
		        [BattleType.ATTACKER] = {
			        gemColor = self.roundData:getGemColor(),
			        numGem = self.roundData:getGemNum()
		        },
		        [BattleType.STRIKER] = {
		            gemColor = self.roundData:getEnemyGemColor(),
			        numGem = 3
		        }
			}
		})

		for entityId, addHp in pairs(addHpDict) do
			BattleReportManager:getInstance():addGemHp(entityId, addHp)
		end

	end
	
	--开始攻击轮询
	self:_pollingInRound()

end

--取出回合内的下一个攻击者
function RoundManager:getNextAttackerInRound()

	local fighterId = self.roundData:popCurrentAttackFighter(self._attackCampType)

	if fighterId then
		return fighterId
	else
		if self._attackCampType == BattleType.ATTACKER then
			self._attackCampType = BattleType.STRIKER
		else
			self._attackCampType = BattleType.ATTACKER
		end
	end

	return self.roundData:popCurrentAttackFighter(self._attackCampType)

end

function RoundManager:_getHurtPlayer(params)

	local hurtGroupTarget = nil
    
    local attacker = params.atkEnt
    --被嘲讽了
    if attacker:getForceAttackTarget() ~= nil then
    	local forceTarget = self._entityMgr:getEntityWithID(attacker:getForceAttackTarget())
    	if forceTarget and forceTarget:getIsDead() == false then
    		hurtGroupTarget = {attacker:getForceAttackTarget()}
    	end

    --混乱
    elseif attacker:getIsChaos() then

    	local randomList = {}
    	local entity

    	for _, v in ipairs(params.leftTeam) do
    		entity = self._entityMgr:getEntityWithID(v)
    		if v ~= attacker:getEntityID() and not entity:getIsOut() then
    			randomList[#randomList + 1] = v
    		end
    	end

    	for _, v in ipairs(params.rightTeam) do
    		entity = self._entityMgr:getEntityWithID(v)
    		if v ~= attacker:getEntityID() and not entity:getIsOut() then
    			randomList[#randomList + 1] = v
    		end
    	end

    	hurtGroupTarget = {randomList[math.random(1, #randomList)]}

    end


    if hurtGroupTarget == nil then
    	hurtGroupTarget = getSkillTargetGroup(params)
    end

	-- local hurtGroupTarget = getSkillTargetGroup( params )
	if hurtGroupTarget == nil then
		print("===============戰鬥沒發現目標群組")
		return nil
	end
	
	local attackerEnt = params.atkEnt

	local skillTargetType = params.skillTargetTypeId

	local entId
	local idxMid
	--打一行
	if skillTargetType == SkillTargetType.targetType_16 then
		idxMid = #hurtGroupTarget

	--前中后
	elseif skillTargetType == SkillTargetType.targetType_0 or 
		   skillTargetType == SkillTargetType.targetType_1 or 
		   skillTargetType == SkillTargetType.targetType_2 then

		--尽量取下排位置
		if #hurtGroupTarget >= 2 then
			local pos1 = self._entityMgr:getEntityWithID(hurtGroupTarget[1]):getBattleFieldPosition()
			local pos2 = self._entityMgr:getEntityWithID(hurtGroupTarget[2]):getBattleFieldPosition()

			if pos2 - pos1 > 1 then
				idxMid = 1
			else
				idxMid = 2
			end
		else
			idxMid = 1
		end

	else
		idxMid = math.ceil(#hurtGroupTarget/2)
	end

	entId = hurtGroupTarget[idxMid]
	
	local hurtGroup = {}
	hurtGroup.targetId = entId
	hurtGroup.attackTargetGroup = hurtGroupTarget

	return hurtGroup

end

function RoundManager:getHurtGroup(curEntId)
	local hurtGroup = self.roundData:getRoundAttackTargets(curEntId)
	return hurtGroup
end

function RoundManager:getAttackSkillData(curEntId)
	local attackSkillData = self.roundData:getRoundAttackSkillData(curEntId)
	return attackSkillData
end

function RoundManager:_finishOneRound()

	self._needHandleRoleList = {}

	--处理回合buff结算
	self:_handleRoundBuffSettlement()

	--处理回合被动技能
	self:_handleRoundPasSkillSettlement()

	--结束阵营光环
	BattleController:getInstance():stopCampSkillHonor(BattleType.ATTACKER)
	BattleController:getInstance():stopCampSkillHonor(BattleType.STRIKER)

	BattleController:getInstance():showUpanisadShadow(false)

	--有人要复活
	local reviveList = self.roundData:getReviveEntityList()
	local reviveLen = #reviveList
	if reviveLen > 0 then
		local function reviveFunc(entityId)
			local entity = self._entityMgr:getEntityWithID(entityId)
			entity:getStateMachine():changeState(FighterStandState:create(), true)
			self.roundData:removeReviveEntity(entityId)

			BattleStatisticManager:getInstance():setDead(entityId, nil)

			for i, v in ipairs(self._needHandleRoleList) do
				if v == entityId then
					table.remove(self._needHandleRoleList, i)
					break
				end
			end

			--光环
			local halo = PassiveSkillManager:getInstance():generate20021(entity)
			self.roundData:addHalo(entityId, halo)

			self:_handleBeforeRoundFinish()

		end

		for i, reviveArg in ipairs(reviveList) do
			
			table.insert(self._needHandleRoleList, reviveArg[1])

			BattleController:getInstance():playReviveAction(reviveArg[1], reviveFunc)
			self._entityMgr:setEntityRevive(reviveArg[1])
			BattleController:getInstance():updateEntityHp(reviveArg[1], reviveArg[2])
		end
	end

	--结束回合前判断
	self:_handleBeforeRoundFinish()

end

function RoundManager:_handleBeforeRoundFinish()

	if #self._needHandleRoleList > 0 then
		return
	end

	--本回合结束, 请求下一回合
	self.battleSched:reqRoundEnd()

end

--回合内按出手顺序轮询攻击
function RoundManager:_pollingInRound()
	--检查是否有战斗结束
	-- local isFinish = self:handleCombatFinish()
	-- if isFinish == true then
	-- 	return
	-- end

	
	--确保启动过宝石消除系统
	if false == self:guarantGemClearSys() then
		return
	end
	
	local attackerEntId = self:getNextAttackerInRound()
	if attackerEntId == nil then
		self:_finishOneRound()
		return
	end
	
	local attacker = self._entityMgr:getEntityWithID(attackerEntId)

	--死亡
	if not attacker or attacker:getIsOut() then
		self:_pollingInRound()
		return
	end

	--切换出手方
	if self._attackCampType == BattleType.ATTACKER then
		self._attackCampType = BattleType.STRIKER
	else
		self._attackCampType = BattleType.ATTACKER
	end

	--不能行动
	if attacker:canAction() == false then
		repeat
			local pas20022 = PassiveSkillManager:getInstance():generate20022(attacker)
			if pas20022 then
				self.roundData:removeDominateBuff(attacker:getEntityID())
				BattleController:getInstance():playPasSkillEffect(
					attacker:getEntityID(), 
					PassiveSkillScriptType.SCRIPT_TYPE_20022
				)

				if self._bm:getIsOB() == false then
					BattleReportManager:getInstance():addPassiveSkill(
						attacker:getEntityID(),
						1,
						{
							[attacker:getEntityID()] = 
							{
								{
								    [2] = PassiveSkillScriptType.SCRIPT_TYPE_20022,
									[3] = pas20022
								}
							}
						}
					)
				end

				break
			end
			self:_pollingInRound()
			return
		until true
	end

	--获取普通攻击
	local function getNormalAttackSkill(atkType)

		if atkType == HeroHelper.atk_type.near_atk then
			return SkillManager:getInstance():getSkillDetailCfg(SkillDataCfg.NEAR_NORMAL_ATTACK, 1, 3)
		else
			return SkillManager:getInstance():getSkillDetailCfg(SkillDataCfg.FAR_NORMAL_ATTACK, 1, 3)
		end

	end

	
	local newState = nil
	local skillCfg = nil

	repeat

		if attacker:canUseSkill() == false then

			if attacker:getOnlyHasSilent() then
				local antiSilent = PassiveSkillManager:getInstance():generate20015(attacker)
				if not antiSilent then
					skillCfg = getNormalAttackSkill(attacker:getBaseInfo().atk_type)
					break
				end
			else
				skillCfg = getNormalAttackSkill(attacker:getBaseInfo().atk_type)
				break
			end
			
		end

		local skillId

		if attacker:getEntityType() == BattleType.ATTACKER then

			local gemColorNum = self.roundData:getGemNum()

			local heroSkillInfo = attacker:getBaseInfo().default_skills[self.roundData.gemColorSkillId]
			skillId = heroSkillInfo:getSkillId()
			skillCfg = SkillManager:getInstance():getSkillDetailCfg(
				skillId, 
				heroSkillInfo:getSkillLevel(), 
				gemColorNum
			)

		else

			skillId, skillLevel = self.roundData:getEnemySkill(attackerEntId)
			skillCfg = SkillManager:getInstance():getSkillDetailCfg(
				skillId, 
				skillLevel, 
				3
			)

		end
		
	until true

	if not skillCfg then
		print("////////////////////無發現此技能", skillId)
	end

	print("=============參戰者使用技能:", attacker:getEntityType(), attackerEntId, skillCfg.cfg._id)
	
	--添加回合内技能配置
	self.roundData:addRoundAttackSkillData(attacker:getEntityID(), skillCfg)
	
	local params = {}
	params.skillTargetTypeId = skillCfg.cfg.atkTargetType
	params.leftTeam = self.roundData.attackerTeam
	params.rightTeam = self.roundData.strikerTeam
	params.atkEnt = attacker
	params.targetNum = skillCfg.cfg._targetNum
	local targetGroup = self:_getHurtPlayer(params)
	if targetGroup then
		local destEnt = self._entityMgr:getEntityWithID(targetGroup.targetId)
		if destEnt == nil or destEnt:getIsOut() then
			self:_pollingInRound()
			return
		end
	else
		self:_pollingInRound()
		return
	end

	--设置当前行动者
	self.roundData:setCurrentActionId(attacker:getEntityID())

	self._broadcastAttackerDict = {}
	self._broadcastTargetDict = {}

	self.roundData:addRoundAttackTarget(attacker:getEntityID(), targetGroup)

	local targetList = targetGroup.attackTargetGroup

	--计算被动技能
	self:calcEntityPassiveSkill(skillCfg.cfg, attacker, targetList)

	--造成额外伤害
	if skillCfg.cfg._atkScriptId == SkillScriptType.EXTRA_FOR_SPECIAL_TARGET then

		local targetDict = BattleController:getInstance():getAccordTarget(
			skillCfg.cfg._atkScriptArgs[1][1], 
			skillCfg.cfg._atkScriptArgs[1][2], 
			targetList,
			attacker
		)

		if targetDict then
			self._extraDamageTargetData = {}
			self._extraDamageTargetData.targetDict = targetDict
			self._extraDamageTargetData.extraDamage = skillCfg.cfg._atkScriptArgs[1][3]
		end

	end


	--播放奥义
	if attacker:getEntityType() == BattleType.ATTACKER then

		if self.roundData:getGemColor() == BattleStoneType.colorType.PURPLE then

			if self.roundData:isPlayUpanisad() == false then

				self.roundData:setPlayUpanisad(true)

				local function onUpanisadFunc()

					self:_startBroadcast(attacker, skillCfg)
				end

				BattleController:getInstance():playUpanisadEffect(onUpanisadFunc)
				return
			end
		end
	end

	self:_startBroadcast(attacker, skillCfg)
	
end

--[[
    开始播报
]]
function RoundManager:_startBroadcast(attacker, skillData)

	self._bm:resumeAcclerate()

	Notifier.regist(CmdName.BATTLE_FIGHTER_BROADCAST_END, self._onBroadcastFighterFunc)

	if attacker:canUseSkill() == true then

		local isShowUpanisad = false
		if attacker:getEntityType() == BattleType.ATTACKER then
			if self.roundData:getGemColor() == BattleStoneType.colorType.PURPLE then
				isShowUpanisad = true
			end
		else
			if self.roundData:getEnemyGemColor() == BattleStoneType.colorType.PURPLE then
				isShowUpanisad = true
			end
		end

		if isShowUpanisad then
			BattleController:getInstance():showUpanisadShadow(true)

			local entityDict = self._entityMgr:getEntityDict()

			local hurtGroup = self:getHurtGroup(attacker:getEntityID())

			local suprtGroup = {}
			local suprtArgs = self.roundData:getPassiveSkillWithScript(
				attacker:getEntityID(), 
				PassiveSkillScriptType.SCRIPT_TYPE_20009
			)

			if suprtArgs then
				suprtGroup = suprtArgs[3]
			end

			local isHas = false

			for entityId, _ in pairs(entityDict) do

				isHas = false
				if entityId == attacker:getEntityID() then
					isHas = true
				else
					for _, hurtId in ipairs(hurtGroup.attackTargetGroup) do

						if hurtId == entityId then
							isHas = true

							break
						end
					end

					for suprtId, _ in pairs(suprtGroup) do
						if suprtId == entityId then
							isHas = true

							break
						end
					end

				end

				if isHas == false then
					BattleController:getInstance():setFighterDownDepth(entityId)
				end
			end
		end
	end

	local newState = nil
	newState = FighterAttackLaunchState:create()
	
	local nextState
	local skillId = skillData.cfg._id
	if skillId == SkillDataCfg.FLEE then
		newState = FighterFleeState:create()
	elseif skillId == SkillDataCfg.DEFENSE then
		nextState = FighterDefenseState:create()
	elseif skillData.cfg._atkScriptId == SkillScriptType.DARTLE then
		nextState = FighterSkillDartleState:create()
	else
		nextState = FighterAttackState:create()
	end

	newState:setNextState(nextState)

	attacker:getStateMachine():changeState(newState)

	if self._bm:getIsOB() == false then
		local target = self.roundData:getRoundAttackTargets(attacker:getEntityID())
		local skillIndex = self:getEntitySkillIndex(attacker)
		BattleReportManager:getInstance():addAttackerAction({
		    fighterId = attacker:getEntityID(),
		    skillId = skillId,
		    skillLev = skillData.cfg._level,
		    skillIndex = skillIndex,
		    target = target,
		})
	end

end

function RoundManager:_broadcastComplete()

	print("/////////////////////////播報完成")
	Notifier.remove(CmdName.BATTLE_FIGHTER_BROADCAST_END, self._onBroadcastFighterFunc)

	local actionId = self.roundData:getCurrentActionId()
	local skillData = self.roundData:getRoundAttackSkillData(actionId)
	if skillData.cfg._atkScriptId == SkillScriptType.BUFF_FROM_ATTACK then
		self:addBuffToEntity(actionId)
	end

	BattleController:getInstance():showUpanisadShadow(false)

	local allyTeam = self._entityMgr:getAllyEntityDict()
	local enemyTeam = self._entityMgr:getEnemyWaveEntityDict(self._bm:getWaveIndex())

	for entityId, _ in pairs(allyTeam) do
		BattleController:getInstance():resetFighterDepth(entityId)
	end

	for entityId, _ in pairs(enemyTeam) do
		BattleController:getInstance():resetFighterDepth(entityId)
	end

	--清除临时buff
	self.roundData:clearTempBuffDict()

	self._extraDamageTargetData = nil

	self:_pollingInRound()

end

--获取英雄技能序号
function RoundManager:getSkillIndex()
	return self.roundData.gemColorSkillId
end

--获取怪物技能序号
function RoundManager:getMonsterSkillIndex(entId)
	local entity = self._entityMgr:getEntityWithID(entId)
	local actionId = entity:getBaseInfo().atk_actions[self.roundData:getEnemyGemColor()]
	return actionId
end

function RoundManager:getGuardSkillIndex(entityId)
	local entity = self._entityMgr:getEntityWithID(entityId)
	
	local actionId = entity:getBaseInfo().atk_actions[self.roundData:getEnemyGemColor()]
	return actionId
end

--[[
    获取敌人技能序号
]]
function RoundManager:getEnemySkillIndex()
	return self.roundData:getEnemyGemColor()
end

--确保启动过宝石消除系统
function RoundManager:guarantGemClearSys()
	local bCanContinue = true
	if self.roundData:hasInvokedGemSys()==false then
		local preEntId = self:getNextAttackerInRound()
		local preAttacker = self._entityMgr:getEntityWithID(preEntId)
		if preAttacker then
			if preAttacker:getEntityType()==BattleType.ATTACKER then
				self.battleSched:startGemClearSys()
				bCanContinue = false
			end
		end
	end
	return bCanContinue
end

function RoundManager:_innerRoundCombat()
	repeat
		--如果己方战队先手,启动宝石消除系统
		if self.roundData.selfTeamAttackFirst == true then
			self.battleSched:startGemClearSys()
			break 
		end
		
		--开始攻击轮询
		self:_pollingInRound()
	until 0
end

function RoundManager:_updateRound()

	local waveData = self._bm:getStartData():getWaveDataWithIndex(
		self._bm:getWaveIndex()
	)
	if waveData.aiOppotunity == AIConfigType.oppotunityType.BEFORE_SELECT_SKILL then
		self.roundData:generateEnemySkill()
		--播放对方的光环
		BattleController:getInstance():playCampSkillHonor(BattleType.STRIKER)
	end

	Notifier.dispatchCmd(
		GuideEvent.Dungeon, 
		{
		    GuideCondType.Round, 
		    self._bm:getWaveIndex(), 
		    self._bm:getRoundIndex()
		}
	)

end

function RoundManager:_initNewRoundEntity()
	
	--清除上一轮回合数据
	self.roundData:clear()

	--额外添加的攻击力
	self._additionAtkPercent = 0
	
	--生成新一回合数据
	self._entityMgr:generateNewRoundData(self.roundData)
	
	--更新回合出手顺序
	self:_updateFighterAttackOrder()

	--处理被动技能
	local buffDict

	local allyDict = self._entityMgr:getAllyAliveEntityDict()
	local enemyDict = self._entityMgr:getEnemyAliveEntityDict()

	for _, entity in pairs(allyDict) do
	    buffDict = PassiveSkillManager:getInstance():generate20025(
	    	entity, 
	    	self._bm:getWaveIndex(), 
	    	self._bm:getRoundIndex(), 
	    	allyDict, 
	    	enemyDict
	    )

	    if buffDict then
	    	self.roundData:addBuffDict(buffDict)
	    end
	end

	for _, entity in pairs(enemyDict) do
	    buffDict = PassiveSkillManager:getInstance():generate20025(
	    	entity, 
	    	self._bm:getWaveIndex(), 
	    	self._bm:getRoundIndex(), 
	    	allyDict, 
	    	enemyDict
	    )

	    if buffDict then
	    	self.roundData:addBuffDict(buffDict)
	    end
	end
	
end


--[[
    计算攻击伤害
    @param atkEntId
    @param targetEntId
    @param atkIsFightBack 攻击者是否反击
]]
function RoundManager:calcAtkHurt(atkEntId, targetEntId, atkIsFightBack)

	if atkIsFightBack == nil then
		atkIsFightBack = false
	end

	local atkEnt = self._entityMgr:getEntityWithID(atkEntId)
	local targetEnt = self._entityMgr:getEntityWithID(targetEntId)

	local function checkPercentTrigger(percent)

		if percent > 0 and math.random() <= percent then
			return true
		end

		return false

	end

	--计算闪避
	local function calcMiss(targetMiss, atkLevel, targetLevel, atkStare)

		--等级压制
		local levelRepression = 0

		--攻击者等级比较大才会造成压制
		if atkLevel > targetLevel then
			levelRepression = math.abs(atkLevel - targetLevel) ^ 1.5
		end

		local missPercent = targetMiss / 1000 - levelRepression / 400 - (atkStare - 1000)/1000

		if missPercent > 0.7 then
			missPercent = 0.7
		end

		return checkPercentTrigger(missPercent)

	end

	--格挡概率
	local function calcBlock(atkWreck, targetBlock)

		local blockPercent = (targetBlock - atkWreck) / 1000

		if blockPercent > 0.7 then
			blockPercent = 0.7
		end

		return checkPercentTrigger(blockPercent)

	end

	--暴击概率
	local function calcCrit(atkCrit, targetTough)

		--有必爆buff
		if self.roundData:getOneBuff(atkEntId, BuffType.ADD_CRIT_PERCENT_ASSASSIN) then
			return true
		end

		local critPercent = (atkCrit - targetTough) / 1000

		if critPercent > 0.7 then
			critPercent = 0.7
		end

		return checkPercentTrigger(critPercent)

	end

	--计算是否反击
	local function calcFightBack(nearFarType, targetNearFarType, targetFightBack)

		if nearFarType ~= SkillDataCfg.NEAR_SKILL or targetNearFarType ~= HeroHelper.atk_type.near_atk then
			return false
		end

		local fightBackPercent = targetFightBack / 1000

		if fightBackPercent > 0.7 then
			fightBackPercent = 0.7
		end

		return checkPercentTrigger(fightBackPercent)

		-- return true

	end

	--计算伤害
	local function calcHurt(atkAttrArgs, targetAttrArgs, atkFactor, skillExtraDamage)

		local hurtNumber = 0

		--攻击系数为0不产生伤害
		if atkFactor == 0 then
			return hurtNumber
		end

		local atk = atkAttrArgs.atk * atkFactor / 10000 + skillExtraDamage
		--攻击者的主动额外攻击力
		if self._extraDamageTargetData then
			if self._extraDamageTargetData.targetDict[targetEntId] then
				atk = atk + self._extraDamageTargetData.extraDamage
			end
		end

		hurtNumber = atk * 1500 / 
					 (math.max(0, (targetAttrArgs.pdef - atkAttrArgs.def_break)) + 1500) + 
                     atkAttrArgs.real_harm


        --发起者被动伤害
		hurtNumber = self.roundData:calcAtkPassiveSkillForStrike(
			atkEntId, 
			targetEntId, 
			hurtNumber, 
			1
		)

		--消除球的额外伤害
		if atkEnt:getEntityType() == BattleType.ATTACKER then
			hurtNumber = hurtNumber * (1 + self._additionAtkPercent)
		end

		--自身属性的伤害豁免
		local reduceHarmMinus = targetAttrArgs.reduce_harm_minus + targetAttrArgs.reduce_harm/10000
		if reduceHarmMinus > 1 then
			reduceHarmMinus = 1
		end

		hurtNumber = hurtNumber * (1 - reduceHarmMinus) * (1 - targetAttrArgs.reduce_harm_add)

		local pseudoNum = math.random(-5, 5)
		hurtNumber = math.ceil(hurtNumber * (100 + pseudoNum) / 100)

		--竞技场额外防守方加成20%
		if self._bm:getType() == BattleType.ARENA then
			if atkEnt:getEntityType() == BattleType.STRIKER then
				hurtNumber = hurtNumber * 1.2
			end
		--公会战
		elseif self._bm:getType() == BattleType.GUILD_FIGHT then
			if atkEnt:getEntityType() == BattleType.STRIKER then
				local addPercent = 0.1
				if self._bm:getStartData().fightArea == GuildFightArea.Power then
					addPercent = addPercent + self._bm:getStartData().cheerPercent
				end
				hurtNumber = hurtNumber + hurtNumber * addPercent
			elseif atkEnt:getEntityType() == BattleType.ATTACKER then
				if self._bm:getStartData().fightArea == GuildFightArea.Defense then
					hurtNumber = hurtNumber * (1 - self._bm:getStartData().cheerPercent)
				end
			end
		end

		if hurtNumber <= 1 then
			hurtNumber = 1
		end

		return hurtNumber

	end

	--计算护盾减伤
	local function calcShield(hurtBase)

		hurtBase = hurtBase - targetEnt:getCurrentShieldHp()

		if hurtBase < 0 then
			hurtBase = 0
		end

		return hurtBase

	end

	--计算吸血
	local function calcVampire(hurtBase, vampireArg)

		local vampireNumber = hurtBase * vampireArg / 1000

		return math.ceil(vampireNumber)

	end


	local hurtNumber = 0
	local vampireNumber = 0

	local atkAttrData = atkEnt:getAttrData()
	local targetAttrData = targetEnt:getAttrData()
	
	--攻击方属性
	-- local atkBaseArgs = atkEnt:getAttackBaseArgs()
	-- --受击方属性
	-- local targetBaseArgs = targetEnt:getAttackBaseArgs()

	local atkBaseArgs = atkAttrData:getDecryptAttrs()
	local targetBaseArgs = targetAttrData:getDecryptAttrs()
	
	--buff属性
	local atkFinalArgs = {}
	self.roundData:setBuffAtkAttr(atkEntId, atkBaseArgs, atkFinalArgs)
	
	--本次攻击额外属性	
	local curAtkExtraArgs = atkEnt:getCurAttackExtraArgs()
	if curAtkExtraArgs then
		local attrStrFlag = AttrHelper:getAttrStrFlag(curAtkExtraArgs.type)
		atkFinalArgs[attrStrFlag] = atkFinalArgs[attrStrFlag] + curAtkExtraArgs.value
	end

	--攻击者的被动技能属性
	self.roundData:setPassiveSkillAttr(atkEntId, atkFinalArgs)
	self.roundData:calcHaloAttr(atkEntId, atkFinalArgs)
	
	local targetFinalArgs = {}
	self.roundData:setBuffAtkAttr(targetEntId, targetBaseArgs, targetFinalArgs)

	--受击者的被动属性
	self.roundData:setPassiveSkillAttr(targetEntId, targetFinalArgs)
	self.roundData:calcHaloAttr(targetEntId, targetFinalArgs)

	local atkSkillData = self:getAttackSkillData(atkEntId)

	local isMiss = calcMiss(
		targetFinalArgs.evasion, 
		atkEnt:getBaseInfo():getCurLevel(), 
		targetEnt:getBaseInfo():getCurLevel(),
		atkFinalArgs.stare
	)
	local isFightBack = false
	if not atkIsFightBack then
		isFightBack = calcFightBack(
			atkSkillData.cfg._nearFarType, 
			targetEnt:getBaseInfo().atk_type, 
			targetFinalArgs.fight_back
		)
	end

	local hurtNumber = 0
	local vampireNumber = 0
	local isBlock = false
	local isCrit = false
	local shieldNumber = 0
	local atkHurtNumber = 0
	--受伤治疗值
	local hurtTreatNumber = 0

	if isMiss == false then

		hurtNumber = calcHurt(
			atkFinalArgs, 
			targetFinalArgs, 
			atkSkillData.cfg._atkFactor, 
			atkSkillData.cfg._extraDamage
		)

		isBlock = calcBlock(atkFinalArgs.break_atk, targetFinalArgs.block)

		isCrit = calcCrit(atkFinalArgs.crit, targetFinalArgs.tought)

		if isBlock then
			hurtNumber = hurtNumber * 0.5
			hurtNumber = math.ceil(hurtNumber)
		end

		if isCrit then
			hurtNumber = hurtNumber * 1.5
		end

		if isBlock then
			--免疫伤害
			isImmune = self.roundData:getPassiveSkillWithScript(
				targetEntId, 
				PassiveSkillScriptType.SCRIPT_TYPE_20016
			)
			if isImmune then
				hurtNumber = 0
			end
		end

		--减免伤害
		isImmune = self.roundData:getPassiveSkillWithScript(
			targetEntId, 
			PassiveSkillScriptType.SCRIPT_TYPE_20019
		)
		if isImmune then
			hurtNumber = hurtNumber - hurtNumber*isImmune[3]
		end

		--受击者被动伤害
		hurtNumber, atkHurtNumber = self.roundData:calcPassiveSkillStrike(
			targetEntId, 
			hurtNumber, 
			1
		)

		--最高伤害
		isImmune = self.roundData:getPassiveSkillWithScript(
			targetEntId, 
			PassiveSkillScriptType.SCRIPT_TYPE_20024
		)

		if isImmune then
			if hurtNumber > isImmune[3] then
				hurtNumber = isImmune[3]
			end
		end

		local undamageBuff = self.roundData:getOneBuff(targetEntId, BuffType.UNDAMAGE_ADD_HP)
		--无伤加血
		if undamageBuff then
			if undamageBuff.argType == BuffArgType.PERCENT then
				hurtTreatNumber = math.ceil(hurtNumber*undamageBuff.attrArg/10000)
			else
				hurtTreatNumber = undamageBuff.attrArg
			end
			hurtNumber = 0
		end

		vampireNumber = calcVampire(hurtNumber, atkFinalArgs.suck_blood)

		------------添加统计
		BattleStatisticManager:getInstance():addHurt(atkEntId, hurtNumber)

	end

	if hurtNumber and hurtNumber < 0 then
		hurtNumber = 0
	end

	local hurtData = {}
	hurtData.isMiss = isMiss
	hurtData.isBlock = isBlock
	hurtData.isCrit = isCrit
	hurtData.hurtNumber = hurtNumber
	hurtData.atkerHurtNumber = atkHurtNumber or 0
	hurtData.vampireNumber = vampireNumber or 0
	hurtData.hurtTreatNumber = hurtTreatNumber

	return hurtData

	-- return {
	-- 	isMiss = isMiss,        --是否miss
	-- 	isBlock = isBlock,      --是否格挡
	-- 	isCrit = isCrit,        --是否暴击
	-- 	isFightBack = isFightBack,  --是否反击
	-- 	hurtNumber = hurtNumber,   --受伤数值
	-- 	atkerHurtNumber = atkHurtNumber or 0, --攻击者受伤害
	-- 	-- shieldNumber = shieldNumber,  --吸收伤害数值
	-- 	vampireNumber = vampireNumber or 0  --吸血数值
	-- }

end

--[[
    计算是否反击
]]
function RoundManager:calcFightBack()

end

--更新参战者出手顺序
function RoundManager:_updateFighterAttackOrder()

	local atTeamOrder = {}
	local skTeamOrder = {}

	for k, v in pairs(self.roundData.attackerTeam) do
		local entity = self._entityMgr:getEntityWithID(v)
		table.insert(
			atTeamOrder, 
			{
			    entId = v, 
			    speedScore = entity:getAgility()
			}
		)
	end
	
	for k, v in pairs(self.roundData.strikerTeam) do
		local entity = self._entityMgr:getEntityWithID(v)
		table.insert(
			skTeamOrder, 
			{
			    entId = v, 
			    speedScore = entity:getAgility()
			}
		)
	end

	local fComp = function(a, b)
		if a.speedScore < b.speedScore then
			return true
		else
			return false
		end
	end

	--战斗成员出手顺序判定
	table.sort(atTeamOrder, fComp)
	table.sort(skTeamOrder, fComp)

	local waveData = self._bm:getStartData():getWaveDataWithIndex(
		self._bm:getWaveIndex()
	)

	if waveData.fightOrder == BattleFightOrderType.ENEMY then
		self._attackCampType = BattleType.STRIKER
	elseif waveData.fightOrder == BattleFightOrderType.ALLY then
		self._attackCampType = BattleType.ATTACKER
	else
		if self._bm:isAllyAttackFirst() then
			self._attackCampType = BattleType.ATTACKER
		else
			self._attackCampType = BattleType.STRIKER
		end
	end

	-- if self._bm:isAllyAttackFirst() then
	-- 	self._attackCampType = BattleType.ATTACKER
	-- else
	-- 	self._attackCampType = BattleType.STRIKER
	-- end

	local roundNSUEntityOrder = self.roundData:getNSUEntityOrder()

	local orderList = {}
	for i, v in ipairs(atTeamOrder) do
		orderList[#orderList + 1] = v.entId
		roundNSUEntityOrder:push(v.entId)
	end
	self.roundData:setAllyAttackOrder(orderList)


	orderList = {}
	for i, v in ipairs(skTeamOrder) do
		orderList[#orderList + 1] = v.entId
		roundNSUEntityOrder:push(v.entId)
	end
	self.roundData:setEnemyAttackOrder(orderList)


end

--[[
    计算参战者的buff(过时)
    @param skillData 技能数据
    @param atker 攻击者数据
    @param targetIdList 目标id列表
]]
function RoundManager:calcEntityBuff(skillData, atker, targetIdList)

	local targeterList = {}
	local entity
	for i, v in ipairs(targetIdList) do

		entity = self._entityMgr:getEntityWithID(v)
		if entity then
			table.insert(targeterList, entity)
		end
	end

	local bm = BuffManager:getInstance()

	local skillId = skillData._id

	--测试id
	-- skillId = 100100

	local buffDict = bm:generatorBuff(
		skillId, 
		skillData._level, 
		skillData._eliminateBaseNum, 
		atker, 
		targeterList
	)

	if not buffDict then
		return
	end

	for entityId, buffList in pairs(buffDict) do

		self.roundData:addBuff(entityId, buffList, self._bm:getRoundIndex())
	end
end

--[[
    生成参战者的buff数据, 由外面控制出现的时机
]]
function RoundManager:generateEntityBuff(scriptId, scriptArgs, atker, targetIdList)

	local targeterList = {}
	local entity
	for i, v in ipairs(targetIdList) do

		entity = self._entityMgr:getEntityWithID(v)
		if entity then
			table.insert(targeterList, entity)
		end
	end

	local bm = BuffManager:getInstance()

	local buffDict = bm:generateBuffWithSkill(
		scriptId, 
		scriptArgs, 
		atker, 
		targeterList
	)

	if not buffDict then
		return
	end

	self.roundData:addTempBuffDict(buffDict)

end

--[[
    添加临时buff到参战者
]]
function RoundManager:addBuffToEntity(entityId)

	self.roundData:addTempBuffToEntity(entityId)
end

--[[
    计算参战者的被动技能
    @param skillData 技能数据
    @param atker 攻击者
    @param targetIdList 目标ID列表
]]
function RoundManager:calcEntityPassiveSkill(skillData, atker, targetIdList)

	--每次计算都先清空参战者的被动技能
	self.roundData:clearPassiveSkill(atker:getEntityID())

	local targeterList = {}
	local entity
	for i, v in ipairs(targetIdList) do

		self.roundData:clearPassiveSkill(v)

		entity = self._entityMgr:getEntityWithID(v)
		if entity then
			table.insert(targeterList, entity)
		end
	end

	local passiveSkillDict = PassiveSkillManager:getInstance():generatePassiveSkill(
		skillData, 
		atker, 
		targeterList
	)
	if not passiveSkillDict then
		return
	end

	for entityId, psList in pairs(passiveSkillDict) do

		self.roundData:addPassiveSkill(entityId, psList)
	end

	if self._bm:getIsOB() == false then
		BattleReportManager:getInstance():addPassiveSkill(
			atker:getEntityID(), 
			1, 
			passiveSkillDict
		)
	end

end

--[[
    处理参战者死亡
]]
function RoundManager:_handleEntityDead(entityId)

	-- table.remove(self._needHandleRoleList)

	-- if #self._needHandleRoleList == 0 then
	-- 	self:_handleBeforeRoundFinish()
	-- end

	for i, v in ipairs(self._needHandleRoleList) do
		if v == entityId then
			table.remove(self._needHandleRoleList, i)
			break
		end
	end

	self:_handleBeforeRoundFinish()

end

--[[
    处理回合buff的结算
]]
function RoundManager:_handleRoundBuffSettlement()

	if not self.roundData.buffDict then
		return
	end

	local changeHpDict = {}

	for k, buffList in pairs(self.roundData.buffDict) do

		changeHpDict[k] = {}

		for i, buffData in ipairs(buffList) do

			if buffData.id == BuffType.KEEP_ADD_HP then
				table.insert(changeHpDict[k], 1, buffData.attrArg)
			elseif buffData.id == BuffType.POISONING then

				--增加毒伤害
				local isAddPoison = self.roundData:getPassiveSkillWithScript(
					buffData.attackerId, 
					PassiveSkillScriptType.SCRIPT_TYPE_20017
				)
				if isAddPoison then
					buffData.attrArg = buffData.attrArg + isAddPoison[3]
					if self._bm:getIsOB() == false then
						BattleReportManager:getInstance():addPassiveSkillRoundEnd(
							PassiveSkillScriptType.SCRIPT_TYPE_20017,
							{
							    attackerId,
							    isAddPoison
						    }
						)
					end
				end

				table.insert(changeHpDict[k], buffData.attrArg)
			elseif buffData.id == BuffType.KEEP_MINUS_HP or
				   buffData.id == BuffType.BURN or 
				   buffData.id == BuffType.KEEP_MINUS_HP_OVERLAY or
				   buffData.id == BuffType.BURN_OVERLAY or 
				   buffData.id == BuffType.POISONING_OVERLAY or 
				   buffData.id == BuffType.SACRED_BURN then
			   
				table.insert(changeHpDict[k], buffData.attrArg)
			end
		end
	end

	for k, v in pairs(changeHpDict) do

		for i, hp in ipairs(v) do
			local needHandle = BattleController:getInstance():updateEntityHp(
				k, 
				hp, 
				true, 
				self._onEntityDeadFunc, 
				false
			)
			if needHandle == true then
				table.insert(self._needHandleRoleList, k)
			end

		end
	end

end

--处理回合被动技能的结算
function RoundManager:_handleRoundPasSkillSettlement()

	local attackerDict = self._entityMgr:getAllyAliveEntityDict()
	local strikerDict = self._entityMgr:getEnemyAliveEntityDict()

	local psList20014 = PassiveSkillManager:getInstance():generate20014(
		attackerDict, 
		strikerDict
	)

	local psList20027 = PassiveSkillManager:getInstance():generate20027(
		attackerDict, 
		strikerDict
	)

	for i, v in ipairs(psList20014) do

		for k, entity in pairs(v[1]) do
			local needHandle = BattleController:getInstance():updateEntityHp(
				k, 
				v[2], 
				true, 
				self._onEntityDeadFunc, 
				false
			)
			if needHandle == true then
				table.insert(self._needHandleRoleList, k)
			end
		end

	end

	for i, v in ipairs(psList20027) do
		for k, entity in pairs(v[1]) do
			local needHandle = BattleController:getInstance():updateEntityHp(
				k, 
				entity:getTotalHp()*v[2], 
				true, 
				self._onEntityDeadFunc, 
				false
			)
			if needHandle == true then
				table.insert(self._needHandleRoleList, k)
			end
		end
	end

	if self._bm:getIsOB() == false then

		BattleReportManager:getInstance():addPassiveSkillRoundEnd(
			PassiveSkillScriptType.SCRIPT_TYPE_20014, 
			psList20014
		)

		BattleReportManager:getInstance():addPassiveSkillRoundEnd(
			PassiveSkillScriptType.SCRIPT_TYPE_20027, 
			psList20027
		)
	end

end

--[[
    校验参战者能否反击
]]
function RoundManager:validEntityFightBack(entityId)

	local entity = self._entityMgr:getEntityWithID(entityId)
	if not entity then
		return false
	end

	if entity:getIsDead() == true then
		return false
	end

	if entity:canAction() then
		return true
	end

	return false

end

--[[
    添加在死亡过程中的玩家
]]
function RoundManager:addDeadProcessEntity(entityId)
	self.roundData:addDeadProcessEntity(entityId)
end

--[[
    移除在死亡过程中的玩家
]]
function RoundManager:removeDeadProcessEntity(entityId)
	self.roundData:removeDeadProcessEntity(entityId)

	if #self.roundData:getDeadProcessList() == 0 then
		Notifier.dispatchCmd(CmdName.BATTLE_HANDLE_DEAD_PROCESS_END)
	end
end

function RoundManager:getRoundData()
	return self.roundData
end

--[[
    获取参战者使用的技能
]]
function RoundManager:getEntitySkillIndex(entity)
	local curSkillIndex
	if entity:canUseSkill() then
		if entity:getEntityType() == BattleType.STRIKER then
			if entity:getFighterType() == BattleType.ROLE then
				curSkillIndex = self:getEnemySkillIndex()
			elseif entity:getFighterType() == BattleType.MONSTER then
				curSkillIndex = self:getMonsterSkillIndex(entity:getEntityID())
			elseif entity:getFighterType() == BattleType.GUARD then
				curSkillIndex = self:getGuardSkillIndex(entity:getEntityID())
			end
			-- if entity:isRole() then
			-- 	curSkillIndex = self:getEnemySkillIndex()
			-- else
			-- 	curSkillIndex = self:getMonsterSkillIndex(entity:getEntityID())
			-- end
		else
			curSkillIndex = self:getSkillIndex()
		end
	else
		curSkillIndex = BattleStoneType.colorType.RED
	end

	return curSkillIndex
end