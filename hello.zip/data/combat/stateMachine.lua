StateMachine = class("StateMachine")

function StateMachine:create(master)
	local objStateMachine = StateMachine.new()	
	objStateMachine:init( master )
	return objStateMachine
end

function StateMachine:init( master )
	self.entityMaster = master
	self.curState = nil
	self.prevState = nil
	self.globalState = nil
	self.hasExecuteState = false
end

function StateMachine:uninit()

end

function StateMachine:setCurState(argCurState)
	self.curState = argCurState
	self.hasExecuteState = false
end

function StateMachine:getExecuteState()
	--cclog( "get hasExecuteState:%s", self.hasExecuteState )
	return self.hasExecuteState
end

function StateMachine:setExecuteState()
	self.hasExecuteState = true
	--cclog( "set hasExecuteState:%s", self.hasExecuteState )
end
	
function StateMachine:setPrevState( argPrevState )
	self.prevState = argPrevState
end

function StateMachine:setGlobalState( argGlobalState )
	self.globalState = argGlobalState
end
	
function StateMachine:update()
	--cclog( "state machine update:%d", self.entityMaster:getEntityID() )
	if self.globalState~=nil then
		self.globalState:invoke(self.entityMaster)
	end
	
	if self.curState~=nil then
		self.curState:invoke(self.entityMaster)
	end
end

function StateMachine:handleMessage( state_msg )
	if self.curState~=nil and self.curState:onMessage( self.entityMaster, state_msg )==true then
		return true
	end
	
	if self.globalState~=nil and self.globalState:onMessage( self.entityMaster, state_msg )==true then
		return true
	end
	
	return false
end

function StateMachine:changeState(newState, forceChange)
	--判断新状态
	assert( newState~=nil and "changeState try to assign nil state to current" ) 

	if forceChange == nil then
		forceChange = false
	end
	
	if self.curState==nil or forceChange == true or self.curState:getType()~=newState:getType() then
		
		--cclog( "changestate:%d", self.entityMaster:getEntityID() )
		
		self.prevState = self.curState

		if self.curState then
			self.curState:exit(self.entityMaster)
		end
		
		self.curState = newState
		
		self.curState:enter(self.entityMaster)
		
		self.hasExecuteState = false
	end
end

function StateMachine:backToPrevState()
	self:changeState( self.prevState )
end

function StateMachine:isInState( argState )
	if self.curState==argState then
		return true
	end
	
	return false
end

function StateMachine:getCurState()
	return self.curState
end

function StateMachine:getPrevState()
	return self.prevState
end

function StateMachine:getGlobalState()
	return self.globalState
end

