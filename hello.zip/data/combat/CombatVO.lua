--
-- Author: thisgf
-- Date: 2014-12-09 15:03:25
-- 战斗相关结构


--播放时的战报数据
BattlePlayReportData = class("BattlePlayReportData")

BattlePlayReportData._seedData = nil

function BattlePlayReportData:ctor()
end

--[[
    设置种子数据
]]
function BattlePlayReportData:setSeedData(value)
    self._seedData = value
end

function BattlePlayReportData:getRole(camp)

    return self._seedData.role[camp]
end

--[[
    获取己方列表
]]
function BattlePlayReportData:getAllyTeamList()

    local fighterList = self._seedData.fighter[BattleType.ATTACKER]

    return fighterList[1].fighterList
end

--[[
    获取敌人列表
]]
function BattlePlayReportData:getEnemyTeamList(waveIndex)

    local fighterList = self._seedData.fighter[BattleType.STRIKER]
    if not fighterList then
        return nil
    end

    return fighterList[waveIndex].fighterList
end

function BattlePlayReportData:_getRoundAction(wave, round)

    local waveAction = self._seedData.action[wave]

    return waveAction[round]
end

--[[
    获取宝石数据
]]
function BattlePlayReportData:getGemData(wave, round, camp)

    local roundAction = self:_getRoundAction(wave, round)

    local campData = roundAction.campData

    return campData[camp]
end

--[[
    获取攻击者的数据
]]
function BattlePlayReportData:getAttackerData(wave, round, index)

    local roundAction = self:_getRoundAction(wave, round)

    return roundAction.attackerList[index]
end

--[[
    整理buff播报, 返回战斗时所用数据
]]
function BattlePlayReportData:handleBuff(buffReportDict)

    local tempBuffDict = {}
    for entityId, reportList in pairs(buffReportDict) do

        local buffList = {}
        for _, buffReportData in ipairs(reportList) do

            local rawData = SkillManager:getInstance():getBattleBuffConfigData(buffReportData.id)

            local buffEffectData = BuffEffectVO:create()
            buffEffectData:assignFromRawData(rawData)
            buffEffectData.round = buffReportData.round
            buffEffectData.attrType = buffReportData.attrType
            buffEffectData.attrArg = buffReportData.attrArg
            buffEffectData.attackerId = buffReportData.attackerId

            table.insert(buffList, buffEffectData)

        end

        tempBuffDict[tonumber(entityId)] = buffList

    end

    return tempBuffDict
end

--[[
    获取被动技能
    @param wave 波数
    @param round 回合数
    @param atkerId 当前攻击者ID
    @param attackTimes 第几次攻击
    @param entityId 参战者
    @param scriptId 脚本ID
]]
function BattlePlayReportData:getPassiveSkill(params)

    params.wave = params.wave or BattleManager:getInstance():getWaveIndex()
    params.round = params.round or BattleManager:getInstance():getRoundIndex()
    params.attackTimes = params.attackTimes or 1

    local roundAction = self:_getRoundAction(params.wave, params.round)

    if params.scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20014 or 
        params.scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20027 then
        
        local psEnd = roundAction.psEnd

        local psData = psEnd[params.scriptId]

        return psData

    elseif params.scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20017 then

        local psEnd = roundAction.psEnd

        local psData = psEnd[params.scriptId]
        if psData then
            if psData[1] == params.attackerId then
                return psData[2]
            end
        end

        return nil

    end

    local ps = roundAction.ps

    local psDict = ps[params.atkerId]

    if not psDict then
        return nil
    end

    for fid, psList in pairs(psDict[params.attackTimes]) do
        if fid == params.entityId then
            for sid, psData in pairs(psList) do
                if sid == params.scriptId then
                    return psData
                end
            end
        end
    end

    return nil

end

function BattlePlayReportData:getRoundGemHp(wave, round)

    local roundAction = self:_getRoundAction(wave, round)

    return roundAction.gemHp
end

function BattlePlayReportData:getPvType()
    return self._seedData.pvType
end

function BattlePlayReportData:getHurtDict()
    return self._seedData.hurtDict
end

function BattlePlayReportData:getResult()
    return self._seedData.result
end

function BattlePlayReportData:create()
    local cprd = BattlePlayReportData.new()
    return cprd
end


--加密的角色数据
BattleEncryptRoleData = class("BattleEncryptRoleData")

BattleEncryptRoleData.heroDict = nil
BattleEncryptRoleData.teamSkillDict = nil

function BattleEncryptRoleData:ctor()

    self.heroDict = {}
    self.teamSkillDict = {}

end

function BattleEncryptRoleData:create()
    return BattleEncryptRoleData.new()
end


--加密的英雄数据
BattleEncryptHeroData = class("BattleEncryptHeroData")

BattleEncryptHeroData.id = 0
BattleEncryptHeroData.base_id = 0 
BattleEncryptHeroData.animat_res_id = 0 -- 动作资源ID
BattleEncryptHeroData.icon_res_id = 0 --头像资源ID
BattleEncryptHeroData.img_res_id = 0 --原画资源ID
BattleEncryptHeroData.pos = 0 -- 卡牌站位类型
BattleEncryptHeroData.race = 0 -- 英雄种族
BattleEncryptHeroData.atk_type = 0 -- 英雄攻击方式
BattleEncryptHeroData.cur_lev = 1 --卡牌当前等级

BattleEncryptHeroData.default_skills = nil --卡牌主动技能
BattleEncryptHeroData.pas_skills = nil --卡牌被动技能

BattleEncryptHeroData.attrs = nil
BattleEncryptHeroData._attrData = nil
BattleEncryptHeroData.modelId = 0   --模型ID

function BattleEncryptHeroData:ctor()
    self.attrs = {}
    self._attrData = BattleEncryptAttrData:create()
end

function BattleEncryptHeroData:getEncryptAttrData()
    return self._attrData
end

function BattleEncryptHeroData:getCurLevel()
    return self.cur_lev
end

function BattleEncryptHeroData:getModelId()
    return self.modelId
end

function BattleEncryptHeroData:create()
    return BattleEncryptHeroData.new()
end


--加密属性数据
BattleEncryptAttrData = class("BattleEncryptHeroData")

BattleEncryptAttrData._isEncrypt = false
BattleEncryptAttrData._attrs = nil

function BattleEncryptAttrData:ctor()
    self._attrs = {}
end

function BattleEncryptAttrData:setIsEncrypt(value)
    self._isEncrypt = value
end

--[[
    设置来自服务端的数据
]]
function BattleEncryptAttrData:setServerAttrs(attrs)
    for i, v in ipairs(attrs) do
        self._attrs[AttrHelper:getAttrStrFlag(v.name)] = v.val
    end
end

--[[
    设置来自客户端的数据
]]
function BattleEncryptAttrData:setClientAttrs(attrs)
    for k, v in pairs(attrs) do
        self._attrs[k] = v
    end
end

function BattleEncryptAttrData:setAttr(attrName, attrValue)
    if self._isEncrypt then
        attrValue = BattleManager:getInstance():getEncryptValue(attrValue)
    end
    self._attrs[AttrHelper:getAttrStrFlag(attrName)] = attrValue
end

function BattleEncryptAttrData:getAttr(attr)

    local attrName

    if type(attr) == "string" then
        attrName = attr
    else
        attrName = AttrHelper:getAttrStrFlag(attr)
    end


    if self._isEncrypt then
        return BattleManager:getInstance():getDecryptValue(self._attrs[attrName])
    end

    return self._attrs[attrName]
end

function BattleEncryptAttrData:getDecryptAttrs()
    local attrs = {}
    for i, v in pairs(self._attrs) do
        if self._isEncrypt then
            attrs[i] = BattleManager:getInstance():getDecryptValue(v)
        else
            attrs[i] = v
        end
    end

    return attrs
end

function BattleEncryptAttrData:create()
    return BattleEncryptAttrData.new()
end

