BattleSchedule = class("BattleSchedule")

BattleSchedule._allyFighterList = nil
BattleSchedule._enemyFighterList = nil

BattleSchedule._waveData = nil

--入场玩家数量
BattleSchedule._numEnterFighter = 0

BattleSchedule._battleResultType = nil

BattleSchedule._onRspResultFunc = nil
BattleSchedule._onReqRoundEnd = nil
BattleSchedule._onUpdatePauseFunc = nil

BattleSchedule._isRequestRoundEnd = nil

BattleSchedule._isRequestNextWave = nil


local enterOrder = {[2] = 1, [1] = 2, [4] = 3, [3] = 4, [6] = 5, [5] = 6}

function BattleSchedule:create()
	local objBattleSchedule = BattleSchedule.new()	
	objBattleSchedule:init()
	return objBattleSchedule
end

function BattleSchedule:init()

	self._bm = BattleManager:getInstance()
	
	self._renderLayer = TouchBattleLayer:create()
	self._renderLayer:hideUI()

	self._entityManage = EntityManager:getInstance()

	
	--回合调度

	if self._bm:getIsOB() then
		self._roundManager = ReportRoundManager:create()
	else
		self._roundManager = RoundManager:create(self)
		self._renderLayer:setRoundManager(self._roundManager)
	end
	-- self._roundManager = RoundManager:create(self)
	-- self._renderLayer:setRoundManager(self._roundManager)

	--设置战斗控制器参数
	BattleController:getInstance():setBattleSche(self)
	BattleController:getInstance():setBattleScene(self._renderLayer)
	BattleController:getInstance():setRoundManager(self._roundManager)

	self._onReqRoundEnd = function()
	    self:reqRoundEnd()
	end
	Notifier.regist(CmdName.BATTLE_REQ_ROUND_END, self._onReqRoundEnd)

	self._onUpdatePauseFunc = function()
	    if self._isRequestRoundEnd and self._bm:isPause() == false then
	    	self:_roundEndCheck()
	    end
	end
	Notifier.regist(CmdName.BATTLE_UPDATE_PAUSE_STATUS, self._onUpdatePauseFunc)

end
	
function BattleSchedule:uninit()

	--重置Entity管理器
	self._entityManage:reset()
	self._entityManage = nil
	
	--回合调度
	self._roundManager:uninit()
	self._roundManager = nil
	
	--清除战斗层
	self._renderLayer:clearMap()
	self._renderLayer:uninit()
	self._renderLayer:removeFromParentAndCleanup(true)	
	self._renderLayer = nil

	BattleController:getInstance():clearBattle()

	Notifier.removeByName(CmdName.BATTLE_HANDLE_DEAD_PROCESS_END)

	if self._onRspResultFunc then
		Notifier.remove(CmdName.BATTLE_RSP_RESULT, self._onRspResultFunc)
	end

	Notifier.remove(CmdName.BATTLE_REQ_ROUND_END, self._onReqRoundEnd)

end

--[[
    设置波数据
]]
function BattleSchedule:setWaveData(value)

	self._waveData = value

	local aiData = self._waveData:getAIDataWithLevel()

	AIManager:getInstance():setAIList(aiData[2], aiData[1])

end

--[[
    初始化战斗
]]
function BattleSchedule:initBattle()

	self:_createAndStartScene()

	self:_createMap()

end

--[[
    开始战斗
]]
function BattleSchedule:begin()

	self:_checkPlot()
end

--[[
    开始下一波战斗
]]
function BattleSchedule:beginNextFight()

	local allyEnterLen = 0

	local allyTeam = self._entityManage:getAllyEntityDict()
	for entityId, entity in pairs(allyTeam) do

		if entity:getIsDead() == false then
			self._roundManager:getRoundData():clearEntityBuff(entityId)
		end
	end


	if self._bm:getStartData().sceneType == BattleSceneType.SCROLL then

		BattleController:getInstance():moveMapToNext()

		local allyTeam = self._entityManage:getAllyEntityDict()

		for entityId, entity in pairs(allyTeam) do

			if entity:getIsDead() == false then

				BattleController:getInstance():playRunAction(entityId)
				allyEnterLen = allyEnterLen + 1

			end
		end

		TimerManager.addTimer(2000, 
			function()
				self._numEnterFighter = self._numEnterFighter - allyEnterLen
				for entityId, entity in pairs(allyTeam) do

					if entity:getIsDead() == false then
						entity:getStateMachine():setCurState(nil)
						entity:getStateMachine():changeState(FighterStandState:create())
					end
				end
				BattleController:getInstance():setMapIndex(self._bm:getWaveIndex())
				self:_playEnterComplete()
			end, 
			false)

	else

		BattleController:getInstance():setMapIndex(self._bm:getWaveIndex())

	end

	self._numEnterFighter = allyEnterLen + #self._enemyFighterList

	self:_playEnemyEnterScene()

end

function BattleSchedule:_createMap()

	local startData = self._bm:getStartData()

	local mapPathList = {}
 
	for i, waveData in ipairs(startData.waveList) do
		mapPathList[i] = waveData.sceneFileName
	end

	self._renderLayer:createMap(
		startData.sceneType, 
		mapPathList, 
		self._bm:getWaveIndex()
	)

end

function BattleSchedule:_checkPlot()

	Notifier.dispatchCmd(GuideEvent.Dungeon, {GuideCondType.Into})
	if self._bm:hasIntoPlot() == true then
		local function onStoryComplete()
			self:_startBattleAfterPlot()
			return true
		end
		self._bm:pauseAccelerate()
		Notifier.regist(GuideEvent.PerStoryComplete, onStoryComplete)
		return
	end

	self:_startBattleAfterPlot()

end

--剧情之后进入战斗
function BattleSchedule:_startBattleAfterPlot()

	self._renderLayer:showUI()

	if not self._bm:getIsOB() then
		self._renderLayer:moveUIWithStart()
	end
	-- self._renderLayer:moveUIWithStart()

	self:_playEnterScene()

end

function BattleSchedule:reqRoundEnd()

	self._isRequestRoundEnd = true

	if self._bm:isPause() then
		return
	end

	self:_roundEndCheck()

end

function BattleSchedule:_roundEndCheck()

	cclog("請求下一回合")

	self._isRequestRoundEnd = false

	self._isRequestNextWave = false

	self._battleResultType = self:_getBattleResult()

	if self._battleResultType == BattleResultType.CONTINUE then
		self._bm:reqNextRound()
	else
		self:_checkWaveEnd()
	end

end

function BattleSchedule:_checkWaveEnd()

	local function handleResult()
		--赢了
		if self._battleResultType == BattleResultType.VICTORY then
			--最后一波怪物
			if self._bm:getWaveIndex() >= self._bm:getProcessData():getWaveTotalIndex() then

				self:_checkGuideBeforeEnd()
			else

				self._bm:reqFightNextWaveEnemy()
			end
		else
			--跪了
		    self:showBattleResult()
		end
	end

	local deadProcessLen = #self._roundManager:getRoundData():getDeadProcessList()
	if deadProcessLen == 0 then

		handleResult()
	else
		local function handleDeadFunc()
			TimerManager.removeTimer(handleDeadFunc)
			if self._isRequestNextWave == true then
				return true
			end
			self._isRequestNextWave = true
			handleResult()
			return true
		end
		
		--设置8s超时
		TimerManager.addTimer(8000, handleDeadFunc, false)

		Notifier.regist(CmdName.BATTLE_HANDLE_DEAD_PROCESS_END, handleDeadFunc)
	end

end

--获取战斗结果
function BattleSchedule:_getBattleResult()

	local allyDict = self._entityManage:getAllyEntityDict()

	local enemyDict = self._entityManage:getEnemyCurWaveDict()

	local allyFail = true
	local enemyFail = true

	if allyDict then
		for _, entity in pairs(allyDict) do
			if not entity:getIsOut() then
				allyFail = false
				break
			end
		end
	end

	if enemyDict then
		for _, entity in pairs(enemyDict) do
			if not entity:getIsOut() then
				enemyFail = false
				break
			end
		end
	end

	local isRoundEnough = false

	local startData = self._bm:getStartData()
	if startData.maxRound > 0 then
		if self._bm:getRoundIndex() >= startData.maxRound then
			isRoundEnough = true
		end
	end

	local result = BattleResultType.CONTINUE
	local battleType = self._bm:getType()

	repeat
		--有复活的参战者
		if #self._roundManager:getRoundData():getReviveEntityList() > 0 then
			result = BattleResultType.CONTINUE
			break
		end

		if allyFail == false and enemyFail == false then
			result = BattleResultType.CONTINUE
			break
		end

		if allyFail and enemyFail then
			if battleType == BattleType.SKY_WAR then
				result = BattleResultType.DRAW
			end
		end

		if battleType == BattleType.RIDDLE_DUNGEON then
			if allyFail == true then
				result = BattleResultType.FAIL
				break
			end

			if enemyFail == true then
				result = BattleResultType.VICTORY
				break
			end

			break
		end

		if enemyFail == true then
			result = BattleResultType.VICTORY
			break
		end

		if allyFail == true then
			result = BattleResultType.FAIL
			break
		end

	until true

	if result == BattleResultType.CONTINUE then
		if isRoundEnough then
			if battleType == BattleType.SKY_WAR then
				result = BattleResultType.DRAW
			else
				result = BattleResultType.FAIL
			end
		end
	end

	return result

end

--检查结束前是否有剧情
function BattleSchedule:_checkGuideBeforeEnd()

	local startData = self._bm:getStartData()

	if self._bm:getType() == BattleType.DUNGEON then

		if self._battleResultType == BattleResultType.VICTORY then
			local eventId = GuideDataProxy:getInstance():isHasPosStoryDungeon(startData.id, startData.subId)
			if eventId ~= nil then
				self._bm:pauseAccelerate()
				Notifier.dispatchCmd(GuideEvent.Dungeon, {GuideCondType.Pass, startData.id, startData.battleType})
				return
			end
		end
	end

	self:showBattleResult()

end

--[[
    显示战斗结果
]]
function BattleSchedule:showBattleResult()

	local allyTeam = self._entityManage:getAllyEntityDict()
	local enemyTeam = self._entityManage:getEnemyCurWaveDict()

	if allyTeam then
		for entityId, entity in pairs(allyTeam) do

			if entity:getIsDead() == false then

				self._roundManager:getRoundData():clearEntityBuff(entityId)
				
				if self._battleResultType == BattleResultType.VICTORY then
					entity:getStateMachine():changeState(FighterCelebrateState:create())
				end
			end
		end
	end

	if enemyTeam then
		for entityId, entity in pairs(enemyTeam) do
			if entity.isDead == false then
				self._roundManager:getRoundData():clearEntityBuff(entityId)
			end
		end
	end

	--观战
	if self._bm:getIsOB() then

		local reportData = self._bm:getReportData()

		local hurtDict = reportData:getHurtDict()
		for eid, hurt in pairs(hurtDict) do
			BattleStatisticManager:getInstance():addHurt(eid, hurt)
		end

		local playbackData = BattleStatisticManager:getInstance():getHurtSummaryData()
		playbackData.myHeroInfo = reportData:getRole(BattleType.ATTACKER)
		if self._bm:getPvType() == BattleType.PVP then
			playbackData.enemyHeroInfo = reportData:getRole(BattleType.STRIKER)
		end
		playbackData.result = reportData:getResult()

		BattleWindowManager:getInstance():openWindow(
			BattleWindowType.PLAYBACK_VIEW, 
			playbackData
		)
		return
	end

	local resultReq

	local result = self._battleResultType

	if not self._onRspResultFunc then
	     self._onRspResultFunc = function()
		    self._renderLayer:hideUI()
	        --延迟800ms
			TimerManager.addTimer(800, function()
				resultData = self._bm:getBattleResultData()
				if self._battleResultType == BattleResultType.VICTORY then
					self._renderLayer:displayWinLayer(resultData)
				else
					self._renderLayer:displayFailLayer(resultData)
				end 
			end, 
			false)

			return true
		 end
    end

	Notifier.regist(CmdName.BATTLE_RSP_RESULT, self._onRspResultFunc)

	BattleReportManager:getInstance():addHurtStatistic(
		BattleStatisticManager:getInstance():getHurtDict()
	)
	BattleReportManager:getInstance():addResult(result)

	if self._bm:getType() == BattleType.GUILD_BOSS then

		local guildBossHp = 0
		for entityId, entity in pairs(enemyTeam) do
			if entity:getBaseInfo().monsterType == Helper.monsterType.GUILD_BOSS then
				guildBossHp = entity:getCurrentHp()
				break
			end
		end
		self._bm:reqBattleResult(result, guildBossHp)
	else

		self._bm:reqBattleResult(result)
	end

end

function BattleSchedule:startGemClearSys()
	-- self.gemClearSys:beginPlay()
	self._renderLayer:beginGemClear()
end

--[[
    创建己方队伍
]]
function BattleSchedule:createAllyTeam(heroDict)

	self._allyFighterList = {}

	local role	
	for position, heroInfo in pairs(heroDict) do
		heroInfo.sex = CharacterManager:getInstance():getBaseData():getSex()
		role = self:_createRole(BattleType.ATTACKER, position, heroInfo)
		self._renderLayer:setSelfTeam(position, role)

		table.insert(self._allyFighterList, role:getEntityID())

		if self._bm:getIsOB() == false then
			BattleReportManager:getInstance():addFighter({
				id = role:getEntityID(),
				fighterType = BattleType.ROLE,
				waveIndex = 1,
				position = position,
				camp = BattleType.ATTACKER,
				baseInfo = 
				{
				    id = heroInfo.id, 
				    hp = role:getCurrentHp(),
				    totalHp = role:getTotalHp(),
				    modelId = heroInfo:getModelId()
			    }
			})

		end

	end

	if self._bm:getIsOB() then
		self._renderLayer:updateAvatarPos()
	end

end

--[[
    创建敌方队伍
]]
function BattleSchedule:createEnemyTeam(enemyDict)

	self._enemyFighterList = {}

	if self._bm:getPvType() == BattleType.PVP then

		--敌方英雄
		local role	
		for position, heroInfo in pairs(enemyDict) do
			print("k=",position)
			print("v=",heroInfo)
			if BattleManager:getInstance():getStartData().battleType == 11 then
				require "FriendMgr"
				heroInfo.sex = FriendMgr:getInstance():getEnemySex()
			end
			role = self:_createRole(BattleType.STRIKER, position, heroInfo)
			self._renderLayer:setEnemyTeam(position, role)

			table.insert(self._enemyFighterList, role:getEntityID())

			if self._bm:getIsOB() == false then
				BattleReportManager:getInstance():addFighter({
					id = role:getEntityID(),
					fighterType = BattleType.ROLE,
					waveIndex = self._bm:getWaveIndex(),
					position = position,
					camp = BattleType.STRIKER,
					baseInfo = 
					{
					    id = heroInfo.id, 
					    hp = role:getCurrentHp(),
					    totalHp = role:getTotalHp(),
					    modelId = heroInfo:getModelId()
				    }
				})
			end

		end

	else

		repeat
			local startData = self._bm:getStartData()
			if self._bm:getType() == BattleType.RES_DUNGEON then
				if startData.resDungeonStatus == 2 then

				    --敌方怪物
					for position, guardData in pairs(enemyDict) do

						local guard = self:_createGuard(BattleType.STRIKER, position, guardData)
						self._renderLayer:setEnemyTeam(position, guard)

						table.insert(self._enemyFighterList, guard:getEntityID())

						if self._bm:getIsOB() == false then
							BattleReportManager:getInstance():addFighter({
								id = guard:getEntityID(),
								fighterType = BattleType.GUARD,
								waveIndex = self._bm:getWaveIndex(),
								position = position,
								camp = BattleType.STRIKER,
								baseInfo = 
								{
								    baseId = guardData.baseId,
								    hp = guard:getCurrentHp(),
								    totalHp = guard:getTotalHp(),
								    modelId = guardData:getModelId()
							    }
							})
						end

					end

				    break
			    end
			end

			local monster

			--敌方怪物
			for position, monsterData in pairs(enemyDict) do

				monster = self:_createMonster(position, monsterData)
				self._renderLayer:setEnemyTeam(position, monster)

				table.insert(self._enemyFighterList, monster:getEntityID())

				if self._bm:getIsOB() == false then
					BattleReportManager:getInstance():addFighter({
						id = monster:getEntityID(),
						fighterType = BattleType.MONSTER,
						waveIndex = self._bm:getWaveIndex(),
						position = position,
						camp = BattleType.STRIKER,
						baseId = monsterData.baseId
					})
				end

			end

		until true

	end

end

--[[
    生成入场顺序
]]
function BattleSchedule:_generateFighterEnterOrder(fighterList)

	local generateEnterOrder = {}

	for k, v in pairs(fighterList) do
		
		local ent = self._entityManage:getEntityWithID(v)
		local battlePos = ent:getBattleFieldPosition()
		local newIndex = enterOrder[battlePos]

		local isInsert = false
		for i1, v1 in ipairs(generateEnterOrder) do

			local oldIndex = enterOrder[v1:getBattleFieldPosition()]

			if oldIndex > newIndex then

				table.insert(generateEnterOrder, i1, ent)
				isInsert = true
				break
			end
		end

		if isInsert == false then
			table.insert(generateEnterOrder, ent)
		end
	end

	return generateEnterOrder

end

--播放双方入场
function BattleSchedule:_playEnterScene()

	self._numEnterFighter = #self._allyFighterList + #self._enemyFighterList

	self:_playAllyEnterScene()
	self:_playEnemyEnterScene()

	self:_playDemonEnter()

end

function BattleSchedule:_playAllyEnterScene()

	local allyEnterOrderList = self:_generateFighterEnterOrder(self._allyFighterList)

	local roleJoinType = self._waveData.roleJoinType

	if self._bm:hasIntoPlot() == true then
		roleJoinType = BattleJoinType.STAND
	end

	self:_playEnterType(
		roleJoinType, 
		self._allyFighterList, 
		allyEnterOrderList
	)

end

function BattleSchedule:_playEnemyEnterScene()

	local enemyEnterOrderList = self:_generateFighterEnterOrder(self._enemyFighterList)

	local joinType = self._waveData.monsterJoinType

	if self._bm:hasIntoPlot() == true then
		if self._waveData.monsterPlotJoinType > 0 then
			joinType = self._waveData.monsterPlotJoinType
		end
	end

	self:_playEnterType(
		joinType, 
		self._enemyFighterList, 
		enemyEnterOrderList
	)

end

function BattleSchedule:_playEnterType(joinType, fighterList, orderList)

	local targetPosition
	local posTable

	local function enterFunc(entityId)

		local entity = self._entityManage:getEntityWithID(entityId)

		entity:getStateMachine():changeState(FighterStandState:create())

		self._numEnterFighter = self._numEnterFighter - 1
		self:_playEnterComplete()

	end

	for k, entityId in pairs(fighterList) do

		local ent = self._entityManage:getEntityWithID(entityId)

		local delayEnterTime = 0
		for i, v1 in ipairs(orderList) do

			if v1 == ent then

				delayEnterTime = 500 + (i - 1) * 200
				break
			end
		end

		if ent:getEntityType() == BattleType.ATTACKER then
			posTable = ROLE_POSITION[ent:getBattleFieldPosition()]
		else
			posTable = MONSTER_POSITION[ent:getBattleFieldPosition()]
		end

		targetPosition = ccp(posTable.x, posTable.y)

		if joinType == BattleJoinType.STAND then

			BattleController:getInstance():playStandEnterAction(
				entityId, 
				targetPosition, 
				enterFunc
			)

		elseif joinType == BattleJoinType.JUMP then

			BattleController:getInstance():playJumpEnterAction(
				entityId, 
				delayEnterTime, 
				targetPosition, 
				enterFunc
			)

		elseif joinType == BattleJoinType.FLASH then

			BattleController:getInstance():playFlashEnterAction(
				entityId, 
				delayEnterTime, 
				enterFunc
			)

		elseif joinType == BattleJoinType.RUN then

			local initPos
			local runTime = 0

			if ent:getEntityType() == BattleType.ATTACKER then
				runTime = 2.5
				initPos = ccp(
					targetPosition.x - DisplayUtil.visibleSize.width, 
					targetPosition.y
				)
			else
				if self._bm:getWaveIndex() > 1 then
					runTime = 2
					initPos = ccp(
						targetPosition.x + DisplayUtil.visibleSize.width*1.5, 
						targetPosition.y
					)
				else
					runTime = 2.5
					initPos = ccp(
						targetPosition.x + DisplayUtil.visibleSize.width, 
						targetPosition.y
					)
				end
			end

			BattleController:getInstance():playRunEnterAction(
				entityId, 
				runTime, 
				initPos, 
				targetPosition, 
				enterFunc
			)
		
		end

	end

end

--入场完成
function BattleSchedule:_playEnterComplete()

	if self._numEnterFighter > 0 then
		return
	end

	--第一场
	if self._bm:getWaveIndex() == 1 then
		Notifier.dispatchCmd(GuideEvent.Dungeon, {GuideCondType.Begin})
	end

	self._battleResultType = self:_getBattleResult()

	if self._battleResultType == BattleResultType.CONTINUE then
		--开始新阶段
		BattleController:getInstance():newPhaseAndPlay()

		self._roundManager:roundSchedule()
	else
		self:_checkWaveEnd()
	end

end

--播放精灵入场
function BattleSchedule:_playDemonEnter()

	if self._bm:getWaveIndex() > 1 then
		return
	end

	if self._bm:getIsOB() == false then

		local selfPet = PetDataProxy:getInstance():getCurPetVo()

		if selfPet.star > 0 then
			BattleController:getInstance():playDemonEnter(
				BattleType.ATTACKER, 
				selfPet.star
			)

			BattleController:getInstance():playDemonAddFC(
				BattleType.ATTACKER, 
				TeamManager:getInstance():getPetExtFc()
			)
		end
		
		if self._bm:getType() == BattleType.GLORY_ROAD or
			self._bm:getType() == BattleType.ARENA or self._bm:getType() == BattleType.FRIEND then
			local startData = self._bm:getStartData()

			if startData.otherRoleInfo.pet_star > 0 then

				BattleController:getInstance():playDemonEnter(
					BattleType.STRIKER, 
					startData.otherRoleInfo.pet_star
				)
				BattleController:getInstance():playDemonAddFC(
					BattleType.STRIKER, 
					startData.otherRoleInfo:getPetExtFc()
				)
			end
		end

	end

end

function BattleSchedule:_createRole(attackType, battleFieldPosition, heroInfo)
	print("hero=",heroInfo.sex)
	print("hero=",heroInfo.sex)
	print("hero=",heroInfo.sex)
	print("hero=",heroInfo.sex)
	
	local role = Role:create(attackType, heroInfo)
	role:setFighterId(heroInfo.fighterId)
	-- role:setBaseAttr(heroInfo.attrs)
	role:setBaseAttrData(heroInfo:getEncryptAttrData())
	role:setBattleFieldPosition(battleFieldPosition)
	role:setPhaseIndex(self._bm:getWaveIndex())
	self._entityManage:registerEntity(role:getEntityID(), role)

	role:setIsRole(true)

	-- if heroInfo.currentHp == 0 then
	-- 	role:setCurrentHp(heroInfo.attrs.hp, false, true)
	-- else
	-- 	role:setCurrentHp(heroInfo.currentHp, false, true)
	-- end

	role:setCurrentHp(
		heroInfo:getEncryptAttrData():getAttr(AttrHelper.attr_flag.hp_cur), 
		false, 
		true
	)

	if attackType == BattleType.ATTACKER then
		role:setTeamIndex(heroInfo.teamIndex)
	end

	--光环
	local halo = PassiveSkillManager:getInstance():generate20021(role)
	self._roundManager:getRoundData():addHalo(heroInfo.fighterId, halo)

	return role

end

function BattleSchedule:_createMonster(battleFieldPosition, monsterInfo)

	local monster = Monster:create(BattleType.STRIKER, monsterInfo.baseId)
	monster:setFighterId(monsterInfo.fighterId)
	monster:setBattleFieldPosition(battleFieldPosition)
	monster:setPhaseIndex(self._bm:getWaveIndex())
	self._entityManage:registerEntity(monster:getEntityID(), monster)
	
	monster:setIsRole(false)
	
	--设置怪物属性值
	monster:setAttackBaseArgs()

	if monsterInfo.hp then
		monster:setCurrentHp(monsterInfo.hp, false, true)
	end

	--光环
	local halo = PassiveSkillManager:getInstance():generate20021(monster)
	self._roundManager:getRoundData():addHalo(monsterInfo.fighterId, halo)
	
	return monster

end

function BattleSchedule:_createGuard(camp, position, guardInfo)

	local guard = BattleGuard:create(camp, guardInfo)
	guard:setFighterId(guardInfo.fighterId)
	-- guard:setBaseAttr(guardInfo.attrs)
	guard:setBaseAttrData(guardInfo:getEncryptAttrData())
	guard:setBattleFieldPosition(position)
	guard:setPhaseIndex(self._bm:getWaveIndex())
	self._entityManage:registerEntity(guard:getEntityID(), guard)

	guard:setIsRole(false)

	-- guard:setCurrentHp(guardInfo.attrData:getData("hp"))
	guard:setCurrentHp(
		guardInfo:getEncryptAttrData():getAttr(AttrHelper.attr_flag.hp)
	)

	--光环
	local halo = PassiveSkillManager:getInstance():generate20021(guard)
	self._roundManager:getRoundData():addHalo(guardInfo.fighterId, halo)

	return guard

end

function BattleSchedule:_createAndStartScene()

	self._battleScene = CCScene:create()
    
    self._battleScene:addChild(self._renderLayer)

	CCDirector:sharedDirector():replaceScene(self._battleScene)
end

function BattleSchedule:terminateBattle()

	self:uninit()
	
	--CCDirector:sharedDirector():popScene()
	self._battleScene = nil
end