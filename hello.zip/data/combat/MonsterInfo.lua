--
-- Author: lvgansheng
-- Date: 2014-07-18 16:52:12
-- 单个怪物数据类

MonsterInfo = class("MonsterInfo")

MonsterInfo.base_id = 0 
MonsterInfo.lev = 0 
MonsterInfo.animat_res_id = 0 -- 动作资源ID
MonsterInfo.icon_res_id = 0 --头像资源ID
MonsterInfo.img_res_id = 0 --原画资源ID
MonsterInfo.name = "怪物名稱"
MonsterInfo.monsterType = 1  --怪物类型
MonsterInfo.pos = 0 -- 站位类型
MonsterInfo.race = 0 -- 怪物种族
MonsterInfo.atk_type = 0 -- 怪物攻击方式
MonsterInfo.default_skills = nil --默认技能
MonsterInfo.pas_skills = nil --默认技能
MonsterInfo._pasSkillDataList = nil --被动技能列表
MonsterInfo.atk_actions = nil --攻击动作列表
MonsterInfo.dead_audio_id = 0 --死亡音效
MonsterInfo.despot_effect = 0 --霸气特效
MonsterInfo.desc = nil --怪物描述


function MonsterInfo:ctor()
	self.default_skills = {}
	self.pas_skills = {}
	self.atk_actions = {}
	self._pasSkillDataList = {}
end

function MonsterInfo:setBaseData(base_id, lev, animat_res_id, icon_res_id, img_res_id, name, monsterType, pos, race, atk_type)
	self.base_id = base_id
	self.lev = lev
	self.animat_res_id = animat_res_id
	self.icon_res_id = icon_res_id
	self.img_res_id = img_res_id
	self.name = name
	self.monsterType = monsterType
	self.pos = pos
	self.race = race
	self.atk_type = atk_type
end

--设置怪物默认的技能,暂时用不着，先存着
function MonsterInfo:setDefaultSkill(act_skill1, act_skill2, act_skill3, pas_skill1, pas_skill2, pas_skill3)
	table.insert(self.default_skills,act_skill1)
	table.insert(self.default_skills,act_skill2)
	table.insert(self.default_skills,act_skill3)
	table.insert(self.pas_skills,pas_skill1)
	table.insert(self.pas_skills,pas_skill2)
	table.insert(self.pas_skills,pas_skill3)

	local skillInfo = nil
	for i, v in ipairs(self.pas_skills) do
		skillInfo = MonsterSkillInfo:create()
		skillInfo:setData(v, 1)

		self._pasSkillDataList[i] = skillInfo
	end

end

--设置怪物技能对应的动作
function MonsterInfo:setAtkAction(action1, action2, action3)

	table.insert(self.atk_actions, action1)
	table.insert(self.atk_actions, action2)
	table.insert(self.atk_actions, action3)
end

--[[
    获取当前等级
]]
function MonsterInfo:getCurLevel()
	return self.lev
end

--[[
    获取被动技能数据列表
]]
function MonsterInfo:getPasSkillDataList()
	return self._pasSkillDataList
end

function MonsterInfo:setModelId(value)
	self.animat_res_id = value
end

function MonsterInfo:getModelId()
	return self.animat_res_id
end



MonsterSkillInfo = class("MonsterSkillInfo")

MonsterSkillInfo.skill_id = 0 --技能id
MonsterSkillInfo.skill_lev = 0 --技能等级
MonsterSkillInfo.is_open = false

function MonsterSkillInfo:setData(skill_id, skill_lev)
	self.skill_id = skill_id
	self.skill_lev = skill_lev
	if skill_lev > 0 then
		self.is_open = true
	else
		self.is_open = false
	end
end

function MonsterSkillInfo:getSkillId()
	return self.skill_id
end

function MonsterSkillInfo:getSkillLevel()
	return self.skill_lev
end

function MonsterSkillInfo:isOpen()
	return self.is_open
end

function MonsterSkillInfo:create()
	local skill_info = MonsterSkillInfo.new()
	return skill_info
end