--
-- Author: thisgf
-- Date: 2014-12-12 10:29:26
-- 播报回合管理

ReportRoundManager = class("ReportRoundManager")

ReportRoundManager._bm = nil
ReportRoundManager._rm = nil
ReportRoundManager._reportData = nil
ReportRoundManager._entityManager = nil

ReportRoundManager._roundData = nil

ReportRoundManager._onEntityDeadFunc = nil

--回合结束前需要处理的角色列表
ReportRoundManager._needHandleRoleList = nil

--播报攻击者列表
ReportRoundManager._broadcastAttackerDict = nil
--播报目标者列表
ReportRoundManager._broadcastTargetDict = nil

--回合更新监听
ReportRoundManager._onUpdateRoundFunc = nil

ReportRoundManager._attackerActionIndex = 0
ReportRoundManager._attackerActionData = nil

ReportRoundManager._waveIndex = 0
ReportRoundManager._roundIndex = 0

function ReportRoundManager:ctor()
end

function ReportRoundManager:init()

    self._bm = BattleManager:getInstance()
    self._rm = BattleReportManager:getInstance()

    self._entityManager = EntityManager:getInstance()

    self._reportData = self._bm:getReportData()

    self._roundData = RoundData:create()

    self._broadcastAttackerDict = {}
    self._broadcastTargetDict = {}

    self._onUpdateRoundFunc = function()
        self:_newRoundBegin()
    end

    self._onBroadcastFighterFunc = function(param)

        local bcType = param.bcType
        local entityId = param.entityId
        local attackerId

        local printInfo

        if bcType == BattleType.BROADCAST_ATTACKER then
            self._broadcastAttackerDict[entityId] = true
            attackerId = entityId

            printInfo = "攻擊者"

        else
            self._broadcastTargetDict[entityId] = true
            attackerId = param.attackerId

            printInfo = "目標者"

        end

        local targetGroup = self._roundData:getRoundAttackTargets(attackerId)

        local isAttackerEnd = true
        local isTargetEnd = true

        if not self._broadcastAttackerDict[attackerId] then
            isAttackerEnd = false
        end

        for i, v in ipairs(targetGroup.attackTargetGroup) do
            if not self._broadcastTargetDict[v] then
                isTargetEnd = false
                break
            end
        end

        cclog("//////////////////////%s 播報完成:%d", printInfo, entityId)

        if isAttackerEnd and isTargetEnd then
            self:_broadcastComplete()
        end

    end

    self._onEntityDeadFunc = function(entityId)
        self:_handleEntityDead(entityId)
    end

end

function ReportRoundManager:roundSchedule()

    cclog("觀戰回合開始")

    self:_scheduleUpdate()

    Notifier.regist(CmdName.BATTLE_UPDATE_ROUND, self._onUpdateRoundFunc)

    --回合正式开始
    self:_newRoundBegin()

end

--新回合开始
function ReportRoundManager:_newRoundBegin()

    self._waveIndex = self._bm:getWaveIndex()
    self._roundIndex = self._bm:getRoundIndex()

    self._roundData:clear()
    self._attackerActionIndex = 1
    self._entityManager:generateNewRoundData(self._roundData)

    self:_addFighterToUpdate()

    self:_setCampGemData()

    --更新回合
    self._roundData:updateRound(self._roundIndex)
    BattleController:getInstance():updateRound(self._roundIndex)

    local gemHpDict = self._reportData:getRoundGemHp(
        self._waveIndex, 
        self._roundIndex
    )

    --站立动作
    local entity
    for _, entityId in ipairs(self._roundData.attackerTeam) do
        entity = self._entityManager:getEntityWithID(entityId)
        entity:getStateMachine():changeState(FighterStandState:create(), true)

        -- if gemHp then
        --     BattleController:getInstance():updateEntityHp(entityId, gemHp)
        -- end
    end

    for _, entityId in ipairs(self._roundData.strikerTeam) do
        entity = self._entityManager:getEntityWithID(entityId)
        entity:getStateMachine():changeState(FighterStandState:create(), true)
    end

    if gemHpDict then
        for entityId, gemHp in pairs(gemHpDict) do
            BattleController:getInstance():updateEntityHp(entityId, gemHp)
        end
    end

    self:_newRoundAction()

end

--设置阵营宝石数据
function ReportRoundManager:_setCampGemData()

    local gemData = self._reportData:getGemData(
        self._waveIndex, 
        self._roundIndex, 
        BattleType.ATTACKER
    )
    self._roundData:setAllyGemColor(gemData.gemColor)

    gemData = self._reportData:getGemData(
        self._waveIndex,
        self._roundIndex,
        BattleType.STRIKER
    )
    self._roundData:setEnemyGemColor(gemData.gemColor)

    --播放光环
    BattleController:getInstance():playCampSkillHonor(BattleType.ATTACKER)
    BattleController:getInstance():playCampSkillHonor(BattleType.STRIKER)

end

function ReportRoundManager:_addFighterToUpdate()
    
    local updateList = self._roundData:getNSUEntityOrder()

    for _, entityId in ipairs(self._roundData:getAttackerTeam()) do
        updateList:push(entityId)
    end

    for _, entityId in ipairs(self._roundData:getStrikerTeam()) do
        updateList:push(entityId)
    end

end

function ReportRoundManager:_newRoundAction()

    self._broadcastAttackerDict = {}
    self._broadcastTargetDict = {}

    local attackerData = self._reportData:getAttackerData(
        self._waveIndex,
        self._roundIndex,
        self._attackerActionIndex
    )

    self._attackerActionData = attackerData

    if not attackerData then
        self:_finishOneRound()
        return
    end

    local attacker = self._entityManager:getEntityWithID(attackerData.id)

    local skillCfg = SkillManager:getInstance():getSkillDetailCfg(
        attackerData.skillId, 
        attackerData.skillLev, 
        3
    )

    local pas20022 = self._reportData:getPassiveSkill({
        attackerId = attacker:getEntityID(),
        scriptId = PassiveSkillScriptType.SCRIPT_TYPE_20022,
        entityId = attacker:getEntityID(),
        attackTimes = 1
    })

    if pas20022 then
        self.roundData:removeDominateBuff(attacker:getEntityID())
        BattleController:getInstance():playPasSkillEffect(
            attacker:getEntityID(), 
            PassiveSkillScriptType.SCRIPT_TYPE_20022
        )
    end

    --添加回合内技能配置
    self._roundData:addRoundAttackSkillData(attacker:getEntityID(), skillCfg)
    --添加目标
    self._roundData:addRoundAttackTarget(attacker:getEntityID(), attackerData.target)

    --播放奥义
    if attacker:getEntityType() == BattleType.ATTACKER then

        if self._roundData:getGemColor() == BattleStoneType.colorType.PURPLE then

            if self._roundData:isPlayUpanisad() == false then

                self._roundData:setPlayUpanisad(true)

                local function onUpanisadFunc()

                    self:_startBroadcast(attacker, skillCfg)
                end

                BattleController:getInstance():playUpanisadEffect(onUpanisadFunc)
                return
            end
        end
    end

    self:_startBroadcast(attacker, skillCfg)

end

function ReportRoundManager:_startBroadcast(attacker, skillData)

    print("/////////////////////////開始播報", attacker:getEntityID())
    Notifier.regist(CmdName.BATTLE_FIGHTER_BROADCAST_END, self._onBroadcastFighterFunc)

    if attacker:canUseSkill() == true then

        local isShowUpanisad = false
        if attacker:getEntityType() == BattleType.ATTACKER then
            if self._roundData:getGemColor() == BattleStoneType.colorType.PURPLE then
                isShowUpanisad = true
            end
        else
            if self._roundData:getEnemyGemColor() == BattleStoneType.colorType.PURPLE then
                isShowUpanisad = true
            end
        end

        if isShowUpanisad then
            BattleController:getInstance():showUpanisadShadow(true)

            local entityDict = self._entityManager:getEntityDict()

            local hurtGroup = self._roundData:getRoundAttackTargets(attacker:getEntityID())

            local suprtGroup = {}
            local suprtArgs = self._reportData:getPassiveSkill({
                attackerId = attacker:getEntityID(),
                attackTimes = 1,
                entityId = attacker:getEntityID(),
                scriptId = PassiveSkillScriptType.SCRIPT_TYPE_20009
            })

            if suprtArgs then
                suprtGroup = suprtArgs[3]
            end

            local isHas = false

            for entityId, _ in pairs(entityDict) do
                isHas = false
                if entityId == attacker:getEntityID() then
                    isHas = true
                else
                    for _, hurtId in ipairs(hurtGroup.attackTargetGroup) do
                        if hurtId == entityId then
                            isHas = true
                            break
                        end
                    end

                    for suprtId, _ in pairs(suprtGroup) do
                        if suprtId == entityId then
                            isHas = true
                            break
                        end
                    end
                end

                if isHas == false then
                    BattleController:getInstance():setFighterDownDepth(entityId)
                end
            end
        end
    end

    local newState = nil
    newState = FighterAttackLaunchState:create()
    
    local nextState
    local skillId = skillData.cfg._id
    if skillId == SkillDataCfg.FLEE then
        newState = FighterFleeState:create()
    elseif skillId == SkillDataCfg.DEFENSE then
        nextState = FighterDefenseState:create()
    elseif skillData.cfg._atkScriptId == SkillScriptType.DARTLE then
        nextState = FighterSkillDartleState:create()
    else
        nextState = FighterAttackState:create()
    end

    newState:setNextState(nextState)

    attacker:getStateMachine():changeState(newState, true)

end

function ReportRoundManager:_broadcastComplete()

    print("/////////////////////////播報完成")

    Notifier.remove(CmdName.BATTLE_FIGHTER_BROADCAST_END, self._onBroadcastFighterFunc)

    BattleController:getInstance():showUpanisadShadow(false)

    local allyTeam = self._entityManager:getAllyEntityDict()
    local enemyTeam = self._entityManager:getEnemyWaveEntityDict(self._bm:getWaveIndex())

    for entityId, _ in pairs(allyTeam) do
        BattleController:getInstance():resetFighterDepth(entityId)
    end

    for entityId, _ in pairs(enemyTeam) do
        BattleController:getInstance():resetFighterDepth(entityId)
    end

    --清除临时buff
    self._roundData:clearTempBuffDict()

    self._attackerActionIndex = self._attackerActionIndex + 1
    self:_newRoundAction()

end

function ReportRoundManager:_finishOneRound()

    self._needHandleRoleList = {}

    --处理回合buff结算
    self:_handleRoundBuffSettlement()

    --处理回合被动技能
    self:_handleRoundPasSkillSettlement()

    --结束阵营光环
    BattleController:getInstance():stopCampSkillHonor(BattleType.ATTACKER)
    BattleController:getInstance():stopCampSkillHonor(BattleType.STRIKER)

    BattleController:getInstance():showUpanisadShadow(false)

    local reviveList = self._roundData:getReviveEntityList()
    local reviveLen = #reviveList
    if reviveLen > 0 then
        local function reviveFunc(entityId)
            local entity = self._entityManager:getEntityWithID(entityId)
            entity:getStateMachine():changeState(FighterStandState:create(), true)
            self._roundData:removeReviveEntity(entityId)

            BattleStatisticManager:getInstance():setDead(entityId, nil)

            for i, v in ipairs(self._needHandleRoleList) do
                if v == entityId then
                    table.remove(self._needHandleRoleList, i)
                    break
                end
            end

            self:_handleBeforeRoundFinish()

        end

        for i, reviveArg in ipairs(reviveList) do
            
            table.insert(self._needHandleRoleList, reviveArg[1])

            BattleController:getInstance():playReviveAction(reviveArg[1], reviveFunc)
            self._entityManager:setEntityRevive(reviveArg[1])
            BattleController:getInstance():updateEntityHp(reviveArg[1], reviveArg[2])
        end
    end

    --结束回合前判断
    self:_handleBeforeRoundFinish()

end

function ReportRoundManager:_handleBeforeRoundFinish()

    if #self._needHandleRoleList > 0 then
        return
    end

    --本回合结束, 请求下一回合
    Notifier.dispatchCmd(CmdName.BATTLE_REQ_ROUND_END)

end


--[[
    处理回合buff的结算
]]
function ReportRoundManager:_handleRoundBuffSettlement()

    local buffDict = self._roundData.buffDict

    if not buffDict then
        return
    end

    local changeHpDict = {}

    for k, buffList in pairs(buffDict) do

        changeHpDict[k] = {}

        for i, buffData in ipairs(buffList) do

            if buffData.id == BuffType.KEEP_ADD_HP then
                table.insert(changeHpDict[k], 1, buffData.attrArg)
            elseif buffData.id == BuffType.POISONING then

                --增加毒伤害
                local isAddPoison = self._reportData:getPassiveSkill(
                    {
                        attackerId = buffData.attackerId, 
                        scriptId = PassiveSkillScriptType.SCRIPT_TYPE_20017
                    }
                )
                if isAddPoison then
                    buffData.attrArg = buffData.attrArg + isAddPoison
                end

                table.insert(changeHpDict[k], buffData.attrArg)
            elseif buffData.id == BuffType.KEEP_MINUS_HP or
                   buffData.id == BuffType.BURN then
               
                table.insert(changeHpDict[k], buffData.attrArg)
            end
        end
    end

    for k, v in pairs(changeHpDict) do

        for i, hp in ipairs(v) do
            local needHandle = BattleController:getInstance():updateEntityHp(
                k, 
                hp, 
                true, 
                self._onEntityDeadFunc, 
                false
            )
            if needHandle == true then
                table.insert(self._needHandleRoleList, k)
            end

        end
    end

end

--处理回合被动技能的结算
function ReportRoundManager:_handleRoundPasSkillSettlement()

    local psData20014 = self._reportData:getPassiveSkill({
        scriptId = PassiveSkillScriptType.SCRIPT_TYPE_20014
    })

    local psData20027 = self._reportData:getPassiveSkill({
        scriptId = PassiveSkillScriptType.SCRIPT_TYPE_20027
    })

    for i, v in ipairs(psData20014) do

        for _, entityId in pairs(v.targetList) do
            local needHandle = BattleController:getInstance():updateEntityHp(
                entityId, 
                v.hp, 
                true, 
                self._onEntityDeadFunc, 
                false
            )
            if needHandle == true then
                table.insert(self._needHandleRoleList, k)
            end
        end
    end

    for i, v in ipairs(psData20027) do

        for _, entityId in pairs(v.targetList) do
            local entity = EntityManager:getInstance():getEntityWithID(entityId)
            local needHandle = BattleController:getInstance():updateEntityHp(
                entityId, 
                entity:getTotalHp()*v.hpPercent, 
                true, 
                self._onEntityDeadFunc, 
                false
            )
            if needHandle == true then
                table.insert(self._needHandleRoleList, k)
            end
        end
    end

end

function ReportRoundManager:addBuffToEntity(entityId)
    self._roundData:addTempBuffToEntity(entityId)
end

--[[
    添加在死亡过程中的玩家
]]
function ReportRoundManager:addDeadProcessEntity(entityId)
    self._roundData:addDeadProcessEntity(entityId)
end

--[[
    移除在死亡过程中的玩家
]]
function ReportRoundManager:removeDeadProcessEntity(entityId)
    self._roundData:removeDeadProcessEntity(entityId)

    if #self._roundData:getDeadProcessList() == 0 then
        Notifier.dispatchCmd(CmdName.BATTLE_HANDLE_DEAD_PROCESS_END)
    end
end

--[[
    处理参战者死亡
]]
function ReportRoundManager:_handleEntityDead(entityId)

    for i, v in ipairs(self._needHandleRoleList) do
        if v == entityId then
            table.remove(self._needHandleRoleList, i)
            break
        end
    end

    self:_handleBeforeRoundFinish()

end

function ReportRoundManager:_scheduleUpdate()
    if self._scheduleFunc then
        return
    end
    
    local updateTick = function()
        self:_update()
    end
    self._scheduleFunc = CCDirector:sharedDirector():getScheduler():scheduleScriptFunc(updateTick, 0, false)
end

function ReportRoundManager:_unscheduleUpdate()
    if self._scheduleFunc == nil then
        return
    end
    CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(self._scheduleFunc)
    self._scheduleFunc = nil
end

--更新状态
function ReportRoundManager:_update()
    
    local updateList = self._roundData:getNSUEntityOrder()
    local totalSize = updateList.size
    for i = 1, totalSize do
        local entityId = updateList:at(i)
        local entityRole = self._entityManager:getEntityWithID(entityId)

        if entityRole then
            entityRole:update()
        end
    end

end

function ReportRoundManager:getRoundData()
    return self._roundData
end

--[[
    获取参战者使用的技能
]]
function ReportRoundManager:getEntitySkillIndex(entity)

    if self._attackerActionData and 
        self._attackerActionData.id == entity:getEntityID() then
        return self._attackerActionData.skillIndex
    end

    return 0
end

--[[
    获取攻击者的数据
]]
function ReportRoundManager:getAttackerActionData()
    return self._attackerActionData
end

function ReportRoundManager:uninit()
    
    self:_unscheduleUpdate()
    Notifier.remove(CmdName.BATTLE_UPDATE_ROUND, self._onUpdateRoundFunc)
    Notifier.remove(CmdName.BATTLE_FIGHTER_BROADCAST_END, self._onBroadcastFighterFunc)

end

function ReportRoundManager:create()

    local rm = ReportRoundManager.new()
    rm:init()
    return rm
end
