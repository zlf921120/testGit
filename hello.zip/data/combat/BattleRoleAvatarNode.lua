--
-- Author: thisgf
-- Date: 2014-07-24 14:27:30
-- 战斗角色头像节点

require "HeroHelper"
require "HeroIcon"

BattleRoleAvatarNode = class("BattleRoleAvatarNode", DisplayUtil.newWidget)

BattleRoleAvatarNode._hpProgress = nil
BattleRoleAvatarNode._heroIcon = nil
BattleRoleAvatarNode._buffNode = nil

function BattleRoleAvatarNode:ctor()
end

function BattleRoleAvatarNode:init()

	local avatarBgImage = ImageView:create()
	avatarBgImage:loadTexture("bui_hero_icon_slot.png", UI_TEX_TYPE_PLIST)
	self:addChild(avatarBgImage)

	self._heroIcon = HeroIcon:create()
	self._heroIcon:hideOtherElem()
	self._heroIcon:setScale(0.8)
	avatarBgImage:addChild(self._heroIcon)

	local bgSize = avatarBgImage:getSize()
	self:setSize(bgSize)

	local hpBgImage = ImageView:create()
	hpBgImage:loadTexture("bui_hp_slot.png", UI_TEX_TYPE_PLIST)
	self:addChild(hpBgImage)

	local hpBgSize = hpBgImage:getSize()
	hpBgImage:setPosition(ccp(0, -(bgSize.height * 0.5 + hpBgSize.height * 0.5 - 5)))

	self._hpProgress = BattleRoleAvatarHPNode:create()
	self._hpProgress:setPosition(ccp(-1, -0.5))
	self._hpProgress:setIsShowShield(false)
	hpBgImage:addNode(self._hpProgress)

	self._buffNode = CCNode:create()
	self:addNode(self._buffNode)

end

function BattleRoleAvatarNode:setHeroId(id)

	self._heroIcon:setHeroId(id)
end

function BattleRoleAvatarNode:setHeroInfo(heroInfo)
	self._heroIcon:setOtherHeroInfo(heroInfo)
end

--[[
    初始化血值
]]
function BattleRoleAvatarNode:initHp(hp, hpMax)

	self._hpProgress:initHp(hp, hpMax)
end

--[[
    设置血值
    @param hp
]]
function BattleRoleAvatarNode:setHp(hp)
	self._hpProgress:updateHp(hp)
end

function BattleRoleAvatarNode:initShieldHp(value)
	self._hpProgress:initShieldHp(value)
end

function BattleRoleAvatarNode:updateShieldHp(value)
	self._hpProgress:updateShieldHp(value)
end

function BattleRoleAvatarNode:getBuffNode()
	return self._buffNode
end

function BattleRoleAvatarNode:create()

	local avatarNode = BattleRoleAvatarNode.new()
	avatarNode:init()
	return avatarNode
end


--战斗角色血条显示
BattleRoleAvatarHPNode = class("BattleRoleAvatarHPNode", DisplayUtil.newNode)

BattleRoleAvatarHPNode._hp = 0
BattleRoleAvatarHPNode._hpMax = 0

BattleRoleAvatarHPNode._hpPercent = -1

BattleRoleAvatarHPNode._shieldHp = 0
BattleRoleAvatarHPNode._shieldHpMax = 0
BattleRoleAvatarHPNode._shieldHpPercent = -1

BattleRoleAvatarHPNode._isShieldTransition = false

BattleRoleAvatarHPNode._isShowShield = true

BattleRoleAvatarHPNode._skinName = ""

BattleRoleAvatarHPNode._normalContainer = nil
BattleRoleAvatarHPNode._shieldContainer = nil

BattleRoleAvatarHPNode._transitionProgress = nil
BattleRoleAvatarHPNode._hpProgress = nil

BattleRoleAvatarHPNode._shieldSlot = nil
BattleRoleAvatarHPNode._shieldHpProgress = nil

function BattleRoleAvatarHPNode:ctor()

	self:setAnchorPoint(ccp(0, 0.5))

	self._normalContainer = CCNode:create()
	self:addChild(self._normalContainer)

	self._shieldContainer = CCNode:create()
	self:addChild(self._shieldContainer)


	self._transitionProgress = CCSprite:createWithSpriteFrameName("bui_hp_transition.png")
	self._transitionProgress:setAnchorPoint(ccp(0, 0.5))
	self._transitionProgress:setVisible(false)
	self._transitionProgress:setPosition(ccp(-75*0.5, 0))
	self._normalContainer:addChild(self._transitionProgress)

	self._hpProgress = LoadingBar:create()
	self._hpProgress:setAnchorPoint(ccp(0, 0.5))
	self._normalContainer:addChild(self._hpProgress)

	self._shieldSlot = CCSprite:createWithSpriteFrameName("bui_hp_shield_slot.png")
	self._shieldSlot:setAnchorPoint(ccp(0, 0.5))
	self._shieldSlot:setPosition(ccp(-93*0.5, 20))
	self._shieldSlot:setVisible(false)
	self._shieldContainer:addChild(self._shieldSlot)

	self._shieldHpProgress = CCSprite:createWithSpriteFrameName("bui_hp_shield.png")
	self._shieldHpProgress:setAnchorPoint(ccp(0, 0.5))
	-- self._shieldHpProgress:setVisible(false)
	self._shieldHpProgress:setPosition(ccp(4, 8))
	self._shieldSlot:addChild(self._shieldHpProgress)

end

--[[
    初始化血值
]]
function BattleRoleAvatarHPNode:initHp(hp, hpMax)

	self._hp = hp
	self._hpMax = hpMax

	self:_setSkin()

	self._transitionProgress:setScaleX(self._hpPercent)

end

--[[
    更新当前血值
]]
function BattleRoleAvatarHPNode:updateHp(hp)

	if hp < 0 then
		hp = 0
	end

	if self._hp == hp then
		return
	end

	self._hp = hp

	self:_setSkin()

	self:_showTransition()

end

function BattleRoleAvatarHPNode:initShieldHp(value)
	self._shieldHp = value
	self._shieldHpMax = value

	if self._shieldHp == 0 then
		self._shieldSlot:setVisible(false)
	else
		if self._isShowShield == true then
			self._shieldSlot:setVisible(true)
		end
	end
	self._shieldHpProgress:setScaleX(1)

end

function BattleRoleAvatarHPNode:updateShieldHp(value)

	if value < 0 then
		value = 0
	end

	if self._shieldHp == value then
		return
	end

	self._shieldHp = value

	self._shieldHpPercent = self._shieldHp / self._shieldHpMax

	self:_showShieldTransition()

end

function BattleRoleAvatarHPNode:_setSkin()

	local percent = self._hp / self._hpMax

	if percent == self._hpPercent then
		return
	end

	self._hpPercent = percent

	local skinName = ""

	if self._hpPercent < 0.3 then
		skinName = "bui_hp_red.png"
	else
		skinName = "bui_hp_green.png"
	end

	if self._skinName ~= skinName then
		
		self._skinName = skinName
		self._hpProgress:loadTexture(self._skinName, UI_TEX_TYPE_PLIST)
		
	end

	self._hpProgress:setPercent(self._hpPercent * 100)

end

function BattleRoleAvatarHPNode:_showTransition()

	if self._isShieldTransition == true then
		return
	end

	local currentPercent = self._transitionProgress:getScaleX()

	if currentPercent <= self._hpPercent then
		self._transitionProgress:stopAllActions()
		self._transitionProgress:setScaleX(self._hpPercent)
		return
	end

	self._transitionProgress:stopAllActions()

	self._transitionProgress:setVisible(true)
	local delayAction = CCDelayTime:create(0.5)
	local actionArray = CCArray:create()
	local scaleAction = CCScaleTo:create(0.2, self._hpPercent, 1)
	local callFunc = CCCallFunc:create(function() 
			self._transitionProgress:setVisible(false)
		end)

	actionArray:addObject(delayAction)
	actionArray:addObject(scaleAction)
	actionArray:addObject(callFunc)

	self._transitionProgress:runAction(CCSequence:create(actionArray))

end

function BattleRoleAvatarHPNode:_showShieldTransition()

	if self._isShowShield == false then
		if self._shieldHpPercent <= 0 then
			self:_showTransition()
		end

		return
	end

	self._isShieldTransition = true

	self._shieldHpProgress:stopAllActions()

	self._shieldSlot:setVisible(true)
	local actionArray = CCArray:create()
	local scaleAction = CCScaleTo:create(0.2, self._shieldHpPercent, 1)
	local callFunc = CCCallFunc:create(function()
			self._isShieldTransition = false
			if self._shieldHpPercent <= 0 then
				self._shieldSlot:setVisible(false)
				self:_showTransition()
			end

		end)

	ActionManager:getInstance():runSequenceActions(self._shieldHpProgress, scaleAction, callFunc)

end

function BattleRoleAvatarHPNode:setIsShowShield(value)

	self._isShowShield = value

	if self._isShowShield == false then
		self._shieldSlot:setVisible(false)
	end

end

function BattleRoleAvatarHPNode:getIsShowShield()
	return self._isShowShield
end

--[[
    设置普通血条的显示
]]
function BattleRoleAvatarHPNode:setVisibleNormal(value)

	self._normalContainer:setVisible(value)
end

function BattleRoleAvatarHPNode:create()

	local hpNode = BattleRoleAvatarHPNode.new()
	return hpNode

end