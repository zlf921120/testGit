RoundData = class("RoundData")

function RoundData:create()
	local objRoundData = RoundData.new()	
	objRoundData:init()
	return objRoundData
end

function RoundData:init()

	self.attackerTeam = {}		--攻击方队伍成员
	self.strikerTeam = {}		--受击方队伍成员
	
	--是否己队先手
	self.selfTeamAttackFirst = true	
	
	--是否启动过宝石消除系统,默认没有启动过
	self.invokedGemClearSys = false
	
	--回合内需要状态更新的队员队列
	self.roundNeedStateUpdateEntityOrder = XQueue.create()

	--回合友方出手列表
	self._allyOrderList = {}
	--回合敌方出手列表
	self._enemyOrderList = {}
	
	--回合内攻击目标,回合内攻击目标到达数量
	self._roundAttackTargets = {}
	
	--回合内角色主动攻击技能配置数据
	self._roundAttackSkillData = {}
	
	--设置宝石数量和颜色
	self._gemColorData = nil
	
	--初始主动技能1
	self.gemColorSkillId = 1

	--参战者buff字典
	self.buffDict = {}

	--临时buff字典
	self._tempBuffDict = {}

	--敌人的ai
	self._aiData = nil

	--参战者被动技能字典
	self._passiveSkillDict = {}

	--阵营光环ID
	self._campHonorDict = {}

	self._isPlayUpanisad = false

	self._allyGemColor = -1
	self._enemyGemColor = -1

	self._deadProcessEntityList = {}

	self._reviveEntityList = {}

	--当前行动者
	self._currentActionId = 0


	--光环字典
	self._entityHaloDict = {}

end

function RoundData:uninit()
	self:clear()
	
	self.buffDict = nil

	self._deadProcessEntityList = nil

	self._reviveEntityList = nil

	self._entityHaloDict = nil

end

function RoundData:clear()

	self.attackerTeam = {}	
	self.strikerTeam = {}
	self.selfTeamAttackFirst = true
	self.invokedGemClearSys = false

	self.roundNeedStateUpdateEntityOrder:clear()
	
	self._roundAttackSkillData = {}

	self._roundAttackTargets = {}
	self._gemColorData = {}
	self.gemColorSkillId = -1

	self._aiData = nil
	self._passiveSkillDict = {}

	self._tempBuffDict = nil

	self._campHonorDict = {}

	self._isPlayUpanisad = false

	self._allyGemColor = -1
	self._enemyGemColor = -1

	--当前行动者
	self._currentActionId = 0

end

function RoundData:pushAttackerTeam(entityId)
	table.insert(self.attackerTeam, entityId)
end

function RoundData:getAttackerTeam()
	return self.attackerTeam
end

function RoundData:pushStrikerTeam(entityId)
	table.insert(self.strikerTeam, entityId)	
end

function RoundData:getStrikerTeam()
	return self.strikerTeam
end

function RoundData:getNSUEntityOrder()
	return self.roundNeedStateUpdateEntityOrder
end

function RoundData:hasInvokedGemSys()
	return self.invokedGemClearSys
end

function RoundData:setInvokedGemSys(argGemClearSys)
	--设置宝石数量和颜色
	self._gemColorData = clone(argGemClearSys)
	self._allyGemColor = self._gemColorData.gemColor

	self.gemColorSkillId = BattleStoneType.forSkillType[argGemClearSys.gemColor]
	
	self.invokedGemClearSys = true
end

function RoundData:setAllyGemColor(value)
	self._allyGemColor = value
end

--获得宝石颜色
function RoundData:getGemColor()
	return self._allyGemColor
end

--获得宝石消除数量
function RoundData:getGemNum()
	return self._gemColorData.gemNums
end


function RoundData:getRoundAttackTargets(curEntId)
	local keyIndex = self:_getHurtKey(curEntId)
	return self._roundAttackTargets[keyIndex]
end

function RoundData:addRoundAttackTarget(attackerEntId, targetGroup)
	local keyIndex = self:_getHurtKey(attackerEntId)
	self._roundAttackTargets[keyIndex] = targetGroup
end

function RoundData:_getHurtKey(attackId)
	return string.format("hurt%d", attackId)
end

function RoundData:getRoundAttackSkillData(curEntId)
	local keyIndex = string.format("SkillData%d", curEntId)
	return self._roundAttackSkillData[keyIndex]
end

function RoundData:addRoundAttackSkillData(attackerEntId, skillData)
	local keyIndex = string.format("SkillData%d", attackerEntId)
	self._roundAttackSkillData[keyIndex] = skillData
end

--[[
    添加buff字典
]]
function RoundData:addBuffDict(buffDict)
	for entityId, buffList in pairs(buffDict) do
		self:addBuff(entityId, buffList)
	end
end

--[[
    添加buff
    @param entityId
    @param buffList
    @param curRound 当前回合
]]
function RoundData:addBuff(entityId, buffList, curRound)

	local curRound = BattleManager:getInstance():getRoundIndex()

	local entity = EntityManager:getInstance():getEntityWithID(entityId)
	local curBuffList = self.buffDict[entityId]

	--免疫debuff被动技能
	local isImmuneDebuff = self:getPassiveSkillWithScript(entityId, SkillScriptType.SCRIPT_TYPE_20016)
	if isImmuneDebuff then
		local i = 1
		while i <= #buffList do
			local buffData = buffList[i]
			if buffData.nature == BuffNatureType.MALIGNANT then
				table.remove(buffList, i)
			else
				i = i + 1
			end
		end
	end

	--免疫debuff的buff
	local immuneBuff = self:getOneBuff(entityId, BuffType.ADD_IMMUNITY)
	if immuneBuff then
		local i = 1
		while i <= #buffList do
			local buffData = buffList[i]
			if BuffType.prohibitUseSkill[buffData.id] then
				table.remove(buffList, i)
			else
				i = i + 1
			end
		end
	end

	local newBuffList = {}

	if not curBuffList then
		curBuffList = {}
		self.buffDict[entityId] = curBuffList
		newBuffList = buffList
	else

		local has = false

		for i, v in ipairs(buffList) do

			has = false
			for i1, v1 in ipairs(curBuffList) do

				if v1.id == v.id then

					--相同ID判断, 先判断数值类型, 如果是叠加的看回合数,
					--然后拿最大的回合和相加的数值
					--绝对值的数值类型先判断数值大小, 然后看回合数
					--没有数值的看回合

					if v.argType == BuffArgType.VALUE or 
						v.argType == BuffArgType.PERCENT then

						--属性值叠加
						if v.impactValueType == BuffType.impactType.OVERLAY then
							v1.attrArg = v1.attrArg + v.attrArg
							local totalArg = v1.attrArg + v.attrArg
							if curRound - v1.currentRound < v.round then
								v.currentRound = curRound
								v.attrArg = totalArg
								curBuffList[i1] = v
							else
								v1.currentRound = curRound
								v1.attrArg = totalArg
							end
						else

							--判断属性值, 如果超过原来的buff则替换
							if math.abs(v.attrArg) > math.abs(v1.attrArg) then
								curBuffList[i1] = v
							elseif math.abs(v.attrArg) == math.abs(v1.attrArg) then
								if curRound - v1.currentRound < v.round then
									-- v1.currentRound = curRound
									v.currentRound = curRound
									curBuffList[i1] = v
								end
							end
						end

					else
						--剩余回合数
						if curRound - v1.currentRound < v.round then
							-- v1.currentRound = curRound
							v.currentRound = curRound
							curBuffList[i1] = v
						end
					end

					--更新嘲讽目标
					if v.id == BuffType.TAUNT then
						entity:setForceAttackTarget(v.attackerId)
					--护盾
					elseif v.id == BuffType.ADD_SHIELD then
						if v.attrArg > entity:getCurrentShieldHp() then
							entity:setShieldHp(v.attrArg)
						end
					end

					has = true

					break
				end
			end

			if has == false then
				newBuffList[#newBuffList + 1] = v
			end

		end
		
	end

	for i, v in ipairs(newBuffList) do

		table.insert(curBuffList, v)

		v.currentRound = curRound

		--嘲讽
		if v.id == BuffType.TAUNT then
			entity:setForceAttackTarget(v.attackerId)
		--护盾
		elseif v.id == BuffType.ADD_SHIELD then
			entity:setShieldHp(v.attrArg)
			entity:showHpBar()
		--变羊
		elseif v.id == BuffType.DEFORM then
			entity:getRenderNode():deformation()
		end

		if v.effectIds then
			for i, effectId in ipairs(v.effectIds) do
				local effectData = EffectManager:getInstance():getEffectData(effectId)

				local container
				if effectData:getHierarchy() == EffectHierarchyType.BOTTOM then
					container = entity:getRenderNode():getBottomBuffEffectContainer()
				else
					container = entity:getRenderNode():getBuffEffectContainer()
				end

				local effect = EffectManager:getInstance():playEffect(
					container, 
					effectId, 
					nil, 
					0, 
					true
				)

				BattleController:getInstance():setEffectDirection(effect, entityId)

			end
		end

		if v.avatarEffectId ~= 0 then

			if entity:isRole() and entity:getAvatarNode() then

				EffectManager:getInstance():playEffect(
					entity:getAvatarNode():getBuffNode(), 
					v.avatarEffectId, 
					nil, 
					0, 
					false
				)
			end

		end

	end

end

--[[
    移除buff
    @param entityId
    @param buffId
]]
function RoundData:removeBuff(entityId, buffId)

	local buffList = self.buffDict[entityId]
	if not buffList then
		return
	end

	local entity = EntityManager:getInstance():getEntityWithID(entityId)

	for i, buffData in ipairs(buffList) do
		if buffData.id == buffId then

			self:_deleteBuff(buffData, entity)

			table.remove(buffList, i)

			break
		end
	end

	if #buffList == 0 then
		self.buffDict[entityId] = nil
	end

end

--[[
    移除控制buff
    @param entityId 参战者ID
]]
function RoundData:removeDominateBuff(entityId)

	local buffList = self.buffDict[entityId]
	if not buffList then
		return
	end

	local entity = EntityManager:getInstance():getEntityWithID(entityId)

	local i = 1
	while i <= #buffList do
		local buffData = buffList[i]
		if BuffType.prohibitAction[buffData.id] then
			
			self:_deleteBuff(buffData, entity)

			table.remove(buffList, i)
		else
			i = i + 1
		end
	end

	if #buffList == 0 then
		self.buffDict[entityId] = nil
	end

end

function RoundData:_deleteBuff(buffData, entity)

	--嘲讽
	if buffData.id == BuffType.TAUNT then
		entity:setForceAttackTarget(nil)
	--护盾
	elseif buffData.id == BuffType.ADD_SHIELD then
		entity:setShieldHp(0)
	--变羊
	elseif buffData.id == BuffType.DEFORM then
		entity:getRenderNode():undeformation()
	end

	
	if buffData.effectIds then
		for i, effectId in ipairs(buffData.effectIds) do
			local effectData = EffectManager:getInstance():getEffectData(effectId)

			local container
			if effectData:getHierarchy() == EffectHierarchyType.BOTTOM then
				container = entity:getRenderNode():getBottomBuffEffectContainer()
			else
				container = entity:getRenderNode():getBuffEffectContainer()
			end

			EffectManager:getInstance():removeEffect(
				container, 
				effectId
			)

		end
	end

	if buffData.avatarEffectId ~= 0 then

		if entity:isRole() and entity:getAvatarNode() then

			EffectManager:getInstance():removeEffect(
				entity:getAvatarNode():getBuffNode(), 
				buffData.avatarEffectId
			)
		end

	end

end

--[[
    更新回合数
    @param round
]]
function RoundData:updateRound(round)

	local buffData

	for k, v in pairs(self.buffDict) do

		local entity = EntityManager:getInstance():getEntityWithID(k)

		local i = 1
		while i <= #v do
			buffData = v[i]

			if round - buffData.currentRound < buffData.round then

				i = i + 1
			else

				table.remove(v, i)

				self:_deleteBuff(buffData, entity)

			end
		end
	end

end

--[[
    清除参战者buff
    @param entityId 参战者Id
    @param buffNatureType buff性质类型 (0:所有, 1:良性, 2:恶性)
]]
function RoundData:clearEntityBuff(entityId, buffNatureType)

	buffNatureType = buffNatureType or BuffNatureType.ALL

	local entity = EntityManager:getInstance():getEntityWithID(entityId)

	local buffList = self.buffDict[entityId]

	if not buffList then
		return
	end

	local buffData

	local i = 1
	while i <= #buffList do

		buffData = buffList[i]

		if buffNatureType == BuffNatureType.ALL or buffData.nature == buffNatureType then

			table.remove(buffList, i)

			self:_deleteBuff(buffData, entity)

		else
			i = i + 1
		end
	end

	if #buffList == 0 then
		self.buffDict[entityId] = nil
	end

end

--[[
    获取buff
    @param 参战者Id
    @return {BuffEffectVO, ...}
]]
function RoundData:getBuff(entityId)

	if not self.buffDict then
		return nil
	end

	return self.buffDict[entityId]
end

--[[
    获取一个buff
]]
function RoundData:getOneBuff(entityId, buffId)

	local buffList = self:getBuff(entityId)
	if not buffList then
		return nil
	end

	for i, v in ipairs(buffList) do
		if v.id == buffId then
			return v
		end
	end

	return nil

end

function RoundData:setEnemyGemColor(value)
	self._enemyGemColor = value
end

--生成每回合敌人的技能列表
function RoundData:generateEnemySkill()

	self._aiData = AIManager:getInstance():generateEnemyAI()

	self._enemyGemColor = AIConfigType.skillIndex[self._aiData.behavior]

end

--[[
    获取敌人的技能ID
]]
function RoundData:getEnemySkill(entityId)

	local entity = EntityManager:getInstance():getEntityWithID(entityId)
	local skillList

	skillList = entity:getBaseInfo().default_skills

	local skillId = 0
	local skillLevel = 1

	if not skillList then
		print("==========ai獲取技能時沒有發現此資料:", entityId)
		return skillId
	end

	if self._aiData.behaviorType == AIConfigType.USE_SKILL then

		if entity:isRole() then
			local skillInfo = skillList[self._enemyGemColor]
			skillId = skillInfo:getSkillId()
			skillLevel = skillInfo:getSkillLevel()
		else
			skillId = skillList[self._enemyGemColor]
		end

	else
		print("=========這個ai不是產生怪物技能")
	end

	return skillId, skillLevel

end

function RoundData:setBuffAtkAttr(entityId, atkBaseArgs, atkFinalWithBuffArgs)
	local buffList = self:getBuff(entityId)

	BuffManager:getInstance():calcBuffAttr(buffList, atkBaseArgs, atkFinalWithBuffArgs)

	--最终伤害 = 伤害值*(1-敌人增加的伤害豁免)*(1-敌人减少的伤害豁免)	
end

--添加被动技能
function RoundData:addPassiveSkill(entityId, psList)

	self._passiveSkillDict[entityId] = psList

	-- print("==================添加被動技能", entityId)
	-- for k, v in ipairs(psList) do
	-- 	print(v[1], v[2])
	-- end
	-- print("===================")

end

--清除被动技能
function RoundData:clearPassiveSkill(entityId)

	self._passiveSkillDict[entityId] = nil
end

function RoundData:getPassiveSkillDict()
	return self._passiveSkillDict
end

--获取被动技能列表
function RoundData:getPassiveSkillList(entityId)

	return self._passiveSkillDict[entityId]
end

--[[
    根据脚本获取被动技能
]]
function RoundData:getPassiveSkillWithScript(entityId, scriptId)

	local psList = self._passiveSkillDict[entityId]
	if not psList then
		return nil
	end

	for i, v in ipairs(psList) do
		if v[2] == scriptId then
			return v
		end
	end

	return nil

end

--[[
    设置被动技能影响的属性
    @param entityId 参战者ID
    @param atkBaseArgs 基础属性
]]
function RoundData:setPassiveSkillAttr(entityId, atkBaseArgs)

	local psList = self._passiveSkillDict[entityId]
	if not psList then
		return
	end

	local scriptId = 0

	for i, v in ipairs(psList) do

		scriptId = v[2]

		if scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20000 or 
		   scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20001 then

			if atkBaseArgs[v[3]] then

				atkBaseArgs[v[3]] = atkBaseArgs[v[3]] + atkBaseArgs[v[3]] * v[4]
			end

		elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20012 then

			local attrList

			for i = 3, #v do

				attrList = v[i]

				if atkBaseArgs[attrList[1]] then

					atkBaseArgs[attrList[1]] = atkBaseArgs[attrList[1]] + attrList[2]
				end
			end

		end
	end

end

--[[
    计算发起者的被动技能对目标的额外数值
    @param atkerId 攻击者ID
    @param strikerId 受击者ID
    @param rawNumber 原数值
    @param numberType 数值类型(1=受伤/2=治疗)
    @return 新数值
]]
function RoundData:calcAtkPassiveSkillForStrike(atkerId, strikerId, rawNumber, numberType)

	local psList = self._passiveSkillDict[atkerId]
	if not psList then
		return rawNumber
	end

	local scriptId = 0

	local match = false

	for i, v in ipairs(psList) do

		scriptId = v[2]

		match = false

		if numberType == 1 then
			if scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20003 or 
			   scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20005 or
			   scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20013 then
			       match = true
			end
		elseif numberType == 2 then
			if scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20006 or 
			   scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20008 then
			       match = true
			end
		end

		if match == true then

		    local strikerDict = v[3]
	 
	 	    for entityId, striker in pairs(strikerDict) do
	 
	 	        if entityId == strikerId then
	 
 	        	    if scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20006 then
 
 	        	        rawNumber = rawNumber + striker:getTotalHp() * v[4]

 	        	    elseif scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20013 then
 	        	    	if v[4] == BattleType.numberType.VALUE then
	 	        	        rawNumber = rawNumber + v[5]
	 	        	    else
	 	        	        rawNumber = rawNumber + rawNumber * v[5]
 	        	    	end
 	        	    else
 
	 		            rawNumber = rawNumber + rawNumber * v[4]
 	        	    end
	 
		            break
		        end
		    end
		end

	end

	return rawNumber

end

--[[
    计算受击者的被动技能
    @param
    @param
    @param numberType 数值类型(1=受伤/2=治疗)
    @return 受击者的新数值 可能有攻击者的数值
]]
function RoundData:calcPassiveSkillStrike(entityId, rawNumber, numberType)

	local psList = self._passiveSkillDict[entityId]
	if not psList then
		return rawNumber
	end

	local atkHurtNumber = 0
	local damagePercent

	local scriptId = 0

	for i, v in ipairs(psList) do

		scriptId = v[2]
		damagePercent = v[3]

		--受到近程攻击反弹
		if numberType == 1 and scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20002 then

			-- print("//////////////////////////傷害數值", rawNumber)

			atkHurtNumber = rawNumber * damagePercent
			-- print("//////////////////////////反彈傷害", atkHurtNumber)

		--受到治疗时，额外恢复治疗量万分比
		elseif numberType == 2 and scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20007 then

			rawNumber = rawNumber + rawNumber * damagePercent
		end
	end

	if atkHurtNumber ~= 0 then
		return rawNumber, atkHurtNumber
	else
		return rawNumber
	end

end

--[[
    计算被动技能产生的buff
]]
function RoundData:calcPassiveSkillBuff(entityId)
	
	local psList = self._passiveSkillDict[entityId]
	if not psList then
		return
	end

	local scriptId = 0
	local buffDict = nil

	for i, v in ipairs(psList) do
		
		scriptId = v[2]

		if scriptId == PassiveSkillScriptType.SCRIPT_TYPE_20011 then

			buffDict = v[3]
			self:addTempBuffDict(buffDict)
		end

	end

end

--[[
    计算光环
]]
function RoundData:calcHaloAttr(entityId, baseAttr)

	for fid, haloData in pairs(self._entityHaloDict) do

		local entity = EntityManager:getInstance():getEntityWithID(fid)
		if entity then
			local targetList = EntityManager:getInstance():getTargetList(
				haloData[1], 
				entity:getEntityType()
			)

			local hitTargetDict

			if targetList then

				local params = {}
				params.targetType = haloData[1]
				params.numTarget = 6
				params.targetList = targetList
				params.attackerId = entity:getEntityID()
				hitTargetDict = PassiveSkillManager:getInstance():validTarget(params)

				for k, _ in pairs(hitTargetDict) do
					if k == entityId then
						baseAttr[haloData[2]] = baseAttr[haloData[2]] + haloData[3]
						break
					end
				end
			end
		end
		
	end

end

--[[
    添加临时buff
]]
function RoundData:addTempBuffDict(buffDict)

	if not self._tempBuffDict then
		self._tempBuffDict = {}
	end

	local hasList

	for entityId, buffList in pairs(buffDict) do

		hasList = self._tempBuffDict[entityId]

		if hasList then

			for _, buffData in ipairs(buffList) do
				table.insert(hasList, buffData)
			end
		else
			self._tempBuffDict[entityId] = buffList
		end
	end

	-- self._tempBuffDict = buffDict

end

--[[
    获取临时buff
]]
function RoundData:getTempBuff(entityId)

	if not self._tempBuffDict then
		return nil
	end

	return self._tempBuffDict[entityId]

end

--[[
    清除临时buff
]]
function RoundData:clearTempBuffDict()
	self._tempBuffDict = nil
end

function RoundData:getTempBuffDict()
	return self._tempBuffDict
end

--[[
    添加临时buff到参战者
]]
function RoundData:addTempBuffToEntity(entityId)

	local buffList = self:getTempBuff(entityId)

	if not buffList then
		return
	end

	self:addBuff(entityId, buffList)

end

--设置技能光环
function RoundData:setSkillHonor(camp, value)
	self._campHonorDict[camp] = value
end

function RoundData:getSkillHonor(camp)
	return self._campHonorDict[camp]
end

--[[
    设置是否播放过奥义特效
]]
function RoundData:setPlayUpanisad(value)
	self._isPlayUpanisad = value
end

function RoundData:isPlayUpanisad()
	return self._isPlayUpanisad
end

function RoundData:getAIData()
	return self._aiData
end

--[[
    获取敌人选择的石头颜色
]]
function RoundData:getEnemyGemColor()
	return self._enemyGemColor
end

function RoundData:setAllyAttackOrder(value)
	self._allyOrderList = value
end

function RoundData:setEnemyAttackOrder(value)
	self._enemyOrderList = value
end

--[[
    获取并删除当前出手参战者
]]
function RoundData:popCurrentAttackFighter(campType)

	if campType == BattleType.ATTACKER then
		return table.remove(self._allyOrderList)
	end
	
	return table.remove(self._enemyOrderList)

end

function RoundData:addDeadProcessEntity(entityId)
	for i, v in ipairs(self._deadProcessEntityList) do
		if v == entityId then
			return
		end
	end
	table.insert(self._deadProcessEntityList, entityId)
end

function RoundData:removeDeadProcessEntity(entityId)
	for i, v in ipairs(self._deadProcessEntityList) do
		if v == entityId then
			table.remove(self._deadProcessEntityList, i)
			break
		end
	end
end

function RoundData:getDeadProcessList()
	return self._deadProcessEntityList
end

--[[
	添加复活的参战者
    @param entityId
    @param reviveHp
]]
function RoundData:addReviveEntity(entityId, reviveHp)
	table.insert(self._reviveEntityList, {entityId, reviveHp})
end

function RoundData:removeReviveEntity(entityId)
	for i, v in ipairs(self._reviveEntityList) do
		if v[1] == entityId then
			table.remove(self._reviveEntityList, i)
			break
		end
	end
end

function RoundData:getReviveEntityList()
	return self._reviveEntityList
end

--[[
    是否复活中
]]
function RoundData:isReviveEntity(entityId)
	for _, reviveData in ipairs(self._reviveEntityList) do
		if reviveData[1] == entityId then
			return true
		end
	end

	return false
end

function RoundData:setCurrentActionId(value)
	self._currentActionId = value
end

function RoundData:getCurrentActionId()
	return self._currentActionId
end

function RoundData:addHalo(entityId, targetParam)
	if not targetParam then
		return
	end
	self._entityHaloDict[entityId] = targetParam
end

function RoundData:removeHalo(entityId)
	self._entityHaloDict[entityId] = nil
end

--[[
    获取光环字典
]]
function RoundData:getHaloDict()
	return self._entityHaloDict
end