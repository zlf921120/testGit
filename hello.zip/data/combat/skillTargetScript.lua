SkillTargetScript = {}

--[[
    根据目标数量获取随机目标列表
]]
local function getSkillRandomTarget(rawTargetList, targetNumber)

	if rawTargetList == nil then
		return nil
	end

	if targetNumber >= #rawTargetList then
		return rawTargetList
	end

	MathUtil.shuffleList(rawTargetList)

	local randomList = {}

	for i = 1, targetNumber do
		randomList[i] = rawTargetList[i]
	end

	return randomList

end

--取前排目标
local function skillTargetFront(team, atkTargetList)
	for k, v in ipairs(team) do
		local ent = EntityManager:getInstance():getEntityWithID(v)
		local position = ent:getBattleFieldPosition()
		if position == BattlePosType.FRONT_1 or position == BattlePosType.FRONT_2 then
			table.insert(atkTargetList, v)
		end
	end	
end

--取中排目标
local function skillTargetMiddle(team, atkTargetList)
	for k, v in ipairs(team) do
		local ent = EntityManager:getInstance():getEntityWithID(v)
		local position = ent:getBattleFieldPosition()
		if position == BattlePosType.MIDDLE_1 or position == BattlePosType.MIDDLE_2 then
		    table.insert(atkTargetList, v)
		end
	end
end

--取后排目标
local function skillTargetEnd(team, atkTargetList)
	for k, v in ipairs(team) do
		local ent = EntityManager:getInstance():getEntityWithID(v)
		local position = ent:getBattleFieldPosition()
		if position == BattlePosType.BACK_1 or position == BattlePosType.BACK_2 then
			table.insert(atkTargetList, v)
		end
	end	
end

local function skillTargetScript_0(params)      --敌方前排  
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--遍历敌方前排
	if entTypeId == BattleType.ATTACKER then
		targetTeam = rightTeam
	else
		targetTeam = leftTeam
	end
	
	local atkTargetList = {}
	--取前排
	skillTargetFront(targetTeam, atkTargetList)
	--如果前排没有取中排攻击目标
	if #atkTargetList == 0 then
		skillTargetMiddle(targetTeam, atkTargetList)
	end
	
	--如果中排都没有目标取后排
	if #atkTargetList == 0 then
		skillTargetEnd(targetTeam, atkTargetList)
	end
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end
	
	return atkTargetList
end	
 
local function skillTargetScript_1(params)      --敌方中排     
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--遍历敌方前排
	if entTypeId == BattleType.ATTACKER then
		targetTeam = rightTeam
	else
		targetTeam = leftTeam
	end
	
	local atkTargetList = {}
	--取中排	
	skillTargetMiddle(targetTeam, atkTargetList)	
	
	--如果中排都没有目标取后排
	if #atkTargetList == 0 then
		skillTargetEnd(targetTeam, atkTargetList)
	end
	
	--如果后排也没有取前排
	if #atkTargetList == 0 then
		skillTargetFront(targetTeam, atkTargetList)
	end
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end

	return atkTargetList	       
end	

local function skillTargetScript_2(params)      --敌方后排         
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = rightTeam
	else
		targetTeam = leftTeam
	end
	
	local atkTargetList = {}
	--后排
	skillTargetEnd(targetTeam, atkTargetList)	
	
	--如果后排都没有目标取中排	
	if #atkTargetList == 0 then
		skillTargetMiddle(targetTeam, atkTargetList)
	end
	
	--如果中排也没有取前排
	if #atkTargetList == 0 then
		skillTargetFront(targetTeam, atkTargetList)
	end
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end
	
	return atkTargetList	       
end	

local function skillTargetScript_3(params)      --敌方前中排          
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId==BattleType.ATTACKER then
		targetTeam = rightTeam
	else
		targetTeam = leftTeam
	end
	
	local atkTargetList = {}	
	--前排	
	skillTargetFront( targetTeam, atkTargetList )

	if #atkTargetList == 0 then
		--前排没人拿中后排
		skillTargetMiddle( targetTeam, atkTargetList )
		skillTargetEnd( targetTeam, atkTargetList )	
	else
		--中排
		skillTargetMiddle( targetTeam, atkTargetList )
	end
	
	local listNum = #atkTargetList
	if listNum==0 then
		return nil
	end
	
	return atkTargetList	    
end	

local function skillTargetScript_4(params)      --敌方中后排      
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = rightTeam
	else
		targetTeam = leftTeam
	end
	
	local atkTargetList = {}	
	
	--中排		
	skillTargetMiddle(targetTeam, atkTargetList)
	--后排		
	skillTargetEnd(targetTeam, atkTargetList)	
	
	--前排	
	if #atkTargetList == 0 then				
		skillTargetFront(targetTeam, atkTargetList)
	end	
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end
	
	return atkTargetList	       
end	

local function skillTargetScript_5(params)      --敌方全体     
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = rightTeam
	else
		targetTeam = leftTeam
	end
	
	local atkTargetList = targetTeam	
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end
	
	return atkTargetList	           
end	

local function skillTargetScript_6(params)      --我方前排       
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--遍历敌方前排
	if entTypeId == BattleType.ATTACKER then
		targetTeam = leftTeam
	else
		targetTeam = rightTeam
	end
	
	local atkTargetList = {}
	--取前排
	skillTargetFront(targetTeam, atkTargetList)
	--如果前排没有取中排攻击目标
	if #atkTargetList == 0 then
		skillTargetMiddle(targetTeam, atkTargetList)
	end
	
	--如果中排都没有目标取后排
	if #atkTargetList == 0 then
		skillTargetEnd(targetTeam, atkTargetList)
	end
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end
	
	return atkTargetList	     
end	

local function skillTargetScript_7(params)      --我方中排   	
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = leftTeam
	else		
		targetTeam = rightTeam
	end
	
	local atkTargetList = {}
	--取中排	
	skillTargetMiddle(targetTeam, atkTargetList)	
	
	--如果中排都没有目标取后排
	if #atkTargetList == 0 then
		skillTargetEnd(targetTeam, atkTargetList)
	end
	
	--如果后排也没有取前排
	if #atkTargetList == 0 then
		skillTargetFront(targetTeam, atkTargetList)
	end
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end

	return atkTargetList	       
end	


local function skillTargetScript_8(params)      --我方后排     	
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = leftTeam
	else		
		targetTeam = rightTeam
	end
	
	local atkTargetList = {}
	--后排
	skillTargetEnd(targetTeam, atkTargetList)	
	
	--如果后排都没有目标取中排	
	if #atkTargetList == 0 then
		skillTargetMiddle(targetTeam, atkTargetList)
	end
	
	--如果中排也没有取前排
	if #atkTargetList == 0 then
		skillTargetFront(targetTeam, atkTargetList)
	end
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end
	
	return atkTargetList	       
end	


local function skillTargetScript_9(params)      --我方前中排     	   
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = leftTeam
	else		
		targetTeam = rightTeam
	end
	
	local atkTargetList = {}

	--前排	
	skillTargetFront(targetTeam, atkTargetList)

	if #atkTargetList == 0 then
		--前排没人拿中后排
		skillTargetMiddle(targetTeam, atkTargetList)
		skillTargetEnd(targetTeam, atkTargetList)	
	else
		--中排
		skillTargetMiddle(targetTeam, atkTargetList)
	end	
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end
	
	return atkTargetList	    
end	


local function skillTargetScript_10(params)      --我方中后排       	
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = leftTeam
	else		
		targetTeam = rightTeam
	end
	
	local atkTargetList = {}	
	
	--中排		
	skillTargetMiddle(targetTeam, atkTargetList)
	--后排		
	skillTargetEnd(targetTeam, atkTargetList)	
	
	--前排	
	if #atkTargetList == 0 then				
		skillTargetFront(targetTeam, atkTargetList)
	end	
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end

	return atkTargetList	       
end	


local function skillTargetScript_11(params)      --我方全体    	 
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = leftTeam
	else		
		targetTeam = rightTeam
	end
	
	local atkTargetList = targetTeam	
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end
	
	return atkTargetList	           
end	


local function skillTargetScript_12(params)      --敌方生命值最少     	
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = rightTeam
	else
		targetTeam = leftTeam
	end
	
	--从小到大排列 先比例 再血值
	local tbId2Hp = {}	
	for _k, v in pairs(targetTeam) do
		local tbId2Hp_item = {}
		local ent = EntityManager:getInstance():getEntityWithID(v)
		tbId2Hp_item.id = v
		tbId2Hp_item.hp = ent:getCurrentHp()
		tbId2Hp_item.hpPercent = ent:getCurrentHp() / ent:getTotalHp()

		--sort
		local index1 = nil
		local equalPercent = nil
		for i, v1 in ipairs(tbId2Hp) do
			if tbId2Hp_item.hpPercent == v1.hpPercent then
				index1 = i
				equalPercent = v1.hpPercent
				break
			elseif tbId2Hp_item.hpPercent > v1.hpPercent then
				index1 = i + 1
			end
		end

		if index1 == nil then
			table.insert(tbId2Hp, 1, tbId2Hp_item)
		else
			if equalPercent then
				index2 = nil
				for i, v1 in ipairs(tbId2Hp) do
					if v1.hpPercent == equalPercent then
						if tbId2Hp_item.hp > v1.hp then
							index2 = i + 1
						end
					end
				end

				if index2 == nil then
					table.insert(tbId2Hp, index1, tbId2Hp_item)
				else
					table.insert(tbId2Hp, index2, tbId2Hp_item)
				end
			else
				table.insert(tbId2Hp, index1, tbId2Hp_item)
			end
		end

	end
	
	-- local fComp = function(a, b)
	-- 	if a.hp < b.hp then
	-- 		return true
	-- 	else
	-- 		return false
	-- 	end
	-- end
	
	-- --从小到大排列
	-- table.sort(tbId2Hp, fComp)
	
	local atkTargetList = tbId2Hp
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end

	targetNum = math.min(listNum, targetNum)

	local targetList = {}

	for i = 1, targetNum do
		targetList[i] = atkTargetList[i].id
	end

	return targetList

end	

local function skillTargetScript_13(params)      --敌方生命值最多     
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = rightTeam
	else
		targetTeam = leftTeam
	end
	
	local tbId2Hp = {}
	for _k, v in pairs(targetTeam) do
		local tbId2Hp_item = {}
		local ent = EntityManager:getInstance():getEntityWithID(v)
		tbId2Hp_item.id = v
		tbId2Hp_item.hp = ent:getCurrentHp() / ent:getTotalHp()
		table.insert(tbId2Hp, tbId2Hp_item)
	end
	
	local fComp = function(a, b)
		if b.hp < a.hp then
			return true
		else
			return false
		end
	end
	
	--从大到小排列
	table.sort(tbId2Hp, fComp)
	
	local atkTargetList = tbId2Hp
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end

	targetNum = math.min(listNum, targetNum)

	local targetList = {}

	for i = 1, targetNum do
		targetList[i] = atkTargetList[i].id
	end

	return targetList

end	

local function skillTargetScript_14(params)      --我方生命值最少      	  	
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = leftTeam
	else		
		targetTeam = rightTeam
	end
	
	local tbId2Hp = {}
	for _k, v in pairs(targetTeam) do
		local tbId2Hp_item = {}
		local ent = EntityManager:getInstance():getEntityWithID(v)
		tbId2Hp_item.id = v
		tbId2Hp_item.hp = ent:getCurrentHp() / ent:getTotalHp()
		table.insert(tbId2Hp, tbId2Hp_item)
	end
	
	local fComp = function(a, b)
		if a.hp < b.hp then
			return true
		else
			return false
		end
	end
	
	--从小到大排列
	table.sort(tbId2Hp, fComp)
	
	local atkTargetList = tbId2Hp	
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end

	targetNum = math.min(listNum, targetNum)

	local targetList = {}

	for i = 1, targetNum do
		targetList[i] = atkTargetList[i].id
	end

	return targetList
end	


local function skillTargetScript_15(params)      --我方生命值最多   	
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = leftTeam
	else
		targetTeam = rightTeam
	end
	
	local tbId2Hp = {}
	for _k, v in pairs(targetTeam) do
		local tbId2Hp_item = {}
		local ent = EntityManager:getInstance():getEntityWithID(v)
		tbId2Hp_item.id = v
		tbId2Hp_item.hp = ent:getCurrentHp() / ent:getTotalHp()
		table.insert(tbId2Hp, tbId2Hp_item)
	end
	
	local fComp = function(a, b)
		if b.hp < a.hp then
			return true
		else
			return false
		end
	end
	
	--从大到小排列
	table.sort(tbId2Hp, fComp)
	
	local atkTargetList = tbId2Hp
	
	local listNum = #atkTargetList
	if listNum==0 then
		return nil
	end

	targetNum = math.min(listNum, targetNum)

	local targetList = {}

	for i = 1, targetNum do
		targetList[i] = atkTargetList[i].id
	end

	return targetList

end


local function skillTargetScript_16(params)      --纵向一列       
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId==BattleType.ATTACKER then
		targetTeam = rightTeam
	else
		targetTeam = leftTeam
	end
	
	local iLen = #targetTeam

	local upMinPos = math.huge
	local downMinPos = math.huge
	
	local upList = {}
	local downList = {}
	for _, entId in pairs(targetTeam) do
		local ent = EntityManager:getInstance():getEntityWithID(entId)
		local pos = ent:getBattleFieldPosition()
		if pos % 2 == 0 then
			if pos < downMinPos then
				downMinPos = pos
			end
			table.insert(downList, entId)
		else
			if pos < upMinPos then
				upMinPos = pos
			end
			table.insert(upList, entId)
		end
	end	
	
	if #upList == 0 and #downList == 0 then
		return nil
	end

	local retAtkTargetList = {}

	if #upList == 0 then
		retAtkTargetList = downList
	elseif #downList == 0 then
		retAtkTargetList = upList
	else

		local upRowType = BattlePosType.posToRow[upMinPos]
		local downRowType = BattlePosType.posToRow[downMinPos]

		--相同随机
		if upRowType == downRowType then

			if math.random(1, 10) <= 5 then
				retAtkTargetList = upList
			else
				retAtkTargetList = downList
			end
		else

			--不然拿哪一列的人更前
			if upRowType < downRowType then
				retAtkTargetList = upList
			else
				retAtkTargetList = downList
			end

		end
	end

	return retAtkTargetList

end	

local function skillTargetScript_17(params)      -- 自己       
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum
	
	local selfId = atkEnt:getEntityID()	
	
	local retAtkTargetList = {selfId}	
	
	return retAtkTargetList
end	

local function skillTargetScript_18(params)      --敌方完全随机     
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum	
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then		
		targetTeam = rightTeam
	else				
		targetTeam = leftTeam
	end
	
	local iLen = #targetTeam
	local iSeed = math.random(1, iLen)	
	
	local listNum = #targetTeam

	if listNum == 0 then
		return nil
	end
	
	return targetTeam
end	

local function skillTargetScript_19(params)      --我方完全随机     
	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	local targetNum = params.targetNum	
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--
	if entTypeId == BattleType.ATTACKER then
		targetTeam = leftTeam
	else		
		targetTeam = rightTeam
	end
	
	local listNum = #targetTeam
	if listNum == 0 then
		return nil
	end
	
	return targetTeam
end


--敌方前排血量最少
local function skillTargetScript_20(params)

	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	--遍历敌方前排
	if entTypeId == BattleType.ATTACKER then
		targetTeam = rightTeam
	else
		targetTeam = leftTeam
	end
	
	local atkTargetList = {}
	--取前排
	skillTargetFront(targetTeam, atkTargetList)
	--如果前排没有取中排攻击目标
	if #atkTargetList == 0 then
		skillTargetMiddle(targetTeam, atkTargetList)
	end
	
	--如果中排都没有目标取后排
	if #atkTargetList == 0 then
		skillTargetEnd(targetTeam, atkTargetList)
	end
	
	local listNum = #atkTargetList
	if listNum == 0 then
		return nil
	end

	if listNum == 1 then
		return atkTargetList
	end

	local minHp = math.huge
	local minTargetId = 0

	for k, v in ipairs(atkTargetList) do
		local entity = EntityManager:getInstance():getEntityWithID(v)
		if entity:getCurrentHp() < minHp then
			minHp = entity:getCurrentHp()
			minTargetId = v
		end
	end
	
	return {minTargetId}

end

--前中后/2-1
local function skillTargetScript_21(params)

	local leftTeam = params.leftTeam
	local rightTeam = params.rightTeam
	local atkEnt = params.atkEnt
	
	local targetTeam = nil
	local entTypeId = atkEnt:getEntityType()
	if entTypeId == BattleType.ATTACKER then
		targetTeam = rightTeam
	else
		targetTeam = leftTeam
	end

	local atkTargetList
	local isEnough = false
	local funcList = {skillTargetFront, skillTargetMiddle, skillTargetEnd}
	for i = 2, 1, -1 do
		isEnough = false
		for _, v in ipairs(funcList) do
			atkTargetList = {}
			v(targetTeam, atkTargetList)
			if #atkTargetList >= i then
				isEnough = true
				break
			end
		end
		if isEnough then
			break
		end
	end

	if #atkTargetList == 0 then
		return nil
	end

	return atkTargetList

end


-------------------------------------------------------------------------------------------
SkillTargetScript[1+SkillTargetType.targetType_0 ] = skillTargetScript_0       --敌方前排
SkillTargetScript[1+SkillTargetType.targetType_1 ] = skillTargetScript_1       --敌方中排
SkillTargetScript[1+SkillTargetType.targetType_2 ] = skillTargetScript_2       --敌方后排
SkillTargetScript[1+SkillTargetType.targetType_3 ] = skillTargetScript_3       --敌方前中排    
SkillTargetScript[1+SkillTargetType.targetType_4 ] = skillTargetScript_4       --敌方中后排    
SkillTargetScript[1+SkillTargetType.targetType_5 ] = skillTargetScript_5       --敌方全体
SkillTargetScript[1+SkillTargetType.targetType_6 ] = skillTargetScript_6       --我方前排
SkillTargetScript[1+SkillTargetType.targetType_7 ] = skillTargetScript_7       --我方中排
SkillTargetScript[1+SkillTargetType.targetType_8 ] = skillTargetScript_8       --我方后排
SkillTargetScript[1+SkillTargetType.targetType_9 ] = skillTargetScript_9       --我方前中排    
SkillTargetScript[1+SkillTargetType.targetType_10] = skillTargetScript_10      --我方中后排    
SkillTargetScript[1+SkillTargetType.targetType_11] = skillTargetScript_11      --我方全体
SkillTargetScript[1+SkillTargetType.targetType_12] = skillTargetScript_12      --敌方生命值最少
SkillTargetScript[1+SkillTargetType.targetType_13] = skillTargetScript_13      --敌方生命值最多
SkillTargetScript[1+SkillTargetType.targetType_14] = skillTargetScript_14      --我方生命值最少
SkillTargetScript[1+SkillTargetType.targetType_15] = skillTargetScript_15      --我方生命值最多
SkillTargetScript[1+SkillTargetType.targetType_16] = skillTargetScript_16      --纵向一列
SkillTargetScript[1+SkillTargetType.targetType_17] = skillTargetScript_17      -- 自己 
SkillTargetScript[1+SkillTargetType.targetType_18] = skillTargetScript_18      --敌方完全随机  
SkillTargetScript[1+SkillTargetType.targetType_19] = skillTargetScript_19      --我方完全随机  
SkillTargetScript[1+SkillTargetType.targetType_20] = skillTargetScript_20      --敌方前排血量最少
SkillTargetScript[1+SkillTargetType.targetType_21] = skillTargetScript_21      --敌方前排血量最少


function getSkillTargetGroup(params)
	local targetTypeId = params.skillTargetTypeId
	
	local endLeftTeam = {}
	local endRightTeam = {}
	
	local entity
	for _, entId in pairs(params.leftTeam) do
		entity = EntityManager:getInstance():getEntityWithID(entId)
		if not entity:getIsOut() then
			table.insert(endLeftTeam, entId)
		end
	end
	
	for _, entId in pairs(params.rightTeam) do
		entity = EntityManager:getInstance():getEntityWithID(entId)
		if not entity:getIsOut() then
			table.insert(endRightTeam, entId)
		end
	end
	
	params.leftTeam = endLeftTeam
	params.rightTeam = endRightTeam
	
	
	if targetTypeId == nil then
		targetTypeId = SkillTargetType.targetType_1
	end
		
	if SkillTargetScript[1+targetTypeId] == nil then
		return nil
	end
	
    local group = SkillTargetScript[1+targetTypeId](params)

    --最少最多不用随机
    if targetTypeId == SkillTargetType.targetType_12 or 
    	targetTypeId == SkillTargetType.targetType_13 or
    	targetTypeId == SkillTargetType.targetType_14 or
    	targetTypeId == SkillTargetType.targetType_15 then
    	return group
    end

    local randomGroup = getSkillRandomTarget(group, params.targetNum)

    --sort with position
    if randomGroup then

    	local posList = {}
	    for i, entityId in ipairs(randomGroup) do

	    	local pos = EntityManager:getInstance():getEntityWithID(entityId):getBattleFieldPosition()
	    	local insertIndex = -1

	    	for j, pos1 in ipairs(posList) do

	    		if pos <= pos1[1] then
	    			insertIndex = j
	    			break
	    		end
	    	end

	    	if insertIndex == -1 then
	    		posList[#posList + 1] = {pos, entityId}
	    	else
	    		table.insert(posList, insertIndex, {pos, entityId})
	    	end
	    end

	    randomGroup = {}

	    for i, posData in ipairs(posList) do
	    	randomGroup[i] = posData[2]
	    end

    end
	
	return randomGroup

end

local skillTargetCampList = {}
skillTargetCampList.ENEMY  = 
{
	SkillTargetType.targetType_0,
	SkillTargetType.targetType_1,
	SkillTargetType.targetType_2,
	SkillTargetType.targetType_3,
	SkillTargetType.targetType_4,
	SkillTargetType.targetType_5,
	SkillTargetType.targetType_12,
	SkillTargetType.targetType_13,
	SkillTargetType.targetType_16,
	SkillTargetType.targetType_18,
	SkillTargetType.targetType_20
}

skillTargetCampList.ALLY = 
{
	SkillTargetType.targetType_6,
	SkillTargetType.targetType_7,
	SkillTargetType.targetType_8,
	SkillTargetType.targetType_9,
	SkillTargetType.targetType_10,
	SkillTargetType.targetType_11,
	SkillTargetType.targetType_14,
	SkillTargetType.targetType_15,
	SkillTargetType.targetType_17,
	SkillTargetType.targetType_19
}


--[[
    获取技能目标的阵营
    @param targetType 目标类型
    @return BattleType.SKILL_ENEMY / BattleType.SKILL_ALLY
]]
function getSkillTargetCamp(targetType)

	for k, v in ipairs(skillTargetCampList.ENEMY) do

		if v == targetType then
			return BattleType.SKILL_ENEMY
		end
	end

	for k, v in ipairs(skillTargetCampList.ALLY) do

		if v == targetType then
			return BattleType.SKILL_ALLY
		end
	end

end