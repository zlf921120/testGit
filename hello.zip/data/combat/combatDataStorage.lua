--
-- Author: thisgf
-- Date: 2014-07-16 20:12:05
-- 战斗配置数据存储

require("fnt_battle_data_pb")
require("FileUtils")
require("combatConfig")

CombatDataStorage = class("CombatDataStorage")

CombatDataStorage._initDataDict = nil

CombatDataStorage._sceneDataDict = nil

CombatDataStorage._isParseData = false

--失败功能提示
CombatDataStorage._failFuncDataList = nil

--对手出手时间数据
CombatDataStorage._enemyTimeDataDict = nil

local _instance

function CombatDataStorage:ctor()

	self._initDataDict = {}
	self._sceneDataDict = {}
	self._failFuncDataList = {}

	self._enemyTimeDataDict = {}

end

function CombatDataStorage:getInstance()

	if not _instance then
		_instance = CombatDataStorage.new()
	end

	return _instance
end

--解析配置数据
function CombatDataStorage:parseConfigData()

	if self._isParseData == true then
		return
	end

	self._isParseData = true

	local file = FileUtils.readConfigFile("fnt_battle_data.dat")

	local combat_data_pb = fnt_battle_data_pb.fnt_battle_data()
	combat_data_pb:ParseFromString(file)


	local sceneData
	for k, v in pairs(combat_data_pb.scene_data_rows) do

		if v.id then

			sceneData = CombatSceneData:create()

			sceneData.id = v.id
			sceneData.fileName = v.file_name

			self._sceneDataDict[v.id] = sceneData
		end
	end


	local lastId = 0
	local lastSubId = 0
	local initData
	local waveData
	for k, v in pairs(combat_data_pb.init_data_rows) do

		if v.id then

			if lastId ~= v.id then
				
				lastSubId = 0

				lastId = v.id

				self._initDataDict[lastId] = {}
				
			end

			if lastSubId ~= v.sub_id then

				lastSubId = v.sub_id

				initData = CombatInitData:create()
				initData.id = lastId
				initData.subId = lastSubId
				initData.battleType = v.battle_type
				initData.sceneType = v.scene_type
				initData.settlementType = v.settlement_type
				initData.maxRound = v.max_round
				initData.maxHandleTime = v.max_handle_time

				self._initDataDict[lastId][lastSubId] = initData
				
			end

			waveData = CombatWaveData:create()
			waveData.sceneId = v.scene_id
			if self._sceneDataDict[v.scene_id] then
				local fileName = self._sceneDataDict[v.scene_id].fileName
				waveData.sceneFileName = string.format("%s/%s.%s", BattleSceneFilePrefix, fileName, BattleSceneFileType)
			end
			waveData.roleJoinType = v.role_join_type
			waveData.monsterPlotJoinType = v.monster_plot_join_type
			waveData.monsterJoinType = v.monster_join_type

			if #v.monster_list > 0 then
				-- local monsterList = Utils.split(v.monster_list, ",")
				local monsterList = loadstring("return {" .. v.monster_list .. "}")()
				for i, monster in ipairs(monsterList) do
					waveData:addMonster(monster)
				end
			end

			waveData.aiOppotunity = v.ai_oppotunity
			waveData.aiTriggerType = v.ai_trigger_type
			waveData.fightOrder = v.fight_order

			if #v.ai_list > 0 then
				local aiList = Utils.split(v.ai_list, ",")
				for i, aiId in ipairs(aiList) do
					waveData:addAI(tonumber(aiId))
				end
			end

			initData:addWaveData(waveData)

		end
	end

	lastId = 0
	lastSubId = 0
	local lastWaveIndex = 0

	for k, v in pairs(combat_data_pb.ai_data_rows) do

		if v.id then

			if lastId ~= v.id then
				lastId = v.id
			end

			if lastSubId ~= v.sub_id then
				lastSubId = v.sub_id
			end

			initData = self._initDataDict[lastId][lastSubId]

			if initData then

				if lastWaveIndex ~= v.wave_index then
					lastWaveIndex = v.wave_index
				end

				waveData = initData:getWaveDataWithIndex(lastWaveIndex)

				waveData:addAIList(v.team_level, v.ai_trigger_type, v.ai_oppotunity, v.ai_list)

			end

		end

	end

	local failData

	for k, v in pairs(combat_data_pb.level_open_rows) do

		if v.level then

			failData = CombatFailFuncData:create()
			failData.level = v.level
			failData.iconId = v.func_id
			failData.windowId = v.window_id

			table.insert(self._failFuncDataList, failData)

		end

	end

	lastId = 0
	lastSubId = 0
	local timeData
	for k, v in pairs(combat_data_pb.enemy_fight_time_rows) do
		if v.id then
			if lastId ~= v.id then
				lastId = v.id
				self._enemyTimeDataDict[lastId] = {}
			end

			if lastSubId ~= v.sub_id then
				lastSubId = v.sub_id
				self._enemyTimeDataDict[lastId][lastSubId] = {}
			end

			timeData = CombatEnemyTimeData:create()
			timeData.allyTime = v.ally_time
			timeData.enemyMinTime = v.enemy_min_time
			timeData.enemyMaxTime = v.enemy_max_time
			table.insert(self._enemyTimeDataDict[lastId][lastSubId], timeData)
		end
	end

end

--[[
    获取战斗初始化数据
    @param id
    @param subId
    @return CombatInitData
]]
function CombatDataStorage:getCombatInitData(id, subId)

	local subDict = self._initDataDict[id]

	if not subDict then
		return nil
	end

	return clone(subDict[subId])

end

--[[
    获取战斗场景配置数据
    @param id
]]
function CombatDataStorage:getCombatSceneData(id)

	return self._sceneDataDict[id]
end

--[[
    获取根据战队等级开放的随机功能数据字典
]]
function CombatDataStorage:getRandomOpenFuncData(num)

	local level = CharacterManager:getInstance():getTeamData():getLev()

	local tempList = {}

	for i, v in ipairs(self._failFuncDataList) do

		if level >= v.level then
			tempList[#tempList + 1] = v
		end
	end

	if num >= #tempList then
		return tempList
	end

	MathUtil.shuffleList(tempList)

	local randomList = {}

	for i = 1, num do
		randomList[i] = tempList[i]
	end

	return randomList

end

--[[
    获取对手出手时间数据
]]
function CombatDataStorage:getEnemyTimeData(id, subId, allyTime)

	local topData = self._enemyTimeDataDict[id]
	if not topData then
		return nil
	end

	local subData = topData[subId]
	if not subData then
		return nil
	end

	for i, v in ipairs(subData) do
		if v.allyTime == allyTime then
			return v
		end
	end

	return nil

end



--战斗初始数据
CombatInitData = class("CombatInitData")

--配置ID
CombatInitData.id = 0
--配置子ID
CombatInitData.subId = 0
--战斗类型
CombatInitData.battleType = 0
--过场类型
CombatInitData.sceneType = 0
--波数据
CombatInitData.waveList = nil

--结算方式
--@see BattleSettlementType
CombatInitData.settlementType = 1

--总波数
CombatInitData.totalWave = 0

--总回合
CombatInitData.maxRound = 0

--最大出手时间(0:不限制 s)
CombatInitData.maxHandleTime = 0


function CombatInitData:ctor()

	self.waveList = {}
	self.totalWave = 0
end

function CombatInitData:addWaveData(data)

	table.insert(self.waveList, data)

	self.totalWave = self.totalWave + 1

end

function CombatInitData:getWaveDataWithIndex(index)

	return self.waveList[index]
end

function CombatInitData:create()

	local initData = CombatInitData.new()

	return initData
end


--战斗每波数据
CombatWaveData = class("CombatWaveData")

CombatWaveData.sceneId = 0
CombatWaveData.sceneFileName = ""
CombatWaveData.roleJoinType = 0
CombatWaveData.monsterPlotJoinType = 0
CombatWaveData.monsterJoinType = 0
--怪物字典(key为位置, value为baseId)
CombatWaveData.monsterDict = nil

--ai出现时机
CombatWaveData.aiOppotunity = 1

--ai触发类型
CombatWaveData.aiTriggerType = 1

--AIid列表
CombatWaveData.aiList = nil

--ai列表组
CombatWaveData._aiListGroup = nil

--出手顺序
CombatWaveData.fightOrder = 0

function CombatWaveData:ctor()
	self.monsterDict = {}
	self.aiList = {}

	self._aiListGroup = {}
end

function CombatWaveData:addMonster(monster)

	self.monsterDict[monster[2]] = monster[1]
end

function CombatWaveData:addAI(id)

	table.insert(self.aiList, id)
end

function CombatWaveData:addAIList(teamLevel, triggerType, aiOppotunity, aiList)

	local l = {}

	local aiStr = Utils.split(aiList, ",")
	for i, aiId in ipairs(aiStr) do
		l[#l + 1] = tonumber(aiId)
	end

	self._aiListGroup[teamLevel] = {triggerType, l, aiOppotunity}

end

--[[
    根据战队等级获取的ai数据
    @return {triggerType, aiList}
]]
function CombatWaveData:getAIDataWithLevel()

	local cm = CharacterManager:getInstance():getTeamData()
	local lev = cm:getLev()

	local teamData
	local maxLevel = 0

	for teamLevel, data in pairs(self._aiListGroup) do

		if lev >= teamLevel then
			if teamLevel > maxLevel then
				maxLevel = teamLevel
				teamData = data
			end
		end
	end

	if not teamData then
		teamData = {self.aiTriggerType, self.aiList}
	end

	return teamData

end

function CombatWaveData:create()

	local waveData = CombatWaveData.new()

	return waveData
end


--战斗场景数据
CombatSceneData = class("CombatSceneData")
CombatSceneData.id = 0
CombatSceneData.fileName = ""

function CombatSceneData:create()

	local sceneData = CombatSceneData.new()

	return sceneData
end


--战斗失败功能控制数据
CombatFailFuncData = class("CombatFailFuncData")

--开放等级
CombatFailFuncData.level = 0
--图标ID
CombatFailFuncData.iconId = 0
--窗体ID
CombatFailFuncData.windowId = 0

function CombatFailFuncData:ctor()


end

function CombatFailFuncData:create()

	local failData = CombatFailFuncData.new()

	return failData
end


--[[
    对手出手时间
]]
CombatEnemyTimeData = class("CombatEnemyTimeData")

CombatEnemyTimeData.allyTime = 0
CombatEnemyTimeData.enemyMinTime = 0
CombatEnemyTimeData.enemyMaxTime = 0

function CombatEnemyTimeData:ctor()
end

function CombatEnemyTimeData:create()
	return CombatEnemyTimeData.new()
end
