--
-- Author: thisgf
-- Date: 2014-07-22 10:35:31
-- 战斗buff管理器

require "AttrHelper"
require "SkillManager"
require "combatConfig"

BuffManager = class("BuffManager")

BuffManager._sm = nil

--buffId和属性类型对应字典
BuffManager._buffForAttrTypeDict = nil
--buff对应抗性
BuffManager._buffForAntiAttrTypeDict = nil

--buff性质字典
BuffManager._buffNatureDict = nil

local _instance

local PERCENT_BASE = 10000

function BuffManager:ctor()

	self._sm = SkillManager:getInstance()

	self._buffForAttrTypeDict = {}
	self._buffForAntiAttrTypeDict = {}
	self._buffNatureDict = {}

	self:_initAttr()

end

function BuffManager:getInstance()

	if not _instance then
		_instance = BuffManager.new()
	end

	return _instance
end

function BuffManager:_initAttr()

	self._buffForAttrTypeDict[BuffType.ADD_ATTACK] = AttrHelper:getAttrStrFlag(AttrHelper.attr_flag.atk)
	self._buffForAttrTypeDict[BuffType.ADD_ATTACK_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_ATTACK]
	self._buffForAttrTypeDict[BuffType.MINUS_ATTACK] = self._buffForAttrTypeDict[BuffType.ADD_ATTACK]
	self._buffForAttrTypeDict[BuffType.MINUS_ATTACK_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_ATTACK]

	self._buffForAttrTypeDict[BuffType.ADD_DEFENSE] = AttrHelper:getAttrStrFlag(AttrHelper.attr_flag.pdef)
	self._buffForAttrTypeDict[BuffType.ADD_DEFENSE_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_DEFENSE]
	self._buffForAttrTypeDict[BuffType.MINUS_DEFENSE] = self._buffForAttrTypeDict[BuffType.ADD_DEFENSE]
	self._buffForAttrTypeDict[BuffType.MINUS_DEFENSE_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_DEFENSE]

	self._buffForAttrTypeDict[BuffType.ADD_CRIT] = AttrHelper:getAttrStrFlag(AttrHelper.attr_flag.crit)
	self._buffForAttrTypeDict[BuffType.ADD_CRIT_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_CRIT]
	self._buffForAttrTypeDict[BuffType.ADD_CRIT_PERCENT_ASSASSIN] = self._buffForAttrTypeDict[BuffType.ADD_CRIT]
	self._buffForAttrTypeDict[BuffType.MINUS_CRIT] = self._buffForAttrTypeDict[BuffType.ADD_CRIT]
	self._buffForAttrTypeDict[BuffType.MINUS_CRIT_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_CRIT]

	self._buffForAttrTypeDict[BuffType.ADD_BLOCK] = AttrHelper:getAttrStrFlag(AttrHelper.attr_flag.block)
	self._buffForAttrTypeDict[BuffType.ADD_BLOCK_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_BLOCK]
	self._buffForAttrTypeDict[BuffType.MINUS_BLOCK] = self._buffForAttrTypeDict[BuffType.ADD_BLOCK]
	self._buffForAttrTypeDict[BuffType.MINUS_BLOCK_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_BLOCK]

	self._buffForAttrTypeDict[BuffType.ADD_BACK] = AttrHelper:getAttrStrFlag(AttrHelper.attr_flag.fight_back)
	self._buffForAttrTypeDict[BuffType.ADD_BACK_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_BACK]
	self._buffForAttrTypeDict[BuffType.MINUS_BACK] = self._buffForAttrTypeDict[BuffType.ADD_BACK]
	self._buffForAttrTypeDict[BuffType.MINUS_BACK_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_BACK]

	self._buffForAttrTypeDict[BuffType.ADD_MISS] = AttrHelper:getAttrStrFlag(AttrHelper.attr_flag.evasion)
	self._buffForAttrTypeDict[BuffType.ADD_MISS_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_MISS]
	self._buffForAttrTypeDict[BuffType.MINUS_MISS] = self._buffForAttrTypeDict[BuffType.ADD_MISS]
	self._buffForAttrTypeDict[BuffType.MINUS_MISS_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_MISS]

	self._buffForAttrTypeDict[BuffType.ADD_IGNORE_DEFENSE] = AttrHelper:getAttrStrFlag(AttrHelper.attr_flag.def_break)
	self._buffForAttrTypeDict[BuffType.ADD_IGNORE_DEFENSE_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_IGNORE_DEFENSE]
	self._buffForAttrTypeDict[BuffType.MINUS_IGNORE_DEFENSE] = self._buffForAttrTypeDict[BuffType.ADD_IGNORE_DEFENSE]
	self._buffForAttrTypeDict[BuffType.MINUS_IGNORE_DEFENSE_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_IGNORE_DEFENSE]

	self._buffForAttrTypeDict[BuffType.ADD_SACRED_DAMAGE] = AttrHelper:getAttrStrFlag(AttrHelper.attr_flag.real_harm)
	self._buffForAttrTypeDict[BuffType.ADD_SACRED_DAMAGE_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_SACRED_DAMAGE]
	self._buffForAttrTypeDict[BuffType.MINUS_SACRED_DAMAGE] = self._buffForAttrTypeDict[BuffType.ADD_SACRED_DAMAGE]
	self._buffForAttrTypeDict[BuffType.MINUS_SACRED_DAMAGE_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_SACRED_DAMAGE]
	
	self._buffForAttrTypeDict[BuffType.ADD_EXEMPT_DAMAGE] = AttrHelper:getAttrStrFlag(AttrHelper.attr_flag.reduce_harm)
	self._buffForAttrTypeDict[BuffType.ADD_EXEMPT_DAMAGE_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_EXEMPT_DAMAGE]
	self._buffForAttrTypeDict[BuffType.MINUS_EXEMPT_DAMAGE] = self._buffForAttrTypeDict[BuffType.ADD_EXEMPT_DAMAGE]
	self._buffForAttrTypeDict[BuffType.MINUS_EXEMPT_DAMAGE_PERCENT] = self._buffForAttrTypeDict[BuffType.ADD_EXEMPT_DAMAGE]
	self._buffForAttrTypeDict[BuffType.ADD_EXEMPT_DAMAGE_PERCENT_2] = self._buffForAttrTypeDict[BuffType.ADD_EXEMPT_DAMAGE]
	self._buffForAttrTypeDict[BuffType.ADD_EXEMPT_DAMAGE_PERCENT_3] = self._buffForAttrTypeDict[BuffType.ADD_EXEMPT_DAMAGE]
	self._buffForAttrTypeDict[BuffType.ADD_EXEMPT_DAMAGE_PERCENT_4] = self._buffForAttrTypeDict[BuffType.ADD_EXEMPT_DAMAGE]

	self._buffForAttrTypeDict[BuffType.ADD_SUCK_BLOOD] = AttrHelper:getAttrStrFlag(AttrHelper.attr_flag.suck_blood)

	self._buffForAttrTypeDict[BuffType.MINUS_STARE_PERCENT] = AttrHelper:getAttrStrFlag(AttrHelper.attr_flag.stare)

	self._buffForAntiAttrTypeDict[BuffType.STUN] = AttrHelper.attr_flag.anti_stun
	self._buffForAntiAttrTypeDict[BuffType.SILENCE] = AttrHelper.attr_flag.anti_silent
	self._buffForAntiAttrTypeDict[BuffType.CHAOS] = AttrHelper.attr_flag.anti_chaos
	self._buffForAntiAttrTypeDict[BuffType.STONE] = AttrHelper.attr_flag.anti_stone
	self._buffForAntiAttrTypeDict[BuffType.TAUNT] = AttrHelper.attr_flag.anti_taunt
	self._buffForAntiAttrTypeDict[BuffType.DEFORM] = AttrHelper.attr_flag.anti_polymorph
	self._buffForAntiAttrTypeDict[BuffType.SLEEP] = AttrHelper.attr_flag.anti_sleep
	self._buffForAntiAttrTypeDict[BuffType.MINUS_EXEMPT_DAMAGE] = AttrHelper.attr_flag.anti_breakarmour
	self._buffForAntiAttrTypeDict[BuffType.MINUS_EXEMPT_DAMAGE_PERCENT] = AttrHelper.attr_flag.anti_breakarmour
	self._buffForAntiAttrTypeDict[BuffType.KEEP_MINUS_HP] = AttrHelper.attr_flag.anti_bleed
	self._buffForAntiAttrTypeDict[BuffType.KEEP_MINUS_HP_OVERLAY] = AttrHelper.attr_flag.anti_bleed
	self._buffForAntiAttrTypeDict[BuffType.BURN] = AttrHelper.attr_flag.anti_burn
	self._buffForAntiAttrTypeDict[BuffType.BURN_OVERLAY] = AttrHelper.attr_flag.anti_burn
	self._buffForAntiAttrTypeDict[BuffType.POISONING] = AttrHelper.attr_flag.anti_poisoning
	self._buffForAntiAttrTypeDict[BuffType.POISONING_OVERLAY] = AttrHelper.attr_flag.anti_poisoning
	self._buffForAntiAttrTypeDict[BuffType.SACRED_BURN] = AttrHelper.attr_flag.anti_sacred_burn

end

--[[
    战斗中判断是否生成buff(已过时)
    @param skillId 技能ID
    @param skillLevel 技能等级
    @param numClear 消除数
    @param targetList 目标者列表
    @return {eneityId:{BuffEffectVO, ..}, ..} or nil
]]
function BuffManager:generatorBuff(skillId, skillLevel, numClear, atker, targetList)

	local skillData = self._sm:getInitiativeSkillData(skillId, skillLevel, numClear)
	if not skillData then
		return nil
	end

	-- local scriptId = skillData._atkScriptId
	-- if not SkillScriptType.BUFF_RELATE_DICT[scriptId] then
	-- 	return nil
	-- end

	return self:_handleBuffWithArgs(scriptId, skillData._atkScriptArgs, atker, targetList)
	
end

--[[
    根据主动技能产生buff
]]
function BuffManager:generateBuffWithSkill(scriptId, scriptArgs, atker, targetList)

	return self:_handleBuffWithArgs(scriptId, scriptArgs, atker, targetList)
end

--[[
    被动技能产生buff
    @param 被动技能参数的脚本ID
    @param 被动技能buff参数
]]
function BuffManager:generateBuffWithPassiveSkill(scriptId, scriptArgs, atker, targetList)

	return self:_handleBuffWithArgs(scriptId, scriptArgs, atker, targetList)
end

function BuffManager:_handleBuffWithArgs(scriptId, scriptArgs, atker, targetList)

	if not SkillScriptType.BUFF_RELATE_DICT[scriptId] then
		return nil
	end

	local buffEffectData
	local buffRawData

	local buffId
	local buffArgs
	local proba --产生概率
	local round = 0 --持续回合
	local value = 0 --值

	local roleBuffList = {}
	local hit = false
	local buffEffectList


	local function createBuffForEntity(entity, buffId, round, value, rawData)

		buffEffectList = roleBuffList[entity:getEntityID()]
		if not buffEffectList then
			buffEffectList = {}
			roleBuffList[entity:getEntityID()] = buffEffectList
		end

		--先判读是否有属性值
		local attrType = self:getAttrWithBuffId(buffId)

		buffEffectData = BuffEffectVO:create()
		buffEffectData:assignFromRawData(rawData)
		buffEffectData.round = round
		buffEffectData.attrType = attrType
		buffEffectData.attrArg = value
		buffEffectData.attackerId = atker:getEntityID()

		table.insert(buffEffectList, buffEffectData)

	end

	--计算有多少个buff
	local buffArgsList = {}

	if scriptId == SkillScriptType.BUFF_FOR_RANDOM_TARGET then

		if #targetList > 1 then

			local target = targetList[math.random(1, #targetList)]

			--取其中一个目标
			targetList = {target}
		end
	end

	--特别处理参数
	if scriptId == SkillScriptType.TREAT_AND_BUFF then

		for i = 2, #scriptArgs do
			buffArgsList[#buffArgsList + 1] = scriptArgs[i]
		end
	elseif scriptId == SkillScriptType.DISPERSE_AND_BUFF then
		
		buffArgsList[1] = scriptArgs[2]
	elseif scriptId == SkillScriptType.BUFF_FOR_SPECIAL_TARGET or 
			scriptId == SkillScriptType.ATTACK_AND_BUFF or 
			scriptId == SkillScriptType.BUFF_FROM_ATTACK then

		buffArgsList = {scriptArgs}
	else
		buffArgsList = scriptArgs
	end


	for _, buff in ipairs(buffArgsList) do

		buffId = buff[1]

		buffRawData = self._sm:getBattleBuffConfigData(buffId)

		if buffRawData then

			buffArgs = buff[2]
			proba = buffArgs[1]
			round = buffArgs[2]
			value = buffArgs[3]

			for _, entity in ipairs(targetList) do

				--未死
				if entity:getIsDead() == false then

					local baseArgs = entity:getAttackBaseArgs()
					local attrData = entity:getAttrData()

					hit = false
					--同阵营不用减抗性
					if atker:getEntityType() == entity:getEntityType() then

						if math.random(1, PERCENT_BASE) <= proba then --命中
							hit = true
						end

					else

						local antiType = self:getAntiAttrWithBuffId(buffId)
						local antiValue = 0
						if antiType ~= nil then

							-- antiValue = baseArgs[AttrHelper:getAttrStrFlag(antiType)] or 0
							antiValue = attrData:getAttr(antiType) or 0

						end

						--剩余几率
						local remainProba = proba - antiValue
						if remainProba <= 0 then
							hit = false
						elseif math.random(1, PERCENT_BASE) <= remainProba then
							hit = true
						end

					end

					if hit then

						createBuffForEntity(
							entity, 
							buffId, 
							round, 
							value, 
							buffRawData
						)
					end

				end
			end

		end

	end

	return roleBuffList

end

--[[
    计算buff属性变化
    @param buffList buff列表
    @param atkBaseArgs 原来的属性
    @param atkFinalWithBuffArgs 计算后的属性(其中包含两个 reduce_harm_add, reduce_harm_minus 为伤害最终计算)
]]
function BuffManager:calcBuffAttr(buffList, atkBaseArgs, atkFinalWithBuffArgs)

	if not buffList then
		buffList = {}
	end

	local has = false
	local attrType = nil

	local addAttrDict = {}
	local minusAttrDict = {}
	--伤害豁免
	local exemptDamageDict = {}

	--先分类buff
	for k, v in ipairs(buffList) do

		attrType = v.attrType
		--伤害豁免由外面计算
		if attrType == BuffType.property.REDUCE_HARM then

			if not exemptDamageDict[v.nature] then
				exemptDamageDict[v.nature] = {}
			end

			if v.nature == BuffNatureType.MALIGNANT then
			--恶性伤害豁免先算万分比再算buff

			    if v.argType == BuffArgType.VALUE then
					table.insert(exemptDamageDict[v.nature], v)
				else
					table.insert(exemptDamageDict[v.nature], 1, v)
				end

			elseif v.nature == BuffNatureType.BENIGN then
			--反其道而行之

			    if v.argType == BuffArgType.VALUE then
					table.insert(exemptDamageDict[v.nature], 1, v)
				else
					table.insert(exemptDamageDict[v.nature], v)
				end
			end

		else

			if v.attrType ~= nil then

				if v.nature == BuffNatureType.BENIGN then
				--良性buff

					if not addAttrDict[v.attrType] then
						addAttrDict[v.attrType] = {}
					end

					--业界良心buff先计算万分比再计算数值
					if v.argType == BuffArgType.VALUE then
						table.insert(addAttrDict[v.attrType], v)
					else
						table.insert(addAttrDict[v.attrType], 1, v)
					end

				elseif v.nature == BuffNatureType.MALIGNANT then
				--恶性buff

					if not minusAttrDict[v.attrType] then
						minusAttrDict[v.attrType] = {}
					end

					--黑心小作坊buff先计算数值再计算万分比
					if v.argType == BuffArgType.VALUE then
						table.insert(minusAttrDict[v.attrType], 1, v)
					else
						table.insert(minusAttrDict[v.attrType], v)
					end

				end
			end
		end
	end

	local function calcPercent(base, percent)

		return base * percent / PERCENT_BASE
	end

	for k, v in pairs(atkBaseArgs) do

		atkFinalWithBuffArgs[k] = v
	end


	local calcValue = 0

	--先计算增加的
	for at, vl in pairs(addAttrDict) do

		calcValue = atkFinalWithBuffArgs[at]
		for i, buff in ipairs(vl) do

			if buff.argType == BuffArgType.VALUE then

				calcValue = calcValue + buff.attrArg
			else
				calcValue = calcValue + calcPercent(calcValue, buff.attrArg)
			end
		end

		atkFinalWithBuffArgs[at] = calcValue

	end

	--再计算减少的
	for at, vl in pairs(minusAttrDict) do

		calcValue = atkFinalWithBuffArgs[at]
		for i, buff in ipairs(vl) do

			if buff.argType == BuffArgType.VALUE then
				calcValue = calcValue + buff.attrArg
			else
				calcValue = calcValue + calcPercent(calcValue, buff.attrArg)
			end
		end

		atkFinalWithBuffArgs[at] = calcValue

	end

	atkFinalWithBuffArgs.reduce_harm_add = 0
	atkFinalWithBuffArgs.reduce_harm_minus = 0

	--计算伤害豁免
	for na, bl in pairs(exemptDamageDict) do

		calcValue = 0

		for i, buff in ipairs(bl) do

			if buff.argType == BuffArgType.VALUE then
				calcValue = calcValue + buff.attrArg
			else
				calcValue = calcValue + calcPercent(1, buff.attrArg)
			end
		end

		if na == BuffNatureType.BENIGN then
			atkFinalWithBuffArgs.reduce_harm_add = calcValue
		else
			atkFinalWithBuffArgs.reduce_harm_minus = calcValue
		end
	end
	
end

--[[
    获取根据buffId对应的属性类型
    @param buffId
    @return AttrHelper.attr_flag
]]
function BuffManager:getAttrWithBuffId(buffId)

	return self._buffForAttrTypeDict[buffId]
end

--[[
    获取抗性属性
]]
function BuffManager:getAntiAttrWithBuffId(buffId)

	return self._buffForAntiAttrTypeDict[buffId]
end


--buff效果结构
BuffEffectVO = class("BuffEffectVO")

--id
BuffEffectVO.id = 0
--持续回合
BuffEffectVO.round = 0

--当前回合
BuffEffectVO.currentRound = 0

--参数类型
--@see BuffArgType
BuffEffectVO.argType = 0

--属性类型
BuffEffectVO.attrType = nil

--属性效果值
BuffEffectVO.attrArg = nil

--buff的性质(良/恶)
BuffEffectVO.nature = 0

--特效ID
BuffEffectVO.effectId = 0

BuffEffectVO.effectIds = nil

--头像特效ID
BuffEffectVO.avatarEffectId = 0

--图标ID
BuffEffectVO.iconId = 0

--释放者ID
BuffEffectVO.attackerId = 0

--添加时特效ID
BuffEffectVO.addEffectId = 0

BuffEffectVO.impactValueType = 1

function BuffEffectVO:ctor()
end

function BuffEffectVO:assignFromRawData(rawData)

	self.id = rawData.id
	self.effectIds = rawData.effectIds
	self.avatarEffectId = rawData.avatarEffectId
	self.iconId = rawData.iconId
	self.argType = rawData.argType
	self.nature = rawData.nature
	self.addEffectId = rawData.addEffectId
	self.impactValueType = rawData.impactValueType
end

function BuffEffectVO:create()

	local buffData = BuffEffectVO.new()

	return buffData
end

