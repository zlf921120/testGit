
local isInitResolution = false
local mapResolutionParams = {}

TouchBattleLayer = class("TouchBattleLayer", DisplayUtil.newLayer)

TouchBattleLayer._avatarContainerPos = ccp(60, 72)           --60,72
TouchBattleLayer._eliminateContainerPos = nil

TouchBattleLayer._numMap = 0

TouchBattleLayer._moveFighterFuncDict = nil
TouchBattleLayer._moveFighterParamDict = nil


--是否显示大招阴影效果
TouchBattleLayer._isShowUpanisadShadow = false

--开始消除宝石时间
TouchBattleLayer._beginGemTime = 0


--头像列表
TouchBattleLayer._avatarList = nil

--更新暂停状态
TouchBattleLayer._onUpdatePauseFunc = nil

--更新加速状态
TouchBattleLayer._onUpdateSpeedFunc = nil


--头像容器
TouchBattleLayer._avatarContainer = nil

--消除容器
TouchBattleLayer._eliminateContainer = nil


--战斗地图(暂时放在这里处理)
TouchBattleLayer._mapView = nil

--受击多少次
TouchBattleLayer._hitsView = nil

TouchBattleLayer._treasureView = nil

--暂停按钮
TouchBattleLayer._pauseButton = nil

--回合界面
TouchBattleLayer._roundView = nil

--阶段界面
TouchBattleLayer._phaseView = nil

--自动战斗按钮
TouchBattleLayer._autoPlayButton = nil

--加速界面
TouchBattleLayer._accelerateView = nil

TouchBattleLayer._onUpdateAutoPlay = nil


--宝石消除
TouchBattleLayer._gemSystem = nil

TouchBattleLayer._settlementView = nil

TouchBattleLayer._pauseView = nil

TouchBattleLayer._countdownView = nil
TouchBattleLayer._enemyFightImage = nil


--战斗地图
local BattleMapView

local BattleHitsView

--战斗阶段
local BattlePhaseView

--回合
local BattleRoundView

--自动战斗按钮
local BattleAutoPlayButton

--buff添加特效
local BuffAddEffect

local BattleTreasureView

--暂停界面
local BattlePauseView

--游戏加速UI
local BattleAccelerateView
--出手倒计时
local BattleFightCountdownView


function TouchBattleLayer:create()
	local objTouchBattleLayer = TouchBattleLayer.new()
	objTouchBattleLayer:init()
	return objTouchBattleLayer
end

function TouchBattleLayer:init()

	self:ignoreAnchorPointForPosition(false)
	self:setAnchorPoint(ccp(0,0))

	self._moveFighterFuncDict = {}
	self._moveFighterParamDict = {}

	self._avatarList = {}

    self:_initLayer()
    if BattleManager:getInstance():getIsOB() then
    	self:_initOBChildNode()
    else
	    self:_initChildNode()
    end

    self:_registeEvent()

end

--[[
    初始化层次
]]
function TouchBattleLayer:_initLayer()

	--场景层
	self._sceneLayer = DisplayUtil.newLayer()
	self:addChild(self._sceneLayer, BATTLE_LAYER_Z.container.SCENE)

	self._mapLayer = DisplayUtil.newLayer()
	self._sceneLayer:addChild(self._mapLayer, BATTLE_LAYER_Z.container.MAP)

	-- self._upanisadLayerColor = CCLayerColor:create(ccc4(0, 0, 0, 255))
	-- self._upanisadLayerColor:setVisible(false)
	-- self._upanisadLayerColor:setContentSize(CCSizeMake(DisplayUtil.visibleSize.width + 40, DisplayUtil.visibleSize.height + 40))
	-- self._upanisadLayerColor:setPosition(ccp(-20, -20))
	-- self._sceneLayer:addChild(self._upanisadLayerColor)

	self._fighterLayer = DisplayUtil.newFitLayer()
	self._sceneLayer:addChild(self._fighterLayer, BATTLE_LAYER_Z.container.FIGHT)

	self._upanisadLayerColor = CCLayerColor:create(ccc4(0, 0, 0, 255))
	self._upanisadLayerColor:setVisible(false)
	self._upanisadLayerColor:setPosition(ccp(-20, -20))
	self._upanisadLayerColor:setScale(1.5)
	self._fighterLayer:addChild(self._upanisadLayerColor, BATTLE_LAYER_Z.fighterContainer.UPANISAD)

	self._bottomEffectLayer = DisplayUtil.newLayer()
	self._fighterLayer:addChild(self._bottomEffectLayer, BATTLE_LAYER_Z.fighterContainer.EFFECT_BOTTOM)

	self._effectLayer = DisplayUtil.newLayer()
	self._fighterLayer:addChild(self._effectLayer, BATTLE_LAYER_Z.fighterContainer.EFFECT)

	self._uiLayer = DisplayUtil.newFitLayer()
	self:addChild(self._uiLayer, BATTLE_LAYER_Z.container.UI)

	self._plotLayer = DisplayUtil.newLayer()
	self:addChild(self._plotLayer, BATTLE_LAYER_Z.container.PLOT)
	
	self._windowLayer = DisplayUtil.newLayer()
	self:addChild(self._windowLayer, BATTLE_LAYER_Z.container.WINDOW)
	BattleWindowManager:getInstance():setWindowLayer(self._windowLayer)

	self._pauseLayer = DisplayUtil.newLayer()
	self:addChild(self._pauseLayer, BATTLE_LAYER_Z.container.PAUSE)

	self._heroAnimLayer = DisplayUtil.newLayer()
	self:addChild(self._heroAnimLayer, BATTLE_LAYER_Z.container.HERO_ANIM)

	self._msgLayer = DisplayUtil.newLayer()
	self:addChild(self._msgLayer, BATTLE_LAYER_Z.container.MSG)

	GameLayerMgr:getInstance():injectBattleLayer(self._windowLayer, self._msgLayer)

end

function TouchBattleLayer:_initChildNode()

	local bm = BattleManager:getInstance()

	self._avatarContainer = DisplayUtil.newNode()
	self._avatarContainer:setPosition(TouchBattleLayer._avatarContainerPos)
	self._uiLayer:addChild(self._avatarContainer)

	self._eliminateContainer = DisplayUtil.newNode()
	self._uiLayer:addChild(self._eliminateContainer)

	local touchGroup = TouchGroup:create()
	self._uiLayer:addChild(touchGroup)

	if bm:getTreasureDungeonType() then
		self._treasureView = BattleTreasureView:create()
		self._treasureView:setPosition(
			ccp(160, 
				DisplayUtil.visibleSize.height - 80
			)
		)
		self._treasureView:setTreasureType(bm:getTreasureDungeonType())
		self._uiLayer:addChild(self._treasureView)
	end

	local function addPauseButton()

		self._pauseButton = Button:create()
		self._pauseButton:loadTextureNormal("bui_stop_button_up.png", UI_TEX_TYPE_PLIST)
		self._pauseButton:loadTexturePressed("bui_stop_button_down.png", UI_TEX_TYPE_PLIST)
		self._pauseButton:setPosition(ccp(50, DisplayUtil.visibleSize.height - 35))
		self._pauseButton:addTouchEventListener(
			function(sender, event)
			    if event == TOUCH_EVENT_BEGAN then
				    bm:reqPause(true)
			    end
			end)
		touchGroup:addWidget(self._pauseButton)
	end

	if bm:getIsOB() then
		addPauseButton()
	else
		if not bm:getTreasureDungeonType() and 
			(bm:getType() == BattleType.DUNGEON or 
			 bm:getType() == BattleType.CLIMBING or 
			 bm:getType() == BattleType.RES_DUNGEON or 
			 bm:getType() == BattleType.RIDDLE_DUNGEON) then
			addPauseButton()
		end
	end

	--自动战斗按钮
	local startData = bm:getStartData()
	if startData.battleType ~= BattleType.PLOT then
		self._autoPlayButton = BattleAutoPlayButton:create()
		self._autoPlayButton:setPosition(
			ccp(
				DisplayUtil.visibleSize.width - 90, 
				DisplayUtil.visibleSize.height - 35
			)
		)
		
		touchGroup:addWidget(self._autoPlayButton)
	end

	self._roundView = BattleRoundView:create()
	self._roundView:setPosition(
		DisplayUtil.visibleSize.width * 0.5, 
		DisplayUtil.visibleSize.height - 35
	)
	self._roundView:setVisible(false)
	self._uiLayer:addChild(self._roundView)

	if bm:showAccelerate() then
		
		self._accelerateView = BattleAccelerateView:create()
		self._accelerateView:setPosition(
			ccp(
				DisplayUtil.visibleSize.width * 0.15,
				DisplayUtil.visibleSize.height - 35
			)
		)
		touchGroup:addWidget(self._accelerateView)

	end

	--天空之役战斗
	if bm:getType() == BattleType.SKY_WAR then
		self._countdownView = BattleFightCountdownView:create()
		self._countdownView:setEnabled(false)
		self._countdownView:setMaxTime(startData.maxHandleTime)
		self._countdownView:setPosition(ccp(
			DisplayUtil.visibleSize.width * 0.5,
			DisplayUtil.visibleSize.height - 110
		))
		touchGroup:addWidget(self._countdownView)

		self._enemyFightImage = ImageView:create()
		self._enemyFightImage:loadTexture("i18n_enemy_handle.png", UI_TEX_TYPE_PLIST)
		self._enemyFightImage:setPosition(ccp(
			DisplayUtil.visibleSize.width * 0.5,
			DisplayUtil.visibleSize.height - 110
		))
		self._enemyFightImage:setEnabled(false)
		touchGroup:addWidget(self._enemyFightImage)
	end

	self:_createGemClearSystem()

end

function TouchBattleLayer:_initOBChildNode()

	self._avatarContainer = DisplayUtil.newNode()
	self._uiLayer:addChild(self._avatarContainer)

	local avatarBgImage = ImageView:create()
	avatarBgImage:loadTexture("bg_6.png", UI_TEX_TYPE_PLIST)
	avatarBgImage:setScale9Enabled(true)
	avatarBgImage:setCapInsets(CCRect(30, 30, 20, 20))
	avatarBgImage:setSize(CCSize(884, 172))
	avatarBgImage:setPosition(ccp(488, 115))
	avatarBgImage:setOpacity(160)
	self._avatarContainer:addChild(avatarBgImage)

	local touchGroup = TouchGroup:create()
	self._uiLayer:addChild(touchGroup)

	local function quitFunc(sender, event)
	    if event ~= TOUCH_EVENT_ENDED then
	    	return
	    end

	    WindowCtrl:getInstance():open(
	    	CmdName.Comm_MsgBox, 
	    	{
	    	    txt = "您需要退出觀戰嗎？",
			    okBtnName = "確定",
			    cancelBtnName = "取消",
			    isCloseAnimate = false,
			    okFunc = function()
				    BattleManager:getInstance():reqBattleEnd()
			    end
		    }
		)
	end

	local returnButton = Button:create()
	returnButton:loadTextureNormal("btn_up_6.png", UI_TEX_TYPE_PLIST)
	returnButton:loadTexturePressed("btn_down_6.png", UI_TEX_TYPE_PLIST)
	returnButton:setPosition(ccp(60, 600))
	returnButton:setTouchEnabled(true)
	returnButton:addTouchEventListener(quitFunc)
	touchGroup:addWidget(returnButton)

	self._accelerateView = BattleAccelerateView:create()
	self._accelerateView:setPosition(
		ccp(
			DisplayUtil.visibleSize.width * 0.15,                     --0.15
			DisplayUtil.visibleSize.height - 35
		)
	)
	touchGroup:addWidget(self._accelerateView)

	self._roundView = BattleRoundView:create()
	self._roundView:setPosition(
		DisplayUtil.visibleSize.width * 0.5, 
		DisplayUtil.visibleSize.height - 35
	)
	self._roundView:setVisible(false)
	self._uiLayer:addChild(self._roundView)

	local playbackImage = ImageView:create()
	playbackImage:loadTexture("i18n_bui_playback.png", UI_TEX_TYPE_PLIST)
	playbackImage:setPosition(ccp(886, 611))
	self._uiLayer:addChild(playbackImage)	

end

function TouchBattleLayer:_openPauseView(value)

	if not self._pauseView then
		self._pauseView = BattlePauseView:create()
		self._pauseView:retain()
	end

	if value then

		self._pauseLayer:addChild(self._pauseView)
	else
		self._pauseView:removeFromParentAndCleanup(false)
	end

end

function TouchBattleLayer:setRoundManager(value)
    self._roundManager = value
end

function TouchBattleLayer:createMap(sceneType, scenePathList, waveIndex)

	if isInitResolution == false then
		isInitResolution = true

		--单个地图设计尺寸
		local mapWidth = 1024
		local mapHeight = 615
		local maxScale = DisplayUtil.getNoBorderScaleValue(mapWidth, mapHeight)

		mapResolutionParams.sameScale = maxScale
		mapResolutionParams.mapScaleX = 1 / DisplayUtil.viewScale.x * maxScale
		mapResolutionParams.mapScaleY = 1 / DisplayUtil.viewScale.y * maxScale

		local finalWidth = mapWidth * maxScale
		local finalHeight = mapHeight * maxScale
		mapResolutionParams.finalSize = CCSizeMake(finalWidth, finalHeight)

		local finalPos = ccp(-(finalWidth - DisplayUtil.frameSize.width) * 0.5, -(finalHeight - DisplayUtil.frameSize.height) * 0.5)
		finalPos.x = finalPos.x * 1 / DisplayUtil.viewScale.x
		finalPos.y = finalPos.y * 1 / DisplayUtil.viewScale.y

		mapResolutionParams.finalPos = finalPos

		local moveToPos = ccp(-DisplayUtil.visibleSize.width * finalWidth / DisplayUtil.frameSize.width, finalPos.y)
		mapResolutionParams.mapMoveToPos = moveToPos

		mapResolutionParams.mapAndGamePercent = mapResolutionParams.finalSize.width / DisplayUtil.frameSize.width

	end

	if TouchBattleLayer._mapView == nil then

		TouchBattleLayer._mapView = BattleMapView:create()
		TouchBattleLayer._mapView:retain()
		TouchBattleLayer._mapView:setCrossType(sceneType)
		TouchBattleLayer._mapView:setScenePathList(scenePathList)

		TouchBattleLayer._mapView:setUserObject(CCInteger:create(0))

		TouchBattleLayer._mapView:setAnchorPoint(ccp(0, 0))
		TouchBattleLayer._mapView:setScaleX(mapResolutionParams.mapScaleX)
		TouchBattleLayer._mapView:setScaleY(mapResolutionParams.mapScaleY)

		TouchBattleLayer._mapView:setSceneIndex(waveIndex)

		TouchBattleLayer._mapView:setPosition(mapResolutionParams.finalPos.x, mapResolutionParams.finalPos.y)

	end

	self._numMap = TouchBattleLayer._mapView:getNumMapTile()

	-- TouchBattleLayer._mapView:removeFromParentAndCleanup(false)
	self._mapLayer:addChild(TouchBattleLayer._mapView)

end

function TouchBattleLayer:_registeEvent()

	--参战者对应的位置
	self._fighterPosDict = {}

	self:setTouchEnabled(true)
	
	--注册震屏事件
	local cbShakeScreen = function(param)
		self:shakeScreen(param)
	end
	Notifier.regist(CmdRegist.SHAKE_SCREEN, cbShakeScreen)

	self._onUpdateAutoPlay = function()
	    if self._autoPlayButton then
		    self._autoPlayButton:setAutoPlay(BattleManager:getInstance():getAutoPlay())
	    end
	    self._gemSystem:setAutoPlay(BattleManager:getInstance():getAutoPlay())
	end
	Notifier.regist(CmdName.BATTLE_UPDATE_AUTO_PLAY, self._onUpdateAutoPlay)


	if BattleManager:getInstance():getTreasureDungeonType() then
		local function onUpdateHurtTimes()
			local itemData = BattleManager:getInstance():getTreasureItem()
			self._treasureView:addTreasure(itemData.quantity)
		end
		Notifier.regist(CmdName.BATTLE_UPDATE_ENEMY_HURT_TIMES, onUpdateHurtTimes)
	end

	self._onUpdatePauseFunc = function()
    	self:_openPauseView(BattleManager:getInstance():isPause())
	end
	Notifier.regist(CmdName.BATTLE_UPDATE_PAUSE_STATUS, self._onUpdatePauseFunc)

	if self._accelerateView then

		self._onUpdateSpeedFunc = function(speed)
	    	self._accelerateView:updateSpeed(speed)
		end
		Notifier.regist(CmdName.BATTLE_UPDATE_ACCELERATE, self._onUpdateSpeedFunc)
	end
	
end
	
function TouchBattleLayer:_createFighterAvatar(index, entity)

	local avatarNode = BattleRoleAvatarNode:create()
	local bgPosition
	if BattleManager:getInstance():getIsOB() then
		bgPosition = AvatarPositionOB[index]
	else
		bgPosition = AvatarPosition[index]
	end

	-- local bgPosition = AvatarPosition[index]
	avatarNode:setPosition(ccp(bgPosition.x, bgPosition.y))
	
	avatarNode:setHeroInfo(entity:getBaseInfo())
	self._avatarContainer:addChild(avatarNode, bgPosition.z)

	entity:setAvatarNode(avatarNode)

	self._avatarList[index] = avatarNode

end

function TouchBattleLayer:_initFighterNode(battlePos, entityRole, displayPos)

	local fighterNode = BattleFighterNode:create()
    fighterNode:setEntityId(entityRole:getEntityID())
    fighterNode:setFighterData(entityRole)

    fighterNode:setPosition(ccp(displayPos.x, displayPos.y))
    fighterNode:setDefaultBodyHeight(
    	entityRole:getActionData().defaultBodyHeight
    )

    fighterNode:setBodyModel(entityRole:getBodyArmature())

    local z = BATTLE_LAYER_Z.normalFighter[battlePos]
    self._fighterLayer:addChild(fighterNode, z)
    
    --设置队员渲染节点
    entityRole:setRenderNode(fighterNode)

    self._fighterPosDict[entityRole:getEntityID()] = displayPos

end

function TouchBattleLayer:setSelfTeam(battleFieldPosition, entityRole)

    local position = ROLE_POSITION[battleFieldPosition]
    self:_initFighterNode(battleFieldPosition, entityRole, position)

    entityRole:setDirection(BattleType.directionType.RIGHT)

    if BattleManager:getInstance():getIsOB() then
	    --设置头像
	    self:_createFighterAvatar(entityRole:getTeamIndex(), entityRole)
	else
		self:_createFighterAvatar(battleFieldPosition, entityRole)
    end

	--设置头像
    -- self:_createFighterAvatar(battleFieldPosition, entityRole)

end

function TouchBattleLayer:setEnemyTeam(battleFieldPosition, entityRole)

    local position = MONSTER_POSITION[battleFieldPosition]
    self:_initFighterNode(battleFieldPosition, entityRole, position)

    entityRole:setDirection(BattleType.directionType.LEFT)

    --播放特效
    if entityRole:isRole() == false then
    	local despotEffect = entityRole:getBaseInfo().despot_effect
    	if despotEffect ~= 0 then
    		BattleController:getInstance():playEffectWithEntity(
    			entityRole:getEntityID(), 
    			{despotEffect}
    		)
    	end
    end

end

function TouchBattleLayer:updateAvatarPos()

	local numAvatar = #self._avatarList
	local width = 884

	local avatarNode

	local beginPosX = (width - ((numAvatar - 1) * 115 + 140)) * 0.5

	for i = 1, numAvatar do
		avatarNode = self._avatarList[i]
		avatarNode:setPosition(ccp(beginPosX + i * 115, 125))
	end

end

function TouchBattleLayer:updateRound(roundNum)

	self._roundView:setRound(roundNum)
end

function TouchBattleLayer:uninit()

	self._moveFighterFuncDict = nil
	self._moveFighterParamDict = nil

	self._mapNode = nil
	
	Notifier.removeByName(CmdRegist.SHAKE_SCREEN)
	
	Notifier.remove(CmdName.BATTLE_RSP_RESULT, self._onRspResultFunc)

	Notifier.remove(CmdName.BATTLE_UPDATE_AUTO_PLAY, self._onUpdateAutoPlay)
	Notifier.remove(CmdName.BATTLE_UPDATE_PAUSE_STATUS, self._onUpdatePauseFunc)

	Notifier.removeByName(CmdName.BATTLE_UPDATE_ENEMY_HURT_TIMES)

	Notifier.remove(CmdName.BATTLE_UPDATE_ACCELERATE, self._onUpdateSpeedFunc)
	
	self:unscheduleUpdate()

	BattleWindowManager:getInstance():closeAllWindow()

	self._roundView:removeFromParentAndCleanup(true)
	self._roundView = nil

	self._fighterPosDict = nil

	if self._hitsView then
		self._hitsView:dispose()
		self._hitsView:removeFromParentAndCleanup(true)
		self._hitsView = nil
	end

	-- if self._statisticView then
	-- 	self._statisticView:release()
	-- end
	-- self._statisticView = nil

	if self._treasureView then
		self._treasureView:dispose()
		self._treasureView:removeFromParentAndCleanup(true)
		self._treasureView = nil
	end

	if self._gemSystem then
		self._gemSystem:quitBattle()
		self._gemSystem:dispose()
		self._gemSystem:removeFromParentAndCleanup(true)
		self._gemSystem = nil
	end

	if self._autoPlayButton then
		self._autoPlayButton:removeFromParentAndCleanup(true)
		self._autoPlayButton = nil
	end

	if self._pauseView then
		self._pauseView:release()
	end

	EffectManager:getInstance():clearEffect(self._bottomEffectLayer)
	EffectManager:getInstance():clearEffect(self._topEffectLayer)

	self:removeAllChildrenWithCleanup(true)

end


function TouchBattleLayer:_createGemClearSystem()

	self._gemSystem = EliminateStone:create()
	self._gemSystem:enterBattle()

	local onClearStone = function(gemColor, gemNums, additionPercent, isTimeOut)

	    if self._countdownView then
			self._countdownView:setEnabled(false)
			self._countdownView:stop()
		end

		if isTimeOut then
			BattleManager:getInstance():reqUpdateAutoPlay(true)
		end

	    local startData = BattleManager:getInstance():getStartData()
		local endGemTime = os.time()
		local diffTime = endGemTime - self._beginGemTime
		local enemyTimeData = CombatDataStorage:getInstance():getEnemyTimeData(
			startData.id, 
			startData.subId, 
			diffTime
		)

		local argGemClearSys = {}
		argGemClearSys.gemColor = gemColor
		argGemClearSys.gemNums = gemNums
		argGemClearSys.additionPercent = additionPercent

		local function invoke()
			if self._enemyFightImage then
				self._enemyFightImage:setEnabled(false)
			end
			self._roundManager:roundInvoke(argGemClearSys)
		end

		if enemyTimeData then
			if self._enemyFightImage then
				self._enemyFightImage:setEnabled(true)
			end
			local dist = math.random(enemyTimeData.enemyMinTime, enemyTimeData.enemyMaxTime)
			TimerManager.addTimer(dist*1000, invoke, false)
		else
			invoke()
		end

		--连线完成
		Notifier.dispatchCmd(GuideEvent.LineFinish)
	end
	self._gemSystem:registPlayCallFunc(onClearStone)
	
	local layerWinSize = CCDirector:sharedDirector():getWinSize()
	local gemClearBG = CCSprite:createWithSpriteFrameName("bui_stone_panel.png")
	gemClearBG:setAnchorPoint(ccp(0, 0))

	local bgSize = gemClearBG:getContentSize()
	TouchBattleLayer._eliminateContainerPos = ccp(DisplayUtil.visibleSize.width - bgSize.width, 0)

	self._eliminateContainer:setPosition(TouchBattleLayer._eliminateContainerPos)

	self._gemSystem:setAnchorPoint(ccp(0,0))
	self._gemSystem:setPosition(ccp(53, 46))

	self._eliminateContainer:addChild(gemClearBG)
	self._eliminateContainer:addChild(self._gemSystem)

end

function TouchBattleLayer:beginGemClear()

	self._beginGemTime = os.time()
	
	if self._countdownView then
		local function onCountdown()
			self._countdownView:setEnabled(false)
		end
		self._countdownView:setEnabled(true)
		self._countdownView:begin(onCountdown)
	end

	if BattleManager:getInstance():getType() == BattleType.RIDDLE_DUNGEON then
		if not self._gemSystem:isFillComplete() then
			self._gemSystem:clearStone()
		end
	end
	self._gemSystem:beginPlay()


end

function TouchBattleLayer:displayWinLayer(resultData)

	BattleWindowManager:getInstance():openWindow(
		BattleWindowType.SETTLEMENT_VIEW, 
		resultData
	)
end

function TouchBattleLayer:displayFailLayer(resultData)

	BattleWindowManager:getInstance():openWindow(
		BattleWindowType.FAIL_VIEW, 
		resultData
	)
end

--显示数据统计界面
function TouchBattleLayer:showStatisticView(statisticData)

	BattleWindowManager:getInstance():openWindow(BattleWindowType.STATISTIC_VIEW, statisticData)
end

function TouchBattleLayer:shakeScreen(params)

	local count = 0
	if params.shakeNum~=nil then
		count = params.shakeNum
	end

	if count == 0 then
		return
	end

	self._sceneLayer:setPosition(ccp(0, 0))
	self._sceneLayer:stopAllActions()


	local xDist = 12
	local yDist = 12

	local moveTime = 0.06

	local function createDirection()
		-- local rawDirection = {1, 2, 3, 4}
		local rawDirection = {2, 4}
		MathUtil.shuffleList(rawDirection)
		return rawDirection
	end

	local actionArray = CCArray:create()	

	for i = 1, count do

		local randomDirection = createDirection()

		for lap = 1, 3 do
			for i1, dir in ipairs(randomDirection) do

				local moveToPos = ccp(0, 0)
				if dir == 1 then
					moveToPos.x = -xDist
				elseif dir == 2 then
					moveToPos.y = yDist
				elseif dir == 3 then
					moveToPos.x = xDist
				else
					moveToPos.y = -yDist
				end

				local moveAction = CCMoveTo:create(moveTime, moveToPos)
				actionArray:addObject(moveAction)

			end
		end
		
	end

	actionArray:addObject(CCCallFunc:create(function() 
		self._sceneLayer:setPosition(ccp(0, 0)) 
		end))

	self._sceneLayer:runAction(CCSequence:create(actionArray))

end

function TouchBattleLayer:displayHurtNum(param)

	local target = param.node
	local hurtNum = param.hurtNum
	
	if hurtNum == nil or hurtNum == 0 then
		return
	end

	local rep = param.rep or 1  --重复量
	
	for i=1,rep do

		local delayAction = CCDelayTime:create((i - 1) * 0.2)
		local moveAction = CCMoveBy:create(0.3, ccp(0, 100))
		local zoomInAction = CCScaleTo:create(0.3, 1.4)
		local spawnAction = CCSpawn:createWithTwoActions(moveAction, zoomInAction)
		local easeAction = CCEaseIn:create(spawnAction, 0.2)
		local delayAction2 = CCDelayTime:create(0.2)
		local zoomOutAction = CCScaleTo:create(0.2, 1)
		local callAction = CCCallFuncN:create(function(node)
	    	local lastCout = tolua.cast(target:getUserObject(),"CCInteger"):getValue()
	    	if lastCout > 0 then
	    		target:setUserObject(CCInteger:create(lastCout - 1))
	    	end
	    	node:removeFromParentAndCleanup(true)
	    end)

		local hurtNumSkin = self:getBattleFloatText(param)
	    target:addDynamicText(hurtNumSkin)

	    ActionManager:getInstance():runSequenceActions(
	    	hurtNumSkin, 
	    	delayAction, 
	    	easeAction, 
	    	delayAction2,
	    	zoomOutAction, 
	    	callAction
	    )

	end
	--默认延时
	local lastCout = tolua.cast(target:getUserObject(),"CCInteger"):getValue()
	target:setUserObject(CCInteger:create(lastCout + 1))
	
end

--[[
    显示miss
]]
function TouchBattleLayer:displayTriggerText(fighterNode, textType)

	local textSprite

	if textType == 1 then
		textSprite = CCSprite:createWithSpriteFrameName("bui_miss_label.png")
	elseif textType == 2 then
		textSprite = CCSprite:createWithSpriteFrameName("i18n_bui_block_label.png")
	end

	if not textSprite then
		return
	end

	local moveAction = CCMoveBy:create(0.3, ccp(0, 100))
	local zoomInAction = CCScaleTo:create(0.3, 1.4)
	local spawnAction = CCSpawn:createWithTwoActions(moveAction, zoomInAction)
	local easeAction = CCEaseIn:create(spawnAction, 0.2)
	local delayAction2 = CCDelayTime:create(0.2)
	local zoomOutAction = CCScaleTo:create(0.2, 1)
	local callAction = CCCallFuncN:create(
		function(sprite) 
			sprite:removeFromParentAndCleanup(true) 
		end)

	fighterNode:addDynamicText(textSprite)

	ActionManager:getInstance():runSequenceActions(
	    textSprite, 
    	easeAction, 
    	delayAction2,
    	zoomOutAction, 
    	callAction
    )

end

--[[
    显示添加buff效果
]]
function TouchBattleLayer:displayAddBuffEffect(fighterNode, buffData)

	local addEffect = BuffAddEffect:create(buffData)

	local container = fighterNode:getInfoContainer()
	container:addChild(addEffect)
	-- local bodySize = fighterNode:getBodySize()
	local bodySize = fighterNode:getDefaultBodySize()

	local targetPos

	if buffData.nature == BuffNatureType.BENIGN then
		addEffect:setPosition(ccp(0, bodySize.height))

		targetPos = ccp(0, bodySize.height + 80)
	else
		addEffect:setPosition(ccp(0, bodySize.height + 80))

		targetPos = ccp(0, bodySize.height)
	end

	local moveAction = CCMoveTo:create(0.5, targetPos)
	local callAction = CCCallFuncN:create(function(effect) 
		    effect:showImpactProperty()
		end)

	local delayAction = CCDelayTime:create(1)
	local callAction2 = CCCallFuncN:create(function(effect)
	    effect:removeFromParentAndCleanup(true) 
    end)

    ActionManager:getInstance():runSequenceActions(
    	addEffect, 
    	moveAction, 
    	callAction, 
    	delayAction, 
    	callAction2
    )


end

--[[
    合并
]]
function TouchBattleLayer:getBattleFloatText(param)

	local totalWidth = 0

	local node = CCNode:create()
	local nodeContainer = CCNode:create()
	node:addChild(nodeContainer)

	local numSkin = self:getNumSkin(param.hurtNum, param.isCrit, param.isTotalNum)
	numSkin:setAnchorPoint(ccp(0, 0.5))

	local labelSprite

	if param.isCrit then
		
		-- labelSprite = CCSprite:createWithSpriteFrameName("i18n_bui_crit_label.png")

	elseif param.isTotalNum then

		labelSprite = CCSprite:createWithSpriteFrameName("i18n_bui_total_damage_label.png")
	end

	if labelSprite then

		labelSprite:setAnchorPoint(ccp(0, 0.5))
		nodeContainer:addChild(labelSprite)

		numSkin:setPosition(ccp(labelSprite:getContentSize().width, 0))

		totalWidth = totalWidth + labelSprite:getContentSize().width
	end

	totalWidth = totalWidth + numSkin:getContentSize().width

	nodeContainer:addChild(numSkin)
	nodeContainer:setPosition(ccp(-totalWidth * 0.5, 0))

	return node

end

--[[
    获取数字皮肤
    @param isCrit 是否暴击
    @param isTotalNum 是否总伤害
]]
function TouchBattleLayer:getNumSkin(hurtNum, isCrit, isTotalNum)

	local labelWidth = 0
	local labelHeight = 0

	local HurtTypeEnum = {plus = ";", minus = ":"} --枚举 加 减
	local hurtType
	local resFilePath = nil
	if hurtNum>0 then
		hurtType = HurtTypeEnum.plus
		resFilePath = "bui_gain_num"
		labelWidth = 280
		labelHeight = 30
	else
		
		hurtType = HurtTypeEnum.minus
		if isTotalNum then
			resFilePath = "bui_total_damage_num"
			labelWidth = 300
			labelHeight = 32
		elseif isCrit then
			resFilePath = "bui_crit_num"
			labelWidth = 360
			labelHeight = 38
		else
			resFilePath = "bui_damage_num"
			labelWidth = 280
			labelHeight = 30
		end
	end

	local filePath = string.format("ui/digit/%s.png",resFilePath)
	local numStr = string.format("%s%d",hurtType,math.abs(hurtNum))
	local labNum = CCLabelAtlas:create(numStr,filePath,labelWidth/12,labelHeight,48)
	return labNum
end

--[[
    显示副本奖励
]]
function TouchBattleLayer:displayTreasureText(node, num)

	local filePath = "ui/digit/bui_treasure_num.png"
	local numStr
	if num < 1 then
		numStr = string.format("%s%.1f", ";", num)
	else
		numStr = string.format("%s%d", ";", num)
	end
	local labNum = CCLabelAtlas:create(numStr, filePath, 31, 41, 46)
	labNum:setAnchorPoint(ccp(0.5, 0.5))

	local moveAction = CCMoveBy:create(0.3, ccp(0, 100))
	local zoomInAction = CCScaleTo:create(0.3, 1.4)
	local spawnAction = CCSpawn:createWithTwoActions(moveAction, zoomInAction)
	local easeAction = CCEaseIn:create(spawnAction, 0.2)
	local delayAction2 = CCDelayTime:create(0.2)
	local zoomOutAction = CCScaleTo:create(0.2, 1)
	local callAction = CCCallFuncN:create(
		function(sprite) 
			sprite:removeFromParentAndCleanup(true) 
		end)

	node:addDynamicText(labNum)

	ActionManager:getInstance():runSequenceActions(
		labNum, 
    	easeAction, 
    	delayAction2,
    	zoomOutAction, 
    	callAction
    )

end

--[[
    移动到目标
    @param entityId
    @param targetId
    @param time s
    @param attackDist 攻击距离
    @param callFunc func(entityId)
]]
function TouchBattleLayer:moveFighterToTarget(entityId, targetId, time, attackDist, callFunc)

	local entity = EntityManager:getInstance():getEntityWithID(entityId)
	local target = EntityManager:getInstance():getEntityWithID(targetId)

	if not entity or not target then

		if callFunc then
			callFunc(entityId)
		end

		return
	end

	local node = entity:getRenderNode()
	local targetNode = target:getRenderNode()

	local entityPos = ccp(node:getPosition())
	local targetPos = ccp(targetNode:getPosition())

	local offsetX = 0
	if moveFighterToTarget == 0 then
		if targetPos.x > entityPos.x then
			offsetX = -80
		else
			offsetX = 80
		end
	else
		if targetPos.x > entityPos.x then
			offsetX = -attackDist
		else
			offsetX = attackDist
		end
	end

	targetPos.x = targetPos.x + offsetX

	self:moveFighter(entity, targetPos, time, callFunc, entityId)

end

function TouchBattleLayer:moveFighter(fighter, targetPos, time, callFunc, param)

	self._moveFighterFuncDict[fighter:getEntityID()] = callFunc
	self._moveFighterParamDict[fighter:getEntityID()] = param

	local function moveEnd(node)

		local callFunc = self._moveFighterFuncDict[node:getEntityID()]
		local param = self._moveFighterParamDict[node:getEntityID()]
		if callFunc then
			callFunc(param)
		end

		self._moveFighterFuncDict[node:getEntityID()] = nil
		self._moveFighterParamDict[node:getEntityID()] = nil
		
	end

	local node = fighter:getRenderNode()

	local entityPos = ccp(node:getPosition())

	if targetPos.x > entityPos.x then
		fighter:setDirection(BattleType.directionType.RIGHT)
	else
		fighter:setDirection(BattleType.directionType.LEFT)
	end

	local actionArray = CCArray:create()

	actionArray:addObject(Act_Factory:getRunAction(fighter, true))
	actionArray:addObject(Act_Factory:getMoveToAction(time, targetPos.x, targetPos.y))

	local callAction = CCCallFuncN:create(moveEnd)
	actionArray:addObject(callAction)

	node:runAction(CCSequence:create(actionArray))

end

--[[
    移动参战者到原始的位置
]]
function TouchBattleLayer:moveFighterToOriginalPos(entityId, time, callFunc)

	local entity = EntityManager:getInstance():getEntityWithID(entityId)

	local position = self._fighterPosDict[entityId]

	self:moveFighter(entity, position, time, callFunc, entityId)

end

--只是显示地图
function TouchBattleLayer:showMapOnly(value)

	if value == true then
		self._fighterLayer:setVisible(false)
		self._effectLayer:setVisible(false)
		self._bottomEffectLayer:setVisible(false)
		self._uiLayer:setVisible(false)
	else
		self._fighterLayer:setVisible(true)
		self._effectLayer:setVisible(true)
		self._bottomEffectLayer:setVisible(true)
		self._uiLayer:setVisible(true)
	end
	
end

--[[
    
]]
function TouchBattleLayer:moveMapBy(xDist, callback, time)

	local mapPosX, mapPosY = TouchBattleLayer._mapView:getPosition()
	local targetX = (mapPosX + mapResolutionParams.finalPos.x) / mapResolutionParams.mapAndGamePercent

	-- targetX = targetX + xDist
	targetX = mapPosX + xDist * mapResolutionParams.mapAndGamePercent

	self:moveMapTo(targetX, callback, time)
    --debug
	-- self._mapLayer:runAction(CCMoveBy:create(time,ccp(xDist,mapResolutionParams.finalPos.y)))
end

function TouchBattleLayer:jumpMapTo(x)
	self._mapLayer:stopAllActions()
	self._mapLayer:setPositionX(x)
end

function TouchBattleLayer:moveMapToNext()
	self:moveMapTo(
		DisplayUtil.visibleSize.width * (
			BattleManager:getInstance():getWaveIndex() - 1
		)
	)
end

--[[
    移动地图至
]]
function TouchBattleLayer:moveMapTo(xDist, callback, time)

	local currentWaveIndex = BattleManager:getInstance():getWaveIndex()

	local numMap = 0
	if currentWaveIndex >= self._numMap then
		numMap = self._numMap - 1
	else
		numMap = currentWaveIndex
	end
	local endSide = (numMap) * DisplayUtil.visibleSize.width

	if xDist < 0 then
		xDist = 0
	elseif xDist > endSide then
		xDist = endSide
	end

	xDist = xDist * mapResolutionParams.mapAndGamePercent - mapResolutionParams.finalPos.x

	time = time or 2

	local moveToAction = CCMoveTo:create(time, ccp(-xDist, mapResolutionParams.finalPos.y))
	local callAction = CCCallFunc:create(function() 
		if callback then 
			callback() 
		end
	end)

	TouchBattleLayer._mapView:runAction(CCSequence:createWithTwoActions(moveToAction, callAction))
	-- self._mapLayer:runAction(CCSequence:createWithTwoActions(moveToAction, callAction))

end

function TouchBattleLayer:showHitsView(currentTimes, totalTimes)

	if self._hitsView == nil then
		self._hitsView = BattleHitsView:create()
		self._hitsView:setPosition(ccp(DisplayUtil.visibleSize.width - 120, 580))
		self._uiLayer:addChild(self._hitsView)
	end

	self._hitsView:setHitTimes(currentTimes, totalTimes)

end

--[[
    显示新阶段
]]
function TouchBattleLayer:showNewPhase()

	if self._phaseView == nil then

		self._phaseView = BattlePhaseView:create()
		self._phaseView:setPosition(
			ccp(
				DisplayUtil.visibleSize.width*0.5, 
				DisplayUtil.visibleSize.height*0.75
			)
		)

		self._uiLayer:addChild(self._phaseView)

	end

	local processData = BattleManager:getInstance():getProcessData()

	local wave = processData:getWaveIndex()
	local totalWave = processData:getWaveTotalIndex()

	self._phaseView:setPhase(wave, totalWave)
	self._phaseView:playAction()

	self._roundView:setWave(wave, totalWave)

end

--[[
    显示回合界面
]]
function TouchBattleLayer:showRoundView()

	self._roundView:setVisible(true)
	self._roundView:setOpacity(0)
	local delayAction = CCDelayTime:create(0.2)
	local fadeAction = CCFadeTo:create(0.5, 255)

	self._roundView:runAction(
		CCSequence:createWithTwoActions(
			delayAction, 
			fadeAction
		)
	)

end

--[[
    开始战斗时移动UI
]]
function TouchBattleLayer:moveUIWithStart()

	self._avatarContainer:stopAllActions()
	self._eliminateContainer:stopAllActions()

	self._avatarContainer:setPosition(
			ccp(
				TouchBattleLayer._avatarContainerPos.x-550, 
				TouchBattleLayer._avatarContainerPos.y
			)
		)

	local moveAction = CCMoveTo:create(0.8, TouchBattleLayer._avatarContainerPos)
	local easeAction = CCEaseBackIn:create(moveAction)
	ActionManager:getInstance():runSequenceActions(self._avatarContainer, easeAction)

	local eliminatePos = TouchBattleLayer._eliminateContainerPos
	self._eliminateContainer:setPosition(
			ccp(DisplayUtil.visibleSize.width + 611, 0)
		)
	moveAction = CCMoveTo:create(0.8, eliminatePos)
	easeAction = CCEaseBackIn:create(moveAction)
	ActionManager:getInstance():runSequenceActions(self._eliminateContainer, easeAction)

end

function TouchBattleLayer:showUI()
	self._uiLayer:setVisible(true)
end

--[[
    战斗结束隐藏UI
]]
function TouchBattleLayer:hideUI()

	self._uiLayer:setVisible(false)
end

--[[
    是否显示奥义阴影
]]
function TouchBattleLayer:showUpanisadShadow(value)

	if self._isShowUpanisadShadow == value then
		return
	end

	self._isShowUpanisadShadow = value

	local fadeAction

	if self._isShowUpanisadShadow == true then

		self._upanisadLayerColor:setVisible(true)
		self._upanisadLayerColor:setOpacity(0)

		fadeAction = CCFadeTo:create(0.2, 150)
		self._upanisadLayerColor:runAction(fadeAction)

	else

		fadeAction = CCFadeTo:create(0.1, 0)
		local callAction = CCCallFunc:create(function()
			self._upanisadLayerColor:setVisible(false)
		end)

		self._upanisadLayerColor:runAction(fadeAction)

	end

end


--[[
    清除地图
]]
function TouchBattleLayer:clearMap()

	TouchBattleLayer._mapView:dispose()
	TouchBattleLayer._mapView:release()
	TouchBattleLayer._mapView = nil
end

--[[
    获取地图节点
]]
function TouchBattleLayer:getMapNode()
    return TouchBattleLayer._mapView
end

--[[
    特效容器
]]
function TouchBattleLayer:getEffectContainer()
	return self._effectLayer
end

--[[
    特效下层容器
]]
function TouchBattleLayer:getBottomEffectContainer()
	return self._bottomEffectLayer
end

function TouchBattleLayer:getUILayer()
	return self._uiLayer
end

function TouchBattleLayer:calcMapMovePos(rawDist)
	return rawDist * mapResolutionParams.mapAndGamePercent
end

function TouchBattleLayer:addAnimationToMap(animation)
	TouchBattleLayer._mapView:addChild(animation)
end

--[[
    获取参战者原始的位置
]]
function TouchBattleLayer:getFighterPos(entityId)
	return self._fighterPosDict[entityId]
end

function TouchBattleLayer:getFighterLayer()
	return self._fighterLayer
end

--剧情层次
function TouchBattleLayer:getPlotLayer()
	return self._plotLayer
end

function TouchBattleLayer:getHeroAnimLayer()
	return self._heroAnimLayer
end




--战斗地图
BattleMapView = class("BattleMapView", DisplayUtil.newNode)

--场景路径列表
BattleMapView._scenePathList = nil

BattleMapView._currentSceneIndex = 0
BattleMapView._totalSceneIndex = 0

BattleMapView._numTile = -1

BattleMapView._currentScenePath = nil

--地图块1
BattleMapView._mapTileSprite = nil
--地图块2
BattleMapView._mapTileSprite2 = nil

--过场类型
BattleMapView._crossType = 0

--路径字典
BattleMapView._tilePathDict = nil

function BattleMapView:ctor()

	self._tilePathDict = {}
end

function BattleMapView:setScenePathList(value)
	self._scenePathList = value
	self._totalSceneIndex = #self._scenePathList
end

function BattleMapView:setCrossType(value)
	self._crossType = value
end

function BattleMapView:setSceneIndex(index)

	if index > self._totalSceneIndex then
		return
	end

	if self._currentSceneIndex == index then
		return
	end

	self._currentSceneIndex = index

	if self._crossType == BattleSceneType.SINGLE then

		if self._mapTileSprite == nil then
			self._mapTileSprite = self:_createMapTile(self._currentSceneIndex)

			self:addChild(self._mapTileSprite)
		end

	elseif self._crossType == BattleSceneType.REPLACE then

		local path = self._scenePathList[self._currentSceneIndex]

		if self._currentScenePath == path then
			return
		end

		if self._mapTileSprite then
			self._mapTileSprite:removeFromParentAndCleanup(true)
		end

		self._mapTileSprite = self:_createMapTile(self._currentSceneIndex)

		self:addChild(self._mapTileSprite)

	elseif self._crossType == BattleSceneType.SCROLL then

		if self._mapTileSprite then
			self._mapTileSprite:removeFromParentAndCleanup(true)
		end

		if self._mapTileSprite2 then
			self._mapTileSprite = self._mapTileSprite2
			-- self._mapTileSprite:setPosition(ccp(0, 0))
			self._mapTileSprite2 = nil
		else
			self._mapTileSprite = self:_createMapTile(self._currentSceneIndex)
			self:addChild(self._mapTileSprite)
		end

		if self._currentSceneIndex < self._totalSceneIndex then

			self._mapTileSprite2 = self:_createMapTile(self._currentSceneIndex + 1)
			self._mapTileSprite2:setPosition(ccp(
				self._mapTileSprite:getContentSize().width * (self._currentSceneIndex), 
				0)
			)

			self:addChild(self._mapTileSprite2)
		end

	end

end

function BattleMapView:_createMapTile(sceneIndex)

	local path = self._scenePathList[sceneIndex]

	self._currentScenePath = path

	self._tilePathDict[path] = true

	local sprite = CCSprite:create(path)
	sprite:setAnchorPoint(ccp(0, 0))
	return sprite

end

function BattleMapView:getNumMapTile()
	
	if self._numTile == -1 then
		if self._crossType == BattleSceneType.SCROLL then
			self._numTile = self._totalSceneIndex
		else
			self._numTile = 1
		end
	end

	return self._numTile

end

function BattleMapView:dispose()

	for path, _ in pairs(self._tilePathDict) do
		CCTextureCache:sharedTextureCache():removeTextureForKey(path)
	end
end

function BattleMapView:create()
	local mapView = BattleMapView.new()

	return mapView
end


BattleHitsView = class("BattleHitsView", DisplayUtil.newNode)

BattleHitsView._bgSprite = nil

BattleHitsView._hitsLabel = nil

BattleHitsView._timesLabel = nil

BattleHitsView._isShow = false

--当前次数
BattleHitsView._currentTimes = 0
--总次数
BattleHitsView._totalTimes = 0

function BattleHitsView:ctor()

	self._onShowTimes = function()
	    self:_showTimes()
	end

	self._bgSprite = CCSprite:createWithSpriteFrameName("bui_hits_bg.png")
	self:addChild(self._bgSprite)
end

function BattleHitsView:setHitTimes(currentTimes, totalTimes)

	if self._timesLabel == nil then
		self._timesLabel = CCLabelAtlas:create(
			tostring(currentTimes),
			"ui/digit/bui_batter_hits_num.png",
			540/10,
			57,
			48
		)

		self._timesLabel:setAnchorPoint(ccp(0.5, 0.5))

		self._timesLabel:setPosition(ccp(-50, 0))

		self:addChild(self._timesLabel)

		self._hitsLabel = CCSprite:createWithSpriteFrameName("bui_hits_label.png")
		self._hitsLabel:setPosition(ccp(50, 0))
		self:addChild(self._hitsLabel)

	end

	self:setVisible(true)

	if self._isShow == false then

		self._isShow = true

		self:setScale(0)
		local action = CCScaleTo:create(0.1, 1)
		self:runAction(action)

	end

	self._currentTimes = currentTimes
	self._totalTimes = totalTimes

	self._timesLabel:setString(tostring(self._currentTimes))

	if self._currentTimes >= self._totalTimes then
		self._timesLabel:stopAllActions()
		local delayAction = CCDelayTime:create(1)
		local callAction = CCCallFunc:create(function() 
			self:setVisible(false)
			self._isShow = false
		end)

		self._timesLabel:runAction(CCSequence:createWithTwoActions(delayAction, callAction))
	end

	-- TimerManager.addTimer(80, self._onShowTimes, true, nil, "showTimes")

end

function BattleHitsView:_showTimes()

	self._timesLabel:setString(tostring(self._currentTimes))

	self._currentTimes = self._currentTimes + 1

	if self._currentTimes > self._totalTimes then
		TimerManager.removeTimer(self._onShowTimes)
		self._timesLabel:stopAllActions()
		local delayAction = CCDelayTime:create(1)
		local callAction = CCCallFunc:create(function() 
			self:setVisible(false)
			self._isShow = false
		end)

		self._timesLabel:runAction(
			CCSequence:createWithTwoActions(delayAction, callAction)
		)
	end

end

function BattleHitsView:dispose()
	TimerManager.removeTimer(self._onShowTimes)
end

function BattleHitsView:create()

	local hitsView = BattleHitsView.new()

	return hitsView

end


BattlePhaseView = class("BattlePhaseView", DisplayUtil.newNode)

BattlePhaseView._container = nil

BattlePhaseView._bgSprite = nil
BattlePhaseView._leftNumLabel = nil
BattlePhaseView._slashSprite = nil
BattlePhaseView._rightNumLabel = nil

function BattlePhaseView:ctor()

	self._container = CCNode:create()
	self:addChild(self._container)

	self._bgSprite = CCSprite:createWithSpriteFrameName("bui_phase_bg.png")
	self._container:addChild(self._bgSprite)

	local labelWidth = 401/10
	local labelHeight = 56
	local labelPath = "ui/digit/bui_phase_num.png"

	self._leftNumLabel = CCLabelAtlas:create("1", labelPath, labelWidth, labelHeight, 48)
	self._leftNumLabel:setAnchorPoint(ccp(0.5, 0.5))
	self._leftNumLabel:setPosition(ccp(-55, 0))
	self._container:addChild(self._leftNumLabel)

	self._slashSprite = CCSprite:createWithSpriteFrameName("bui_phase_slash.png")
	self._slashSprite:setPosition(ccp(0, 0))
	self._container:addChild(self._slashSprite)

	self._rightNumLabel = CCLabelAtlas:create("3", labelPath, labelWidth, labelHeight, 48)
	self._rightNumLabel:setAnchorPoint(ccp(0.5, 0.5))
	self._rightNumLabel:setPosition(ccp(55, 0))
	self._container:addChild(self._rightNumLabel)

end

function BattlePhaseView:setPhase(currentPhase, totalPhase)

	self._leftNumLabel:setString(tostring(currentPhase))
	self._rightNumLabel:setString(tostring(totalPhase))

end

function BattlePhaseView:playAction()

	self:setVisible(true)

	local time = 0.1

	self._bgSprite:setScaleX(2)
	local bgScaleAction = CCScaleTo:create(time, 1, 1)
	self._bgSprite:runAction(bgScaleAction)

	self._leftNumLabel:setPosition(ccp(-110, 0))
	local moveAction = CCMoveTo:create(time, ccp(-55, 0))
	self._leftNumLabel:runAction(moveAction)

	self._rightNumLabel:setPosition(ccp(110, 0))
	moveAction = CCMoveTo:create(time, ccp(55, 0))
	self._rightNumLabel:runAction(moveAction)

	local delayAction = CCDelayTime:create(0.5)
	local callAction = CCCallFunc:create(function() self:setVisible(false) end)

	ActionManager:getInstance():runSequenceActions(
		self._container, 
		delayAction, 
		callAction
	)

end

function BattlePhaseView:create()

	local bpv = BattlePhaseView.new()

	return bpv
end



BattleRoundView = class("BattleRoundView", DisplayUtil.newColorNode)

BattleRoundView._bgSprite = nil
BattleRoundView._labelSprite = nil

BattleRoundView._roundLabel = nil

function BattleRoundView:ctor()

	self:setCascadeOpacityEnabled(true)

	-- self._bgSprite = CCSprite:createWithSpriteFrameName("bui_round_bg.png")
	-- self:addChild(self._bgSprite)

	self._labelSprite = CCSprite:createWithSpriteFrameName("i18n_bui_round_label.png")
	self:addChild(self._labelSprite)

	self._roundLabel = CCLabelAtlas:create("1", "ui/digit/bui_round_num.png", 18, 26, 48)
	self._roundLabel:setAnchorPoint(ccp(0.5, 0.5))
	self._roundLabel:setPosition(ccp(110, -3))
	self:addChild(self._roundLabel)

	self._currentWaveLabel = CCLabelAtlas:create("1", "ui/digit/bui_round_num.png", 18, 26, 48)
	self._currentWaveLabel:setAnchorPoint(ccp(0.5, 0.5))
	self._currentWaveLabel:setPosition(ccp(-53, -3))
	self:addChild(self._currentWaveLabel)

	self._totalWaveLabel = CCLabelAtlas:create("1", "ui/digit/bui_round_num.png", 18, 26, 48)
	self._totalWaveLabel:setAnchorPoint(ccp(0.5, 0.5))
	self._totalWaveLabel:setPosition(ccp(-15, -3))
	self:addChild(self._totalWaveLabel)

end

function BattleRoundView:setRound(value)

	self._roundLabel:setString(tostring(value))

	self._roundLabel:setScale(3)

	local scaleAction = CCScaleTo:create(0.2, 1)
	self._roundLabel:runAction(scaleAction)

end

function BattleRoundView:setWave(currentWave, totalWave)
	self._currentWaveLabel:setString(tostring(currentWave))
	self._totalWaveLabel:setString(tostring(totalWave))
end

function BattleRoundView:create()

	local rv = BattleRoundView.new()
	return rv
end


BattleAutoPlayButton = class("BattleAutoPlayButton", DisplayUtil.newWidget)

BattleAutoPlayButton._closeImage = nil
BattleAutoPlayButton._settingImage = nil

BattleAutoPlayButton._button = nil

BattleAutoPlayButton._label = nil

BattleAutoPlayButton._isAutoPlay = nil

BattleAutoPlayButton._autoBattleLabel = nil
BattleAutoPlayButton._autoSettingLabel = nil

function BattleAutoPlayButton:ctor()

	local function onChangeAutoPlay(sender, event)

		if event ~= TOUCH_EVENT_ENDED then
			return
		end

		BattleManager:getInstance():reqUpdateAutoPlay(not self._isAutoPlay)

	end

	-- self._button = Button:create()
	-- self._button:loadTextureNormal("bui_auto_button_up.png", UI_TEX_TYPE_PLIST)
	-- self._button:loadTexturePressed("bui_auto_button_down.png", UI_TEX_TYPE_PLIST)
	-- self._button:setTouchEnabled(true)
	-- self._button:addTouchEventListener(onChangeAutoPlay)
	-- self:addChild(self._button)

	-- local buttonSize = self._button:getSize()

	-- self._closeImage = ImageView:create()
 --    self._closeImage:loadTexture("bui_auto_close.png", UI_TEX_TYPE_PLIST)
	-- self._closeImage:setPosition(ccp(-buttonSize.width * 0.5 + 30, 0))
	-- self:addChild(self._closeImage)

	-- self._settingImage = ImageView:create()
	-- self._settingImage:loadTexture("bui_auto_setting.png", UI_TEX_TYPE_PLIST)
	-- self._settingImage:setPosition(ccp(self._closeImage:getPosition()))
	-- self:addChild(self._settingImage)

	-- self._label = Label:create()
	-- self._label:setColor(ccc3(0xE8, 0xD8, 0xCF))
	-- self._label:setPosition(ccp(15, 0))
	-- self._label:setTextHorizontalAlignment(kCCTextAlignmentLeft)
	-- self._label:setTextVerticalAlignment(kCCVerticalTextAlignmentCenter)
	-- self._label:setFontSize(24)
	-- self:addChild(self._label)

	self:ignoreContentAdaptWithSize(false)
	self:setSize(CCSizeMake(122, 55))
	self:setTouchEnabled(true)
	self:addTouchEventListener(onChangeAutoPlay)

	self._autoBattleLabel = ImageView:create()
	self._autoBattleLabel:loadTexture("i18n_bui_auto_battle.png", UI_TEX_TYPE_PLIST)
	self:addChild(self._autoBattleLabel)

	self._autoSettingLabel = ImageView:create()
	self._autoSettingLabel:loadTexture("i18n_bui_auto_setting.png", UI_TEX_TYPE_PLIST)
	self:addChild(self._autoSettingLabel)


	self:setAutoPlay(BattleManager:getInstance():getAutoPlay())

end

function BattleAutoPlayButton:setAutoPlay(value)

	if self._isAutoPlay == value then
		return
	end

	self._isAutoPlay = value

	if self._isAutoPlay == true then

		-- self._label:setText("取消自動")
		-- self._closeImage:setVisible(true)
		-- self._settingImage:setVisible(false)

		self._autoBattleLabel:setVisible(true)
		self._autoSettingLabel:setVisible(false)
	else

		-- self._label:setText("自動戰鬥")
		-- self._closeImage:setVisible(false)
		-- self._settingImage:setVisible(true)

		self._autoBattleLabel:setVisible(false)
		self._autoSettingLabel:setVisible(true)
	end

end

function BattleAutoPlayButton:create()
	return BattleAutoPlayButton.new()
end


BuffAddEffect = class("BuffAddEffect", DisplayUtil.newNode)

BuffAddEffect._buffData = nil

--箭头
BuffAddEffect._arrowSprite = nil
--属性文字
BuffAddEffect._propertySprite = nil
--值标签
BuffAddEffect._valueLabel = nil

function BuffAddEffect:ctor(buffData)

	self._buffData = buffData

	self._propertySprite = CCSprite:createWithSpriteFrameName(
		string.format("i18n_bui_be_%d.png", self._buffData.addEffectId)
	)

	local reduceHarmPath

	if self._buffData.nature == BuffNatureType.BENIGN then
		self._arrowSprite = CCSprite:createWithSpriteFrameName("bui_be_arrow_up.png")
		self._propertySprite:setPosition(ccp(0, -28))

		reduceHarmPath = "ui/digit/bui_buff_add_num.png"
	else
		self._arrowSprite = CCSprite:createWithSpriteFrameName("bui_be_arrow_down.png")
		self._propertySprite:setPosition(ccp(0, 20))

		reduceHarmPath = "ui/digit/bui_buff_reduce_num.png"
	end

	self:addChild(self._arrowSprite)

	self._propertySprite:setVisible(false)
	self:addChild(self._propertySprite)

	if self._buffData.attrType == BuffType.property.REDUCE_HARM then

		local value = 0
		if self._buffData.argType == BuffArgType.VALUE then
			value = self._buffData.attrArg
		else
			value = math.ceil(self._buffData.attrArg * 100 / 10000)
		end

		self._valueLabel = CCLabelAtlas:create(tostring(value), reduceHarmPath, 15, 26, 48)
		self._valueLabel:setAnchorPoint(ccp(0.5, 0.5))
		self._valueLabel:ignoreAnchorPointForPosition(false)
		self._valueLabel:setPosition(ccp(95, 35))
		self._propertySprite:addChild(self._valueLabel)

	end


end

--显示影响的属性
function BuffAddEffect:showImpactProperty()
	self._propertySprite:setVisible(true)
end

function BuffAddEffect:create(buffData)

	local bae = BuffAddEffect.new(buffData)
	return bae

end


BattleTreasureView = class("BattleTreasureView", DisplayUtil.newWidget)

BattleTreasureView._treasure = 0
BattleTreasureView._lastTreasure = 0
BattleTreasureView._updateNumList = nil

BattleTreasureView._updateNumFunc = nil

BattleTreasureView._isUpdating = false

BattleTreasureView._treasureIcon = nil
BattleTreasureView._treasureLabel = nil

BattleTreasureView._action = nil


function BattleTreasureView:ctor()

	self._updateNumList = {}

	self._updateNumFunc = function()
	    if #self._updateNumList == 0 then
	    	self._isUpdating = false
	    	TimerManager.removeTimer(self._updateNumFunc)

    		self._treasureLabel:stopAllActions()
			self._treasureLabel:setScale(2.5)
			local scaleAction = CCScaleTo:create(0.2, 1)
			self._treasureLabel:runAction(scaleAction)
			self._treasureLabel:setText(tostring(self._treasure))
	    	return
	    end

	    local diffNum = table.remove(self._updateNumList, 1)
	    self._treasureLabel:setText(tostring(diffNum))

	end


	local bg = ImageView:create()
	bg:loadTexture("bg_14.png", UI_TEX_TYPE_PLIST)
	bg:setScale9Enabled(true)
	bg:setCapInsets(CCRectMake(25, 20, 15, 20))
	bg:setSize(CCSizeMake(150, 60))
	self:addChild(bg)

	self._treasureIcon = ImageView:create()
	self._treasureIcon:setPosition(ccp(-47, 0))
	self:addChild(self._treasureIcon)

	self._treasureLabel = Label:create()
	self._treasureLabel:setColor(ccc3(0xf5, 0xcc, 0x55))
	self._treasureLabel:setAnchorPoint(ccp(0.5, 0.5))
	self._treasureLabel:setPosition(ccp(15, 0))
	self._treasureLabel:setFontSize(24)
	self._treasureLabel:setText("0")
	self:addChild(self._treasureLabel)


	-- self:setTreasureType(ItemHelper.itemType.exp)

end

function BattleTreasureView:setTreasureType(value)

	if value == ItemHelper.itemType.gold then
		self._treasureIcon:loadTexture("gold.png", UI_TEX_TYPE_PLIST)
	elseif value == ItemHelper.itemType.diamond then
		self._treasureIcon:loadTexture("diamond.png", UI_TEX_TYPE_PLIST)
	else
		self._treasureIcon:loadTexture("icon_exp_potion.png", UI_TEX_TYPE_PLIST)
	end

end

function BattleTreasureView:addTreasure(value)

	local function movementFunc(armature, movementType, movementID)

		if movementType ~= ComConstTab.MovementEventType.COMPLETE then
			return
		end

		armature:removeFromParentAndCleanup(true)

		local updateNumList = MathUtil.getDiffNumList(
			self._lastTreasure, 
			self._treasure, 
			4
		)

		self._lastTreasure = self._treasure

		local lastNum = math.huge

		for _, v in ipairs(updateNumList) do
			if v ~= lastNum then
				lastNum = v
				table.insert(self._updateNumList, lastNum)
			end
		end


		if self._isUpdating == false then
			self._isUpdating = true
			TimerManager.addTimer(40, self._updateNumFunc, true)
		end

	end

	self._treasure = self._treasure + value

	local armature = EffectManager:getInstance():createUIAnimate("baozangfeiru")
	armature:getAnimation():setMovementEventCallFunc(movementFunc)
	armature:getAnimation():playWithIndex(0, -1, -1, 0)
	armature:setPosition(ccp(160, -30))
	self:addNode(armature)

end

function BattleTreasureView:dispose()
	TimerManager.removeTimer(self._updateNumFunc)
end

function BattleTreasureView:create()

	local btv = BattleTreasureView.new()

	return btv
end


BattlePauseView = class("BattlePauseView", AbstView.new)

BattlePauseView._isOpenSound = false

BattlePauseView._onButtonTouch = nil

BattlePauseView._quitButton = nil
BattlePauseView._muteButton = nil
BattlePauseView._continueButton = nil
BattlePauseView._soundImage = nil
BattlePauseView._soundLabel = nil

function BattlePauseView:ctor()

end

function BattlePauseView:init()

	self:addDefaultShadow()
	self:adjustScal()
	self.shadow:setOpacity(200)

	self._isOpenSound = SysSettingMgr:getInstance():isPlayBgMusic() or SysSettingMgr:getInstance():isPlaySoundEffect()

	self:_initWidget("ui/battleui/battle_pause_ui_1.json")

	self._onButtonTouch = function(sender, event)
	    if event ~= TOUCH_EVENT_ENDED then
	    	return
	    end

	    if sender == self._quitButton then
	        BattleManager:getInstance():reqBattleEnd()
	    elseif sender == self._muteButton then
		    self._isOpenSound = not self._isOpenSound

        	SysSettingMgr:getInstance():setIsPlsySoundEffect(self._isOpenSound)
	        SysSettingMgr:getInstance():setIsPlsyBgMusic(self._isOpenSound)

	        self:_updateSound()
	    elseif sender == self._continueButton then
	        BattleManager:getInstance():reqPause(false)
		end
	end

	self._quitButton = self:_getWidget("button_quit", ComponentType.BUTTON)
	self._muteButton = self:_getWidget("button_mute", ComponentType.BUTTON)
	self._continueButton = self:_getWidget("button_continue", ComponentType.BUTTON)

	self._quitButton:addTouchEventListener(self._onButtonTouch)
	self._muteButton:addTouchEventListener(self._onButtonTouch)
	self._continueButton:addTouchEventListener(self._onButtonTouch)

	self._soundImage = self:_getWidget("image_sound", ComponentType.IMAGE_VIEW)
	self._soundLabel = self:_getWidget("label_sound", ComponentType.LABEL)

	self:_updateSound()

end

function BattlePauseView:_updateSound()
	if not self._isOpenSound then
		self._soundImage:loadTexture("bui_mute_cancel.png", UI_TEX_TYPE_PLIST)
		self._soundLabel:setText("聲音 : 開")
	else
		self._soundImage:loadTexture("bui_mute.png", UI_TEX_TYPE_PLIST)
		self._soundLabel:setText("聲音 : 關")
	end
end

function BattlePauseView:create()
	local bpv = BattlePauseView.new()
	bpv:init()
	return bpv
end


BattleAccelerateView = class("BattleAccelerateView", DisplayUtil.newWidget)

BattleAccelerateView._speedImage = nil
BattleAccelerateView._multiImage = nil

BattleAccelerateView._label = nil
BattleAccelerateView._button = nil

function BattleAccelerateView:ctor()

	local function onReqAccelerate(sender, event)
	    if event ~= TOUCH_EVENT_BEGAN then
	    	return
	    end

	    BattleManager:getInstance():reqAccelerate()
	end

	self._speedImage = ImageView:create()
	self._speedImage:loadTexture("i18n_bui_play_speed.png", UI_TEX_TYPE_PLIST)
	self:addChild(self._speedImage)

	self._multiImage = ImageView:create()
	self._multiImage:setPosition(ccp(55, 0))
	self:addChild(self._multiImage)

	self:ignoreContentAdaptWithSize(false)
	self:setAnchorPoint(ccp(0.35,0.5))
	self:setSize(CCSizeMake(120, 50))               --105,30
	self:setTouchEnabled(true)
	self:addTouchEventListener(onReqAccelerate)

	self:updateSpeed(BattleManager:getInstance():getCurrentSpeed())

end

function BattleAccelerateView:updateSpeed(value)
	-- self._label:setText(string.format("加速:%d", value))
	if value > 3 then                    
		value = 3
	end

	self._multiImage:loadTexture(
		string.format("bui_speed_%d.png", value), 
		UI_TEX_TYPE_PLIST
	)
end

function BattleAccelerateView:create()
	return BattleAccelerateView.new()
end

--[[
    回合倒计时显示
]]
BattleFightCountdownView = class("BattleFightCountdownView", DisplayUtil.newWidget)

BattleFightCountdownView._currentTime = 0
BattleFightCountdownView._maxTime = nil

BattleFightCountdownView._numLabel = nil

BattleFightCountdownView._onCountdown = nil
BattleFightCountdownView._callback = nil

function BattleFightCountdownView:ctor()
	self._numLabel = CCLabelAtlas:create(
		"0", 
		"ui/digit/bui_fight_cd_num.png",
		50, 
		70, 
		48
	)
	self._numLabel:setAnchorPoint(ccp(0.5, 0.5))
	self:addNode(self._numLabel)

	self._onCountdown = function()
	    self._numLabel:setString(self._currentTime)
	    self._currentTime = self._currentTime - 1
	    if self._currentTime < 0 then
		    self:stop()
	    	self._callback()
	    end
	end

end

function BattleFightCountdownView:setMaxTime(value)
	self._maxTime = value
end

function BattleFightCountdownView:begin(callback)
	self._callback = callback
	self._currentTime = self._maxTime
	self._onCountdown()
	TimerManager.addTimer(1000, self._onCountdown, true)
end

function BattleFightCountdownView:stop()
	TimerManager.removeTimer(self._onCountdown)
end

function BattleFightCountdownView:create()
	return BattleFightCountdownView.new()
end
