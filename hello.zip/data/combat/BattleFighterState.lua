--
-- Author: thisgf
-- Date: 2014-08-28 14:48:57
-- 战斗参战者状态


--参战者站立状态
FighterStandState = class("FighterStandState", StateBase:create())

FighterStandState.isAttackReturn = false

function FighterStandState:ctor()
end

function FighterStandState:enter(entity)

	if entity:getAnimation():getCurrentMovementID() == "attack01" then
		print(debug.traceback())
	end

	repeat
		if entity:isRole() then
			local actionData = entity:getActionData()
			if actionData:getFileName() == "daozei" then
				local roundData = BattleController:getInstance():getRoundManager():getRoundData()
				local buff = roundData:getOneBuff(
					entity:getEntityID(), 
					BuffType.ADD_CRIT_PERCENT_ASSASSIN
				)
				if buff then
					buff = roundData:getOneBuff(
						entity:getEntityID(), 
						BuffType.DEFORM
					)
					if not buff then
						BattleController:getInstance():playStandAction2(entity:getEntityID())
						break
					end
				end
			end
		end

		BattleController:getInstance():playStandAction(entity:getEntityID())

	until true

	if entity:getEntityType() == BattleType.ATTACKER then
		entity:setDirection(BattleType.directionType.RIGHT)
	else
		entity:setDirection(BattleType.directionType.LEFT)
	end

end

function FighterStandState:create()

	local fss = FighterStandState.new()
	fss:init()
	return fss
end

function FighterStandState:init()
	self:setType("FighterStandState")
end



--攻击发动状态
FighterAttackLaunchState = class("FighterAttackLaunchState", StateBase:create())

--状态进入
function FighterAttackLaunchState:enter(entity)
	
end

--状态调用
function FighterAttackLaunchState:invoke(entity)

	if entity:getStateMachine():getExecuteState() == true then
		return
	end

	entity:getStateMachine():setExecuteState()

	local function playEffectEnd(container, effectId)
		self:endState(entity)
	end

	local atkSkillData = BattleController:getInstance():getAttackSkillData(entity:getEntityID())

	local effectIds = atkSkillData.args.beforeAttackEffectIds
	if #effectIds > 0 then

		BattleController:getInstance():playEffectWithEntity(entity:getEntityID(), effectIds, 1, playEffectEnd)

	else
		self:endState(entity)
	end
	
end
	
--创建状态对象
function FighterAttackLaunchState:ctor()	
end

function FighterAttackLaunchState:create()
	local fals = FighterAttackLaunchState.new()
	fals:init()
	return fals
end

--状态对象初始化
function FighterAttackLaunchState:init()

	self:setType("FighterAttackLaunchState")
end	



--参战者攻击状态
FighterAttackState = class("FighterAttackState", StateBase:create())

FighterAttackState._skillData = nil
FighterAttackState._entity = nil
FighterAttackState._attackerId = 0

FighterAttackState._attackHandler = nil

FighterAttackState._targetGroupData = nil
FighterAttackState._targetList = nil

FighterAttackState._nearFarType = 0

FighterAttackState._roundManager = nil

FighterAttackState._attackActionComplete = false
FighterAttackState._attackerReactionComplete = true

--目标攻击次数参数列表
FighterAttackState._targetTimesParamsList = nil

--攻击次数
FighterAttackState._attackTimes = 1
--当前攻击次数
FighterAttackState._attackCurrentTimes = 0
--主动攻击次数
FighterAttackState._initAttackTimes = 1

--被动最大连击数
FighterAttackState._passAttackTimes = 1

--目标者受击次数
FighterAttackState._targetHitTimes = 0

--是否攻击足够了
FighterAttackState._isAttackEnough = false


--受击次数字典
FighterAttackState._targetHurtTimesDict = nil
FighterAttackState._targetHurtStateDict = nil

--目标完成回调
FighterAttackState._targetHurtEndFunc = nil

--已经通知外面的参战者字典
FighterAttackState._notifyEndEntityDict = nil

--云特效
FighterAttackState._cloudEffect = nil


function FighterAttackState:ctor()

	self._roundManager = BattleController:getInstance():getRoundManager()

	self._targetHurtStateDict = {}
	self._notifyEndEntityDict = {}

	self._targetHurtTimesDict = {}

	self._targetHurtEndFunc = function(entityId)

	    if self._notifyEndEntityDict[entityId] == true then
	    	return
	    end

	    self._targetHurtStateDict[entityId] = nil

	    local entity = EntityManager:getInstance():getEntityWithID(entityId)

	    self._targetHurtTimesDict[entityId] = self._targetHurtTimesDict[entityId] - 1

	    -- print("///////////////////////剩餘受擊次數", self._targetHurtTimesDict[entityId])

	    --攻击者死了, 目标死了, 受击次数够了
	    if self._entity:getIsDead() == true or 
	    	entity:getIsDead() == true or 
	    	self._targetHurtTimesDict[entityId] <= 0 then

	    	Notifier.dispatchCmd(
		    		CmdName.BATTLE_FIGHTER_BROADCAST_END, 
		    		{
			    		bcType = BattleType.BROADCAST_TARGET, 
			    		attackerId = self._attackerId, 
			    		entityId = entityId
		    		}
	    		)

	    	self._notifyEndEntityDict[entityId] = true
	    end

	end

end

function FighterAttackState:invoke(entity)

	if entity:getStateMachine():getExecuteState() == true then
		return
	end

	entity:getStateMachine():setExecuteState()

	self._entity = entity
	self._attackerId = self._entity:getEntityID()

	local atkSkillData = BattleController:getInstance():getAttackSkillData(self._attackerId)
	self._skillData = atkSkillData
	self._nearFarType = atkSkillData.cfg._nearFarType

	self._targetGroupData = BattleController:getInstance():getHurtGroup(self._attackerId)
	self._targetList = self._targetGroupData.attackTargetGroup

	self._attackCurrentTimes = 1

	if BattleManager:getInstance():getIsOB() then
		self._attackTimes = #self._roundManager:getAttackerActionData().hurtData
	else
		if atkSkillData.cfg._atkScriptId == SkillScriptType.BATTER then
			self._attackTimes = atkSkillData.cfg._atkScriptArgs[1][1]
		else
			self._attackTimes = 1
		end
	end

	self._initAttackTimes = self._attackTimes

	--受击次数等于攻击次数
	for _, v in ipairs(self._targetList) do
		self._targetHurtTimesDict[v] = 0
	end

	self._targetTimesParamsList = {}

	if self._nearFarType == SkillDataCfg.NEAR_SKILL then
		self:_executeNear()
	elseif self._nearFarType == SkillDataCfg.FAR_SKILL then
		self:_executeFar()
	end

end

--执行近程
function FighterAttackState:_executeNear()

	local function moveCallFunc(entityId)
		BattleController:getInstance():setAttackerDirection(
			self._attackerId, 
			self._targetGroupData.targetId
		)
		self:_playAttackAction()
	end

	BattleController:getInstance():setAttackerFront(self._attackerId, self._targetGroupData.targetId)

	if self._skillData.cfg._atkScriptId == SkillScriptType.ATTACK_PHANTOM then
		--不好写通用接口, 直接在这里处理
		local container = BattleController:getInstance():getBattleScene():getFighterLayer()

		self._cloudEffect = EffectManager:getInstance():playEffect(
			container,
			23062,
			nil,
			0,
			false,
			0
		)
		self._cloudEffect:setScaleX(self._entity:getRenderNode():getBodyScaleX())
		self._cloudEffect:setPosition(ccp(self._entity:getRenderNode():getPosition()))

	end
	
	if self._skillData.args.closeToType == BattleType.closeType.BLINK then
		BattleController:getInstance():blinkEntityTo(
			self._attackerId, 
			self._targetGroupData.targetId, 
			self._skillData.args.attackDist, 
			moveCallFunc
		)
	else
		local battleScene = BattleController:getInstance():getBattleScene()
		battleScene:moveFighterToTarget(
			self._attackerId, 
			self._targetGroupData.targetId, 
			BattleType.moveTime.ATTACK, 
			self._skillData.args.attackDist, 
			moveCallFunc
		)
	end

end

--执行远程
function FighterAttackState:_executeFar()

	self:_playAttackAction()
end

function FighterAttackState:_playAttackAction()

	local isActionTrigger = false

	self._attackActionComplete = false

	--攻击触发
	local function triggerCallFunc()

		if self._attackActionComplete == true then
			return
		end

		isActionTrigger = true

		self:_attackTrigger()

	end

	local function callFunc()

		self._attackActionComplete = true

		if isActionTrigger == false then
			self:_attackTrigger()
		end

		--远程攻击攻击者动作完成
		if self._nearFarType == SkillDataCfg.FAR_SKILL then
			BattleController:getInstance():playStandAction(self._attackerId)
		end

		BattleController:getInstance():removeCloneEntity(self._attackerId)
		if self._cloudEffect then
			EffectManager:getInstance():removeEffect(
				self._cloudEffect:getContainer(),
				self._cloudEffect:getEffectId()
			)
		end

		self:_attackEnd()

	end

	local curSkillIndex = self._roundManager:getEntitySkillIndex(self._entity)

	BattleController:getInstance():playAudio(
		self._skillData.args.audioId, 
		self._skillData.args.audioDelayTime
	)

	BattleController:getInstance():playAttackAction(
		self._attackerId, 
		curSkillIndex, 
		callFunc, 
		triggerCallFunc
	)

	if self._skillData.cfg._atkScriptId == SkillScriptType.ATTACK_PHANTOM then
		if #self._targetList == 2 then
			local target = EntityManager:getInstance():getEntityWithID(
				self._targetGroupData.targetId
			)

			local targetX = 0
			local targetY = 0

			local renderNode = self._entity:getRenderNode()
			local attackPos = ccp(renderNode:getPosition())

			local dist = target:getRenderNode():getPositionX() - attackPos.x

			local targetIndex = target:getBattleFieldPosition()
			local targetPos = nil
			if self._entity:getEntityType() == BattleType.ATTACKER then
				if targetIndex % 2 == 0 then
					targetPos = MONSTER_POSITION[targetIndex - 1]
				else
					targetPos = MONSTER_POSITION[targetIndex + 1]
				end
			else
				if targetIndex % 2 == 0 then
					targetPos = ROLE_POSITION[targetIndex - 1]
				else
					targetPos = ROLE_POSITION[targetIndex + 1]
				end
			end

			local targetZ
			if targetIndex % 2 == 0 then
				targetZ = BATTLE_LAYER_Z.normalFighter[targetIndex - 1]
			else
				targetZ = BATTLE_LAYER_Z.normalFighter[targetIndex + 1]
			end

			targetX = targetPos.x - dist
			targetY = targetPos.y

			BattleController:getInstance():addCloneEntity(
				self._attackerId, 
				ccp(
					targetX, 
					targetY
				),
				targetZ + 1
			)

			BattleController:getInstance():playAttackAction(
				self._attackerId,
				curSkillIndex,
				nil,
				nil,
				true
			)

		end
	end

end

function FighterAttackState:_attackTrigger()

	if BattleManager:getInstance():getIsOB() == false then
		self:_generateTargetParam()
		self:_generateTempBuff()
	else
		self:_generateTargetParamOB()
	end

	BattleController:getInstance():playEffectWithEntity(
		self._attackerId, 
		self._skillData.args.attackingEffectIds, 
		1
	)

	if self._nearFarType == SkillDataCfg.NEAR_SKILL then
		if BattleManager:getInstance():getIsOB() then
			self:_attackNextForOB()
		else
			self:_attackNext()
		end
		-- self:_attackNext()
	elseif self._nearFarType == SkillDataCfg.FAR_SKILL then
		self:_playFlyEffect()
	end

end

--攻击结束
function FighterAttackState:_attackEnd()

	if self._attackActionComplete == false or 
		self._attackerReactionComplete == false then
		return
	end

	self._attackCurrentTimes = self._attackCurrentTimes + 1

	BattleController:getInstance():resetFighterDepth(self._attackerId)

	local function deadFunc()
		self:_processComplete()
	end

	local function moveFunc(entityId)
		local standState = FighterStandState:create()
		self._entity:getStateMachine():changeState(standState)
		self:_processComplete()
	end

	--死亡或反击不能回去
	if self._entity:getIsDead() == true then

		for _, entityId in ipairs(self._targetList) do
			self._targetHurtEndFunc(entityId)
		end

		BattleController:getInstance():playDeadAction(self._attackerId, deadFunc)

	else

		repeat

			--还有攻击次数

			if self._isAttackEnough == false then

				--判断还有没有攻击目标
				local isAllDead = true
				for _, entityId in ipairs(self._targetList) do
					local entity = EntityManager:getInstance():getEntityWithID(entityId)
					if entity:getIsDead() == false then
						isAllDead = false
						break
					end
				end

				if isAllDead == false then
					self:_playAttackAction()
					break
				end

			end
				
			--近程回去
			if self._nearFarType == SkillDataCfg.NEAR_SKILL then

				if self._skillData.args.closeToType == BattleType.closeType.BLINK then
					BattleController:getInstance():blinkEntityBack(self._attackerId, moveFunc)
				else
					BattleController:getInstance():getBattleScene():moveFighterToOriginalPos(
						self._attackerId, 
						BattleType.moveTime.RETURN, 
						moveFunc
					)
				end

			else
				moveFunc()
			end
			
		until true
		
	end

end

--攻击流程完成
function FighterAttackState:_processComplete()

	Notifier.dispatchCmd(
			CmdName.BATTLE_FIGHTER_BROADCAST_END, 
			{
				bcType = BattleType.BROADCAST_ATTACKER, 
				entityId = self._attackerId
			}
		)

end

--飞行特效
function FighterAttackState:_playFlyEffect()

	--开始攻击时刻的特效动作
	local function cbFunc()
		if BattleManager:getInstance():getIsOB() then
			self:_attackNextForOB()
		else
			self:_attackNext()
		end
		-- self:_attackNext()
	end

	local effectIds

	if self._skillData.cfg:getId() == SkillDataCfg.FAR_NORMAL_ATTACK then
		local actionData = EffectManager:getInstance():getActionData(
			self._entity:getBaseInfo():getModelId()
		)
		if actionData then
			if actionData.defaultFlyEffect ~= 0 then
				effectIds = {actionData.defaultFlyEffect}
			end
		end
	else
		effectIds = self._skillData.args.middleAttackEffectIds
	end

	if effectIds and #effectIds > 0 then

		--获取特效  EffectManager		
		--traceType = 0					--特效轨迹		
		
		local entTarget = EntityManager:getInstance():getEntityWithID(self._targetGroupData.targetId)
		
		BattleController:getInstance():playEffectFlyTo({
			attacker = self._entity,
			target = entTarget,
			effectId = effectIds[1],
			traceType = EffectMoveTraceType.MOVETO,
			callback = cbFunc
		})

	else
		cbFunc()
	end

end

--攻击动作下一步
function FighterAttackState:_attackNext()

	self._targetHitTimes = self._targetHitTimes + 1
	local targetTimesParams = self._targetTimesParamsList[self._targetHitTimes]

	local hurtGroupNum = #self._targetList

	local atkScriptId = self._skillData.cfg._atkScriptId

	--震屏
	local shakeNum = self._skillData.args.shakeNum
	if shakeNum > 0 then
		Notifier.dispatchCmd(CmdRegist.SHAKE_SCREEN, {shakeNum = shakeNum})
	end

	--触发时间列表
	local triggerTimeList = self._skillData.args.triggerTimeList
	if #triggerTimeList == 0 then
		triggerTimeList = {0}
	end

	--目标里面有自己
	if self._roundManager:hasSelfHurtTarget(self._attackerId) then

		local function onAttackerReactionFunc()
			self._attackerReactionComplete = true
			Notifier.removeByName(CmdRegist.ATTACKER_REACTION_COMPLETE)
			self:_attackEnd()
		end

		self._attackerReactionComplete = false
		Notifier.regist(CmdRegist.ATTACKER_REACTION_COMPLETE, onAttackerReactionFunc)
	else
		self._attackerReactionComplete = true
	end

	local attackParam = {}
	attackParam.attackerId = self._attackerId  --攻击者
	attackParam.targetNum = hurtGroupNum       --目标数量
	attackParam.triggerTimeList = triggerTimeList  --触发时间列表
	attackParam.skillData = self._skillData
	attackParam.targetCamp = getSkillTargetCamp(self._skillData.cfg.atkTargetType)  --目标敌/友方
	attackParam.attackTimes = self._attackCurrentTimes

	for i = 1, hurtGroupNum do

		local receiverEntityId = self._targetList[i]
		local targeter = EntityManager:getInstance():getEntityWithID(receiverEntityId)

		--非死亡
		if targeter:getIsDead() == false then

			local targetParam = targetTimesParams.targetParams[receiverEntityId]

			repeat

				--给自己上buff
				if atkScriptId == SkillScriptType.BUFF_FOR_SELF then
					break
				end

				--驱散
				if atkScriptId == SkillScriptType.DISPERSE then
					self._roundManager:getRoundData():clearEntityBuff(receiverEntityId, self._skillData.cfg._atkScriptArgs[1][1])
				end

				--驱散并获得buff
				if atkScriptId == SkillScriptType.DISPERSE_AND_BUFF then
					self._roundManager:getRoundData():clearEntityBuff(receiverEntityId, self._skillData.cfg._atkScriptArgs[1][1])
				end

				--驱散并治疗
				if atkScriptId == SkillScriptType.DISPERSE_AND_TREAT then

					self._roundManager:getRoundData():clearEntityBuff(receiverEntityId, self._skillData.cfg._atkScriptArgs[1][1])
					-- targetParam.treatNumber = self._skillData.cfg._atkScriptArgs[2][1]

					break
				end

				--伤害自己添加buff
				if atkScriptId == SkillScriptType.ATTACK_AND_BUFF then
					break
				end

			until true

			--更新攻击者的血值
			BattleController:getInstance():updateEntityHp(
				self._attackerId, 
				targetParam.vampireNumber
			)
			if targetParam.atkerHurtNumber then
				BattleController:getInstance():updateEntityHp(
					self._attackerId, 
					-targetParam.atkerHurtNumber, 
					false
				)
			end

			self._targetHurtTimesDict[receiverEntityId] = self._targetHurtTimesDict[receiverEntityId] + 1

			local hurtState = self._targetHurtStateDict[receiverEntityId]
			if hurtState then
				
				hurtState:uninit()
				self._targetHurtEndFunc(receiverEntityId)
				targeter:getStateMachine():setCurState(nil)
			end

			hurtState = FighterHurtState:create()
			hurtState:setHurtEndFunc(self._targetHurtEndFunc)
			self._targetHurtStateDict[receiverEntityId] = hurtState

			hurtState:setAttackParam(attackParam)
			hurtState:setTargetParam(targetParam)
			targeter:getStateMachine():changeState(hurtState)

		end

	end

	--溅射伤害
	if targetTimesParams.spurtParams then

		for entityId, shn in pairs(targetTimesParams.spurtParams) do

            BattleController:getInstance():updateEntityHp(
            	entityId, 
            	-shn, 
            	true
            )

			BattleController:getInstance():playEffectWithEntity(
				entityId, {23038}, 1
			)
		end
	end

	local targetEffectIds = self._skillData.args.targetEffectIds

	--群体攻击
	if #targetEffectIds > 0 then
		local function groupEffectFunc()
			Notifier.dispatchCmd(CmdRegist.GROUP_EFFECT_COMPLETE)
		end
		if self._skillData.args.targetEffectRange == BattleType.effectRange.GROUP then
			BattleController:getInstance():playGroupEffect(
				targetEffectIds, 
				self._targetList, 
				groupEffectFunc
			)
		end
	end

	-- self._entity:setCurAttackExtraArgs(nil)

end

function FighterAttackState:_generateTempBuff()

	local roundData = self._roundManager:getRoundData()

	local targetTimesParams = self._targetTimesParamsList[self._attackCurrentTimes]

	local buffTargetGroup = {}
	local skillArgs
	local targetParams
	local scriptId = self._skillData.cfg._atkScriptId
	local scriptArgsList = {}

	--指定目标类型
	if scriptId == SkillScriptType.BUFF_FOR_SPECIAL_TARGET then

		for _, skillArgs in ipairs(self._skillData.cfg._atkScriptArgs) do
			targetParams = {
				skillTargetTypeId = skillArgs[1],
				leftTeam = roundData:getAttackerTeam(),
				rightTeam = roundData:getStrikerTeam(),
				targetNum = skillArgs[2],
				atkEnt = self._entity
			}

			buffTargetGroup[#buffTargetGroup + 1] = getSkillTargetGroup(targetParams)
			scriptArgsList[#scriptArgsList + 1] = {skillArgs[3], skillArgs[4]}

		end

	elseif scriptId == SkillScriptType.ATTACK_AND_BUFF then

		skillArgs = self._skillData.cfg._atkScriptArgs[2]
		targetParams = {
			skillTargetTypeId = skillArgs[1],
			leftTeam = roundData:getAttackerTeam(),
			rightTeam = roundData:getStrikerTeam(),
			targetNum = skillArgs[2],
			atkEnt = self._entity
		}

		buffTargetGroup[1] = getSkillTargetGroup(targetParams)
		scriptArgsList[1] = {skillArgs[3], skillArgs[4]}

	elseif scriptId == SkillScriptType.BUFF_FROM_ATTACK then

		local totalDamage = 0
		local targetTimesParams = self._targetTimesParamsList[self._attackCurrentTimes]
		for _, targetParam in pairs(targetTimesParams.targetParams) do
			totalDamage = totalDamage + (targetParam.hurtNumber or 0)
		end

		for i, skillArgs in ipairs(self._skillData.cfg._atkScriptArgs) do

			local gainNumber = skillArgs[2][3] * totalDamage / 10000
			scriptArgsList[i] = {skillArgs[1], {skillArgs[2][1], skillArgs[2][2], gainNumber}}
			buffTargetGroup[i] = {self._attackerId}
		end

	else

		buffTargetGroup[1] = self._targetList
		scriptArgsList[1] = self._skillData.cfg._atkScriptArgs
	end

	local targetParam = {}

	--生成临时buff
	for i, targetList in ipairs(buffTargetGroup) do

		local targetListTemp = clone(targetList)

		--移除miss的受击者
		for k, v in ipairs(targetListTemp) do
			local buffTarget = EntityManager:getInstance():getEntityWithID(v)
			if buffTarget:getEntityType() ~= self._entity:getEntityType() then
				local targetParam = targetTimesParams.targetParams[v]
				if targetParam and targetParam.isMiss then
					table.remove(targetListTemp, k)
				end
			end
		end

		self._roundManager:generateEntityBuff(
			scriptId, 
			scriptArgsList[i], 
			self._entity, 
			targetListTemp
		)
	end

	--计算被动buff
	roundData:calcPassiveSkillBuff(self._attackerId)

	--添加buff播报
	if BattleManager:getInstance():getIsOB() == false then

		local tempBuffDict = roundData:getTempBuffDict()
		if tempBuffDict then
			BattleReportManager:getInstance():addBuff(
				tempBuffDict, 
				self._attackCurrentTimes
			)
		end
	end

end

--生成目标参数
function FighterAttackState:_generateTargetParam()

	local roundData = self._roundManager:getRoundData()

	--每次攻击对目标的参数
	local targetTimesParams = {}
	targetTimesParams.targetParams = {}

	self._targetTimesParamsList[self._attackCurrentTimes] = targetTimesParams

	--是否有溅射伤害
	local spurtPassArgs = roundData:getPassiveSkillWithScript(
		self._attackerId, 
		PassiveSkillScriptType.SCRIPT_TYPE_20009
	)
	local spurtHurtNumber = 0

	local atkScriptId = self._skillData.cfg._atkScriptId

	--攻击额外属性
	if atkScriptId == SkillScriptType.ATTACK_EXTRA_DAMAGE then
		for _type, _value in pairs(self._skillData.cfg._atkScriptArgs) do						
			local extraArgs = {}
			extraArgs.type = _value[1]
			extraArgs.value = _value[2]
			self._entity:setCurAttackExtraArgs(extraArgs)
			break
		end
	end

	local isBlock = false
	local isMiss = false

	for i, entityId in ipairs(self._targetList) do

		local targetParam = {}

		targetTimesParams.targetParams[entityId] = targetParam

		repeat

			--给自己上buff
			if atkScriptId == SkillScriptType.BUFF_FOR_SELF then
				break
			end

			--治疗
			if atkScriptId == SkillScriptType.TREAT or 
				atkScriptId == SkillScriptType.TREAT_AND_BUFF then 

				local treatHp = 0
				for _, v in pairs(self._skillData.cfg._atkScriptArgs) do
					treatHp = v[1]
					break
				end

				targetParam.treatNumber = treatHp

				break
			end

			--驱散并治疗
			if atkScriptId == SkillScriptType.DISPERSE_AND_TREAT then

				targetParam.treatNumber = self._skillData.cfg._atkScriptArgs[2][1]

				break
			end

			--伤害自己添加buff
			if atkScriptId == SkillScriptType.ATTACK_AND_BUFF then
				break
			end

			local hurtArgs = self._roundManager:calcAtkHurt(self._attackerId, entityId)

			for hurtKey, hurtValue in pairs(hurtArgs) do
				
				targetParam[hurtKey] = hurtValue
			end

		until true

		targetParam.hurtNumber = targetParam.hurtNumber or 0
		targetParam.treatNumber = targetParam.treatNumber or 0

		--更新治疗值
		targetParam.treatNumber = roundData:calcAtkPassiveSkillForStrike(
			self._attackerId,
			entityId,
			targetParam.treatNumber,
			2
		)

		targetParam.treatNumber = roundData:calcPassiveSkillStrike(
			entityId,
			targetParam.treatNumber,
			2
		)

		if spurtPassArgs then
			spurtHurtNumber = targetParam.hurtNumber
		end

		if not isBlock then
			isBlock = targetParam.isBlock
		end

		if not isMiss then
			isMiss = targetParam.isMiss
		end

		if BattleManager:getInstance():getIsOB() == false then
			BattleReportManager:getInstance():addHurtData(
				self._attackCurrentTimes,
				entityId,
				targetParam
			)
		end

	end

	--溅射伤害
	if spurtPassArgs then

		targetTimesParams.spurtParams = {}
		for entityId, _ in pairs(spurtPassArgs[3]) do

			local shn = math.ceil(spurtHurtNumber * spurtPassArgs[4])
			targetTimesParams.spurtParams[entityId] = shn

			BattleStatisticManager:getInstance():addHurt(self._attackerId, shn)
		end

		if BattleManager:getInstance():getIsOB() == false then
			BattleReportManager:getInstance():addSpurtHurtData(
				self._attackCurrentTimes,
				targetTimesParams.spurtParams
			)
		end
	end

	self._isAttackEnough = false

	if isMiss or isBlock then
		self._isAttackEnough = true
	end

	if not self._isAttackEnough then

		repeat

			if self._passAttackTimes > self._initAttackTimes then
				break
			end

			--是否产生连击
			local isPassBatter = PassiveSkillManager:getInstance():generate20018(
				self._skillData.cfg, 
				self._entity
			)
			if not isPassBatter then
				break
			end

			self._passAttackTimes = self._passAttackTimes + 1
			self._attackTimes = self._attackTimes + 1

		until true

		if self._attackCurrentTimes >= self._attackTimes then
			self._isAttackEnough = true
		else
			self._isAttackEnough = false
		end

	end

	self._entity:setCurAttackExtraArgs(nil)

end

function FighterAttackState:_generateTargetParamOB()
	if self._attackCurrentTimes >= self._attackTimes then
		self._isAttackEnough = true
	else
		self._isAttackEnough = false
	end
end

function FighterAttackState:_attackNextForOB()

	self._targetHitTimes = self._targetHitTimes + 1

	local actionData = self._roundManager:getAttackerActionData()

	local hurtGroupNum = #self._targetList

	--震屏
	local shakeNum = self._skillData.args.shakeNum
	if shakeNum > 0 then
		Notifier.dispatchCmd(CmdRegist.SHAKE_SCREEN, {shakeNum = shakeNum})
	end

	--触发时间列表
	local triggerTimeList = self._skillData.args.triggerTimeList
	if #triggerTimeList == 0 then
		triggerTimeList = {0}
	end

	if actionData.buff then
		local buffDict = actionData.buff[self._targetHitTimes]
		if buffDict then
			local tempBuffDict = BattleManager:getInstance():getReportData():handleBuff(buffDict)
			self._roundManager:getRoundData():addTempBuffDict(tempBuffDict)
		end
	end

	local attackParam = {}
	attackParam.attackerId = self._attackerId  --攻击者
	attackParam.targetNum = hurtGroupNum       --目标数量
	attackParam.triggerTimeList = triggerTimeList  --触发时间列表
	attackParam.skillData = self._skillData
	attackParam.targetCamp = getSkillTargetCamp(self._skillData.cfg.atkTargetType)  --目标敌/友方
	attackParam.attackTimes = self._attackCurrentTimes

	for _, entityId in ipairs(self._targetList) do
		local targeter = EntityManager:getInstance():getEntityWithID(entityId)
		local targetParam

		for _, v in ipairs(actionData.hurtData[self._targetHitTimes]) do

			if v[1] == entityId then
				targetParam = v[2]
				break
			end
		end

		--更新攻击者的血值
		BattleController:getInstance():updateEntityHp(self._attackerId, targetParam.vampireNumber)
		if targetParam.atkerHurtNumber then
			BattleController:getInstance():updateEntityHp(self._attackerId, -targetParam.atkerHurtNumber, false)
		end

		self._targetHurtTimesDict[entityId] = self._targetHurtTimesDict[entityId] + 1
		
		local hurtState = self._targetHurtStateDict[entityId]
		if hurtState then
			
			hurtState:uninit()
			self._targetHurtEndFunc(entityId)
			targeter:getStateMachine():setCurState(nil)
		end

		hurtState = FighterHurtState:create()
		hurtState:setHurtEndFunc(self._targetHurtEndFunc)
		self._targetHurtStateDict[entityId] = hurtState

		hurtState:setAttackParam(attackParam)
		hurtState:setTargetParam(targetParam)
		targeter:getStateMachine():changeState(hurtState)

	end

	--溅射伤害
	if actionData.spurtData and actionData.spurtData[self._targetHitTimes] then
		for shnId, shn in pairs(actionData.spurtData[self._targetHitTimes]) do

            BattleController:getInstance():updateEntityHp(
            	shnId, 
            	-shn, 
            	true
            )

			BattleController:getInstance():playEffectWithEntity(shnId, {23038}, 1)
		end
	end

	local targetEffectIds = self._skillData.args.targetEffectIds

	--群体攻击
	if #targetEffectIds > 0 then
		local function groupEffectFunc()
			Notifier.dispatchCmd(CmdRegist.GROUP_EFFECT_COMPLETE)
		end
		if self._skillData.args.targetEffectRange == BattleType.effectRange.GROUP then
			BattleController:getInstance():playGroupEffect(
				targetEffectIds, 
				self._targetList, 
				groupEffectFunc
			)
		end
	end


end

function FighterAttackState:init()
	self:setType("FighterAttackState")
end

function FighterAttackState:create()
	local fas = FighterAttackState.new()
	fas:init()
	return fas
end


--参战者受伤特效(包括加血等)
FighterHurtState = class("FighterHurtState", StateBase:create())

FighterHurtState._entity = nil
FighterHurtState._entityId = 0

--攻击参数
FighterHurtState._attackParam = nil

--受伤参数
FighterHurtState._targetParam = nil

FighterHurtState._hurtEndFunc = nil

FighterHurtState._hurtAction = nil

--更新真实伤害索引
FighterHurtState._realHurtList = nil
FighterHurtState._updateRealHurtIndex = 0

FighterHurtState._entityCampType = nil

function FighterHurtState:ctor()

end

function FighterHurtState:setAttackParam(value)
	self._attackParam = value
end

function FighterHurtState:setTargetParam(value)
	self._targetParam = value
end

--[[
    设置受伤完成回调
]]
function FighterHurtState:setHurtEndFunc(callback)
	self._hurtEndFunc = callback
end

function FighterHurtState:enter(entity)

	self._entity = entity
	self._entityId = entity:getEntityID()

	self._entityCampType = self._entity:getEntityType()

	self:_updateEntityHp()

	local targetCamp = self._attackParam.targetCamp
	if targetCamp == BattleType.SKILL_ALLY and 
		self._entity:getIsChaos() == false then
		self:_playAllyReaction()
	else
		self:_playEnemyReaction()
	end

	BattleController:getInstance():playEntityBuffAddEffect(self._entityId)

end

function FighterHurtState:invoke(entity)

	if entity:getStateMachine():getExecuteState() == true then
		return
	end

	entity:getStateMachine():setExecuteState()

end

--是否需要播放目标特效
function FighterHurtState:_needPlayTargetEffect()

	local argumentData = self._attackParam.skillData.args

	-- local targetEffectId = argumentData.targetEffectId
	local targetEffectIds = argumentData.targetEffectIds

	if #targetEffectIds == 0 then
		return false
	end

	local range = argumentData.targetEffectRange

	if range == BattleType.effectRange.GROUP then
		return false
	end

	return true

end

--更新血值
function FighterHurtState:_updateEntityHp()

	self._entity:updateCurrentHp(self._targetParam.treatNumber)

	--打自己
	if self._attackParam.skillData.cfg._atkScriptId == SkillScriptType.ATTACK_AND_BUFF then

		local selfHarm = self._attackParam.skillData.cfg._atkScriptArgs[1][1]
		self._entity:setMinHp(1)
		self._entity:updateCurrentHp(-selfHarm)
		self._entity:setMinHp(0)

		local param = {}
		param.node = self._entity:getRenderNode()
		param.hurtNum = -selfHarm
		BattleController:getInstance():displayHurtNum(param)

	end

	--更新护盾
	if self._entity:getTotalShieldHp() > 0 and self._entity:getCurrentShieldHp() == 0 then
		BattleController:getInstance():removeBuff(self._entityId, BuffType.ADD_SHIELD)
	end

end

--友方反应
function FighterHurtState:_playAllyReaction()

	--自己加血
	local param = {}
	param.node = self._entity:getRenderNode()
	param.hurtNum = self._targetParam.treatNumber
	BattleController:getInstance():displayHurtNum(param)

	local function reactionEnd()

		BattleController:getInstance():addBuffToEntity(self._entityId)

		self:_playHurtEnd()
	end

	if self:_needPlayTargetEffect() == true then

		BattleController:getInstance():playEffectWithEntity(
			self._entityId, 
			self._attackParam.skillData.args.targetEffectIds, 
			-1, 
			reactionEnd
		)

	else

		if #self._attackParam.skillData.args.targetEffectIds == 0 then

			TimerManager.addTimer(300, reactionEnd, false)
		else
			local function groupEffectFunc()
				Notifier.remove(CmdRegist.GROUP_EFFECT_COMPLETE, groupEffectFunc)
				reactionEnd()
				return true
			end

			Notifier.regist(CmdRegist.GROUP_EFFECT_COMPLETE, groupEffectFunc)
		end
	end
	
end

--敌方反应
function FighterHurtState:_playEnemyReaction()

	local isMiss = self._targetParam.isMiss

	if self:_needPlayTargetEffect() == true then

		BattleController:getInstance():playEffectWithEntity(
			self._entityId, 
			self._attackParam.skillData.args.targetEffectIds, 
			-1
		)
	end

	if isMiss == true then
		self:_playEnemyMiss()
	else
		self:_playEnemyHurt()
	end

end

--敌方受伤
function FighterHurtState:_playEnemyHurt()

	local targetHurtEffectIds = self._attackParam.skillData.args.targetHurtEffectIds
	local renderNode = self._entity:getRenderNode()

	local isBlock = self._targetParam.isBlock
	local isCrit = self._targetParam.isCrit
	local hurtNumber = -self._targetParam.hurtNumber
	local displayHurtNumber = hurtNumber
	if self._targetParam.hurtTreatNumber and 
		self._targetParam.hurtTreatNumber > 0 then
		local param = {}
		param.node = renderNode
		param.hurtNum = self._targetParam.hurtTreatNumber
		BattleController:getInstance():displayHurtNum(param)
		self._entity:updateCurrentHp(self._targetParam.hurtTreatNumber)
	end

	local isHurt = hurtNumber < 0
	if isHurt then
		displayHurtNumber = displayHurtNumber + self._entity:getCurrentShieldHp()
		if displayHurtNumber > 0 then
			displayHurtNumber = 0
		end
	end

	local hpNumList, realNumberList = BattleUtil:getMultiTimesHp(#self._attackParam.triggerTimeList, hurtNumber)
	self._realHurtList = realNumberList

	local _, dNumberList = BattleUtil:getMultiTimesHp(#self._attackParam.triggerTimeList, displayHurtNumber)

	local hurtNumLen = #hpNumList
	local dHurtNumLen = #dNumberList

	local index = 0


	self._updateRealHurtIndex = 0

	--飘血
	local function showFloatHp()

		index = index + 1

		if dHurtNumLen > 0 then

			local param = {}
			param.node = renderNode
			-- param.hurtNum = hpNumList[index]
			param.hurtNum = dNumberList[index]
			param.isCrit = isCrit

			BattleController:getInstance():displayHurtNum(param)

		end

		if self:isUninit() == true then
			return
		end

		if self._updateRealHurtIndex < #self._realHurtList then
			self._updateRealHurtIndex = self._updateRealHurtIndex + 1
			self._entity:updateCurrentHp(self._realHurtList[self._updateRealHurtIndex])
		end

		BattleController:getInstance():playEffectWithEntity(self._entityId, targetHurtEffectIds, -1)

		if isHurt then
			BattleController:getInstance():playHurtShakeAction(self._entityId, 0)
		else
			BattleController:getInstance():playHurtShakeAction(self._entityId, 1)
		end

		if self._entity:getEntityType() == BattleType.STRIKER and hurtNumLen > 1 then
			BattleController:getInstance():showHitsTimes(index, hurtNumLen)
		end
		
	end

	--第一个受伤
	local function playHurtAction()

		showFloatHp()

		if self:isUninit() then
			return
		end

		if isHurt then
			BattleController:getInstance():playHurtAction(self._entityId, true)
			BattleController:getInstance():removeBuff(self._entityId, BuffType.SLEEP)
		else
			BattleController:getInstance():playHurtAction(self._entityId, false)
		end

	end

	--持续受伤
	local function playKeepHurtAction()

		showFloatHp()

		if self:isUninit() then
			return
		end

		BattleController:getInstance():playHurtAction(self._entityId, false)

	end

	--恢复站立动作之前调用
	local function playBeforeResetAction()

		BattleController:getInstance():addBuffToEntity(self._entityId)
	end

	local function hurtEndFunc(entityId)

		self:_playHurtEnd()
	end

	--重置动作
	local function playResetAction()

		if dHurtNumLen > 1 then
			
			local param = {}
			param.node = renderNode
			-- param.hurtNum = hurtNumber
			param.hurtNum = displayHurtNumber
			param.isTotalNum = true

			BattleController:getInstance():displayHurtNum(param)

		end

		if self._entityCampType == BattleType.STRIKER then
			if hurtNumber < 0 then
				TimerManager.addTimer(250, function() 
					BattleStatisticManager:getInstance():addEnemyHurtTimes()
					if BattleManager:getInstance():getTreasureDungeonType() then
						local itemData = BattleManager:getInstance():getTreasureItem()
						BattleController:getInstance():displayTreasureText(self._entityId, itemData.quantity) 
					end
				end, 
				false)
			end
		end


		if self:isUninit() == true then
			return
		end

		--确保播放完成时处理
		for i = self._updateRealHurtIndex + 1, #self._realHurtList do
			self._entity:updateCurrentHp(self._realHurtList[i])
		end
		self._updateRealHurtIndex = #self._realHurtList

		if self._entity:getIsDead() then
			BattleController:getInstance():resetHurtAction(self._entityId, 0)
			self:_playEnemyDead()

		else
			BattleController:getInstance():playStandAction(self._entityId)
			BattleController:getInstance():resetHurtAction(
				self._entityId, 
				0.08, 
				hurtEndFunc
			)
		end
	end

	local actionArray = CCArray:create()

	--先取出第一个时间点
	local delayTime = self._attackParam.triggerTimeList[1]

	--格挡
	if isBlock then
		if delayTime < 0.2 then
			delayTime = delayTime + 0.2
		end
	end

	local delayAction = CCDelayTime:create(delayTime)
	actionArray:addObject(delayAction)
	actionArray:addObject(CCCallFuncN:create(playHurtAction))

	for i = 2, #self._attackParam.triggerTimeList do

		local nextTime = self._attackParam.triggerTimeList[i]
		local interval = nextTime - delayTime

		delayTime = nextTime

		--持续时间
		delayAction = CCDelayTime:create(interval)
		actionArray:addObject(delayAction)
		actionArray:addObject(CCCallFuncN:create(playKeepHurtAction))

	end

	actionArray:addObject(CCCallFuncN:create(playBeforeResetAction))

	--延迟500ms收工
	delayAction = CCDelayTime:create(0.5)
	actionArray:addObject(delayAction)
	actionArray:addObject(CCCallFuncN:create(playResetAction))

	self._hurtAction = CCSequence:create(actionArray)
	renderNode:runAction(self._hurtAction)

	--格挡
	if isBlock then
		BattleController:getInstance():playTargetTriggerText(self._entityId, 2)
		BattleController:getInstance():playEffectWithEntity(self._entityId, {23032})
	end

end

--敌方闪避
function FighterHurtState:_playEnemyMiss()

	local function missFunc()
		BattleController:getInstance():resetHurtAction(self._entityId, 0)
		self:_playHurtEnd()
	end

	BattleController:getInstance():playTargetTriggerText(self._entityId, 1)

	BattleController:getInstance():playMissAction(self._entityId, missFunc)

end

--敌人死亡
function FighterHurtState:_playEnemyDead()

	local function deadFunc()
		self:_playHurtEnd()
	end

	BattleController:getInstance():playDeadAction(self._entityId, deadFunc)

	if self._attackParam.targetCamp ~= BattleType.SKILL_ALLY then

		local buffDict
		if BattleManager:getInstance():getIsOB() then
			local reportData = BattleManager:getInstance():getReportData()
			local pas20023 = reportData:getPassiveSkill({
				atkerId = self._entityId,
				attackTimes = 1,
				entityId = self._entityId,
				scriptId = PassiveSkillScriptType.SCRIPT_TYPE_20023
			})
			if pas20023 then
				buffDict = pas20023.buffDict
			end
		else
			buffDict = PassiveSkillManager:getInstance():generate20023(
				self._entity, 
				self._attackParam.attackerId
			)

			if buffDict then
				BattleReportManager:getInstance():addPassiveSkill(
					self._entityId,
					1,
					{
					    [self._entityId] = {
					        {
					            [2] = PassiveSkillScriptType.SCRIPT_TYPE_20023,
					            [3] = buffDict
					        }
					    }
					}
				)
			end
		end

		if buffDict then
			local roundData = BattleController:getInstance():getRoundManager():getRoundData()
			for entityId, buffList in pairs(buffDict) do
				roundData:addBuff(entityId, buffList)
			end
		end
	end

end

--受伤状态结束
function FighterHurtState:_playHurtEnd()

	if self:isUninit() == true then
		return
	end

	if self._entity:getIsDead() == false then

		--攻击者自己的反应
		if self._attackParam.attackerId == self._entityId then

			Notifier.dispatchCmd(CmdRegist.ATTACKER_REACTION_COMPLETE)
		else
			local standState = FighterStandState:create()
			self._entity:getStateMachine():changeState(standState, true)
		end
	end

	self._hurtEndFunc(self._entityId)

end

function FighterHurtState:create()

	local fhs = FighterHurtState.new()
	fhs:init()
	return fhs
end

function FighterHurtState:uninit()

	if self._realHurtList then
		for i = self._updateRealHurtIndex + 1, #self._realHurtList do
			self._entity:updateCurrentHp(self._realHurtList[i])
		end
	end

	self._entity = nil
	-- self._entityId = 0
	self._hurtEndFunc = nil

	self._isUninit = true

end

function FighterHurtState:init()
	self:setType("FighterHurtState")
end


--庆祝状态
FighterCelebrateState = class("FighterCelebrateState", StateBase:create())

function FighterCelebrateState:ctor()
end

function FighterCelebrateState:init()
	self:setType("FighterCelebrateState")
end

function FighterCelebrateState:enter(entity)

	Act_Factory:runWinAction(entity)

end

function FighterCelebrateState:create()

	local fcs = FighterCelebrateState.new()
	fcs:init()
	return fcs
end


--逃跑状态
FighterFleeState = class("FighterFleeState", StateBase:create())

function FighterFleeState:ctor()
end

function FighterFleeState:init()
	self:setType("FighterFleeState")
end

function FighterFleeState:enter(entity)

	entity:setIsFlee(true)

	local function fleeFunc(entityId)
		BattleController:getInstance():removeEntity(entityId)
		Notifier.dispatchCmd(
    		CmdName.BATTLE_FIGHTER_BROADCAST_END, 
    		{
	    		bcType = BattleType.BROADCAST_ATTACKER, 
	    		entityId = entityId
	    	}
		)
		
		Notifier.dispatchCmd(
    		CmdName.BATTLE_FIGHTER_BROADCAST_END, 
    		{
	    		bcType = BattleType.BROADCAST_TARGET, 
	    		attackerId = entityId, 
	    		entityId = entityId
    		}
		)
	end

	BattleController:getInstance():playFleeAction(entity:getEntityID(), fleeFunc)

end

function FighterFleeState:create()

	local ffs = FighterFleeState.new()
	ffs:init()
	return ffs
end


--防御状态
FighterDefenseState = class("FighterFleeState", StateBase:create())

function FighterDefenseState:ctor()
end

function FighterDefenseState:init()
	self:setType("FighterDefenseState")
end

function FighterDefenseState:enter(entity)

	local entityId = entity:getEntityID()

	--暂时不干任何事

	if entity:getEntityType() == BattleType.ATTACKER then
		entity:setDirection(BattleType.directionType.RIGHT)
	else
		entity:setDirection(BattleType.directionType.LEFT)
	end

	Notifier.dispatchCmd(
		CmdName.BATTLE_FIGHTER_BROADCAST_END, 
		{
    		bcType = BattleType.BROADCAST_ATTACKER, 
    		entityId = entityId
    	}
	)
		
	Notifier.dispatchCmd(
		CmdName.BATTLE_FIGHTER_BROADCAST_END, 
		{
    		bcType = BattleType.BROADCAST_TARGET, 
    		attackerId = entityId, 
    		entityId = entityId
		}
	)

end

function FighterDefenseState:create()
	local fds = FighterDefenseState.new()
	fds:init()
	return fds
end


-----------------特殊的技能效果表现------------------

--技能连射表现状态
FighterSkillDartleState = class("FighterSkillDartleState", StateBase:create())

FighterSkillDartleState.MAX_DARTLE = 10

FighterSkillDartleState._roundManager = nil

FighterSkillDartleState._entity = nil
FighterSkillDartleState._entityId = nil

FighterSkillDartleState._targetList = nil
FighterSkillDartleState._dartleTargetDict = nil

FighterSkillDartleState._dartleTimesTargetList = nil

FighterSkillDartleState._currentShootTimes = 1

FighterSkillDartleState._shootFunc = nil

FighterSkillDartleState._attackParam = nil

--受击次数字典
FighterSkillDartleState._targetHurtTimesDict = nil
FighterSkillDartleState._targetHurtEndFunc = nil

FighterSkillDartleState._targetHurtStateDict = nil


function FighterSkillDartleState:ctor()

	self._targetHurtStateDict = {}
	self._targetHurtTimesDict = {}

	self._dartleTargetDict = {}


	self._shootFunc = function()
	    self:_shoot()
	end

	self._targetHurtEndFunc = function(entityId)

	    self._targetHurtStateDict[entityId] = nil

	    local entity = EntityManager:getInstance():getEntityWithID(entityId)

	    self._targetHurtTimesDict[entityId] = self._targetHurtTimesDict[entityId] - 1

	    -- print("///////////////////////剩餘受擊次數", self._targetHurtTimesDict[entityId])

	    --攻击者死了, 目标死了, 受击次数够了
	    if self._entity:getIsDead() == true or 
	    	entity:getIsDead() == true or 
	    	self._targetHurtTimesDict[entityId] <= 0 then

	    	Notifier.dispatchCmd(
	    		CmdName.BATTLE_FIGHTER_BROADCAST_END, 
	    		{
		    		bcType = BattleType.BROADCAST_TARGET, 
		    		attackerId = self._entityId, 
		    		entityId = entityId
	    		}
    		)

	    end

	end


end

function FighterSkillDartleState:init()
	self:setType("FighterSkillDartleState")
end

function FighterSkillDartleState:enter(entity)

	self._entity = entity
	self._entityId = entity:getEntityID()

	self._roundManager = BattleController:getInstance():getRoundManager()

	self._skillData = BattleController:getInstance():getAttackSkillData(self._entityId)

	--攻击者参数
	self._attackParam = {}
	self._attackParam.attackerId = self._entityId  --攻击者
	self._attackParam.targetNum = 1       --目标数量
	self._attackParam.triggerTimeList = {0}  --触发时间列表
	self._attackParam.skillData = self._skillData
	self._attackParam.targetCamp = getSkillTargetCamp(self._skillData.cfg.atkTargetType)  --目标敌/友方

	local skillIndex = self._roundManager:getEntitySkillIndex(self._entity)

	local function triggerFunc()
		self:_attackTrigger()
	end

	local function attackFunc()

		self:_attackEnd()
	end

	self._targetGroupData = BattleController:getInstance():getHurtGroup(self._entityId)
	self._targetList = clone(self._targetGroupData.attackTargetGroup)


	BattleController:getInstance():playAttackAction(
		self._entityId, 
		skillIndex, 
		attackFunc, 
		triggerFunc
	)

end

function FighterSkillDartleState:_attackTrigger()

	if BattleManager:getInstance():getIsOB() == false then
		self:_generateAttackParam()
	else
		self:_generateAttackParamOB()
	end
	-- self:_generateAttackParam()

	-- local targetList = self._roundManager:getHurtGroup(self._entityId).attackTargetGroup
	self._targetGroupData = BattleController:getInstance():getHurtGroup(self._entityId)
	local targetList = self._targetGroupData.attackTargetGroup
	for i, entityId in ipairs(targetList) do
		if not self._dartleTargetDict[entityId] then
			self._targetHurtTimesDict[entityId] = 0
			self._targetHurtEndFunc(entityId)
		end
	end

	self._currentShootTimes = 1
	TimerManager.addTimer(100, self._shootFunc, true)

	self:_shoot()

end

function FighterSkillDartleState:_attackEnd()

	local standState = FighterStandState:create()
	self._entity:getStateMachine():changeState(standState)
	Notifier.dispatchCmd(
		CmdName.BATTLE_FIGHTER_BROADCAST_END, 
		{
			bcType = BattleType.BROADCAST_ATTACKER, 
			entityId = self._entityId
		}
	)

end

function FighterSkillDartleState:_shoot()

	if self._currentShootTimes > #self._dartleTimesTargetList then
		TimerManager.removeTimer(self._shootFunc)
		return
	end

	local hurtDict = self._dartleTimesTargetList[self._currentShootTimes]

	local target

	local function flyFunc(targetId, shootTimes)

		target = EntityManager:getInstance():getEntityWithID(targetId)

		local hurtState = self._targetHurtStateDict[targetId]
		if hurtState then
			
			hurtState:uninit()
			self._targetHurtEndFunc(targetId)
			target:getStateMachine():setCurState(nil)
		end

		local dartleHurtParamDict = self._dartleTimesTargetList[shootTimes]

		hurtState = FighterHurtState:create()
		self._targetHurtStateDict[targetId] = hurtState

		hurtState:setHurtEndFunc(self._targetHurtEndFunc)
		hurtState:setAttackParam(self._attackParam)
		hurtState:setTargetParam(dartleHurtParamDict[targetId])
		target:getStateMachine():changeState(hurtState)
	end

	for entityId, hurtData in pairs(hurtDict) do

		target = EntityManager:getInstance():getEntityWithID(entityId)
		BattleController:getInstance():playEffectFlyTo({
			attacker = self._entity,
			target = target,
			effectId = self._skillData.args.middleAttackEffectIds[1],
			traceType = EffectMoveTraceType.CURVE,
			callback = flyFunc,
			callParam = self._currentShootTimes
		})
	end

	self._currentShootTimes = self._currentShootTimes + 1

end

--生成攻击参数
function FighterSkillDartleState:_generateAttackParam()

	local hurtDict = {}

	local dartleTimes = 1

	self._dartleTimesTargetList = {}

	local maxDartleTimes = self._skillData.cfg._atkScriptArgs[1][1]

	while dartleTimes <= maxDartleTimes do

		if #self._targetList == 0 then
			break
		end

		self._dartleTimesTargetList[dartleTimes] = {}

		local targetParam = {}
		targetParam.skillTargetTypeId = SkillTargetType.targetType_5
		targetParam.atkEnt = self._entity
		targetParam.leftTeam = self._targetList
		targetParam.rightTeam = self._targetList
		targetParam.targetNum = 1

		local targetList = getSkillTargetGroup(targetParam)

		BattleReportManager:getInstance():addDartleTarget(dartleTimes, targetList)

		local hurtData
		local target

		for i, entityId in ipairs(targetList) do

			self._dartleTargetDict[entityId] = true

			target = EntityManager:getInstance():getEntityWithID(entityId)

			hurtData = self._roundManager:calcAtkHurt(self._entityId, entityId)
			hurtData.entityId = entityId

			if hurtDict[entityId] then
				hurtDict[entityId] = hurtDict[entityId] + hurtData.hurtNumber
			else
				hurtDict[entityId] = hurtData.hurtNumber
			end

			-- print("///////////////////傷害", entityId, hurtDict[entityId], target:getCurrentHp())

			--应该扑街了
			if hurtDict[entityId] >= target:getCurrentHp() + target:getCurrentShieldHp() then

				for j, targetId in ipairs(self._targetList) do

					if entityId == targetId then
						table.remove(self._targetList, j)
						break
					end
				end

			end

			if not self._targetHurtTimesDict[entityId] then
				self._targetHurtTimesDict[entityId] = 0
			end

			self._targetHurtTimesDict[entityId] = self._targetHurtTimesDict[entityId] + 1

			self._dartleTimesTargetList[dartleTimes][entityId] = hurtData

			BattleReportManager:getInstance():addHurtData(
				dartleTimes, 
				entityId, 
				hurtData
			)

		end

		dartleTimes = dartleTimes + 1

	end

end

function FighterSkillDartleState:_generateAttackParamOB()

	local actionData = self._roundManager:getAttackerActionData()
	local maxDartleTimes = #actionData.dartleTarget

	local hurtDict = {}

	local dartleTimes = 1

	self._dartleTimesTargetList = {}

	for dartleTimes, targetList in ipairs(actionData.dartleTarget) do

		self._dartleTimesTargetList[dartleTimes] = {}

		local hurtData

		for i, entityId in ipairs(targetList) do

			self._dartleTargetDict[entityId] = true

			hurtData = actionData.hurtData[dartleTimes][1][2]
			hurtData.entityId = entityId

			if not self._targetHurtTimesDict[entityId] then
				self._targetHurtTimesDict[entityId] = 0
			end

			self._targetHurtTimesDict[entityId] = self._targetHurtTimesDict[entityId] + 1

			self._dartleTimesTargetList[dartleTimes][entityId] = hurtData

		end
	end

end

function FighterSkillDartleState:create()
	local fsds = FighterSkillDartleState.new()
	fsds:init()
	return fsds
end
