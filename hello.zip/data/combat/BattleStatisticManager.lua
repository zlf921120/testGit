--
-- Author: thisgf
-- Date: 2014-10-18 11:58:08
-- 战斗统计数据管理

BattleStatisticManager = class("BattleStatisticManager")

BattleStatisticManager._hurtRecordDict = nil

BattleStatisticManager._deadRecordDict = nil

BattleStatisticManager._hurtSummaryData = nil
BattleStatisticManager._deadSummaryData = nil

--敌人受伤次数
BattleStatisticManager._enemyHurtTimes = nil

local _instance

function BattleStatisticManager:ctor()

	self._hurtRecordDict = {}
	self._deadRecordDict = {}

	self._hurtSummaryData = {}

	self._enemyHurtTimes = 0

end

function BattleStatisticManager:getInstance()

	if not _instance then
		_instance = BattleStatisticManager.new()
	end

	return _instance
end

--[[
    添加伤害统计
]]
function BattleStatisticManager:addHurt(entityId, value)

	local hurt = self._hurtRecordDict[entityId]
	if hurt then
		hurt = hurt + value
	else
		hurt = value
	end

	self._hurtRecordDict[entityId] = hurt

	local entity = EntityManager:getInstance():getEntityWithID(entityId)
	if entity and entity:getEntityType() == BattleType.ATTACKER then
		if not self._hurtSummaryData.allyTotalHurt then
			self._hurtSummaryData.allyTotalHurt = 0
		end
		self._hurtSummaryData.allyTotalHurt = self._hurtSummaryData.allyTotalHurt + value
	end

end

function BattleStatisticManager:getHurt(entityId)
	return self._hurtRecordDict[entityId]
end

function BattleStatisticManager:getHurtDict()
	return self._hurtRecordDict
end

--[[
    获取伤害统计汇总数据
    @return {allyTeam = {}, enemyTeam = {}, pvType = int}
]]
function BattleStatisticManager:getHurtSummaryData()

	local allyHurtTeam = {}
	local enemyHurtTeam = {}

	self._hurtSummaryData.allyTeam = allyHurtTeam
	self._hurtSummaryData.enemyTeam = enemyHurtTeam
	self._hurtSummaryData.pvType = BattleManager:getInstance():getPvType()
	self._hurtSummaryData.type = BattleManager:getInstance():getType()
	self._hurtSummaryData.resDungeonStatus = BattleManager:getInstance():getStartData().resDungeonStatus

	local waveMaxIndex = BattleManager:getInstance():getWaveIndex()

	local allyIndex = 1
	local enemyIndex = 1

	local allyTeam = EntityManager:getInstance():getAllyEntityDict()

	local enemyTeam = EntityManager:getInstance():getEnemyWaveEntityDict(waveMaxIndex)

	local hurtNum

	if allyTeam then
		for entityId, entity in pairs(allyTeam) do

			if self._hurtRecordDict[entityId] then
				hurtNum = math.ceil(self._hurtRecordDict[entityId])
			else
				hurtNum = 0
			end

			allyIndex = #allyHurtTeam + 1

			for i, hurt in ipairs(allyHurtTeam) do

				if entity:getBattleFieldPosition() < hurt.pos then
					allyIndex = i
					break
				end
			end

			table.insert(
				allyHurtTeam, 
				allyIndex, 
				{
				    hurt = hurtNum, 
				    baseInfo = entity:getBaseInfo(), 
				    pos = entity:getBattleFieldPosition()
				}
			)

		end
	end

	if enemyTeam then
		for entityId, entity in pairs(enemyTeam) do

			if self._hurtRecordDict[entityId] then
				hurtNum = math.ceil(self._hurtRecordDict[entityId])
			else
				hurtNum = 0
			end

			enemyIndex = #enemyHurtTeam + 1

			for i, hurt in ipairs(enemyHurtTeam) do

				if entity:getBattleFieldPosition() < hurt.pos then
					enemyIndex = i
					break
				end
			end

			table.insert(
				enemyHurtTeam, 
				enemyIndex, 
				{
				    hurt = hurtNum, 
				    baseInfo = entity:getBaseInfo(), 
				    pos = entity:getBattleFieldPosition()
				}
			)
		end
	end

	return self._hurtSummaryData

end

--[[
    获取己方队伍总伤害
]]
function BattleStatisticManager:getAllyTotalHurt()
	return self._hurtSummaryData.allyTotalHurt
end

function BattleStatisticManager:setDead(entityId, value)

	self._deadRecordDict[entityId] = value
end

function BattleStatisticManager:getDeadDict()
	return self._deadRecordDict
end

--[[
    获取死亡统计数据
    己方死亡
    怪物死亡
    @return {allyNumDead = int, monsterDeadDict = {}}
]]
function BattleStatisticManager:getDeadSummaryData()

	if self._deadSummaryData then
		return self._deadSummaryData
	end

	self._deadSummaryData = {}

	local allyNumDead = 0
	local monsterDeadDict = {}

	local entity

	for entityId, _ in pairs(self._deadRecordDict) do

		entity = EntityManager:getInstance():getEntityWithID(entityId)

		if entity then

			if entity:getEntityType() == BattleType.ATTACKER then
				allyNumDead = allyNumDead + 1
			else
				if entity:getFighterType() == BattleType.MONSTER then

					if not monsterDeadDict[entity:getAvatorId()] then
						monsterDeadDict[entity:getAvatorId()] = 1
					else
						monsterDeadDict[entity:getAvatorId()] = monsterDeadDict[entity:getAvatorId()] + 1
					end
				end
			end
		end
	end

	self._deadSummaryData.allyNumDead = allyNumDead
	self._deadSummaryData.monsterDeadDict = monsterDeadDict

	return self._deadSummaryData

end

function BattleStatisticManager:addEnemyHurtTimes()
	self._enemyHurtTimes = self._enemyHurtTimes + 1

	Notifier.dispatchCmd(CmdName.BATTLE_UPDATE_ENEMY_HURT_TIMES)

end

--[[
    敌人受伤次数    
]]
function BattleStatisticManager:getEnemyHurtTimes()
	return self._enemyHurtTimes
end

--[[
    获取队伍血值信息
]]
function BattleStatisticManager:getTeamHpData()

	local selfHeros = {}
	local targetHeros = {}

	local entityDict = EntityManager:getInstance():getEntityDict()

	for _, entity in pairs(entityDict) do
		if entity:getEntityType() == BattleType.ATTACKER then
			--攻击方
			selfHeros[entity:getAvatorId()] = {entity:getCurrentHp(), entity:getTotalHp()}
		elseif entity:getEntityType() == BattleType.STRIKER then
			--受击方
			targetHeros[entity:getAvatorId()] = {entity:getCurrentHp(), entity:getTotalHp()}
		end
	end

	return selfHeros, targetHeros

end

function BattleStatisticManager:clearData()
	
	self._hurtRecordDict = {}
	self._hurtSummaryData = {}

	self._deadRecordDict = {}
	self._deadSummaryData = nil

	self._enemyHurtTimes = 0

end