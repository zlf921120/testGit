BattleInterface = class("BattleInterface")

local isInitAsset = false

function BattleInterface:create()
	local objBattleInterface = BattleInterface.new()
	objBattleInterface:init()
	return objBattleInterface
end

function BattleInterface:init()

	require("combatConfig")

	require("animate/ActFactory")

	require("entityBase")
	require("stateBase")

	require("ItemManager")
	require("HeroManager")
	require("MonsterManager")

	require("stateMachine")
	require("BattleFighterState")
	require("EliminateStone")

	require("role")
	require("entityManager")

	require("roundData")
	require("skillTargetScript")
	require("roundManager")
	require("monster")

	require("BattleGuard")

	require("BattleController")
	require("BattleRoleAvatarNode")

	require("touchBattleLayer")
	require("battleSchedule")

	require("SkillManager")

	require("combatDataStorage")

	require("TimerManager")
	require("PassiveSkillManager")
	require("AIManager")

	require("battleSceneManager")

	require("BattleWindowManager")

	require("DungeonClearanceView")
	require("BattleFailView")
	require("BattleSettlementNormalView")
	require("BattleSettlementCardView")
	require "BattleSettlementView"
	require("ArenaManager")
	require("BattleFighterNode")
	require("GloryDataProxy")

	require "animate/ActionManager"
	require "AudioEngine"

	require "BattleStatisticManager"
	require "BattleStatisticView"
	require "BattlePlaybackView"

	require "GuideEvent"
	require "GuideCfg"

	require "BattleProcessData"

	require "BattleUtil"
	require "CombatVO"
	require "ReportRoundManager"
	require "ResContendManager"

	self:_initAsset()
	
end

function BattleInterface:destroy()

end
	
function BattleInterface:uninit()
	
end

function BattleInterface:_initAsset()

	if isInitAsset == true then
		return
	end

	isInitAsset = true

	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/battleui/battle_ui.plist")

end


--响应开始战斗
function BattleInterface:beginBattle()
    
	self._battleSceneManager = BattleSceneManager:create()
    
	GuideDataProxy:getInstance():cleanDungeonTutorialCond()
	GuideDataProxy:getInstance():cleanDungeonStoryCond()
    
    self._battleSceneManager:beginBattle()

   	AudioEngine.playRandomBattleMuisc(true)

end

--战斗结束
function BattleInterface:endBattle()

    self:destroy()

	self._battleSceneManager:endBattle()

	self._battleSceneManager = nil

	SceneCtrl:getInstance():goToScene(CmdName.MAIN_SCENE)
	
end
