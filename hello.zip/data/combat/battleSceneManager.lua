BattleSceneManager = class("BattleSceneManager")

BattleSceneManager._bm = nil
BattleSceneManager._startData = nil

BattleSceneManager._onUpdateWaveFunc = nil

function BattleSceneManager:create()
	local objBattleSceneManager = BattleSceneManager.new()
	objBattleSceneManager:init()
	return objBattleSceneManager
end

function BattleSceneManager:init()

	self._bm = BattleManager:getInstance()

	self.battleSche = nil
	self.curSceneIdx = 0
	self.totalSceneNums = 0
	
	--友方字典
	self._allyDict = {}

	--敌人字典
	self._enemyDict = {}
	
	self._onUpdateWaveFunc = function()
	    self:_nextWave()
	end

	Notifier.regist(CmdName.BATTLE_UPDATE_WAVE, self._onUpdateWaveFunc)

end

function BattleSceneManager:uninit()

	self._allyDict = {}
	self._enemyDict = {}

	self._bm = nil

	self.battleSche = nil
	
	Notifier.remove(CmdName.BATTLE_UPDATE_WAVE, self._onUpdateWaveFunc)

end

--初始化场景所需数据
function BattleSceneManager:_initBattleSceneData()

end

--观战时的友方英雄
function BattleSceneManager:_createAllyHeroForOB()

	local reportData = self._bm:getReportData()
	local teamList = reportData:getAllyTeamList()

	local positionList = {}

	local heroInfo
	local attrData
	for i, fighter in ipairs(teamList) do

		heroInfo = clone(HeroManager:getInstance():getHeroInfoByBaseId(fighter.baseInfo.id))
		heroInfo.fighterId = fighter.id
		heroInfo:setModelId(fighter.baseInfo.modelId)
		attrData = heroInfo:getEncryptAttrData()
		attrData:setIsEncrypt(false)
		attrData:setAttr(AttrHelper.attr_flag.hp, fighter.baseInfo.totalHp)
		attrData:setAttr(AttrHelper.attr_flag.hp_cur, fighter.baseInfo.hp)
		self._allyDict[fighter.position] = heroInfo

		table.insert(positionList, fighter.position)
		
	end

	table.sort(positionList, function(a, b) if a > b then return true end end)
	for i, pos in ipairs(positionList) do
		heroInfo = self._allyDict[pos]
		heroInfo.teamIndex = i
	end

end

--创建友方英雄数据
function BattleSceneManager:_createAllyHero()

	local startData = self._startData

	battleType = self._startData.battleType

	--创建己方队伍
	self._allyDict = {}

	local teamHeroList

	--剧情战斗(模拟英雄)
	if startData.teamType == TeamType.PLOT then

		teamHeroList = GuideDataProxy:getInstance():getHeroes()

		for pos, heroInfo in pairs(teamHeroList) do

			heroInfo.currentHp = 0
			-- heroInfo.attrData = BattleEncryptAttrData:create()
			local attrData = heroInfo:getEncryptAttrData()
			attrData:setIsEncrypt(false)
			attrData:setClientAttrs(heroInfo.attrs)

			self._allyDict[pos] = heroInfo
		end

	else

		teamHeroList = clone(TeamManager:getInstance():getBattleHeroList(startData.teamType))
		local heroInfo
		for position, heroId in pairs(teamHeroList) do

			heroInfo = startData.selfRoleData.heroDict[heroId]
			heroInfo.pos = position

			if heroInfo:getEncryptAttrData():getAttr(AttrHelper.attr_flag.hp_cur) == 0 then
				cclog("////////////////////////////獲取英雄%d的屬性時發現血值為0", heroId)
			end

			heroInfo.currentHp = heroInfo:getEncryptAttrData():getAttr(AttrHelper.attr_flag.hp_cur)

			self._allyDict[position] = heroInfo
			
		end
	end

	self:_setFighterId(self._allyDict)

end

--创建观战中的敌人
function BattleSceneManager:_createEnemyForOB()

	self._enemyDict = {}

	local pvType = self._bm:getPvType()
	local reportData = self._bm:getReportData()

	local teamList = reportData:getEnemyTeamList(self._bm:getWaveIndex())

	if not teamList then
		return
	end

	local attrData

	if pvType == BattleType.PVE then

		repeat
			if self._startData.battleType == BattleType.RES_DUNGEON then
				if self._startData.resDungeonStatus and self._startData.resDungeonStatus == 2 then
					for i, fighter in ipairs(teamList) do

						local guardInfo = clone(
							ResContendManager:getInstance():getGuardData(
								fighter.baseInfo.baseId
							)
						)
						guardInfo.fighterId = fighter.id
						guardInfo:setModelId(fighter.baseInfo.modelId)
						attrData = guardInfo:getEncryptAttrData()
						attrData:setIsEncrypt(false)
						attrData:setAttr(AttrHelper.attr_flag.hp, fighter.baseInfo.totalHp)
						attrData:setAttr(AttrHelper.attr_flag.hp_cur, fighter.baseInfo.hp)

						self._enemyDict[fighter.position] = guardInfo
					end

					break
				end
			end

			for i, fighter in ipairs(teamList) do

				self._enemyDict[fighter.position] = {
					baseId = fighter.baseId, 
					fighterId = fighter.id
				}
			end

		until true

	else
		for i, fighter in ipairs(teamList) do

			local heroInfo = clone(HeroManager:getInstance():getHeroInfoByBaseId(fighter.baseInfo.id))
			heroInfo.fighterId = fighter.id
			heroInfo:setModelId(fighter.baseInfo.modelId)
			attrData = heroInfo:getEncryptAttrData()
			attrData:setIsEncrypt(false)
			attrData:setAttr(AttrHelper.attr_flag.hp, fighter.baseInfo.totalHp)
			attrData:setAttr(AttrHelper.attr_flag.hp_cur, fighter.baseInfo.hp)
			self._enemyDict[fighter.position] = heroInfo
		end
	end

end

--创建敌人
function BattleSceneManager:_createEnemy()
	print("create enemy")
	print("create enemy")
	print("create enemy")
	print("create enemy")
	print("create enemy")
	print("create enemy")
	local startData = self._startData

	self._enemyDict = {}

	local battleType = startData.battleType

	local enemyInfo
	local monsterDict

	--创建pvp敌方队伍
	self._enemyDict = {}
	if battleType == BattleType.ARENA or 
		battleType == BattleType.SKY_WAR or battleType == BattleType.FRIEND then

		enemyInfo = startData.otherRoleInfo
		for position, heroInfo in pairs(enemyInfo:getBattleData()) do

			heroInfo = clone(heroInfo)
			heroInfo.currentHp = 0
			self._enemyDict[position] = heroInfo
		end

	elseif battleType == BattleType.GLORY_ROAD then
		--荣耀之路

		enemyInfo = startData.otherRoleInfo
		local gloryEnemyHpInfo = GloryDataProxy:getInstance():getEnemyHpInfo(enemyInfo.role_id)
		for position, heroInfo in pairs(enemyInfo:getBattleData()) do

			heroInfo = clone(heroInfo)
			heroInfo.currentHp = 0
			self._enemyDict[position] = heroInfo

		end

	elseif battleType == BattleType.GUILD_BOSS then
		--公会boss
		monsterDict = self._startData:getWaveDataWithIndex(self._bm:getWaveIndex()).monsterDict
		for position, monsterId in pairs(monsterDict) do
			if monsterId == startData.boss.id then
				self._enemyDict[position] = {
				    baseId = monsterId, 
				    hp = self._bm:getDecryptValue(startData.boss.hp)
				}
			else
				self._enemyDict[position] = {baseId = monsterId}
			end
		end

	elseif battleType == BattleType.GUILD_FIGHT then
		--公会战
		enemyInfo = startData.otherRoleInfo
		local guildEnemyHpInfo = GuildDataProxy:getInstance():getFightEnemyVoByRoleId(enemyInfo.role_id)
		for position, heroInfo in pairs(enemyInfo:getBattleData()) do

			heroInfo = clone(heroInfo)
			heroInfo.currentHp = 0
			self._enemyDict[position] = heroInfo

		end
	elseif battleType == BattleType.RES_DUNGEON then

		if startData.guards then
			for position, gd in pairs(startData.guards) do
				self._enemyDict[position] = gd
			end
		else
			monsterDict = self._startData:getWaveDataWithIndex(self._bm:getWaveIndex()).monsterDict
			for position, monsterId in pairs(monsterDict) do
				self._enemyDict[position] = {baseId = monsterId}
			end
		end

	else

		monsterDict = self._startData:getWaveDataWithIndex(self._bm:getWaveIndex()).monsterDict
		for position, monsterId in pairs(monsterDict) do
			self._enemyDict[position] = {baseId = monsterId}
		end
	end

	self:_setFighterId(self._enemyDict)

end

function BattleSceneManager:_setFighterId(fighterDict)

	for _, fighterData in pairs(fighterDict) do
		fighterData.fighterId = self._bm:generateFighterId()
	end

end

function BattleSceneManager:beginBattle()

	self._startData = self._bm:getStartData()

	--获取初始数据
	self:_initBattleSceneData()
	if self._bm:getIsOB() then
		self:_createAllyHeroForOB()
	else
		self:_createAllyHero()

		BattleReportManager:getInstance():addRole({
			camp = BattleType.ATTACKER,
			info = {
			    name = CharacterManager:getInstance():getBaseData():getName(),
			    level = CharacterManager:getInstance():getTeamData():getLev(),
			    faceId = CharacterManager:getInstance():getBaseData():getFaceId()
			}
		})

		if self._bm:getPvType() == BattleType.PVP then
			BattleReportManager:getInstance():addRole({
				camp = BattleType.STRIKER,
				info = {
				    name = self._startData.otherRoleInfo.role_name,
				    level = self._startData.otherRoleInfo.team_lev,
				    faceId = self._startData.otherRoleInfo.face_id
				}
			})
		end
	end
	-- self:_createAllyHero()

	self.battleSche = BattleSchedule:create()
	self.battleSche:initBattle()

	self.battleSche:createAllyTeam(self._allyDict)

	self:_fightNextWave()

	self.battleSche:begin()

end

--下一波
function BattleSceneManager:_nextWave()

	self:_fightNextWave()

	self.battleSche:beginNextFight()

end

function BattleSceneManager:_fightNextWave()

	self.battleSche:setWaveData(
		self._startData:getWaveDataWithIndex(
			self._bm:getWaveIndex()
		)
	)
	if self._bm:getIsOB() then
		self:_createEnemyForOB()
	else
		self:_createEnemy()
		BattleReportManager:getInstance():setCurrentWave(self._bm:getWaveIndex())
	end
	-- self:_createEnemy()

	self.battleSche:createEnemyTeam(self._enemyDict)

end

function BattleSceneManager:clear()

end

function BattleSceneManager:endBattle()
	
	self.battleSche:terminateBattle()

	self:uninit()
end
