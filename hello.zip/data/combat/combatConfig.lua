require "BattleStoneEnum"

CmdRegist = {}
CmdRegist.ATTACK_NEXT_PLAYER = "attackNextPlayer"
CmdRegist.SHAKE_SCREEN = "shakeScreen"
CmdRegist.DISPLAY_HURT_NUM = "displayHurtNum"
CmdRegist.TIME_EVENT_CLEAR_REGIST = "timeEventClearRegist"
CmdRegist.TIME_EVENT_CLEAR_REMOVE = "timeEventClearRemove"
CmdRegist.ENTER_BATTLE_SCENE = "enterBattleScene"
CmdRegist.BACKGROUND_CROSS_EVENT = "backgroundCrossEvent"

CmdRegist.ATTACKER_REACTION_COMPLETE = "BattleFightEvent.ATTACKER_REACTION_COMPLETE"  --攻击者的反应完成

CmdRegist.GROUP_EFFECT_COMPLETE = "BattleFightEvent.GROUP_EFFECT_COMPLETE"   --群体特效完成

--战斗场景文件路径
BattleSceneFilePrefix = "ui/scene"
BattleSceneFileType = "jpg"

BattleType = {}
--战斗方
BattleType.ATTACKER = 1  --攻击方
BattleType.STRIKER	= 2	 --受击方

--战斗类型
BattleType.PVE = 1		--PVE战斗类型
BattleType.PVP = 2		--PVP战斗类型

BattleType.HERO_NUMS = 6	--默认英雄数量

BattleType.DUNGEON = 1  --副本战斗类型
BattleType.CLIMBING = 2 --爬塔战斗类型
BattleType.ARENA = 3 --竞技场
BattleType.GLORY_ROAD = 4 --荣耀之路
BattleType.PLOT = 5  --剧情战斗
BattleType.GUILD_BOSS = 6  --公会战斗
BattleType.RES_DUNGEON = 7  --资源争夺副本
BattleType.GUILD_FIGHT = 8 --公会战
BattleType.RIDDLE_DUNGEON = 9 --解谜副本
BattleType.SKY_WAR = 10 --天空之役
BattleType.FRIEND = 11 --好友切磋
BattleType.OBSERVE = 100 --观战

BattleType.SKILL_ALLY = 1   --技能友方
BattleType.SKILL_ENEMY = 2  --技能敌方

BattleType.BROADCAST_ATTACKER = 1  --播报攻击方
BattleType.BROADCAST_TARGET = 2   --播报目标方

--角色类型
BattleType.ROLE = 1
--怪物类型
BattleType.MONSTER = 2
--守卫类型
BattleType.GUARD = 3


--移动时间
BattleType.moveTime = 
{
    ATTACK = 0.2,
    RETURN = 0.1	
}

--特效范围
BattleType.effectRange = 
{
	SINGLE = 1,
	GROUP = 2
}

--战斗ID类型
BattleIDType = 
{
	ARENA = 22000,
	GLORY_ROAD = 23000,
	GUILD_FIGHT = 24000,
	SKY_WAR = 25000,
	RES_DUNGEON = 90000,
	FRIEND = 100000
}

--方向
BattleType.directionType = 
{
	LEFT = 1,
	RIGHT = 2
}

--怪物类型
BattleType.monsterType = 
{
	--小怪
	MOBS = 1,
	--boss
	BOSS = 2
}

--近程靠近类型
BattleType.closeType = 
{
	--跑
	RUN = 1,
	--闪
	BLINK = 2
}

--数值类型
BattleType.numberType = 
{
	--值
	VALUE = 1,
	--万分比
	PERCENT = 2
}

--战场位置类型
BattlePosType = 
{
	--前中后
	FRONT_1 = 1,
	FRONT_2 = 2,
	MIDDLE_1 = 3,
	MIDDLE_2 = 4,
	BACK_1 = 5,
	BACK_2 = 6
}

BattlePosType.rowType = 
{
	FRONT = 1,
	MIDDLE = 2,
	BACK = 3
}

--位置对应行
BattlePosType.posToRow = 
{
	[BattlePosType.FRONT_1] = BattlePosType.rowType.FRONT,
	[BattlePosType.FRONT_2] = BattlePosType.rowType.FRONT,
	[BattlePosType.MIDDLE_1] = BattlePosType.rowType.MIDDLE,
	[BattlePosType.MIDDLE_2] = BattlePosType.rowType.MIDDLE,
	[BattlePosType.BACK_1] = BattlePosType.rowType.BACK,
	[BattlePosType.BACK_2] = BattlePosType.rowType.BACK
}

--行对位置
BattlePosType.rowToPos = 
{
	[BattlePosType.rowType.FRONT] = {
		BattlePosType.FRONT_1, 
		BattlePosType.FRONT_2
	},
	[BattlePosType.rowType.MIDDLE] = {
		BattlePosType.MIDDLE_1, 
		BattlePosType.MIDDLE_2
	},
	[BattlePosType.rowType.BACK] = {
		BattlePosType.BACK_1, 
		BattlePosType.BACK_2
	}
}

BattlePosType.posList = 
{
	BattlePosType.FRONT_1,
	BattlePosType.FRONT_2,
	BattlePosType.MIDDLE_1, 
	BattlePosType.MIDDLE_2,
	BattlePosType.BACK_1, 
	BattlePosType.BACK_2
}

--技能数据配置
SkillDataCfg = {}
SkillDataCfg.NEAR_SKILL = 0		--近程攻击技能
SkillDataCfg.FAR_SKILL = 1		--远程攻击技能

--近程普通攻击
SkillDataCfg.NEAR_NORMAL_ATTACK = 200001
--远程普通攻击
SkillDataCfg.FAR_NORMAL_ATTACK = 200002
--防御
SkillDataCfg.DEFENSE = 299998
--逃跑
SkillDataCfg.FLEE = 299999

--[[
朝向目标攻击者到受击者	0
垂直向下	1
斜45度	2
]]--
EffectMoveTraceType = {}
EffectMoveTraceType.MOVETO = 0
EffectMoveTraceType.DOWN = 1
EffectMoveTraceType.OBLIQUE45 = 2
--曲线飞行
EffectMoveTraceType.CURVE = 3

EffectMoveTraceType.FLY_DIRECT_TYPE = 
{
	--平行
	PARALLEL = 1,
	--面向目标
	TO_TARGET = 2
}

ROLE_POSITION = 
{
	[1] = {x=380, y=380},
	[2] = {x=315, y=280},
	[3] = {x=250, y=380},
	[4] = {x=185, y=280},
	[5] = {x=120, y=380},
	[6] = {x=55, y=280}
}

--monster position
MONSTER_POSITION = 
{
	[1] = {x=960-315, y=380},
	[2] = {x=960-380, y=280},
	[3] = {x=960-185, y=380},
	[4] = {x=960-250, y=280},
	[5] = {x=960-55, y=380},
	[6] = {x=960-120, y=280}
}

--战斗层次
BATTLE_LAYER_Z = 
{
	--场景层
	SCENE = 0,
	--地图层
	MAP = 1,
	--下层参战者
	BOTTOM_FIGHTER = 10,
	--奥义
	UPANISAD = 50,
	--下层特效层
	EFFECT_BOTTOM = 50,
	--参战者层
	FIGHTER = 200,
	--特效层
	EFFECT = 300,
	--ui层
	UI = 400,
	--窗体层
	WINDOW = 500
}

BATTLE_LAYER_Z.container = 
{
	--场景层
	SCENE = 0,
	--地图层
	MAP = 1,
	--参战者层
	FIGHT = 100,
	--ui层
	UI = 200,
	--剧情层
	PLOT = 300,
	--窗体层
	WINDOW = 400,
	--暂停层
	PAUSE = 500,
	--英雄动画
	HERO_ANIM = 550,
	--消息层
	MSG = 600
}

BATTLE_LAYER_Z.fighterContainer = 
{
	--奥义
	UPANISAD = 100,
	--下层特效层
	EFFECT_BOTTOM = 110,
	--参战者层
	FIGHTER = 200,
	--特效层
	EFFECT = 300,
}

BATTLE_LAYER_Z.normalFighter = 
{
	[1] = BATTLE_LAYER_Z.fighterContainer.FIGHTER + 30,
	[2] = BATTLE_LAYER_Z.fighterContainer.FIGHTER + 50,
	[3] = BATTLE_LAYER_Z.fighterContainer.FIGHTER + 25,
	[4] = BATTLE_LAYER_Z.fighterContainer.FIGHTER + 45,
	[5] = BATTLE_LAYER_Z.fighterContainer.FIGHTER + 20,
	[6] = BATTLE_LAYER_Z.fighterContainer.FIGHTER + 40
}

BATTLE_LAYER_Z.downFighter = 
{
	[1] = 30,
	[2] = 50,
	[3] = 25,
	[4] = 45,
	[5] = 20,
	[6] = 40
}


--技能攻击目标类型
SkillTargetType = {}
SkillTargetType.targetType_0  = 0       --敌方前排
SkillTargetType.targetType_1  = 1       --敌方中排
SkillTargetType.targetType_2  = 2       --敌方后排
SkillTargetType.targetType_3  = 3       --敌方前中排    
SkillTargetType.targetType_4  = 4       --敌方中后排    
SkillTargetType.targetType_5  = 5       --敌方全体
SkillTargetType.targetType_6  = 6       --我方前排
SkillTargetType.targetType_7  = 7       --我方中排
SkillTargetType.targetType_8  = 8       --我方后排
SkillTargetType.targetType_9  = 9       --我方前中排    
SkillTargetType.targetType_10 = 10      --我方中后排    
SkillTargetType.targetType_11 = 11      --我方全体
SkillTargetType.targetType_12 = 12      --敌方生命值最少
SkillTargetType.targetType_13 = 13      --敌方生命值最多
SkillTargetType.targetType_14 = 14      --我方生命值最少
SkillTargetType.targetType_15 = 15      --我方生命值最多
SkillTargetType.targetType_16 = 16      --纵向一列
SkillTargetType.targetType_17 = 17      -- 自己 
SkillTargetType.targetType_18 = 18      --敌方完全随机
SkillTargetType.targetType_19 = 19      --我方完全随机
SkillTargetType.targetType_20 = 20      --敌方前排血量最少
SkillTargetType.targetType_21 = 21      --前中后/2-1


--角色头像位置
AvatarPosition = 
{
	[1] = {x = 115*2, y = 132, z = 2},
	[2] = {x = 115*2, y = 0, z = 1},
	[3] = {x = 115, y = 132, z = 2},
	[4] = {x = 115, y = 0, z = 1},
	[5] = {x = 0, y = 132, z = 2},
	[6] = {x = 0, y = 0, z = 1}
}

--观战角色头像位置
AvatarPositionOB = 
{
	[1] = {x = 115*5, y = 132, z = 2},
	[2] = {x = 115*4, y = 132, z = 1},
	[3] = {x = 115*3, y = 132, z = 2},
	[4] = {x = 115*2, y = 132, z = 1},
	[5] = {x = 115, y = 132, z = 2},
	[6] = {x = 0, y = 132, z = 1}
}


BattleJoinType = {}
--跑入
BattleJoinType.RUN = 1
--跳入
BattleJoinType.JUMP = 2
--闪入
BattleJoinType.FLASH = 3
--普通站立
BattleJoinType.STAND = 4


--技能脚本类型
SkillScriptType = {}

--无
SkillScriptType.NONE = 0
--给对方上buff
SkillScriptType.BUFF_FOR_TARGET = 10000
--给己方上buff
SkillScriptType.BUFF_FOR_SELF = 10001
--本次攻击额外伤害
SkillScriptType.ATTACK_EXTRA_DAMAGE = 10002
--治疗
SkillScriptType.TREAT = 10003
--驱散
SkillScriptType.DISPERSE = 10004
--连击
SkillScriptType.BATTER = 10005
--连射
SkillScriptType.DARTLE = 10006
--给随机一个目标施加buff
SkillScriptType.BUFF_FOR_RANDOM_TARGET = 10007
--给指定目标buff
SkillScriptType.BUFF_FOR_SPECIAL_TARGET = 10008
--治疗和加buff
SkillScriptType.TREAT_AND_BUFF = 10009
--驱散并获得buff
SkillScriptType.DISPERSE_AND_BUFF = 10010
--驱散并治疗
SkillScriptType.DISPERSE_AND_TREAT = 10011
--造成伤害并获得buff
SkillScriptType.ATTACK_AND_BUFF = 10012
--对指定目标造成额外伤害
SkillScriptType.EXTRA_FOR_SPECIAL_TARGET = 10013
--将该回合产生伤害的总和的万分之X转化为自身护盾，护盾有最大持续回合限制
SkillScriptType.BUFF_FROM_ATTACK = 10014
--变身成2个角色打敌方2排的敌人
SkillScriptType.ATTACK_PHANTOM = 10015


--被动技能最大连击次数
SkillScriptType.MAX_BATTER = 4

--最大复活次数
SkillScriptType.MAX_REVIVE = 1


SkillScriptType.targetType = {}
SkillScriptType.targetType[SkillScriptType.BUFF_FOR_SELF] = BattleType.ATTACKER
SkillScriptType.targetType[SkillScriptType.NONE] = BattleType.STRIKER
SkillScriptType.targetType[SkillScriptType.BUFF_FOR_TARGET] = BattleType.STRIKER
SkillScriptType.targetType[SkillScriptType.ATTACK_EXTRA_DAMAGE] = BattleType.STRIKER
SkillScriptType.targetType[SkillScriptType.BATTER] = BattleType.STRIKER
SkillScriptType.targetType[SkillScriptType.DARTLE] = BattleType.STRIKER
SkillScriptType.targetType[SkillScriptType.BUFF_FOR_RANDOM_TARGET] = BattleType.STRIKER
SkillScriptType.targetType[SkillScriptType.TREAT_AND_BUFF] = BattleType.ATTACKER


--buff类型
BuffType = {}
--持续加血
BuffType.KEEP_ADD_HP = 10000
--加攻击
BuffType.ADD_ATTACK = 10001
--加防御
BuffType.ADD_DEFENSE = 10002
--加暴击
BuffType.ADD_CRIT = 10003
--加格挡
BuffType.ADD_BLOCK = 10004
--加反击
BuffType.ADD_BACK = 10005
--加破击
BuffType.ADD_WRECK = 10006
--加闪避
BuffType.ADD_MISS = 10007
--加忽视防御
BuffType.ADD_IGNORE_DEFENSE = 10008
--加神圣伤害
BuffType.ADD_SACRED_DAMAGE = 10009
--加伤害减免
BuffType.ADD_EXEMPT_DAMAGE = 10010
--加万分比攻击
BuffType.ADD_ATTACK_PERCENT = 10011
--加万分比防御
BuffType.ADD_DEFENSE_PERCENT = 10012
--加万分比暴击
BuffType.ADD_CRIT_PERCENT = 10013
--加万分比格挡
BuffType.ADD_BLOCK_PERCENT = 10014
--加万分比反击
BuffType.ADD_BACK_PERCENT = 10015
--加万分比破击
BuffType.ADD_WRECK_PERCENT = 10016
--加万分比miss
BuffType.ADD_MISS_PERCENT = 10017
--加万分比无视防御
BuffType.ADD_IGNORE_DEFENSE_PERCENT = 10018
--加万分比神伤
BuffType.ADD_SACRED_DAMAGE_PERCENT = 10019
--加万分比伤害豁免
BuffType.ADD_EXEMPT_DAMAGE_PERCENT = 10020
--加吸血
BuffType.ADD_SUCK_BLOOD = 10021
--加万分比伤害豁免2
BuffType.ADD_EXEMPT_DAMAGE_PERCENT_2 = 10022
--加万分比暴击(刺客下回合必定暴击)
BuffType.ADD_CRIT_PERCENT_ASSASSIN = 10023
--加万分比伤害豁免3
BuffType.ADD_EXEMPT_DAMAGE_PERCENT_3 = 10024
--加万分比伤害豁免4
BuffType.ADD_EXEMPT_DAMAGE_PERCENT_4 = 10025

--加护盾
BuffType.ADD_SHIELD = 10100
--加免疫
BuffType.ADD_IMMUNITY = 10101
--受击免伤加血
BuffType.UNDAMAGE_ADD_HP = 10200
--中毒
BuffType.POISONING = 20000
--减攻击
BuffType.MINUS_ATTACK = 20001
--减防御
BuffType.MINUS_DEFENSE = 20002
--减暴击
BuffType.MINUS_CRIT = 20003
--减格挡
BuffType.MINUS_BLOCK = 20004
--减反击
BuffType.MINUS_BACK = 20005
--减破击
BuffType.MINUS_WRECK = 20006
--减闪避
BuffType.MINUS_MISS = 20007
--减忽视防御
BuffType.MINUS_IGNORE_DEFENSE = 20008
--减神圣伤害
BuffType.MINUS_SACRED_DAMAGE = 20009
--减伤害豁免
BuffType.MINUS_EXEMPT_DAMAGE = 20010
--减万分比攻击
BuffType.MINUS_ATTACK_PERCENT = 20011
--减万分比防御
BuffType.MINUS_DEFENSE_PERCENT = 20012
--减万分比暴击
BuffType.MINUS_CRIT_PERCENT = 20013
--减万分比格挡
BuffType.MINUS_BLOCK_PERCENT = 20014
--减万分比反击
BuffType.MINUS_BACK_PERCENT = 20015
--减万分比破击
BuffType.MINUS_WRECK_PERCENT = 20016
--减万分比闪躲
BuffType.MINUS_MISS_PERCENT = 20017
--减万分比无视防御
BuffType.MINUS_IGNORE_DEFENSE_PERCENT = 20018
--减万分比神伤
BuffType.MINUS_SACRED_DAMAGE_PERCENT = 20019
--减万分比伤害豁免
BuffType.MINUS_EXEMPT_DAMAGE_PERCENT = 20020
--流血
BuffType.KEEP_MINUS_HP = 20021
--灼伤
BuffType.BURN = 20022
--眩晕
BuffType.STUN = 20100
--沉默
BuffType.SILENCE = 20101
--混乱
BuffType.CHAOS = 20102
--石化
BuffType.STONE = 20103
--嘲讽
BuffType.TAUNT = 20104
--变形
BuffType.DEFORM = 20105
--睡眠
BuffType.SLEEP = 20106
--减命中万分比
BuffType.MINUS_STARE_PERCENT = 20107
--持续掉血(叠加)
BuffType.KEEP_MINUS_HP_OVERLAY = 20108
--灼烧(叠加)
BuffType.BURN_OVERLAY = 20109
--中毒(叠加)
BuffType.POISONING_OVERLAY = 20110
--神圣灼烧
BuffType.SACRED_BURN = 20111


--buff属性
BuffType.property = 
{
	--伤害减免
	REDUCE_HARM = "reduce_harm"
}

--禁止使用技能的buff
BuffType.prohibitUseSkill = 
{
	[BuffType.STUN] = true,
	[BuffType.SILENCE] = true,
	[BuffType.CHAOS] = true,
	[BuffType.STONE] = true,
	[BuffType.TAUNT] = true,
	[BuffType.DEFORM] = true,
	[BuffType.SLEEP] = true
}

--禁止行动的buff
BuffType.prohibitAction = 
{
	[BuffType.STUN] = true,
	[BuffType.DEFORM] = true,
	[BuffType.STONE] = true,
	[BuffType.SLEEP] = true
}

BuffType.impactType = 
{
	ABS = 1,
	OVERLAY = 2
}



--buff性质
BuffNatureType = {}
--所有
BuffNatureType.ALL = 0
--良性
BuffNatureType.BENIGN = 1
--恶性
BuffNatureType.MALIGNANT = 2


--buff参数效果类型
BuffArgType = {}

--效果值
BuffArgType.VALUE = 1

--万分比
BuffArgType.PERCENT = 2

--无效果
BuffArgType.NONE = 3


--战斗过场景类型
BattleSceneType = {}
--过场景
BattleSceneType.SCROLL = 1
--单场景
BattleSceneType.SINGLE = 2
--切场景
BattleSceneType.REPLACE = 3


--战斗结果类型
BattleResultType = {}

--失败
BattleResultType.FAIL = 0
--成功
BattleResultType.VICTORY = 1
--继续战斗
BattleResultType.CONTINUE = 2
--平局
BattleResultType.DRAW = 3


--战斗卡牌奖励类型
BattleCardAwardType = {}

--展示
BattleCardAwardType.SHOW = 0
--奖励
BattleCardAwardType.AWARD = 1

--战斗结算类型
BattleSettlementType = {}
--普通
BattleSettlementType.NORMAL = 1
--翻牌
BattleSettlementType.CARD = 2


--ai配置类型
AIConfigType = {}
AIConfigType.ENEMY = 1  --敌方
AIConfigType.ALLY = 2   --友方
AIConfigType.OTHER = 3  --其他

AIConfigType.TEAM_HP = 1 --队伍血值
AIConfigType.ANYONE_HP = 2 --任何人血值
AIConfigType.ROUND = 3 --回合
AIConfigType.TEAM_BUFF = 4 --队伍buff
AIConfigType.ANYONE_BUFF = 5 --任何人buff
AIConfigType.SELECT_SKILL = 6 --选择技能

AIConfigType.LT = 1 --少于
AIConfigType.GT = 2 --大于
AIConfigType.EQ = 3 --等于
AIConfigType.GE = 4 --大等
AIConfigType.LE = 5 --少等
AIConfigType.CONTAIN = 6 --包含(buff)
AIConfigType.NOT_CONTAIN = 7 --不包含(buff)
AIConfigType.DIVISIBLE = 8 --整除(buff)

AIConfigType.VALUE = 1 --数值
AIConfigType.PERCENT = 2 --万分比

AIConfigType.USE_SKILL = 1 --使用技能
AIConfigType.TALK = 2 --说话

AIConfigType.SKILL_1 = "skill_1" --技能1
AIConfigType.SKILL_2 = "skill_2" --技能2
AIConfigType.SKILL_3 = "skill_3" --技能3
AIConfigType.skillIndex = {}
AIConfigType.skillIndex[AIConfigType.SKILL_1] = BattleStoneType.colorType.RED --技能1
AIConfigType.skillIndex[AIConfigType.SKILL_2] = BattleStoneType.colorType.BLUE--技能2
AIConfigType.skillIndex[AIConfigType.SKILL_3] = BattleStoneType.colorType.PURPLE --技能3

AIConfigType.triggerType = 
{
	--根据条件触发
	CONDITION = 1,
	--回合循环
	ROUND_LOOP = 2
}

--ai出现的时机
AIConfigType.oppotunityType = 
{
    BEFORE_SELECT_SKILL = 1,
    AFTER_SELECT_SKILL = 2	
}

--战斗奖励类型
BattleAwardType = {}
--免费
BattleAwardType.FREE = 1
--付费
BattleAwardType.PAY = 2


--被动技能类型
PassiveSkillScriptType = {}

--损失生命每加/减一个万分比,获得数值万分比
PassiveSkillScriptType.SCRIPT_TYPE_20000 = 20000
--生命减少到一个万分比,获得数值万分比
PassiveSkillScriptType.SCRIPT_TYPE_20001 = 20001
--受到近程攻击反弹
PassiveSkillScriptType.SCRIPT_TYPE_20002 = 20002
--攻击对目标类型造成额外万分比伤害
PassiveSkillScriptType.SCRIPT_TYPE_20003 = 20003
--收到近程攻击反击
PassiveSkillScriptType.SCRIPT_TYPE_20004 = 20004
--主动群攻时，随机对一个被攻击对象增加额外万分比伤害
PassiveSkillScriptType.SCRIPT_TYPE_20005 = 20005
--主动治疗时，额外恢复目标生命上限万分比的治疗量
PassiveSkillScriptType.SCRIPT_TYPE_20006 = 20006
--受到治疗时，额外恢复治疗量万分比
PassiveSkillScriptType.SCRIPT_TYPE_20007 = 20007
--主动治疗时，对生命减少到一个万分比值的对象，额外增加治疗量
PassiveSkillScriptType.SCRIPT_TYPE_20008 = 20008
--产生伤害时，有一定几率对附近的敌人产生溅射伤害
PassiveSkillScriptType.SCRIPT_TYPE_20009 = 20009
--死亡后下一回合会原地复活,恢复x血量,每场战斗只能触发1次
PassiveSkillScriptType.SCRIPT_TYPE_20010 = 20010
--主动攻击后，概率产生buff
PassiveSkillScriptType.SCRIPT_TYPE_20011 = 20011
--主动攻击时，目标生命减少到一个万分比,攻击者获得数值绝对值，且损失生命每加/减一个万分比,攻击者获得数值绝对值
PassiveSkillScriptType.SCRIPT_TYPE_20012 = 20012
--主动攻击时，对某一种族敌人增加额外伤害万分比
PassiveSkillScriptType.SCRIPT_TYPE_20013 = 20013
--只要该单位存活于战场,每回合结束时,目标群体会自动加减生命绝对值
PassiveSkillScriptType.SCRIPT_TYPE_20014 = 20014
--该角色在被沉默控制的状态下有X的概率(万分比)仍可施法
PassiveSkillScriptType.SCRIPT_TYPE_20015 = 20015
--该角色触发格挡时,有X%几率完全免疫伤害和一切负面,控制效果
PassiveSkillScriptType.SCRIPT_TYPE_20016 = 20016
--增加毒伤害x点
PassiveSkillScriptType.SCRIPT_TYPE_20017 = 20017
--每次攻击如果不被闪避/格挡,都有10%几率追加额外连击(因此大招最多可以产生8连击)
PassiveSkillScriptType.SCRIPT_TYPE_20018 = 20018
--受到群攻时，有一定几率保护自己，免疫34%伤害，免疫几率随技能等级提升
PassiveSkillScriptType.SCRIPT_TYPE_20019 = 20019
--当血量低于某个数值时,获得buff(可多个)
PassiveSkillScriptType.SCRIPT_TYPE_20020 = 20020
--只要该单位存活于战场,目标类型和数量的英雄都会在战斗中 +/- 某种数值绝对值
PassiveSkillScriptType.SCRIPT_TYPE_20021 = 20021
--当自身进入被控制状态后，有20%的几率立刻解除控制
PassiveSkillScriptType.SCRIPT_TYPE_20022 = 20022
--自身死亡时,对杀死自己的敌方单位施加强大的灼烧法术,每回合受到200点伤害,持续5回合
PassiveSkillScriptType.SCRIPT_TYPE_20023 = 20023
--被敌方攻击时,一定概率最多只产生X点的伤害(无论是否暴击,破甲等)
PassiveSkillScriptType.SCRIPT_TYPE_20024 = 20024
--在每场战斗不同回合的时候, 场中目标增加一个BUFF
PassiveSkillScriptType.SCRIPT_TYPE_20025 = 20025
--在敌方触发了反震效果之后,有X的概率抵抗反震(不触发反震)
PassiveSkillScriptType.SCRIPT_TYPE_20026 = 20026
--该单位存活于战场,每回合结束时,目标群体会有概率+/-目标单位自身最大血量的万分比数值
PassiveSkillScriptType.SCRIPT_TYPE_20027 = 20027


--buff相关脚本列表
SkillScriptType.BUFF_RELATE_DICT = {
	[SkillScriptType.BUFF_FOR_TARGET] = true,
	[SkillScriptType.BUFF_FOR_SELF] = true,
	[SkillScriptType.BUFF_FOR_RANDOM_TARGET] = true,
	[SkillScriptType.TREAT_AND_BUFF] = true,
	[SkillScriptType.DISPERSE_AND_BUFF] = true,
	[SkillScriptType.BUFF_FOR_SPECIAL_TARGET] = true,
	[SkillScriptType.ATTACK_AND_BUFF] = true,
	[SkillScriptType.BUFF_FROM_ATTACK] = true,
	[PassiveSkillScriptType.SCRIPT_TYPE_20011] = true,
	[PassiveSkillScriptType.SCRIPT_TYPE_20020] = true,
	[PassiveSkillScriptType.SCRIPT_TYPE_20023] = true,
	[PassiveSkillScriptType.SCRIPT_TYPE_20025] = true
}

--窗口类型
BattleWindowType = 
{
	SETTLEMENT_VIEW = "settlement_view",
	FAIL_VIEW = "fail_view",
	STATISTIC_VIEW = "statistic_view",
	PLAYBACK_VIEW = "playback_view"
}

--战斗出手顺序类型
BattleFightOrderType = 
{
	--根据敏捷值
	AGILITY = 0,
	--敌人必先出手
	ENEMY = 1,
	--已方必先出手
	ALLY = 2
}