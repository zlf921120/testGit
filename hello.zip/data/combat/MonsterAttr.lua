--
-- Author: lvgansheng
-- Date: 2014-07-18 17:17:06
-- 怪物属性

MonsterAttr = class("MonsterAttr")
MonsterAttr.attrs = nil

function MonsterAttr:init()
	self.attrs = {}
end

function MonsterAttr:create()
	local attr = MonsterAttr.new()
	attr:init()
	return attr
end

function MonsterAttr:setData(attr_type,value)
	self.attrs[attr_type] = value
end

--获取某类型的属性
function MonsterAttr:getDataByType(attr_type)
	local value = self.attrs[attr_type] 
	if value == nil then 
		value = 0
	end

	return value
end

--获取怪物所有属性
function MonsterAttr:getAttrs() 
	return self.attrs
end