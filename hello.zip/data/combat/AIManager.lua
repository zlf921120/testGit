--
-- Author: thisgf
-- Date: 2014-07-28 15:12:09
-- 怪物ai管理器


require "fnt_ai_data_pb"
require "combatDataStorage"
require "combatConfig"
require "MonsterManager"


AIManager = class("AIManager")

AIManager.DEFAULT_AI = 10000

AIManager._bm = nil
AIManager._sm = nil
AIManager._mm = nil
AIManager._combatData = nil

AIManager._aiDataList = nil

--条件函数集合
AIManager._conditionFuncDict = nil

AIManager._roundManager = nil

--ai触发类型
AIManager._triggerType = 1

--当前使用的ai数据列表
AIManager._currentAIDataList = nil

AIManager._aiIndex = 1
--ai使用次数
AIManager._aiUseNumList = nil


AIManager._isParseData = false


local _instance

function AIManager:ctor()

	self._sm = SkillManager:getInstance()
	self._mm = MonsterManager:getInstance()
	self._bm = BattleManager:getInstance()
	self._combatData = CombatDataStorage:getInstance()

	self._aiDataList = {}
	self._conditionFuncDict = {}

	self._currentAIDataList = {}
	self._aiUseNumList = {}

	self:_initConditionFunc()

	self:parseAIData()

end

function AIManager:getInstance()

	if not _instance then
		_instance = AIManager.new()
	end

	return _instance
end

function _combinCondition(...)

	local t = {...}

	return table.concat(t, "_")

end

function AIManager:_initConditionFunc()

	local combin
    for i = AIConfigType.LT, AIConfigType.LE do

	    combin = _combinCondition(AIConfigType.ALLY, AIConfigType.TEAM_HP, i)
		self._conditionFuncDict[combin] = self._cdtTeamValue
	    combin = _combinCondition(AIConfigType.ALLY, AIConfigType.ANYONE_HP, i)
		self._conditionFuncDict[combin] = self._cdtTeamValue


		combin = _combinCondition(AIConfigType.ENEMY, AIConfigType.TEAM_HP, i)
		self._conditionFuncDict[combin] = self._cdtTeamValue
		combin = _combinCondition(AIConfigType.ENEMY, AIConfigType.ANYONE_HP, i)
		self._conditionFuncDict[combin] = self._cdtTeamValue

		combin = _combinCondition(AIConfigType.OTHER, AIConfigType.ROUND, i)
		self._conditionFuncDict[combin] = self._cdtRound

    end

    combin = _combinCondition(AIConfigType.OTHER, AIConfigType.ROUND, AIConfigType.DIVISIBLE)
    self._conditionFuncDict[combin] = self._cdtRound

    combin = _combinCondition(AIConfigType.ALLY, AIConfigType.TEAM_BUFF, AIConfigType.CONTAIN)
	self._conditionFuncDict[combin] = self._cdtBuff
    combin = _combinCondition(AIConfigType.ALLY, AIConfigType.TEAM_BUFF, AIConfigType.NOT_CONTAIN)
	self._conditionFuncDict[combin] = self._cdtBuff
    combin = _combinCondition(AIConfigType.ALLY, AIConfigType.ANYONE_BUFF, AIConfigType.CONTAIN)
	self._conditionFuncDict[combin] = self._cdtBuff
	combin = _combinCondition(AIConfigType.ALLY, AIConfigType.ANYONE_BUFF, AIConfigType.NOT_CONTAIN)
	self._conditionFuncDict[combin] = self._cdtBuff


	combin = _combinCondition(AIConfigType.ENEMY, AIConfigType.TEAM_BUFF, AIConfigType.CONTAIN)
	self._conditionFuncDict[combin] = self._cdtBuff
	combin = _combinCondition(AIConfigType.ENEMY, AIConfigType.TEAM_BUFF, AIConfigType.NOT_CONTAIN)
	self._conditionFuncDict[combin] = self._cdtBuff
	combin = _combinCondition(AIConfigType.ENEMY, AIConfigType.ANYONE_BUFF, AIConfigType.CONTAIN)
	self._conditionFuncDict[combin] = self._cdtBuff
	combin = _combinCondition(AIConfigType.ENEMY, AIConfigType.ANYONE_BUFF, AIConfigType.NOT_CONTAIN)
	self._conditionFuncDict[combin] = self._cdtBuff

	combin = _combinCondition(AIConfigType.ENEMY, AIConfigType.SELECT_SKILL, AIConfigType.EQ)
	self._conditionFuncDict[combin] = self._cdtSkill

end

--条件队伍数值
function AIManager:_cdtTeamValue(aiData)

	local teamDict = self:_getTeam(aiData)

	if not teamDict then
		return false
	end

	local function operatorHp(operation, leftValue, rightValue)

		local value = 0
		if aiData.argType == AIConfigType.PERCENT then
			value = rightValue*aiData.arg/10000
		else
			value = aiData.arg
		end

		-- print("=============", leftValue, value)

		if operation == AIConfigType.LT then
	    	return leftValue < value
	    elseif operation == AIConfigType.GT then
	    	return leftValue > value
	    elseif operation == AIConfigType.EQ then
	    	return leftValue == value
	    elseif operation == AIConfigType.GE then
	    	return leftValue >= value
	    elseif operation == AIConfigType.LE then
	    	return leftValue <= value
	    end
	end

	local hpType = aiData.cdtAttr
	local operation = aiData.cdtOperation
	

	local curHpValue = 0
	local maxHpValue = 0
	local entity

	local hit = false

    if hpType == AIConfigType.TEAM_HP then

    	for _, entity in pairs(teamDict) do

			curHpValue = curHpValue + entity:getCurrentHp()
			maxHpValue = maxHpValue + entity:getTotalHp()

    	end

    	hit = operatorHp(operation, curHpValue, maxHpValue)

    elseif hpType == AIConfigType.ANYONE_HP then

    	for _, entity in pairs(teamDict) do

    		curHpValue = entity:getCurrentHp()
	    	maxHpValue = entity:getTotalHp()

	    	hit = operatorHp(operation, curHpValue, maxHpValue)

	    	if hit then
	    		break
	    	end

    	end

    end

    return hit

end

--回合条件
function AIManager:_cdtRound(aiData)

	local round = self._bm:getRoundIndex()

	local operator = aiData.cdtOperation
	local value = aiData.arg

	if operator == AIConfigType.LT then
    	return round < value
    elseif operator == AIConfigType.GT then
    	return round > value
    elseif operator == AIConfigType.EQ then
    	return round == value
    elseif operator == AIConfigType.GE then
    	return round >= value
    elseif operator == AIConfigType.LE then
    	return round <= value
    elseif operator == AIConfigType.DIVISIBLE then

    	if value == 0 then
    		value = 1
    	end

    	return round % value == 0
    end

    return false

end

--buff条件
function AIManager:_cdtBuff(aiData)

	local teamDict = self:_getTeam(aiData)

	if not teamDict then
		return false
	end

	local entity
	local buffList

	local hit = false

	--如果是队伍buff则全队都要包含或不包含才成立, 如果是任何人buff则随便一个包含或不包含就成立

	for _, entity in pairs(teamDict) do

        buffList = self._roundManager.roundData:getBuff(entity:getEntityID())

        --包含
        if aiData.cdtOperation == AIConfigType.CONTAIN then

        	hit = false
	        if buffList then

	        	for i1, v1 in ipairs(buffList) do

	        		if v1.id == aiData.arg then

	        			hit = true
	        			break
	        		end
	        	end
	        end

	        --队伍
	        if aiData.cdtAttr == AIConfigType.TEAM_BUFF then

	        	if hit == false then
		        	break
		        end
	        else

	        	if hit == true then
	        		break
	        	end

	        end

	    else

	    	--不包含

	    	hit = true
	    	if buffList then

	        	for i1, v1 in ipairs(buffList) do

	        		if v1.id == aiData.arg then

	        			hit = false
	        			break
	        		end
	        	end

	        end

	        --队伍
	        if aiData.cdtAttr == AIConfigType.TEAM_BUFF then

	        	if hit == true then
		        	break
		        end
	        else

	        	if hit == false then
	        		break
	        	end
	        end

    	end
	end

	return hit

end

--对手技能条件
function AIManager:_cdtSkill(aiData)
	local skillIndex = self._roundManager:getSkillIndex()

	if skillIndex == aiData.arg then
		return true
	end

	return false

end

function AIManager:_getTeam(aiData)

	local entityType = 0

	local teamDict = {}
	if aiData.targetType == AIConfigType.ENEMY then
		--攻击方
		entityType = BattleType.ATTACKER
		return EntityManager:getInstance():getAllyEntityDict()
	elseif aiData.targetType == AIConfigType.ALLY then
		--受击方
		entityType = BattleType.STRIKER
		return EntityManager:getInstance():getEnemyCurWaveDict()
	end

end

function AIManager:parseAIData()

	if self._isParseData == true then
		return
	end

	self._isParseData = true

	local file = FileUtils.readConfigFile("fnt_ai_data.dat")
	local ai_data_pb = fnt_ai_data_pb.fnt_ai_data()
	ai_data_pb:ParseFromString(file)


	local aiData
	for k, v in pairs(ai_data_pb.ai_rows) do

		if v.id then

			aiData = AIData:create()
			aiData.id = v.id
			aiData.triggerTimes = v.trigger_times
			aiData.targetType = v.target
			aiData.cdtAttr = v.attr
			aiData.cdtOperation = v.operation
			aiData.argType = v.arg_type
			aiData.arg = v.arg
			aiData.usePercent = v.percent
			aiData.behaviorType = v.behavior_type
			aiData.behavior = v.behavior

			self._aiDataList[aiData.id] = aiData

		end

	end

end


--[[
    初始化战斗数据
]]
function AIManager:initBattleData(roundManager)

	self._roundManager = roundManager
end

function AIManager:setAIList(idList, triggerType)

	self._aiIndex = 1

	self._triggerType = triggerType or AIConfigType.triggerType.CONDITION

	self._currentAIDataList = {}
	self._aiUseNumList = {}
	local aiData
	for i, v in ipairs(idList) do

		aiData = self:getAIData(v)
		if aiData then
			table.insert(self._currentAIDataList, aiData)
			table.insert(self._aiUseNumList, 0)
		end
	end

end

--[[
    产生敌人ai数据
    @return AIData
]]
function AIManager:generateEnemyAI()

	local aiData

	if self._triggerType == AIConfigType.triggerType.ROUND_LOOP then
		aiData = self:_generateWithLoop()
	else
		aiData = self:_generateWithCondition()
	end

	if not aiData then
		--取默认ai
		aiData = self:getAIData(AIManager.DEFAULT_AI)
	end

	print("====================使用AI", aiData.id)

	return aiData

end

function AIManager:_generateWithCondition()

	local id
	local aiData

	local combin
	local hit = false

	--根据ai列表里面前后优先匹配
	for i = self._aiIndex, #self._currentAIDataList do

		aiData = self._currentAIDataList[i]

		if aiData.triggerTimes == 0 or self._aiUseNumList[i] < aiData.triggerTimes then

			hit = false

			combin = _combinCondition(aiData.targetType, aiData.cdtAttr, aiData.cdtOperation)

			local cdtFunc = self._conditionFuncDict[combin]

			if cdtFunc then
				hit = cdtFunc(self, aiData)
			else
				cclog("=====沒有處理此AI的函數=====")
			end

			if hit then

				if math.random(1,100) <= aiData.usePercent then
					self._aiUseNumList[i] = self._aiUseNumList[i] + 1
					break
				else
					hit = false
				end
			end
		end
	end

	return aiData

end

function AIManager:_generateWithLoop()

	if self._aiIndex > #self._currentAIDataList then
		self._aiIndex = 1
	end

	local lastIndex = self._aiIndex

	self._aiIndex = self._aiIndex + 1

	return self._currentAIDataList[lastIndex]

end

function AIManager:getAIData(id)

	return self._aiDataList[id]
end



AIData = class("AIData")

--id
AIData.id = 0
--触发次数
AIData.triggerTimes = 0
--目标类型
AIData.targetType = 0
--条件属性
AIData.cdtAttr = 0
--条件关系
AIData.cdtOperation = 0
--参数类型
AIData.argType = 0
--参数
AIData.arg = 0
--出招概率
AIData.usePercent = 0
--行为类型
AIData.behaviorType = 0
--行为
AIData.behavior = ""

function AIData:create()

	local aiData = AIData.new()

	return aiData
end
