--
-- Author: thisgf
-- Date: 2014-09-01 20:56:44
-- 战斗参战者节点

BattleFighterNode = class("BattleFighterNode", DisplayUtil.newNode)


--战斗id
BattleFighterNode._entityId = nil

--参战者数据
BattleFighterNode._fighterData = nil

--身体尺寸
BattleFighterNode._bodySize = nil

BattleFighterNode._defualtBodySize = nil
BattleFighterNode._defaultBodyHeight = nil

BattleFighterNode._isDeformation = false

--主容器
BattleFighterNode._mainContainer = nil

--阴影层
BattleFighterNode._shadowContainer = nil

--下层buff特效层
BattleFighterNode._bottomBuffEffectContainer = nil

--下层特效层
BattleFighterNode._bottomEffectContainer = nil

--身体层
BattleFighterNode._bodyContainer = nil

--buff特效层
BattleFighterNode._buffEffectContainer = nil
--打击效果层
BattleFighterNode._topEffectContainer = nil

--血条信息层
BattleFighterNode._infoContainer = nil


--阴影
BattleFighterNode._shadowSprite = nil

--身体
BattleFighterNode._bodyArmature = nil

--小动物
BattleFighterNode._animalArmature = nil

BattleFighterNode._healthBar = nil

--血条容器
BattleFighterNode._hpContainer = nil

BattleFighterNode._hpSlot = nil


--血条
BattleFighterNode._hpProgressNode = nil


function BattleFighterNode:ctor()

end

function BattleFighterNode:init()

	self._direction = -1

	self:setUserObject(CCInteger:create(0))

	self._mainContainer = CCNode:create()
	self:addChild(self._mainContainer)

	self._shadowContainer = CCNode:create()
	self._mainContainer:addChild(self._shadowContainer)

	self._bottomBuffEffectContainer = CCNode:create()
	self._mainContainer:addChild(self._bottomBuffEffectContainer)

	self._bottomEffectContainer = CCNode:create()
	self._mainContainer:addChild(self._bottomEffectContainer)

	self._bodyContainer = CCNode:create()
	self._mainContainer:addChild(self._bodyContainer)

	self._buffEffectContainer = CCNode:create()
	self._mainContainer:addChild(self._buffEffectContainer)

	self._topEffectContainer = CCNode:create()
	self._mainContainer:addChild(self._topEffectContainer)

	self._infoContainer = CCNode:create()
	self:addChild(self._infoContainer)

	self:_initChildNode()

end

function BattleFighterNode:_initChildNode()

	self._hpContainer = CCNode:create()
	self._hpContainer:setAnchorPoint(ccp(0.5, 0.5))
	self._infoContainer:addChild(self._hpContainer)
	-- self._hpContainer:setVisible(false)

	self._hpSlot = CCSprite:createWithSpriteFrameName("bui_role_hp_slot.png")
	self._hpSlot:setVisible(false)
	self._hpContainer:addChild(self._hpSlot)

	local slotSize = self._hpSlot:getContentSize()

	self._hpProgressNode = BattleRoleAvatarHPNode:create()
	self._hpProgressNode:setScaleX(1.1)
	self._hpProgressNode:setScaleY(0.8)
	self._hpProgressNode:setVisibleNormal(false)
	-- self._hpProgressNode:setPosition(ccp(slotSize.width * 0.5, slotSize.height * 0.5))
	self._hpContainer:addChild(self._hpProgressNode)

end

function BattleFighterNode:setEntityId(value)
	self._entityId = value
end

function BattleFighterNode:setFighterData(value)
	self._fighterData = value
end

function BattleFighterNode:setDefaultBodyHeight(value)
	self._defaultBodyHeight = value
	self._defualtBodySize = CCSizeMake(0, self._defaultBodyHeight)
end

function BattleFighterNode:setBodyModel(bodyModel)

	if self._bodyArmature == bodyModel then
		return
	end

	if self._bodyArmature then
		self._bodyArmature:removeFromParentAndCleanup(true)
	end

	if self._shadowSprite == nil then

		local shadowName = nil

		if self._fighterData:getFighterType() == BattleType.MONSTER then
			local monsterType = self._fighterData:getBaseInfo().monsterType
			if monsterType == Helper.monsterType.GUILD_BOSS or
				monsterType == Helper.monsterType.SUPER_BOSS then
				shadowName = "bui_shadow_big.png"
			else
				shadowName = "yingzi.png"
			end
		else
			shadowName = "yingzi.png"
		end
		self._shadowSprite = CCSprite:createWithSpriteFrameName(shadowName)
		self._shadowContainer:addChild(self._shadowSprite)

	end
	
	self._bodyArmature = bodyModel
	self._bodyContainer:addChild(self._bodyArmature)

	self._bodySize = self._bodyArmature:getContentSize()

	if self._defaultBodyHeight == 0 then
		self:setDefaultBodyHeight(self._bodySize.height)
	end

	self:_updateBodySize()

end

function BattleFighterNode:getBodyArmature()
	return self._bodyArmature
end

function BattleFighterNode:_updateBodySize()

	self._hpContainer:setPosition(
		ccp(
			0, 
			self._defaultBodyHeight * self._bodyArmature:getScaleY()
			)
		)
end

function BattleFighterNode:deformation()

	if self._isDeformation then
		return
	end

	self._isDeformation = true

	if not self._animalArmature then
		self._animalArmature = AnimateManager:getInstance():getArmatureFromEffectId(50018)
		self._bodyContainer:addChild(self._animalArmature)
	end

	self._animalArmature:setVisible(true)
	self._bodyArmature:setVisible(false)

end

function BattleFighterNode:undeformation()

    if not self._isDeformation then
        return
    end

    self._isDeformation = false

	self._bodyArmature:setVisible(true)

	if self._animalArmature then
		self._animalArmature:setVisible(false)
	end

end

function BattleFighterNode:initHp(hp, hpMax)
	self._hpProgressNode:initHp(hp, hpMax)
end

function BattleFighterNode:updateHp(value)
	self._hpProgressNode:updateHp(value)
end

function BattleFighterNode:initShieldHp(value)
	self._hpProgressNode:initShieldHp(value)
end

function BattleFighterNode:updateShieldHp(value)
	self._hpProgressNode:updateShieldHp(value)
end

function BattleFighterNode:setHeadHealthBar(healthBarBGSprite, healthBar)

	if self._healthBar then
		self._healthBar:removeFromParentAndCleanup(true)
	end

	self._healthBar = healthBar
	healthBarBGSprite:setVisible(false)
	self._infoContainer:addChild(healthBarBGSprite)

end

function BattleFighterNode:getHeadHealthBar()
	return self._healthBar
end

function BattleFighterNode:getMainContainer()
	return self._mainContainer
end

function BattleFighterNode:getAnimation()
	if self._isDeformation then
		return self._animalArmature:getAnimation()
	end
	return self._bodyArmature:getAnimation()
end

function BattleFighterNode:getBottomBuffEffectContainer()
	return self._bottomBuffEffectContainer
end

function BattleFighterNode:getBuffEffectContainer()
	return self._buffEffectContainer
end

--[[
    特效下层
]]
function BattleFighterNode:getBottomEffectContainer()
	return self._bottomEffectContainer
end

function BattleFighterNode:getEffectContainer()
	return self._topEffectContainer
end

--[[
    身体容器
]]
function BattleFighterNode:getBodyContainer()
	return self._bodyContainer
end

--[[
    获取血条显示节点
]]
function BattleFighterNode:getHpContainer()
	return self._hpContainer
end

--[[
    设置血条显示
]]
function BattleFighterNode:setHpVisible(value)

	self._hpSlot:setVisible(value)
	self._hpProgressNode:setVisibleNormal(value)

end

--[[
    添加动态显示文本
]]
function BattleFighterNode:addDynamicText(value)

	-- local pos = ccp(0, self._bodySize.height*0.8)
	local pos = ccp(0, self._defaultBodyHeight * 0.8)
	value:setPosition(pos)

	self._infoContainer:addChild(value)
end

function BattleFighterNode:getInfoContainer()
	return self._infoContainer
end

--[[
    设置方向
]]
function BattleFighterNode:setDirection(direction)

	if self._direction == direction then
		return
	end

	self._direction = direction

	if direction == BattleType.directionType.LEFT then
	    self._mainContainer:setScaleX(1)
	else
	    self._mainContainer:setScaleX(-1)
	end

end

function BattleFighterNode:getDirection()
	return self._direction
end

function BattleFighterNode:getBodySize()
	return self._bodySize
end

--默认身体尺寸
function BattleFighterNode:getDefaultBodySize()
	return self._defualtBodySize
end

function BattleFighterNode:getBodyScaleX()
	return self._mainContainer:getScaleX()
end

function BattleFighterNode:getEntityID()
	return self._entityId
end

function BattleFighterNode:clearAllEffect()

	EffectManager:getInstance():clearEffect(self._bottomEffectContainer)
	EffectManager:getInstance():clearEffect(self._topEffectContainer)
	EffectManager:getInstance():clearEffect(self._bottomBuffEffectContainer)
	EffectManager:getInstance():clearEffect(self._buffEffectContainer)

end

function BattleFighterNode:create()

	local fighterNode = BattleFighterNode.new()
	fighterNode:init()
	return fighterNode
end

--释放
function BattleFighterNode:uninit()

	self._entityId = nil
	self:clearAllEffect()

	if self._animalArmature then
		AnimateManager:getInstance():releaseArmature(self._armaturePath)
	end

end
