StateBase = class("StateBase")

StateBase._isUninit = false


--状态进入
function StateBase:enter( entity )
	
end

--状态调用
function StateBase:invoke( entity )
	
end

--状态退出
function StateBase:exit( entity )
	
end

--收到消息
function StateBase:onMessge( entity, state_msg )
	
end

--结束状态
function StateBase:endState(entity)

    if self.nextState then
		entity:getStateMachine():changeState(self.nextState)
	end
	
end
	
--创建状态对象
function StateBase:ctor()	
	self:init()	
end

--状态对象初始化
function StateBase:init()
	
end	

--状态对象销毁
function StateBase:uninit()
end

function StateBase:isUninit()
	return self._isUninit
end

function StateBase:setType( stateType )
	self.stype = stateType
end

function StateBase:getType()
	return self.stype
end

--[[
    设置下一个状态
]]
function StateBase:setNextState(state)
	self.nextState = state
end

function StateBase:getNextState()
	return self.nextState
end

function StateBase:create()
	local sb = StateBase.new()
	sb:init()
	return sb
end


