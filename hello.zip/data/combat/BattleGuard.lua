--
-- Author: thisgf
-- Date: 2015-02-05 17:48:54
-- 战斗守卫

BattleGuard = class("BattleGuard", EntityBase:create())

function BattleGuard:ctor()

end

function BattleGuard:init(camp, guardInfo)
    
    self:initBase()

    self._baseInfo = guardInfo

    self._modelId = guardInfo.modelId

    local actionData = EffectManager:getInstance():getActionData(self._modelId)

    self._actionData = actionData
    
    self._avatorId = guardInfo.baseId

    self._armaturePath = actionData:getFileFullPathName()

    self._armature = AnimateManager:getInstance():getArmature(
        self._armaturePath, 
        actionData:getFileName()
    )
    
    self:setEntityType(camp)

    self._fighterType = BattleType.GUARD

end

function BattleGuard:setBaseAttr(attr)
    self._atkBaseArgs = attr
    self.attackSpeed = self._atkBaseArgs.atk_speed

    --设置守卫的最大血值
    self:setTotalHp(attr.hp)
end

function BattleGuard:setBaseAttrData(value)
    self._attrData = value
    self:setTotalHp(self._attrData:getAttr(AttrHelper.attr_flag.hp))
end

function BattleGuard:create(camp, guardInfo)
    local bg = BattleGuard.new()
    bg:init(camp, guardInfo)
    return bg
end

