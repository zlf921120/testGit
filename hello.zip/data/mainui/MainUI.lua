--
-- Author: lvgansheng
-- Date: 2014-06-16 20:21:38
-- 游戏主UI
require("TouchPriority")
require("WindowCtrl")
require("HeadIcon")
require("Loading")
require("ActivateCfg")

require "SkywarManager"

MainUI = class("MainUI", function () return CCLayer:create() end)
MainUI.uiLayer = nil
MainUI.widget = nil
MainUI._left_panel = nil
MainUI._middle_panel = nil
MainUI._right_panel = nil
MainUI._iconList = nil
MainUI.returnButton = nil
MainUI._activate_item = nil

--测试用
local user_id_txt = nil

local __instance = nil

local characterMgr = CharacterManager:getInstance()

local hero_btn_tips_img -- 英雄图标上的绿色提示点
local main_btn_tips_img -- 主按钮上的绿色提示点
local task_btn_tips_img --任务图标上的绿色提示点

local is_first_click = true


local left_width = 179
local middle_width = 615
local right_width = 152

local left_height = 146
local middle_height = 89
local right_height = 610

------------------初始化-----------------------
function MainUI:init()
    local visibleSize = CCDirector:sharedDirector():getVisibleSize()
    local origin = CCDirector:sharedDirector():getVisibleOrigin()    
    
    --加载资源
--    CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA8888)
    ComResMgr:getInstance():loadRes("ui/common/common.plist","ui/common/common.pvr.ccz")
    ComResMgr:getInstance():loadRes("ui/common/other.plist","ui/common/other.pvr.ccz")
  --  CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA4444)

    self.left_uiLayer = TouchGroup:create()
    self.left_uiLayer:retain() 
    self.middle_uiLayer = TouchGroup:create() 
    self.middle_uiLayer:retain() 
    self.right_uiLayer = TouchGroup:create() 
    self.right_uiLayer:retain() 
    self._iconList = {} --图标列表
    -- GameLayerMgr:getInstance():getLeftWinLayer():addChild(self.left_uiLayer)
    -- GameLayerMgr:getInstance():getMidWinLayer():addChild(self.middle_uiLayer)
    -- GameLayerMgr:getInstance():getRightWinLayer():addChild(self.right_uiLayer)
   
    -- self:addChild(self.uiLayer)
        
    self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/mainui/mainui.ExportJson")

    self._left_panel = self.widget:getChildByName("left_panel")
    self._middle_panel = self.widget:getChildByName("middle_panel")
    self._right_panel = self.widget:getChildByName("right_panel")

    local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
    local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()

    self._left_panel:setScaleX(1/globa_scalx*DisplayUtil.min_scale)
    self._left_panel:setScaleY(1/globa_scaly*DisplayUtil.min_scale)

    self._middle_panel:setScaleX(1/globa_scalx*DisplayUtil.min_scale)
    self._middle_panel:setScaleY(1/globa_scaly*DisplayUtil.min_scale)

    self._right_panel:setScaleX(1/globa_scalx*DisplayUtil.min_scale)
    self._right_panel:setScaleY(1/globa_scaly*DisplayUtil.min_scale)

    self._left_panel:removeFromParentAndCleanup(true)
    self._middle_panel:removeFromParentAndCleanup(true)
    self._right_panel:removeFromParentAndCleanup(true)

    self.left_uiLayer:addWidget(self._left_panel)
    self.middle_uiLayer:addWidget(self._middle_panel)
    self.right_uiLayer:addWidget(self._right_panel)

    -- user_id_txt = CCLabelTTF:create()
    -- user_id_txt:setAnchorPoint(ccp(0,0.5))
    -- user_id_txt:setPosition(ccp(40,460))
    -- self.left_uiLayer:addChild(user_id_txt)
    -- user_id_txt:setFontSize(20)
    -- user_id_txt:setString(string.format("網路=%s~~~設備型號=%s~~~系統=%s",Global:getNetWorkState(),Global:comFunForLua(2,""),Global:comFunForLua(3,"")))
    
    -- self.left_uiLayer:setTouchPriority(TouchPriority.left)
    self.middle_uiLayer:setTouchPriority(TouchPriority.middle)
    self.right_uiLayer:setTouchPriority(TouchPriority.right)

    self.head_icon = HeadIcon:create()
    self.head_icon:isShowBg(false)
    self.head_icon:setPosition(ccp(55,95))
    self.head_icon:setZOrder(1)
    self.head_icon:setClickEvent(function(sender, event_type) 
        if event_type == ComConstTab.TouchEventType.ended then
            -- WindowCtrl:getInstance():open(CmdName.ChangeHeadView) 
            WindowCtrl:getInstance():open(CmdName.Team_View,{tabar_idx=1})
        end
    end)
    self._left_panel:addChild(self.head_icon)

    local mainui_fx_img = self._left_panel:getChildByName("mainui_fx_img")
    --战斗力数字图片
    self.fc_num_img = LabelAtlas:create()
    self.fc_num_img:setProperty(0000,"ui/digit/bui_stone_red_num.png",20,26,"0")
    -- self.fc_num_img:setStringValue(6782)
    self.fc_num_img:setPosition(ccp(87,11))
    self.fc_num_img:setScale(0.75)
    self.fc_num_img:setAnchorPoint(ccp(0,0))
    mainui_fx_img:addChild(self.fc_num_img)

    local loack_panel = tolua.cast(self.right_uiLayer:getWidgetByName("Panel_176"), "Layout") 
    loack_panel:setScaleX(1/DisplayUtil.min_scale*globa_scalx*2)
    loack_panel:setScaleY(1/DisplayUtil.min_scale*globa_scaly)
    loack_panel:setPositionX(loack_panel:getPositionX()-200)

    local btn = tolua.cast(self.right_uiLayer:getWidgetByName("func_list_btn"), "Button") 
    -- local panel = self.uiLayer:getWidgetByName("Panel_99")
    local panel = tolua.cast(self.right_uiLayer:getWidgetByName("ImageView_38"), "ImageView")   
    local panelX = panel:getPositionX()
    local panelY = panel:getPositionY()
    local isPanelHide = true
    --初始不显示
    panel:setPositionY(800)
    panel:setVisible(false)

    --设置面板中各个按钮的事件
    local heroBtn = self.right_uiLayer:getWidgetByName("hero_btn") 
    local backpackBtn = self.right_uiLayer:getWidgetByName("backpack_btn") 
    local teamBtn = self.right_uiLayer:getWidgetByName("team_btn") 
    local taskBtn = self.right_uiLayer:getWidgetByName("task_btn")
    local spriteBtn = self.right_uiLayer:getWidgetByName("sprite_btn")

    --下拉列表中，英雄图标的绿色提示点
    hero_btn_tips_img = ImageView:create()
    hero_btn_tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
    heroBtn:addChild(hero_btn_tips_img)
    hero_btn_tips_img:setPosition(ccp(35,35))
    hero_btn_tips_img:setVisible(false)

    --任务图标的绿色提示点
    task_btn_tips_img = ImageView:create()
    task_btn_tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
    taskBtn:addChild(task_btn_tips_img)
    task_btn_tips_img:setPosition(ccp(35,35))
    task_btn_tips_img:setVisible(false)

    main_btn_tips_img = ImageView:create()
    main_btn_tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
    btn:addChild(main_btn_tips_img)
    main_btn_tips_img:setPosition(ccp(60,20))
    -- main_btn_tips_img:setScale(0.7)
    main_btn_tips_img:setVisible(false)

    --vip等级
    self.panelVip = self._left_panel:getChildByName("panel_vip")
    self.labAtlasVip = DisplayUtil.createLabAtlas("ui/digit/vip_num.png",0,18,28,31,48)
    self.labAtlasVip:setAnchorPoint(ccp(0.5,0.5))
    self.labAtlasVip:setPosition(ccp(self.panelVip:getChildByName("p_1"):getPosition()))
    self.panelVip:addNode(self.labAtlasVip)

    --购买金币按钮
    self.gold_btn = self.middle_uiLayer:getWidgetByName("gold_btn")

    local function changePanelStatus()
        if isPanelHide then
            isPanelHide = false
            panel:setVisible(true)

            local action = CCMoveTo:create(0.15, ccp(panelX, panelY))
           -- panel:runAction(CCMoveTo:create(0.1, ccp(panelX, panelY)))
            panel:runAction(CCEaseBackOut:create(action))

            if WindowCtrl:getInstance():hasWin() then
                loack_panel:setTouchEnabled(true)
                loack_panel:setVisible(true)
            end

            --第一次点击，检测一次，后续的都由对应事件响应
            -- if is_first_click then
            --     is_first_click = false
            --     local tip_img_vis = HeroManager:getInstance():isHeroListViewNeedTipsPoint()
            --     hero_btn_tips_img:setVisible(tip_img_vis)
            --     main_btn_tips_img:setVisible(tip_img_vis)
            -- end
        else
            isPanelHide = true
            local action2 = CCMoveTo:create(0.15, ccp(panelX, visibleSize.height+140))
            -- panel:runAction(CCMoveTo:create(0.1, ccp(panelX, visibleSize.height+140)))
            panel:runAction(CCEaseBackOut:create(action2))
            panel:setVisible(false)
            loack_panel:setTouchEnabled(false)
            loack_panel:setVisible(false)
        end 
    end

    local function onBtnClcik(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            changePanelStatus()
            --新手引导事件
            require "GuideDataProxy"
            if GuideDataProxy:getInstance().nowMainTutroialEventId == 10101 or
                GuideDataProxy:getInstance().nowMainTutroialEventId == 10302 or
                GuideDataProxy:getInstance().nowMainTutroialEventId == 10402 or
                GuideDataProxy:getInstance().nowMainTutroialEventId == 10605 or
                GuideDataProxy:getInstance().nowMainTutroialEventId == 10703 or
                GuideDataProxy:getInstance().nowMainTutroialEventId == 10902 or
                GuideDataProxy:getInstance().nowMainTutroialEventId == 11203 or
                GuideDataProxy:getInstance().nowMainTutroialEventId == 11106 then
                Notifier.dispatchCmd(GuideEvent.StepFinish,"click_btnmenu")
            end
        end
    end
    btn:addTouchEventListener(onBtnClcik)
    loack_panel:addTouchEventListener(onBtnClcik)

    local function onModuleBtnClcik(sender, eventType) --各个功能模块的点击
        
        if eventType == ComConstTab.TouchEventType.ended then
            --当前下拉是否已经完成
            if  panel:getPositionY() ~= panelY then
                return
            end

            local widgetName = sender:getName()

            if widgetName == "hero_btn" then
                WindowCtrl:getInstance():open(CmdName.Hero_List_View)            
            elseif widgetName == "backpack_btn" then
                WindowCtrl:getInstance():open(CmdName.BACKPACK_VIEW)
            elseif widgetName == "team_btn" then
                WindowCtrl:getInstance():open(CmdName.Team_View)
            elseif widgetName == "task_btn" then
                WindowCtrl:getInstance():open(CmdName.Task_View)
            elseif widgetName == "sprite_btn" then
                WindowCtrl:getInstance():open(CmdName.Pet_View)
            end

            changePanelStatus() 
        end

    end

    heroBtn:addTouchEventListener(onModuleBtnClcik)
    backpackBtn:addTouchEventListener(onModuleBtnClcik)
    teamBtn:addTouchEventListener(onModuleBtnClcik)
    taskBtn:addTouchEventListener(onModuleBtnClcik)
    spriteBtn:addTouchEventListener(onModuleBtnClcik)

       --vip按钮
        self.vip_btn = self.left_uiLayer:getWidgetByName("vip_btn")
        self.vip_btn:addTouchEventListener(function(sender, eventType)
            if eventType == ComConstTab.TouchEventType.ended then
               --  require "VipNetTask"
               -- VipNetTask:getInstance():requestVipInfo()
               WindowCtrl:getInstance():open(CmdName.Vip_View,{panel_type=VipPanelType.PayInfoPanel})
            end
        end)
        table.insert(self._iconList,self.vip_btn)

        --活动按钮
        self.activity_btn = tolua.cast(self.left_uiLayer:getWidgetByName("activity_btn"),"Button")
        self.activity_btn:setVisible(false)
        self.activity_btn:setTouchEnabled(false)
        self.activity_btn:addTouchEventListener(function(sender, eventType)
            if eventType == ComConstTab.TouchEventType.ended then
                require "RewardNetTask"
                RewardNetTask:getInstance():requestActivityRewardInfo()
            end
        end)
        table.insert(self._iconList,self.activity_btn)

        --debug
        -- FB活动按钮
        if SdkManager:getSdkPlatform() == SdkHelper.channel.lunplay or SdkManager:getSdkPlatform() == SdkHelper.channel.cp then 
            self.fb_btn = Button:create()
            self.fb_btn:setPosition(ccp(0, 14))
            self.fb_btn:setAnchorPoint(ccp(0,0))
            self.fb_btn:loadTextureNormal("btn_fb_up.png", UI_TEX_TYPE_PLIST)
            self.fb_btn:loadTexturePressed("btn_fb_down.png", UI_TEX_TYPE_PLIST)
            -- self.fb_btn:setTitleText("FB活動")
            self._left_panel:addChild(self.fb_btn)
            self.fb_btn:addTouchEventListener(function(sender, eventType)
                if eventType == ComConstTab.TouchEventType.ended then
                    if SdkManager:getSdkPlatform() == SdkHelper.channel.lunplay then
                    --     --先调用SDK获取好友数据，回调回来打开好友列表界面
                        Global:excSdkFunc(2)
                    else
                        WindowCtrl:getInstance():open(CmdName.FbReward_View)
                    end
                end
            end)
            table.insert(self._iconList,self.fb_btn)
        end

        
        -- table.insert(self._iconList,self.friend_btn)

        --公告按钮
        self.broad_btn = self.left_uiLayer:getWidgetByName("broad_btn")
        self.broad_btn:setVisible(false)
        self.broad_btn:setTouchEnabled(false)
        self.broad_btn:addTouchEventListener(function(sender, eventType)
            if eventType == ComConstTab.TouchEventType.ended then
                
                WindowCtrl:getInstance():open(CmdName.Notice_Scene)
            end
        end)
        table.insert(self._iconList,self.broad_btn)

        --公会战按钮
        self.guild_btn = tolua.cast(self.left_uiLayer:getWidgetByName("btn_guild"),"Button")
        self.guild_btn:setVisible(false)
        self.guild_btn:setTouchEnabled(false)
        self.guild_btn:addTouchEventListener(function(sender, eventType)
            if eventType == ComConstTab.TouchEventType.ended then
                require "GuildNetTask"
                WindowCtrl:getInstance():open(CmdName.Guild_View_FightScene)
            end
        end)
        table.insert(self._iconList,self.guild_btn)

        --天空之役
        self.sky_battle_btn = tolua.cast(self.left_uiLayer:getWidgetByName("btn_skybattle"),"Button")
        self.sky_battle_btn:setVisible(false)
        self.sky_battle_btn:setTouchEnabled(false)
        self.sky_battle_btn:addTouchEventListener(function(sender, eventType)
            if eventType == ComConstTab.TouchEventType.ended then
                ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.SkyBattle,function()
                  WindowCtrl:getInstance():open(CmdName.Skywar_View)
                  ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.sky_battle)
                end)
            end
        end)
        table.insert(self._iconList,self.sky_battle_btn)

        --首冲按钮
        self.firstcharge_btn = tolua.cast(self.left_uiLayer:getWidgetByName("btn_firstcharge"),"Button")
        self.firstcharge_btn:setVisible(false)
        self.firstcharge_btn:setTouchEnabled(false)
        self.firstcharge_btn:addTouchEventListener(function(sender, eventType)
            if eventType == ComConstTab.TouchEventType.ended then
                WindowCtrl:getInstance():open(CmdName.Reward_FirstRechargeView)
            end
        end)
        table.insert(self._iconList,self.firstcharge_btn)

        --节日按钮
        -- self.festival_btn = tolua.cast(self.left_uiLayer:getWidgetByName("btn_festival"),"Button")
        -- -- self.festival_btn:setVisible(false)
        -- -- self.festival_btn:setTouchEnabled(false)
        -- self.festival_btn:addTouchEventListener(function(sender, eventType)
        --     if eventType == ComConstTab.TouchEventType.ended then
        --         require "FestivalNetTask"
        --         FestivalNetTask:getInstance():requestFestivalInfos()

        --     end
        -- end)
        -- table.insert(self._iconList,self.festival_btn)

        --购买钻石
       local diamon_btn = self.middle_uiLayer:getWidgetByName("diamon_btn")
       diamon_btn:addTouchEventListener(function(sender, eventType)
            if eventType == ComConstTab.TouchEventType.ended then
                WindowCtrl:getInstance():open(CmdName.Vip_View,{panel_type=VipPanelType.PayInfoPanel})
            end
       end)

       --购买金币
       local gold_btn = self.middle_uiLayer:getWidgetByName("gold_btn")
       -- self.gold_btn = self.middle_uiLayer:getWidgetByName("gold_btn")
       gold_btn:addTouchEventListener(function(sender, eventType)
            if eventType == ComConstTab.TouchEventType.ended then
                if CharacterDataProxy:getInstance().isCanRefresh == 1 then
                    CharacterNetTask:getInstance():requestCheckBuyCoin()
                else
                    WindowCtrl:getInstance():open(CmdName.Character_buyCoin)
                end
            end
       end)
       --购买体力
       local phy_btn = self.middle_uiLayer:getWidgetByName("phy_btn")
       phy_btn:addTouchEventListener(function(sender, eventType)
            if eventType == ComConstTab.TouchEventType.ended then   
                CharacterNetTask:getInstance():requestCheckBuyPhysical()
            end
       end)
       --体力区域
       local phy_bg = self.middle_uiLayer:getWidgetByName("phy_bg")
       phy_bg:addTouchEventListener(function(sender, eventType)
            local btn = tolua.cast(sender,"Button")
             if eventType == ComConstTab.TouchEventType.began then
                require "CheckPhysicalScene"
                CheckPhysicalScene:show()
            end
            if eventType == ComConstTab.TouchEventType.ended
               or eventType == ComConstTab.TouchEventType.canceled then
                CheckPhysicalScene:hide()
            end

             cclog("位置~~%d",self._middle_panel:getPositionX())
       end)

    self:setRoleInfo()
    self:addEvent()
    self:handlePhysicalTimer() --初始化体力

    self:adjustPos()

    --延迟处理的事情
    TimerManager.addTimer(4000,function() self:delayEvent() end)

     WindowCtrl:getInstance():setMainUI(self.left_uiLayer, self.middle_uiLayer, self.right_uiLayer, self)
  end

function MainUI:addEvent()
    --新消息提示
    Notifier.regist(CmdName.MAIN_SHOW_NEWS_TIP,function(param) self:showNewsTip(param) end)
    Notifier.regist(CmdName.MAIN_HIDE_NEWS_TIP,function(param) self:hideNewsTip(param) end)
    Notifier.regist(CmdName.MAIN_SHOW_NEWS_ICON,function(param) self:showNewsIcon(param) end)
    Notifier.regist(CmdName.MAIN_HIDE_NEWS_ICON,function(param) self:hideNewsIcon(param) end)
    Notifier.regist(CmdName.MAIN_SHOW_ACTIVATE_ITEM,function(param) self:showPerpareActivate(param) end)
    Notifier.regist(CmdName.MAIN_HIDE_ACTIVATE_ITEM,function(param) self:hidePerpareActivate(param) end)

    Notifier.regist(CmdName.RSP_GET_ROLE_INFO,function() self:setRoleInfo() end)
    Notifier.regist(CmdName.RSP_UPDATE_ROLE_ASSET,function() self:setRoleInfo() end)



    -- Notifier.regist(CharacterEvent.RSP_PHYSICAL_SYNC,function()self:handlePhysicalTimer()  end) --同步体力事件

   Notifier.regist(CmdName.CHARACTER_RSP_UPDATE_TEAM,function() self:setRoleInfo() end)
   Notifier.regist(CmdName.RSP_UPDATE_ROLE_INFO,function() self:setRoleInfo() end)
   Notifier.regist(CmdName.UpdateGreenTipsPoint, function(params) self:UpdateGreenTipsPoint(params) end)
   Notifier.regist(CmdName.VIP_INFO_UPDATE,function() self:setRoleInfo() end)

   --监听是否有人添加好友
   -- Notifier.regist(CmdName.Friend_Add_Friend, )

   --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)

    Notifier.regist(CmdName.UpdateHeadIconSuc,function(head_id) self.head_icon:setFaceId(head_id) end) 
    Notifier.regist(CmdName.Team_Fc_Update,function() self:updateTeamFc() end) 
    Notifier.regist(CmdName.updateOpenTime,function() RewardDataProxy:getInstance():isShowActivityIcon() end)
end

function MainUI:getInstance()
    return __instance
end

function MainUI:create()
    local layer = MainUI.new()
    layer:init()
    layer:retain()
    __instance = layer
    return layer
end

--设置角色信息
function MainUI:setRoleInfo()
    local name_label = self.left_uiLayer:getWidgetByName("name_label")
    tolua.cast(name_label,"Label")
    name_label:setText(characterMgr:getBaseData():getName())

    local value = 0
    local diamond_label = self.middle_uiLayer:getWidgetByName("diamond_label")
    tolua.cast(diamond_label,"Label")
    value = characterMgr:getAssetData():getDiamond()
    self:checkPlayAnim(diamond_label,value)
    diamond_label:setText(value)

    local glod_label = self.middle_uiLayer:getWidgetByName("gold_label")
    tolua.cast(glod_label,"Label")
    value = characterMgr:getAssetData():getGold()
    self:checkPlayAnim(glod_label,value)
    glod_label:setText(value) 

    local physical_label = tolua.cast(self.middle_uiLayer:getWidgetByName("physical_label"),"Label")
    local physical_labelMax = tolua.cast(self.middle_uiLayer:getWidgetByName("physical_label_max"),"Label")
    local physical_middle = tolua.cast(self.middle_uiLayer:getWidgetByName("Label_302"),"Label")
    value = characterMgr:getAssetData():getPhysical()
    self:checkPlayAnim(physical_label,value)
    self:checkPhyscialColor(physical_label,physical_middle,physical_labelMax,value)
    physical_label:setText(value)
    physical_labelMax:setText(CharacterDataProxy:getInstance():getLevPhysicalMax())

    local team_lv_label = self.left_uiLayer:getWidgetByName("team_lv_label")
    tolua.cast(team_lv_label,"Label")
    value = characterMgr:getTeamData():getLev()
    self:checkPlayAnim(team_lv_label,value)
    team_lv_label:setText(value) 

    value = characterMgr:getBaseData():getVipLv()
    self:checkPlayAnimVip(self.labAtlasVip,value)
    self.labAtlasVip:setString(value)

    --设置头像
    self.head_icon:setFaceId(characterMgr:getBaseData():getFaceId())
    -- self.head_icon:setFaceId(10000)
    self:updateTeamFc()
end

function MainUI:checkPlayAnim(lab,value)
    local oldValue = lab:getStringValue()
    if oldValue ~= tostring(value) then
        local arr = CCArray:create()
        arr:addObject(CCDelayTime:create(0.2))
        arr:addObject(CCScaleTo:create(0.12,1.4))
        arr:addObject(CCScaleTo:create(0.1,1))
        lab:stopAllActions()
        lab:runAction(CCSequence:create(arr))
    end
end

function MainUI:checkPlayAnimVip(lab,value)
    local oldValue = lab:getString()
    if oldValue ~= tostring(value) then
        local arr = CCArray:create()
        arr:addObject(CCDelayTime:create(0.2))
        arr:addObject(CCScaleTo:create(0.12,1.4))
        arr:addObject(CCScaleTo:create(0.1,1))
        lab:stopAllActions()
        lab:runAction(CCSequence:create(arr))
        
        self.panelVip:setVisible(true)
    end
end

function MainUI:checkPhyscialColor(lab,labMiddle,labMax,value)
    -- local oldValue = lab:getStringValue()
    if value < CharacterDataProxy:getInstance():getLevPhysicalMax() then
        lab:setColor(ccc3(0xfb,0xf1,0xa0))
        labMax:setColor(ccc3(0xfb,0xf1,0xa0))
        labMiddle:setColor(ccc3(0xfb,0xf1,0xa0))
    else
        lab:setColor(ccc3(0xff,0xb1,0x09))
        labMax:setColor(ccc3(0xfb,0xf1,0xa0))
        labMiddle:setColor(ccc3(0xff,0xb1,0x09))
    end
end
--新手引导动画
function MainUI:showStepAnim(param)
    if param.target == "mainui_drop" then
        local btn = tolua.cast(self.right_uiLayer:getWidgetByName("func_list_btn"), "Button") 
        GuideRenderMgr:getInstance():renderMainFlag(btn,param.id,param.target)
    elseif param.target == "mainui_btnhero" then
        local btn = self.right_uiLayer:getWidgetByName("hero_btn") 
        GuideRenderMgr:getInstance():renderMainFlag(btn,param.id,param.target)
    elseif param.target == "mainui_btnteam" then
        local btn = self.right_uiLayer:getWidgetByName("team_btn") 
        GuideRenderMgr:getInstance():renderMainFlag(btn,param.id,param.target)
    elseif param.target == "mainui_btnbag" then
        local btn = self.right_uiLayer:getWidgetByName("backpack_btn")
        GuideRenderMgr:getInstance():renderMainFlag(btn,param.id,param.target)
    elseif param.target == "mainui_btnsprite" then
        local btn = self.right_uiLayer:getWidgetByName("sprite_btn") 
        GuideRenderMgr:getInstance():renderMainFlag(btn,param.id,param.target)
    end
end

--响应 同步体力事件
function MainUI:handlePhysicalTimer()

    local cm = CharacterManager:getInstance()
    local dp = CharacterDataProxy:getInstance()
    
    -- --体力秒数定时器
    -- local function scendTimer(isForceInit)
    --     local sceneVo = dp:getCheckPhysicalSceneVo()
    --     local nowTime = ServerTimerManager:getInstance():getCurTime()
    --     local addPhys = math.floor( ( nowTime - sceneVo.lastTime ) / 360 )--加的体力数
    --     local disTime = ( nowTime - sceneVo.lastTime ) % 360  --剩余秒数
    --     sceneVo.countTime = 6 * 60 - disTime   --倒计时数

    --     if addPhys ~= 0 then
    --         sceneVo.lastTime = nowTime - disTime
    --         if isForceInit then
    --             --初始化登录体力不加 因为服务端已经算好了
    --         else
    --             cm:addAutoRolePhysical(addPhys)
    --         end
    --     end
    -- end
    -- dp.scendPhysicalTimer = scendTimer
    -- TimerManager.addTimer(1000,scendTimer,true)
    -- scendTimer(true) --马上触发
-------------------------------------------------------------------------------
    local sceneVo = dp:getCheckPhysicalSceneVo()
    local nowTime = ServerTimerManager:getInstance():getCurTime()
    local disTime = ( nowTime - sceneVo.lastTime ) % 360  --剩余秒数
    sceneVo.countTime = 6 * 60 - disTime   --倒计时数

    -- local function cycleScendTimer() --6分钟自动秒数
    --     local nowTime = ServerTimerManager:getInstance():getCurTime()
    --     local addPhys = math.floor( ( nowTime - sceneVo.lastTime ) / 360 )--加的体力数
    --     local disTime = ( nowTime - sceneVo.lastTime ) % 360  --剩余秒数
    --     if addPhys ~= 0 then
    --         sceneVo.lastTime = nowTime - disTime
    --         cm:addAutoRolePhysical(addPhys)
    --     end
    -- end
    Timer.setTimer(sceneVo.countTime,function()
        CharacterDataProxy:getInstance().refreshPhysicalTimer()
        TimerManager.addTimer(1000 * 6 * 60,CharacterDataProxy:getInstance().refreshPhysicalTimer,true)
    end)
end

--根据分辨率调整mainui各个控件的位置
function MainUI:adjustPos()
    -- self._left_panel:setScaleX(1/globa_scalx*globa_scaly)
    -- self._middle_panel:setScaleX(1/globa_scalx*globa_scaly)
    -- self._right_panel:setScaleX(1/globa_scalx*globa_scaly)

    local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
    local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()

    local frame_size =  CCEGLView:sharedOpenGLView():getFrameSize()
    
    --左边模块的位置
    local diff_y = 0
    local rel_y = 0

    --中间模块的位置
    middle_width = middle_width*DisplayUtil.min_scale
    local diff_x = (frame_size.width-middle_width)/2
    local rel_x = diff_x/globa_scalx
    self._middle_panel:setPositionX(rel_x)
    cclog("位置~~%d",self._middle_panel:getPositionX())

    -- middle_height = middle_height*DisplayUtil.min_scale
    -- diff_y = self._middle_panel:getPositionY()
    -- rel_y = diff_y*DisplayUtil.min_scale
    -- self._middle_panel:setPositionY(rel_y)

    --右边模块的位置
    right_width = right_width*DisplayUtil.min_scale
    diff_x = (frame_size.width-right_width)
    rel_x = diff_x/globa_scalx
    self._right_panel:setPositionX(rel_x)
    

    if (frame_size.width==1024 and frame_size.height==768) or  
        (frame_size.width==1024*2 and frame_size.height==768*2) then
        self._right_panel:setPositionY(self._right_panel:getPositionY()+60)
    end
    -- right_height = right_height*DisplayUtil.min_scale
    -- diff_y = (frame_size.height-right_height)/2
    -- rel_y = diff_y*globa_scaly + self._right_panel:getPositionY()
    -- self._right_panel:setPositionY(rel_y)

    -- self._right_panel:setPositionY(79.5)
    
    -- self._right_panel:setPositionY(self._right_panel:getPositionY()*globa_scaly)
end

function MainUI:UpdateGreenTipsPoint(params)
    local hero_tips_vis = HeroManager:getInstance():isHeroListViewNeedTipsPoint()
    local task_tips_vis = TaskManager:getInstance():isNeedTipsPoint()
    local eqm_upgrade_vis = #ItemManager:getInstance():getCanUpgradeHeroList() > 0
    hero_btn_tips_img:setVisible(hero_tips_vis or eqm_upgrade_vis)
    main_btn_tips_img:setVisible(hero_tips_vis or task_tips_vis or eqm_upgrade_vis)
    task_btn_tips_img:setVisible(task_tips_vis)

    if task_tips_vis or hero_tips_vis or eqm_upgrade_vis then
        self:tipsPointPlayAct(task_btn_tips_img)
        self:tipsPointPlayAct(main_btn_tips_img)
    else
        task_btn_tips_img:stopAllActions()
        main_btn_tips_img:stopAllActions()
    end

    --是否需要显示英雄绿点
    if hero_tips_vis or eqm_upgrade_vis then
        self:tipsPointPlayAct(hero_btn_tips_img)
    else
        hero_btn_tips_img:stopAllActions()
    end
end

--主界面完成后，延迟若干时间后处理的事情
function MainUI:delayEvent()
    --首次进入主界面，刷新一次绿色提示点状态
    self:UpdateGreenTipsPoint()

    self:checkCreateFestivalIcons()
    FestivalDataProxy:getInstance():delayExcFestivalInfos()

    --定义刷新
    local function timerRefresh()
        GuildDataProxy:getInstance():progressSchedule()
        SkywarManager:getInstance():checkValidOpenTime()
    end

    SkywarManager:getInstance():checkValidOpenTime()
    TimerManager.addTimer(1000 * 30, timerRefresh, true)
    
end

function MainUI:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

--动态创建节日活动按钮
function MainUI:checkCreateFestivalIcons()
	local voList = FestivalDataProxy:getInstance():getFestivalVoList()
	for festival_id,v in pairs(voList) do
		if v:isVaild() then
			if self["festival_btn"..festival_id] == nil then
				self["festival_btn"..festival_id] = Button:create()
				self["festival_btn"..festival_id]:setAnchorPoint(ccp(0,0))
				self["festival_btn"..festival_id]:loadTextureNormal(v.res_icon.."_up.png", UI_TEX_TYPE_PLIST)
				self["festival_btn"..festival_id]:loadTexturePressed(v.res_icon.."_down.png", UI_TEX_TYPE_PLIST)
				self["festival_btn"..festival_id]:setPosition(ccp(0, 14))
				self._left_panel:addChild(self["festival_btn"..festival_id])
                self:showBtnArm(self["festival_btn"..festival_id],NewTipsEnum.festival)
				self["festival_btn"..festival_id]:addTouchEventListener(function(sender, event)
				    if event ~= TOUCH_EVENT_ENDED then
				    	return
				    end

				    require "FestivalNetTask"
	                FestivalNetTask:getInstance():requestFestivalInfos(festival_id)
				end)
				table.insert(self._iconList,self["festival_btn"..festival_id])
			end
		else
			if self["festival_btn"..festival_id] then
				self["festival_btn"..festival_id]:removeFromParentAndCleanup(true)
				self["festival_btn"..festival_id] = nil
			end
		end
	end
end

function MainUI:enter()

    require "ScrollBroad"
    ScrollBroad:show()

    self:UpdateGreenTipsPoint()
    self:refreshNewsTipAct()
    self:sortIcon()
end

function MainUI:refreshNewsTipAct()
    if self.broad_btn:getChildByTag(2866) ~= nil then
        self:tipsPointPlayAct(self.broad_btn:getChildByTag(2866))
    end
    if self.guild_btn:getChildByTag(2866) ~= nil then
        self:tipsPointPlayAct(self.guild_btn:getChildByTag(2866))
    end
    if self.activity_btn:getChildByTag(2866) ~= nil then
        self:tipsPointPlayAct(self.activity_btn:getChildByTag(2866))
    end
    if self.vip_btn:getChildByTag(2866) ~= nil then
        self:tipsPointPlayAct(self.vip_btn:getChildByTag(2866))
    end
    if self.firstcharge_btn:getChildByTag(2866) ~= nil then
        self:tipsPointPlayAct(self.firstcharge_btn:getChildByTag(2866))
    end
    if self.gold_btn:getChildByTag(2866) ~= nil then
        self:tipsPointPlayAct(self.gold_btn:getChildByTag(2866))
    end

    local voList = FestivalDataProxy:getInstance():getCurTipsTarget()
	for festival_id,v in pairs(voList) do
		if v == 1 then
			local target = self["festival_btn"..festival_id]
			if target and target:getChildByTag(2866) ~= nil then
				self:tipsPointPlayAct(target:getChildByTag(2866))
			end
		end
	end
end

-- 展示 新消息 提示
function MainUI:showNewsTip(key)
    local target = nil
    local pos = nil
    if key == NewTipsEnum.mainui_guild_fight then
        target = self.guild_btn
        pos = ccp(130,52)
    elseif key == NewTipsEnum.notice then
        target = self.broad_btn
        pos = ccp(95,52)
    elseif key == NewTipsEnum.task_physical then
        target = self.right_uiLayer:getWidgetByName("func_list_btn") 
        pos = ccp(140,40)
    elseif key == NewTipsEnum.login_buy_coin then --显示免费购买金币绿点提示
        pos = ccp(15,15)
        target = self.gold_btn
    elseif key == NewTipsEnum.festival then
    	local voList = FestivalDataProxy:getInstance():getCurTipsTarget()
    	for festival_id,v in pairs(voList) do
    		if v == 1 then
    			local target = self["festival_btn"..festival_id]
    			if target and target:getChildByTag(2866) == nil then
			        local tips_img = ImageView:create()
			        tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
			        tips_img:setTag(2866)
			        tips_img:setPosition(ccp(95,52))
			        target:addChild(tips_img)
			        self:tipsPointPlayAct(tips_img)
			    elseif target and target:getChildByTag(2866) ~= nil then
			        local tips_img = target:getChildByTag(2866)
			        self:tipsPointPlayAct(tips_img)
			    end
    		end
    	end
    elseif key == NewTipsEnum.reward then
        local res = RewardDataProxy:getInstance():getCurActivityBtnRes()
        if res == "i18n_activity_btn" then
            pos = ccp(110,52)
        else
            pos = ccp(95,52)
        end
        target = self.activity_btn
    elseif key == NewTipsEnum.vip then
        pos = ccp(95,52)
        target = self.vip_btn
    elseif key == NewTipsEnum.first_charge then
        pos = ccp(100,52)
        target = self.firstcharge_btn
    end
    if target and target:getChildByTag(2866) == nil then
        local tips_img = ImageView:create()
        tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
        tips_img:setTag(2866)
        tips_img:setPosition(pos)
        target:addChild(tips_img)
        self:tipsPointPlayAct(tips_img)
    elseif target and target:getChildByTag(2866) ~= nil then
        local tips_img = target:getChildByTag(2866)
        self:tipsPointPlayAct(tips_img)
    end
end

-- 隐藏 新消息 提示
function MainUI:hideNewsTip(key)
    local target = nil
    if key == NewTipsEnum.mainui_guild_fight then
        target = self.guild_btn
    elseif key == NewTipsEnum.notice then
        target = self.broad_btn
    elseif key == NewTipsEnum.task_physical then
        target = self.right_uiLayer:getWidgetByName("func_list_btn") 
    elseif key == NewTipsEnum.reward then
        target = self.activity_btn
    elseif key == NewTipsEnum.vip then
        target = self.vip_btn
    elseif key == NewTipsEnum.festival then
    	local voList = FestivalDataProxy:getInstance():getCurTipsTarget()
    	for festival_id,v in pairs(voList) do
    		if v == 0 then
    			local target = self["festival_btn"..festival_id]
    			if target and target:getChildByTag(2866) ~= nil then
			        target:removeChildByTag(2866,true)
			    end
    		end
    	end
    elseif key == NewTipsEnum.first_charge then
        target = self.firstcharge_btn
        self:hideNewsIcon(key)
    elseif key == NewTipsEnum.login_buy_coin then  --隐藏金币绿点提示
        target = self.gold_btn
        self:hideNewsIcon(key)
    end
    if target and target:getChildByTag(2866) ~= nil then
        characterMgr:getBaseData():setNewsTipStatus(key,1) --0 显示  1 不显示
        target:removeChildByTag(2866,true)
    end
end

--隐藏图标
function MainUI:hideNewsIcon(key)
    if key == NewTipsEnum.notice then
        self.broad_btn:setVisible(false)
        self.broad_btn:setTouchEnabled(false)
    elseif key == NewTipsEnum.reward then
        self.activity_btn:setVisible(false)
        self.activity_btn:setTouchEnabled(false)
    elseif key == NewTipsEnum.sky_battle then
        self.sky_battle_btn:setVisible(false)
        self.sky_battle_btn:setTouchEnabled(false)
    elseif key == NewTipsEnum.mainui_guild_fight then
        self.guild_btn:setVisible(false)
        self.guild_btn:setTouchEnabled(false)
    elseif key == NewTipsEnum.first_charge then
        self.firstcharge_btn:setVisible(false)
        self.firstcharge_btn:setTouchEnabled(false)
    elseif key == NewTipsEnum.festival then
    	local voList = FestivalDataProxy:getInstance():getCurIconsTarget()
    	for festival_id,v in pairs(voList) do
    		if v == 0 then
    			local target = self["festival_btn"..festival_id]
    			if target then
			        target:setVisible(false)
			        target:setTouchEnabled(false)
			    end
    		end
    	end
    end
    self:sortIcon()
end

--展示图标
function MainUI:showNewsIcon(key)
    if key == NewTipsEnum.notice then
        self.broad_btn:setVisible(true)
        self.broad_btn:setTouchEnabled(true)
    elseif key == NewTipsEnum.sky_battle then
        self.sky_battle_btn:setVisible(true)
        self.sky_battle_btn:setTouchEnabled(true)
    elseif key == NewTipsEnum.festival then

    	self:checkCreateFestivalIcons()
    	local voList = FestivalDataProxy:getInstance():getCurIconsTarget()
    	for festival_id,v in pairs(voList) do
    		if v == 1 then
    			local target = self["festival_btn"..festival_id]
    			if target then
			        target:setVisible(true)
			        target:setTouchEnabled(true)
                    self:showBtnArm(target,key)
			    end
    		end
    	end

    elseif key == NewTipsEnum.reward then
        self.activity_btn:setVisible(true)
        self.activity_btn:setTouchEnabled(true)
        --切换纹理
        local res = RewardDataProxy:getInstance():getCurActivityBtnRes()
        self.activity_btn:loadTextureNormal(res .."_up.png" ,UI_TEX_TYPE_PLIST)
        self.activity_btn:loadTexturePressed(res .."_down.png" ,UI_TEX_TYPE_PLIST)
        if res == "i18n_activity_btn" then
            self:showBtnArm(self.activity_btn,key)
        else
            self:hideBtnArm(self.activity_btn,key)
        end
    elseif key == NewTipsEnum.mainui_guild_fight then
        self.guild_btn:setVisible(true)
        self.guild_btn:setTouchEnabled(true)
        --切换纹理
        local res = GuildDataProxy:getInstance():getCurGuildFightViewRes()
        self.guild_btn:loadTextureNormal(res .."_up.png" ,UI_TEX_TYPE_PLIST)
        self.guild_btn:loadTexturePressed(res .."_down.png" ,UI_TEX_TYPE_PLIST)
    elseif key == NewTipsEnum.first_charge then
        self.firstcharge_btn:setVisible(true)
        self.firstcharge_btn:setTouchEnabled(true)
        self:showBtnArm(self.firstcharge_btn,key)
    end
    self:sortIcon()
end

function MainUI:showPerpareActivate(activateId)
    require "ActivateDataProxy"
    require "MainPerpareActivateItem"
    local vo = ActivateDataProxy:getInstance():getEventVoById(activateId)
    if self._left_panel:getChildByTag(2488) == nil then
        self._activate_item = MainPerpareActivateItem:create()
        self._activate_item:setTag(2488)
        self._activate_item:setPosition(ccp(50,-30))
        self._left_panel:addChild(self._activate_item)
    end
    self._activate_item:setData(vo)
end

function MainUI:hidePerpareActivate(activateId)
    local child = self._left_panel:getChildByTag(2488)
    if child ~= nil then
        self._left_panel:removeChildByTag(2488,true)
    end
end

--展示特效
function MainUI:showBtnArm(container,key)
    if key == NewTipsEnum.reward and container:getNodeByTag(5514) == nil then
        local armPath = "ui/effects_ui/kaifuhuodong/kaifuhuodong.ExportJson"
        local arm = AnimateManager:getInstance():getArmature(armPath, "kaifuhuodong") 
        arm:getAnimation():play("Animation1",-1,-1,1)
        arm:setPosition(ccp(38,34))
        arm:setTag(5514)
        container:addNode(arm)
    elseif key == NewTipsEnum.first_charge and container:getNodeByTag(5514) == nil then
        local armPath = "ui/effects_ui/shouchong/shouchong.ExportJson"
        local arm = AnimateManager:getInstance():getArmature(armPath, "shouchong") 
        arm:getAnimation():play("Animation1",-1,-1,1)
        arm:setPosition(ccp(0,-5))
        arm:setTag(5514)
        container:addNode(arm)
    elseif key == NewTipsEnum.festival and container:getNodeByTag(5514) == nil then
        local armPath = "ui/effects_ui/laodongjie/laodongjie.ExportJson"
        local arm = AnimateManager:getInstance():getArmature(armPath, "laodongjie") 
        arm:getAnimation():play("Animation1",-1,-1,1)
        arm:setPosition(ccp(40,30))
        arm:setTag(5514)
        container:addNode(arm)
    end
end
--隐藏特效
function MainUI:hideBtnArm(container,key)
    if key == NewTipsEnum.reward and container:getNodeByTag(5514) ~= nil then
        container:removeNodeByTag(5514)
    elseif key == NewTipsEnum.first_charge and container:getNodeByTag(5514) ~= nil then
        container:removeNodeByTag(5514)
    elseif key == NewTipsEnum.festival and container:getNodeByTag(5514) ~= nil then
        container:removeNodeByTag(5514)
    end
end
--图标排序
function MainUI:sortIcon()
    local tmpTbl = {}
    for i=1,#self._iconList do
        local v = self._iconList[i]
        if v:isVisible() == true then
            table.insert(tmpTbl,v)
        end
    end
    local baseX = 244
    for i=1,#tmpTbl do
        local v = tmpTbl[i]
        v:setPositionX(baseX)
        baseX = baseX + v:getContentSize().width
    end
end

function MainUI:updateTeamFc()
    self.fc_num_img:setStringValue(TeamManager:getInstance():_onlyCalcFc(TeamType.Normal))
end