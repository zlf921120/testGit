--主界面预备 激活 提示项
MainPerpareActivateItem = class("MainPerpareActivateItem",function()
	return Widget:create()
end)

function MainPerpareActivateItem:create()
	local ret = MainPerpareActivateItem.new()
	ret:init()
	return ret
end

function MainPerpareActivateItem:init()
	require "ActivateDataProxy"
	require "ActivateCfg"
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/activate/activate.plist")

	self.imgView = ImageView:create()
	self:addChild(self.imgView)

	self.imgTitleBg = ImageView:create()
	self.imgTitleBg:loadTexture("activate_perpare_frame.png",UI_TEX_TYPE_PLIST)
	self.imgTitleBg:setPosition(ccp(0,-60 - 10))
	self:addChild(self.imgTitleBg)

	self.labCond = Label:create()
	self.labCond:setPosition(ccp(0, -60 - 10))
	self.labCond:setColor(ccc3(0xf5, 0xcc, 0x55))
	self.labCond:setFontSize(22)
	self:addChild(self.labCond)

	self.armLight = AnimateManager:getInstance():getArmature("ui/effects_ui/XGNKQbeijingguang/XGNKQbeijingguang.ExportJson","XGNKQbeijingguang")
	self.armLight:getAnimation():play("Animation1",-1,-1,1)
	self.armLight:setPosition(ccp(0,-5))
	self:addNode(self.armLight)
end

function MainPerpareActivateItem:setData(vo)

	self.imgView:loadTexture( ActivatePerpareImg[ vo.id ],UI_TEX_TYPE_PLIST )
	self.labCond:setText( vo.leftCond.forbid )
end