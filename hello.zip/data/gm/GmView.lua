--
-- Author: lvgansheng
-- Date: 2014-06-27 12:03:17
--  内部人员测试用界面

require("sp_pb")
require("BattleTestCmd")
require "GuideTestCmd"
require "ErrorLogView"
require "ResContendTestCmd"

GmView = class("GmView",function() return CCLayer:create() end)

GmView._logView = nil

function GmView:init()
    self:setPositionX(10)
    self:setPositionY(200)
	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
	self.uiLayer:setTouchPriority(-2550)

	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/gm_ui/gm_ui.ExportJson")
    self.uiLayer:addWidget(self.widget)

    local gm_txt_field = tolua.cast(self.uiLayer:getWidgetByName("TextField_240"), "TextField") 
    gm_txt_field:setInsertText(true)
    gm_txt_field:setVisible(false)
    gm_txt_field:setTouchEnabled(false)

    local inputAccout = CCEditBox:create(CCSize(550,50),CCScale9Sprite:create("ui/login/resource/img/img_empty.png"))
    -- local inputAccout = CCEditBox:create(CCSize(550,50),CCScale9Sprite:initWithSpriteFrame("bg_1.png"))
    local x,y = gm_txt_field:getPosition()
    inputAccout:setPosition(ccp(x ,y))
    inputAccout:setTouchPriority(-2551)
    inputAccout:setMaxLength(72)
    inputAccout:setPlaceHolder("请在此输入GM命令")
    inputAccout:setInputMode(kEditBoxInputModeSingleLine)
    inputAccout:setFontSize(24)
    self:addChild(inputAccout)
    inputAccout:setTouchEnabled(false)

    self._logView = ErrorLogView:create()
    self._logView:setPosition(ccp(0, -200))
    self._logView:retain()

    local send_btn = self.uiLayer:getWidgetByName("Button_29")
    local sp_client_gm_req = sp_pb.sp_client_gm_req();

    function sp_client_gm_req_cbf(pbPkgData)
        local gmRsp = sp_pb.sp_client_gm_rsp()
        gmRsp:ParseFromString(pbPkgData)
        if gmRsp.ret ~= error_code_pb.msg_ret.success then
            return
        end
        ComSender:getInstance():dealExtInfo(gmRsp.ext)
        cclog ("别返回这条协议啊，这是不对的sp_client_gm_req_cbf")
    end 

    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.sp_client_gm_req+1, "sp_client_gm_req_cbf()") --侦听背包数据的增加，测试用   


    local function pressCallBack(sender, eventType)
     if eventType == ComConstTab.TouchEventType.ended then
    	local gm_txt = inputAccout:getText()
    	cclog ("当前输入的gm命令是:%s, %d",gm_txt, #gm_txt)
        sp_client_gm_req.cmd = gm_txt

        if BattleTestCmd:getInstance():catchCmd(gm_txt) or 
            GuideTestCmd:getInstance():catchCmd(gm_txt) or 
            GuideTestCmd:getInstance():catchCmd2(gm_txt) or
            ResContendTestCmd:getInstance():catchCmd(gm_txt) then
            return
        end
       -- Global:sendPkg(proto_cmd_pb.msg_cmd.sp_client_gm_req, sp_client_gm_req:SerializeToString() , sp_client_gm_req:ByteSize())
        if #gm_txt == 0 then
            -- CCTextureCache:sharedTextureCache():dumpCachedTextureInfo()
            self._logView:removeFromParentAndCleanup(false)
            self:addChild(self._logView)
            collectgarbage("collect")
            collectgarbage("collect")
            local size = collectgarbage("count")
            self._logView:addLog(string.format("%.2f", size/1024))
        else
            ComSender:getInstance():send(proto_cmd_pb.msg_cmd.sp_client_gm_req,sp_client_gm_req)
        end
      end
	end

	send_btn:addTouchEventListener(pressCallBack)    

	local hide_btn = self.uiLayer:getWidgetByName("Button_241")

    local function hide_btn_click(sender, eventType)
      if eventType == ComConstTab.TouchEventType.ended then
    	if self.uiLayer:getPositionX() < 0 then
    		-- self:setPositionX(10)
            inputAccout:setVisible(true)
            inputAccout:setTouchEnabled(true)
            self.uiLayer:setPositionX(10)
    	else
            inputAccout:setVisible(false)
            inputAccout:setTouchEnabled(false)
    		-- self:setPositionX(-730)
            self.uiLayer:setPositionX(-730)
    	end
	  end
    end
	hide_btn:addTouchEventListener(hide_btn_click)

    -- self:setPositionX(-730)    
    self.uiLayer:setPositionX(-730)
    inputAccout:setVisible(false)
    -- inputAccout:setText("资源争夺 新")
    
end

function GmView:create()
	local view = GmView.new()
	view:init()
	return view
end

