--
-- Author: thisgf
-- Date: 2014-10-07 16:58:20
-- 战斗测试命令

require "combatDataStorage"
require "GuideLocalReader"
require "fnt_battle_test_data_pb"
require "BattleReportManager"
require "BattleProcessData"

BattleTestCmd = class("BattleTestCmd")

BattleTestCmd._testDataDict = nil

BattleTestCmd._isParseData = false

local _instance

function BattleTestCmd:ctor()

	self._testDataDict = {}

end

function BattleTestCmd:getInstance()
	if _instance == nil then
		_instance = BattleTestCmd.new()
	end

	return _instance
end

function BattleTestCmd:parseTestData()

	if self._isParseData == true then
		return
	end

	self._isParseData = true

	local configData = FileUtils.readConfigFile("fnt_battle_test_data.dat")

	local test_data_pb = fnt_battle_test_data_pb.fnt_battle_test_data()
	test_data_pb:ParseFromString(configData)

	for k, v in pairs(test_data_pb.test_rows) do

		if v.id ~= nil then

			local initData = CombatInitData:create()
			initData.sceneType = BattleSceneType.SINGLE
			initData.battleType = BattleType.DUNGEON

			local waveData = CombatWaveData:create()
			waveData.sceneId = 10006
			local fileName = CombatDataStorage:getInstance():getCombatSceneData(waveData.sceneId).fileName
			waveData.sceneFileName = string.format("%s/%s.%s", BattleSceneFilePrefix, fileName, BattleSceneFileType)

			local monsterList = loadstring("return {" .. v.monster_list .. "}")()
			for i, monster in ipairs(monsterList) do
				waveData:addMonster(monster)
			end

			waveData.roleJoinType = BattleJoinType.RUN
			waveData.monsterJoinType = BattleJoinType.RUN

			initData:addWaveData(waveData)

			self._testDataDict[v.id] = initData
		end
	end


end

function BattleTestCmd:catchCmd(txt)

	local s, e = string.find(txt, "战斗测试")
	local cmdList = Utils.split(txt, " ")
	if cmdList[1] ~= "战斗测试" then
		return false
	end

	local subCmd = cmdList[2]

	if subCmd == "剧情" then

		GuideLocalReader:getInstance():loadInProxy()
		
		BattleManager:getInstance():reqBattlePlot()

	elseif subCmd == "观战" then

		-- local reportData = BattleReportManager:getInstance():getReportData()

		-- BattleManager:getInstance():reqBattleObserve(reportData)

		BattleManager:getInstance():reqHandleRecord(1)
		TimerManager.addTimer(1000, function() 
			BattleManager:getInstance():reqHandleRecord(2) 
		end, false)

	elseif subCmd == "退出" then

		BattleManager:getInstance():reqBattleEnd()
	elseif subCmd == "副本" then

		local dunId = tonumber(cmdList[3])
		local dunDiff = tonumber(cmdList[4]) or 1
		if dunId ~= nil then
			BattleManager:getInstance():reqBattleStart(
                dunId, 
                dunDiff,
                TeamType.Normal
            )
		end

	elseif subCmd == "h" then
		if math.random(1, 2) == 1 then
			for i = 1, 10 do
				ArenaManager:getInstance():sendArenaResetReq(ArenaHelper.Reset.enemy_list)
			end
		else
			local time = 1
			TimerManager.addTimer(
				20, 
				function() 
					ArenaManager:getInstance():sendArenaResetReq(ArenaHelper.Reset.enemy_list) 
				    time = time + 1
				    if time > 10 then
				    	TimerManager.removeTimerWithToken("arena")
				    end
				end, 
				true,
				nil,
				"arena"
			)
		end
	else
		local id = tonumber(subCmd)
		if id ~= nil then

			CombatDataStorage:getInstance():parseConfigData()

			self:parseTestData()

			local testData = self._testDataDict[id]

			BattleManager:getInstance():reqBattleTest(testData)
		end
	end

	return true

end

