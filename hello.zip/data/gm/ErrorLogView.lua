--
-- Author: thisgf
-- Date: 2014-12-04 20:46:27
-- 错误记录界面

require "ChatHelper"

ErrorLogView = class("ErrorLogView", AbstView.create)

ErrorLogView._closeButton = nil
ErrorLogView._listView = nil

local _widgetPath = "ui/error_log/error_log_view_1.json"
local errorInstance = nil

function addLogInfo(info)
    errorInstance:addLog(info)
end

function ErrorLogView:ctor()

end

function ErrorLogView:init()

    local function onAddLogInfo(info)
        self:addLog(info)
    end

    Notifier.regist(CmdName.ADD_LOG_INFO, onAddLogInfo)
    Global:RegisterCmdWithParas("LUA_ERROR_EVENT", "addLogInfo(string)")

    self:_initUI()
end

function ErrorLogView:_initUI()

    self:_initWidget(_widgetPath)

    self._closeButton = self:_getWidget("button_close", ComponentType.BUTTON)
    self._closeButton:addTouchEventListener(function(sender, event)
        if event ~= TOUCH_EVENT_ENDED then
            return
        end

        self:removeFromParentAndCleanup(false)
     end)

    self._listView = self:_getWidget("listview_content", ComponentType.LIST_VIEW)

    -- for i = 1, 2 do
    --     self:addLog("Notifier.regist(CmdName.DUNGEON_UPDATE_REARDBOX,function() self:_updateDungeonBox() end)" .. i)
    -- end

end

function ErrorLogView:addLog(log)

    -- local label = Label:create()
    -- label:setFontSize(20)
    -- label:setText(log)
    -- label:setAnchorPoint(ccp(0, 0))
    -- label:setSize(CCSize(470, 25))
    -- self._listView:pushBackCustomItem(label)

    local rtf = ChatHelper.createRtf({{txt = log}}, 460, 100, ccp(0, 0))
    self._listView:pushBackCustomItem(rtf)

end

function ErrorLogView:create()
    local elv = ErrorLogView.new()
    errorInstance = elv
    elv:init()
    return elv
end
