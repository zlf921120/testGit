-- 调试管理器
-- Author: thisgf
-- Date: 2014-12-09 10:59:35
--

require "sp_pb"
require "proto_cmd_pb"
require "IManager"

GmManager = class("GmManager", IManager:create())

local _instance = nil

function GmManager:ctor()
end

function GmManager:getInstance()
    if not _instance then
        _instance = GmManager.new()
    end

    return _instance
end

--[[
    初始化
]]
function GmManager:init()
    Global:RegisterCmdWithParas("LUA_ERROR_EVENT", "onLuaErrorEvent(string)")
end

--[[
    添加错误信息
]]
function GmManager:addErrorInfo(value)
    onLuaErrorEvent(value)
end

function onLuaErrorEvent(info)

    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.sp_client_err_submit_rsp, "onClientErrSubmitRsp()")

    local submitReq = sp_pb.sp_client_err_submit_req()
    submitReq.err = info

    _instance:sendProto(submitReq)

end

function onClientErrSubmitRsp(proto)

    Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.sp_client_err_submit_rsp, "onClientErrSubmitRsp()")

end
