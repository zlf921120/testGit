--
-- Author: thisgf
-- Date: 2015-01-15 14:26:34
-- 资源争夺命令

require "ResContendManager"

ResContendTestCmd = class("ResContendTestCmd")

local _instance

function ResContendTestCmd:ctor()

end

function ResContendTestCmd:getInstance()
    if _instance == nil then
        _instance = ResContendTestCmd.new()
    end

    return _instance
end

function ResContendTestCmd:catchCmd(txt)
    local s, e = string.find(txt, "资源争夺")

    if s == nil then
        return false
    end

    ResContendManager:getInstance()

    local subCmd = string.sub(txt, e + 2)

    if subCmd == "描述" then
        WindowCtrl:getInstance():open(CmdName.RES_CONTEND_DESC_VIEW)
    elseif subCmd == "守卫" then
        WindowCtrl:getInstance():open(CmdName.RES_CONTEND_GUARD_VIEW, {dunId = 0, tag = 2})
    elseif subCmd == "记录" then
        WindowCtrl:getInstance():open(CmdName.RES_CONTEND_RECORD_VIEW)
    elseif subCmd == "占领" then
        WindowCtrl:getInstance():open(CmdName.RES_CONTEND_OT_VIEW)
    elseif subCmd == "展示" then
        local lastGd = ResContendManager:getInstance():getGuardData(20000)
        local gd = ResContendManager:getInstance():getGuardData(20000)
        gd.stars = 5

        WindowCtrl:getInstance():open(CmdName.RES_CONTEND_SG_VIEW, {gd = gd, lastGd = lastGd})
    elseif subCmd == "新" then
        WindowCtrl:getInstance():open(CmdName.RES_CONTEND_NG_VIEW, {20000, 20001})
    end

    return true

end
