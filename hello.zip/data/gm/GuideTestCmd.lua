--新手引导测试
GuideTestCmd = class("GuideTestCmd")
local _instance

function GuideTestCmd:ctor()

end

function GuideTestCmd:getInstance()
	if _instance == nil then
		_instance = GuideTestCmd.new()
	end

	return _instance
end

function GuideTestCmd:cleanGuide()

end

function GuideTestCmd:catchCmd(txt)

	local s, e = string.find(txt, "新手引导")
	if s ~= nil then

		local subCmd = string.sub(txt, e + 2)
--[[
		if subCmd == "剧情" then

			GuideLocalReader:getInstance():loadInProxy()
			
			BattleManager:getInstance():reqBattlePlot()

		else
		--]]
			local id = tonumber(subCmd)
			if id ~= nil then
				self:cleanGuide()
				
				GuideDataProxy:getInstance():delMainLocalCacheById(id)
				GuideEventTask:getInstance():forceExecuteMainTurtuial(id)
			end
		--end

		return true
	end

	return false
end

function GuideTestCmd:catchCmd2(txt)
	if txt == "解谜副本" then

		WindowCtrl:getInstance():open(CmdName.SecretView)

		return true
	end

	return false
end