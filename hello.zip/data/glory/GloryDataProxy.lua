
-- 荣耀 数据代理
GloryDataProxy = class("GloryDataProxy")
GloryDataProxy.stationVoList = {}
GloryDataProxy.glorySceneVo = nil
GloryDataProxy.myHeroVoList = {} --我方英雄血量列表
GloryDataProxy.rankVoList = {}
GloryDataProxy.isCanRefresh = 1

local __instance = nil
local _allowInstance = false

function GloryDataProxy:ctor()
    if not _allowInstance then
		error("GloryDataProxy is a singleton class")
	end
	self:init()
end

function GloryDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = GloryDataProxy.new()
		_allowInstance = false
	end

	return __instance
end

function GloryDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function GloryDataProxy:init()
	require "GloryVo"
end
---------------------------------------------
function GloryDataProxy:createGlorySceneVo()
	self.glorySceneVo = nil
	self.glorySceneVo = GlorySceneVo.new()
	return self.glorySceneVo
end

function GloryDataProxy:getGlorySceneVo()
	return self.glorySceneVo
end
-----------------------------------------
function GloryDataProxy:createGloryStationVo()
	return GloryStationVo.new()
end

function GloryDataProxy:getStationVoById(id)
	return self.stationVoList[ id ]
end

function GloryDataProxy:setStationVo(vo)
	self.stationVoList[ vo.id ] = vo
end

function GloryDataProxy:getStationVoList()
	return self.stationVoList
end
--------------------------------------------
function GloryDataProxy:createEnemyVo()
	return GloryEnemyVo.new()
end

function GloryDataProxy:createHeroVo()
	return GloryHeroVo.new()
end
--------------------------------------------
function GloryDataProxy:getMyHeroVoList()
	return self.myHeroVoList
end
---------------------------------------------
function GloryDataProxy:setRankVo(vo)
	vo.height = 114
	self.rankVoList[vo.rank] = vo
end

function GloryDataProxy:getRankVoById(id)
	return self.rankVoList[id]
end

function GloryDataProxy:getRankVoList()
	return self.rankVoList
end

--刷新重置次数
function GloryDataProxy:refreshGlory(num)
	if self.glorySceneVo ~= nil then
		local numLimit = VipDataProxy:getInstance():getPrivilegeValue(VipPrivilegeType.ResetGloryLimit) --vip 重置上限
		self.glorySceneVo.leftReset = numLimit - num --已重置次数
	end
end

function GloryDataProxy:setMyHeroVo(vo)
	-- local oldVo = self.myHeroVoList[ vo.id ]
	-- local oldMax = 0
	-- if oldVo then
	-- 	oldMax = oldVo.maxHp
	-- 	vo.maxHp = oldMax
	-- end
	-- print(" vo.hpMax ",vo.maxHp)
	self.myHeroVoList[ vo.id ] = vo
end

function GloryDataProxy:getMyHeroVoById(id)
	-- print("調用 getMyHeroVoById")
	local v = self.myHeroVoList[ id ]
	if v then
		if v.molecular == 0 then
			v.perc = 0
		else
			v.perc = v.molecular / v.denominator
		end
		local attrVo = HeroManager:getInstance():getHeroFinalAttr(id, TeamType.Glory)
		v.hp = attrVo[ AttrHelper.attr_flag.hp ] * v.perc
		v.maxHp = attrVo[ AttrHelper.attr_flag.hp ]
		-- print(" v.perc ",v.perc,v.id)
	end
	return v
end

function GloryDataProxy:getEnemyHeroVoById(stationId,id)
	local stationVo = self.stationVoList[ stationId ]
	local v = nil
	if stationVo then
		local heroVoDict = stationVo.enemyVo.heroVoDict
		v = heroVoDict[id]
		if v.molecular == 0 then
			v.perc = 0
		else
			v.perc = v.molecular / v.denominator
		end
		v.hp = v.maxHp * v.perc
		-- v.hpMax = attrVo[ AttrHelper.attr_flag.hp ]
		-- print(" v.perc ",v.perc,v.id,v.hp,v.maxHp)
	end
	return v
end
--------------------通过roleid获取相应敌人-----------------------
function GloryDataProxy:getEnemyInfo(role_id)
	local ret = nil
    for k,v in pairs(self.stationVoList) do

    	local stationVo = self.stationVoList[k]
    	if stationVo.battleVo.role_id.uin == role_id.uin and
    		stationVo.battleVo.role_id.channel_id == role_id.channel_id and
    		stationVo.battleVo.role_id.zone_id == role_id.zone_id then

    		ret = stationVo.battleVo
    		break
    	end
    end
    return ret
end
--------------------通过roleid获取相应敌人 的血量信息-----------------------
function GloryDataProxy:getEnemyHpInfo(role_id)
	-- print(" role_id ",role_id.uin)
	local ret = nil
    for k,v in pairs(self.stationVoList) do

    	local stationVo = self.stationVoList[k]
    	if stationVo.battleVo.role_id.uin == role_id.uin and
    		stationVo.battleVo.role_id.channel_id == role_id.channel_id and
    		stationVo.battleVo.role_id.zone_id == role_id.zone_id then
    		---------------计算 血值-----------------------------------
    		ret = stationVo.enemyVo
    		local heroVoDict = ret.heroVoDict
    		for k,v in pairs(heroVoDict) do
				if v.molecular == 0 then
					v.perc = 0
				else
					v.perc = v.molecular / v.denominator
				end
				v.hp = v.maxHp * v.perc
    		end
    		--------------------------------------------------
    		break
    	end
    end
    return ret
end

