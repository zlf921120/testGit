--星空神殿 排行
GloryRankPanel = class("GloryRankPanel",WindowBase)

function GloryRankPanel:create()
    local ret = GloryRankPanel.new()
    __instance = ret
    return ret   
end

function GloryRankPanel:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
    Notifier.removeByName(GloryEvent.CB_UPDATE_RANK)
end

function GloryRankPanel:init()
	require "GloryRankItem"

    self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/glory/GloryRankPanel.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("close_btn"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then 
			WindowCtrl:getInstance():close(self.name)
		end
    end)

    self.scrolRank = DisplayUtil.createAdaptScrollView(546,420,114,0,1)
    self.scrolRank:setPosition(ccp(215,69))
    self._widget:addChild(self.scrolRank,10)

    Notifier.regist(GloryEvent.CB_UPDATE_RANK,function()
        GloryRenderMgr:getInstance():renderRankListAdapt(self.scrolRank) 

        self.lastRankY = -1

        self.scrolRank:stopAllActions()
        self.scrolRank:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
            
                local viewY = self.scrolRank:getInnerContainer():getPositionY()
            	if self.lastRankY ~= viewY then
            		self.lastRankY = viewY
	                
	                local viewRect = CCRectMake(0,math.abs(viewY),546,420)
	               	GloryRenderMgr:getInstance():refreshRankList(viewRect,self.scrolRank)
               	end
            end),
            CCDelayTime:create(0.1))))
    end)

end

function GloryRankPanel:open()

	GloryNetTask:getInstance():requestGloryRank()
end