
--荣耀之路 事件

GloryEvent = 
{
	CB_UPDATE_SCENE = "glory_update_scene",

	CB_DISABLE_SCENE = "glory_disable_scene",

	CB_UPDATE_SCENE_AFTER_BATTLE = "glory_UPDATE_SCENE_AFTER_BATTLE",

	CB_UPDATE_RANK = "glory_update_rank",
}
