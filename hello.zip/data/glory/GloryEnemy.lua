--耀荣之路 敌人信息面板
GloryEnemy = class("GloryEnemy",WindowBase)
GloryEnemy.__index = GloryEnemy
GloryEnemy._widget = nil
GloryEnemy.uiLayer = nil

local __instance = nil
local _isCanFight = false

function GloryEnemy:create()
    local ret = GloryEnemy.new()
    __instance = ret
    return ret   
end

local function event_btn_close(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		WindowCtrl:getInstance():close(CmdName.Glory_Scene_Enemy)
	end
end

local function event_btn_start(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		local dp = GloryDataProxy:getInstance()
		local sceneVo = dp:getGlorySceneVo()
		if _isCanFight then
			if sceneVo.isFinish == 0 then  --未通关
				local id = pSender:getTag()
				local stationData = dp:getStationVoById(id)
				local battleVo = stationData.battleVo
			
				sceneVo.nowStation = id  --记录当前站点

				WindowCtrl:getInstance():open(CmdName.Team_View,{
			        team_type = TeamType.Glory,
			        id = stationData.gloryId,
			        subId = 1,
			        level = stationData.id,
			        roleId = battleVo.role_id
		        })

				WindowCtrl:getInstance():close(CmdName.Glory_Scene_Enemy)
			else --已经通关
				Alert:show("恭喜您本次挑戰星空神殿通關成功！點擊重置繼續挑戰")
			end
		else
			Alert:show("前一關卡通關後開啟本關卡")
		end
	end
end

function GloryEnemy:init()

	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/glory/glory.plist")

	self._widget = GUIReader:shareReader():widgetFromJsonFile("glory/GloryEnemy.ExportJson")
	self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    require "ItemIcon"
	local btnStart = self._widget:getChildByName("btn_start")
	btnStart:addTouchEventListener(event_btn_start)

	local p_icon2 = self._widget:getChildByName("p_icon2")
	local idx = 1
	for j=1,2 do
		for i=1,3 do
			local icon = GloryHeroIcon:create()
			icon:setScale(0.7)
			icon:setVisible(false)
			icon:setPosition(ccp( p_icon2:getPositionX() + (i-1) * 110 + (j-1) * 60, p_icon2:getPositionY() - (j-1) * 100))
			icon:setTag(100 + idx)
			self._widget:addChild(icon)
			idx = idx + 1
		end
	end
	
	local p_icon = self._widget:getChildByName("p_icon")
    self.headIcon = HeadIcon:create()
    self._widget:addChild(self.headIcon)
    self.headIcon:setScale(0.8)
    self.headIcon:setPosition(ccp(p_icon:getPosition()))

    local imgFc = self._widget:getChildByName("img_fig")
    self.labFc = CCLabelAtlas:create("123456","ui/digit/digit_4.png",24,32,48)
    self.labFc:setAnchorPoint(ccp(0,0.5))
    self.labFc:setPosition( ccp(imgFc:getPositionX() + 10, imgFc:getPositionY()) )
    self._widget:addNode(self.labFc,2)

    self.imgCanFight = self._widget:getChildByName("img_hasget")

    self:isShowBg(false)
end

function GloryEnemy:open()

	local id = self.params["id"]
	local dp = GloryDataProxy:getInstance()
	local stationVo = dp:getStationVoById(id)
	if stationVo.enemyVo == nil then --还没收到数据
		print("還沒收到數據")
		return
	end
	local tbl = stationVo.enemyVo.heroVoDict
	local index = 0

	local heros = stationVo.battleVo.battle_data

	for k,v in pairs(tbl) do
		index = index + 1
	 	local child = self._widget:getChildByTag(100 + index )
	 	v = dp:getEnemyHeroVoById(stationVo.id,k)
	 	child:setVisible(true)
	 	child:setHp(v.hp,v.maxHp)

	 	if heros[index] ~= nil then
            child:setVisible(true)
            child:setOtherHeroInfo(heros[index], stationVo.battleVo.sex)
        else
            child:setOtherHeroInfo(nil)
        end
	end

	self.labFc:setString(stationVo.fcMax)

	local lev = CharacterManager:getInstance():getTeamData():getLev()

	local p_1 = self._widget:getChildByName("p_1")
	for i=1,3 do
		local dropVo = stationVo.dropTbl[lev]
		if dropVo ~= nil then
			local icon = ItemIcon:create()
			icon:setTag(300 + i)
			icon:setScale(0.8)
			icon:setPosition(ccp(p_1:getPositionX() + (i-1) * 100, p_1:getPositionY() ))
			if i == 3 then
				icon:setBaseId( 50002 )
				icon:getClickImg():setTag(50002)
				icon:setItemNum(dropVo.coin)
			elseif i == 1 then
				icon:getClickImg():setTag(dropVo.baseId)
				icon:setBaseId( dropVo.baseId )
			elseif i == 2 then
				icon:setBaseId( 50005 )
				icon:getClickImg():setTag(50005)
				icon:setItemNum(dropVo.integral)
			end
			icon:setTouchEvent(function(pSender,eventType)
	            if eventType == ComConstTab.TouchEventType.began then
	            	require "ItemInfoPanel"

	                ItemInfoPanel:show(pSender:getTag())
	            elseif eventType == ComConstTab.TouchEventType.ended or
	                    eventType == ComConstTab.TouchEventType.canceled then
	                ItemInfoPanel:hide()
	            end
	        end)
			self._widget:addChild(icon,10)
		end
	end

	local btnStart = self._widget:getChildByName("btn_start")
	btnStart:setTag(id)
	local sceneVo = dp:getGlorySceneVo()
	-- local flag = id <= sceneVo.nowStation 
	if id < sceneVo.nowStation then
		btnStart:setBright(false)
    	btnStart:setTouchEnabled(false)
    	btnStart:setVisible(false)
    	self.imgCanFight:setVisible(true)
    elseif id == sceneVo.nowStation then
    	btnStart:setBright(true)
    	btnStart:setTouchEnabled(true)
    	btnStart:setVisible(true)
    	self.imgCanFight:setVisible(false)
    	_isCanFight = true
    elseif id > sceneVo.nowStation then
    	btnStart:setBright(true)
    	btnStart:setTouchEnabled(true)
    	btnStart:setVisible(true)
    	self.imgCanFight:setVisible(false)
    	_isCanFight = false
	end

	local battleVo = stationVo.battleVo
	local labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
	labName:setText(battleVo.role_name)

	local labLevel = tolua.cast(self._widget:getChildByName("lab_level"),"Label")
	labLevel:setText(battleVo.team_lev)

	local labOrganiz = tolua.cast(self._widget:getChildByName("lab_organiz"),"Label")
	local guildName = battleVo.guild_name
	if guildName == "" then
		guildName = "暫無公會"
	end
	labOrganiz:setText(guildName)

	self.headIcon:setFaceId(battleVo.face_id, battleVo.sex)

	GloryScene:getInstance():setVisibleUi(false)
end

function GloryEnemy:close()
	for i=1,6 do
	 	local child = self._widget:getChildByTag(100 + i)
	 	child:setVisible(false)
	end

	for i=1,6 do
		local child = self._widget:getChildByTag(300 + i)
		if child ~= nil then
			child:removeFromParentAndCleanup(true)
		end
	end

	GloryScene:getInstance():setVisibleUi(true)
end