--荣耀场景
GlorySceneVo = class("GlorySceneVo")
GlorySceneVo.hasBuyResetNum = 0 --已经购买过重置次数
GlorySceneVo.leftReset = 0 --剩余重置 数
GlorySceneVo.nowStation = 0 --当前站点
GlorySceneVo.isFinish = 0 --是否已通关

-- 荣耀 站点
GloryStationVo = class("GloryStationVo")
GloryStationVo.id = 0  --关卡数
GloryStationVo.enemyVo = nil   --玩家信息相关
GloryStationVo.battleVo = nil  --玩家战斗相关
GloryStationVo.gloryId = 0 --荣耀id
GloryStationVo.fcMax = 0 --总战力
GloryStationVo.dropTbl = nil --掉落物品表(按战队等级获取[物品,金币,积分])
GloryStationVo.dungeonStarNum = 0 --星级

--敌人
GloryEnemyVo = class("GloryEnemyVo")
GloryEnemyVo.heroVoDict = nil  --英雄列表

--英雄
GloryHeroVo = class("GloryHeroVo")
GloryHeroVo.id = 0 
GloryHeroVo.hp = 0 --血量
GloryHeroVo.maxHp = 0 --血量上限
GloryHeroVo.pos = 0 --上阵位置
GloryHeroVo.perc = 1 --血量百分比
GloryHeroVo.molecular = 0 --分子
GloryHeroVo.denominator = 0 --分母