
--星空神殿 场景
GloryScene = class("GloryScene",WindowBase)
GloryScene.__index = GloryScene
GloryScene._widget = nil
GloryScene.uiLayer = nil
GloryScene.is_bg_init = false

local __instance = nil
local scrolMap = nil

function GloryScene:create()
    local ret = GloryScene.new()
    __instance = ret
    return ret
end

local function event_btn_shop(sender,event)
    if event == ComConstTab.TouchEventType.ended then
        WindowCtrl:getInstance():open(CmdName.Shop_View ,{ area = BuyArea.Glory })
    end
end

local function event_btn_desc(sender,event)
	if event == ComConstTab.TouchEventType.ended then

		WindowCtrl:getInstance():open(CmdName.Comm_DescPanel,
           {title="星空神殿",content=GloryCfg.DescContent,innerHight=450,
           rewardArr = {{img="gold.png",lab="金幣"},
          				 {img="reward_necklace.png",lab="項鍊"},
                         {img="reward_soul.png",lab="靈魂石"}}})
    end
end

local function event_btn_reset(sender,event)
	if event == ComConstTab.TouchEventType.ended then
		local sceneVo = GloryDataProxy:getInstance():getGlorySceneVo()
		if sceneVo.leftReset <= 0 then
			Alert:show("星空神殿重置次數不足")
		else
			WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,{txt = "您確定要重新挑戰榮耀之路嗎?",
			okFunc = function()
				GloryNetTask:getInstance():requestGloryReset()
			end})
		end
	end
end

local _selectIdx = 0
local function event_btn_left(sender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		local ret = __instance.menu:turn(false)

		if ret then
			_selectIdx = _selectIdx + 1
			if _selectIdx > 12 then
				_selectIdx = 1
			end
			__instance.imgStationName:loadTexture(string.format("i18n_glory_sname%d.png",_selectIdx),UI_TEX_TYPE_PLIST)
	    	__instance.labStation:setText(string.format("%d/12",_selectIdx))
    	end
	end
end

local function event_btn_right(sender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		local ret = __instance.menu:turn(true)

		if ret then
			_selectIdx = _selectIdx - 1
			if _selectIdx < 1 then
				_selectIdx = 12
			end
			__instance.imgStationName:loadTexture(string.format("i18n_glory_sname%d.png",_selectIdx),UI_TEX_TYPE_PLIST)
	    	__instance.labStation:setText(string.format("%d/12",_selectIdx))
    	end
	end
end

local function event_btn_station(sender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		
		local dp = GloryDataProxy:getInstance()
		local stationVo = dp:getStationVoById(sender:getTag())
		if stationVo.enemyVo == nil then --还没收到数据
			return 
		else
			WindowCtrl:getInstance():open(CmdName.Glory_Scene_Enemy,{id = sender:getTag()})
		end
	end
end

function GloryScene:init()

	require "GloryNetTask"
	require "GloryEvent"
	require "GloryRenderMgr"
	require "GloryHeroIcon"
	require "GloryEnemy"
	require "GloryLocalReader"
	require "GloryCfg"
	require "ShopCfg"
	-- --加载纹理
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/glory/glory.plist")
	GloryLocalReader:getInstance():loadInProxy()
	ComResMgr:getInstance():loadOtherRes()
	ComResMgr:getInstance():loadResByName("ui/arena/arena_bg.plist","ui/arena/arena_bg.pvr.ccz")

	self._widget = GUIReader:shareReader():widgetFromJsonFile("glory/GlorySkyScene.ExportJson")
	self._widget:setTouchEnabled(true)
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.imgBg = ImageView:create()
 	self.imgBg:setPosition(ccp(480,320))
 	
	self._widget:getChildByName("panel_bg"):addChild(self.imgBg)

 	local panelUi = tolua.cast(self._widget:getChildByName("panel_ui"),"Layout")

 	local btnShop = tolua.cast(panelUi:getChildByName("btn_shop"),"Button")
 	btnShop:addTouchEventListener(event_btn_shop)

 	local btnDesc = tolua.cast(panelUi:getChildByName("btn_desc"),"Button")
 	btnDesc:addTouchEventListener(event_btn_desc)

 	local btnReset = tolua.cast(panelUi:getChildByName("btn_reset"),"Button")
 	btnReset:addTouchEventListener(event_btn_reset)

 	self.btnRank = tolua.cast(panelUi:getChildByName("btn_rank"),"Button")
 	self.btnRank:addTouchEventListener(function(sender,event)
		if event == ComConstTab.TouchEventType.ended then

			WindowCtrl:getInstance():open(CmdName.Glory_RankPanel)
		end
 	end)

 	-- local btnLeft = tolua.cast(panelUi:getChildByName("btn_left"),"Button")
 	-- btnLeft:setTouchEnabled(false)
 	-- btnLeft:setVisible(false)

 	-- local btnRight = tolua.cast(panelUi:getChildByName("btn_right"),"Button")
 	-- btnRight:setTouchEnabled(false)
 	-- btnRight:setVisible(false)

 	Notifier.regist(GloryEvent.CB_UPDATE_SCENE,function() self:update() end)
 	Notifier.regist(GloryEvent.CB_UPDATE_SCENE_AFTER_BATTLE,function() self:updateAfterBattle() end)

 	-- local scaleArr = {0.80,0.67,0.58,0.55,0.58,0.67,0.80,0.92,1.01,1.05,1.01,0.92}
 	local scaleArr = {0.80,0.92,1.01,1.05,1.01,0.92,0.80,0.65,0.58,0.55,0.58,0.65}
 	-- local localZArr = {7,7,9,7,8,6,8,10,12,13,12,11}
 	local localZArr = {7,11,12,13,12,10,8,6,8,7,9,7}

 	self.imgTbl = {}
	for i=1,12 do
	 	local img = ImageView:create()
	 	img:loadTexture(string.format("glory_station%d.png",i),UI_TEX_TYPE_PLIST)
	 	-- img:addTouchEventListener(event_btn_station)
	 	img:setAnchorPoint(ccp(0.5,0))
	 	img:setTouchEnabled(false)
	 	img:setScale(scaleArr[i])
	 	local p = self._widget:getChildByName(string.format("p_%d",i))
	 	img:setPosition(ccp( p:getPositionX(),p:getPositionY() + 10))
	 	img:setTag(i) --记录站点下标

	 	-- self:makeStar(img)
	 	-- img:addChild(ImageView:create())
	 	-- 

	 	self._widget:addChild(img)

	 	table.insert(self.imgTbl,img)
	end

 	require "AnnularMenu"
 	-- local posArr = {ccp(55,134),ccp(207,102),ccp(415,90 + 30),ccp(622 - 10,102),ccp(774 - 30,135),ccp(830,180),
		-- 			ccp(774 - 30,225),ccp(622 - 30,257),ccp(415 - 10,270),ccp(207 + 30,257),ccp(55 + 30,224),ccp(0,179)}

	-- local scaleArr = {0.92,1.01,1.05,1.01,0.92,0.79,0.67,0.58,0.55,0.58,0.67,0.80}


 	self.menu = AnnularMenu:create(self.imgTbl,CCSize(830,360))
 	self._widget:addChild(self.menu)

 	self.labStation = tolua.cast(self._widget:getChildByName("lab_nowstation"),"Label")

 	self.imgStationName = ImageView:create()
 	self.imgStationName:setPosition(ccp(self.labStation:getPositionX(), self.labStation:getPositionY() + 30 ))
 	self._widget:addChild(self.imgStationName,20)

 	CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo("ui/effects_ui/rongyaozhilu_weixuanzhong/rongyaozhilu_weixuanzhong.ExportJson")
 	CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo("ui/effects_ui/rongyaozhilu_xuanzhong/rongyaozhilu_xuanzhong.ExportJson")

 	self._armLightTbl = {}
 	for i=1,12 do
 		local armLight = nil
 		if i == 4 then
 			armLight = CCArmature:create("rongyaozhilu_xuanzhong")
 		else
 			armLight = CCArmature:create("rongyaozhilu_weixuanzhong")
 		end
		armLight:setScale(scaleArr[i])
		armLight:setPosition(ccp( self._widget:getChildByName(string.format("p_%d",i)):getPosition()))
		armLight:getAnimation():play("Animation1",0,-1,1)
		self._widget:addNode(armLight,localZArr[i])
		table.insert(self._armLightTbl,armLight)
 	end

 	panelUi:setTouchEnabled(true)
 	panelUi:addTouchEventListener(function(pSender,eventType)
 		if eventType == ComConstTab.TouchEventType.began then
 			-- print(" =========  ",pSender:getTouchStartPos().x,pSender:getTouchStartPos().y)
 			self.menu:handleTouchBegan(pSender:getTouchStartPos().x,pSender:getTouchStartPos().y)
 		elseif eventType == ComConstTab.TouchEventType.moved then
 			self.menu:handleTouchMoved(pSender:getTouchMovePos().x,pSender:getTouchMovePos().y,function(dire)
 				self:makeTurn(dire)
 			end)
 		elseif eventType == ComConstTab.TouchEventType.ended then
 			self.menu:handleTouchEnded(pSender:getTouchEndPos().x,pSender:getTouchEndPos().y,function(id)
 				WindowCtrl:getInstance():open(CmdName.Glory_Scene_Enemy,{id = id})
 			end)
 		end
 	end)

 	--锁层
    self.panelLock = tolua.cast(self.uiLayer:getWidgetByName("panel_lock"),"Layout")
    self.panelLock:setTouchEnabled(true)

 	Notifier.regist(CmdName.BATTLE_RSP_END,GloryNetTask:getInstance().gloryHandleBattleEnd) --战斗结束
end

function GloryScene:makeStar(contaniner)

	local posTbl = {ccp(-20,20),ccp(0,20),ccp(20,20)}
	for i=1,3 do
		local img = ImageView:create()
		img:setVisible(false)
		img:setName(string.format("img_star%d",i))
		img:setScale(0.4)
		img:loadTexture("golden_star.png",UI_TEX_TYPE_PLIST)
		img:setPosition(posTbl[i])
		contaniner:addChild(img)
	end
end

-- function GloryScene:updateStarByIdx(target,idx)
-- 	local stationVo = GloryDataProxy:getInstance():getStationVoById(idx)
-- 	local posTbl = {ccp(-20,20),ccp(0,20),ccp(20,20)}

-- 	local score =  stationVo.dungeonStarNum
-- 	for i=1,3 do
-- 		local imgStar = target:getChildByName(string.format("img_star%d",i))
-- 		imgStar:setVisible(i <= score)
-- 	end
-- 	for i=1,score do
-- 		local imgStar = target:getChildByName(string.format("img_star%d",i))
-- 		imgStar:setPositionX( i/(score+1) * 40 )
-- 	end
-- end

-- function GloryScene:updateAllStar(menu)
-- 	local voList = GloryDataProxy:getInstance():getStationVoList()
-- 	for k,v in pairs(voList) do
-- 		self:updateStarByIdx( menu:getItem(v.id) , v.id ) --更新星级
-- 	end
-- end

function GloryScene:makeTurn(dire)

	if dire == true then -- 向右转
		_selectIdx = _selectIdx - 1
		if _selectIdx < 1 then
			_selectIdx = 12
		end
			__instance.imgStationName:loadTexture(string.format("i18n_glory_sname%d.png",_selectIdx),UI_TEX_TYPE_PLIST)
	    	__instance.labStation:setText(string.format("%d/12",_selectIdx))
	else
			_selectIdx = _selectIdx + 1
		if _selectIdx > 12 then
			_selectIdx = 1
		end
			__instance.imgStationName:loadTexture(string.format("i18n_glory_sname%d.png",_selectIdx),UI_TEX_TYPE_PLIST)
	    	__instance.labStation:setText(string.format("%d/12",_selectIdx))
	end
end

function GloryScene:update()
	
	self.panelLock:setTouchEnabled(false)

	local imgArrow = self._widget:getChildByName("img_arrow")
	imgArrow:stopAllActions()
	imgArrow:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
		CCMoveBy:create(0.8, ccp(0,-10)),
		CCMoveBy:create(0.8, ccp(0, 10)))))

	local panelUi = tolua.cast(self._widget:getChildByName("panel_ui"),"Layout")

	local sceneVo = GloryDataProxy:getInstance():getGlorySceneVo()
    local labLeft = tolua.cast(panelUi:getChildByName("lab_left"),"Label")
    labLeft:setText(string.format("剩餘重置 %d 次",sceneVo.leftReset))

	_selectIdx = sceneVo.nowStation

    -- local curImg = self.menu:getChildByTag( sceneVo.nowStation )
    local curImg = self._widget:getChildByTag( sceneVo.nowStation )
    self.menu:jumpTo(curImg,4)
    self.menu:updateClickAble(sceneVo.nowStation)
    -- self:updateAllStar(self.menu)
    self.imgStationName:loadTexture(string.format("i18n_glory_sname%d.png",sceneVo.nowStation),UI_TEX_TYPE_PLIST)
    self.labStation:setText(string.format("%d/12",sceneVo.nowStation))
end

function GloryScene:updateAfterBattle()

	local imgArrow = self._widget:getChildByName("img_arrow")
	imgArrow:stopAllActions()
	imgArrow:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
		CCMoveBy:create(0.8, ccp(0,-10)),
		CCMoveBy:create(0.8, ccp(0, 10)))))

	self._widget:runAction(CCSequence:createWithTwoActions(
		CCDelayTime:create(0.3),
		CCCallFunc:create(function()

			local panelUi = tolua.cast(self._widget:getChildByName("panel_ui"),"Layout")
			local sceneVo = GloryDataProxy:getInstance():getGlorySceneVo()
			local lastSelectIdx = _selectIdx
			if sceneVo.nowStation > lastSelectIdx then
				self.menu:turn(false)
				self.menu:updateClickAble(sceneVo.nowStation)
				-- self:updateStarByIdx( self.menu:getItem(lastSelectIdx) , lastSelectIdx ) --更新星级

				_selectIdx = _selectIdx + 1
				if _selectIdx > 12 then
					_selectIdx = 1
				end
				__instance.imgStationName:loadTexture(string.format("i18n_glory_sname%d.png",_selectIdx),UI_TEX_TYPE_PLIST)
		    	__instance.labStation:setText(string.format("%d/12",_selectIdx))
			end

		end)))
end

function GloryScene:setVisibleUi(value)
	local panelUi = tolua.cast(self._widget:getChildByName("panel_ui"),"Layout")
	panelUi:setVisible(value)
end

function GloryScene:getInstance()
	return __instance
end

function GloryScene:open()

	--Notifier.regist(CmdName.BATTLE_RSP_END,GloryNetTask:getInstance().gloryHandleBattleEnd) --战斗结束

 	if self.imgBg and self.is_bg_init == false then

 		-- local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
 		-- local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()

 		self.is_bg_init = true
		self.imgBg:loadTexture("ui/glory/glory_bg.jpg")

	 	-- print(" 1/DisplayUtil.min_scale*globa_scalx ",self.imgBg:getScaleX())
	 	-- print(" 1/DisplayUtil.min_scale*globa_scaly ",self.imgBg:getScaleY())
	 	-- print(" DisplayUtil.max_scale ",DisplayUtil.max_scale)
		 self.imgBg:setScaleX(1/DisplayUtil.min_scale*DisplayUtil.max_scale)
		 self.imgBg:setScaleY(1/DisplayUtil.min_scale*DisplayUtil.max_scale)
	end

	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/glory/glory.plist")
	local dp = GloryDataProxy:getInstance()
    if dp.isCanRefresh == 1 then
	   GloryNetTask:getInstance():requestGlorySceneInfo()
	else
		self:update()
    end
end

function GloryScene:close()
	--Notifier.remove(CmdName.BATTLE_RSP_END,GloryNetTask:getInstance().gloryHandleBattleEnd)
	self.menu:clean()

	CCTextureCache:sharedTextureCache():removeTextureForKey("ui/glory/glory_bg.jpg")
	-- CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile("ui/glory/glory.plist")
end