
----------------------------------------------------------------------------
-- 荣耀 本地xls数据读取类
GloryLocalReader = class("GloryLocalReader")

local __instance = nil
local _allowInstance = false
local _hasLoad = false

function GloryLocalReader:ctor()
    if not _allowInstance then
		error("GloryLocalReader is a singleton class")
	end
	self:init()
end

function GloryLocalReader:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = GloryLocalReader.new()
		_allowInstance = false
	end

	return __instance
end

function GloryLocalReader:init()
	require "GloryDataProxy"
	require "fnt_glory_data_pb"
	--print("-------------GloryLocalReader init finish--------------")
end

function GloryLocalReader:loadInProxy()

	if _hasLoad then return end--只加载一次
	_hasLoad = true

	local dp = GloryDataProxy:getInstance()
    local pbdata = FileUtils.readConfigFile("fnt_glory_data.dat")
    
    local msg = fnt_glory_data_pb.fnt_glory_data()
    msg:ParseFromString(pbdata)
  
	local item = nil
	------------站点------------------------
    local matchUnit = msg.matching_rules_rows
    for i, v in pairs(matchUnit) do    	
        if v.glory_id ~= nil then
        	local stationVo = dp:createGloryStationVo()
        	stationVo.id = v.customs_pass
        	stationVo.gloryId = v.glory_id
        	-- stationVo.fcMin = v.fc_float_min
        	-- stationVo.fcMax = v.fc_float_max
        	-- stationVo.dropTbl = loadstring("return {" .. v.reward_id .. "}")()
        	-- table.insert(stationVo.dropTbl,50002)
         --    table.insert(stationVo.dropTbl,50005)
            stationVo.dropTbl = {}

        	-- stationVo.coin = v.coin
         --    stationVo.integral = v.integral
        	dp:setStationVo(stationVo)
        end
    end
    ------------掉落-------------------------------
    local dropUnit = msg.glory_reward_rows
    for i, v in pairs(dropUnit) do 
        if v.id ~= nil then
            local stationVo = dp:getStationVoById(v.id)
            stationVo.dropTbl[v.lev] = { baseId = v.base_id , coin = v.coin, integral = v.integral}
        end
    end
end
