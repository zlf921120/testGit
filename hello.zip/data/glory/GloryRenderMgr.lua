-- 荣耀 渲染器
GloryRenderMgr = class("GloryRenderMgr")

local __instance = nil
local _allowInstance = false

function GloryRenderMgr:ctor()
    if not _allowInstance then
		error("GloryRenderMgr is a singleton class")
	end
	self:init()
end

function GloryRenderMgr:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = GloryRenderMgr.new()
		_allowInstance = false
	end

	return __instance
end

function GloryRenderMgr:destoryInstance()
	self.dic:release()
	_allowInstance = false
	__instance = nil
end

function GloryRenderMgr:init()

	self.dic = CCDictionary:create() --缓存
	self.dic:retain()
	
end

local function _sortRankFunc(voList)
	local tmpList = {}
	for id,itemVo in pairs(voList) do
		table.insert(tmpList,itemVo)
	end
	--排序等级
	table.sort(tmpList,function(a,b)
		return a.rank < b.rank
	end)
	return tmpList
end

--渲染 日程 表 
function GloryRenderMgr:renderRankListAdapt(scrol)
	local voList = GloryDataProxy:getInstance():getRankVoList()
	local tmpList = _sortRankFunc(voList)
	scrol:setInnerHeightWithList(tmpList) --刷新高度
	if #tmpList == 0 then return end

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + v.height
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,5 do
		local key = string.format("rank_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GloryRankItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshRankList(viewRect,scrol)
end
function GloryRenderMgr:refreshRankList(rect,scrol)
	
	local voList = GloryDataProxy:getInstance():getRankVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,5,"rank_%d",_sortRankFunc(voList),scrol,539,114,rect)
end