--星空神殿 排名项 信息
GloryRankItemView = class("GloryRankItemView", WindowBase)
GloryRankItemView.role_info = nil
GloryRankItemView.is_dispose = true

function GloryRankItemView:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
end

function GloryRankItemView:init()
	self.uiLayer = TouchGroup:create() 
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/glory/GloryRankItemView.ExportJson")
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.head_icon = HeadIcon:create()
    self.head_icon:setPosition(ccp(190,441))
    self._widget:addChild(self.head_icon,10)

    local panel = tolua.cast(self.uiLayer:getWidgetByName("Panel_326"), "Layout")
    panel:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
    		WindowCtrl:getInstance():close(self.name)
        end
    end)

    self.labRecord = tolua.cast(self.uiLayer:getWidgetByName("lab_record"),"Label")

    self.rank_num_img = LabelAtlas:create()
    self.rank_num_img:setProperty(0000,"ui/digit/digit_4.png",24,32,"0")
    self.uiLayer:addWidget(self.rank_num_img)
    self.rank_num_img:setPosition(ccp(650,405))

    self.scrollView = DisplayUtil.createAdaptScrollView(700,108*2,108,0,6)
    self.scrollView:setPosition(ccp(132,74))
    self._widget:addChild(self.scrollView,3)
end

function GloryRankItemView:create()
    local enemy_info_view = GloryRankItemView.new()
    return enemy_info_view
end

function GloryRankItemView:open()
    self.role_info = self.params.role_info

    self:changeContent()
end

function GloryRankItemView:close()
    self.params = nil
    self.role_info = nil
end

--改变显示内容
function GloryRankItemView:changeContent()
    self.head_icon:setFaceId(self.role_info.face_id, self.role_info.sex)
    
    local name_label = tolua.cast(self.uiLayer:getWidgetByName("name_label"), "Label") 
    name_label:setText(self.role_info.role_name)

    local lev_label = tolua.cast(self.uiLayer:getWidgetByName("lev_label"), "Label") 
    lev_label:setText(string.format("Lv.%d",self.role_info.team_lev))

    local rank_txt_label = tolua.cast(self.uiLayer:getWidgetByName("Label_333_Copy0"), "Label") 
    if self.view_type == ArenaHelper.enemyInfoView.Combat_Record  then
        self.rank_num_img:setVisible(false)
        rank_txt_label:setVisible(false)
    else
        rank_txt_label:setVisible(true)
        self.rank_num_img:setVisible(true)
        self.rank_num_img:setStringValue(self.role_info.rank)
    end

    local fc_label = tolua.cast(self.uiLayer:getWidgetByName("fc_label"), "Label") 
    fc_label:setText(self.role_info.fight_capacity)

    self.scrollView:setScrollHeight( math.max(2, #self.role_info.heros) )

    local function createPosArr( len )
        local col = 6
        local row = math.max(2,math.ceil(len / col))
        local ret = {}

        local baseX = 60
        local baseY = 60

        local idx = 0
        for i=0,row - 1 do

            for j=0,col - 1 do
                idx = idx + 1

                local height = 100
                local width = 113

                table.insert(ret, { x = baseX + j * width , y = baseY + (row - i - 1) * height })
            end
        end
        return ret
    end

    local pos = createPosArr( #self.role_info.heros )

    local idx = 0
    local function step_create()
        idx = idx + 1
        local heroVo = self.role_info.heros[idx]
        if heroVo ~= nil then
            local hero_icon = HeroIcon:create()
            hero_icon:setScale(0.8)
            hero_icon:setPosition(ccp(pos[idx].x,pos[idx].y))
            hero_icon:setOtherHeroInfo(heroVo, self.role_info.sex)
            self.scrollView:getInnerContainer():addChild(hero_icon)
        else
            self.scrollView:stopAllActions()
        end
    end

    self.scrollView:stopAllActions()
    self.scrollView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
        CCCallFunc:create(step_create),
        CCDelayTime:create(0.05))))

    self.labRecord:setText(GloryCfg.ConstellName[ self.role_info.win_num ])
end