--荣耀之路 英雄头像

require "HeroIcon"

GloryHeroIcon = class("GloryHeroIcon", function() return HeroIcon:create() end)
GloryHeroIcon.loadingBar = nil
GloryHeroIcon.hp = -1
GloryHeroIcon.max = 0
GloryHeroIcon.labTip = nil

function GloryHeroIcon:create()
	local icon = GloryHeroIcon.new()
	icon:init()
	return icon
end

function GloryHeroIcon:init()
	
	self.loadingBar = LoadingBar:create()
    self.loadingBar:loadTexture("bui_hp_red.png",UI_TEX_TYPE_PLIST)
    self.loadingBar:setDirection(LoadingBarTypeLeft)
    self.loadingBar:setPosition(ccp(0,-60))
    self.loadingBar:setScaleY(0.85)
    self.loadingBar:setScaleX(1.1)
    self.loadingBar:setVisible(false)

    self.loadingBarBg = ImageView:create()
    self.loadingBarBg:loadTexture("bui_role_hp_slot.png",UI_TEX_TYPE_PLIST)
    self.loadingBarBg:setPosition(ccp(self.loadingBar:getPosition()))
    self.loadingBarBg:setVisible(false)
    self:addChild(self.loadingBarBg)
    self:addChild(self.loadingBar)

    self.labTip = Label:create()
    self.labTip:setText("已陣亡")
    self.labTip:setVisible(false)
    self.labTip:setColor(ccc3(0xbb, 0xe6, 0xd8))
    self.labTip:setFontSize(26)
    self.labTip:setPosition(ccp(0,10))
    self:addChild(self.labTip)

end

function GloryHeroIcon:setMystery(value)
    if value then
        self.icon_border:loadTexture("hero_quality_border_1.png",UI_TEX_TYPE_PLIST)
        self.icon_img:setVisible(false)
        self.star_layer:setVisible(false)
    else
        self.icon_img:setVisible(true)
        self.star_layer:setVisible(true)
    end
end

function GloryHeroIcon:setHp(value,max)
    self.loadingBar:setVisible(true)
    self.loadingBarBg:setVisible(true)
    
    if self.hp == value then return end
	self.hp = value
    if value / max < 0.3 then
        self.loadingBar:loadTexture("bui_hp_red.png",UI_TEX_TYPE_PLIST)
    else
        self.loadingBar:loadTexture("bui_hp_green.png",UI_TEX_TYPE_PLIST) 
    end
	self.loadingBar:setPercent(value / max * 100)
	local flag = self.hp ~= 0
	self:setIsActive(flag)
	self.labTip:setVisible(not flag)
end

function GloryHeroIcon:setHpVisible(isVis)
    self.loadingBar:setVisible(isVis)
    self.loadingBarBg:setVisible(isVis)
end
