
--荣耀之路 网络助手
GloryNetTask = class("GloryNetTask")
-- GloryNetTask.tmpUnFightHeroList = nil

local __instance = nil
local _allowInstance = false

function GloryNetTask:ctor()
    if not _allowInstance then
		error("GloryNetTask is a singleton class")
	end
	self:init()
end

function GloryNetTask:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = GloryNetTask.new()
		_allowInstance = false
	end

	return __instance
end

function GloryNetTask:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function GloryNetTask:init()
	require "glory_pb"
	require "GloryDataProxy"
	require "OtherRoleInfo"
	--注册网络事件
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.glory_info_rsp,"handleGlorySceneInfo()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.glory_rank_info_rsp,"handleGloryRank()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.glory_resetting_rsp,"handleGloryReset()")

	--有英雄激活 需要刷新
	Notifier.regist(CmdName.UpdateHeroListView,function(heroId)
		local dp = GloryDataProxy:getInstance()
		dp.isCanRefresh = 1
	end)

	Notifier.regist(CmdName.VIP_INFO_UPDATE,function(params)
		local sceneVo = GloryDataProxy:getInstance():getGlorySceneVo()
		local numLimit = VipDataProxy:getInstance():getPrivilegeValue(VipPrivilegeType.ResetGloryLimit) --vip 重置上限
		local lastLimit = VipDataProxy:getInstance():getPrivilegeValueByLev(VipPrivilegeType.ResetGloryLimit,params.oldVipLev) --上级别 vip 重置上限
		sceneVo.leftReset = math.min(sceneVo.leftReset + math.abs(numLimit - lastLimit), numLimit) --增加vip补偿次数
		Notifier.dispatchCmd(GloryEvent.CB_UPDATE_SCENE)
	end)
end

--请求 荣耀之路 场景信息
function GloryNetTask:requestGlorySceneInfo()
	print("-----------requestGlorySceneInfo-------------")
	local glory_info_req = glory_pb.glory_info_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.glory_info_req,glory_info_req)
end

--响应 荣耀之路 场景信息
function handleGlorySceneInfo(pkg)
	local glory_info_rsp = glory_pb.glory_info_rsp()
	glory_info_rsp:ParseFromString(pkg)

	print("-----------handleGlorySceneInfo-------------",glory_info_rsp.ret)
	if glory_info_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GloryDataProxy:getInstance()
		dp.isCanRefresh = 0
		
		local sceneVo = dp:createGlorySceneVo()
		local numLimit = VipDataProxy:getInstance():getPrivilegeValue(VipPrivilegeType.ResetGloryLimit) --vip 重置上限
		sceneVo.leftReset = numLimit - glory_info_rsp.num --num是已重置次数
		-- print("numLimit , glory_info_rsp.num ",numLimit , glory_info_rsp.num)
		sceneVo.nowStation = glory_info_rsp.now_pass
		sceneVo.isFinish = glory_info_rsp.clearance
		if sceneVo.isFinish == 1 then 
			sceneVo.nowStation = 12
		end

		-- print("當前 sceneVo.nowStation ",sceneVo.nowStation,#glory_info_rsp.targets)
		local targets = glory_info_rsp.targets 
		for i=1,12 do
			-----------------------------------------------------
			local server_role_info = targets[i].targets
			local client_role_info = OtherRoleInfo:create()
	        client_role_info:setBaseInfo(server_role_info.id, server_role_info.name, 
	                                server_role_info.team_lev,server_role_info.fc, 
	                                server_role_info.face_id, server_role_info.rank, 
	                                server_role_info.win_num,server_role_info.guild_name,
	                                server_role_info.sex)
	        client_role_info:setHeros(server_role_info.heroes)
	        ---------------------------------------------
	        local enemyVo = dp:createEnemyVo()
			enemyVo.heroVoDict = {}

			local other_hp = targets[i].other_hp
			-- print(" #other_hp ",#other_hp)
			for k=1,#other_hp do
				local heroVo = dp:createHeroVo()
				heroVo.id = other_hp[k].hero_id
				heroVo.maxHp = other_hp[k].denominator

				if i < sceneVo.nowStation then
					-- heroVo.hp = 0
					heroVo.molecular = 0
					heroVo.denominator = 0
				else
					-- heroVo.hp = other_hp[k].hp
					heroVo.molecular = other_hp[k].molecular
					heroVo.denominator = other_hp[k].denominator
				end
				-- print(" i 敵人 heroVo.id ",i,heroVo.id,heroVo.molecular,heroVo.denominator)
				enemyVo.heroVoDict[heroVo.id] = heroVo
			end
			-------------汇总-----------------------------------
			-- print(" targets[i].pass ",targets[i].pass)
			local stationVo = dp:getStationVoById(targets[i].pass)
			stationVo.enemyVo = enemyVo
			stationVo.battleVo = client_role_info
			stationVo.fcMax = server_role_info.fc
		end
		-----------------------------------------------------
		local hero_id = glory_info_rsp.hero_id
		local myHp = glory_info_rsp.my_hp

		for j=1,#hero_id do
			local heroVo = dp:createHeroVo()
			heroVo.id = hero_id[j].id
			heroVo.molecular = 1
			heroVo.denominator = 1

			for i=1,#myHp do --扣血
				if myHp[i].hero_id == heroVo.id then

					if myHp[i].molecular == 0 then --死了的英雄
						heroVo.molecular = 0
						heroVo.denominator = 0
					else
						heroVo.molecular = myHp[i].molecular
						heroVo.denominator = myHp[i].denominator
					end
				end
			end
			dp:setMyHeroVo(heroVo)
		end

		ComSender:getInstance():dealExtInfo(glory_info_rsp.ext)

		Notifier.dispatchCmd(GloryEvent.CB_UPDATE_SCENE)
	else
		Alert:show(Helper.getErrStr(glory_info_rsp.ret))
	end
end

--请求 重置
function GloryNetTask:requestGloryReset()

	print("-----------requestGloryReset-------------")
	local glory_resetting_req = glory_pb.glory_resetting_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.glory_resetting_req,glory_resetting_req)
end

--响应 重置
function handleGloryReset(pkg)

	local glory_resetting_rsp = glory_pb.glory_resetting_rsp()
	glory_resetting_rsp:ParseFromString(pkg)

	print("-----------handleGloryReset-------------",glory_resetting_rsp.ret)
	if glory_resetting_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GloryDataProxy:getInstance()

		local sceneVo = dp:createGlorySceneVo()
		local numLimit = VipDataProxy:getInstance():getPrivilegeValue(VipPrivilegeType.ResetGloryLimit) --vip 重置上限
		sceneVo.leftReset = numLimit - glory_resetting_rsp.num --已重置次数
		-- print(" numLimit - glory_resetting_rsp.num ",numLimit , glory_resetting_rsp.num)
		sceneVo.nowStation = glory_resetting_rsp.now_pass

		local targets = glory_resetting_rsp.targets 
		for i=1,#targets do
			-----------------------------------------------------
			local server_role_info = targets[i].targets
			local client_role_info = OtherRoleInfo:create()

	        client_role_info:setBaseInfo(server_role_info.id, server_role_info.name, 
	                                server_role_info.team_lev,server_role_info.fc, 
	                                server_role_info.face_id, server_role_info.rank, 
	                                server_role_info.win_num,server_role_info.guild_name,
	                                server_role_info.sex)

	        client_role_info:setHeros(server_role_info.heroes)
	        ---------------------------------------------
	        local enemyVo = dp:createEnemyVo()
			enemyVo.heroVoDict = {}

			local other_hp = targets[i].other_hp
			for k=1,#other_hp do
				local heroVo = dp:createHeroVo()
				heroVo.id = other_hp[k].hero_id
				heroVo.molecular = other_hp[k].molecular
				heroVo.denominator = other_hp[k].denominator
				-- heroVo.hp = other_hp[k].hp
				heroVo.maxHp = other_hp[k].denominator

				enemyVo.heroVoDict[heroVo.id] = heroVo
			end

			-------------汇总-----------------------------------
			local stationVo = dp:getStationVoById(targets[i].pass)
			stationVo.enemyVo = enemyVo
			stationVo.battleVo = client_role_info
			stationVo.fcMax = server_role_info.fc
		end

		-----------------------------------------------------
		local voList = dp:getMyHeroVoList()
		for k,v in pairs(voList) do
			local heroVo = voList[k]
			-- heroVo.hp = heroVo.maxHp
			-- heroVo.perc = 1
			heroVo.molecular = 1
			heroVo.denominator = 1
			-- print(" heroVo.hp  ",heroVo.id,heroVo.hp,heroVo.perc,heroVo.maxHp)
		end
		-----------------------------------------------------

		ComSender:getInstance():dealExtInfo(glory_resetting_rsp.ext)

		Notifier.dispatchCmd(GloryEvent.CB_UPDATE_SCENE)

		Alert:show("重置榮耀之路成功")
	else
		Alert:show(Helper.getErrStr(glory_resetting_rsp.ret))
	end
end

--响应 更新当前 荣耀信息
function GloryNetTask:handleGloryInfoBySvr(myHp,targets)

	-- local glory_combat_over_rsp = glory_pb.glory_combat_over_rsp()
	-- glory_combat_over_rsp:ParseFromString(pkg)

	print("-----------handleGloryInfo-------------")
	-- if glory_combat_over_rsp.ret == error_code_pb.msg_ret.success then
		
		-- local myHp = glory_combat_over_rsp.my_hp
		local dp = GloryDataProxy:getInstance()
		local voList = dp:getMyHeroVoList()

		for j=1,#myHp do
			-- local heroVo = dp:getMyHeroVoById(myHp[j].id)
			local heroVo = voList[ myHp[j].hero_id ]
			-- print(" heroVo.maxHp ",heroVo.maxHp)
			-- heroVo.hp = myHp[j].mrole_hp
			heroVo.molecular = myHp[j].molecular
			heroVo.denominator = myHp[j].denominator
		end
		
		local sceneVo = dp:getGlorySceneVo()
		local stationVo =  dp:getStationVoById(targets.pass)
		local enemyVo = stationVo.enemyVo

        local other_hp = targets.other_hp
		for k=1,#other_hp do
			local heroVo = enemyVo.heroVoDict[other_hp[k].hero_id]
			-- heroVo.hp = other_hp[k].hp
			heroVo.molecular = other_hp[k].molecular
			heroVo.denominator = other_hp[k].denominator
			heroVo.maxHp = other_hp[k].denominator
			-- heroVo.maxHp = other_hp[k].max_hp --注意！服务端maxHp返回 0
			enemyVo.heroVoDict[heroVo.id] = heroVo
			-- print(" i=> 敵人 heroVo.id ",heroVo.molecular,heroVo.denominator)
		end
		
		-- ComSender:getInstance():dealExtInfo(glory_combat_over_rsp.ext)
	-- end
end

--请求荣耀之路 排行榜
function GloryNetTask:requestGloryRank()
	print("-----------requestGloryRank-------------")
	local glory_rank_info_req = glory_pb.glory_rank_info_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.glory_rank_info_req,glory_rank_info_req)
end

--响应荣耀之路 排行榜
function handleGloryRank(pkg)
	local glory_rank_info_rsp = glory_pb.glory_rank_info_rsp()
	glory_rank_info_rsp:ParseFromString(pkg)

	print("-----------handleGloryRank-------------",glory_rank_info_rsp.ret)
	if glory_rank_info_rsp.ret == error_code_pb.msg_ret.success then

		for i=1,#glory_rank_info_rsp.ranks do
			local v = glory_rank_info_rsp.ranks[i]
			local client_role_info = OtherRoleInfo:create()
	        client_role_info:setBaseInfo(v.id, v.name, 
	                                v.team_lev,v.fc, 
	                                v.face_id, v.rank, 
	                                v.win_num,v.guild_name,
	                                v.sex)
	        client_role_info:setHeros(v.heroes)
	        client_role_info:sortHeros()
	        GloryDataProxy:getInstance():setRankVo(client_role_info)
		end
		
		Notifier.dispatchCmd(GloryEvent.CB_UPDATE_RANK)

		ComSender:getInstance():dealExtInfo(glory_rank_info_rsp.ext)
	else
		Alert:show(Helper.getErrStr(glory_rank_info_rsp.ret))
	end
end

function GloryNetTask.gloryHandleBattleEnd()

	local batResData = BattleManager:getInstance():getBattleResultData()
	if BattleManager:getInstance():getIsOB() or batResData == nil then
        return
    end
    if BattleManager:getInstance():getType() == BattleType.GLORY_ROAD then

	    local isWin = batResData.resultType == BattleResultType.VICTORY
	    local dp = GloryDataProxy:getInstance()
	    local sceneVo = dp:getGlorySceneVo()
		--------------------------------------------------
		if isWin then --胜利
			local stationVo = dp:getStationVoById(sceneVo.nowStation)
			local enemyVo = stationVo.enemyVo
			for k,v in pairs(enemyVo.heroVoDict) do
				-- __instance.tmpUnFightHeroList[ v.id ] = nil --不能自动补满血 要手动操作
				-- v.hp = 0
				-- v.perc = 0
				v.molecular = 0
				v.denominator = 0
			end
			if sceneVo.nowStation < 12 then
				sceneVo.nowStation = sceneVo.nowStation + 1
			elseif sceneVo.nowStation == 12 then --全通关
				sceneVo.isFinish = 1

				WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,{okFunc = function()
	                local sceneVo = GloryDataProxy:getInstance():getGlorySceneVo()
					if sceneVo.leftReset <= 0 then
						Alert:show("您今天的重置機會已用完")
					else
						GloryNetTask:getInstance():requestGloryReset() --直接重置
					end
	            end, txt = "恭喜您本次挑戰星空神殿通關成功！",
	            okBtnName = "再次挑戰",cancelBtnName = "確定"})

			end
			-- stationVo.dungeonStarNum = math.max( batResData.numStars ,stationVo.dungeonStarNum )
		else --失败
			local teamList = TeamManager:getInstance():getBattleHeroList(TeamType.Glory)
			local voList = dp:getMyHeroVoList()
			for k,heroId in pairs(teamList) do
				for k,v2 in pairs(voList) do
					if heroId == v2.id then
						-- v2.hp = 0
						-- v2.perc = 0
						v2.molecular = 0
						v2.denominator = 0
						-- __instance.tmpUnFightHeroList[ heroId ] = nil --不能自动补满血 要手动操作
					end
				end
			end
		end
		--------------------------------------------------
		Notifier.dispatchCmd(GloryEvent.CB_UPDATE_SCENE_AFTER_BATTLE)
	end

end