--
-- Author: zhenglinfeng
-- Date: 2015-11-09 12：05
-- 游戏好友界面

require("FriendMgr")
FriendView = class("FriendView",WindowBase)

--有人请求添加好友显示的item
local _requestItem = nil
--查找到的是否互为好友
local _is_friend = nil

function FriendView:create()
	local ret = FriendView.new()
	return ret
end

function FriendView:init()
    self.isOpen = true

    self.cur_num = 1
    self.request_num = 0

	-- ComResMgr:getInstance():loadResByName("ui/reward/direction_btn.plist", "ui/reward/direction_btn.png")
    ComResMgr:getInstance():loadResByName("ui/friend/friendsRes.plist", "ui/friend/friendsRes.png")

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/friend/FriendsUI.ExportJson")

	self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.listMenu = tolua.cast(self._widget:getChildByName("list_friend"),"ListView")

    self.allItem = {}

    --查找到好友需要显示的item
    self.infoLayer = TouchGroup:create()
    self.infoLayer:setTouchPriority(2551)
    self:addChild(self.infoLayer, 100)
    self.checkItem = FriendItem:create()
    self.checkItem:setPosition(ccp(206, 420))
    self.infoLayer:addWidget(self.checkItem)
    self.infoLayer:setVisible(false)
    self.infoLayer:setTouchEnabled(false)

    local close_btn = self.uiLayer:getWidgetByName("btn_close")
    close_btn:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    self.lab_title = tolua.cast(self._widget:getChildByName("Label_8356"), "Label")

    --返回按钮，查找到好友需要显示
    self.return_btn = tolua.cast(self._widget:getChildByName("btn_return"),"Button")
    self.return_btn:setTitleText("")
    self.return_btn:setSize(CCSize(87, 90))
    self.return_btn:loadTextures("friend_return_up.png", "friend_return_down.png", "", UI_TEX_TYPE_PLIST)
    self.return_btn:setVisible(false)
    self.return_btn:setEnabled(false)
    self.return_btn:addTouchEventListener(function(sender, event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            FriendMgr:getInstance():setIsOpenCheckView(false)
            _is_friend = nil
            self.lab_title:setText("好友列表")
            if _requestItem then
                _requestItem:setVisible(true)
                _requestItem:setTouchEnabled(true)
            end
            if self.infoLayer:isVisible() then
                self.infoLayer:setTouchPriority(2551)
                self.infoLayer:setVisible(false)
                self.infoLayer:setTouchEnabled(false)
                for k,v in pairs(self.allItem) do
                    v:changeBtnFont("切 磋")
                    v:setVisible(true)
                    v:setTouchEnabled(true)
                end
            end
            self.return_btn:setVisible(false)
            self.return_btn:setEnabled(false)
        end
    end)

    local check_btn = tolua.cast(self._widget:getChildByName("btn_check"),"Button")
    check_btn:addTouchEventListener(function(sender, event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            if self.inputAccout:getText() == "" or self.inputAccout:getText() == nil then
                Alert:show("请输入玩家的名字")
                return
            end
            if self.inputAccout:getText() == CharacterManager:getInstance():getBaseData():getName() then
                Alert:show(self.inputAccout:getText().."不就是你自己吗？")
                return
            end
            FriendMgr:getInstance():sendCheckProto(self.inputAccout:getText())
        end
    end)

    local name_txt_fild = tolua.cast(self._widget:getChildByName("tf_name"),"TextField")
    self.inputAccout = CCEditBox:create(CCSize(250,30),CCScale9Sprite:create("ui/login/resource/img/img_empty.png"))
    local x,y = name_txt_fild:getPosition()
    self.inputAccout:setAnchorPoint(ccp(0, 0.5))
    self.inputAccout:setPosition(ccp(x ,y))
    self.inputAccout:setTouchPriority(-2551)
    self.inputAccout:setMaxLength(10)
    self.inputAccout:setPlaceHolder("請輸入玩家的名字")
    self.inputAccout:setInputMode(kEditBoxInputModeSingleLine)
    self.inputAccout:setFontSize(15)
    self:addChild(self.inputAccout)
    self.inputAccout:setTouchEnabled(true)

    --刷新好友列表
    self._onFriendInfoUpdate = function(friend_infos)
        if friend_infos then
            self:updateFriendInfo(friend_infos)
        end
    end

    self._onCheckFriend = function(_infos)
        if _infos then
            self.return_btn:setVisible(true)
            self.return_btn:setEnabled(true)
            self.lab_title:setText("查找好友")
            _is_friend = _infos.is_friend
            self:showCheckView(_infos.info)
        end
    end

    self._onNewFriend = function(new_friend_info)
        --所有申请人的信息都在new_friend_info
        if #new_friend_info < 1 then
            --没有人加好友  如果_requestItem存在  就要remove 然后设置为空
            if _requestItem then
                self.listMenu:removeItem(self.listMenu:getIndex(_requestItem))
                _requestItem = nil
            end
            return
        end
        self.request_num = #new_friend_info
        self:setView()
    end

    self._onRefreshSendPhy = function( )
        -- print("检查是否有发送过=============")
        for k,v in pairs(self.allItem) do
            if v.hasSend == true then
                local oneFriendItem = v
                oneFriendItem:setBtnSendEn(1)
            end
        end
    end

    self._onCheckEvent = function(_isCanTouch)
        if _isCanTouch > 0 then
            self.infoLayer:setTouchEnabled(false)
            self.inputAccout:setTouchEnabled(false)
            self.infoLayer:setTouchPriority(_isCanTouch)
            self.inputAccout:setTouchPriority(_isCanTouch)
        elseif _isCanTouch < 0 then
            self.inputAccout:setTouchEnabled(true)
            if FriendMgr:getInstance():getIsOpenCheckView() then
                self.infoLayer:setTouchEnabled(true)
                self.infoLayer:setTouchPriority(_isCanTouch)
            end
            self.inputAccout:setTouchPriority(_isCanTouch)
        end
    end

    self._onOperUpdate = function(_data)
        if #_data < 1 then
            if _requestItem then
                self.listMenu:removeItem(self.listMenu:getIndex(_requestItem))
                _requestItem = nil
            end
            --这里要让绿点消失，并且关闭申请界面
            Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP, NewTipsEnum.friend) 
            FriendMgr:getInstance():setNewTips(false)          
            WindowCtrl:getInstance():close(CmdName.Request_View)
        else
            local request_count = tolua.cast(_requestItem:getChildByName("lab_count"),"Label")
            request_count:setText(tostring(#_data))
        end 
    end
    --刷新好友列表
    Notifier.regist(CmdName.Friend_View_update, self._onFriendInfoUpdate)
    --请求好友列表
    FriendMgr:getInstance():getFriendInfo()

end

function FriendView:setView()
    if FriendMgr:getInstance():getNewTips() then

        FriendMgr:getInstance():setIsOpenCheckView(false)
        _is_friend = nil

        -- if self.infoLayer:isVisible() then
            self.infoLayer:setTouchPriority(2551)
            self.infoLayer:setVisible(false)
            self.infoLayer:setTouchEnabled(false)
            for k,v in pairs(self.allItem) do
                v:changeBtnFont("切 磋")
                v:setVisible(true)
                v:setTouchEnabled(true)
            end
        -- end
        self.return_btn:setVisible(false)
        self.return_btn:setEnabled(false)


        --有人申请好友，需要先插入一项好友的显示
        if not _requestItem then
            _requestItem = GUIReader:shareReader():widgetFromJsonFile("ui/friend/requestFriend.ExportJson")
            self.listMenu:insertCustomItem(_requestItem, 0)
        end
        _requestItem:setVisible(true)
        _requestItem:setTouchEnabled(true)
        local request_count = tolua.cast(_requestItem:getChildByName("lab_count"),"Label")
        request_count:setText(tostring(self.request_num))
        _requestItem:setTouchEnabled(true)
        _requestItem:addTouchEventListener(function(sender, event_type)
            if event_type == ComConstTab.TouchEventType.ended then
                WindowCtrl:getInstance():open(CmdName.Request_View)
            end       
        end)
    end
end

--显示查找的界面
function FriendView:showCheckView(_checkData)
    for k,v in pairs(self.allItem) do
        v:setVisible(false)
        v:setTouchEnabled(false)
    end
    if _requestItem then
        _requestItem:setVisible(false)
        _requestItem:setTouchEnabled(false)
    end

    FriendMgr:getInstance():setIsOpenCheckView(true)
    self.infoLayer:setVisible(true)
    self.infoLayer:setTouchEnabled(true)
    self.infoLayer:setTouchPriority(-2551)
    self.checkItem:updateData(_checkData, false)
    self.checkItem:changeBtnFont("加为好友")

end

--更新好友信息
function FriendView:updateFriendInfo(_data)
    --获取好友列表之后，刷新界面
    for k,v in pairs(self.allItem) do
        self.listMenu:removeItem(self.listMenu:getIndex(v))
    end
    self.allItem = {}
    for i=1, #_data.friend_infos do
        local item = FriendItem:create()
        if _data.friend_infos[i].info then
            print("是否赠送过体力=========",_data.friend_infos[i].has_give_phy)
            item:updateData(_data.friend_infos[i].info, true , _data.friend_infos[i].has_give_phy )
            self.listMenu:pushBackCustomItem(item)
            table.insert(self.allItem, item)
        end
    end 
end

function FriendView:open()
    FriendMgr:getInstance():setIsFriendView(true)
    ComResMgr:getInstance():loadResByName("ui/friend/friendsRes.plist", "ui/friend/friendsRes.png")
    -- ComResMgr:getInstance():loadResByName("ui/reward/direction_btn.plist", "ui/reward/direction_btn.png")
    self.inputAccout:setText("")

    if FriendMgr:getInstance():getIsOpenCheckView() then
        --打开好友界面的时候隐藏查找好友的那个item
        FriendMgr:getInstance():setIsOpenCheckView(false)
        _is_friend = nil
        if _requestItem then
            _requestItem:setVisible(true)
            _requestItem:setTouchEnabled(true)
        end
        if self.infoLayer:isVisible() then
            self.infoLayer:setTouchPriority(2551)
            self.infoLayer:setVisible(false)
            self.infoLayer:setTouchEnabled(false)
            for k,v in pairs(self.allItem) do
                v:changeBtnFont("切 磋")
                v:setVisible(true)
                v:setTouchEnabled(true)
            end
        end
        self.return_btn:setVisible(false)
        self.return_btn:setEnabled(false)
    end

    if not self.isOpen then
        --第一次打开界面因为在init里面注册了  所以不需要再次注册
        --当界面关闭的时候remove掉注册，所以第二次打开或者之后打开的时候都要再次注册
        --刷新好友列表
        Notifier.regist(CmdName.Friend_View_update, self._onFriendInfoUpdate)
        FriendMgr:getInstance():getFriendInfo()
    end  
    --显示查找好友界面
    Notifier.regist(CmdName.Friend_View_check, self._onCheckFriend)

    Notifier.regist(CmdName.Friend_Update_Request, self._onOperUpdate)

    Notifier.regist(CmdName.Friend_Check_Event, self._onCheckEvent)

    Notifier.regist(CmdName.Friend_New_Friend, self._onNewFriend)

    Notifier.regist(CmdName.Friend_Refresh_SendPhy, self._onRefreshSendPhy)

    --有绿点，就是有新好友请求
    if FriendMgr:getInstance():getNewTips() then
        FriendMgr:getInstance():sendNewFriend()
    else
        print("riririri")
    end
end

function FriendView:close()
    self.isOpen = false
    FriendMgr:getInstance():setIsFriendView(false)
    Notifier.remove(CmdName.Friend_View_update, self._onFriendInfoUpdate)
    Notifier.remove(CmdName.Friend_View_check, self._onCheckFriend)
    Notifier.remove(CmdName.Friend_Update_Request, self._onOperUpdate)
    Notifier.remove(CmdName.Friend_Check_Event, self._onCheckEvent)
    Notifier.remove(CmdName.Friend_New_Friend, self._onNewFriend)
    Notifier.remove(CmdName.Friend_Refresh_SendPhy, self._onRefreshSendPhy)
	ComResMgr:getInstance():remove("ui/friend/friendsRes.plist", "ui/friend/friendsRes.png")
    -- ComResMgr:getInstance():remove("ui/reward/direction_btn.plist", "ui/reward/direction_btn.png")
end

function FriendView:dispose()
end



--[[----------------------------------------------------------------------------------------------------------------------------------------------------------]]


FriendItem = class("FriendItem", function() 
    return Layout:create()
end)
FriendItem.hasSend = false

function FriendItem:create()
    local ret = FriendItem.new()
    ret:init()
    return ret
end

function FriendItem:init()
	self.friend_item = GUIReader:shareReader():widgetFromJsonFile("ui/friend/FirendItem.ExportJson")
    self.friend_item:setPositionX(-26)
	self:addChild(self.friend_item)

    self.btn_qc = tolua.cast(self.friend_item:getChildByName("btn_qc"),"Button")
    self.btn_qc:setPositionX(self.btn_qc:getPositionX() - 8)
    self.btn_qc:addTouchEventListener(function(sender, event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            local isOpen = FriendMgr:getInstance():getIsOpenCheckView()
            if isOpen then
                --发送添加好友的请求
                if _is_friend == 1 then
                    Alert:show("你们已经是好友啦")
                    return
                end
                -- if FriendMgr:getInstance():getRequestListInfo(self.vo.id.uin) 
                self:changeBtnFont("已申请", true)
                FriendMgr:getInstance():sendAddFriend(self.vo.id)
            else
                
                WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, 
                {
                    txt = "是否向好友發起挑戰？",
                    okBtnName = "挑戰",
                    cancelBtnName = "取消",
                    isCloseAnimate = true,
                    okFunc = function()
                        FriendMgr:getInstance():setEnemySex(self.vo.sex)
                        -- 好友之间的切磋
                        CombatDataStorage:getInstance():parseConfigData()
                        WindowCtrl:getInstance():open(CmdName.Team_View,{
                        team_type = TeamType.Normal,
                        id = BattleIDType.FRIEND,
                        subId = 1,
                        roleId = self.vo.id
                        })
                    end
                })
            end
        end
    end)

    self.lab_name = tolua.cast(self.friend_item:getChildByName("lab_name"),"Label")
    self.lab_name:setPositionX(self.lab_name:getPositionX() + 4)

    self.lab_lv = tolua.cast(self.friend_item:getChildByName("lab_lv"), "Label")

    self.lab_gh = tolua.cast(self.friend_item:getChildByName("lab_gh"), "Label")
    self.lab_gh:setPositionX(195)

    self.icon = tolua.cast(self.friend_item:getChildByName("img_icon"), "ImageView")
    self.icon:setVisible(false)
    self.icon:setTouchEnabled(true)

    self.icon:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            if self.vo then
                --查看信息
                local other_hero = self.vo.heroes
                local curInfo = {}
                local heroList = {}
                 for i=1, #other_hero do
                    local other_hero_info = {}
                    other_hero_info.hero_id = other_hero[i].base_id
                    print("base_id=",other_hero[i].base_id)
                    print("base_id=",other_hero[i].base_id)
                    print("base_id=",other_hero[i].base_id)
                    print("base_id=",other_hero[i].base_id)
                    print("base_id=",other_hero[i].base_id)
                    other_hero_info.stars = other_hero[i].stars
                    table.insert(heroList, other_hero_info)
                end
                --info通用界面需要传的信息
                curInfo.heroList = heroList
                curInfo.faceId = self.vo.face_id
                curInfo.level = self.vo.team_lev
                curInfo.name = self.vo.name
                curInfo.id = self.vo.id
                curInfo.sex = self.vo.sex
                curInfo.guild = self.vo.guild_name
                curInfo.fightValue = self.vo.fc
                curInfo.pet_star = self.vo.sprite_stars
                curInfo.isFriend = self.isFriend
                --查看好友信息的时候，把信息存起来，方便删除好友的时候传递信息
                if self.isFriend then
                    FriendMgr:getInstance():setDelInfo(self.vo.id)
                end
                WindowCtrl:getInstance():open(CmdName.Comm_PlayerInfo,{vo = curInfo})
            end
        end
    end)

    self:setSize(CCSize(550, 120))
end

function FriendItem:updateData(_data, _isFriend , has_give_phy)
    self.isFriend = _isFriend
    self.hasSend = false

    if _isFriend and self.btn_qc then
        self.give_btn = Button:create()
        self.give_btn:loadTextures("btn_up_1.png", "btn_down_1.png", "btn_disable_1.png", UI_TEX_TYPE_PLIST)
        self.give_btn:setScale(0.8)
        self.give_btn:setTitleFontSize(24)
        self.give_btn:setTitleColor(ccc3(251, 241, 160))
        -- self.btn_qc:setPositionX(self.btn_qc:getPositionX() + 20)
        self.give_btn:setPosition(ccp(385, 60))
        self.friend_item:addChild(self.give_btn)
        --[[
            self.give_btn:setBright(false)
            self.give_btn:setTouchEnabled(false)
            self.give_btn:setTitleText("已赠送")
        ]]
        self.give_btn:addTouchEventListener(function(sender, event_type)
            if event_type == ComConstTab.TouchEventType.ended then
                --请求赠送体力  赠送成功之后要屏蔽对这个好友的赠送功能
                self.hasSend = true
                local send_data = {}
                send_data.id = _data.id
                send_data.type = 1
                FriendMgr:getInstance():sendGiveProto(send_data)
            end
        end)
        self:setBtnSendEn(has_give_phy)
    end

    self.vo = _data
    local icon = HeadIcon:create()
    icon:setPosition(ccp(self.icon:getPosition()))
    icon:setScale(0.8)
    icon:setFaceId(self.vo.face_id, self.vo.sex)
    self.friend_item:addChild(icon)

    self:setVisible(true)
    self:setTouchEnabled(true)
    self.btn_qc:setTouchEnabled(true)
    self.icon:setTouchEnabled(true)
    self.lab_name:setText(_data.name)
    self.lab_lv:setText("Lv.".._data.team_lev)
    if _data.guild_name == "" or _data.guild_name == nil then
        self.lab_gh:setText("公会.无")
    else
        self.lab_gh:setText("公会：".._data.guild_name)
    end
end

function FriendItem:setBtnSendEn(has_give_phy)
    if has_give_phy == 0 then
        print("可以赠送体力!!!!!!!")
        self.give_btn:setTitleText("赠送体力")
        self.give_btn:setBright(true)
        self.give_btn:setTouchEnabled(true)
    else
        self.give_btn:setBright(false)
        self.give_btn:setTouchEnabled(false)
        self.give_btn:setTitleText("已赠送")
    end
end

function FriendItem:changeBtnFont(Text, isCanTouch)
    self.btn_qc:setTitleText(Text)
    if isCanTouch then
        self.btn_qc:setBright(false)
        self.btn_qc:setTouchEnabled(false)
    else
        self.btn_qc:setBright(true)
        self.btn_qc:setTouchEnabled(true)
    end
end