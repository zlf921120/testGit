--
-- Author: zhenglinfeng
-- Date: 2015-11-10 17：21
-- 打开好友面板按钮

require("FriendMgr")

FriendBtn = class("FriendBtn", function() 
    return CCLayer:create()
end)

local btn_tips_img = nil

function FriendBtn:ctor() 
	self:init()
end

function FriendBtn:init()
    
    ComResMgr:getInstance():loadResByName("ui/friend/friend_btn.plist", "ui/friend/friend_btn.png")

	self.uiFriendLayer = TouchGroup:create()
    self:addChild(self.uiFriendLayer)

	self.friend_btn = Button:create()
    self.friend_btn:setAnchorPoint(ccp(0,0))
    self.friend_btn:setPosition(ccp(0, 400))
    self.friend_btn:loadTextureNormal("friend_l.png", UI_TEX_TYPE_PLIST)
    self.friend_btn:loadTexturePressed("friend_an.png", UI_TEX_TYPE_PLIST)
    self.friend_btn:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Friend_View)
        end
    end)

    -- local btn_text = ImageView:create()
    -- btn_text:loadTexture("friend_text.png", UI_TEX_TYPE_PLIST)
    -- local btn_size = self.friend_btn:getContentSize()
    -- btn_text:setPosition(ccp(btn_size.width/2, btn_size.height/2))
    -- self.friend_btn:addChild(btn_text)

    self.uiFriendLayer:addWidget(self.friend_btn)

	--绿点
	btn_tips_img = ImageView:create()
    btn_tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
    btn_tips_img:setTag(2866)
    self:addChild(btn_tips_img)
    btn_tips_img:setPosition(ccp(48,485))
    btn_tips_img:setVisible(false)


    --监听有没有人推送
    -- self.haveNewFriend = function(params)
    --     print("friend count=",#params)
    --     if #params > 0 then
    --         Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP, NewTipsEnum.friend)
    --     end
    -- end
    
    -- Notifier.regist(CmdName.Friend_New_Friend, self.haveNewFriend)

    if CharacterManager:getInstance():getTeamData():getLev() < 20 then
        self.friend_btn:setVisible(false)
        self.friend_btn:setTouchEnabled(false)
        self.teamLvChange = function(team_info)
        local oldLev = team_info[2]
        local newLev = team_info[3]
            if oldLev < 20 and newLev >= 20 then
                self.friend_btn:setVisible(true)
                self.friend_btn:setTouchEnabled(true)
                --升级到20以上，是否显示绿点
                if FriendMgr:getInstance():getNewTips() then
                    Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.friend)
                end
            end
        end

        --玩家等级小于20级才需要监听英雄等级变化
        Notifier.regist(GuideEvent.Main, self.teamLvChange)
    else
        

        -- FriendMgr:getInstance():sendNewFriend()
    end

    

end

function FriendBtn:create()
	local ret = FriendBtn.new()
	return ret
end