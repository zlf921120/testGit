--
-- Author: zhenglinfeng
-- Date: 2015-11-09 12：05
-- 游戏好友界面管理

require("sns_pb")

FriendMgr = class("FriendMgr")

local _instance = nil
local all_new_info = {}
local haveNewTips = nil

function FriendMgr:getInstance()
	if not _instance then
		_instance = FriendMgr.new()
	end
	return _instance
end

function FriendMgr:ctor()
	self:init()
	self.isOpenCheckView = false
	self.isFriendView = false
	haveNewTips = false
	self.Del_Friend_info = {}
	self.request_friend_list = {}
end

function FriendMgr:init()
end

function FriendMgr:setDelInfo(_info)
	self.Del_Friend_info = nil
	self.Del_Friend_info = _info
end

function FriendMgr:getDelInfo()
	return self.Del_Friend_info
end

function FriendMgr:setNewTips(_newTips)
	print("tips=",_newTips)
	print("tips=",_newTips)
	print("tips=",_newTips)
	print("tips=",_newTips)
	haveNewTips = _newTips
end

function FriendMgr:getNewTips()
	return haveNewTips
end

function FriendMgr:setIsOpenCheckView(isopen)
	self.isOpenCheckView = isopen
end

function FriendMgr:getIsOpenCheckView()
	return self.isOpenCheckView
end

function FriendMgr:getIsFriendView()
	return self.isFriendView
end

function FriendMgr:setIsFriendView(_isFriend)
	self.isFriendView = _isFriend
end

function FriendMgr:sendCheckProto(sendData)
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_search_role_req+1, "onCheckFriend()")
	local search_role_req = sns_pb.sns_search_role_req()
	search_role_req.name = sendData
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.sns_search_role_req, search_role_req)
end

function FriendMgr:getFriendInfo()
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_list_friend_req+1, "onGetFriendInfo()")
	local list_friend_req = sns_pb.sns_list_friend_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.sns_list_friend_req, list_friend_req)
end

function onCheckFriend(_data)
	
	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_search_role_req+1, "onCheckFriend()")

	local search_role_rsp = sns_pb.sns_search_role_rsp()

	search_role_rsp:ParseFromString(_data)

	-- ComSender:getInstance():dealExtInfo(search_role_rsp.ext)
	if search_role_rsp.ret ~= error_code_pb.msg_ret.success then
        return 
    end
    if #search_role_rsp.roles < 1 then
    	Alert:show("找不到该玩家")
    	--查不到人也要刷新界面
    	Notifier.dispatchCmd(CmdName.Friend_View_check, nil)
    	-- ComSender:getInstance():dealExtInfo(search_role_rsp.ext)
    	return
    end

    local server_role_info = search_role_rsp.roles[1]
    -- local friend_info = server_role_info.info
    Notifier.dispatchCmd(CmdName.Friend_View_check, server_role_info)
    ComSender:getInstance():dealExtInfo(search_role_rsp.ext)

end

function onGetFriendInfo(_data)
	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_list_friend_req+1, "onGetFriendInfo()")
	local list_friend_rsp = sns_pb.sns_list_friend_rsp()
	list_friend_rsp:ParseFromString(_data)
	if list_friend_rsp.ret ~= error_code_pb.msg_ret.success then
		Alert:show("获取好友列表失败")
		return
	end
	--通知界面更新
    Notifier.dispatchCmd(CmdName.Friend_View_update, list_friend_rsp)
    ComSender:getInstance():dealExtInfo(list_friend_rsp.ext)
end

function FriendMgr:sendAddFriend(_id)

	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_request_friend_rsp, "onAddFriend()")
	local request_friend_req = sns_pb.sns_request_friend_req()
	request_friend_req.target_id.uin = _id.uin
	request_friend_req.target_id.channel_id = _id.channel_id
	request_friend_req.target_id.zone_id = _id.zone_id
	
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.sns_request_friend_req, request_friend_req)
end

function onAddFriend(_data)
	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_request_friend_rsp, "onAddFriend()")
	local request_friend_rsp = sns_pb.sns_request_friend_rsp()
	if request_friend_rsp.ret ~= error_code_pb.msg_ret.success then
		Alert:show("申请失败")
		return
	end

	Alert:show("申请成功")
    ComSender:getInstance():dealExtInfo(request_friend_rsp.ext)
end

function FriendMgr:sendNewFriend()
	--请求好友列表  这个列表是别人添加我为好友时的列表
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_list_request_friend_rsp, "onNewFriend()")
	local request_friend_req = sns_pb.sns_list_request_friend_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.sns_list_request_friend_req, request_friend_req)
end

function onNewFriend(_data)
	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_list_request_friend_rsp, "onNewFriend()")
	local request_friend = sns_pb.sns_list_request_friend_rsp()
	request_friend:ParseFromString(_data)
	
	-- request_friend.ret ~= 0 
	if request_friend.ret ~= 0 then
		Alert:show("什么鬼？？")
		return
	end
	if #request_friend.requests < 1 then
		_instance:setNewTips(false)
		-- Alert:show("没有新好友")
	else
		_instance:setNewTips(true)
		Alert:show("有新好友")
	end
	all_new_info = nil
	all_new_info = request_friend.requests
	Notifier.dispatchCmd(CmdName.Friend_New_Friend, request_friend.requests)
	ComSender:getInstance():dealExtInfo(request_friend.ext)
end

function FriendMgr:getNewFriendInfo()
	return all_new_info
end

local oper_type = nil

--请求好友操作  同意或者拒绝
function FriendMgr:sendOperFriend(_data)
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_oper_request_friend_rsp, "onOperFriend()")
	local oper_request_friend = sns_pb.sns_oper_request_friend_req()
	oper_request_friend.oper = _data.type
	oper_type = _data.type
	if _data.info then
		oper_request_friend.target_id.uin = _data.info.uin
		oper_request_friend.target_id.channel_id = _data.info.channel_id
		oper_request_friend.target_id.zone_id = _data.info.zone_id
	end
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.sns_oper_request_friend_req, oper_request_friend)
end

function onOperFriend(_data)
	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_oper_request_friend_rsp, "onOperFriend()")
	local oper_rsp = sns_pb.sns_oper_request_friend_rsp()
	if oper_rsp.ret ~= 0 then
		Alert:show("什么鬼？？")
		return
	end
	all_new_info = nil
	all_new_info = oper_rsp.requests
	if oper_type == 1 or oper_type == 3 then
		_instance:getFriendInfo()
	end
	Notifier.dispatchCmd(CmdName.Friend_Oper_Friend, oper_rsp.requests)
	Notifier.dispatchCmd(CmdName.Friend_Update_Request, oper_rsp.requests)
	ComSender:getInstance():dealExtInfo(oper_rsp.ext)
end

--请求删除好友
function FriendMgr:sendDelProto(_data)
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_del_friend_rsp, "onDelFriend()")
	local del_friend_req = sns_pb.sns_del_friend_req()

	del_friend_req.target_id.uin = _data.uin
	del_friend_req.target_id.channel_id = _data.channel_id
	del_friend_req.target_id.zone_id = _data.zone_id

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.sns_del_friend_req, del_friend_req)
end

function onDelFriend()
	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_del_friend_rsp, "onOperFriend()")
	local del_rsp = sns_pb.sns_del_friend_rsp()
	if del_rsp.ret ~= 0 then
		Alert:show("什么鬼？？")
		return
	end
	--直接重新请求好友列表吧
	_instance:getFriendInfo()
    ComSender:getInstance():dealExtInfo(del_rsp.ext)
end

function FriendMgr:sendGiveProto(_data)
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_friend_give_phy_rsp, "onGivePhysical()")
	local give_phy_req = sns_pb.sns_friend_give_phy_req()
	give_phy_req.target_id.uin = _data.id.uin
	give_phy_req.target_id.channel_id = _data.id.channel_id
	give_phy_req.target_id.zone_id = _data.id.zone_id
	give_phy_req.way = _data.type          --赠送体力方式
	if _data.type == 2 then
		print("id=",_data.id.uin)
		print("channel_id=",_data.id.channel_id)
		print("zone_id=",_data.id.zone_id)
	end
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.sns_friend_give_phy_req, give_phy_req)
end

function onGivePhysical(_data)
	--回调设置按钮灰色
	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.sns_friend_give_phy_rsp, "onGivePhysical()")
	local give_phy_rsp = sns_pb.sns_friend_give_phy_rsp()
	give_phy_rsp:ParseFromString(_data)
	print("收到赠送体力结果！！！！！！",give_phy_rsp.ret,give_phy_rsp.ext)
	if give_phy_rsp.ret ~= error_code_pb.msg_ret.success then
		Alert:show(Helper.getErrStr(give_phy_rsp.ret))
		return
	end
	Alert:show("赠送体力成功！")
	Notifier.dispatchCmd(CmdName.Friend_Refresh_SendPhy)
	ComSender:getInstance():dealExtInfo(give_phy_rsp.ext)
end

function FriendMgr:setRequestListInfo(_index)
	if not self.request_friend_list._index then
		self.request_friend_list._index = true
	end
end

function FriendMgr:getRequestListInfo(_index)
	return self.request_friend_list._index
end

local _enemySex

function FriendMgr:setEnemySex(_sex)
	print("enemy sex=",_sex)
	print("enemy sex=",_sex)
	print("enemy sex=",_sex)
	print("enemy sex=",_sex)
	print("enemy sex=",_sex)
	_enemySex = _sex
end

function FriendMgr:getEnemySex()
	return _enemySex
end