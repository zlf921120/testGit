--
-- Author: zhenglinfeng
-- Date: 2015-11-11 10：44
-- 处理添加好友的界面


require("FriendMgr")
RequestView = class("RequestView",WindowBase)

local all_data = {}

function RequestView:create()
	local ret = RequestView.new()
	return ret
end

function RequestView:init()
    self.uiLayer = TouchGroup:create()
    self:addChild(self.uiLayer)

    self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/friend/RequesView.ExportJson")
    self.uiLayer:addWidget(self.widget)

    self.list_item = tolua.cast(self.widget:getChildByName("ListView_8532"),"ListView")

    self.btn_yeaAll = tolua.cast(self.widget:getChildByName("btn_yes"),"Button")
    self.btn_yeaAll:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
        	self.list_item:removeAllItems()
            Alert:show("恭喜添加好友成功!")
        	local send_data = {}
        	send_data.type = 3
        	FriendMgr:getInstance():sendOperFriend(send_data) 
        end
    end)

    self.btn_noAll = tolua.cast(self.widget:getChildByName("btn_no"),"Button")
    self.btn_noAll:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
        	self.list_item:removeAllItems()
            Alert:show("您已成功拒绝好友")
        	local send_data = {}
        	send_data.type = 4
        	FriendMgr:getInstance():sendOperFriend(send_data)
        end
    end)

    local btn_close = tolua.cast(self.widget:getChildByName("btn_close"), "Button")
    btn_close:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
        	WindowCtrl:getInstance():close(self.name)
        end
    end)

    self._onViewUpdate = function(update_after_list)
    	self.list_item:removeAllItems()
    	self:addItem(update_after_list)
    end

end

function RequestView:open()
    Notifier.regist(CmdName.Friend_Oper_Friend, self._onViewUpdate)
    self:addItem()
end

function RequestView:addItem(_list)
	--getNewFriendInfo()  在请求邀请好友列表的时候就写入了那些人的信息
	--在操作了好友之后，会回调到这里，如果_list不为空就要以他为准
    self.list_item:removeAllItems()
    local tab_info = nil
    if _list then
        tab_info = _list
    else
        tab_info = FriendMgr:getInstance():getNewFriendInfo()
    end
	for i=1, #tab_info do
        local item = RequestItem:create()
        item:setData(tab_info[i])
        self.list_item:pushBackCustomItem(item)
    end
end

function RequestView:close()
	Notifier.remove(CmdName.Friend_Oper_Friend, self._onViewUpdate)
end



RequestItem = class("RequestItem", function() 
    return Layout:create()
end)

function RequestItem:create()
    local ret = RequestItem.new()
    ret:init()
    return ret
end

function RequestItem:init()
	self.reques_item = GUIReader:shareReader():widgetFromJsonFile("ui/friend/RequestItem.ExportJson")
    self.reques_item:setPosition(ccp(15,-15))
	self:addChild(self.reques_item)

	self.item_data = {}

	self.btn_yes = tolua.cast(self.reques_item:getChildByName("btn_yes"),"Button")
	self.btn_no = tolua.cast(self.reques_item:getChildByName("btn_no"),"Button")
	self.btn_yes:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            Alert:show("恭喜添加好友成功!")
        	local send_data = {}
        	send_data.type = 1
        	send_data.info = self.item_data.id
        	FriendMgr:getInstance():sendOperFriend(send_data)
        end
    end)

    self.btn_no:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            Alert:show("您已成功拒绝好友")
        	local send_data = {}
        	send_data.type = 2
        	send_data.info = self.item_data.id
        	FriendMgr:getInstance():sendOperFriend(send_data)
        end
    end)

	self.lab_time = tolua.cast(self.reques_item:getChildByName("lab_min"),"Label")
	self.lab_who = tolua.cast(self.reques_item:getChildByName("lab_who"),"Label")

	self:setSize(CCSize(580, 80))
end

function RequestItem:setData(_data)
    local diffTime = (os.time() - _data.time)/3600
    local Str_Text = ""
    if 24 <= diffTime then
        Str_Text = tostring(math.floor(diffTime/24)).."天前"
    elseif 12 <= diffTime then
        Str_Text = "半天前"
    elseif 60 <= diffTime*60 then
        Str_Text = tostring(math.floor(diffTime)).."小时前"
    elseif 5 <= diffTime*60 then
        Str_Text = tostring(math.floor(diffTime*60)).."分钟前"
    else
        Str_Text = "刚刚"
    end
	self.lab_time:setText(Str_Text)
	self.lab_who:setText(_data.name.."申请添加您为好友")
	self.item_data = _data
	table.insert(all_data, _data)
end