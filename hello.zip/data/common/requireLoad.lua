RequireLoad = class("RequireLoad")

function RequireLoad:create(cmdName, cbFunc)
	local objRequireLoad = RequireLoad.new()	
	objRequireLoad:init(cmdName, cbFunc)
	return objRequireLoad
end

function RequireLoad:init(cmdName, cbFunc)
	self.container = CCArray:create()
	self.container:retain()
	
	self.cmdName = cmdName
	self.cbFunc = cbFunc
	
	Global:RegisterCmd( cmdName, cbFunc )	
end

--[[
Global:RegisterCmd( "registerTestCmd", "registerTestCmd()" )
Global:DispatchCmd( "registerTestCmd" )
]]--

function RequireLoad:uninit()
	Global:UnregistCmd( self.cmdName, self.cbFunc )	
	self.container:release()
end

function RequireLoad:require(filename)
	local cFilename = CCString:create(filename)
	self.container:addObject( cFilename )
end

function RequireLoad:start()
	Global:requireLoad(self.container, self.cmdName)
end
