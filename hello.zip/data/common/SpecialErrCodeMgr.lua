--
-- Author: lvgansheng
-- Date: 2014-12-03 12:26:54
-- 特殊错误码处理
require "role_pb"

SpecialErrCodeMgr = class("SpecialErrCodeMgr")

local _instance = nil
local _allowInstance = false

function SpecialErrCodeMgr:ctor()
    if not _allowInstance then
        error("SpecialErrCodeMgr is a singleton class,please call getInstance method")
    end
end

function SpecialErrCodeMgr:getInstance()
    if _instance == nil then
        _allowInstance = true
        _instance = SpecialErrCodeMgr.new()
        _allowInstance = false
    end
    return _instance
end

--是否特殊错误码
function SpecialErrCodeMgr:isSpecialErrCode(err_code)
	if err_code==error_code_pb.msg_ret.err_task_reward_picked or --任务重复领取
		err_code==error_code_pb.msg_ret.err_eqm_not_found or  --找不到装备
		err_code==error_code_pb.msg_ret.err_item_illegal or --非法物品
		err_code==error_code_pb.msg_ret.err_zone_role_not_login then --顶号或者未登陆
		return true
	end

	return false
end

-- 重新请求某些数据，同步客户端服务端数据
function SpecialErrCodeMgr:dealSpecialErrCode(err_code)
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.role_fix_info_req+1, "onGetFixInfoRsp()")

	local role_fix_info_req = role_pb.role_fix_info_req()
	
	if err_code==error_code_pb.msg_ret.err_task_reward_picked then
		table.insert(role_fix_info_req.types,4)
		ComSender:getInstance():send(proto_cmd_pb.msg_cmd.role_fix_info_req,role_fix_info_req)
	elseif err_code==error_code_pb.msg_ret.err_eqm_not_found then

        table.insert(role_fix_info_req.types,2)
        table.insert(role_fix_info_req.types,3)
		ComSender:getInstance():send(proto_cmd_pb.msg_cmd.role_fix_info_req,role_fix_info_req)
	elseif err_code==error_code_pb.msg_ret.err_item_illegal then
		-- local type_one = role_fix_info_req.types:add()
		-- type_one = 2
        table.insert(role_fix_info_req.types,2)
		ComSender:getInstance():send(proto_cmd_pb.msg_cmd.role_fix_info_req,role_fix_info_req)
	elseif err_code==error_code_pb.msg_ret.err_zone_role_not_login then
		WindowCtrl:getInstance():closeAllWin()
		local params = {}
        params["txt"] = "您的帳號需要重新登錄。"
        params["isSingleBtn"] = 1
        params.okFunc = function()
			-- SceneCtrl:getInstance():goToScene(CmdName.LOGIN_SCENE)
            SceneCtrl:getInstance():reLogin()
        end
        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
    elseif err_code==error_code_pb.msg_ret.err_zone_role_no_login then --玩家封号处理
        WindowCtrl:getInstance():closeAllWin()
        local params = {}
        params["txt"] = "您的帳號出現異常，已被封號。\n如有問題請聯繫客服處理。"
        params["isSingleBtn"] = 1
        params.okFunc = function()
            SceneCtrl:getInstance():reLogin()
        end
        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
	end

end

function onGetFixInfoRsp(pbPkgData)
	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.role_fix_info_req+1, "onGetFixInfoRsp()")

    local role_fix_info_rsp = role_pb.role_fix_info_rsp()

    role_fix_info_rsp:ParseFromString(pbPkgData)
	if role_fix_info_rsp.ret ~= error_code_pb.msg_ret.success then
        cclog("role_fix_info_rsp fail,i don't know why---%d",role_fix_info_rsp.ret)
        return 
    end    

    for i,type_one in pairs(role_fix_info_rsp.types) do
    	if type_one==2 then
	    	--客户端主动删除所有物品
	        local backpackItemTab = ItemManager:getInstance().backpackItemTab
	        local delItemTab = {}
	        for i,v in pairs(backpackItemTab) do
	             table.insert(delItemTab, i)
	        end
	        ItemManager:getInstance():delMultiItem(delItemTab)

	        --添加物品
	        ItemManager:getInstance():addMultiItem(role_fix_info_rsp.bag_info.items)
    	elseif type_one==3 then

    		--清空本地装备记录
    		ItemManager:getInstance():clearAllEqm()
    		HeroManager:getInstance():setHeroAllEqms(role_fix_info_rsp.eqm_info.eqms)
    	elseif type_one==4 then

    		--重置任务信息
    		TaskManager:getInstance():initTaskInfo(role_fix_info_rsp.task_info.tasks, 
    			role_fix_info_rsp.task_info.done_tasks , role_fix_info_rsp.task_info.future_tasks)
    	end
    end

    -- 直接关闭当前所有界面
    WindowCtrl:getInstance():closeAllWin()
end