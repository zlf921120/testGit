--
-- Author: lvgansheng
-- Date: 2014-07-25 21:23:57
-- 通用资源管理器

require "BattleManager"

ComResMgr = class("ComResMgr")
ComResMgr.xlsDataList = {}
local res_path_arr = nil

local _instance = nil
local _allowInstance = false

local init_res_arr = {}
table.insert(init_res_arr,{"ui/common/common.plist","ui/common/common.png"})
-- table.insert(init_res_arr,{"ui/common/common_temp.plist","ui/common/common_temp.png"})

function ComResMgr:ctor()
    if not _allowInstance then
        error("ComResMgr is a singleton class,please call getInstance method")
    end

    self._onClearCache = function()
        self:clearCache()
    end

    res_path_arr = {}
    TimerManager.addTimer(60000,self._onClearCache,true) --每2分钟清理一次
end

function ComResMgr:getInstance()
    if _instance == nil then
        _allowInstance = true
        _instance = ComResMgr.new()
        _allowInstance = false
    end
    return _instance
end

function ComResMgr:loadRes(plist_path,img_path)
    if plist_path == nil or plist_path == "" then
        return 
    end

    if res_path_arr[plist_path] then --已经加载过
        return
    end

    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile(plist_path, img_path)
    res_path_arr[plist_path] = true
end

--预加载资源
function ComResMgr:loadInitRes()
    for i,v in pairs(init_res_arr) do
        self:loadRes(v[1],v[2])
    end
end

function ComResMgr:loadOtherRes(plist_path,img_path)
     self:loadRes("ui/common/other.plist","ui/common/other.pvr.ccz")
end

function ComResMgr:loadResByName(plist_path,img_path)
     self:loadRes(plist_path,img_path)
end

function ComResMgr:loadResWithPlist(path)
    if res_path_arr[path] then --已经加载过
        return
    end

    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile(path)
    res_path_arr[path] = true
end

function ComResMgr:remove(plist_path,img_path)
    res_path_arr[plist_path] = nil
    CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile(plist_path)
end

function ComResMgr:clearCache()
    -- 战斗中，不清空缓存，防止技能卡顿
    if BattleManager:getInstance():isBattle() then
        return
    end
    CCTextureCache:sharedTextureCache():removeUnusedTextures()
end

function ComResMgr:getXlsDataById(id)
    return self.xlsDataList[ id ]
end
