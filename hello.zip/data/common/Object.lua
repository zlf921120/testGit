Object = {}
--[[
	作为基类被继承
	创建对象
	
	create作为工厂的new方法，派生类请按照这个规范命名，类似于cocos2d的create和createWith的格式
	
	派生类的示例
	Vector2 = {}
	Vector2.create = function()
		local this = Object.create()--相当于调度基类的构造方法
		this.Class = Vector2
		--todo 派生类的定义
		this.x = 10
		this.y = 20
		this.update = function(this , t)
			--todo
			this.x = this.x + 1
		end
		return this
	end
	
	override的示例
	Vector3 = {}
	Vector3.create = function()
		local this = Vector2.create()--调用基类的构造方法
		this.Class = Vector3
		this.z = 0
		
		--这里相当于于override了基类的update方法
		local super_update = this.update
		this.update = function(this ,t)
			--调用基类的方法，如果必要的话
			this:super_update(t)
			--todo
			this.z = this.z + 1
		end
		
		return this
	end	
	
--]]
Object.create = function()
	local this = {}
	this.Class = Object
	this.name = "Object"

	function this.instanceOf(Class)
		return this.Class == Class
	end

	return this
end