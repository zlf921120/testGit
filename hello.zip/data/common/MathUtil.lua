--
-- Author: thisgf
-- Date: 2014-09-14 15:23:30
-- 数学工具类

MathUtil = {}

MathUtil.DEG_BASE = math.pi / 180
MathUtil.RAD_BASE = 180 / math.pi


--[[
    洗乱数组
]]
function MathUtil.shuffleList(list)

	local len = #list

	for i = 1, len do
		local randomIndex = math.random(1, len)

		list[i], list[randomIndex] = list[randomIndex], list[i]
	end

end

--[[
    获取两点之间的弧度
]]
function MathUtil.getAngleWithTwoPoint(a, b)

	local dy = a.y - b.y
	local dx = b.x - a.x

	return math.atan2(dy, dx)

end

--[[
    获取两点之间的距离
]]
function MathUtil.getDistance(pOne, pTwo)

	local dx = math.abs(pTwo.x - pOne.x)
	local dy = math.abs(pTwo.y - pOne.x)

	return math.sqrt(dx * dx, dy * dy)

end

--角度转弧度
function MathUtil.deg2rad(value)
	return value * MathUtil.DEG_BASE
end

--[[
    弧度转角度
]]
function MathUtil.rad2deg(value)
	return value * MathUtil.RAD_BASE
end

--[[
	四舍五入
--]]
function MathUtil.round(value)
	local temp_int_part,temp_dec_part = math.modf(value)

	if  temp_dec_part>= 0.5 then
		return temp_int_part+1
	else
		return temp_int_part
	end
end

function MathUtil.getThreeSectionNum(value)

	local str = tostring(value)

	local len = #str

	local i = len

	local t = {}

	while i > 0 do

		local section = string.sub(str, i - 2, i)

		i = i - 3

		table.insert(t, 1, section)

		str = string.sub(str, 1, i)

	end

	return table.concat(t, ",")
	
end

--获取中间点
function MathUtil.getMiddlePos(p1,p2)
	return ccp( (p1.x + p2.x) / 2, (p1.y + p2.y) / 2 ) 
end

--[[
    获取差距数字列表
    @param rawNum 原数字
    @param newNum 新数字
    @param times 次数
]]
function MathUtil.getDiffNumList(rawNum, newNum, times)

	local diffNum = newNum - rawNum
    local everyNum = math.floor(diffNum * 10 / times) / 10
    if everyNum > 1 then
    	everyNum = math.floor(everyNum)
    end

    local numList = {}
    for i = 1, times - 1 do
    	rawNum = rawNum + everyNum
    	numList[i] = rawNum
    end

    numList[times] = newNum

    return numList

end

function MathUtil.encryptNumber(rawValue, mask)
    
    local iValue = math.floor(rawValue)
    local encryptValue = Global:simpleEncrypt(iValue, mask)

    if iValue == rawValue then
        return encryptValue
    end

    local decimal = string.sub(tostring(rawValue - iValue), 2, -1)

    return string.format("%s%s", encryptValue, decimal)

end

function MathUtil.decryptNumber(encryptValue, mask)

    if not encryptValue then
        return 0
    end

    local _, dotIndex = string.find(encryptValue, ".", 1, true)
    local decryptValue
    if dotIndex then
        decryptValue = Global:simpleDecrypt(string.sub(encryptValue, 0, dotIndex), mask)
    else
        decryptValue = Global:simpleDecrypt(encryptValue, mask)
        return decryptValue
    end

    return tonumber(decryptValue + tonumber(string.sub(encryptValue, dotIndex)))

end
