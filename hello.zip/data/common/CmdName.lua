CmdName = {}

CmdName.finishedBattlePerformEvent = "finishedBattlePerformEvent"

CmdName.inputPassword = "inputPassword"
CmdName.inputSmsCode = "inputSmsCode"
CmdName.loginSuccessSig = "loginSuccessSig"
CmdName.loginFailed = "loginFailed"
CmdName.updateOpenTime = "CmdName.updateOpenTime"

CmdName.ChannelScene = "CmdName.ChannelScene"
CmdName.AdvView = "CmdName.AdvView" --广告层
CmdName.ShowAdvView = "CmdName.ShowAdvView" --展示广告层

CmdName.LOGIN_SCENE = "loginScene" --登录场景
CmdName.LOGIN_FINISH = "CmdName.LOGIN_FINISH" --登录完成 进入游戏

CmdName.UpdateScene = "CmdName.UpdateScene" --登录场景

CmdName.GENDER_SCENE = "genderScene" --性别选择场景
CmdName.NICKNAME_SCENE = "NICKNAME_SCENE" --创建昵称面板

CmdName.REQ_ZONE_LIST = "reqZoneList"

CmdName.MAIN_SCENE = "mainScene" --主场景
CmdName.MAINUI_SHOW_ALERT = "CmdName.MAINUI_SHOW_ALERT" --主场景提示信息
CmdName.MAIN_SHOW_NEWS_TIP = "CmdName.MAIN_SHOW_NEWS_TIP" --主场景展示消息提示
CmdName.MAIN_HIDE_NEWS_TIP = "CmdName.MAIN_HIDE_NEWS_TIP" --主场景展示消息提示
CmdName.MAIN_SHOW_NEWS_ICON = "CmdName.MAIN_SHOW_NEWS_ICON" --主场景展示图标
CmdName.MAIN_HIDE_NEWS_ICON = "CmdName.MAIN_HIDE_NEWS_ICON" --主场景隐藏图标
CmdName.MAIN_SHOW_NEWS_IMG = "CmdName.MAIN_SHOW_NEWS_IMG" --主场景展示New图
CmdName.MAIN_HIDE_NEWS_IMG = "CmdName.MAIN_HIDE_NEWS_IMG" --主场景隐藏New图
CmdName.MAIN_SHOW_ACTIVATE_ITEM = "CmdName.MAIN_SHOW_ACTIVATE_ITEM" --主场景显示 激活项
CmdName.MAIN_HIDE_ACTIVATE_ITEM = "CmdName.MAIN_HIDE_ACTIVATE_ITEM" --主场景隐藏 激活项

CmdName.Character_buyCoin = "CmdName.Character_buyCoin"  --购买金币 场景
CmdName.Character_buyMultCoin = "CmdName.Character_buyMultCoin" --购买 多重金币
CmdName.Character_checkPhysicalScene = "CmdName.Character_checkPhysicalScene" --检查体力 信息

CmdName.SHOW_EVENT = "ShowEvent"
CmdName.SHOW_HOME_PAGE = "ShowHomePage"
CmdName.SHOW_UPGRADE_PAGE = "ShowUpgradePage"
CmdName.SHOW_EVOLUTION_PAGE= "ShowEvolutionPage"
CmdName.SHOW_HEROLIST_PAGE = "ShowHeroListPage"
CmdName.SHOW_HEROINFO_PAGE = "ShowHeroInfoPage"
CmdName.SHOW_BATTLE_ENTRY_PAGE = "ShowBattleEntryPage"
CmdName.SHOW_BATTLE_STORIES_PAGE = "ShowBattleStoriesPage"
CmdName.SHOW_BATTLE_DUNGEONS_PAGE = "ShowBattleDungeonsPage"
CmdName.SHOW_BATTLE_SMASH_PAGE = "ShowBattleSmashPage"
CmdName.SHOW_EVO_HEROLIST_PAGE= "ShowEvoHeroListPage"
CmdName.SHOW_TASKREWARD_PAGE = "ShowTaskRewardPage"
CmdName.SHOW_UPGRADE_HEROLIST_PAGE = "ShowUpgradeHeroListPage"
CmdName.SHOW_SELL_PAGE = "ShowSellPage"
CmdName.SHOW_STORE_PAGE = "ShowStorePage"
CmdName.SHOW_STORE_MONEY_PAGE = "ShowStoreMoneyPage"
CmdName.SHOW_MORE_PAGE = "ShowMorePage"
CmdName.SHOW_FRIEND_LIST = "ShowFriendList"

--人物事件 begin

--通知登录成功, 进去主界面
CmdName.RSP_LOGIN_SUCCESS = "CharacterEvent.RSP_LOGIN_SUCCESS"

--通知登录失败
CmdName.RSP_LOGIN_FAIL = "CharacterEvent.RSP_LOGIN_FAIL"
--通知获取到角色信息
CmdName.RSP_GET_ROLE_INFO = "CharacterEvent.RSP_GET_ROLE_INFO"
CmdName.RSP_UPDATE_ROLE_INFO = "CharacterEvent.RSP_UPDATE_ROLE_INFO" --更新

--通知更新角色资产
CmdName.RSP_UPDATE_ROLE_ASSET = "CharacterEvent.RSP_UPDATE_ROLE_ASSET"

--通知更新战队信息
CmdName.CHARACTER_RSP_UPDATE_TEAM = "CharacterEvent.RSP_UPDATE_TEAM"

--人物事件 end

--背包相关事件
CmdName.BACKPACK_INIT = "BackPackEvent.BackPackinit" -- 初始化背包
CmdName.BACKPACK_ADD = "BackPackEvent.BackPackAdd" --背包增加物品,有可能是从无到有，也有可能只是数量+1
CmdName.BACKPACK_UPDATE = "BackPackEvent.BackPackUpdate" --背包物品数量变化
CmdName.BACKPACK_DEL = "BackPackEvent.BackPackDel" --删除物品
CmdName.UseItemSuccess = "BackPackEvent.UseItemSuccess" --使用物品
CmdName.BagAddNewEqmItem = "BackPackEvent.BagAddNewEqmItem" --背包物品从无到有,而且新增的是装备

--装备相关事件
CmdName.EqmInfoUpdate = "EquipEvent.EqmInfoUpdate" --在选择界面点击响应装备后，通知装备界面更新
CmdName.ChangeItemStorage = "EquipEvent.ChangeItemStorage" -- 测试用事件，从背包中移除物品并添加到装备列表，模拟服务端的过程
CmdName.CtrlRoleLeftPanel =  "EquipEvent.CtrlRoleLeftPanel" -- 通知角色界面右边部分显示相应窗体，根据参数显示
CmdName.EqmPoweredSuccess =  "EquipEvent.EqmPoweredSuccess" -- 装备强化成功
CmdName.EnchantSuccess =  "EquipEvent.EnchantSuccess" -- 装备附魔成功
CmdName.EqmEnchantEnergy =  "EquipEvent.EqmEnchantEnergy" -- 装备附魔时选择一个物品
CmdName.IdentifySuccess =  "EquipEvent.IdentifySuccess" -- 装备鉴定成功
CmdName.IdentifyResesSuc = "CmdName.IdentifyResesSuc" --装备重置成功
CmdName.IdentifyAttrLockSuc = "CmdName.IdentifyAttrLockSuc" --装备鉴定属性锁定/解锁成功
CmdName.GemSuccess =  "EquipEvent.GemSuccess" -- 宝石镶嵌成功
CmdName.GemSuccessMsgShow =  "EquipEvent.GemSuccessMsgShow" -- 宝石镶嵌成功显示的信息
CmdName.GemOffSuccess =  "EquipEvent.GemSuccess" -- 宝石摘除成功
CmdName.GemUpgradeSuccess =  "EquipEvent.GemSuccess" -- 宝石升级成功
CmdName.SimuClickOnGemSlot =  "EquipEvent.SimuClickOnGemSlot" -- 模拟点击某个宝石槽
CmdName.Eqm_UnLocked = "CmdName.Eqm_UnLocked" -- 装备点击操作解锁
CmdName.EqmBatchPoweredSucc = "CmdName.EqmBatchPoweredSucc" -- 装备批量强化成功
CmdName.EqmCommAnimPanel = "CmdName.EqmCommAnimPanel" --装备动画层
CmdName.HeroFullCardAnimPanel = "CmdName.HeroFullCardAnimPanel" --英雄动画层
CmdName.EqmIdentifyResetPanel = "CmdName.EqmIdentifyResetPanel" --鉴定重置面板
CmdName.GuideHeroAnimScene = "CmdName.GuideHeroAnimScene" --获得新英雄
CmdName.FashionUpgradePanel = "CmdName.FashionUpgradePanel" --时装进阶面板
CmdName.FashionAdditionView = "CmdName.FashionAdditionView" --时装加成面板
CmdName.Update_Fashion_Star = "CmdName.Update_Fashion_Star" --时装进阶
CmdName.Update_Fashion_Upgrade = "CmdName.Update_Fashion_Upgrade" --更新时装进阶面板
CmdName.Fashion_Skin_Select_Item = "CmdName.Fashion_Skin_Select_Item" --选中焦点时装
CmdName.Upadate_Fashion_Skin = "CmdName.Upadate_Fashion_Skin"
CmdName.IntroTips = "CmdName.IntroTips" --简介 提示
CmdName.HeroUpgradePreview = "CmdName.HeroUpgradePreview" --英雄进阶预览
--窗体相关事件

CmdName.WINDOW_CLOSE_ALL = "WindowEvent.CLOSE_ALL"   --所有窗口关闭

CmdName.Hero_View = "CmdName.Hero_View" --角色界面
CmdName.BACKPACK_VIEW = "CmdName.BACKPACK_VIEW" --背包
CmdName.BACKPACK_SELL_VIEW = "CmdName.BACKPACK_SELL_VIEW" --背包物品出售界面
CmdName.Shop_View = "CmdName.Shop_View" --商店界面
CmdName.Shop_View_GoodsInfo = "CmdName.Shop_View_GoodsInfo" --商店 商品介绍
CmdName.Mail_View = "CmdName.Mail_View" --信件界面
CmdName.Chat_View = "CmdName.Chat_View" --聊天界面
CmdName.Chat_View_FacePanel = "CmdName.Chat_View_FacePanel" --聊天表情 面板
--公会相关
CmdName.Guild_View_Public = "CmdName.Guild_View_Public"  --公会界面 的 公开场景 部分
CmdName.Guild_View_Member = "CmdName.Guild_View_Member"  --公会界面 的 内部场景 部分
CmdName.Guild_View_Permission = "CmdName.Guild_View_Permission" --公会界面 的 会长权限面板
CmdName.Guild_View_Boss = "CmdName.Guild_View_Boss" --公会Boss 场景
CmdName.Guild_View_BossOpen = "CmdName.Guild_View_BossOpen" --公会Boss 开启面板
CmdName.Guild_View_BossPerpare = "CmdName.Guild_View_BossPerpare" --公会Boss 战斗预备面板
CmdName.Guild_View_Skill = "CmdName.Guild_View_Skill" --公会技能 场景
CmdName.Guild_View_Skill_Guild = "CmdName.Guild_View_Skill_Guild" --公会技能 升级
CmdName.Guild_View_AuctionPanel = "CmdName.Guild_View_AuctionPanel" --公会竞拍 场景
CmdName.Guild_View_GuildInfoPanel = "CmdName.Guild_View_GuildInfoPanel" --公会信息 面板
CmdName.Guild_View_DonatePanel = "CmdName.Guild_View_DonatePanel" --公会捐献 面板
CmdName.Guild_View_DescWorship = "CmdName.Guild_View_DescWorship" --内部公会 的 膜拜大神面板
CmdName.Guild_View_ChoiceWorship = "CmdName.Guild_View_ChoiceWorship" --内部公会 的 选择膜拜面板
CmdName.Guild_View_GivePhysical = "CmdName.Guild_View_GivePhysical" --内部公会 的 互赠体力面板
CmdName.Guild_View_LogoPanel_create = "CmdName.Guild_View_LogoPanel_create" --公会图标面板 创建
CmdName.Guild_View_LogoPanel_edit = "CmdName.Guild_View_LogoPanel_edit"  --公会图标面板 修改
CmdName.Guild_View_EditMember = "CmdName.Guild_View_EditMember" --内部公会 修改成员 面板
CmdName.Guild_View_MEMBMER_ALL_GUILD = "CmdName.Guild_View_MEMBMER_ALL_GUILD" --内部公会 查看所有公会
CmdName.Guild_View_BossDesc = "CmdName.Guild_View_BossDesc" --boss规则
CmdName.Guild_View_FightScene = "CmdName.Guild_View_FightScene" --公会战 场景
CmdName.Guild_View_SignupView = "CmdName.Guild_View_SignupView" --公会战 报名面板
CmdName.Guild_View_FightPerpare = "CmdName.Guild_View_FightPerpare" --公会战 备战面板
CmdName.Guild_View_FightBattle = "CmdName.Guild_View_FightBattle" --公会战 挑战场景
CmdName.Guild_View_FightEdit = "CmdName.Guild_View_FightEdit" --公会战 修改 玩家备战位置
CmdName.Guild_View_Log = "CmdName.Guild_View_Log" --公会日志 面板
CmdName.Guild_View_CheerView = "CmdName.Guild_View_CheerView" --公会战 助威
CmdName.Guild_View_FightScorePanel = "CmdName.Guild_View_FightScorePanel" --公会战 成绩面板
CmdName.Guild_View_FightSchePanel = "CmdName.Guild_View_FightSchePanel" --公会战 日程面板
CmdName.Guild_View_PerpareFinish = "CmdName.Guild_View_PerpareFinish" --公会战 备战成功 提示
CmdName.Guild_View_SignupList = "CmdName.Guild_View_SignupList" --公会战 报名列表
CmdName.Guild_View_GloryPanel = "CmdName.Guild_View_GloryPanel" --公会战 荣耀面板
CmdName.Guild_View_GloryAllotPanel = "CmdName.Guild_View_GloryAllotPanel" --公会战 战利物品分配
CmdName.Guild_View_PerviewGiftView = "CmdName.Guild_View_PerviewGiftView" --公会战 战力物品预览面板
CmdName.Guild_View_RankView = "CmdName.Guild_View_RankView" --公会战 排行榜

CmdName.Tower_Scene = "CmdName.Tower_Scene" --永恒之塔
CmdName.Tower_Scene_Perpare = "CmdName.Tower_Scene_Perpare" --预备 进入塔 
CmdName.Tower_Scene_DescPanel = "CmdName.Tower_Scene_DescPanel" --爬塔描述 面板
CmdName.Tower_Scene_ResetPanel = "CmdName.Tower_Scene_ResetPanel" --爬塔 重置
CmdName.Tower_Scene_BoxPanel = "CmdName.Tower_Scene_BoxPanel" --爬塔宝箱 面板

CmdName.Glory_Scene = "CmdName.Glory_Scene" --荣耀之路
CmdName.Glory_Scene_DescPanel = "CmdName.Glory_Scene_DescPanel" --荣耀 描述 面板
CmdName.Glory_Scene_Enemy = "CmdName.Glory_Scene_Enemy"  --荣耀 敌人战队 面板
CmdName.Glory_RankPanel = "CmdName.Glory_RankPanel" --排行面板
CmdName.Glory_RankItemView = "CmdName.Glory_RankItemView" --排名条目

CmdName.Lottery_Scene = "CmdName.Lottery_Scene" --宝箱 抽奖场景
CmdName.Lottery_Result = "CmdName.Lottery_Result" --宝箱 抽奖结果
CmdName.Lottery_Scene_DropPanel = "CmdName.Lottery_Scene_DropPanel" --宝箱掉落 面板

CmdName.Comm_MsgBox = "CmdName.Comm_MsgBox" --通用 的 消息框
CmdName.Comm_PlayerInfo = "CmdName.Comm_PlayerInfo" --通用 的 玩家信息框
CmdName.Comm_Activate = "CmdName.Comm_Activate" --激活新功能提示面板
CmdName.Comm_Guide = "CmdName.Comm_Guide" --新手引导面板
CmdName.Comm_ItemInfo = "CmdName.Comm_ItemInfo" --通用物品展示面板
CmdName.Comm_DescPanel = "CmdName.Comm_DescPanel" --通用 描述面板

CmdName.Notice_Scene = "CmdName.Notice_Scene" --公告 面板

CmdName.Friend_View = "CmdName.Friend_View" --好友界面
CmdName.Request_View = "CmdName.Request_View" --添加好友界面

CmdName.Vip_View = "CmdName.Vip_View" --vip 面板
CmdName.Vip_Gift_View = "CmdName.Vip_Gift_View" --vip 礼包面板

CmdName.Pet_View = "CmdName.Pet_View" --宠物 面板
CmdName.Pet_View_Upgrade = "CmdName.Pet_View_Upgrade" --宠物 升阶
CmdName.Pet_View_Levup = "CmdName.Pet_View_Levup" --宠物 升级
CmdName.Pet_View_EidtName = "CmdName.Pet_View_EidtName" --宠物 修改名字

CmdName.Sign_View = "CmdName.Sign_View" --签到页面 
CmdName.Sign_View_DescPanel = "CmdName.Sign_View_DescPanel" --签到说明 面板
CmdName.Sign_View_GoodsInfo = "CmdName.Sign_View_GoodsInfo" --签到物品 描述 面板
CmdName.Sign_View_RewardInfo = "CmdName.Sign_View_RewardInfo" --签到奖励 面板

CmdName.FbReward_View = "CmdName.FbReward_View" --FB好友列表页面

CmdName.Reward_Scene = "CmdName.Reward_Scene" --奖励发放
CmdName.Reward_MuilItemPanel = "CmdName.Reward_MuilItemPanel" --大量物品展示
CmdName.Reward_GuildGiftPanel = "CmdName.Reward_GuildGiftPanel" --大量公会战 物品展示
CmdName.Reward_MultGiftPanel = "CmdName.Reward_MultGiftPanel" --大量物品 预览
CmdName.Reward_FirstRechargeView = "CmdName.Reward_FirstRechargeView" --首冲奖励面板

CmdName.FestivalView = "CmdName.FestivalView" --节日活动

CmdName.Eqm_Forge_View = "CmdName.Eqm_Forge_View" --装备锻造界面
CmdName.Hero_List_View = "CmdName.Hero_List_View" --卡牌列表界面
CmdName.EqmOnConfirmView =  "EquipEvent.EqmOnConfirmView" -- 通知角色界面右边部分显示相应窗体，根据参数显示
CmdName.EqmExchView = "CmdName.EqmExchView" --锻造物品选择界面
CmdName.EqmUpgradeSuc = "CmdName.EqmUpgradeSuc" --装备升级成功
CmdName.Dungeon_View = "CmdName.Dungeon_View" --副本界面
CmdName.DungeonPerpare = "CmdName.DungeonPerpare" --副本预备入口界面
CmdName.Dungeon_Raids_View = "CmdName.Dungeon_Raids_View" --副本扫荡界面
CmdName.Dungeon_Clearance_View = "CmdName.Dungeon_Clearance_View" --副本通关界面
CmdName.Dungeon_Box_View = "CmdName.Dungeon_Box_View" --副本通关宝箱奖励
CmdName.Dungeon_Teasure_Desc = "CmdName.Dungeon_Teasure_Desc" --宝藏副本描述面板
CmdName.Team_View = "CmdName.Team_View" --战队界面
CmdName.Task_View = "CmdName.Task_View" --任务界面
CmdName.New_Task_View = "CmdName.New_Task_View" --接新任务的界面
CmdName.Finish_Task_View = "CmdName.Finish_Task_View" --完成任务时弹出的界面
CmdName.Arena_View = "CmdName.Arena_View" --竞技场主界面
CmdName.Arena_Rule_View = "CmdName.Arena_Rule_View" --竞技场规则界面
CmdName.Arena_Rank_View = "CmdName.Arena_Rank_View" --竞技场排行榜界面
CmdName.Arena_Record_View = "CmdName.Arena_Record_View" --竞技场战斗记录界面
CmdName.Skywar_View = "CmdName.Skywar_View" --天空之役主界面
CmdName.Skywar_Rule_View = "CmdName.Skywar_Rule_View" --天空之役规则界面
CmdName.Skywar_Rank_View = "CmdName.Skywar_Rank_View"  --天空之役排行榜界面
CmdName.Skywar_Season_View = "CmdName.Skywar_Season_View"  --天空之役赛程界面
CmdName.Skywar_Division_View = "CmdName.Skywar_Division_View" --天空之役段位界面
CmdName.Skywar_Match_View = "CmdName.Skywar_Match_View"  --天空之役匹配界面
CmdName.FindSoulGemView = "CmdName.FindSoulGemView" --寻找灵魂石引导界面
CmdName.FindEqmView = "CmdName.FindEqmView" --寻找装备引导界面
CmdName.ItemUpgradeView = "CmdName.ItemUpgradeView" --背包中装备升级
CmdName.GetSkillPointView = "CmdName.GetSkillPointView" --寻找技能点引导界面
CmdName.OtherRoleInfoView = "CmdName.OtherRoleInfoView" --其它玩家详细信息的界面
CmdName.TeamLevUpView = "CmdName.TeamLevUpView" -- 战队升级界面
CmdName.ChangeHeadView = "CmdName.ChangeHeadView" --设置头像界面
CmdName.EqmBatchPoweredView = "CmdName.EqmBatchPoweredView" --批量强化界面
CmdName.SystemSettingView = "CmdName.SystemSettingView" --系统设置界面
CmdName.ChatBlackListView = "CmdName.ChatBlackListView" --聊天黑名单界面
CmdName.BatchUseItemView = "CmdName.BatchUseItemView" --批量使用物品界面

CmdName.SecretView = "CmdName.SecretView" --解密副本
CmdName.SecretPerpareView = "CmdName.SecretPerpareView" --预备战斗
CmdName.SecretDiffChoice = "CmdName.SecretDiffChoice" --选择难度
CmdName.SecretRewardPanel = "CmdName.SecretRewardPanel" --奖励领取
CmdName.SecretFobidView = "CmdName.SecretFobidView" --禁止提示

CmdName.RES_CONTEND_DESC_VIEW = "CmdName.RES_CONTEND_DESC_VIEW" --资源争夺描述界面
CmdName.RES_CONTEND_GUARD_VIEW = "CmdName.RES_CONTEND_GUARD_VIEW" --资源争夺守卫界面
CmdName.RES_CONTEND_RULE_VIEW = "CmdName.RES_CONTEND_RULE_VIEW"  --资源争夺规则界面
CmdName.RES_CONTEND_RECORD_VIEW = "CmdName.RES_CONTEND_RECORD_VIEW" --资源争夺记录界面
CmdName.RES_CONTEND_OT_VIEW = "CmdName.RES_CONTEND_OT_VIEW" --资源争夺占领界面
CmdName.RES_CONTEND_SG_VIEW = "CmdName.RES_CONTEND_SG_VIEW" --资源争夺展示守卫界面
CmdName.RES_CONTEND_ATTR_VIEW = "CmdName.RES_CONTEND_ATTR_VIEW" --资源争夺所有属性界面
CmdName.RES_CONTEND_NG_VIEW = "CmdName.RES_CONTEND_NG_VIEW" --资源争夺新守卫展示界面
CmdName.RES_CONTEND_DF_RULE_VIEW = "CmdName.RES_CONTEND_DF_RULE_VIEW" --资源争夺驻守规则界面
CmdName.GemSuitDetailView = "CmdName.GemSuitDetailView" --宝石套详细信息界面
CmdName.EnchantSuitDesc = "CmdName.EnchantSuitDesc" --附魔套 描述面板

--战斗相关事件 begin

CmdName.BATTLE_RSP_START = "BattleRspEvent.RSP_BATTLE_START"

--战斗结束
CmdName.BATTLE_RSP_END = "BattleRspEvent.RSP_BATTLE_END"

--中途获取到宝石
CmdName.BATTLE_RSP_GET_GEM = "BattleRspEvent.RSP_GET_GEM"

--通知战斗结果
--@data BattleResultData
CmdName.BATTLE_RSP_RESULT = "BattleRspEvent.RSP_RESULT"

CmdName.FINISH_CURRENT_BATTLE_SCENE = "finishCurrentBattleScene"

--副本抽奖返回
CmdName.BATTLE_PAY_LOTTERY_RSP = "BattleRspEvent.RSP_PAY_LOTTERY"

--操作石头是否可用(param:true/false)
CmdName.BATTLE_CONTROL_STONE = "BattleEvent.CONTROL_STONE"

--更新自动战斗状态
CmdName.BATTLE_UPDATE_AUTO_PLAY = "BattleEvent.UPDATE_AUTO_PLAY"

--请求打开统计界面
CmdName.BATTLE_OPEN_STATISTIC_VIEW = "BattleEvent.OPEN_STATISTIC_VIEW"

--请求播报时回合结束
CmdName.BATTLE_REQ_ROUND_END = "BattleEvent.REQ_ROUND_END"

--回合更新
CmdName.BATTLE_UPDATE_ROUND = "BattleEvent.UPDATE_ROUND"

--波数更新
CmdName.BATTLE_UPDATE_WAVE = "BattleEvent.UPDATE_WAVE"

--处理死亡过程的参战者结束
CmdName.BATTLE_HANDLE_DEAD_PROCESS_END = "BattleEvent.HANDLE_DEAD_PROCESS_END"

--参战者播报完成
CmdName.BATTLE_FIGHTER_BROADCAST_END = "BattleEvent.FIGHTER_BROADCAST_END"

--更新敌人受击次数
CmdName.BATTLE_UPDATE_ENEMY_HURT_TIMES = "BattleEvent.UPDATE_ENEMY_HURT_TIMES"

--更新暂停状态
CmdName.BATTLE_UPDATE_PAUSE_STATUS = "BattleEvent.UPDATE_PAUSE_STATUS"

--更新加速
CmdName.BATTLE_UPDATE_ACCELERATE = "BattleEvent.BATTLE_UPDATE_ACCELERATE"

--战斗相关事件 end


--英雄界面相关事件
CmdName.HeroInfoInit = "CmdName.HeroInfoInit" -- 收到服务端的卡牌列表时，通知界面初始化
CmdName.UpdateHeroListView = "CmdName.UpdateHeroListView" --卡牌列表有改变，一般是新增卡牌时通知
CmdName.UpdateHeroInfo = "CmdName.UpdateHeroInfo" --单个卡牌信息有改变，一般是等级/星级/经验变化
CmdName.HeroSkillUpgradeSuccess = "HeroEvent.HeroSkillUpgradeSuccess" --技能升级相关
CmdName.HeroUpgradeSuccess = "HeroEvent.HeroUpgradeSuccess" --英雄进阶成功
CmdName.HeroAddExpSuc = "HeroEvent.HeroAddExpSuc" --英雄使用经验药成功
CmdName.InitBattleHeroEqm = "HeroEvent.InitBattleHeroEqm" --初始化上阵英雄装备
CmdName.HeroAdvInfoView = "CmdName.HeroAdvInfoView" --英雄高级属性

--副本事件 begin
--初始化副本进度
CmdName.DUNGEON_INIT_SCHEDULE = "DungeonRspEvent.DUNGEON_INIT_SCHEDULE"  
--更新单个副本进度
CmdName.DUNGEON_UPDATE_ONE_SCHEDULE = "DungeonRspEvent.DUNGEON_UPDATE_ONE_SCHEDULE"
CmdName.DUNGEON_UPDATE_REARDBOX = "CmdName.DUNGEON_UPDATE_REARDBOX"
--更新资源本进度
CmdName.DUNGEON_UPDATE_RES_SCHEDULE = "DungeonRspEvent.UPDATE_RES_SCHEDULE"
--扫荡通知
--@data DungeonRaidsRewardVO nil 表示扫荡失败
CmdName.DUNGEON_UPDATE_RAIDS = "CmdName.DUNGEON_UPDATE_RAIDS"
CmdName.DUNGEON_CB_CLOSE_BOX = "CmdName.DUNGEON_CB_CLOSE_BOX"
CmdName.DUNGEON_SHOW_LOTTERY = "CmdName.DUNGEON_SHOW_LOTTERY"
CmdName.DUNGEON_UPDATE_DESC = "CmdName.DUNGEON_UPDATE_DESC"
CmdName.DUNGEON_UPDATE_PERPARE = "CmdName.DUNGEON_UPDATE_PERPARE"
--副本事件 end

--队伍事件 begin

CmdName.TEAM_INIT_BASE = "TeamRspEvent.TEAM_INIT_BASE" --初始化战斗基础信息

CmdName.TEAM_INIT_HERO = "TeamRspEvent.TEAM_INIT_HERO"  --初始化战队英雄信息

CmdName.TEAM_ADD_HERO = "TeamRspEvent.TEAM_ADD_HERO"   --添加英雄数据(data:heroDataList)

CmdName.TEAM_INIT_SKILL = "TeamRspEvent.TEAM_INIT_SKILL"  --初始化技能数据
CmdName.Guild_Exit = "CmdName.Guild_Exit" --退出公会响应

--添加出战英雄(data {pos, TeamHeroVO})
CmdName.TEAM_ADD_HERO_BATTLE = "TeamEvent.ADD_HERO_BATTLE"

--删除出战英雄(data {pos})
CmdName.TEAM_REMOVE_HERO_BATTLE = "TeamEvent.REMOVE_HERO_BATTLE"

--请求出战失败
CmdName.TEAM_ADD_HERO_BATTLE_FAIL = "TeamEvent.ADD_HERO_BATTLE_FAIL"

--添加助阵英雄(data {pos, TeamHeroVO})
CmdName.TEAM_ADD_HERO_STANDBY = "TeamEvent.ADD_HERO_STANDBY"

--请求助阵失败
CmdName.TEAM_ADD_HERO_STANDBY_FAIL = "TeamEvent.ADD_HERO_STANDBY_FAIL"

CmdName.TEAM_REMOVE_HERO_STANDBY = "TeamEvent.REMOVE_HERO_STANDBY"

--升级技能通知(data skillId)
CmdName.TEAM_UPGRADE_SKILL_RSP = "TeamEvent.RSP_UPGRADE_SKILL"

--服务端通知修改出阵/助阵英雄列表成功
CmdName.TEAM_UPGRADE_HERO_SUCCESS = "TeamEvent.UPGRADE_HERO_SUCCESS"
--战队面板 关闭
CmdName.Team_View_Close = "CmdName.Team_View_Close"
--更新队伍战斗力
CmdName.Team_Fc_Update= "CmdName.Team_Fc_Update"

--队伍事件 end=======

--任务相关
CmdName.InitTaskList = "CmdName.InitTaskList" --初始化任务列表
CmdName.AddTask = "CmdName.AddTask" --增加新任务
CmdName.UpdateTask = "CmdName.UpdateTask" --更新任务状态
CmdName.UpdateTaskView = "CmdName.UpdateTaskView" --更新任务界面

--竞技场相关
CmdName.Arena_Base_Update = "ArenaEvent.Arena_Base_Update" --刷新主界面次数跟剩余时间等信息
CmdName.Arena_Enemy_Update = "ArenaEvent.Arena_Enemy_Update" --刷新主界面的三个可挑战信息
CmdName.Arena_init = "ArenaEvent.Arena_init" --初始化竞技场信息
CmdName.Arena_rank_update = "ArenaEvent.Arena_rank_update" --更新竞技场排行榜信息
CmdName.Arena_record_update = "ArenaEvent.Arena_record_update" --更新竞技场战斗记录

--好友相关
CmdName.Friend_View_update = "Friend_View_update" --刷新好友列表
CmdName.Friend_View_check = "Friend_View_check" --查找好友列表
CmdName.Friend_Add_Friend = "Friend_Add_Friend" --添加好友
CmdName.Friend_New_Friend = "Friend_New_Friend" --有新好友
CmdName.Friend_Oper_Friend = "Friend_Oper_Friend" --操作好友（同意或者拒绝）
CmdName.Friend_Check_Event = "Friend_Check_Event" --打开通用信息面板交互
CmdName.Friend_Update_Request = "Friend_Update_Request" --操作好友需求后刷新——新好友列表
CmdName.Friend_Refresh_SendPhy = "Friend_Refresh_SendPhy" --成功赠送体后刷新

--天空之役相关
CmdName.Skywar_Winer_Reward = "CmdName.Skywar_Winer_Reward"
CmdName.Skywar_Season_Reward = "CmdName.Skywar_Season_Reward"
CmdName.Skywar_Base_Update = "CmdName.Skywar_Base_Update"  --更新界面
CmdName.Skywar_Rank_Update = "CmdName.Skywar_Rank_Update"  --更新排行榜
CmdName.Skywar_Signup_Update = "CmdName.Skywar_Signup_Update"  --更新匹配信息
CmdName.Skywar_Cancel_Match = "CmdName.Skywar_Cancel_Match"  --取消匹配
CmdName.Skywar_Match_Success = "CmdName.Skywar_Match_Success"  -- 匹配成功
CmdName.Skywar_Match_Fail = "CmdName.Skywar_Match_Fail"  --匹配失败
CmdName.SKYWAR_REWARD_SUCCESS = "CmdName.SKYWAR_REWARD_SUCCESS"  --领取奖励成功
--mainui相关
CmdName.Main_UI_Init_Success = "CmdName.Main_UI_Init_Success"

--系统设置相关
CmdName.UpdateHeadIconSuc = "CmdName.UpdateHeadIconSuc" --更新头像

--其它
CmdName.LastWaitWinClosed = "WinEvent.LastWaitWinClosed" --队列窗体最后一个关闭了
CmdName.GameStar = "CmdName.GameStar" --相关数据已经装备完毕
CmdName.UpdateGreenTipsPoint = "CmdName.UpdateGreenTipsPoint" --更新tips绿点的状态，隐藏/显示 
CmdName.ERR_SERVER = "CmdName.ERR_SERVER" --网络 有误

--更新系统时间
CmdName.SYSTEM_UPDATE_TIME = "SystemEvent.UPDATE_TIME"

--更新聊天黑名单数据
CmdName.Update_Chat_Black_List = "CmdName.Update_Chat_Black_List"

--添加记录信息
CmdName.ADD_LOG_INFO = "CmdName.ADD_LOG_INFO"

--VIP信息更新
CmdName.VIP_INFO_UPDATE = "CmdName.VIP_INFO_UPDATE";

--更新音效
CmdName.SYSTEM_UPDATE_AUDIO = "SystemEvent.UPDATE_AUDIO"
--更新音乐
CmdName.SYSTEM_UPDATE_MUSIC = "SystemEvent.UPDATE_MUSIC"


--资源争夺事件 start

--初始化守卫
CmdName.RES_CT_INIT_GUARD = "ResCTEvent.INIT_GUARD"

--更新守卫上下阵
CmdName.RES_CT_UPDATE_PUTON_GUARD = "ResCTEvent.UPDATE_PUTON_GUARD"

--上阵守卫
CmdName.RES_CT_PUT_ON = "ResCTEvent.PUT_ON_GUARD"

--下阵守卫
CmdName.RES_CT_GET_OFF = "ResCTEvent.GET_OFF_GUARD"

--获取到副本数据
CmdName.RES_CT_RSP_DUNGEON_DATA = "ResCTEvent.RSP_DUNGEON_DATA"

--更新守卫战斗力
CmdName.RES_CT_UPDATE_GUARD_FC = "ResCTEvent.UPDATE_GUARD_FC"

--更新收获资源
CmdName.RES_CT_UPDATE_GATHER = "ResCTEvent.UPDATE_GATHER"

--更新守卫升阶
CmdName.RES_CT_RSP_UPGRADE_GUARD = "ResCTEvent.RSP_UPGRADE_GUARD"

--更新录像
CmdName.RES_CT_UPDATE_RECORD = "ResCTEvent.UPDATE_RECORD"

--获取到所有的副本数据
CmdName.RES_CT_RSP_ALL_DUNGEON = "ResCTEvent.RSP_ALL_DUNGEON"

--更新绿点
CmdName.RES_CT_UPDATE_GREEN = "ResCTEvent.UPDATE_GREEN"

--资源争夺事件 end
