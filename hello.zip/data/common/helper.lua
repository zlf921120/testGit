CC_CONTENT_SCALE_FACTOR = function()
    return CCDirector:sharedDirector():getContentScaleFactor()
end


CC_POINT_PIXELS_TO_POINTS = function(pixels)
    return ccp(pixels.x/CC_CONTENT_SCALE_FACTOR(), pixels.y/CC_CONTENT_SCALE_FACTOR())
end

CC_POINT_POINTS_TO_PIXELS = function(points)
    return ccp(points.x*CC_CONTENT_SCALE_FACTOR(), points.y*CC_CONTENT_SCALE_FACTOR())
end


-- cclog
cclog = function(...)
    print(string.format(...))
end

require "error_code_pb"
require("SpecialErrCodeMgr")

-- change table to enum type
function CreateEnumTable(tbl, index)
    local enumTable = {}
    local enumIndex = index or -1
    for i, v in ipairs(tbl) do
        enumTable[v] = enumIndex + i
    end
    return enumTable
end

-- back menu callback
local function MainMenuCallback()
    local scene = CCScene:create()
    scene:addChild(CreateTestMenu())

    CCDirector:sharedDirector():replaceScene(scene)
end

-- add the menu item for back to main menu
function CreateBackMenuItem()
    local label = CCLabelTTF:create("MainMenu", "Arial", 20)
    local MenuItem = CCMenuItemLabel:create(label)
    MenuItem:registerScriptTapHandler(MainMenuCallback)

    local s = CCDirector:sharedDirector():getWinSize()
    local Menu = CCMenu:create()
    Menu:addChild(MenuItem)
    Menu:setPosition(0, 0)
    MenuItem:setPosition(s.width - 50, 25)

    return Menu
end

Helper = {
    index = 1,
    createFunctioinTable = nil,
    currentLayer = nil,
    titleLabel = nil,
    subtitleLabel = nil
}

Helper.errMsgDict = 
{
    [error_code_pb.msg_ret.failed] = "操作失敗，請重試",
    [error_code_pb.msg_ret.err_user_acct_duplicated] = "此帳號已存在，請重新註冊",
    [error_code_pb.msg_ret.err_user_acct_not_exists] = "帳號不存在",
    [error_code_pb.msg_ret.err_user_acct_wrong] = "帳號密碼錯誤，登錄失敗",
    [error_code_pb.msg_ret.err_item_illegal] = "非法物品",
    [error_code_pb.msg_ret.err_bag_full] = "背包滿了",
    [error_code_pb.msg_ret.err_not_enough_coin] = "您的金幣不足",
    [error_code_pb.msg_ret.err_not_enough_gold] = "您的鑽石不足",
    [error_code_pb.msg_ret.err_not_enough_item] = "物品不足",
    [error_code_pb.msg_ret.err_lev_max] = "操作物件的等級已滿",
    [error_code_pb.msg_ret.err_not_enough_team_lev] = "您的戰隊等級不足",
    [error_code_pb.msg_ret.err_not_physical] = "體力不足",
    [error_code_pb.msg_ret.err_combat_start] = "啟動戰鬥失敗",
    [error_code_pb.msg_ret.err_combat_no_hero_set] = "沒有設置參戰的英雄",
    [error_code_pb.msg_ret.err_combat_record_expire] = "此戰鬥錄影已過期",
    [error_code_pb.msg_ret.err_eqm_not_found] = "找不到裝備",
    [error_code_pb.msg_ret.err_eqm_enchant_cost_item_illegal] = "附魔消耗的物品不正確",
    [error_code_pb.msg_ret.err_hero_not_found] = "找不到英雄",
    [error_code_pb.msg_ret.err_hero_duplicated] = "已經擁有了該英雄",
    [error_code_pb.msg_ret.err_shop_reached_limit] = "您的購買次數已達上限",
    [error_code_pb.msg_ret.err_shop_buy_exceed_limit] = "購買商品將會超過上限",
    [error_code_pb.msg_ret.err_shop_buy_expired] = "購買商品過期",
    [error_code_pb.msg_ret.err_dungeon_leapfrog] = "副本不能越級挑戰",
    [error_code_pb.msg_ret.err_mail_not_found] = "找不到指定郵件",
    [error_code_pb.msg_ret.err_mail_item_already_picked] = "郵件附件已被提取過",
    [error_code_pb.msg_ret.err_task_accepted] = "任務已接到",
    [error_code_pb.msg_ret.err_task_done] = "任務已完成",
    [error_code_pb.msg_ret.err_task_reward_picked] = "任務獎勵已經領取過了",
    [error_code_pb.msg_ret.err_task_not_done] = "任務還沒完成",
    [error_code_pb.msg_ret.err_guild_same_name] = "有同名的公會名字",
    [error_code_pb.msg_ret.err_guild_one_abnormal] = "伺服器繁忙，請稍後查詢",
    [error_code_pb.msg_ret.err_guild_dissolution_no_rights] = "只有會長還可以解散公會",
    [error_code_pb.msg_ret.err_guild_there_are_others] = "公會還有其他人存在，不能解散",
    [error_code_pb.msg_ret.err_guild_guild_leader_sign_out] = "會長不能退出公會，請轉讓職位",
    [error_code_pb.msg_ret.err_guild_apply_number] = "已經申請的公會數目大於設置值 (20個)",
    [error_code_pb.msg_ret.err_guild_free_mix_to_max] = "免申請設置最小等級為20",
    [error_code_pb.msg_ret.err_guild_not_number] = "創建公會名字不能全是數字",
    [error_code_pb.msg_ret.err_guild_already] = "您已經有公會了，無法加入其他公會哦",
    [error_code_pb.msg_ret.err_server_not_schedule_query] = "伺服器沒有這條記錄",
    [error_code_pb.msg_ret.err_guild_receive_physical_not_num] = "對方今日被贈送次數已滿",
    [error_code_pb.msg_ret.err_guild_not_guild_physical] = "對方獲贈的次數已經沒有了",
    [error_code_pb.msg_ret.err_guild_not_worship_reward] = "當前沒有可以領取的獎勵（膜拜）",
    [error_code_pb.msg_ret.err_guild_not_lev_worship] = "對方戰隊的等級不足，不能膜拜",
    [error_code_pb.msg_ret.err_guild_worship_quit] = "膜拜的人已經退出公會了",
    [error_code_pb.msg_ret.err_guild_not_abdicate_id] = "讓位的人已經退出公會",
    [error_code_pb.msg_ret.err_guild_abdicate_post] = "被讓位的人的職位大於或者等於你的職位",
    [error_code_pb.msg_ret.err_guild_client_post_illegal] = "任命的職位不合法",
    [error_code_pb.msg_ret.err_guild_worship_typd] = "膜拜的類型不存在",
    [error_code_pb.msg_ret.err_guild_leaderid_clientid] = "用戶端發來的id跟會長的id一致，所以不能操作任命，讓位，剔除等等操作",
    [error_code_pb.msg_ret.err_guild_flag_same] = "伺服器可能跟不上玩家的操作，請稍後再試",
    [error_code_pb.msg_ret.err_guild_quit_is__leader] = "請先解散公會操作",
    [error_code_pb.msg_ret.err_signin_receive_days] = "不能領取明天以及明天以後的獎勵",
    [error_code_pb.msg_ret.err_signin_finish_id] = "你已經領取過該獎勵了",
    [error_code_pb.msg_ret.err_signin_not_viplev] = "vip等級不足，不能領取",
    [error_code_pb.msg_ret.err_buy_physical_limit] = "你的體力已滿，無需購買",
    [error_code_pb.msg_ret.err_chat_no_guild] = "沒有公會，不能公會聊天",
    [error_code_pb.msg_ret.err_hero_skill_lev_max] = "英雄技能等級滿了",
    [error_code_pb.msg_ret.err_hero_skill_hero_lev] = "英雄等級不符合要求",
    [error_code_pb.msg_ret.err_glory_finish] = "你已經通關了",
    [error_code_pb.msg_ret.err_glory_not_pos] = "上陣的位置不對",
    [error_code_pb.msg_ret.err_have_dead_hero] = "有死亡的英雄上陣了",
    [error_code_pb.msg_ret.err_in_cooldown] = "冷卻中",
    [error_code_pb.msg_ret.err_zone_role_not_login] = "本次登陸失效，請重新登陸",
    [error_code_pb.msg_ret.err_not_enough_num] = "本關卡的戰鬥剩餘次數不足",
    [error_code_pb.msg_ret.err_change_namesex_have_flag] = "你已經修改過名字或是性別了",
    [error_code_pb.msg_ret.err_change_namesex_is_keyword] = "你輸入的是敏感詞",
    [error_code_pb.msg_ret.err_change_namesex_size] = "你輸入的字元長度不合法",
    [error_code_pb.msg_ret.err_change_namesex_illegal_characters] = "你輸入的內容含有非法字元",
    [error_code_pb.msg_ret.err_change_namesex_name_the_same] = "該名字已被註冊",
    [error_code_pb.msg_ret.err_change_sex_illegal] = "非法性別",
    [error_code_pb.msg_ret.err_in_cooldown_the_same] = "你剛退出公會，48小時後才能重新回到該公會",
    [error_code_pb.msg_ret.err_in_cooldown_diff] = "你剛退出公會，1小時後才能加入公會",
    [error_code_pb.msg_ret.err_guild_lev_not] = "公會等級不足",
    [error_code_pb.msg_ret.err_guild_not_people] = "公會人數已滿",
    [error_code_pb.msg_ret.err_guild_have_auction] = "你已經出過價格了",
    [error_code_pb.msg_ret.err_expire] = "您輸入的啟動碼已過期",
    [error_code_pb.msg_ret.err_already_picked] = "該啟動碼已被領取",
    [error_code_pb.msg_ret.err_illegal_code] = "啟動碼有誤",
    [error_code_pb.msg_ret.err_activate_code_same_type] = "您已領取過該類型的禮包",
    [error_code_pb.msg_ret.err_guild_vice_leader_full] = "副會長職位已滿",
    [error_code_pb.msg_ret.err_guild_is_signup] = "該公會已報名",
    [error_code_pb.msg_ret.err_guild_is_spoils] = "該玩家已經分配過獎勵了",
    [error_code_pb.msg_ret.err_guild_is_check] = "隊伍被鎖定了",
    [error_code_pb.msg_ret.err_guild_combat_no_out] = "公會戰戰鬥期間不能解散公會",
    [error_code_pb.msg_ret.err_guild_combat_no_join] = "公會戰戰鬥期間不能加入公會",
    [error_code_pb.msg_ret.err_guild_combat_no_regional] = "該區域剩餘位置不足",
    [error_code_pb.msg_ret.err_res_dungeon_is_owner_no_rob] = "你是佔領者，不能搶奪",
    [error_code_pb.msg_ret.err_guild_not_power] = "許可權不足",
    [error_code_pb.msg_ret.err_res_dungeon_is_not_owner] = "副本已被敵方佔領",
    [error_code_pb.msg_ret.err_res_dungeon_no_res_to_pick] = "現在還沒有資源可以提取哦",
    [error_code_pb.msg_ret.err_guill_mrole_start_combat] = "對方已經在戰鬥中",
    [error_code_pb.msg_ret.err_res_dungeon_not_enough_guard_soul] = "妖怪卡牌不足",
    [error_code_pb.msg_ret.err_guild_gain_spoils] = "該戰利品已被分配",
    [error_code_pb.msg_ret.err_activitie_fund] = "你還沒有購買基金",
    [error_code_pb.msg_ret.err_activitie_luckdraw] = "您還有獎牌沒有翻開，翻開後可領取獎勵哦",
    [error_code_pb.msg_ret.err_shop_buy_not_start] = "該商品還沒有開放購買",
    [error_code_pb.msg_ret.err_activitie_charge] = "您還沒有參與充值活動，首充任意金額即可領取獎勵哦",
    [error_code_pb.msg_ret.err_guild_contribute_limit] = "捐獻金幣已達到上限",
    [error_code_pb.msg_ret.err_activitie_not_charge] = "累計充值不足",
    [error_code_pb.msg_ret.err_activitie_not_enchant_reward] = "領取附魔獎勵，等級不足",
    [error_code_pb.msg_ret.err_sky_battle_cant_signup] = "現在還不能報名",
    [error_code_pb.msg_ret.err_sky_battle_signup_exhausted] = "您的報名次數已用完",
    [error_code_pb.msg_ret.err_hero_not_num] = "英雄數目不足",
    [error_code_pb.msg_ret.err_puzzle_dungeon_have_prompt] = "你已購買過",
    [error_code_pb.msg_ret.err_puzzle_dungeon_not_leapfrog_prompt] = "別貪心嘛，提示要一條一條的解鎖的哦",
    [error_code_pb.msg_ret.err_activitie_not_loss_gold_reward] = "累計消耗值不足",
    [error_code_pb.msg_ret.err_sns_give_phy_num_max] = "今天赠送体力的次数已满",
}

function Helper.nextAction()
    Helper.index = Helper.index + 1
    if Helper.index > table.getn(Helper.createFunctionTable) then
        Helper.index = 1
    end

    return Helper.newScene()
end

function  Helper.backAction()
    Helper.index = Helper.index - 1
    if Helper.index == 0 then
        Helper.index = table.getn(Helper.createFunctionTable)
    end

    return Helper.newScene()
end

function Helper.restartAction()
    return Helper.newScene()
end

function Helper.newScene()
    local scene = CCScene:create()
    Helper.currentLayer = Helper.createFunctionTable[Helper.index]()
    scene:addChild(Helper.currentLayer)
    scene:addChild(CreateBackMenuItem())

    CCDirector:sharedDirector():replaceScene(scene)
end

function Helper.initWithLayer(layer)
    Helper.currentLayer = layer

    local size = CCDirector:sharedDirector():getWinSize()
    Helper.titleLabel = CCLabelTTF:create("", "Arial", 28)
    layer:addChild(Helper.titleLabel, 1)
    Helper.titleLabel:setPosition(size.width / 2, size.height - 50)

    Helper.subtitleLabel = CCLabelTTF:create("", "Thonburi", 16)
    layer:addChild(Helper.subtitleLabel, 1)
    Helper.subtitleLabel:setPosition(size.width / 2, size.height - 80)

    -- menu
    local item1 = CCMenuItemImage:create(s_pPathB1, s_pPathB2)
    local item2 = CCMenuItemImage:create(s_pPathR1, s_pPathR2)
    local item3 = CCMenuItemImage:create(s_pPathF1, s_pPathF2)
    item1:registerScriptTapHandler(Helper.backAction)
    item2:registerScriptTapHandler(Helper.restartAction)
    item3:registerScriptTapHandler(Helper.nextAction)

    local menu = CCMenu:create()
    menu:addChild(item1)
    menu:addChild(item2)
    menu:addChild(item3)
    menu:setPosition(CCPointMake(0, 0))
    item1:setPosition(CCPointMake(size.width / 2 - item2:getContentSize().width * 2, item2:getContentSize().height / 2))
    item2:setPosition(CCPointMake(size.width / 2, item2:getContentSize().height / 2))
    item3:setPosition(CCPointMake(size.width / 2 + item2:getContentSize().width * 2, item2:getContentSize().height / 2))
    layer:addChild(menu, 1)

    local background = CCLayer:create()
    layer:addChild(background, -10)
end

function createTestLayer(title, subtitle)
    local layer = CCLayer:create()
    Helper.initWithLayer(layer)
    local titleStr = title == nil and "No title" or title
    local subTitleStr = subtitle  == nil and "" or subtitle
    Helper.titleLabel:setString(titleStr)
    Helper.subtitleLabel:setString(subTitleStr)
    return layer
end

--[[ 
参数说明： 
srcDateTime 原始时间字符串，要求格式2015-02-01 00:00:00,这个时间格式字符串表示4位年份、月份、day、小时、分钟、秒都是2位数字 
interval 对该时间进行加或减具体值,>0表示加 <0表示减 
dateUnit 时间单位，支持DAY、HOUR、SECOND、MINUTE 4种时间单位操作，根据interval具体值对原始时间按指定的单位进行加或减 
例如， 
interval=10，unit='DAY',表示对原始时间加10天 
interval=-1，unit='HOUR',表示对原始时间减1小时 

返回结果是一个os.date,他是一个table结构，里面包含了year,month,day,hour,minute,second 6个属性，跟据需要从结果里面取出需要的属性然后根据需要产生相应的新的日期格式即可。 
]]--
function Helper.getNewDate(srcDateTime,interval ,dateUnit)
    --从日期字符串中截取出年月日时分秒
    local Y = string.sub(srcDateTime,1,4)
    local M = string.sub(srcDateTime,6,7)
    local D = string.sub(srcDateTime,9,10)
    local H = string.sub(srcDateTime,12,13)
    local MM = string.sub(srcDateTime,15,16)
    local SS = string.sub(srcDateTime,18,19)

    --把日期时间字符串转换成对应的日期时间
    local dt1 = os.time{year=Y, month=M, day=D, hour=H,min=MM,sec=SS}

    --根据时间单位和偏移量得到具体的偏移数据
    local ofset=0

    if dateUnit =='DAY' then
        ofset = 60 *60 * 24 * interval

    elseif dateUnit == 'HOUR' then
        ofset = 60 *60 * interval
        
    elseif dateUnit == 'MINUTE' then
        ofset = 60 * interval

    elseif dateUnit == 'SECOND' then
        ofset = interval
    end

    --指定的时间+时间偏移量
    local newTime = os.date("*t", dt1 + tonumber(ofset))
    return newTime
end

function Helper.getNewTime(srcDateTime)
    --从日期字符串中截取出年月日时分秒
    local Y = string.sub(srcDateTime,1,4)
    local M = string.sub(srcDateTime,6,7)
    local D = string.sub(srcDateTime,9,10)
    local H = string.sub(srcDateTime,12,13)
    local MM = string.sub(srcDateTime,15,16)
    local SS = string.sub(srcDateTime,18,19)

    --把日期时间字符串转换成对应的日期时间
    local dt1 = os.time{year=Y, month=M, day=D, hour=H,min=MM,sec=SS}
    return dt1
end

--计算 UTF8 字符串的长度，每一个中文算一个字符
function string.utf8len(input)
    local len  = string.len(input)
    local left = len
    local cnt  = 0
    local arr  = {0, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc}
    while left ~= 0 do
        local tmp = string.byte(input, -left)
        local i   = #arr
        while arr[i] do
            if tmp >= arr[i] then
                left = left - i
                break
            end
            i = i - 1
        end
        cnt = cnt + 1
    end
    return cnt
end

--分别把每个字(包括中英)放进一个表里面
function Helper.separate(txt)
    local str=txt
    local tblStr = {}
    local i = 1
    while i <= #str  do
       c = str:sub(i,i)
       ord = c:byte()
       if ord > 128 then
          table.insert(tblStr,str:sub(i,i+2))
          i = i+3
       else
          table.insert(tblStr,c)
          i=i+1
       end
    end
    return tblStr
end    

--将时间戳转换为字符串描述
--desc_type = 1 表示X月X日10:00这种格式,不需要显示年
function Helper.unixTime2DateStr(target_unix_time,desc_type)
    if desc_type==nil then
        desc_type = 1
    end

    local target_time_tab =  os.date("*t", target_unix_time)
    local date_str = ""
    local hour_desc = target_time_tab.hour
    local min_desc = target_time_tab.min
    
    if target_time_tab.hour<10 then
        hour_desc = "0"..target_time_tab.hour
    end

    if target_time_tab.min<10 then
        min_desc = "0"..target_time_tab.min
    end

    if desc_type==1 then
        date_str = string.format("%d月%d日%s:%s",target_time_tab.month,target_time_tab.day ,hour_desc ,min_desc  )
    end

    return date_str
end

--统计中英字符 元素个数
function Helper.numEnCnElem(txt)
    local str=txt
    local len = 0
    local i = 1
    while i <= #str  do
       c = str:sub(i,i)
       ord = c:byte()
       if ord > 128 then
          len = len + 1
          i = i+3
       else
          len = len + 1
          i=i+1
       end
    end
    return len
end

--统计中英字符长度 (中 1  英 2)
function Helper.lenEnCn(txt)
    local str=txt
    local len = 0
    local i = 1
    while i <= #str  do
       c = str:sub(i,i)
       ord = c:byte()
       if ord > 128 then
          len = len + 2
          i = i+3
       else
          len = len + 1
          i=i+1
       end
    end
    return len
end

--统计换行符的数量
function Helper.nlCount(str)
    local cout = 0
    local tbl = Helper.separate(str)
    for i=1,table.getn(tbl) do
        if tbl[i] == "\n" then
            cout = cout + 1
        end
    end
    return cout
end

--根据行字数上限 插入 换行符
function Helper.insertnl(txt,num,max,ln)
    local tbl = Helper.separate(txt)
    local ret = ""
    local ln = ln or "\n"
    local lineWidth = (num - 1) * 22 --中文字宽22
    local totalWidth = 0

    local charWidth = 0
    local oneLine = 0
    for i=1,#tbl do
        if tbl[i]:byte() > 128 then
            charWidth = 22  
        else
            charWidth = 12
        end

        totalWidth = totalWidth + charWidth
        oneLine = oneLine + charWidth

        ret = ret .. tbl[i]
        if oneLine > lineWidth then
            oneLine = 0
            
            if i ~= #tbl then
                ret = ret .. ln
            end
        end

        if max ~= nil then
            local maxWidth = max * 22
            if totalWidth >= maxWidth then
                ret = ret .. "..."
                return ret
            end
        end
    end
    return ret
end

function Helper.makeStrSize(str,lineWidth)
    local width = 1
    local i = 1
    while i <= #str  do
       c = str:sub(i,i)
       ord = c:byte()
       if ord > 128 then
          width = width + 22
          i = i+3
       else
          width = width + 12
          i=i+1
       end
    end
    local height = math.max(1, math.ceil(width / lineWidth)) * 22
    return CCSize(lineWidth,height),height
end


function Helper.coutStrWidth(str)
    local width = 0
    local i = 1
    while i <= #str  do
       c = str:sub(i,i)
       ord = c:byte()
       if ord > 128 then
          -- table.insert(tblStr,str:sub(i,i+2))
          width = width + 22
          i = i+3
       else
          -- table.insert(tblStr,c)
          width = width + 12
          i=i+1
       end
    end
    return width
end

--寻找数组中某个值的下标，仅在数组中每个值都不一样时有效
function Helper.findArrIndexByValue(arr,value)
    local tempArr = arr
    local tempValue = value 
    for i,v in ipairs(tempArr) do
        if v == tempValue then
            return i
        end
    
    end   
end

--将string转为table1
function Helper.stringToTable(str)
   local ret = loadstring("return "..str)()
   return ret
end

-- 一些通用的常量定义
ComConstTab = ComConstTab or {}

ComConstTab.TouchEventType = 
{
    began = 0,
    moved = 1,
    ended = 2,
    canceled = 3,
}

ComConstTab.LoadingBarType = 
{ 
    left = 0, 
    right = 1,
}

ComConstTab.CheckBoxEventType = 
{
    selected = 0,
    unselected = 1,
}

ComConstTab.PageEventType =
{
    turning = 0
}

ComConstTab.ScrollViewEventType = 
{
    scroll_to_top = 0,
    scroll_to_bottom = 1,
    scroll_to_left = 2,
    scroll_to_right = 3,
    scroll_scrolling = 4,
    bounce_top = 5,
    bounce_bottom = 6,
    bounce_left = 7,
    bounce_right = 8,
}

ComConstTab.MovementEventType = 
{
    START = 0,  
    COMPLETE = 1,   
    LOOP_COMPLETE = 2
}

--layer对应的点击
ComConstTab.TouchEventType2 = 
{
    BEGAN = "began",
    MOVED = "moved",
    ENDED = "ended"
}

--性别定义
Helper.sex = {}
Helper.sex.female = 0 --女
Helper.sex.male = 1 --男

--返回相应错误信息
function Helper.getErrStr(err_id)
    
    --部分特殊错误码的处理
    if SpecialErrCodeMgr:getInstance():isSpecialErrCode(err_id) then
        SpecialErrCodeMgr:getInstance():dealSpecialErrCode(err_id)
    end

    if Helper.errMsgDict[err_id] then 
        return Helper.errMsgDict[err_id]
    end
    local err_str = "操作失敗，請重試 "..err_id
    return err_str
end

--[[
    显示错误代码提示
]]
function Helper.showErrMsg(errId)

    local errMsg = Helper.getErrStr(errId)

    if not errMsg or #errMsg == 0 then
        return
    end

    Alert:show(errMsg)

end

local function formatTime(num)
    if num<10 then
        return "0"..num
    else
        return num
    end
end

--[[
@param sec 秒
--]]
function Helper.sec2TimeStr(sec)
    local my_sec = sec 
    local temp_hours = 0
    local temp_mils = 0
    local temp_secs = 0

    temp_mils = math.floor(my_sec/60)
    temp_secs = my_sec%60
    
    if temp_mils>59 then
        temp_hours = math.floor(temp_mils/60)
        temp_mils = temp_mils%60
    end

    local time_str = nil
    if temp_hours>0 then
        time_str = formatTime(temp_hours)..":"..formatTime(temp_mils)..":"..formatTime(temp_secs)
    else
        time_str = formatTime(temp_mils)..":"..formatTime(temp_secs)
    end

    return time_str
end
--获取物品数字描述
function Helper.makeItemNumDesc(num,mode)
    if num > 1 then
        return num
    elseif mode and ItemManager:getInstance():isEqm(mode.item_type)
                or mode.item_type==ItemHelper.itemType.equip_fragment then
        return ItemHelper:getHeroPosShortName(mode.limit_stand)
    else
        return ""
    end
end

--[[
获取当前时间跟目标时间的时间差，单位是秒
@param end_time unix时间戳，单位是秒
--]]
-- function Helper.getTimeDiff(end_time)
--     local cur_time = os.time()
--     local diff = end_time - cur_time
--     return diff
-- end

function Helper.utf8(num)
num = tonumber(num,16)
local char = string.char
local floor = math.floor
local highbits = 7
local sparebytes = 0
while num >= 2^(highbits + sparebytes * 6) do
  highbits = highbits - 1
  if highbits < 1 then error "utf-8 sequence out of range" end
  sparebytes = sparebytes + 1
end
if sparebytes == 0 then
  return char(num)
else
  local bytes = {}
  for i=1, sparebytes do
    local byte = floor((num / 2^((i-1)*6)) % 2^6)
    bytes[sparebytes+2-i] = char(byte + 2^7)
  end
  local byte = floor(num / 2^(sparebytes*6))
  bytes[1] = char(byte + 2^8 - 2^(highbits))
  return table.concat(bytes)
end
end

--多个unicode字串转换 中文
--如 "|2003|3001"
function Helper.muliStrConvUtf8(str)
    local ret = ""
    local strTbl = Helper.separate(str)
    for i,s in ipairs(strTbl) do
        if s == "|" then
            local v = string.gsub(strTbl[i+1]..strTbl[i+2]..strTbl[i+3]..strTbl[i+4],"(%x%x%x%x%x?%x?)",Helper.utf8)
            ret = ret .. v

            table.remove(strTbl,i + 1) --删除后4个元素
            table.remove(strTbl,i + 1)
            table.remove(strTbl,i + 1)
            table.remove(strTbl,i + 1)
        else
            ret = ret .. s
        end
    end
    return ret
end

function string.utf8sub(str, startChar, numChars)

    -- 判断utf8字符byte长度
    -- 0xxxxxxx - 1 byte
    -- 110yxxxx - 192, 2 byte
    -- 1110yyyy - 225, 3 byte
    -- 11110zzz - 240, 4 byte
    local function chsize(char)
        if not char then
            print("not char")
            return 0
        elseif char > 240 then
            return 4
        elseif char > 225 then
            return 3
        elseif char > 192 then
            return 2
        else
            return 1
        end
    end

    local startIndex = 1
    while startChar > 1 do
        local char = string.byte(str, startIndex)
        startIndex = startIndex + chsize(char)
        startChar = startChar - 1
    end

    local currentIndex = startIndex

    while numChars > 0 and currentIndex <= #str do
        local char = string.byte(str, currentIndex)
        currentIndex = currentIndex + chsize(char)
        numChars = numChars -1
    end
    return str:sub(startIndex, currentIndex - 1)
end


function Helper.converNumToChinese(num)
    if num == 0 then
        return "零"
    elseif num ==1 then
         return "一"
    elseif num ==2 then
         return "二"
    elseif num ==3 then
         return "三"
    elseif num ==4 then
         return "四"
    elseif num ==5 then
         return "五"
    elseif num ==6 then
         return "六"
    elseif num ==7 then
         return "七"
    elseif num ==8 then
         return "八"
    elseif num ==9 then
         return "九"
    end
end
--获取中文 倒计时时间
function Helper.getChCoutStrTime(second,limit)
    local ret = ""
    if second < limit then
        ret = "剛剛"
    elseif second < 60 * 60 then
        ret = math.floor( second / 60 ) .. "分鐘前"
    elseif second < 60 * 60 * 24 then
        ret = math.floor( second / 3600 ) .. "小時前"
    else
        ret = math.min(3, math.floor( second / ( 3600 * 24 ) )) .. "天前"
    end
    return ret
end

--获取中文 倒计时时间 --样式2
function Helper.getChCoutStringTime(sec)
    local my_sec = sec 
    local temp_days = 0
    local temp_hours = 0
    local temp_mils = 0
    local temp_secs = 0

    temp_mils = math.floor(my_sec/60)
    temp_secs = my_sec%60
    
    if temp_mils>59 then
        temp_hours = math.floor(temp_mils/60)
        temp_mils = temp_mils%60
    end

    if temp_hours > 23 then
        temp_days = math.floor(temp_hours/24)
        temp_hours = temp_hours%24
    end

    local time_str = nil
    if temp_days > 0 then
        time_str = temp_days.."天"..formatTime(temp_hours).."小時"..formatTime(temp_mils).."分"
    elseif temp_hours>0 then
        time_str = formatTime(temp_hours).."小時"..formatTime(temp_mils).."分"
    elseif temp_mils >0 then
        time_str = temp_mils.."分"
    else
        time_str = temp_secs.."秒"
    end
    return time_str
end

--获取中文 倒计时时间 --样式3
function Helper.getChShortCoutStrTime(sec)
    local my_sec = sec 
    local temp_days = 0
    local temp_hours = 0
    local temp_mils = 0
    local temp_secs = 0

    temp_mils = math.floor(my_sec/60)
    temp_secs = my_sec%60
    
    if temp_mils>59 then
        temp_hours = math.floor(temp_mils/60)
        temp_mils = temp_mils%60
    end

    if temp_hours > 23 then
        temp_days = math.floor(temp_hours/24)
        temp_hours = temp_hours%24
    end

    local time_str = nil
    if temp_days > 0 then
        time_str = temp_days.."天"
    else
        time_str = formatTime(temp_hours).."小時"
    end
    return time_str
end

--获取中文 数字表达
function Helper.getChNumStr(num)
    local ret = ""
    if num >= 100000 then
        ret = math.floor( num / 10000 ) .. "萬"
    else
        ret = tostring(num)
    end
    return ret
end

--是否含有敏感词
function Helper.hasSensitiveWord(txt)
    local ret = false
    --敏感词
    require "ChatLocalReader"
    ChatLocalReader:getInstance():loadInProxy()
    for k,v in pairs(ChatHelper.sensitiveTbl) do
        if string.find(txt,v) then
            return true
        end
    end
    return ret
end

--模型动作类型
Helper.ModelActionType = 
{
    --站立
    STAND = "stand",
    --入场
    ENTER = "enter",
    --跑动
    RUN = "run",
    --受伤
    HURT = "hurt",
    --死亡
    DEAD = "dead",
    --攻击1
    ATTACK1 = "attack01",
    --攻击2
    ATTACK2 = "attack02",
    --攻击3
    ATTACK3 = "attack03",
    --庆祝1
    CELEBRATE1 = "celebrate01",
    --庆祝2
    CELEBRATE2 = "celebrate02",
    --闪烁
    BLINK = "blink",
    --站立2
    STAND_2 = "attack02_01",
    --复活
    REVIVE = "revive"
}

--怪物类型
Helper.monsterType = 
{
    --小怪
    MOBS = 1,
    --boss
    BOSS = 2,
    --公会boss
    GUILD_BOSS = 3,
    --超级boss
    SUPER_BOSS = 4
}


--空函数(CCArmatureAnimation用)
Helper.tempAction = function() end

--回收时间
Helper.GC_TIME = 
{

    --骨骼动画(2 min)
    ARMATURE = 120000
}

--用自身的roid 来匹配目标的roid是否一致
function Helper.mathCurRoId(role_id)

    return role_id.uin == CharacterManager:getInstance():getLoginData():getAcctId() and
        role_id.channel_id == CharacterManager:getInstance():getLoginData():getChannelId() and 
        role_id.zone_id == CharacterManager:getInstance():getLoginData():getZoneId()
end

function Helper.isSamePos(a,b)
    return a.x == b.x and a.y == b.y
end

Helper.TargetPlatForms = {}
Helper.TargetPlatForms.UNKNOWN = 0
Helper.TargetPlatForms.IOS     = 1
Helper.TargetPlatForms.ANDROID = 2
Helper.TargetPlatForms.WIN32   = 3
Helper.TargetPlatForms.MARMALADE = 4
Helper.TargetPlatForms.LINUX = 5
Helper.TargetPlatForms.BADA = 6
Helper.TargetPlatForms.BLACKBERRY = 7
Helper.TargetPlatForms.MAC = 8
Helper.TargetPlatForms.NACL = 9
Helper.TargetPlatForms.EMSCRIPTEN = 10
Helper.TargetPlatForms.TIZEN = 11
Helper.TargetPlatForms.WINRT = 12
Helper.TargetPlatForms.WP8   = 13

Helper.NetWorkState = {}
Helper.NetWorkState.disconnect = 0
Helper.NetWorkState.WIFI = 1
Helper.NetWorkState.GPRS = 2


function Helper.isSamePos(a,b)
    return a.x == b.x and a.y == b.y
end

--将参数拼接为特殊字符串，传递给c++
function Helper.params2Cpp(...)
    local args = {...}
    local result_str = ""
    for i=1,#args do
        if i == 1 then
            result_str = args[i]
        else
            result_str =  result_str.."#%#"..args[i]
        end
       
    end
    return result_str
end
