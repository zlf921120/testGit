require("XArray")
require("Object")
Timer = {}

--初始化
Timer.init = nil
--销毁资源
Timer.shutDown = nil
--更新回调方法
Timer_onTimeUpdateHandler = nil
--设置计时器
Timer.setTimer = nil
--添加更新处理
Timer.addUpdateHandler = nil
--移除更新处理
Timer.removeUpdateHandler = nil
--创建回调闭包
local CallBackSelector = nil
--计数器
local nCount = 0
--调度队列
local callQueue = {}
--清理调用队列
local cleanUp = nil
--是否需要清零
local isDirty = false
--更新方法的句柄
local hFunc = nil
--更新列表[function(t)]
local updateList = XArray.create()
---------华丽的分隔线-----------
--创建回调
--[[
	清理调用队列中的空对象
--]]
cleanUp = function()
	local n = nCount
	local v = callQueue
	local k = 0
	for i = 1 ,n do
		if(v[i] == nil)then
			for i = i + 1 , n do 
				if(v[i] ~= nil)then
					k = k + 1
					v[k] = v[i]
					v[i] = nil
					break
				end
			end
		else
			k = k + 1
		end
	end
	nCount = k
end
--[[
	更新回调方法
	@param t　2帧之间的时间间隔
--]]
Timer_onTimeUpdateHandler = function(t)
	--调度每个计时器的更新方法
	if(isDirty)then
		cleanUp()
		isDirty = false
	end
	for i = 1 , nCount do
		local it = callQueue[i]
		if(it ~= nil)then
			it.elapsedTime = it.elapsedTime + t
			if(it.elapsedTime >= it.totalTime)then
				if it.data == nil then
					it.fnCall()
				else
					it.fnCall(it.data)
				end
				callQueue[i] = nil
				isDirty = true
			end
		end
	end
	
	--调度更新列表的每个元素的更新方法
	if(updateList.dirty)then
		updateList:cleanUp()
	end
	local v = updateList.pool
	for i = 1 , updateList.size do
		if(v[i][1](t , v[i][2]))then
			v[i] = nil
			updateList.dirty = true
		end
	end
end

--[[
	创建回调选择器
--]]
local CallBackSelector = function()
	local ret = {}
	ret.fnCall = nil
	ret.elapsedTime = 0
	ret.totalTime = 0
	nCount = nCount + 1
	callQueue[nCount] = ret
	return ret
end
--[[
	初始化
--]]
Timer.init = function()
	if(hFunc ~= nil)then
		return
	end
	hFunc = CCDirector:sharedDirector():getScheduler():scheduleScriptFunc(Timer_onTimeUpdateHandler, 0, false)
end
--[[
	销毁
--]]
Timer.shutDown = function()
	if(hFunc ~= nil)then
		CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(hFunc)
		hFunc = nil
	end
end
--[[
	设置计时器
	@param timeDuring	被回调的时机
	@param fnCallback	被回调的函数 function() todo end
--]]
Timer.setTimer = function(timeDuring , fnCallback, data)
    --Global:cclog("setTimer...timerDuring"..timeDuring)
    assert(timeDuring)
	Timer.init()
	if(timeDuring <= 0)then
		if nil == data then
			fnCallback()
		else
			fnCallback(data)
		end
		return
	end
	local selector = CallBackSelector()
	selector.fnCall = fnCallback
	selector.data = data
	selector.elapsedTime = 0
	selector.totalTime = timeDuring
end

--[[
	添加更新处理函数
	@param fnCall function(t , context) return isFinished end
	@param context 
--]]
Timer.addUpdateHandler = function(fnCall ,context)
	local updateable = {}
	updateable[1] = fnCall
	updateable[2] = context
	updateList:add(updateable)
end
--[[
	移除更新处理
	@param fnCall回调的方法
--]]
Timer.removeUpdateHandler = function (fnCall )	
	local id ,idx = updateList:findIf(
		function (it)
			return it[1] == fnCall
	 	end)
	if(id)then
		updateList:removeAt(idx)
	end
end



TClock = {}

TClock.create = function(timeDuring)
	local this = Object.create()
	if(timeDuring == nil)then
		this.timeDuring = 0
	else
		this.timeDuring = timeDuring
	end
	this.added = false
	
	this.update = function(this , t)
		this.timeDuring = this.timeDuring - t
		if(this.timeDuring < 0)then
			this.added = false
			return true
		end
		return false
	end
	
	this.timeOut = function(this)
		return this.timeDuring <= 0
	end
	
	
	this.reset = function(timeDuring)
		if(timeDuring == nil)then
			this.timeDuring = 0
		else
			this.timeDuring = timeDuring
		end
		this:active()
	end
	
	
	
	this.active = function(this)
		if(not this.added)then
			this.added = true
			Timer.addUpdateHandler(
			function(t)
				this:update(t)
			end)
		end
	end
	
	this:active()
	
	return this
end
























