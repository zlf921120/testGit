
--[[
    显示工具类
]]

--组件类型
ComponentType = {
    LAYOUT = "Layout",
    BUTTON = "Button",
    LABEL = "Label",
    IMAGE_VIEW = "ImageView",
    SCROLL_VIEW = "ScrollView",
    LIST_VIEW = "ListView",
    PROGRESS = "LoadingBar", 
    CHECKBOX = "CheckBox"
}

DisplayUtil = {}

function DisplayUtil.init()

	DisplayUtil.visibleSize = CCDirector:sharedDirector():getVisibleSize()
	DisplayUtil.origin = CCDirector:sharedDirector():getVisibleOrigin()
	DisplayUtil.frameSize = CCEGLView:sharedOpenGLView():getFrameSize()
	DisplayUtil.centerPos = ccp(DisplayUtil.visibleSize.width*0.5, DisplayUtil.visibleSize.height*0.5)

	DisplayUtil.viewScale = ccp(CCEGLView:sharedOpenGLView():getScaleX(), CCEGLView:sharedOpenGLView():getScaleY())

	if CCEGLView:sharedOpenGLView():getScaleX()>CCEGLView:sharedOpenGLView():getScaleY() then
		DisplayUtil.min_scale = CCEGLView:sharedOpenGLView():getScaleY()
		DisplayUtil.max_scale = CCEGLView:sharedOpenGLView():getScaleX()
	else
		DisplayUtil.min_scale = CCEGLView:sharedOpenGLView():getScaleX()
		DisplayUtil.max_scale = CCEGLView:sharedOpenGLView():getScaleY()
	end
end

function DisplayUtil.newLayer()
	return CCLayer:create()
end

function DisplayUtil.newWidget()
	return Widget:create()
end

function DisplayUtil.newLayout()
	return Layout:create()
end

function DisplayUtil.newNode()
	return CCNode:create()
end

function DisplayUtil.newColorNode()
	return CCNodeRGBA()
end

function DisplayUtil.newWindowBase()
	return WindowBase:create()
end

--返回一个经过比例处理的Layout
function DisplayUtil.newFitLayout()
	local fit_layout = Layout:create()
	local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
 	local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()

 	fit_layout:setScaleX(1/globa_scalx*DisplayUtil.min_scale)
 	fit_layout:setScaleY(1/globa_scaly*DisplayUtil.min_scale)

 	return fit_layout
end


--返回一个经过比例处理的CCLayer
function DisplayUtil.newFitLayer()
	local fit_layer = CCLayer:create()
	local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
 	local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()

 	fit_layer:setScaleX(1/globa_scalx*DisplayUtil.min_scale)
 	fit_layer:setScaleY(1/globa_scaly*DisplayUtil.min_scale)

 	return fit_layer
end


--[[
    获取无黑边等比缩放比例
    @return 一个缩放比
]]
function DisplayUtil.getNoBorderScaleValue(nodeWidth, nodeHeight)

	local gameWidth = DisplayUtil.frameSize.width
	local gameHeight = DisplayUtil.frameSize.height

	local sx = gameWidth / nodeWidth
	local sy = gameHeight / nodeHeight


	local maxScale = 0

	if sx > sy then
		maxScale = sx
	else
		maxScale = sy
	end

	return maxScale

end

--获取组件
function DisplayUtil.getWidgetByName(root, name, widgetType)
	return tolua.cast(UIHelper:seekWidgetByName(root, name), widgetType)
end

--[[
    是否触碰到
]]
function DisplayUtil.isTouch(node, touchX, touchY)
	
	local location = node:convertToNodeSpace(ccp(touchX, touchY))
	-- local locationAR = node:convertToNodeSpaceAR(ccp(touchX, touchY))

	-- print(location.x, location.y, locationAR.x, locationAR.y)

	local size = node:getContentSize()
	-- local anchorPos = node:getAnchorPoint()

	local sr = CCRectMake(0, 0, size.width, size.height)
	-- local sr = CCRectMake(-size.width*anchorPos.x, -size.height*anchorPos.y, size.width, size.height)

	-- sr.origin = ccp(0, 0)

	-- print(sr.size.width, sr.size.height, location.x, location.y)

	if sr:containsPoint(location) then
		return true
	end

	return false

end

--[[
    显示对象是一个圆形, 判断是否触碰到
    @param node
    @param touchX
    @param touchY
]]
function DisplayUtil.isTouchWithRadius(node, touchX, touchY)

	local touchLocation = node:convertToNodeSpaceAR(ccp(touchX, touchY))

	local size = node:getContentSize()

	local radius = size.width * 0.5   --半径

	local anchorPos = node:getAnchorPoint()

	-- local centerPos = ccp(radius, radius)
	local centerPos = ccp(size.width * anchorPos.x, size.width * anchorPos.x)

	local distance = ccpDistance(touchLocation, centerPos)

	if distance <= radius then
		return true
	end

	return false
	
end

--[[
    获取世界坐标
]]
function DisplayUtil.getWorldPos(node)

	local parent = node:getParent()

	if not parent then
		return
	end

	local pos = parent:convertToWorldSpace(ccp(node:getPosition()))

	return pos

end

--根据名字创建序列帧动画 并播放限定播放时间
function DisplayUtil.createAnimWithPlayTime(name,playTime,iLoops)
	local pCache = CCSpriteFrameCache:sharedSpriteFrameCache()
	local pArray = CCArray:create()

	local pFrame = nil
	local index = 1
	while true do
		pFrame = pCache:spriteFrameByName(string.format("%s%d.png",name,index))
		index = index +1
		if pFrame == nil then
			break
		end
		pArray:addObject(pFrame)
	end

	local pAnim = CCAnimation:createWithSpriteFrames(pArray,0.15)
	-- pAnim:setLoops(iLoops)
	-- pAnim:setRestoreOriginalFrame(true)
	-- pAnim:setDelayPerUnit(playTime / pArray:count())

	local firstFrame = pCache:spriteFrameByName(string.format("%s%d.png",name,1))
	if firstFrame == nil then return nil end

	local pSprite = CCSprite:create()
	pSprite:setContentSize(firstFrame:getOriginalSize())
	pSprite:runAction(CCRepeatForever:create(CCAnimate:create(pAnim)))
	return pSprite
end

function DisplayUtil.makeSpriteWithPlayTime(sprite,name,playTime,iLoops)
	local pCache = CCSpriteFrameCache:sharedSpriteFrameCache()
	local pArray = CCArray:create()

	local pFrame = nil
	local index = 1
	while true do
		pFrame = pCache:spriteFrameByName(string.format("%s%d.png",name,index))
		index = index +1
		if pFrame == nil then
			break
		end
		pArray:addObject(pFrame)
	end

	local pAnim = CCAnimation:createWithSpriteFrames(pArray,0.15)
	-- pAnim:setLoops(iLoops)
	-- pAnim:setRestoreOriginalFrame(true)
	-- pAnim:setDelayPerUnit(playTime / pArray:count())

	local firstFrame = pCache:spriteFrameByName(string.format("%s%d.png",name,1))
	if firstFrame == nil then return nil end

	sprite:setContentSize(firstFrame:getOriginalSize())
	sprite:stopAllActions()
	sprite:runAction(CCRepeatForever:create(CCAnimate:create(pAnim)))
end

--根据名字创建序列帧动画
function DisplayUtil.createAnim(name,delay,iLoops)
	local pCache = CCSpriteFrameCache:sharedSpriteFrameCache()
	local pArray = CCArray:create()

	local pFrame = nil
	local index = 1
	while true do
		pFrame = pCache:spriteFrameByName(string.format("%s%d.png",name,index))
		index = index +1
		if pFrame == nil then
			break
		end
		pArray:addObject(pFrame)
	end

	local pAnim = CCAnimation:createWithSpriteFrames(pArray,delay)
	-- pAnim:setLoops(iLoops)
	-- pAnim:setRestoreOriginalFrame(true)
	-- pAnim:setDelayPerUnit(delay)

	local firstFrame = pCache:spriteFrameByName(string.format("%s%d.png",name,1))
	if firstFrame == nil then return nil end

	local pSprite = CCSprite:create()
	pSprite:setContentSize(firstFrame:getOriginalSize())
	pSprite:runAction(CCRepeatForever:create(CCAnimate:create(pAnim)))
	return pSprite
end


local function isNaN(x)
	return x ~= x
end

--[[
     获取ScrollView滚动比例
     @return percent 0-100
]]
function DisplayUtil.getScrollViewPercent(scrollView)

	local svSize = scrollView:getSize()

	local innerSize = scrollView:getInnerContainerSize()

	local innerPos = ccp(scrollView:getInnerContainer():getPosition())

	local direction = scrollView:getDirection()

	local hp = math.abs(innerPos.x) / (innerSize.width - svSize.width)

	-- print(svSize.width, svSize.height, innerSize.width, innerSize.height, innerPos.x, innerPos.y, hp)

	if hp > 1 then
		hp = 1
	elseif hp < 0 then
		hp = 0
	elseif isNaN(hp) then
		hp = 0
	end

	local vp = math.abs(innerPos.y) / (innerSize.height - svSize.height)

	if vp > 1 then
		vp = 1
	elseif vp < 0 then
		vp = 0
	elseif isNaN(vp) then
		vp = 0
	end

	hp = hp * 100
	vp = vp * 100

	if direction == SCROLLVIEW_DIR_NONE then
		return 0
	elseif direction == SCROLLVIEW_DIR_VERTICAL then
		return vp
	elseif direction == SCROLLVIEW_DIR_HORIZONTAL then
		return hp
	else
		return hp, vp
	end	

end

--[[
    获取某个位置在滚动层的比例, 默认减去滚动显示尺寸的一半
    @return 0-100
]]
function DisplayUtil.getScrollViewPercentWithPos(scrollView, pos)

	local svSize = scrollView:getSize()

	local innerSize = scrollView:getInnerContainerSize()

	local direction = scrollView:getDirection()

	local function calcPercent(xy, svWH, innerWH)

		local border = 0
		local percent = 0

		border = xy - (svWH * 0.5)

		if border < 0 then
			return 0
		elseif border > innerWH - svWH then
			return 1
		end

		percent = border / (innerWH - svWH)

		return percent

	end

	local hp = calcPercent(pos.x, svSize.width, innerSize.width)
	local vp = calcPercent(pos.y, svSize.height, innerSize.height)

	if hp > 1 then
		hp = 1
	elseif hp < 0 then
		hp = 0
	elseif isNaN(hp) then
		hp = 0
	end

	if vp > 1 then
		vp = 1
	elseif vp < 0 then
		vp = 0
	elseif isNaN(vp) then
		vp = 0
	end

	hp = hp * 100
	vp = vp * 100

	if direction == SCROLLVIEW_DIR_NONE then
		return 0
	elseif direction == SCROLLVIEW_DIR_VERTICAL then
		return vp
	elseif direction == SCROLLVIEW_DIR_HORIZONTAL then
		return hp
	else
		return hp, vp
	end

end

--[[
    设置一个节点是否存在, 指可见和可点击
]]
function DisplayUtil.setNodeExist(node, value)

	node:setVisible(value)
	node:setTouchEnabled(value)

end

--创建富本文(仅含文字)
function DisplayUtil.createRtfLab(tbl,maxChar)
	local function createElementLab(e,char)
		local lab = Label:create()
		lab:setAnchorPoint(ccp(1, 0.5))
		lab:setText(char)
		lab:setColor(e.color or ItemHelper.colors.yellow)
		lab:setFontSize(e.fontSize or 22)
		return lab
	end

	local function progress(labTbl,maxChar,totalChat)
		local lineWidth = maxChar * 22

		local ret = CCNode:create()
		ret.labTbl = labTbl

		for i=1,#labTbl do
			local lab = labTbl[i]
			ret:addChild( lab )
		end

		local totalWidth = 0
    	local charWidth = 0
    	local oneLine = 0
    	local lines = 1
		for i=1,#totalChat do

	        charWidth = labTbl[i]:getSize().width

	        totalWidth = totalWidth + charWidth
	        oneLine = oneLine + charWidth

			local lab = labTbl[i]
			if lab == nil then break end

	        lab:setPosition(ccp(oneLine,-lines * 22))
	        if oneLine > lineWidth then
	            oneLine = 0
	            lines = lines +1
	        end
	    end

		function ret:setAllVisible(value)
			for i=1,#ret.labTbl do
				ret.labTbl[i]:setVisible(value)
			end
		end
		function ret:setVisibleAtIndex(i,value)
			ret.labTbl[i]:setVisible(value)
		end
		return ret
	end

	local labTbl = {}
	local totalChat = {}
	for i=1,#tbl do
		local charTbl = Helper.separate(tbl[i].txt)
		for j=1,#charTbl do
			table.insert(totalChat,charTbl[j])
			table.insert(labTbl,createElementLab(tbl[i],charTbl[j]))
		end
	end
	return progress(labTbl,maxChar,totalChat)
end

--创建纹理字(可设置间隙)
function DisplayUtil.createLabAtlas(src,value,gap,charWidth,charHeight,charBegin)
	local tblStr = Helper.separate(tostring(value))
 	local node = CCNode:create()
 	node.tblLab = {}
 	node.value = value
	for i=1,#tblStr do
		local lab = CCLabelAtlas:create(tblStr[i],src,charWidth,charHeight,charBegin)
		table.insert(node.tblLab,lab)
		node:addChild(lab)

		lab:setPosition(ccp(gap * (i-1), 0))
	end
	node:setContentSize(CCSize(gap * #tblStr,charHeight))

	function node:setString(v)
		node.value = v
		for i=1,#node.tblLab do
			node.tblLab[i]:removeFromParentAndCleanup(true)
			node.tblLab[i] = nil
		end

		local tblStr = Helper.separate(tostring(v))
		for i=1,#tblStr do
			local lab = CCLabelAtlas:create(tblStr[i],src,charWidth,charHeight,charBegin)
			lab:setString(tblStr[i])
			table.insert(node.tblLab,lab)
			node:addChild(lab)

			lab:setPosition(ccp(gap * (i-1), 0))
		end

		node:setContentSize(CCSize(gap * #tblStr,charHeight))
	end

	function node:getString()
		return tostring(node.value)
	end
	return node
end

--限制listView的显示范围
function DisplayUtil.makeVisibleListView(listView,itemHeight,viewHeight)

	listView:addEventListenerScrollView(function(pSender,eventType)
        if eventType == SCROLLVIEW_EVENT_SCROLLING then --隐藏不显示的cell

            local nowY = pSender:getInnerContainer():getPositionY()

            for i=0,pSender:getItems():count() - 1 do
                local item = pSender:getItem(i)
                if item:getPositionY() > -nowY - itemHeight and item:getPositionY() < -nowY + viewHeight + itemHeight then
                    item:setVisible(true)
                else
                    item:setVisible(false)
                end
            end
        end
    end)
end

--创建自适应滑动容器
function DisplayUtil.createAdaptScrollView(w,h,itemHeight,itemNum,itemDefaultCol)
	local scrol = ScrollView:create()
	scrol:setTouchEnabled(true) 
	scrol:setSize(CCSize(w,h))
	scrol:setDirection(SCROLLVIEW_DIR_VERTICAL)
    scrol:setClippingEnabled(true)
	function scrol:setScrollHeight(itemNum)
		local innerWidth = scrol:getSize().width
		local innerHeight = math.ceil(itemNum/itemDefaultCol)*itemHeight --滚动框高度由物品个数决定
		scrol:setInnerContainerSize(CCSize(innerWidth, innerHeight))
	end
	function scrol:setInnerHeightWithList(list)
		local innerWidth = scrol:getSize().width
		local innerHeight = 0
		for i=1,#list do --滚动框高度由不同物品的高度确定
			innerHeight = innerHeight + list[i].height
		end
		scrol:setInnerContainerSize(CCSize(innerWidth, innerHeight))
	end
	return scrol
end

--刷新自适应列表项
function DisplayUtil.refreshAdaptScrol(cacheDic,cacheDicLen,key,viewVoList,scrol,itemWidth,itemHeight,rect,isRefresh)
	local ret = {}
	for i=1,#viewVoList do
		local v = viewVoList[i]
		if rect:intersectsRect(CCRectMake(v.posX,v.posY,itemWidth,itemHeight)) then
			table.insert(ret,v)
		end
	end

	for i=1,cacheDicLen do
		local item = cacheDic:objectForKey(string.format(key,i))
		if item then
			local v = ret[i]
			if v ~= nil then
				item:setPosition(ccp(v.posX,v.posY))
				item:setData(v,isRefresh)
				if item:getParent() == nil then
					scrol:addChild(item)
				end
			else
				item:removeFromParentAndCleanup(false)
			end
		end
	end
end
