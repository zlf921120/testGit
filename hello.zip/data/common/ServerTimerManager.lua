--
-- Author: lvgansheng
-- Date: 2014-08-29 16:43:21
-- 跟服务端做时间的校准


ServerTimerManager = class("ServerTimerManager")

local _instance = nil
local _allowInstance = false

ServerTimerManager.diff_value = 0
ServerTimerManager.open_day = 0

function ServerTimerManager:init()
	-- self._onSendSystemTimeReq = function()
	-- 	Notifier.remove(CmdName.Main_UI_Init_Success, self._onSendSystemTimeReq)
	-- 	self:sendSystemTimeReq()
	-- end

	-- Notifier.regist(CmdName.Main_UI_Init_Success, self._onSendSystemTimeReq)
end

function ServerTimerManager:getInstance()
	 if _instance == nil then
        _allowInstance = true
        _instance = ServerTimerManager.new()
        _instance:init()
        _allowInstance = false
    end

    return _instance
end

--请求服务端当前时间
function ServerTimerManager:sendSystemTimeReq()
 	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.zone_system_time_rsp, "onGetSystemTimeRsp()")
	local zone_system_time_req = zone_pb.zone_system_time_req()
	zone_system_time_req.client_time = os.time()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.zone_system_time_req,zone_system_time_req)
end

--同步服务端时间
function onGetSystemTimeRsp(pbPkgData)
	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.zone_system_time_rsp, "onGetSystemTimeRsp()")
	
	local  zone_system_time_rsp = zone_pb.zone_system_time_rsp()
	zone_system_time_rsp:ParseFromString(pbPkgData)

	if zone_system_time_rsp.ret ~= error_code_pb.msg_ret.success then
		cclog("sync svr time fail:%d",zone_system_time_rsp.ret)
		return
	end


	_instance:setSrvTime(zone_system_time_rsp.time)
	-- _instance.diff_value = zone_system_time_rsp.time - os.time()
	-- cclog("跟服務端的時間差%d",_instance.diff_value)
	-- cclog("跟服務端的時間差%d",_instance.diff_value)
	-- cclog("跟服務端的時間差%d",_instance.diff_value)
	-- cclog("跟服務端的時間差%d",_instance.diff_value)
end

function ServerTimerManager:setSrvTime(srv_time)
	self.diff_value = srv_time - os.time()
	cclog("跟服務端的時間差%d",_instance.diff_value)
	cclog("跟服務端的時間差%d",_instance.diff_value)
	cclog("跟服務端的時間差%d",_instance.diff_value)
	cclog("跟服務端的時間差%d",_instance.diff_value)
    
    Notifier.dispatchCmd(CmdName.SYSTEM_UPDATE_TIME)
end

function ServerTimerManager:setOpenDay(day)
	self.open_day = day
end
--获取 当前是开服第N天
function ServerTimerManager:getOpenDay()
	return self.open_day
end

--获取校准过后的本地时间
function ServerTimerManager:getCurTime()
	local cur_time = os.time()
	return cur_time+self.diff_value
end

function ServerTimerManager:getTimeDiff(end_time)
    local diff = end_time - self:getCurTime()
    return diff
end

--获取当前客户端跟服务端的时间差
function ServerTimerManager:getClientDiffSrvTime()
	return self.diff_value
end

function ServerTimerManager:transSrvTime2Client(srv_time)
	return srv_time-self.diff_value
end