--Encapsulate SimpleAudioEngine to AudioEngine,Play music and sound effects. 

require("SysSettingMgr")

local M = {}
local sharedEngine = SimpleAudioEngine:sharedEngine()
local dp = SoundDataProxy:getInstance()
function M.stopAllEffects()
    sharedEngine:stopAllEffects()
end

function M.getMusicVolume()
    return sharedEngine:getBackgroundMusicVolume()
end

function M.isMusicPlaying()
    return sharedEngine:isBackgroundMusicPlaying()
end

function M.getEffectsVolume()
    return sharedEngine:getEffectsVolume()
end

function M.setMusicVolume(volume)
    sharedEngine:setBackgroundMusicVolume(volume)
end

function M.stopEffect(handle)
    sharedEngine:stopEffect(handle)
end

function M.stopMusic(isReleaseData)
    local releaseDataValue = false
    if nil ~= isReleaseData then
        releaseDataValue = isReleaseData
    end
    sharedEngine:stopBackgroundMusic(releaseDataValue)
end

function M.playMusic(id, isLoop)
    local loopValue = false
    if nil ~= isLoop then
        loopValue = isLoop
    end

    if SysSettingMgr:getInstance():isPlayBgMusic()~=true then
        -- cclog("系統設置說不能播放背景音樂")
        return
    end


    local soundVo = dp:getSoundVoById(id)
    M.stopMusic()
    sharedEngine:playBackgroundMusic(soundVo.src, loopValue)
end

function M.pauseAllEffects()
    sharedEngine:pauseAllEffects()
end

function M.playRandomBattleMuisc(isLoop)

    if SysSettingMgr:getInstance():isPlayBgMusic()~=true then
        return
    end

    local loopValue = false
    if nil ~= isLoop then
        loopValue = isLoop
    end
    M.stopMusic()
    local id = math.random(SoundCfg.Battle01,SoundCfg.Battle03)
    M.playMusic(id,loopValue)
end

function M.preloadMusic(id)
    local soundVo = dp:getSoundVoById(id)
    sharedEngine:preloadBackgroundMusic(soundVo.src)
end

function M.resumeMusic()
    sharedEngine:resumeBackgroundMusic()
end

function M.playEffect(id, isLoop)
    local loopValue = false
    if nil ~= isLoop then
        loopValue = isLoop
    end

     if SysSettingMgr:getInstance():isPlaySoundEffect()~=true then
        -- cclog("系統設置說不能播放音效")
        return
    end

    local soundVo = dp:getSoundVoById(id)
    if not soundVo then
        print("==============播放音效時缺失資料, id:", id)
        return
    end
    return sharedEngine:playEffect(soundVo.src, loopValue)
end

function M.rewindMusic()
    sharedEngine:rewindBackgroundMusic()
end

function M.willPlayMusic()
    return sharedEngine:willPlayBackgroundMusic()
end

function M.unloadEffect(id)
    local soundVo = dp:getSoundVoById(id)
    sharedEngine:unloadEffect(soundVo.src)
end

function M.preloadEffect(id)
    local soundVo = dp:getSoundVoById(id)
    sharedEngine:preloadEffect(soundVo.src)
end

function M.setEffectsVolume(volume)
    sharedEngine:setEffectsVolume(volume)
end

function M.pauseEffect(handle)
    sharedEngine:pauseEffect(handle)
end

function M.resumeAllEffects(handle)
    sharedEngine:resumeAllEffects()
end

function M.pauseMusic()
    sharedEngine:pauseBackgroundMusic()
end

function M.resumeEffect(handle)
    sharedEngine:resumeEffect(handle)
end

local modename = "AudioEngine"
local proxy = {}
local mt    = {
    __index = M,
    __newindex =  function (t ,k ,v)
        print("attemp to update a read-only table")
    end
} 
setmetatable(proxy,mt)
_G[modename] = proxy
package.loaded[modename] = proxy


