--
-- Author: lvgansheng
-- Date: 2014-07-17 19:19:48
-- 公共协议发送器

ComSender = class("ComSender")
ComSender._lastPkgCmd = 0     --记录最近一个包的cmd
ComSender._lastPkgContent = "" --记录最近一个包的内容
ComSender._lastSendTime = 0 --记录最近一个包的发送时间点

local _instance = nil
local _allowInstance = false
local _is_game_star = false
--不需要发送notify的协议
local _black_req_name_list = {}
_black_req_name_list[proto_cmd_pb.msg_cmd.acct_quick_register_req] = 1
_black_req_name_list[proto_cmd_pb.msg_cmd.acct_manual_register_req] = 1
_black_req_name_list[proto_cmd_pb.msg_cmd.acct_login_req] = 1
_black_req_name_list[proto_cmd_pb.msg_cmd.zone_login_req] = 1
_black_req_name_list[proto_cmd_pb.msg_cmd.zone_logout_req] = 1
_black_req_name_list[proto_cmd_pb.msg_cmd.zone_system_time_req] = 1
_black_req_name_list[proto_cmd_pb.msg_cmd.sp_client_err_submit_req] = 1
_black_req_name_list[proto_cmd_pb.msg_cmd.sp_client_gm_req] = 1

local max_interval = 60000 
local step_interval = 5000
local def_interval = 15000
local cur_interval = def_interval

local function updateSendInterval()
	cur_interval = cur_interval + step_interval
	if cur_interval>max_interval then
		cur_interval = def_interval
	end
end

--定时自动申请协议
local function atuoSendProto()
    if CharacterManager:getInstance()._is_game_star~=true then
        return
    end

    -- if BattleManager:getInstance():isBattle()  then
    --     return
    -- end
    local role_notify_req = role_pb.role_notify_req()

    _instance:send(proto_cmd_pb.msg_cmd.role_notify_req, role_notify_req)
    cclog("心跳包")
    -- Global:sendPkg(proto_cmd_pb.msg_cmd.role_notify_req, role_notify_req:SerializeToString(), role_notify_req:ByteSize())
end

function ComSender:ctor()

    if not _allowInstance then
        error("ComSender is a singleton class,please call getInstance method")
    end
end

function ComSender:getInstance()

    if _instance == nil then
        _allowInstance = true
        _instance = ComSender.new()
        _allowInstance = false
    end

    return _instance
end

--跳转到主界面后开始心跳包
function ComSender:beginHeartbeat()

    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.role_notify_req+1, "onGetNotifyRsp()")   
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.role_transform_info_rsp, "roleTransInfoRsp()") 

    TimerManager.addTimer(max_interval, atuoSendProto,true)

    -- local function onGameStar()
    --     _is_game_star = true
    --     Notifier.remove(CmdName.GameStar,onGameStar)
    --     TimerManager.addTimer(max_interval, atuoSendProto,true)
    -- end
    -- Notifier.regist(CmdName.GameStar,onGameStar)  
end

function onGetNotifyRsp(pbPkgData)
    local notify_rsp = role_pb.role_notify_rsp()
    notify_rsp:ParseFromString(pbPkgData)

    print("------------------------onGetNotifyRsp------------------------------------")

    if notify_rsp.ret ~= error_code_pb.msg_ret.success then
        Helper.getErrStr(notify_rsp.ret) --检测
        -- cclog("role_notify_rsp fail,i don't know why---%s",)
        return 
    end        

    ComSender:getInstance():dealExtInfo(notify_rsp.ext)
   
end


function ComSender:send(req_name, proto_req, is_send_notify, isRetry)
        
    -- 未收到初始化协议，不允许做任何事情
    if CharacterManager:getInstance()._is_game_star~=true and
       (req_name~=proto_cmd_pb.msg_cmd.role_info_req and 
        req_name~=proto_cmd_pb.msg_cmd.zc_zone_list_req and
        req_name~=proto_cmd_pb.msg_cmd.acct_login_req and 
        req_name~=proto_cmd_pb.msg_cmd.zone_login_req and 
        req_name~=proto_cmd_pb.msg_cmd.acct_quick_register_req and 
        req_name~=proto_cmd_pb.msg_cmd.acct_manual_register_req and
        req_name~=proto_cmd_pb.msg_cmd.sp_client_err_submit_req and 
        req_name~=proto_cmd_pb.msg_cmd.acct_sdk_login_req) then

       cclog("還沒有收到初始化協議，你別亂來~~~~%d",req_name)
       cclog("還沒有收到初始化協議，你別亂來~~~~%d",req_name)
       cclog("還沒有收到初始化協議，你別亂來~~~~%d",req_name)
       cclog("還沒有收到初始化協議，你別亂來~~~~%d",req_name)
       cclog("還沒有收到初始化協議，你別亂來~~~~%d",req_name)
       cclog("還沒有收到初始化協議，你別亂來~~~~%d",req_name)
       cclog("還沒有收到初始化協議，你別亂來~~~~%d",req_name)
       return
    end

    --同一条协议，100毫秒内不允许发送
    if self._lastPkgCmd == req_name and 
        os.clock()-self._lastSendTime<0.1 then
        cclog("短時間內發送同一協定，無視~~~~協定號：%d~~~~~%f",req_name,os.clock()-self._lastSendTime)
        return
    end
    cclog("協議號：%d~~~~~%f",req_name,os.clock()-self._lastSendTime)
    local proto_content = proto_req:SerializeToString()

    self._lastSendTime = os.clock()
    self._lastPkgCmd = req_name
    self._lastPkgContent = proto_content

    if not isRetry then
        isRetry = 0
    end

    Global:sendPkg(req_name, proto_content , string.len(proto_content), isRetry)
   	
    TimerManager.addTimer(max_interval, atuoSendProto,true) --重新开始计时
end

function ComSender:sendLastPkg()

    Global:sendPkg(self._lastPkgCmd, self._lastPkgContent , string.len(self._lastPkgContent), 1)
end

--变身GM命令的特殊需求
function roleTransInfoRsp(pbPkgData)
    local transform_info_rsp = role_pb.role_transform_info_rsp()
    transform_info_rsp:ParseFromString(pbPkgData)

    if transform_info_rsp.ret ~= error_code_pb.msg_ret.success then
        cclog("role_transform_info_rsp fail,i don't know why---%d",transform_info_rsp.ret)
        return 
    end

    --重置所有英雄数据
    if transform_info_rsp.heroes then
        HeroManager:getInstance():initHeroList(transform_info_rsp.heroes, HeroHelper.hero_info_req_type.all)
    end

    --重置所有装备数据
    if transform_info_rsp.eqms then 
        ItemManager:getInstance():clearAllEqm()
        HeroManager:getInstance():setHeroAllEqms(transform_info_rsp.eqms)
    end

    --战队数据有变化，主动请求多一次，GM命令才这样做
    if transform_info_rsp.team then
        TeamManager:getInstance():reqTeamAllInfo(TeamType.Normal, true)
    end

    --更新资产
    if transform_info_rsp.assets then
      CharacterManager:getInstance():updateRoleAssets(transform_info_rsp.assets)
    end

    --更新背包物品
    if transform_info_rsp.items then
        --客户端主动删除所有物品
        local backpackItemTab = ItemManager:getInstance().backpackItemTab
        local delItemTab = {}
        for i,v in pairs(backpackItemTab) do
             table.insert(delItemTab, i)
        end
        ItemManager:getInstance():delMultiItem(delItemTab)

        --添加物品
        ItemManager:getInstance():addMultiItem(transform_info_rsp.items)
    end 

    ComSender:getInstance():dealExtInfo(transform_info_rsp.ext)
end

function ComSender:dealExtInfo(srv_ext_info)
    local srv_ext_info = srv_ext_info
    
    --任务相关
    if srv_ext_info.task_info.is_filled>0 then
         TaskManager:getInstance():updateTaskStatus(srv_ext_info.task_info.update_tasks, 
                                                     srv_ext_info.task_info.add_tasks)
    end
    --notify_info相关，是否有新聊天，新公告等
    if srv_ext_info.notify_info.is_filled>0 then
        print(" notify_info 相關!!!! ")
        if srv_ext_info.notify_info.has_new_mail == 1 then
            print("有新郵件!!!")
            Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.mail)
        end
        if #srv_ext_info.notify_info.new_chats > 0 then
            require "ChatDataProxy"
            require "ChatCfg"
            require "ChatNetTask"
            print("有新聊天資訊內容!!!")
            local isHasGuild = false
            local isHasWorld = false
            for i=1,#srv_ext_info.notify_info.new_chats do
                print("類型",srv_ext_info.notify_info.new_chats[i])
                if srv_ext_info.notify_info.new_chats[i] == ChatArea.ORGANIZ then
                    isHasGuild = true
                end
                if srv_ext_info.notify_info.new_chats[i] == ChatArea.WORLD then
                    isHasWorld = true
                end
            end
            
            local dp = ChatDataProxy:getInstance()
            dp:makeChatNewTips(srv_ext_info.notify_info.new_chats)
            Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.chat)
            if isHasGuild then
                ChatNetTask:getInstance():requestOrganizChatCycle()
            end
            if isHasWorld then
                ChatNetTask:getInstance():requestWorldChatCycle()
            end
        end
        if srv_ext_info.notify_info.has_new_gm > 0 then
            require "ChatDataProxy"
            local dp =  ChatDataProxy:getInstance()
            if srv_ext_info.notify_info.has_new_gm > 0 then
                dp:getChatNews()[4] = "done"  --GM 信息提示
            end
            Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.chat)
        end
        if #srv_ext_info.notify_info.rolling_notices > 0 then
            CharacterDataProxy:getInstance():makeScrolCacheList(srv_ext_info.notify_info.rolling_notices)
        end
        if srv_ext_info.notify_info.arena_reduce > 0 then
            print("競技場被打下來了!!!")
            Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.arena)
            CharacterManager:getInstance():getBaseData()._newsTipList["arena"] = 0 --0 显示 1 不显示
            
        end
        if srv_ext_info.notify_info.mysticism > 0 then
            ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Mystery,function()
                print("神秘商人刷新了!!!")
                require "ShopDataProxy"
                ShopDataProxy:getInstance().isCanFreshMystery = 1
                Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.mystery)
            end,false)
        end
        if #srv_ext_info.notify_info.notices >= 1 then
            print("有公告!!!!!!")
            require "NoticeDataProxy"
            local notices = srv_ext_info.notify_info.notices
            NoticeDataProxy:getInstance():makeNoticeBySvr(notices)
            NoticeDataProxy:getInstance():checkPopNotice()
        end
        if srv_ext_info.notify_info.has_gift >= 1 then
            print("有新的VIP禮包!!!!!!")
            require "VipDataProxy"
            Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.vip)
        end
        if srv_ext_info.notify_info.is_vip_signin >= 1 then
            print("有簽到物品可領!!!!")
            SignDataProxy:getInstance().hasNewTips = 0
            Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.reward)
        end
        if srv_ext_info.notify_info.encrypted_green and srv_ext_info.notify_info.encrypted_green >= 1 then
            print("有公會戰更新!!!")
            GuildDataProxy:getInstance().short_fight_news_enter = 1 
            GuildDataProxy:getInstance():checkGuildNewsTips()
        end
        if srv_ext_info.notify_info.guild_auction_green and srv_ext_info.notify_info.guild_auction_green >= 1 then
            print("有人出的競拍價超過你了!!!")
            GuildDataProxy:getInstance().myauction_news = 1
            GuildDataProxy:getInstance():checkGuildNewsTips()
        end
        if srv_ext_info.notify_info.new_spoils_green and srv_ext_info.notify_info.new_spoils_green >= 1 then
            print("公會戰有新戰力品分配!!!")
            GuildDataProxy:getInstance().fight_reward_news = 1
            GuildDataProxy:getInstance():checkGuildNewsTips()
        end
        if srv_ext_info.notify_info.activitie_is_charge == 1 then
            print("可以去領首沖獎勵!!!!")
            CharacterManager:getInstance():getBaseData()._chargeStatus = srv_ext_info.notify_info.activitie_is_charge
            Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.first_charge)
        end
    end

    --公会战时间规则
    if srv_ext_info.combat_rule.is_filled>0 then
        print("公會戰新消息!!!!")
        GuildDataProxy:getInstance():saveGuildFightRule(srv_ext_info.combat_rule.rule)
        GuildDataProxy:getInstance().progressSchedule()
    end

    --活动相关
    if srv_ext_info.activitie_info.is_filled>0 then
        print("活動相關")
        local dp = RewardDataProxy:getInstance()
        local totalDay = srv_ext_info.activitie_info.day
        dp._totalLoginDay = totalDay
        dp:isShowNewsTips() --检查绿点情况
        dp:isShowActivityIcon() --检查图标情况
    end

    --公会相关
    if srv_ext_info.guild_info.is_filled>0 then
        print("公會相關!!!!")
        require("GuildNetTask")
        require("GuildDataProxy")
        local role_id = srv_ext_info.guild_info.id
        local guild_id = srv_ext_info.guild_info.guild_id
        local worship = srv_ext_info.guild_info.worship

        if role_id ~= nil and Helper.mathCurRoId(role_id) == true then --匹配玩家自身

            if srv_ext_info.guild_info.operate == OrganizCommHandle.guild_appointment or
              srv_ext_info.guild_info.operate == OrganizCommHandle.guild_abdicate then  --被任命 或 被让位
                print(" 被任命 或 被讓位 !!!!!!!!!! ")
                 GuildNetTask:getInstance():handleAppointMentBySvr(role_id,srv_ext_info.guild_info.post)
            elseif srv_ext_info.guild_info.operate == OrganizCommHandle.guild_eliminate or
                  srv_ext_info.guild_info.operate == OrganizCommHandle.guild_agree_apply then  --被剔除 或 被同意
                
                print(" 被剔除 或 被同意 !!!!!!!! ",role_id)
                if CharacterManager:getInstance():getGuildData():getId() ~= 0 then
                    CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
                    CharacterManager:getInstance():updateRoleAssets( srv_ext_info.guild_info.assets )
                    --跳转公开场景(被T)
                    GuildDataProxy:getInstance():closeAllGuildView()
                else
                    --更新 公会 所有数据
                    CharacterManager:getInstance():getGuildData():initJoinGuild()
                    WindowCtrl:getInstance():close(CmdName.Guild_View_Public)
                    WindowCtrl:getInstance():open(CmdName.Guild_View_Member)
                end

            elseif srv_ext_info.guild_info.operate == OrganizCommHandle.guild_lose_apply then --被忽略
                print("  被忽略 !!!!!!!!!!")
                GuildNetTask:getInstance():handleIgnoreBySvr(role_id,guild_id)
            end

            if worship ~= nil then
                print(" 被膜拜 !!!!!!!!! ")
                GuildNetTask:getInstance():handleDescWorshipBySvr(worship)
            end
        end

        CharacterManager:getInstance():getGuildData()._hasBeenFightNum = srv_ext_info.guild_info.combat_att
        if srv_ext_info.guild_info.boss ~= nil then
            print("刷新boss列表!!!!")
            GuildDataProxy:getInstance():makeGuildBossHpBySvr(srv_ext_info.guild_info.boss)
        end
    end

    --副本相关
    if srv_ext_info.dungeon_info.is_filled>0 then

        DungeonManager:getInstance():initResDungeonSchedule(srv_ext_info.dungeon_info.open_res_duns)
        
        if srv_ext_info.dungeon_info.base.dungeon_id > 0 then
            DungeonManager:getInstance():updateOneScheduleBySrv(srv_ext_info.dungeon_info.base,
                                    srv_ext_info.dungeon_info.grade, srv_ext_info.dungeon_info.number)
        end

        if srv_ext_info.dungeon_info.res_dun_info.base_id > 0 then
            ResContendManager:getInstance():initDungeonData(srv_ext_info.dungeon_info.res_dun_info)
        end

        if #srv_ext_info.dungeon_info.new_res_dun_guard_base_ids > 0 then
            ResContendManager:getInstance():addNewGuardIds(
                srv_ext_info.dungeon_info.new_res_dun_guard_base_ids
            )
        end

        if #srv_ext_info.dungeon_info.rob_res_duns > 0 then
            ResContendManager:getInstance():setBeRobResDun(
                srv_ext_info.dungeon_info.rob_res_duns
            )
            Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP, NewTipsEnum.guard)
        end

        if #srv_ext_info.dungeon_info.can_change_dun_ids > 0 then
            ResContendManager:getInstance():setCanChangeDun(
                srv_ext_info.dungeon_info.can_change_dun_ids
            )
            Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP, NewTipsEnum.guard)
        end

        if srv_ext_info.dungeon_info.puzzle_dungeon.dungeon_id > 0 then
            require "secret/SecretNetTask"
            SecretNetTask:getInstance().handleUpdateBySvr(srv_ext_info.dungeon_info.puzzle_dungeon.dungeon_id,srv_ext_info.dungeon_info.puzzle_dungeon.dungeon_difficulty)
        end
    end

    --英雄相关
    if srv_ext_info.hero_info.is_filled>0 then
        HeroManager:getInstance():addHerosBySrv(srv_ext_info.hero_info.add_heroes)
        HeroManager:getInstance():addHerosBySrv(srv_ext_info.hero_info.hero_bases)
    end

    --战队相关
    if srv_ext_info.team_info.is_filled>0 then
        TeamManager:getInstance():_freshTeamInfoBySrv(srv_ext_info.team_info.type, 
                    srv_ext_info.team_info.base, srv_ext_info.team_info.combat_info,
                    srv_ext_info.team_info.standby_info, srv_ext_info.team_info.skills)
    end

    --竞技场相关
    if srv_ext_info.arena_info.is_filled>0 then
         ArenaManager:getInstance():refreshArenaInfoBySrv(srv_ext_info.arena_info.left_num, 
                         srv_ext_info.arena_info.cooldown_time, srv_ext_info.arena_info.rank, 
                         srv_ext_info.arena_info.targets, srv_ext_info.arena_info.reset_num,
                         srv_ext_info.arena_info.history_rank)
    end

    --星空神殿相关
    if srv_ext_info.glory_info.is_filled>0 then
        require("GloryNetTask")
        GloryNetTask:getInstance():handleGloryInfoBySvr(srv_ext_info.glory_info.my_hp,srv_ext_info.glory_info.targets)
    end

    --公会战相关
    if srv_ext_info.combat.is_filled>0 then
        require "GuildNetTask"
        GuildNetTask:getInstance():handleGuildFightHpBySvr(srv_ext_info.combat.my_hp,srv_ext_info.combat.members_mrole)
    end

    --系统信息
    if srv_ext_info.system_info.is_filled > 0 then
        local stm = ServerTimerManager:getInstance()
        stm:setSrvTime(srv_ext_info.system_info.time)
        if stm:getOpenDay() ~= 0 and stm:getOpenDay() ~= srv_ext_info.system_info.open_day then
            stm:setOpenDay(srv_ext_info.system_info.open_day)
            Notifier.dispatchCmd(CmdName.updateOpenTime)
        end
    end

    --(凌晨5点)重置数据
    if srv_ext_info.global_info.is_filled > 0 then
        cclog("心跳包的淩晨5點重置數據")
        _instance:resetNewDayData(srv_ext_info.global_info) 
    end

    --vip信息更新
    if srv_ext_info.vip_info.is_filled >0 then
    	CharacterManager:getInstance():updateVIPdata(srv_ext_info.vip_info.lev , 
    													srv_ext_info.vip_info.exp)
    	cclog("vip經驗~~~~%d~~等級~~~%d",srv_ext_info.vip_info.exp, srv_ext_info.vip_info.lev)
    end

    --充值信息更新
    if srv_ext_info.charge_info.is_filled>0 then
        require("PayManager")
        CharacterManager:getInstance():updatePayData(srv_ext_info.charge_info.goods_type , 
                                                        srv_ext_info.charge_info.end_day)
        PayManager:getInstance():updatePayGoodsList(srv_ext_info.charge_info.goods_list)

        CharacterManager:getInstance():updateRoleAssets( srv_ext_info.charge_info.assets )
        cclog("goods_type=%d~~~~~end_day=%s",srv_ext_info.charge_info.goods_type,srv_ext_info.charge_info.end_day)
    end
    --节日活动
    if srv_ext_info.ext_holiday.is_filled > 0 then
        print("節日活動更新了!!!!")
        FestivalDataProxy:getInstance():makeFestivalInfos(srv_ext_info.ext_holiday.holiday)
    end

    --天空之役
    if srv_ext_info.sky_battle_info.is_filled > 0 then
        require "SkywarManager"
        SkywarManager:getInstance():setOpenTime(srv_ext_info.sky_battle_info.sky_battle_periods)
    end
    print("好友邀请资讯内容",srv_ext_info.sns_info.is_filled,srv_ext_info.sns_info.request_friend_num)
    if srv_ext_info.sns_info.is_filled >0 then
        print("收到好友的邀请===================")
        print("收到好友的邀请===================")
        print("收到好友的邀请===================")
        print("收到好友的邀请===================")
        print("收到好友的邀请===================")
        print("收到好友的邀请===================")
        require "FriendMgr"
        require "CharacterManager"
        if CharacterManager:getInstance():getTeamData():getLev() >= 20 then
            FriendMgr:getInstance():setNewTips(true)
            Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.friend)
        else
            print("btn no see")
            print("btn no see")
            print("btn no see")
            print("btn no see")
            FriendMgr:getInstance():setNewTips(true)
            Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP, NewTipsEnum.friend)
            -- Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.friend)
        end
        
    end
end

function ComSender:isHeartBeatCMD()
   if self._lastPkgCmd == proto_cmd_pb.msg_cmd.role_notify_req then
        return true
   end
   return false
end


function ComSender:resetNewDayData(srv_global_info)
       print(" (淩晨5點)重置數據 ")
        require "GloryDataProxy" -- 星空神殿的重置次数刷新
        GloryDataProxy:getInstance():refreshGlory(srv_global_info.glory_num)
        require "CharacterDataProxy" --购买体力+购买体力次数刷新
        CharacterDataProxy:getInstance():refreshBuyCoinPhysical(srv_global_info.physical)
        require "DungeonManager" --困难+噩梦+宝藏副本次数刷新,副本可购买次数刷新
        DungeonManager:getInstance():refreshDungeon(srv_global_info.dungeon)
        require "SignDataProxy" -- 签到的天数数据刷新
        SignDataProxy:getInstance():refreshSign()
        require "LotteryDataProxy" --淘宝的免费次数刷新
        LotteryDataProxy:getInstance():refreshLottery(srv_global_info.boxdraw)
        require "TowerDataProxy" -- 爬塔的重置次数刷新
        TowerDataProxy:getInstance():refreshTower(srv_global_info.climbing_num)
        --公会Boss已挑战次数
        CharacterManager:getInstance():refreshCharacter(srv_global_info.guild)
        --竞技场相关信息刷新
        require("ArenaManager")
        ArenaManager:getInstance():refreshNewDayData(srv_global_info.arena.srv_left_num, 
                    srv_global_info.arena.srv_cd_time, srv_global_info.arena.srv_reset_num)
        --任务刷新
        require("TaskManager")
        TaskManager:getInstance():initTaskInfo(srv_global_info.task.tasks, 
                srv_global_info.task.done_tasks , srv_global_info.task.future_tasks)
end