--
-- Author: thisgf
-- Date: 2014-06-12 11:27:16
-- 管理器接口

require "ComSender"

IManager = class("IManager")

IManager._logPrefix = "調試"

function IManager:create()
	local im = IManager.new()
	return im
end

function IManager:log(...)

	local arg = {...}

	if #arg == 0 then
		return
	end

    local info = arg[1]
    info = self._logPrefix .. " >> " .. info
    arg[1] = info

    cclog(unpack(arg))

end

function IManager:sendProto(pkg, isRetry)

    local message_meta = getmetatable(pkg)
    if message_meta == nil then
    	error("發送協定失敗", 2)
    end

    local cmdName = proto_cmd_pb.msg_cmd[message_meta._descriptor.name] or 
                    proto_cmd_2_pb.msg_cmd2[message_meta._descriptor.name]
    -- if not cmdName then
    --     cmdName = proto_cmd_2_pb.msg_cmd2[message_meta._descriptor.name]
    -- end

    local serialize = pkg:SerializeToString()
    local byteSize = pkg:ByteSize()
    if byteSize == 0 then
    	byteSize = string.len(serialize)
    end

    ComSender:getInstance():send(cmdName, pkg, nil, isRetry)

end


