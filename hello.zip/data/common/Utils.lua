require("XArray")
Utils = {}

--[[
	清空数组的所有元素
	@param t 要清空的顺序表
--]]
Utils.clear = function(t)
	while(#t > 0) do
		table.remove(t , #t)
	end
end

Utils.get_length_from_any_table = function(tableValue)
	local tableLength = 0
	
	for k, v in pairs(tableValue) do
		tableLength = tableLength + 1
	end
	
	return tableLength
end

--[[
	clone对象，针对protobuf的地方使用
	@param objLeft	左值
	@param objRight 右值
--]]
Utils.tclone = function(objLeft , objRight)
	local strData = objRight:SerializeToString()
	objLeft:ParseFromString(strData)
end

--[[
	对table里面的每一项做值拷贝，只有一层有效
	@param objLeft	左值
	@param objRight 右值
--]]
Utils.copy = function(objLeft , objRight)
	for k,v in pairs(objRight)do
		objLeft[k] = v
	end
end

--[[
	根据分隔符分割字符串，返回分割后的table
--]]
Utils.split = function(s, delim)
  assert (type (delim) == "string" and string.len (delim) > 0, "bad delimiter")
  local start = 1
  local t = {}  -- results table

  -- find each instance of a string followed by the delimiter
  while true do
    local pos = string.find(s, delim, start, true) -- plain find
    if not pos then
      break
    end

    table.insert (t, string.sub (s, start, pos - 1))
    start = pos + string.len (delim)
  end -- while

  -- insert final one (after last delimiter)
  table.insert (t, string.sub (s, start))
  return t
end


Utils.int2ip = function(intIP)
	local retIP = ""
	local leftValue = intIP
	for i=0,3 do
		local temp = math.pow(256,3-i)
		local sectionValue = math.floor(leftValue/temp)
		leftValue = leftValue % temp
		retIP = sectionValue..retIP
		if(i~=3) then
			retIP = "."..retIP
		end
	end
	return retIP
end

--[[
	获取某个动作的播放时长
--]]
Utils.getSeqTime = function(ccbi , act_name)
	local amb = ccbi:getAnimationManager()
	if(not amb)then
		return 0
	end
	local seqId = amb:getSequenceId(act_name)
	if(not seqId)then
		return 0
	end
	local seq = amb:getSequence(seqId)
	if(not seq)then
		return 0
	end
	return seq:getDuration()
end

--[[
	打印调试信息
--]]
_trace = function(msg)
	Global:cclog(msg)
end



Utils.length = function(str)
	return #(str.gsub('[\128-\255][\128-\255]',' '))
end

Utils.sub = function(str,s,e)
	str = str:gsub('([\001-\127])','\000%1')
	str = str:sub(s*2+1,e*2)
	str = str:gsub('\000','')
	return str
end

Utils.trans = function(str)
   local n = string.len(str)
   local str2 = ""
   local k = 1
   for i = 1 , n / 3 do
        str2 = str2 .. string.sub(str , k , k + 2)
        k = k + 3
        str2 = str2 .. "\n"
   end
   return str2
end


Utils.play = function(ccbi, act_name)
	assert(ccbi)
	local man = ccbi:getAnimationManager()
	assert(man)
	man:runAnimationsForSequenceNamedTweenDuration(act_name,0)
	local seqID = man:getSequenceId(act_name)
	local ccbseq = man:getSequence(seqID)
	return ccbseq:getDuration()
end

Utils.CHINESE_MAP = {[0]="零", [1]="一", [2]="二", [3]="三", [4]="四", [5]="五", [6]="六", [7]="七", [8]="八", [9]="九"}
--[[数字转中文]]
Utils.toChinese = function(num)
	assert(num<99)
	if(num < 10) then
		return Utils.CHINESE_MAP[num]
	else
		local a = math.floor(num/10)
		local b = num % 10
		if(b==0) then
			return Utils.CHINESE_MAP[a].."十"
		else
			return Utils.CHINESE_MAP[a].."十"..Utils.CHINESE_MAP[b]
		end
	end
	return ""
end

--[[
	@param label CCSprite 需要描边的sprite
	@param size number 描边大小
	@param color ccc3 描边颜色
	@param opacity number 描边透明度
	@return CCRenderTexture
--]]
Utils.createStroke = function(label, size, color, opacity)
	local rt = CCRenderTexture:create(
		label:getTexture():getContentSize().width + size * 2,
		label:getTexture():getContentSize().height + size * 2)

	local originalPos = ccp(label:getPosition())
	local originalColor = label:getColor()
	local originalOpacity = label:getOpacity()
	local originalVisibility = label:isVisible()
	local originalBlend = label:getBlendFunc()

	local bf = ccBlendFunc()
	bf.src = GL_SRC_ALPHA
	bf.dst = GL_ONE

	label:setColor(color)
	label:setOpacity(opacity or 255)
	label:setVisible(true)
	label:setBlendFunc(bf)

	local bottomLeft = ccp(
		label:getTexture():getContentSize().width * label:getAnchorPoint().x + size, 
		label:getTexture():getContentSize().height * label:getAnchorPoint().y + size)

	local positionOffset= ccp(
		- label:getTexture():getContentSize().width * (0.5-label:getAnchorPoint().x),
		- label:getTexture():getContentSize().height * (0.5-label:getAnchorPoint().y))

	local position = ccp(originalPos.x - positionOffset.x, originalPos.y - positionOffset.y)
	--local position = ccp(originalPos.x, originalPos.y)

	local function render(lab,offsetPos,weight)
		lab:setPosition(ccp(bottomLeft.x + offsetPos.x * weight,bottomLeft.y + offsetPos.y * weight ))
		lab:visit()
	end

	rt:begin()
	-- for i = 0, 360, 15 do
	-- 	local radians = math.rad(i)
	-- 	label:setPosition(ccp(bottomLeft.x + math.sin(radians)*size, bottomLeft.y + math.cos(radians)*size))
	-- 	label:visit()
	-- end
		render(label,ccp(1,0),size)
		render(label,ccp(-1,0),size)
		render(label,ccp(0,1),size)
		render(label,ccp(0,-1),size)

	rt:endToLua()

	label:setPosition(originalPos)
	label:setColor(originalColor)
	label:setBlendFunc(originalBlend)
	label:setVisible(originalVisibility)
	label:setOpacity(originalOpacity)

	--rt:getSprite():setAnchorPoint(label:getAnchorPoint())
	rt:setPosition(position)
	rt:getSprite():getTexture():setAntiAliasTexParameters()

	return rt
end

Utils.createStrokeLabel = function(label, size, color, opacity)

	local ret = CCNode:create()
	local strokeSp = Utils.createStroke(label, size, color, opacity)
	ret.stroke = strokeSp
	ret.label = label
	ret:addChild(strokeSp)
	ret:addChild(label,1)	

	function ret:setString(str)
		ret.label:setString(str)
		ret:removeChild( ret.stroke , true )
		local strokeSp = Utils.createStroke(label, size, color, opacity)
		ret.stroke = strokeSp
		ret:addChild(strokeSp)
	end
	return ret
end

--[[
	@param label CCSprite 需要描边的sprite
	@param offsetX number x方向偏移量
	@param offsetY number y方向偏移量
	@param color ccc3 描边颜色
	@param opacity number 描边透明度
	@return CCRenderTexture
--]]
Utils.createShadow = function(label, offsetX, offsetY, color, opacity)
	local rt = CCRenderTexture:create(
		label:getTexture():getContentSize().width + math.abs(offsetX) * 2,
		label:getTexture():getContentSize().height + math.abs(offsetY) * 2)

	local originalPos = label:getPosition()
	local originalColor = label:getColor()
	local originalOpacity = label:getOpacity()
	local originalVisibility = label:isVisible()
	local originalBlend = label:getBlendFunc()

	local bf = ccBlendFunc()
	bf.src = GL_SRC_ALPHA
	bf.dst = GL_ONE

	label:setColor(color)
	label:setOpacity(opacity)
	label:setVisible(true)
	label:setBlendFunc(bf)

	local bottomLeft = ccp(
		label:getTexture():getContentSize().width * label:getAnchorPoint().x + math.abs(offsetX), 
		label:getTexture():getContentSize().height * label:getAnchorPoint().y  + math.abs(offsetY))

	local positionOffset= ccp(
		- label:getTexture():getContentSize().width * (0.5-label:getAnchorPoint().x),
		- label:getTexture():getContentSize().height * (0.5-label:getAnchorPoint().y))

	local position = ccp(originalPos.x - positionOffset.x, originalPos.y - positionOffset.y)
	--local position = ccp(originalPos.x, originalPos.y)

	rt:begin()
	label:setPosition(ccp(bottomLeft.x + offsetX, bottomLeft.y + offsetY))
	label:visit()
	rt:endToLua()

	label:setPosition(originalPos)
	label:setColor(originalColor)
	label:setBlendFunc(originalBlend)
	label:setVisible(originalVisibility)
	label:setOpacity(originalOpacity)

	--rt:getSprite():setAnchorPoint(label:getAnchorPoint())
	rt:setPosition(position)
	rt:getSprite():getTexture():setAntiAliasTexParameters()

	return rt
end

--创建描边字
function Utils.createStrokeLab(params)
	if type(params) ~= "table" then print(" params type error,you should use table") return end

	function realign(label,x, y)
		local textAlign = label:getTextHorizontalAlignment()
        if textAlign == kCCTextAlignmentLeft then
            label:setPosition(ccp(math.floor(x + label:getContentSize().width / 2), y))
        elseif textAlign == kCCTextAlignmentRight then
            label:setPosition(ccp(x - math.floor(label:getContentSize().width / 2), y))
        else
            label:setPosition(ccp(x, y))
        end
    end

    local refer 	   = tolua.cast(params.label,"Label")  --参考样本
    local color        = refer:getColor() or ccc3(255,255,255)
    local outlineColor = params.outlineColor or ccc3(0,0,0)
    local x, y         = refer:getPosition()
    local txt 		   = params.txt or ""
    local fontSize 	   = refer:getFontSize()
    local weight 	   = params.weight or 1

    local g = CCNode:create()
    params.size  = params.size
    params.color = outlineColor
    params.x, params.y = 0, 0
    
    g.shadow1 = Label:create()
    realign(g.shadow1,weight, -weight)
    g:addChild(g.shadow1)

    g.shadow2 = Label:create()
    realign(g.shadow2,-weight, weight)
    g:addChild(g.shadow2)
    
    -- g.shadow3 = Label:create()
    -- realign(g.shadow3,0, -weight)
    -- g:addChild(g.shadow3)
   
    -- g.shadow4 = Label:create()
    -- realign(g.shadow4,0, weight)
    -- g:addChild(g.shadow4)

    params.color = color
    g.label = Label:create()
    realign(g.label,0, 0)
    g:addChild(g.label)

    --是否需要设置锚点
    if params.anc_point then
		g.shadow1:setAnchorPoint(params.anc_point)
		g.shadow2:setAnchorPoint(params.anc_point)
		-- g.shadow3:setAnchorPoint(params.anc_point)
		-- g.shadow4:setAnchorPoint(params.anc_point)
		g.label:setAnchorPoint(params.anc_point)
    end
    

    function g:setText(text)
        g.shadow1:setText(text)
        g.shadow2:setText(text)
        -- g.shadow3:setText(text)
        -- g.shadow4:setText(text)
        g.label:setText(text)
    end

    function g:getContentSize()
        return g.label:getContentSize()
    end

    function g:setFontSize(fontSize)
    	g.label:setFontSize(fontSize)
        g.shadow1:setFontSize(fontSize)
        g.shadow2:setFontSize(fontSize)
        -- g.shadow3:setFontSize(fontSize)
        -- g.shadow4:setFontSize(fontSize)
    end

    function g:setColor(...)
        g.label:setColor(...)
    end

    function g:setOutlineColor(...)
        g.shadow1:setColor(...)
        g.shadow2:setColor(...)
        -- g.shadow3:setColor(...)
        -- g.shadow4:setColor(...)
    end

    function g:setOpacity(opacity)
        g.label:setOpacity(opacity)
        g.shadow1:setOpacity(opacity)
        g.shadow2:setOpacity(opacity)
        -- g.shadow3:setOpacity(opacity)
        -- g.shadow4:setOpacity(opacity)
    end

    if x and y then
        g:setPosition(x, y)
    end
    g:setText(txt)
    g:setColor(color)
    g:setOutlineColor(outlineColor)
    g:setFontSize(fontSize)
    return g
end

--[[
分割字符串
	@param szFullString 目标字符
	@param szSeparator 	分隔符
--]]
Utils.Split = function(szFullString, szSeparator)
local nFindStartIndex = 1
local nSplitIndex = 1
local nSplitArray = {}
while true do
   local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)
   if not nFindLastIndex then
    nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
    break
   end
   nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
   nFindStartIndex = nFindLastIndex + string.len(szSeparator)
   nSplitIndex = nSplitIndex + 1
end
return nSplitArray
end

--[[
合并字符串
	@param list 目标表
	@param delimiter 分隔符
--]]
Utils.Join = function(delimiter, list)
  local len = table.getn(list)
  if len == 0 then 
    return "" 
  end
  local string = list[1]
  for i = 2, len do 
    string = string .. delimiter .. list[i] 
  end
  return string
end

---- 通过日期获取秒 yyyy-MM-dd HH:mm:ss
Utils.GetTimeByDate = function(r)
    local a = Utils.Split(r, " ")
    local b = Utils.Split(a[1], "-")
    local c = Utils.Split(a[2], ":")
    local t = os.time({year=b[1],month=b[2],day=b[3], hour=c[1], min=c[2], sec=c[3]})
    return t
end

--[[
    格式化时间
    @param sec 秒
    @param sep 分隔符
    @return "hour sep month sep second"
]]
Utils.formatTime = function(sec, sep)

    sep = sep or ":"
    
    if sec < 0 then
        return nil
    end

    local second = sec % 60
    local min = math.floor(sec / 60) % 60
    local hour = math.floor(sec / 3600)

    return string.format("%02d%s%02d%s%02d", hour, sep, min, sep, second)
end


function strCipherPad( rawStr )
	local iLen = string.len( rawStr )
	local iYu = iLen%16
	local strP = ""
	if iYu>0 then
		for i=1, 16-iYu do
			strP = strP .. '\0'
		end
		rawStr = rawStr .. strP
	end
	return rawStr
end

--[[
    转换成中文数字
]]
Utils.toChineseNum = function(num)
	assert(num<99)
	if(num < 10) then
		return Utils.CHINESE_MAP[num]
	else
		local a = math.floor(num/10)
		local b = num % 10

		local tenStr
		if a <= 1 then
			tenStr = "十"
		else
			tenStr = Utils.CHINESE_MAP[a].."十"
		end

		local bits
		if b == 0 then
			bits = ""
		else
			bits = Utils.CHINESE_MAP[b]
		end

		return tenStr .. bits
		
	end
	return ""

end

--[[
    序列化表, 可以通过loadstring反序列化
    @return string
]]
Utils.serializeTable = function(name, value)

    local mark = {}
    
    local function serT(tbl, name)
        mark[tbl] = name
        local tmp = {}
        for k,v in pairs(tbl) do
            local key = type(k) == "number" and "" or k .. "="
            if type(v) == "table" then
                local dotkey = name .. (type(k) == "number" and key or "." .. key)
                if not mark[v] then
                    table.insert(tmp, key..serT(v,dotkey))
                end
            else
                local cv = type(v) == "string" and "\""..v.."\"" or tostring(v)
                table.insert(tmp, key..cv)
            end
        end
        return "{"..table.concat(tmp,",").."}"
    end
 
    return string.format("%s = %s; return %s", name, serT(value, name), name)

end

--四舍五入
-- Utils.