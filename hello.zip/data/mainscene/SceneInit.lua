--
-- Author: lvgansheng
-- Date: 2014-09-03 20:32:49
-- 

SceneInit = class("SceneInit")
SceneInit.loadFuncMap = {}  --加载队列

local _instance = nil
local _allowInstance = false

function SceneInit:init()

	require("CharacterManager")
	require("WindowHelper")
	require("GameLayerMgr")
	require("MainUI")
	require("MainScene")
	require("gm/GmView")
	require "SkillManager"
	require "MonsterManager"
	require "HeroManager"
	require "TaskManager"
	require "DungeonManager"
	require("EffectManager")
	require("ServerTimerManager")
	require("ComResMgr")
	require "GuideEvent"
	require("ItemManager")
	require("TeamManager")
	require "GuildLocalReader"
	require "PetLocalReader"
	
	local ad = CCArmatureDataManager:sharedArmatureDataManager()
	table.insert(self.loadFuncMap,function() ad:addArmatureFileInfo("ui/main_scene/butterfly/butterfly.ExportJson") end)
	table.insert(self.loadFuncMap,function() ad:addArmatureFileInfo("ui/main_scene/sky_battle/sky_battle.ExportJson") end)
	table.insert(self.loadFuncMap,function() ad:addArmatureFileInfo("ui/main_scene/duplicate/duplicate.ExportJson") end)
	table.insert(self.loadFuncMap,function() ad:addArmatureFileInfo("ui/main_scene/forever_tower/forever_tower.ExportJson") end)
	table.insert(self.loadFuncMap,function() ad:addArmatureFileInfo("ui/main_scene/forge/forge.ExportJson") end)
	table.insert(self.loadFuncMap,function() ad:addArmatureFileInfo("ui/main_scene/guild/guild.ExportJson") end)
	table.insert(self.loadFuncMap,function() ad:addArmatureFileInfo("ui/main_scene/honour_road/honour_road.ExportJson") end)
	table.insert(self.loadFuncMap,function() ad:addArmatureFileInfo("ui/main_scene/mystery_trader/mystery_trader.ExportJson") end)
	table.insert(self.loadFuncMap,function() ad:addArmatureFileInfo("ui/main_scene/sea/sea.ExportJson") end)
	table.insert(self.loadFuncMap,function() ad:addArmatureFileInfo("ui/main_scene/shop/shop.ExportJson") end)
	table.insert(self.loadFuncMap,function() ad:addArmatureFileInfo("ui/main_scene/treasure/treasure.ExportJson") end)
	table.insert(self.loadFuncMap,function() ad:addArmatureFileInfo("ui/main_scene/water/water.ExportJson") end)

	table.insert(self.loadFuncMap,function() SkillManager:getInstance():parseConfig()  				end)
	table.insert(self.loadFuncMap,function() EffectManager:getInstance():parseEffectData() 			end)
	table.insert(self.loadFuncMap,function() MonsterManager:getInstance():readData()  				end)
	table.insert(self.loadFuncMap,function() CharacterLocalReader:getInstance():loadInProxy()  		end)
	table.insert(self.loadFuncMap,function() ServerTimerManager:getInstance()  						end)
	table.insert(self.loadFuncMap,function() HeroManager:getInstance():readHeroData()  				end)
	table.insert(self.loadFuncMap,function() TaskManager:getInstance():readTaskData() 				end)
	table.insert(self.loadFuncMap,function() DungeonManager:getInstance()						    end)
	table.insert(self.loadFuncMap,function() ItemManager:getInstance():readItemData()				end)
	table.insert(self.loadFuncMap,function() ItemManager:getInstance():readEqmData()				end)
	table.insert(self.loadFuncMap,function() ItemManager:getInstance():readGemData()				end)
	table.insert(self.loadFuncMap,function() ItemManager:getInstance():loadItemIconPlist()			end)
	table.insert(self.loadFuncMap,function() ServerTimerManager:getInstance()						end)
	table.insert(self.loadFuncMap,function() TeamManager:getInstance()								end)
	table.insert(self.loadFuncMap,function() DungeonManager:getInstance():parseDungeonData()		end)
 	table.insert(self.loadFuncMap,function() PetLocalReader:getInstance():loadInProxy()				end)
    table.insert(self.loadFuncMap,function() GuildLocalReader:getInstance():loadInProxy()			end)

	-- table.insert(self.loadFuncMap,function() ComResMgr:getInstance():loadInitRes()  				end)
	
	LoginDataProxy:getInstance().loadingTotal = #self.loadFuncMap
end

function SceneInit:getInstance()
    if _instance == nil then
        _allowInstance = true
        _instance = SceneInit.new()
        _instance:init()
        _allowInstance = false
    end

    return _instance
end
-- --登录解析数据
local function loginParseData()
	
	-- ItemManager:getInstance():readItemData()
end

-- --登陆后加载资源 
-- local function loginInitRes()
-- 	ComResMgr:getInstance():loadInitRes()
-- end

-- --加载队列资源
-- function SceneInit:loadSequenceRes()
-- 	local dp = LoginDataProxy:getInstance()
-- 	if dp.loadingCout < dp.loadingTotal then
-- 		dp.loadingCout = dp.loadingCout + 1
-- 	end
-- 	self.loadFuncMap[dp.loadingCout]()
-- end

function SceneInit:reqRoleInitReq()

	-- for i=1,#self.loadFuncMap do
	--  	self.loadFuncMap[i]()
	-- end 

	-- 初始化协议信息返回成功后
	Notifier.regist(CmdName.RSP_GET_ROLE_INFO, function() 

		local mainui = WindowCtrl:getInstance():getMainUI()
		if mainui == nil then --如果没创建过，则创建顶部三个控件
			mainui = MainUI:create() 
		end

		local mainScene = GameLayerMgr:getInstance():getMainScene()
		
		local main_view = WindowCtrl:getInstance():getMainScene()
		if main_view then --如果已经存在，说明是从主场景跳转过来的，不需要重新创建
			main_view:delayAction()
		else
			main_view = MainScene:create()
			WindowCtrl:getInstance():setMainScene(main_view)
			GameLayerMgr:getInstance():getSceneLayer():addChild(main_view)
		end
		
		-- local ret = GameLayerMgr:getInstance():getMainScene()
		
		if Global:isDevelop() then
			--GM窗口，仅供测试
			GameLayerMgr:getInstance():getMainScene():addChild(GmView:create(),100)
		end

		--清理登录和选性别场景纹理
		-- CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile("ui/login/login.plist")
		-- CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile("ui/login/ZoneItem0.plist")
		-- CCTextureCache:sharedTextureCache():removeTextureForKey("img_company.png")
		-- CCTextureCache:sharedTextureCache():removeTextureForKey("login_bg.png")
		-- ComResMgr:getInstance():clearCache()

		-- 是否需要显示角色选择/改名窗体
		if CharacterManager:getInstance():getBaseData():getHasCreateGender() == 0 then --未选择
		    WindowCtrl:getInstance():open(CmdName.GENDER_SCENE) 
		elseif CharacterManager:getInstance():getBaseData():getHasCreateGender() == 1 and 
			CharacterManager:getInstance():getBaseData():getHasCreateName()== 0 then
			WindowCtrl:getInstance():open(CmdName.NICKNAME_SCENE)
		end
		
		--开始心跳包
		ComSender:getInstance():beginHeartbeat()

		Notifier.dispatchCmd(CmdName.GameStar)  	
		Notifier.dispatchCmd(CmdName.Main_UI_Init_Success)

	end)

	CharacterManager:getInstance():requireRoleInfo() --请求角色数据

	
	
	return mainScene
end

--退出账号后，回到登陆界面前，需要做的操作
function SceneInit:resetInitStatus()
	require("WindowCtrl")
	--关闭之前打开的所有界面
	WindowCtrl:getInstance():closeAllWin()

	--重置游戏开始状态
	require("CharacterManager")
	CharacterManager:getInstance():setIsGameStart(false)

	--重置星空神殿

	--重置恶魔塔
	
end
