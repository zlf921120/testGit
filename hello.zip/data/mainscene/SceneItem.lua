
--场景元件

SceneItem = class("SceneItem",DisplayUtil.newWidget)

SceneItem.name = nil --元件名称
SceneItem.scene_item_info = 0 --元件类型,稍后定义一个类型文件，图片/动画/其它
SceneItem.name_label = nil
SceneItem.main_body = nil --元件主题部分
SceneItem.name_bg = nil --名字的背景部分
SceneItem.select_light = nil --选中时候的光

local select_status = false
local name_bg_half_width =64

--x轴偏移
local sky_battle_disx = -50
local duplicate_disx = 10
--y轴偏移
local mail_name_disy = -6 --邮件按钮名称的偏差
local treasure_name_disy = -10 --宝箱按钮名称的偏差
local guild_name_disy = -10 --公会按钮名称的偏差
local mystery_trader_name_disy = 12 --神秘商人名称的偏差
local sky_battle_disy = -5
local duplicate_disy = 45 -- 副本名称偏差
local monster_station_disy = -18 --妖怪驻地名称偏差

function SceneItem:init()

    self.select_light = ImageView:create()
    self.select_light:loadTexture("scene_select_light.png",UI_TEX_TYPE_PLIST)
    self.select_light:setScale(1.8)
    self.select_light:setVisible(false)
    self:addChild(self.select_light,0)

    local path = ""
    if self.scene_item_info.icon_type == MainSceneHelper.icon_type.animation then
      path = string.format("ui/main_scene/%s/%s.ExportJson",self.scene_item_info.name,self.scene_item_info.name)
      self.main_body = AnimateManager:getInstance():getArmature(path,self.scene_item_info.name)
      self.main_body:getAnimation():playWithIndex(0)
      self:addNode(self.main_body)
    else
      self.main_body = ImageView:create()
      path = string.format("%s.png",self.scene_item_info.name)
      self.main_body:loadTexture(path,UI_TEX_TYPE_PLIST)
      self:addChild(self.main_body)
    end

    local ccmz = self.main_body:getContentSize()
    local half_width = ccmz.width/2
    local half_height = ccmz.height/2

    self.select_light:setPosition(ccp(half_width,half_height))

    local dis_y = -15
    local dis_x = 0
    if self.scene_item_info.icon_effect == MainSceneHelper.icon_effect.fun_btn then

      self.main_body:setAnchorPoint(ccp(0,0)) -- 功能按钮需要把左下角设置为锚点

      if self.scene_item_info.name=="mail" then
        dis_y = dis_y+mail_name_disy
      elseif self.scene_item_info.name == "mystery_trader" then
      	dis_y = dis_y+mystery_trader_name_disy
      elseif self.scene_item_info.name == "sky_battle" then
        dis_x = dis_x+sky_battle_disx
        dis_y = dis_y + sky_battle_disy
      elseif self.scene_item_info.name == "treasure" then
        dis_y = dis_y + treasure_name_disy
      elseif self.scene_item_info.name == "guild" then
        dis_y = dis_y + guild_name_disy
      elseif self.scene_item_info.name == "duplicate" then
        dis_y = dis_y + duplicate_disy
        dis_x = dis_x + duplicate_disx
      elseif self.scene_item_info.name == "monster_station" then
        dis_y = dis_y + monster_station_disy
      end

    	self.name_bg = ImageView:create()
    	self.name_bg:loadTexture("btn_up_15.png",UI_TEX_TYPE_PLIST)
    	self:addChild(self.name_bg)
      self.name_bg:setPositionX(ccmz.width/2+dis_x)
    	self.name_bg:setPositionY(dis_y)

    	self.name_label = ImageView:create()
      path = string.format("i18n_%s_txt.png",self.scene_item_info.name)
    	self.name_label:loadTexture(path,UI_TEX_TYPE_PLIST)
    	self:addChild(self.name_label)  
      self.name_label:setPositionX(ccmz.width/2+dis_x)  
    	self.name_label:setPositionY(dis_y)	
    end

    self:specialExc()

end

function SceneItem:create(scene_item_info)
	local scene_item = SceneItem.new()
	scene_item.scene_item_info = scene_item_info
	scene_item:init()
	return  scene_item
end

function SceneItem:setSelect(is_select)
  if self.scene_item_info.icon_effect == MainSceneHelper.icon_effect.decoration then
    -- cclog("非功能圖示，不給點擊")
    return
  end

  if select_status == is_select then
    return 
  end
  select_status = is_select
	if is_select then
		self.name_bg:loadTexture("btn_down_15.png",UI_TEX_TYPE_PLIST)
	else
		self.name_bg:loadTexture("btn_up_15.png",UI_TEX_TYPE_PLIST)
	end
  self.select_light:setVisible(is_select)
end

function SceneItem:zoomInIcon()
	if  self.main_body:getScale() ~= 1.1 then
    self.main_body:runAction(CCScaleTo:create(0.1,1.1)) 
		self.select_light:runAction(CCScaleTo:create(0.1,1.9)) 
	end
end

function SceneItem:zoomOutIcon()
	if self.main_body:getScale() ~= 1 then
    self.main_body:runAction(CCScaleTo:create(0.1,1)) 
		self.select_light:runAction(CCScaleTo:create(0.1,1.8)) 
	end
end

--改变动画状态
function SceneItem:changeAnimState(actionName)
    self.main_body:getAnimation():stop()
    self.main_body:getAnimation():play(actionName,-1,-1,1)
end

--蝴蝶特殊处理
function SceneItem:specialExc()
  if self.scene_item_info.name == "butterfly" then
    self.main_body:getAnimation():setMovementEventCallFunc(function(armature, movementType, movementID)
      if movementType == AnimationMovementType.COMPLETE 
        or movementType == AnimationMovementType.LOOP_COMPLETE then 
        self.main_body:getAnimation():pause()
        
        TimerManager.addTimer(5000,function()
           self.main_body:getAnimation():playWithIndex(0)
        end)
      end
    end)
  end
end