--购买 多重 金币 场景

BuyMultCoinScene = class("BuyMultCoinScene",WindowBase)
BuyMultCoinScene.__index = BuyMultCoinScene
BuyMultCoinScene._widget = nil
BuyMultCoinScene.uiLayer = nil

local __instance = nil
local _lastCout = 0

local labCout = nil

function BuyMultCoinScene:create()
    local ret = BuyMultCoinScene.new()
    __instance = ret
    return ret
end

local function event_btn_close(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		WindowCtrl:getInstance():close(CmdName.Character_buyMultCoin)
	end
end

local function event_btn_ok(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		local cout = tonumber(labCout:getStringValue())
		if cout > 0 then
			_lastCout = cout --记录上一次购买量
			CharacterNetTask:getInstance():requestMultBuyCoin(cout)
		end
	end
end

local function update(cout)

	local dp = CharacterDataProxy:getInstance()
	local sceneVo = dp:getBuyCoinSceneVo()

	local totalDiamon = 0
	for i=1,cout do
		totalDiamon = totalDiamon + dp:getBuyCoutDiamonCoin(sceneVo.hadBuyNum + i - 1)
	end

	local totalCoin = cout * dp:getLevCoinAdd()

	labCout:setText(cout)

	local labDiamon = tolua.cast(__instance.uiLayer:getWidgetByName("lab_diamon"),"Label")
	labDiamon:setText(totalDiamon)

	local labCoin = tolua.cast(__instance.uiLayer:getWidgetByName("lab_coin"),"Label")
	labCoin:setText(totalCoin)

end

local function event_btn_min(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		if tonumber(labCout:getStringValue()) > 1 then
			update(tonumber(labCout:getStringValue()) - 1)
		end
	end
end

local function event_btn_add(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		local dp = CharacterDataProxy:getInstance()
		local sceneVo = dp:getBuyCoinSceneVo()

		if tonumber(labCout:getStringValue()) + sceneVo.hadBuyNum < dp:getBuyCoinMax() then
			update(tonumber(labCout:getStringValue()) + 1)
		end
	end
end

function BuyMultCoinScene:open()

	local dp = CharacterDataProxy:getInstance()
	local sceneVo = dp:getBuyCoinSceneVo()

	local cout = dp:getBuyCoinMax() - sceneVo.hadBuyNum --剩余
	if _lastCout > 0 then --二次购买
		if cout > _lastCout then
			cout = _lastCout
		end
	else --首次购买
		if cout > 3 then
			cout = 3
		end
	end

	update(cout)
end

function BuyMultCoinScene:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("main_scene/buyMultCoin.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	local btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_cancel"),"Button")
    btnClose:addTouchEventListener(event_btn_close)

    local btnOk = tolua.cast(self.uiLayer:getWidgetByName("btn_ok"),"Button")
    btnOk:addTouchEventListener(event_btn_ok)
    
    local btnMin = tolua.cast(self.uiLayer:getWidgetByName("btn_min"),"Button")
    btnMin:addTouchEventListener(event_btn_min)

    local btnAdd = tolua.cast(self.uiLayer:getWidgetByName("btn_add"),"Button")
    btnAdd:addTouchEventListener(event_btn_add)

    labCout = tolua.cast(__instance.uiLayer:getWidgetByName("lab_cout"),"Label")
end
