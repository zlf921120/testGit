--
-- Author: lvgansheng
-- Date: 2014-07-10 16:57:09
-- 主场景
require("SceneItem")
require("MainSceneHelper")
require "AnimateManager"
require "MainSceneMgr"
require "ColudItem"

MainScene = class("MainScene", function() return CCLayer:create() end)

local max_width = 1920
-- local limit_four_x = 0

MainScene.cloud_spr_list = nil
MainScene.cloud_img_list = nil
MainScene.cloud_act_list = nil

local send_x

local one
local two
local four
local five

local one_x
local two_x
local four_x
local five_x

function MainScene:init()
    local visbile_size = CCDirector:sharedDirector():getVisibleSize() 
    
    self.cloud_spr_list = {}
    self.cloud_act_list = {}

    -- limit_four_x =-max_width+visbile_size.width

    local temp_x = CCEGLView:sharedOpenGLView():getScaleX()
    local temp_y = CCEGLView:sharedOpenGLView():getScaleY()

    local adjust_scalx = 1/temp_x*temp_y
    -- self:scaleX(1/temp_x)
    self:setScaleX(adjust_scalx)


    self.fun_icon_dic = CCDictionary:create()
    self.fun_icon_dic:retain()

    self.uiLayer = TouchGroup:create()
    self:addChild( self.uiLayer)

    self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/main_scene/main_scene.ExportJson")
    self.panelLock = tolua.cast(self.widget:getChildByName("panel_lock"),"Layout")
    self:setTouchEn(true)
    local width_x = CCEGLView:sharedOpenGLView():getFrameSize().width

    local adj_x = -(width_x-960*temp_y)/2
    self:setPositionX(adj_x/temp_x)
    -- self:setPositionX(-74)

    local sc_width = width_x/temp_y
    -- local sc_width = visbile_size.width+(width_x-960*temp_y)

    --滚动层
    self.sc_view = ScrollView:create()
    self.sc_view:setTouchEnabled(true)
    self.sc_view:setSize(CCSize(sc_width, visbile_size.height))   
    self.sc_view:setDirection(SCROLLVIEW_DIR_HORIZONTAL)
    self.uiLayer:addWidget(self.sc_view)
    self.sc_view:addChild(self.widget)
    self.sc_view:setInnerContainerSize(CCSize(max_width, visbile_size.height)) 

    one = tolua.cast(self.uiLayer:getWidgetByName("one_bg"), "ImageView") --最前面的陆地
    one_x = one:getPositionX()
    one_width = one:getContentSize().width
 
    two = tolua.cast(self.uiLayer:getWidgetByName("two_bg"), "Layout") --  漂浮在空中的两个
    --local two_bg_animate = AnimateManager:getInstance():getArmature("ui/main_scene/duanweisai/duanweisai.ExportJson","duanweisai")
   -- two_bg_animate:setAnchorPoint(ccp(0,0))
   -- two_bg_animate:getAnimation():playWithIndex(0)
    --two:addNode(two_bg_animate)
    two_x = two:getPositionX()

    -- three = tolua.cast(self.uiLayer:getWidgetByName("three_bg"), "ImageView") --空中的云
    -- three:setVisible(false)
    -- three_x = three:getPositionX()

    four = tolua.cast(self.uiLayer:getWidgetByName("four_bg"), "ImageView") --中间陆地
    four_x = four:getPositionX()
    
    five = tolua.cast(self.uiLayer:getWidgetByName("five_bg"), "ImageView") --最后面的天空层
    five_x = five:getPositionX()
    five_width = five:getContentSize().width

    --设置浮岛上云朵的位置
    -- local two_bg_cloud = tolua.cast(self.uiLayer:getWidgetByName("three_bg"), "ImageView") --空中的云 
    -- local two_bg_cloud_width_half = 180
    -- local two_bg_cloud_width_half = limit_four_x*0.3

    local i =0
    local old_x = 0 

    local function openWinByWidgetName(widget_name)
        if widget_name == "chat" then --聊天
              WindowCtrl:getInstance():open(CmdName.Chat_View)
          elseif widget_name == "shop" then --商店
              require "ShopCfg"
              WindowCtrl:getInstance():open(CmdName.Shop_View,{area = BuyArea.Normal})
          elseif widget_name == "mail" then --信函
              WindowCtrl:getInstance():open(CmdName.Mail_View)
          elseif widget_name == "duplicate" then -- 副本
              WindowCtrl:getInstance():open(CmdName.Dungeon_View)
              --新手引导事件
              if GuideDataProxy:getInstance().nowMainTutroialEventId == 10511 or
                  GuideDataProxy:getInstance().nowMainTutroialEventId == 11106 or
                  GuideDataProxy:getInstance().nowMainTutroialEventId == 10814 then
                  Notifier.dispatchCmd(GuideEvent.StepFinish,"click_dungeonicon")
              end
          elseif widget_name == "guild" then -- 帮会
          	ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Guild,function()
              require "GuildNetTask"
              GuildNetTask:getInstance():requestMyGuildInfo()
              ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.guild)
            end)
          elseif widget_name == "forge" then -- 锻造屋  
             local params ={}
              params.cur_view_type = HeroHelper.forgePanelType.powered
              WindowCtrl:getInstance():open(CmdName.EqmExchView,params) 
              
          elseif widget_name == "forever_tower" then --永恒之塔
              ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Tower,function()
                 WindowCtrl:getInstance():open(CmdName.Tower_Scene)
                 ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.tower)
              end)
          elseif widget_name == "honour_road" then --星空神殿
              ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Glory,function()
                  WindowCtrl:getInstance():open(CmdName.Glory_Scene)
                  ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.glory)
              end)
          elseif widget_name == "arena" then --竞技场
              ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Arena,function()
                  WindowCtrl:getInstance():open(CmdName.Arena_View)
                  ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.arena)
              end)
          elseif widget_name == "treasure" then --宝箱
              ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Altar,function()
                --新手引导事件
                WindowCtrl:getInstance():open(CmdName.Lottery_Scene)
                if GuideDataProxy:getInstance().nowMainTutroialEventId == 11101 then
                   Notifier.dispatchCmd(GuideEvent.StepFinish,"click_treasureicon")
                end
              end)
          elseif widget_name == "mystery_trader" then --神秘商人
              ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Mystery,function()
                require "ShopCfg"
                WindowCtrl:getInstance():open(CmdName.Shop_View,{area = BuyArea.Mystery})
                ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.mystery)
              end)
          elseif widget_name == "sky_battle" then --天空之役
          	  ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.SkyBattle,function()
                  WindowCtrl:getInstance():open(CmdName.Skywar_View)
                  ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.sky_battle)
              end)
          elseif widget_name == "monster_station" then
              ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Robdungeon,function()
                  WindowCtrl:getInstance():open(CmdName.RES_CONTEND_GUARD_VIEW, {dunId = 0})
                 ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.robdungeon)
                  self:hideNewsTip(NewTipsEnum.guard)
              end)
          elseif widget_name == "secret" then
            ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Secret,function()
              require "SecretNetTask"
              SecretNetTask:getInstance():requestSecretInfo()
              ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.secret)
            end)
          end
    end

    local old_num = 0
    local temp_test = 0
    self.scroll_step = function()
      send_x = self.sc_view:getInnerContainer():getPositionX()

      if old_num>200 then
        old_num = 0
        TimerManager.removeTimer(self.scroll_step)
        return 
      end
      -- cclog("scroll_step~~~~%d",old_num)
      local temp_one = send_x*0.7
      local temp_two = two_x+send_x*0.3 
      local temp_five = -send_x*0.5

      local old_one = one:getPositionX()
      local old_two = two:getPositionX()
      local old_five = five:getPositionX()

      if temp_one-old_one<0.1 and 
         temp_two-old_two<0.1 and
         temp_five-old_five<0.1  then
          old_num = old_num + 1
      else
          old_num = 0
      end

      old_send_x = send_x
      one:setPositionX(temp_one)
      two:setPositionX(temp_two)
      five:setPositionX(temp_five)
    end

    local icon_click_x = 0
    local function onIconClickEvent(sender,eventType)
        local widget_name = sender:getName()
        local temp_item = self.fun_icon_dic:objectForKey(widget_name)
        if eventType == ComConstTab.TouchEventType.ended then
          --点击结束后，去除元件的选中状态
          -- local temp_item = self.fun_icon_dic:objectForKey(widget_name)
          if temp_item ~= nil then
           temp_item:setSelect(false)
           temp_item:zoomOutIcon()
          end

          openWinByWidgetName(widget_name)

        elseif eventType == ComConstTab.TouchEventType.moved then
            --如果点击了图标后滑动，则去除选中状态
            -- local temp_item = self.fun_icon_dic:objectForKey(widget_name)
            local move_x = sender:getTouchMovePos().x-icon_click_x
            if temp_item ~= nil and 
              (move_x>50 or move_x<-50) then
              temp_item:setSelect(false)
               temp_item:zoomOutIcon()
            end
        elseif eventType == ComConstTab.TouchEventType.began then
            --被点击元素变为选中状态
            -- local temp_item = self.fun_icon_dic:objectForKey(widget_name)
            if temp_item ~= nil then
              temp_item:setSelect(true)
                temp_item:zoomInIcon()
            end
            icon_click_x = sender:getTouchStartPos().x
           TimerManager.addTimer(15,self.scroll_step,true)

        else
          if temp_item ~= nil  then
              temp_item:setSelect(false)
              temp_item:zoomOutIcon()
          end
          -- cclog("這是摩米奇妙的時間")
        end
    end

    --点击界面，开始倒计时
    self.sc_view:addTouchEventListener(function(sender,eventType)
      if eventType == ComConstTab.TouchEventType.began then
        TimerManager.addTimer(15,self.scroll_step,true)
      end
    end)

    MainSceneMgr:getInstance():readData() --读取场景配置
    local temp_scene_info = MainSceneMgr:getInstance().scene_info
    local scene_item = nil
    local temp_panel = nil
    local step_num = 5

    local function step_create()
      local i = 0
      
      for name,scene_info_one in pairs (temp_scene_info) do
        if i == step_num then
          return
        end
        scene_item = SceneItem:create(scene_info_one)
	     temp_panel = tolua.cast(self.uiLayer:getWidgetByName(name), "Layout")
     
        if scene_info_one.icon_effect==MainSceneHelper.icon_effect.fun_btn then
  	     temp_panel:addTouchEventListener(onIconClickEvent)
        end
	    
        temp_panel:addChild(scene_item)
          self.fun_icon_dic:setObject(scene_item,name)
          temp_scene_info[name] = nil
          i= i +1
      end

      if i==0 or i<step_num then --已经没有需要创建的元素了
        TimerManager.removeTimer(step_create)
        cclog("開始創建雲")
        -- 开始创建云
        self:initCloud()
        
        self:delayAction()

      end

    end
    --添加好友按钮
    require("FriendBtn")
    local fbtn = FriendBtn:create()
    self:addChild(fbtn)
    self.fun_icon_dic:setObject(fbtn, NewTipsEnum.friend)

    TimerManager.addTimer(200, step_create,true)
    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
    --新消息提示
    Notifier.regist(CmdName.MAIN_SHOW_NEWS_TIP,function(param) self:showNewsTip(param) end)
    Notifier.regist(CmdName.MAIN_HIDE_NEWS_TIP,function(param) self:hideNewsTip(param) end)
    --New提示
    Notifier.regist(CmdName.MAIN_SHOW_NEWS_IMG,function(param) self:showNewsImg(param) end)
    Notifier.regist(CmdName.MAIN_HIDE_NEWS_IMG,function(param) self:hideNewsImg(param) end)
end

--一些需要主场景创建完毕后才处理的
function MainScene:delayAction()
    require "ActivateNetTask"
    ActivateEventTask:getInstance()
    Notifier.dispatchCmd(ActivateEvent.InitActivate)
    if CharacterManager:getInstance():getBaseData():getHasCreateGender() ~= 0 then --已选择性别
        --加载剧情/新手引导
        require "GuideNetTask"
        GuideEventTask:getInstance()
        GuideLocalReader:getInstance():loadInProxy()
        Notifier.dispatchCmd(GuideEvent.InitDungeon)
        GuideEventTask:getInstance():initCheckDispMainTutorial()
    end
    ActivateEventTask:getInstance():initPerpareItem()

    require "GuideNetTask"
    GuideEventTask:getInstance()
    Notifier.dispatchCmd(GuideEvent.InitMain)
    require "VipNetTask"
    VipNetTask:getInstance()
    --检测是否有公告
    NoticeDataProxy:getInstance():checkPopNotice()
    --初始化 活动奖励
    RewardDataProxy:getInstance():makeRewardBySvr()
    --开启倒计时
    self:startSchedule()
    
    require "ChatNetTask"
    ChatNetTask:getInstance()
    --登陆成功后开始计时的本地推送
    SysSettingMgr:getInstance():initSomeNoticeAfterLogin()
    LotteryDataProxy:getInstance():isCanAddOneOffNotice()

    GuildDataProxy:getInstance().progressSchedule()

     --通知展示新消息提示
    local voList = CharacterManager:getInstance():getBaseData():getNewsTipList()
    for k,v in pairs(voList) do 
        if k == "login_buy_coin" then
           if v == 1 then
              Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,k)
           end
        elseif k == "friend" then
          if v == 0 then
            require "FriendMgr"
            -- require "CharacterManager"
            if CharacterManager:getInstance():getTeamData():getLev() >= 20 then
              FriendMgr:getInstance():setNewTips(true)
              Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.friend)
            else
              print("btn no see")
              print("btn no see")
              print("btn no see")
              print("btn no see")
              FriendMgr:getInstance():setNewTips(true)
              Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP, NewTipsEnum.friend)
            end
          end
        elseif v == 0 then --0显示  1不显示
          print("key=",k)
          Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,k)
        end
    end

    local voList = CharacterManager:getInstance():getBaseData():getShowIconList()
    for k,v in pairs(voList) do
        if v == 0 then --0显示  1不显示
             Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_ICON,k)
        end
    end

    print("my uid=",CharacterManager:getInstance():getLoginData():getAcctId())
    print("my uid=",CharacterManager:getInstance():getLoginData():getAcctId())
    print("my uid=",CharacterManager:getInstance():getLoginData():getAcctId())

    -- require("FriendBtn")
    -- local fbtn = FriendBtn:create()
    -- self:addChild(fbtn)
    -- self.fun_icon_dic:setObject(fbtn, NewTipsEnum.friend)
end

function MainScene:create()
	local main = MainScene.new()
	main:init()
	return main
end

function MainScene:initCloud()

  local cloud_one = tolua.cast(self.uiLayer:getWidgetByName("cloud_one_img"), "ImageView")
  cloud_one:setVisible(false) 
  
  local cloud_two = tolua.cast(self.uiLayer:getWidgetByName("cloud_two_img"), "ImageView")
  cloud_two:setVisible(false) 
  
  local cloud_three = tolua.cast(self.uiLayer:getWidgetByName("cloud_three_img"), "ImageView")
  cloud_three:setVisible(false)  

  local cloud_four = tolua.cast(self.uiLayer:getWidgetByName("cloud_four_img"), "ImageView")
  cloud_four:setVisible(false) 
  
  local cloud_five = tolua.cast(self.uiLayer:getWidgetByName("cloud_five_img"), "ImageView")
  cloud_five:setVisible(false)

  local cloud_one_spr = ColudItem:create(1)
  cloud_one_spr:setPosition(ccp(cloud_one:getPosition()))
  self.cloud_spr_list[1] = cloud_one_spr
  four:addChild(cloud_one_spr,10)

  local cloud_two_spr = ColudItem:create(2)
  cloud_two_spr:setPosition(ccp(cloud_two:getPosition()))
  self.cloud_spr_list[2] = cloud_two_spr
  four:addChild(cloud_two_spr)

  local cloud_three_spr = ColudItem:create(3)
  cloud_three_spr:setPosition(ccp(cloud_three:getPosition()))
  self.cloud_spr_list[3] = cloud_three_spr
  four:addChild(cloud_three_spr)

  local cloud_four_spr = ColudItem:create(4)
  cloud_four_spr:setPosition(ccp(cloud_four:getPosition()))
  self.cloud_spr_list[4] = cloud_four_spr
  four:addChild(cloud_four_spr,10)

  local cloud_five_spr = ColudItem:create(5)
  cloud_five_spr:setPosition(ccp(cloud_five:getPosition()))
  self.cloud_spr_list[5] = cloud_five_spr
  four:addChild(cloud_five_spr,10)
  
  TimerManager.addTimer(1500, function() self:ctrlCloud() end,true)
end

function MainScene:ctrlCloud()
  local i = math.random(5)
  -- local i = 4
  local cspr = self.cloud_spr_list[i]
  if cspr then
      cspr:playAct()
  end

end

function MainScene:enter()
  for i,temp_cloud in pairs(self.cloud_spr_list) do
    temp_cloud:reset()
  end

  one:setPositionX(one_x)
  two:setPositionX(two_x)
  four:setPositionX(four_x)
  five:setPositionX(five_x)

  GameLayerMgr:getInstance():cleanMsgLayer()
  self:updateNewsTip()

    require "GuildPopChatView"
    GuildPopChatView:getInstance().progressTimer()
end

--[[
控制主场景移动
@param move_perc 移动到的百分比
@param move_time 单位是秒
--]]
function MainScene:moveByClient(move_perc, move_time)
    -- local temp_sc_x =  self.sc_view:getInnerContainer():getPositionX()
    -- self.sc_view:getInnerContainer():setPositionX(temp_sc_x+dis_x)
    -- TimerManager.addTimer(15,scroll_step,true)
    TimerManager.addTimer(15,self.scroll_step,true)
    self.sc_view:scrollToPercentHorizontal(move_perc,move_time,true)
end

function MainScene:setTouchEn(b)
  self.panelLock:setTouchEnabled(not b)
end

--新手引导动画
function MainScene:showStepAnim(param)
    if param.target == "forge_view" then
        local item = self.fun_icon_dic:objectForKey("forge")
        GuideRenderMgr:getInstance():renderMainFlag(item,param.id,param.target)
    elseif param.target == "dungeon_icon" then
        local item = self.fun_icon_dic:objectForKey("duplicate")
        GuideRenderMgr:getInstance():renderMainFlag(item,param.id,param.target)
    elseif param.target == "treasure_icon" then
        local item = self.fun_icon_dic:objectForKey("treasure")
        GuideRenderMgr:getInstance():renderMainFlag(item,param.id,param.target)
    end
end

function MainScene:tipsPointPlayAct(act_bn)
    if not act_bn:isVisible() then
      act_bn:setVisible(true)
    end
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

--更新 新消息提示
function MainScene:updateNewsTip()
    local voList = CharacterManager:getInstance():getBaseData():getNewsTipList()
    if voList then
        for k,v in pairs(voList) do 
            if v == 0 then
                self:showNewsTip(k)
            end
        end
    end
end

-- 展示 新消息 提示
function MainScene:showNewsTip(key)
    print("tips key=",key)
    local target = nil
    local pos = nil
    if key == NewTipsEnum.lottery then                       
        target = self.fun_icon_dic:objectForKey("treasure")
        pos = ccp(145,5)
    elseif key == NewTipsEnum.mail then
        target = self.fun_icon_dic:objectForKey("mail")
        pos = ccp(95,-15)
    elseif key == NewTipsEnum.chat then
        target = self.fun_icon_dic:objectForKey("chat")
        pos = ccp(115,-10) 
        if target then
            target:changeAnimState("dongtai")
        end
    elseif key == NewTipsEnum.arena then
        target = self.fun_icon_dic:objectForKey("arena")
        pos = ccp(115+15,-10+10) 
    elseif key == NewTipsEnum.mystery then
        target = self.fun_icon_dic:objectForKey("mystery_trader")
        pos = ccp(115+50,-10+15)
    elseif key == NewTipsEnum.guard then
        target = self.fun_icon_dic:objectForKey("monster_station")
        pos = ccp(115+10,-39+15)
    elseif key == NewTipsEnum.guild then
        target = self.fun_icon_dic:objectForKey("guild")
        pos = ccp(115,-15)
    elseif key == NewTipsEnum.friend then
        target = self.fun_icon_dic:objectForKey("friend")
        pos = ccp(48,485)
    end
    if target and target:getChildByTag(2866) == nil then
        print("type1")
        local tips_img = ImageView:create()
        tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
        tips_img:setTag(2866)
        tips_img:setPosition(pos)
        target:addChild(tips_img)
        self:tipsPointPlayAct(tips_img)
    elseif target and target:getChildByTag(2866) ~= nil then
        print("type2")
        local tips_img = target:getChildByTag(2866)
        self:tipsPointPlayAct(tips_img)
    end
end

-- 隐藏 新消息 提示
function MainScene:hideNewsTip(key)
    local target = nil
    if key == NewTipsEnum.lottery then
        target = self.fun_icon_dic:objectForKey("treasure")
    elseif key == NewTipsEnum.mail then
        target = self.fun_icon_dic:objectForKey("mail")
    elseif key == NewTipsEnum.chat then
        target = self.fun_icon_dic:objectForKey("chat")
        target:changeAnimState("jingzhi")
    elseif key == NewTipsEnum.arena then
        target = self.fun_icon_dic:objectForKey("arena")
    elseif key == NewTipsEnum.mystery then
        target = self.fun_icon_dic:objectForKey("mystery_trader")
    elseif key == NewTipsEnum.guard then
        target = self.fun_icon_dic:objectForKey("monster_station")
    elseif key == NewTipsEnum.guild then
        target = self.fun_icon_dic:objectForKey("guild")
    elseif key == NewTipsEnum.friend then
        target = self.fun_icon_dic:objectForKey("friend")
    end
    if target and target:getChildByTag(2866) ~= nil then
        CharacterManager:getInstance():getBaseData():setNewsTipStatus(key,1) --0 显示  1 不显示
        target:removeChildByTag(2866,true)
    end
end

--展示 新开启 图
function MainScene:showNewsImg(key)
    local target = nil
    local pos = nil
    if key == NewImgEnum.arena then
        target = self.fun_icon_dic:objectForKey("arena")
        pos = ccp(145,5)
    elseif key == NewImgEnum.guild then
        target = self.fun_icon_dic:objectForKey("guild")
        pos = ccp(145,5)     
    elseif key == NewImgEnum.glory then
        target = self.fun_icon_dic:objectForKey("honour_road")
        pos = ccp(145,5) 
    elseif key == NewImgEnum.secret or
            key == NewImgEnum.secret_diff2 then
        target = self.fun_icon_dic:objectForKey("secret")
        pos = ccp(145,5+10)
    elseif key == NewImgEnum.sky_battle then
        target = self.fun_icon_dic:objectForKey("sky_battle")
        pos = ccp(145,5+10)
    elseif key == NewImgEnum.tower then
        target = self.fun_icon_dic:objectForKey("forever_tower")
        pos = ccp(145-30,5)
    elseif key == NewImgEnum.mystery then
        target = self.fun_icon_dic:objectForKey("mystery_trader")
        pos = ccp(145+50,5+8)
    elseif key == NewImgEnum.dungeon_diff2 or
            key == NewImgEnum.dungeon_diff3 then
        target = self.fun_icon_dic:objectForKey("duplicate")
        pos = ccp(145+35,5+50)
    elseif key == NewImgEnum.forge_enchant or
            key == NewImgEnum.forge_gem or 
            key == NewImgEnum.forge_identity or
            key == NewImgEnum.forge_upgrade then
        target = self.fun_icon_dic:objectForKey("forge")
        pos = ccp(115 -20,-10+15) 
    elseif key == NewImgEnum.robdungeon then
        target = self.fun_icon_dic:objectForKey("monster_station")
        pos = ccp(115 -20,-10+15) 
    end
    if target and target:getNodeByTag(4152) == nil then
        local tips_img = AnimateManager:getInstance():getArmature("ui/effects_ui/new/new.ExportJson","new")
        tips_img:getAnimation():play("Animation1",-1,-1,1)
        tips_img:setTag(4152)
        tips_img:setPosition(pos)
        target:addNode(tips_img,10)
    end
end

-- 隐藏 新开启 图
function MainScene:hideNewsImg(key)
    local target = nil
     if key == NewImgEnum.arena then
        target = self.fun_icon_dic:objectForKey("arena")
    elseif key == NewImgEnum.guild then
        target = self.fun_icon_dic:objectForKey("guild")   
    elseif key == NewImgEnum.glory then
        target = self.fun_icon_dic:objectForKey("honour_road")
    elseif key == NewImgEnum.tower then
        target = self.fun_icon_dic:objectForKey("forever_tower")
    elseif key == NewImgEnum.mystery then
        target = self.fun_icon_dic:objectForKey("mystery_trader")
    elseif key == NewImgEnum.secret or
            key == NewImgEnum.secret_diff2 then
        target = self.fun_icon_dic:objectForKey("secret")
    elseif key == NewImgEnum.sky_battle then
        target = self.fun_icon_dic:objectForKey("sky_battle")
    elseif key == NewImgEnum.forge_enchant or
            key == NewImgEnum.forge_gem or 
            key == NewImgEnum.forge_identity or
            key == NewImgEnum.forge_upgrade then
        target = self.fun_icon_dic:objectForKey("forge")
    elseif key == NewImgEnum.dungeon_diff2 or
            key == NewImgEnum.dungeon_diff3 then
        target = self.fun_icon_dic:objectForKey("duplicate")
    elseif key == NewImgEnum.robdungeon then
        target = self.fun_icon_dic:objectForKey("monster_station")
    end
    if target and target:getNodeByTag(4152) ~= nil then
        ActivateDataProxy:getInstance():setEventVoDoneViewNew(key)
        if key == NewImgEnum.forge_gem or 
          key == NewImgEnum.forge_identity or
          key == NewImgEnum.forge_enchant or
          key == NewImgEnum.forge_upgrade then
            if ActivateDataProxy:getInstance():isCanHideForgetNew() then
                target:removeNodeByTag(4152)
            end
        elseif key == NewImgEnum.dungeon_diff2 or 
              key == NewImgEnum.dungeon_diff3 then
            if ActivateDataProxy:getInstance():isCanHideDungeonNew() then
                target:removeNodeByTag(4152)
            end
        else
          target:removeNodeByTag(4152)
        end
    end
end

--开启定时器
function MainScene:startSchedule()

    TimerManager.addTimer(1000 * 30,LotteryDataProxy:getInstance().progressSchedule,true)
    LotteryDataProxy:getInstance().progressSchedule()
end