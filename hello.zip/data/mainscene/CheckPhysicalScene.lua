--检测体力状态 场景 

CheckPhysicalScene = class("CheckPhysicalScene",WindowBase)
CheckPhysicalScene.__index = CheckPhysicalScene
CheckPhysicalScene._widget = nil
CheckPhysicalScene.uiLayer = nil

local __instance = nil

function CheckPhysicalScene:getInstance()
    if not __instance then
        local ret = CheckPhysicalScene.new()
        __instance = ret
        ret:init()
        ret:retain()
    end
    return __instance
end

function CheckPhysicalScene:init()
	self:adjustScal()
	--加载纹理
    ComResMgr:getInstance():loadOtherRes()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("main_scene/checkPhysicalScene.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self._progressSchedule = function()
 		self:update()
	end
end

function CheckPhysicalScene:update()

	local dp = CharacterDataProxy:getInstance()
	local sceneVo = dp:getCheckPhysicalSceneVo()

	local buyCout = sceneVo.buyCout
	local nowTime = ServerTimerManager:getInstance():getCurTime()

	local imgBg = tolua.cast(self.uiLayer:getWidgetByName("img_bg"),"ImageView")

	local labTime = tolua.cast(self.uiLayer:getWidgetByName("lab_time"),"Label")
	labTime:setText(os.date("%H:%M:%S",nowTime))

	local labBuyCout = tolua.cast(self.uiLayer:getWidgetByName("lab_buycout"),"Label")
	labBuyCout:setText(string.format("%d/%d",buyCout, CharacterDataProxy:getInstance():getBuyPhysicalMax()) )

	local labFull = tolua.cast(self.uiLayer:getWidgetByName("lab_full"),"Label")

	local labNextFix = tolua.cast(self.uiLayer:getWidgetByName("lab_fixnext"),"Label")
	local labNext = tolua.cast(self.uiLayer:getWidgetByName("lab_next"),"Label")
	
	local labAllFix = tolua.cast(self.uiLayer:getWidgetByName("lab_fixall"),"Label")
	local labAll = tolua.cast(self.uiLayer:getWidgetByName("lab_all"),"Label")

	local labGayFix = tolua.cast(self.uiLayer:getWidgetByName("lab_fxgay"),"Label")
	local labGay = tolua.cast(self.uiLayer:getWidgetByName("lab_gay"),"Label")

	local assetData = CharacterManager:getInstance():getAssetData()
	local physicalMax = dp:getLevPhysicalMax()
	local physicalNow = assetData:getPhysical()

	-- print(" 體力上限  ",physicalMax, " 當前體力 ",physicalNow)

	if physicalMax < physicalNow or physicalMax == physicalNow then --体力已满
		labFull:setVisible(true)

		labNextFix:setVisible(false)
		labNext:setVisible(false)
		labAllFix:setVisible(false)
		labAll:setVisible(false)
		labGayFix:setVisible(false)
		labGay:setVisible(false)
	else
		--imgBg:setContentSize(250,170) --体力未满
		labFull:setVisible(false)

		labNextFix:setVisible(true)
		labNext:setVisible(true)
		labAllFix:setVisible(true)
		labAll:setVisible(true)
		labGayFix:setVisible(true)
		labGay:setVisible(true)

		-- print(" countTime ",sceneVo.countTime,nowTime)
		local disTime = ( nowTime - sceneVo.lastTime ) % 360  --剩余秒数
        sceneVo.countTime = 6 * 60 - disTime   --倒计时数

		labNext:setText(Helper.sec2TimeStr(sceneVo.countTime))

		local dis = physicalMax - physicalNow
		local coutTimeAll = (dis - 1) * 6 * 60 + sceneVo.countTime
		labAll:setText(Helper.sec2TimeStr(coutTimeAll))
		--重置体力
		CharacterDataProxy:getInstance().refreshPhysicalTimer()
		CharacterDataProxy:getInstance().resetPhysicalTimer()
	end
end

function CheckPhysicalScene:startSchedule()
    self:clearSchedule()
    TimerManager.addTimer(1000,self._progressSchedule,true)
end

--清理定时器
function CheckPhysicalScene:clearSchedule()
    TimerManager.removeTimer(self._progressSchedule)
end

function CheckPhysicalScene:open()
	self:update()
	self:startSchedule()
end

function CheckPhysicalScene:close()
	self:clearSchedule()
end

function CheckPhysicalScene:hide()
	local layer = GameLayerMgr:getInstance():getMsgLayer()
    local child = layer:getChildByTag(1777)
    if child ~= nil then
        child:stopAllActions()
        layer:removeChildByTag(1777,false)
    end

    local physicalLayer = CheckPhysicalScene:getInstance()
    physicalLayer:close()
end

function CheckPhysicalScene:show()
	local layer = GameLayerMgr:getInstance():getMsgLayer()
    local child = layer:getChildByTag(1777)
    if child ~= nil then
        child:stopAllActions()
        layer:removeChildByTag(1777,false)
    end

    local physicalLayer = CheckPhysicalScene:getInstance()
    physicalLayer:setTag(1777)
    physicalLayer:open()
    layer:addChild(physicalLayer)
end