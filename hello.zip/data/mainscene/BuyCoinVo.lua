--购买金币条目 值对象
BuyCoinItemVo = class("BuyCoinItemVo")
BuyCoinItemVo.id = 0
BuyCoinItemVo.diamon = 0 --消耗的 钻石数
BuyCoinItemVo.coin = 0 --获得的 金币数

--购买金币 场景值对象
BuyCoinSceneVo = class("BuyCoinSceneVo")
BuyCoinSceneVo.hadBuyNum = 0 --已购买次数
BuyCoinSceneVo.lastTimeBuyNum = 0 --上一次买的次数 (注：是每个mult请求为1次)
BuyCoinSceneVo.coinNum = 0 --金币值
BuyCoinSceneVo.diamonNum = 0 --钻石值

--检查体力面板 场景值对象
CheckPhysicalSceneVo = class("CheckPhysicalSceneVo")
CheckPhysicalSceneVo.buyCout = 0
CheckPhysicalSceneVo.countTime = 0 --倒计时时间
CheckPhysicalSceneVo.lastTime = 0 --上一点体力加的时间