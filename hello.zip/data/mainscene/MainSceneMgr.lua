
require("fnt_main_scene_data_pb")

MainSceneMgr = class("MainSceneMgr")

local _instance = nil
local _allowInstance = false

MainSceneMgr.scene_info = nil

function MainSceneMgr:ctor()

    if not _allowInstance then
        error("MainSceneMgr is a singleton class,please call getInstance method")
    end

    self.scene_info = {}
end

function MainSceneMgr:getInstance()

    if _instance == nil then
        _allowInstance = true
        _instance = MainSceneMgr.new()
        _allowInstance = false
    end

    return _instance

end

--读取配置文件
function MainSceneMgr:readData()
	 if self.isRead then
    	cclog ("mian_scene_data had already read,don't call this method again")
        return
    end

    --[[local dataFile = CCFileUtils:sharedFileUtils():fullPathForFilename("fnt_main_scene_data.dat")
    local datafile_handle = io.open(dataFile, "rb")
    pbdata = datafile_handle:read("*a")
    datafile_handle:close()--]]
	local pbdata = Global:getAssetFileData("fnt_main_scene_data.dat", "rb")
    
    local msg = fnt_main_scene_data_pb.fnt_main_scene_data()
    msg:ParseFromString(pbdata)

    -- 尝试读取第一个标签页的数据
    local scene_info_rows = msg.scene_info_rows
    local scene_info_one = nil

    for i, v in pairs(scene_info_rows) do
        if v.icon_type~=nil then 
            scene_info_one = {}
            scene_info_one.name = v.name
            scene_info_one.icon_type = v.icon_type
            scene_info_one.icon_effect = v.icon_effect
            self.scene_info[scene_info_one.name] = scene_info_one
            
        end
    end

    self.isRead = true
end