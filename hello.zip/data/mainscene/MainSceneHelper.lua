--
-- Author: lvgansheng
-- Date: 2014-08-04 11:27:11
-- 主场景帮助类

MainSceneHelper = {}
MainSceneHelper.icon_type = {}
MainSceneHelper.icon_type.image = 1 --静态图片
MainSceneHelper.icon_type.animation = 2 --动画

MainSceneHelper.icon_effect = {}
MainSceneHelper.icon_effect.fun_btn = 1 --功能按钮
MainSceneHelper.icon_effect.decoration = 2 --装饰，流水/云朵等