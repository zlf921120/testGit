
-- 购买金币 场景
BuyCoinScene = class("BuyCoinScene",WindowBase)
BuyCoinScene.__index = BuyCoinScene
BuyCoinScene._widget = nil
BuyCoinScene.uiLayer = nil

local __instance = nil

local panel_more = nil

function BuyCoinScene:create()
    local ret = BuyCoinScene.new()
    __instance = ret
    return ret
end

local function event_btn_close(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		__instance:addCloseAnim()
	end
end

local function event_btn_mult(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then

		if __instance._widget:getNodeByTag(239) ~= nil then return end

		local sceneVo = CharacterDataProxy:getInstance():getBuyCoinSceneVo()
		local limit = CharacterDataProxy:getInstance():getBuyCoinMax()
		if limit - sceneVo.hadBuyNum > 0 then
			WindowCtrl:getInstance():open(CmdName.Character_buyMultCoin)
		else
			WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()

                WindowCtrl:getInstance():open(CmdName.Vip_View)

            end, txt = string.format(BuyAssetCfg.UpLevelVipTip),
            okBtnName = "查看"})
		end
	end
	Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.login_buy_coin) --消除绿点
end

local function event_btn_one(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then

		if __instance._widget:getNodeByTag(239) ~= nil then return end

		local sceneVo = CharacterDataProxy:getInstance():getBuyCoinSceneVo()
		local limit = CharacterDataProxy:getInstance():getBuyCoinMax()
		if limit - sceneVo.hadBuyNum > 0 then
			
			CharacterNetTask:getInstance():requestBuyCoin()
		else
			WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()
				-- require "VipNetTask"
    --             VipNetTask:getInstance():requestVipInfo()
    			WindowCtrl:getInstance():open(CmdName.Vip_View)

            end, txt = string.format(BuyAssetCfg.UpLevelVipTip),
            okBtnName = "查看"}) 
		end
	end
	Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.login_buy_coin) --消除绿点
end

local function event_cb_show_recode()

	panel_more:setVisible(true)
	local list_recode = tolua.cast(panel_more:getChildByName("list_recode"),"ListView")
	list_recode:removeAllItems() --先清理

	local dp = CharacterDataProxy:getInstance() 
	local lists = dp:getBuyCoinItemVoList()

	-- local key_table = {}
	-- for key,_ in pairs(lists) do
	-- 	table.insert(key_table,key)
	-- end
	-- table.sort(key_table, function (a, b) if a > b then return true end end)
	-- for _,key in pairs(key_table) do
	-- 	local item = BuyCoinRecodeItem:create(lists[key])
	-- 	-- list_recode:pushBackCustomItem(item._widget)
	-- 	list_recode:insertCustomItem(item._widget,0)  --将最新购买记录插到最前面
	-- end

	for i=1,table.getn(lists) do
		local item = BuyCoinRecodeItem:create(lists[i])
		-- list_recode:pushBackCustomItem(item._widget)
		list_recode:insertCustomItem(item._widget,0)  --将最新购买记录插到最前面		
	end
	tolua.cast(list_recode,"ScrollView"):scrollToTop(0.5,true)
end

function BuyCoinScene:init()
	require "BuyAssetCfg"
	require "BuyCoinRecodeItem"
	--加载纹理
    ComResMgr:getInstance():loadOtherRes()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("main_scene/buyCoinScene.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	local btnMult = tolua.cast(self.uiLayer:getWidgetByName("btn_mult"),"Button")
    btnMult:addTouchEventListener(event_btn_mult)

    local btnOne = tolua.cast(self.uiLayer:getWidgetByName("btn_one"),"Button")
    btnOne:addTouchEventListener(event_btn_one)

    local btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    btnClose:addTouchEventListener(event_btn_close)

    self.labDiamon = tolua.cast(self.uiLayer:getWidgetByName("lab_diamon"),"Label")

    panel_more = self.uiLayer:getWidgetByName("panel_more")

    Notifier.regist(BuyAssetEvent.CB_SHOW_COIN_RECODE,event_cb_show_recode)
    Notifier.regist(BuyAssetEvent.CB_UPDATE_SCENE,function() self:update() end)
    Notifier.regist(BuyAssetEvent.CB_SHOW_ANIM,function(param) self:playAnim(param) end)
end

function BuyCoinScene:open()
	self:update()
	self:addOpenAnim()
end

function BuyCoinScene:update()
	local sceneVo = CharacterDataProxy:getInstance():getBuyCoinSceneVo()

	if sceneVo.diamon == 0 then
		self.labDiamon:setText("免費")
	else
		self.labDiamon:setText(sceneVo.diamon)
	end
	local labCoin = tolua.cast(self.uiLayer:getWidgetByName("lab_coin"),"Label")
	labCoin:setText(sceneVo.coin)

	local labLeft = tolua.cast(self.uiLayer:getWidgetByName("lab_left"),"Label")
	local limit = CharacterDataProxy:getInstance():getBuyCoinMax()
	labLeft:setText(string.format("%d/%d", limit - sceneVo.hadBuyNum, limit))

	local btnOne = tolua.cast(self.uiLayer:getWidgetByName("btn_one"),"Button")
	btnOne:setBright(true)
    btnOne:setTouchEnabled(true)

    local btnMult = tolua.cast(self.uiLayer:getWidgetByName("btn_mult"),"Button")
    btnMult:setBright(true)
    btnMult:setTouchEnabled(true)
end

function BuyCoinScene:close()
	panel_more:setVisible(false)
	self._widget:removeAllNodes()
	self._widget:getChildByName("img_box"):setVisible(true)
	if self._widget:getChildByTag(286) ~= nil then
		self._widget:removeChildByTag(286,true)
	end
	if self._widget:getChildByTag(284) ~= nil then
		self._widget:removeChildByTag(284,true)
	end

	AnimateManager:getInstance():clear("ui/main_scene/goumaijinbi/goumaijinbi.ExportJson")
	AnimateManager:getInstance():clear("ui/main_scene/danjinbi/danjinbi.ExportJson")
end

--播放动画
function BuyCoinScene:playAnim(param)

	local btnMult = tolua.cast(self.uiLayer:getWidgetByName("btn_mult"),"Button")
	btnMult:setBright(false)
    btnMult:setTouchEnabled(false)
    local btnOne = tolua.cast(self.uiLayer:getWidgetByName("btn_one"),"Button")
    btnOne:setBright(false)
    btnOne:setTouchEnabled(false)

	local num = param.num    	--得金币数
	local isBoom = param.isBoom --是否暴击

	local imgBox = self._widget:getChildByName("img_box")
	imgBox:setVisible(false)

	CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo("ui/main_scene/goumaijinbi/goumaijinbi.ExportJson")
	local armature = CCArmature:create("goumaijinbi")
	armature:setTag(239)
	armature:setZOrder(5)
	self._widget:addNode(armature)
	local x,y = imgBox:getPosition()
	armature:setPosition(ccp(x,y - 100))
	armature:getAnimation():setMovementEventCallFunc(function(armatureBack,movementType,movementID)

        if movementType == AnimationMovementType.COMPLETE or 
			movementType == AnimationMovementType.LOOP_COMPLETE then
			imgBox:setVisible(true)

			if self._widget:getNodeByTag(239) ~= nil then
				self._widget:removeNodeByTag(239)
			end
			btnOne:setBright(true)
    		btnOne:setTouchEnabled(true)
    		btnMult:setBright(true)
    		btnMult:setTouchEnabled(true)

			Notifier.dispatchCmd(BuyAssetEvent.CB_SHOW_COIN_RECODE)
		end
	end)

	armature:getAnimation():play("Animation1",0,-1,0)
-------------------------------------------------------------------
	TimerManager.addTimer(1000,function()

		for i=1,10 do
			TimerManager.addTimer(math.random(100,1000),function()

				CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo("ui/main_scene/danjinbi/danjinbi.ExportJson")
				local armCoin = CCArmature:create("danjinbi")
				armCoin:setZOrder(10)
				self._widget:addNode(armCoin)
				-- local x,y = imgBox:getPosition()
				armCoin:setPosition(ccp(480 + math.random(-250,250), 320 + math.random(-250,250)) )
				armCoin:getAnimation():setMovementEventCallFunc(function(armatureBack,movementType,movementID)

			        if movementType == AnimationMovementType.COMPLETE or 
						movementType == AnimationMovementType.LOOP_COMPLETE then

						self._widget:removeNode(armatureBack)
					end
				end)
				
				armCoin:getAnimation():play("Animation1",0,-1,0)
			end)
		end
	end)
-------------------------------------------------------------------
	local imgGetCoin = ImageView:create()
	imgGetCoin:loadTexture("i18n_buy_coin.png",UI_TEX_TYPE_PLIST)
	self._widget:addChild(imgGetCoin)
	imgGetCoin:setScale(10)
	imgGetCoin:setZOrder(7)
	imgGetCoin:setTag(286)
	imgGetCoin:setVisible(false)
	local arr = CCArray:create()
	arr:addObject(CCDelayTime:create(1.6))
	arr:addObject(CCShow:create())
	arr:addObject(CCScaleTo:create(0.2,1))
	arr:addObject(CCDelayTime:create(1.5))
	arr:addObject(CCCallFuncN:create(function(node)
		node:removeFromParentAndCleanup(true)
	end))
	imgGetCoin:runAction(CCSequence:create(arr))

	local labAltasCoin = CCLabelAtlas:create(tostring(num),"ui/digit/buy_coin_num.png",28,49,48)
	self._widget:addNode(labAltasCoin)
	labAltasCoin:setScale(10)
	labAltasCoin:setZOrder(7)
	labAltasCoin:setVisible(false)
	labAltasCoin:setAnchorPoint(ccp(0.5,0.5))
	local arr = CCArray:create()
	arr:addObject(CCDelayTime:create(1.6))
	arr:addObject(CCShow:create())
	arr:addObject(CCScaleTo:create(0.2,1))
	arr:addObject(CCDelayTime:create(1.5))
	arr:addObject(CCCallFuncN:create(function(node)
		self._widget:removeNode(node)
	end))
	labAltasCoin:runAction(CCSequence:create(arr))
-----------------------------------------------------------------------
	--居中
	local left = ( 960 - labAltasCoin:getContentSize().width - imgGetCoin:getContentSize().width ) / 2
	imgGetCoin:setPosition(ccp(left + imgGetCoin:getContentSize().width / 2,400))
	labAltasCoin:setPosition(ccp(left + imgGetCoin:getContentSize().width + labAltasCoin:getContentSize().width / 2,400))
----------------------------------------------------------------------
	if isBoom then --是否暴击
		local imgBoom = ImageView:create()
		imgBoom:setScale(10)
		imgBoom:setZOrder(7)
		imgBoom:setTag(284)
		imgBoom:loadTexture("i18n_buy_boom.png",UI_TEX_TYPE_PLIST)
		imgBoom:setPosition(ccp(self._widget:getChildByName("p_3"):getPosition()))
		self._widget:addChild(imgBoom)
		imgBoom:setVisible(false)
		local arr = CCArray:create()
		arr:addObject(CCDelayTime:create(1.6))
		arr:addObject(CCShow:create())
		arr:addObject(CCScaleTo:create(0.2,1))
		arr:addObject(CCDelayTime:create(1.5))
		arr:addObject(CCCallFuncN:create(function(node)
			node:removeFromParentAndCleanup(true)
		end))
		imgBoom:runAction(CCSequence:create(arr))
	end
end