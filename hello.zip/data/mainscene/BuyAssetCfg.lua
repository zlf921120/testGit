
BuyAssetCfg = 
{
	buyPhysicalTip = "花費%d鑽石購買%d點體力\n是否繼續?(今天已購買%d次)",
	err_buy_physcial_coutfull = "達到購買上限",
	UpLevelVipTip = "你的購買次數不足，提升VIP等級能獲得更多的購買次數",
	RefreshlVipTip = "您的vip等級次數不足，今日刷新次數已滿",
	UpLevelVipTipUnLock = "你的VIP等級不足,提升VIP等級能獲得更多的特權",
}

BuyAssetEvent = 
{
	CB_SHOW_COIN_RECODE = "cb_show_coin_recode" , --展示购买金币记录
	CB_UPDATE_SCENE = "buycpin_cb_update_scene", --更新购买金币场景
	BUYCOIN_SHOW_ALERT = "BUYCOIN_SHOW_ALERT", --购买金币 提示信息
	CB_SHOW_ANIM = "cb_show_buy_coin_anim", --购买金币动画
}