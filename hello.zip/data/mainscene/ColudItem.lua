--
-- Author: lvgansheng
-- Date: 2014-09-25 10:32:19
-- 主场景云

ColudItem = class("ColudItem", DisplayUtil.newWidget)
ColudItem.last_time = 0 --最后消失的时间点

local could_name_list = {"cloud_one.png", "cloud_two.png", "cloud_three.png",
						"cloud_four.png", "cloud_five.png"}

local time_list = {2,3,3,2,4}
local distan_list = {380,300,380,300,350}

function ColudItem:init(idx)
	self.idx = idx
	self.time_diff = time_list[idx] or 5
	self.dis = distan_list[idx] or 300
	self.cloud_spr = CCSprite:createWithSpriteFrameName(could_name_list[idx])
	self.cloud_spr:setVisible(false)
	self:addNode(self.cloud_spr)
end

function ColudItem:create(idx)
	local colud = ColudItem.new()
	colud:init(idx)
	return colud
end

function ColudItem:playAct()
	if self.cloud_spr:isVisible() then
		return
	end

	if os.clock()-self.last_time>self.time_diff or self.last_time==0 then
		self.cloud_spr:setVisible(true)
	  	self.cloud_spr:setOpacity(0)
		self.cloud_spr:setPositionX(0)
		
	  	--第一段云的移动,alpha从0~255
		local spawn_act_in = CCSpawn:createWithTwoActions(CCMoveBy:create(5, ccp(100, 0)),CCFadeIn:create(5))
		
		local spawn_act_middle = CCMoveBy:create(15, ccp(self.dis, 0))

		local spawn_act_out = CCSpawn:createWithTwoActions(CCMoveBy:create(5, ccp(100, 0)),CCFadeOut:create(5))

		local call_back_act = CCCallFunc:create(function()
			self.cloud_spr:setVisible(false)
			self.cloud_spr:setPositionX(0)
			self.last_time = os.clock()
		end)

		local arr = CCArray:create()
		arr:addObject(spawn_act_in)
		arr:addObject(spawn_act_middle)
		arr:addObject(spawn_act_out)
		arr:addObject(call_back_act)
		self.cloud_spr:runAction(CCSequence:create(arr)) 
	end
end

--是否正在移动
function ColudItem:isMove()
	self.cloud_spr:isVisible()
end

function ColudItem:reset()
	self.cloud_spr:setVisible(false)
	self.cloud_spr:setPositionX(0)
	self.last_time = os.clock()
end