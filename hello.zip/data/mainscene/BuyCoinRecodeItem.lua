
BuyCoinRecodeItem = class("BuyCoinRecodeItem", function() 
    return CCLayer:create()
end)
BuyCoinRecodeItem.__index = BuyCoinRecodeItem
BuyCoinRecodeItem._widget 	= nil

--购买记录 条目
function BuyCoinRecodeItem:create(itemVo)
    local ret = BuyCoinRecodeItem.new()
    ret:init(itemVo)
    return ret
end

function BuyCoinRecodeItem:init(itemVo)

	self._widget = GUIReader:shareReader():widgetFromJsonFile("main_scene/BuyCoinRecode.ExportJson")

    local labDiamon = tolua.cast(self._widget:getChildByName("lab_diamon"),"Label")
    labDiamon:setText(itemVo.diamon)
    
    local labCoin = tolua.cast(self._widget:getChildByName("lab_coin"),"Label")
    labCoin:setText(itemVo.coin)
end
