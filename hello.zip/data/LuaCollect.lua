--
-- Author: thisgf
-- Date: 2014-12-30 16:34:09
--

local level = 1

local lastCount = {}

local function analyzeTable(t, record, count)

    for k, v in pairs(t) do

        if type(v) == "table" then

            if not record[v] then

                record[v] = tostring(k)
                if not count[k] then
                    count[k] = {}
                end
                table.insert(count[k], tostring(v))
                analyzeTable(v, record, count)

                if getmetatable(v) then
                    analyzeTable(getmetatable(v), record, count)
                end

            end
        end

    end

end

function LuaCollect(reset)

    if reset then
        level = 1
        lastCount = {}
    else
        level = level + 1
    end

    local count = {}
    local record = {}

    if level > 1 then
        collectgarbage("collect")
        collectgarbage("collect")
    end

    analyzeTable(_G, record, count)

    if level > 1 then
        local f
        if level == 2 then
            f = io.open("collect.txt", "w+")
        else
            f = io.open("collect.txt", "a+")
            print("//////////////////////////////呵呵呵", level)
        end

        if not f then
            print("can't open file")
        else
            f:write(string.format("------------------------level:%d-------------------\n", level))
            for k, v in pairs(count) do
                if not lastCount[k] then
                    f:write(string.format("name:[%s], num:%d\n", k, #v))
                end
            end

            f:close()
        end

        lastCount = count

    end

end