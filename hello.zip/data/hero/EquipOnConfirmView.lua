--
-- Author: lvgansheng
-- Date: 2014-06-19 20:30:47
-- 确认是否装备的界面

EquipOnConfirmView =  class("EquipOnConfirmView", WindowBase)
EquipOnConfirmView.uiLayer = nil
EquipOnConfirmView.widget = nil
EquipOnConfirmView.enterFun = nil 
EquipOnConfirmView.exitFun = nil
EquipOnConfirmView.withParamEnterFun = nil
EquipOnConfirmView.hero_id = 0
EquipOnConfirmView.item = nil
EquipOnConfirmView.location = 0
EquipOnConfirmView.open_param = nil

local visbile_size = nil

function EquipOnConfirmView:init()

	require("AttrLabel")
	require("EqmOnCfmItem")

	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)

    visbile_size = CCDirector:sharedDirector():getVisibleSize() 
	
	local bg_layer = Layout:create()
	-- bg_layer:ignoreContentAdaptWithSize(false)
	bg_layer:setTouchEnabled(true)
	-- bg_layer:setBackGroundColorOpacity(255)
	-- bg_layer:setBackGroundColor(ItemHelper.colors.yellow,ItemHelper.colors.red)
	bg_layer:setSize(CCSize(visbile_size.width,visbile_size.height))
	self.uiLayer:addWidget(bg_layer)

	self.widget_left = EqmOnCfmItem:create()
	self.widget_right = EqmOnCfmItem:create()

	self.uiLayer:addWidget(self.widget_left)
	self.uiLayer:addWidget(self.widget_right)

	self.widget_left:setPositionX((visbile_size.width-770)/2)
	self.widget_right:setPositionX((visbile_size.width-770)/2+358)


    --self.widget_left:setPositionX(visbile_size.width/2-170)

    self.canelBtn = Button:create() 	--取消按钮
    self.canelBtn:retain()
    self.canelBtn:loadTextures("btn_up_1.png","btn_down_1.png","",UI_TEX_TYPE_PLIST)
    self.canelBtn:setTitleText("取消")
    local function cancelBtnfun(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
			WindowCtrl:getInstance():close(CmdName.EqmOnConfirmView)	
        end
    end

    self.canelBtn:addTouchEventListener(cancelBtnfun)
    self.uiLayer:addWidget( self.canelBtn)
    self.canelBtn:setPosition(ccp(880,147))
    self.canelBtn:setTitleFontSize(24)
    self.canelBtn:setTitleColor(ItemHelper.colors.yellow)

    self.cfmBtn = Button:create() 	--装备按钮
    self.cfmBtn:retain()
    self.cfmBtn:loadTextures("btn_up_1.png","btn_down_1.png","",UI_TEX_TYPE_PLIST)
    self.cfmBtn:setTitleText("裝備")
    local function cfmBtnFun(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
			local exc_hero_info = HeroManager:getInstance():getHeroInfoById(self.itemData.hero_id)

        	if exc_hero_info then
             	local params = {}
             	local exc_hero_info = HeroManager:getInstance():getHeroInfoById(self.itemData.hero_id)
                -- params["rtf"] = string.format("確認要和%s身上的裝備%s替換嗎？",exc_hero_info.name,self.itemData.mode.name)
                params["rtf"]={{txt="確認要和", color=ItemHelper.colors.yellow, fontSize=22},
                				{txt=exc_hero_info.name, color=ItemHelper.colors.green, fontSize=22},
                				{txt="身上的裝備", color=ItemHelper.colors.yellow, fontSize=22},
                				{txt=self.itemData.mode.name, color=ItemHelper:getColorByQuality(self.itemData.mode.quality), fontSize=22},
                				{txt="替換嗎?", color=ItemHelper.colors.yellow, fontSize=22}}

                params.okFunc = function()
                    -- 发送鉴定协议
                     local param = {}
		             param.hero_id = self.hero_id
		             param.item = self.itemData
		             param.location = self.itemData.mode.item_type
		             Notifier.dispatchCmd(CmdName.ChangeItemStorage,param)
		            -- WindowCtrl:getInstance():close(CmdName.EqmOnConfirmView)
                end
                WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
            else
            	  	local param = {}
		             param.hero_id = self.hero_id
		             param.item = self.itemData
		             param.location = self.itemData.mode.item_type
		             Notifier.dispatchCmd(CmdName.ChangeItemStorage,param)
		             --WindowCtrl:getInstance():close(CmdName.EqmOnConfirmView)

		            --新手引导事件
		            if GuideDataProxy:getInstance().nowMainTutroialEventId == 10611 then
		             	Notifier.dispatchCmd(GuideEvent.StepFinish,"click_ex_confirm")
		         	end
            end
             -- cclog("跟某個英雄%d交換裝備%d",self.itemData.hero_id,self.itemData.mode.base_id)
        end
    end
    self.cfmBtn:addTouchEventListener(cfmBtnFun)
    self.uiLayer:addWidget( self.cfmBtn)
    self.cfmBtn:setPosition(ccp(880,55))
    self.cfmBtn:setTitleFontSize(24)
    self.cfmBtn:setTitleColor(ItemHelper.colors.yellow)

	self.widget_middle = ItemInfoView:create()
    self.uiLayer:addWidget(self.widget_middle)
    self.widget_middle:setPositionX(visbile_size.width/2-170)
    self.widget_middle.selBtn:setTitleText("取消")
    self.widget_middle.apply_btn:setTitleText("裝備")
    self.widget_middle.selBtn:addTouchEventListener(cancelBtnfun)
    self.widget_middle.apply_btn:addTouchEventListener(cfmBtnFun)
    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function EquipOnConfirmView:showStepAnim(param)
	if param.target == "backpack_eqm" then
		GuideRenderMgr:getInstance():renderMainFlag(self.widget_middle.apply_btn,param.id,param.target)
	elseif param.target == "ex_confirm" then
		GuideRenderMgr:getInstance():renderMainFlag(self.cfmBtn,param.id,param.target)
	end
end

function EquipOnConfirmView:open()
	self:setItemData(self.params.hero_id,self.params.item)
end

function EquipOnConfirmView:create()
	local confirm_view = EquipOnConfirmView.new()
	-- confirm_view:init()
	return confirm_view	
end

function EquipOnConfirmView:setItemData(hero_id,item)
	self.hero_id = hero_id
	self.itemData = item 
	-- self.attr_flag = ItemHelper:getAttrFlagByLocation(item.mode.item_type)
	
	-- self:changeContent()
	local eqms = HeroManager:getInstance():getBattleHeroEqmList(hero_id)
	local eqm_vo = eqms:getSingleEquip(item.mode.item_type)
	local cur_item = nil
	if eqm_vo then
		cur_item = eqm_vo.item
	end

	if cur_item then
		self.widget_left:setEnabled(true)
		self.widget_right:setEnabled(true)
		self.canelBtn:setEnabled(true)
		self.cfmBtn:setEnabled(true)
		self.widget_middle:setEnabled(false)
		self.widget_left:setItemData(cur_item)
		self.widget_right:setItemData(item,cur_item)
	else
		self.widget_left:setEnabled(false)
		self.widget_right:setEnabled(false)
		self.canelBtn:setEnabled(false)
		self.cfmBtn:setEnabled(false)
		self.widget_middle:setEnabled(true)
		self.widget_middle:setItemData(item)

	end

	--设置按钮位置


end

function EquipOnConfirmView:changeContent()
	-- self.item_icon:setBaseId(self.itemData.mode.base_id)

	-- local namelabel = self.widget_left:getChildByName("name_label")
	-- tolua.cast(namelabel,"Label")
	-- namelabel:setText(self.itemData.mode.name)
	-- namelabel:setColor(ItemHelper:getColorByQuality(self.itemData.mode.quality))

	-- self.attr_list_view:removeAllItems()

	-- if self.itemData.mode.limit_lev>0 then
	-- 	self.team_lv_label:setData("戰隊等級",self.itemData.mode.limit_lev)
	-- 	self.attr_list_view:pushBackCustomItem(self.team_lv_label)
	-- end

	-- if ItemManager:getInstance():isEqm(self.itemData.mode.item_type) == false then
	-- 	self.item_desc:setText(self.itemData.mode.desc)
	-- 	self.attr_list_view:pushBackCustomItem(self.item_desc)
	-- 	return 
	-- end

	-- self.item_type_label:setData("裝備類型",ItemHelper:getTypeName(self.itemData.mode.item_type))
	
	-- local attr_name = AttrHelper:getAttrNameByFlag(self.attr_flag)
 -- 	local attrs = ItemManager:getInstance():getEqmBaseAttrAddQuality(self.itemData.mode.base_id)
	-- self.base_attr_label:setData(attr_name,attrs[self.attr_flag])

	-- self.attr_list_view:pushBackCustomItem(self.item_type_label)
	-- self.attr_list_view:pushBackCustomItem(self.base_attr_label)

	-- --强化等级处理
	-- if self.itemData.powered_lev>0 then
	-- 	 self.powered_lv_label:setData("強化等級:",self.itemData.powered_lev)
	-- 	 self.attr_list_view:pushBackCustomItem(self.powered_lv_label)
	-- end 

	-- --附魔等级处理
	-- if self.itemData.enchant_lev>0 then
	-- 	self.enchant_label:setData(string.format("附魔等級:%s星",Helper.converNumToChinese(self.itemData.enchant_lev)))
	-- 	self.attr_list_view:pushBackCustomItem(self.enchant_label)
	-- end

	-- --鉴定属性处理
	-- local identify_attrs = self.itemData.identify_attrs
	-- local count = #identify_attrs
	-- local attr_vo = nil
	-- local attr_label = nil
	-- if count>0 then
	-- 	self.attr_list_view:pushBackCustomItem(self.identify_dec_label)

	-- 	for key=1,count do
	-- 		attr_vo = identify_attrs[key]
	-- 		attr_label = self.attr_label_dic:objectForKey(key)
	-- 		if attr_label == nil then
	-- 			attr_label = AttrLabel:create()
	-- 			self.attr_label_dic:setObject(attr_label, key)
	-- 		end
	-- 		attr_label:setData(AttrHelper:getAttrNameByFlag(attr_vo.flag),attr_vo.value)
	-- 		self.attr_list_view:pushBackCustomItem(attr_label)
	-- 	end
	-- end
end
