--
-- Author: lvgansheng
-- Date: 2014-08-12 20:06:06
-- 其他玩家的信息

require "CombatVO"

OtherRoleInfo = class("OtherRoleInfo")
OtherRoleInfo.role_id = nil 
OtherRoleInfo.role_name = nil
OtherRoleInfo.team_lev = 0
OtherRoleInfo.fight_capacity = 0
OtherRoleInfo.face_id = 0
OtherRoleInfo.sex = 0
OtherRoleInfo.rank = 0
OtherRoleInfo.win_num = 0 
OtherRoleInfo.heros = nil -- 该玩家身上带的英雄信息
OtherRoleInfo.battle_data = nil -- 战斗时候的站位
OtherRoleInfo.guild_name = nil -- 帮会名称
OtherRoleInfo.demon_stars = 0  --精灵阶数

OtherRoleInfo.pet_lv = 0 -- 侍宠精灵等级
OtherRoleInfo.pet_star = 0 -- 侍宠精灵星级

OtherRoleInfo.agility = 0  --先手值
OtherRoleInfo.team_skills = nil  --战队技能


OtherRoleInfo.hero_fc_dic = nil
OtherRoleInfo.hero_num = 0
function OtherRoleInfo:init()
	require("RoleId")
	require("TeamEnum")

	self.team_skills = {}
end

function OtherRoleInfo:create()
	local role = OtherRoleInfo.new()
	role:init()
	return role
end

--设置该玩家的基础信息
function OtherRoleInfo:setBaseInfo(role_id, role_name, 
						team_lev, fight_capacity, face_id, 
						rank, win_num, guild_name,sex)
		-- self.robot_type = robot_type
		self.role_id = RoleId:create()
		self.role_id:setData(role_id.uin, role_id.channel_id, role_id.zone_id)
		self.role_name = role_name
		self.team_lev = team_lev
		self.fight_capacity = fight_capacity
		self.face_id = face_id
		self.rank = rank
		self.win_num = win_num
		self.guild_name = guild_name
		self.sex = sex
end

--设置角色所携带的英雄
function OtherRoleInfo:setHeros(heros)
	local temp_hero_info = nil
	local server_hero_info = nil
	local client_hero_info = nil
	local skills = nil
	local skill_info = nil
	self.heros = {}
	self.battle_data = {}
	self.hero_fc_dic = {}
	local temp_fc_attrs = nil
	self.hero_num = #heros
	for i=1,#heros do
		temp_fc_attrs = {}
		server_hero_info = heros[i]
		temp_hero_info = HeroInfo.new()
		temp_hero_info.attrs = {}
		temp_hero_info:setOtherHeroInfo(
		    server_hero_info.base_id,
			server_hero_info.lev, 
			server_hero_info.stars,
			server_hero_info.sel_model_infos
		)
		
		client_hero_info = HeroManager:getInstance():getHeroInfoByBaseId(server_hero_info.base_id)
		temp_hero_info.hurt_audio_id = client_hero_info.hurt_audio_id
		temp_hero_info.charm = client_hero_info.charm
		-- cclog("英雄魅力值~~~%d~~~%d",server_hero_info.base_id, client_hero_info.charm)

		--设置敌方英雄的战队位置
		temp_hero_info.enemy_pos = server_hero_info.pos

		self.battle_data[TEAM_POS_FOR_BATTLE_DICT[temp_hero_info.enemy_pos]] = temp_hero_info

		--设置属性
		local server_attr_one = nil
		local flag_name = nil
		local svr_hero_attrs = server_hero_info.attrs
		if svr_hero_attrs then
			for _,server_attr_one in ipairs(svr_hero_attrs) do
			   flag_name = AttrHelper:getAttrStrFlag(server_attr_one.name)
			   temp_hero_info.attrs[flag_name] = server_attr_one.val
			   temp_fc_attrs[server_attr_one.name] = server_attr_one.val
	  		end
	  		--先默认1000
	  		-- temp_hero_info.attrs.stare = 1000
  		end

		--HeroManager:getInstance():transHeroAttrs(server_hero_info.attrs,temp_hero_info.attrs)

		--设置技能
		skills = server_hero_info.skills
		if skills then
			for j=1,#skills do
				skill_info = skills[j]
	      		temp_hero_info:setSkillInfo(skill_info.id,skill_info.lev)
			end
		end

		--加密属性
		local attrData = temp_hero_info:getEncryptAttrData()
		attrData:setIsEncrypt(true)
		attrData:setServerAttrs(server_hero_info.combat_attrs)

		--加密技能
		for i, v in ipairs(server_hero_info.combat_skills) do
			temp_hero_info:setEncryptSkillData(v.id, v.lev)
		end

		self.hero_fc_dic[server_hero_info.base_id]= HeroManager:getInstance():calculateHeroFc(temp_hero_info,temp_fc_attrs)
		table.insert(self.heros,temp_hero_info)
		-- cclog("英雄戰鬥力~~~~%d~~~~%d",server_hero_info.base_id,self.hero_fc_dic[server_hero_info.base_id])
	end
end

--排序英雄 星级>战力>基础ID
function OtherRoleInfo:sortHeros()
	if self.heros and #self.heros > 0 then

		local function sortFunc(a,b)
			if a.cur_lev ~= b.cur_lev then
				return a.cur_lev < b.cur_lev
			end
			if a.cur_stars ~= b.cur_stars then
				return a.cur_stars < b.cur_stars
			end
			if a.base_id ~= b.base_id then
				return a.base_id < b.base_id
			end
		end
		table.sort(self.heros,sortFunc)
	end
end

--设置侍宠技能
function OtherRoleInfo:setTeamSkills(skills)
	self.team_skills = skills

	for i, v in ipairs(skills) do
		--暂时只用到敏捷值
		if v.id == TeamSkillID.AGILITY then
			local ts = TeamManager:getInstance():getConfigSkillData(v.id, v.lev)
			self.agility = ts.agility
			break
		end
	end

end

--设置侍宠等级跟星级
function OtherRoleInfo:setPetAttr(pet_lv, pet_star)
	self.pet_lv = pet_lv
	self.pet_star = pet_star
end

--返回敌方英雄战斗站位
function OtherRoleInfo:getBattleData()
	return self.battle_data
end

local function sortHeroInfo(hero_info_one, hero_info_two)
	if hero_info_one.cur_lev ~= hero_info_two.cur_lev then
		return hero_info_one.cur_lev>hero_info_two.cur_lev
	end

	return hero_info_one.charm>hero_info_two.charm
end

function OtherRoleInfo:getMaxCharmHero()
	local max_fc = 0
	local max_hero_id = 0
		
	table.sort(self.heros,sortHeroInfo)
	max_hero_id = self.heros[1].base_id

	return max_hero_id
end

--获取敌方侍宠精灵提供的战力
function OtherRoleInfo:getPetExtFc()
	local ext_fc = 0

	local ext_hp = 0
	local ext_atk = 0
	local ext_pdef = 0

	--侍宠属性增加的战斗力
	local ext_attrs = PetDataProxy:getInstance():getAttrAddition(self.pet_star, self.pet_lv)
	ext_hp = ext_attrs.hp
	ext_atk = ext_attrs.act
	ext_pdef = ext_attrs.def

	-- (1*生命+6.5*攻击+5*防御)/5
	local one_hero_add_fc = (ext_hp+6.5*ext_atk+5*ext_pdef)/5
	ext_fc = self.hero_num*one_hero_add_fc

	--技能增加的战斗力
	local tmp_local_skill_info = nil
	for k,team_skill_vo in ipairs(self.team_skills) do
		if team_skill_vo.lev > 0 then
			tmp_local_skill_info = TeamManager:getInstance():getConfigSkillData(team_skill_vo.id, team_skill_vo.lev)
			if tmp_local_skill_info then
				ext_fc = ext_fc + tmp_local_skill_info.team_fc_add		
			end
		end
	end

	cclog("敵方精靈增加的額外戰鬥力為%d",ext_fc)

	-- 精灵增加的战斗力向上取整，防止显示的时候有小数值
	ext_fc = math.ceil(ext_fc)

	return ext_fc
end

--获取指定英雄
function OtherRoleInfo:getHeroById(id)
	if self.heros then
		for k,v in pairs(self.heros) do
			if v.id == id then
				return v
			end
		end
	end
	return nil
end

--查看英雄是否全部阵亡
function OtherRoleInfo:isDealAllHero()
	local cout = 0
	if self.heros then
		for k,v in pairs(self.heros) do
			local hp_cur = v:getAttr(AttrHelper.attr_flag.hp_cur)
			if hp_cur and hp_cur > 0 then
				cout = cout + hp_cur 
			end
		end
	end
	return cout <= 0
end