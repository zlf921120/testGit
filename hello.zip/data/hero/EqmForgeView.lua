--
-- Author: lvgansheng
-- Date: 2014-06-20 14:20:54
-- 装备锻造界面


EqmForgeView =  class("EqmForgeView",WindowBase)
EqmForgeView.uiLayer = nil
EqmForgeView.widget = nil
EqmForgeView.enterFun = nil 
EqmForgeView.exitFun = nil
EqmForgeView.item = nil
EqmForgeView.location = 0

local cur_view_type = 0 -- 记录当前打开的界面类型

function EqmForgeView:init()

    require("EqmPoweredView")
    require("EqmEnchantView")
    require("EqmExchView")
    require("EqmIdentifyView")
    require "EqmUpgradeView"
    require("EqmGemView")
    require("EquipIcon")
    require("CustomMenu")

    self.view_dic = CCDictionary:create() --记录子界面
    self.view_dic:retain()

	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/equip/equip_def/equip_def.ExportJson")
    self.uiLayer:addWidget(self.widget)

    self.nam_label =  tolua.cast(self.uiLayer:getWidgetByName("name_label"), "Label") 
    self.nam_label:setText("")

    local exch_btn = self.uiLayer:getWidgetByName("exch_btn")
    local function onExchBtnClick(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            local params ={}
            params.cur_view_type = cur_view_type
            params.cur_hero_id = self.item.hero_id
           WindowCtrl:getInstance():open(CmdName.EqmExchView,params)
        end
    end
    exch_btn:addTouchEventListener(onExchBtnClick)

    self.left_arrow = Button:create()
    self.left_arrow:setScaleX(-1)
    self.left_arrow:loadTextures("btn_up_14.png", "btn_down_14.png", "", UI_TEX_TYPE_PLIST)
    self.left_arrow:retain()
    self.left_arrow:setPosition(ccp(248-80,408))

    self.equip_icon = EquipIcon:create()
    self.equip_icon:setPosition(ccp(248,408))
    -- self.equip_icon:isShowNumLabel(false)
    self.equip_icon:retain()

    self.right_arrow = Button:create()
    self.right_arrow:loadTextures("btn_up_14.png", "btn_down_14.png", "", UI_TEX_TYPE_PLIST)
    self.right_arrow:retain()
    self.right_arrow:setPosition(ccp(248+80,408))
    
    self.btnDesc = tolua.cast(self.uiLayer:getWidgetByName("btn_intro"),"Button")
    self.btnDesc:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            require "IntroTips"
            local tbl = {}
            tbl[HeroHelper.forgePanelType.powered] = IntroTipsCfg.PowerTips
            tbl[HeroHelper.forgePanelType.identify] = IntroTipsCfg.IdentifyTips
            tbl[HeroHelper.forgePanelType.enchant] = IntroTipsCfg.EnchatTips
            tbl[HeroHelper.forgePanelType.gem] = IntroTipsCfg.GemTips
            tbl[HeroHelper.forgePanelType.upgrade] = IntroTipsCfg.UpgradeTips

            WindowCtrl:getInstance():open(CmdName.IntroTips,{txt=tbl[self.cur_pos_type],widthChar=25})
        end
    end)

    --锻造界面类型切换
    local function menuCallback(tag)
        local pos_type = nil
        if tag == 1 then 
            pos_type = HeroHelper.forgePanelType.powered
        elseif tag == 2 then
            pos_type =HeroHelper.forgePanelType.identify
            ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.forge_identity)
            self:hideNewsImg(NewImgEnum.forge_identity)
        elseif tag == 3 then
            pos_type = HeroHelper.forgePanelType.enchant
            ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.forge_enchant)
            self:hideNewsImg(NewImgEnum.forge_enchant)
        elseif tag == 4 then   
            pos_type = HeroHelper.forgePanelType.gem
            ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.forge_gem)
            self:hideNewsImg(NewImgEnum.forge_gem)
        elseif tag == 5 then
            pos_type = HeroHelper.forgePanelType.upgrade
            ActivateDataProxy:getInstance():setEventVoDoneViewNew(NewImgEnum.forge_upgrade)
            self:hideNewsImg(NewImgEnum.forge_upgrade)
        else 
            pos_type = HeroHelper.forgePanelType.powered
        end
       
       self:changeConentByPosType(pos_type)
    end

    local menu_arr = {}
    table.insert(menu_arr,{txt="強化"})
    table.insert(menu_arr,{txt="鑒定"})
    table.insert(menu_arr,{txt="附魔"})
    table.insert(menu_arr,{txt="寶石"})
    table.insert(menu_arr,{txt="升級"})

    self.cus_menu = CustomMenu:create()
    self.cus_menu:setData(menu_arr,menuCallback)
    self.cus_menu:alignItemsVerticallyWithPadding(15)
    self.cus_menu:setPosition(CCPoint(889,300))
    self.widget:addNode(self.cus_menu) 

    --附魔成功
    self._onEnchantSuc = function( )
       self.equip_icon:setItem(self.item)
    end

    --强化成功成功
    self._onPoweredSuc = function( )
       -- self.equip_icon:setItem(self.item)
        self.equip_icon:setPowerNum(self.item.powered_lev)
    end

    --批量强化成功
    self._onPoweredBatchSuc = function(params)
        -- cclog("新的強化等級=%s",self.item.powered_lev)
        self.item = ItemManager:getInstance():getEquipInfoById(self.item.id)
        self.equip_icon:setPowerNum(self.item.powered_lev)
        WindowCtrl:getInstance():close(CmdName.EqmBatchPoweredView)
        --批量强化特效
        -- if params ==nil or params["is_batch_powered"]==true then
        local win_params = params or {}
        WindowCtrl:getInstance():open(CmdName.EqmCommAnimPanel, win_params)
        -- end
    end

    --升级装备成功
    self._onUpgradeEqmSuc = function(param)
        self.equip_icon:setItem(param.item)
    end

    self.left_arrow:addTouchEventListener(function(sender, eventType )
        if eventType == ComConstTab.TouchEventType.ended then
            self.cur_quick_idx = self:findFitQuickIdxBy(self.cur_quick_idx,1)

            -- local qucik_item_list = ItemManager:getInstance():getQuickForgeList()
             WindowCtrl:getInstance():open(CmdName.Eqm_Forge_View,
                        {self.qucik_item_list[self.cur_quick_idx], 
                        self.qucik_item_list[self.cur_quick_idx].mode.item_type, cur_view_type})
                   
        end
    end)

    --local down_change_btn = self.uiLayer:getWidgetByName("down_change_btn")
    self.right_arrow:addTouchEventListener(function(sender, eventType )
        if eventType == ComConstTab.TouchEventType.ended then
            self.cur_quick_idx = self:findFitQuickIdxBy(self.cur_quick_idx,2)
            WindowCtrl:getInstance():open(CmdName.Eqm_Forge_View,
                        {self.qucik_item_list[self.cur_quick_idx], 
                        self.qucik_item_list[self.cur_quick_idx].mode.item_type, cur_view_type})
        end
    end)

    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function EqmForgeView:open()
    self.item = self.params[1]
    self.location = self.params[2]
    self.cur_pos_type = self.params[3] or HeroHelper.forgePanelType.powered

    if self.params[4]~=false or self.qucik_item_list==nil then
        self.qucik_item_list,self.quick_tab_idx, 
        self.identify_quick_list,self.upgrade_quick_list = ItemManager:getInstance():getQuickForgeList()
    end

    self.cur_quick_idx = self.quick_tab_idx[self.item.hero_id.."_"..self.item.mode.base_id] or 1

    self:changeConentByPosType(self.cur_pos_type)
    self.cus_menu:setSelectedItem(self.cur_pos_type)
    self.equip_icon:setItem(self.item)
    self.nam_label:setText(self.item.mode.name)
    Notifier.regist(CmdName.EnchantSuccess,self._onEnchantSuc)
    Notifier.regist(CmdName.EqmPoweredSuccess,self._onPoweredSuc)
    Notifier.regist(CmdName.EqmBatchPoweredSucc,self._onPoweredBatchSuc)
    Notifier.regist(CmdName.EqmUpgradeSuc,self._onUpgradeEqmSuc)

    self:checkShowMenuItem()

    --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10504 or
        GuideDataProxy:getInstance().nowMainTutroialEventId == 10616 or
        GuideDataProxy:getInstance().nowMainTutroialEventId == 10804 then
        
        Notifier.dispatchCmd(GuideEvent.StepFinish,"click_forgeitem")
    end
end

--展示 新开启 图
function EqmForgeView:showNewsImg(key)
    local target = nil
    local pos = nil
    if key == NewImgEnum.forge_enchant then
        target = self.cus_menu:getItemByIdx(3)
        pos = ccp(130,50 + 25) 
    elseif key == NewImgEnum.forge_gem then
        target = self.cus_menu:getItemByIdx(4)
        pos = ccp(130,50 + 25) 
    elseif key == NewImgEnum.forge_identity then
        target = self.cus_menu:getItemByIdx(2)
        pos = ccp(130,50 + 25) 
    elseif key == NewImgEnum.forge_upgrade then
        target = self.cus_menu:getItemByIdx(5)
        pos = ccp(130,50 + 25) 
    end
    if target and target:getChildByTag(4152) == nil then
        local tips_img = AnimateManager:getInstance():getArmature("ui/effects_ui/new/new.ExportJson","new")
        tips_img:getAnimation():play("Animation1",-1,-1,1)
        tips_img:setTag(4152)
        tips_img:setPosition(pos)
        target:addChild(tips_img,10)
        -- self:tipsPointPlayAct(tips_img)
    elseif target and target:getChildByTag(4152) ~= nil then
        local tips_img = target:getChildByTag(4152)
        -- self:tipsPointPlayAct(tips_img)
    end
end

-- 隐藏 新开启 图
function EqmForgeView:hideNewsImg(key)
    local target = nil
    if key == NewImgEnum.forge_enchant then
        target = self.cus_menu:getItemByIdx(3)
    elseif key == NewImgEnum.forge_gem then
        target = self.cus_menu:getItemByIdx(4)
    elseif key == NewImgEnum.forge_identity then
        target = self.cus_menu:getItemByIdx(2)
    elseif key == NewImgEnum.forge_upgrade then
        target = self.cus_menu:getItemByIdx(5)
    end
    if target and target:getChildByTag(4152) ~= nil then
        target:removeChildByTag(4152,true)
    end
end

function EqmForgeView:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

function EqmForgeView:checkShowMenuItem()
    local dp = ActivateDataProxy:getInstance()
    dp:showForgeNewImg(function(key) self:showNewsImg(key) end)
    self.cus_menu:setHideByTbl(dp:getForgeHideTbl())
end

function EqmForgeView:returnFun()
    WindowCtrl:getInstance():close(self.name)
    --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10621 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"exit_identity")
    end
    --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10811 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"exit_enchant")
    end
end

--新手引导动画
function EqmForgeView:showStepAnim(param) 
    if param.target == "forge_btnidentity" then
        GuideRenderMgr:getInstance():renderMainFlag(self.widget,param.id,param.target)
    elseif param.target == "forge_btnenchant" then
        GuideRenderMgr:getInstance():renderMainFlag(self.widget,param.id,param.target)
    elseif param.target == "forge_exit" then
        GuideRenderMgr:getInstance():renderMainFlag(self.close_btn,param.id,param.target)
    end
end

function EqmForgeView:close()
    local cur_view = self.view_dic:objectForKey(cur_view_type)
    if cur_view then
        cur_view:close()
    end
    self.equip_icon:setItem(nil)
    Notifier.remove(CmdName.EnchantSuccess,self._onEnchantSuc)
    Notifier.remove(CmdName.EqmPoweredSuccess,self._onPoweredSuc)
    Notifier.remove(CmdName.EqmBatchPoweredSucc,self._onPoweredBatchSuc)
    Notifier.remove(CmdName.EqmUpgradeSuc,self._onUpgradeEqmSuc)

    --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10621 or
        GuideDataProxy:getInstance().nowMainTutroialEventId == 10509 or
        GuideDataProxy:getInstance().nowMainTutroialEventId == 10812 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"exit_forge")
    end
end
function EqmForgeView:create()
    local attr_view = EqmForgeView.new()
    -- attr_view:init()
    return attr_view    
end

function EqmForgeView:extTouch(enable)

    self.cus_menu:setTouchEnabled(enable)   
end

function EqmForgeView:extTouchPriority(value)
    self.cus_menu:setTouchPriority(value)

end

function EqmForgeView:changeConentByPosType(pos_type,params)
    --首次打开，创建相应界面
    if self.view_dic:objectForKey(pos_type) == nil then
        if pos_type == HeroHelper.forgePanelType.powered then 
            self.view_dic:setObject(EqmPoweredView:create(),pos_type)
        elseif pos_type == HeroHelper.forgePanelType.enchant then
            self.view_dic:setObject(EqmEnchantView:create(),pos_type)
        elseif pos_type == HeroHelper.forgePanelType.identify then
            self.view_dic:setObject(EqmIdentifyView:create(),pos_type) 
       elseif pos_type == HeroHelper.forgePanelType.gem then
            self.view_dic:setObject(EqmGemView:create(),pos_type) 
        elseif pos_type == HeroHelper.forgePanelType.upgrade then
            self.view_dic:setObject(EqmUpgradeView:create(),pos_type)
        end
    end

    local cur_view = self.view_dic:objectForKey(cur_view_type)
    if cur_view_type > 0 then
        cur_view:close()
        cur_view:removeFromParentAndCleanup(true)
    end

    cur_view_type = pos_type
    cur_view = self.view_dic:objectForKey(cur_view_type)
    self.cur_pos_type = pos_type

    if cur_view_type == HeroHelper.forgePanelType.powered then
        cur_view:setData(self.item,self.location)
    elseif cur_view_type == HeroHelper.forgePanelType.enchant then
        cur_view:setData(self.item,self.location)
    elseif cur_view_type == HeroHelper.forgePanelType.identify then
        cur_view:setData(self.item,self.location)
    elseif cur_view_type == HeroHelper.forgePanelType.gem then
        cur_view:setData(self.item,self.location)
    elseif cur_view_type == HeroHelper.forgePanelType.upgrade then
        cur_view:setData(self.item,self.location)
    end

    cur_view:open()
    self.equip_icon:removeFromParentAndCleanup(true)
    self.left_arrow:removeFromParentAndCleanup(true)
    self.right_arrow:removeFromParentAndCleanup(true)
    cur_view:addChild(self.equip_icon)
    cur_view:addChild(self.left_arrow)
    cur_view:addChild(self.right_arrow)
    self.uiLayer:addWidget(cur_view)

    --控制左右快捷箭头是否显示
    if cur_view_type == HeroHelper.forgePanelType.identify and #self.identify_quick_list==0 then
        self.left_arrow:setVisible(false)
        self.right_arrow:setVisible(false)
        self.left_arrow:setTouchEnabled(false)
        self.right_arrow:setTouchEnabled(false)
    elseif cur_view_type == HeroHelper.forgePanelType.upgrade and #self.upgrade_quick_list==0 then
        self.left_arrow:setVisible(false)
        self.right_arrow:setVisible(false)
        self.left_arrow:setTouchEnabled(false)
        self.right_arrow:setTouchEnabled(false)
    else
        self.left_arrow:setVisible(true)
        self.right_arrow:setVisible(true)
        self.left_arrow:setTouchEnabled(true)
        self.right_arrow:setTouchEnabled(true)
    end
end

function EqmForgeView:findFitQuickIdxBy(tmp_quick_idx, quick_type)

    local tmp_quick_idx = tmp_quick_idx

    if quick_type==1 then --左箭头
        tmp_quick_idx = tmp_quick_idx -1
    else --右箭头
        tmp_quick_idx = tmp_quick_idx +1
    end

    if tmp_quick_idx<=0 then
        tmp_quick_idx = #self.qucik_item_list
    elseif tmp_quick_idx>#self.qucik_item_list then
        tmp_quick_idx = 1
    end

    if cur_view_type == HeroHelper.forgePanelType.identify then
        local tmp_item = self.qucik_item_list[tmp_quick_idx]
        if ItemManager:getInstance():canIdentify(tmp_item)==false then
           tmp_quick_idx = self:findFitQuickIdxBy(tmp_quick_idx, quick_type) 
        end
    elseif cur_view_type == HeroHelper.forgePanelType.upgrade then
        local tmp_item = self.qucik_item_list[tmp_quick_idx]
        local ret,err = ItemManager:getInstance():isCanEqmUpgradeByBaseId(tmp_item.mode.base_id)
        if err.teamLev==nil then
           tmp_quick_idx = self:findFitQuickIdxBy(tmp_quick_idx, quick_type) 
        end
    end
    
    return tmp_quick_idx
end