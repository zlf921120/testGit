--
-- Author: lvgansheng	
-- Date: 2014-06-18 11:14:27
-- 装备界面的插槽
require("ItemIcon")

EquipIcon = class("EquipIcon", ItemIcon)

EquipIcon.item = nil
EquipIcon.location = 0 --当前插槽的装备部位

function EquipIcon:extInit(location)
	self.location = location

	self.location_label = Label:create()
    self.location_label:setText(ItemHelper:getTypeName(self.location))
    self.location_label:setColor(ItemHelper.colors.yellow)
    self.location_label:setFontSize(22)
    self:addChild(self.location_label)

	self.add_btn= Button:create()
	self.add_btn:setVisible(false)
	self.add_btn:setTouchEnabled(false)
	self.add_btn:loadTextures("btn_up_2.png", "btn_down_2.png", "", UI_TEX_TYPE_PLIST)
    self:addChild(self.add_btn)
    self.add_btn:addTouchEventListener(function(sender, eventType)
 		 if eventType == ComConstTab.TouchEventType.ended then
 		 		if self.is_battle == false or self.isLock then
 		 			return
 		 		end

 		 		local param = {}
 		 		local equipType = ItemHelper:getEquipTypeWithItemType(self.location)
 		 		if equipType == ItemHelper.equipType.equip then
 		 			table.insert(param,HeroHelper.leftPanelType.equipListView)
				elseif equipType == ItemHelper.equipType.fashion then
					table.insert(param,HeroHelper.leftPanelType.fashion)
				end
	            table.insert(param,self.location)
	            if #param == 2 then
	            	Notifier.dispatchCmd(CmdName.CtrlRoleLeftPanel,param)
	        	end
 		 end
    end)

	self.up_btn = Button:create()

	self.up_btn_touch_panel = DisplayUtil.newLayout()
	self.up_btn_touch_panel:setTouchEnabled(true)
	self.up_btn_touch_panel:setSize(CCSize(100,100))
	self.up_btn_touch_panel:setPositionX(-50)
	self.up_btn_touch_panel:setPositionY(-50)
	self.up_btn:addChild(self.up_btn_touch_panel)

	self.up_btn:setVisible(false)
	self.up_btn:setTouchEnabled(false)
	self.up_btn:setPosition(ccp(30,-30))
	self.up_btn:setScale(0.5)
	self.up_btn:loadTextures("btn_up_12.png", "btn_down_12.png", "", UI_TEX_TYPE_PLIST)
    self:addChild(self.up_btn)
    self.up_btn_touch_panel:addTouchEventListener(function(sender, eventType)
 		 if eventType == ComConstTab.TouchEventType.ended then
 		 		if self.is_battle ==false or self.isLock then
 		 			return
 		 		end
 		 		--新手引导处理 (步骤进行到10608时不希望能点击该按钮)
 		 		require "GuideDataProxy"
 		 		if GuideDataProxy:getInstance().nowMainTutroialEventId == 10608 then
 		 			return
 		 		end

 		 		local param = {}
 		 		local equipType = ItemHelper:getEquipTypeWithItemType(self.location)
 		 		if equipType == ItemHelper.equipType.equip then
 		 			table.insert(param,HeroHelper.leftPanelType.equipListView)
				elseif equipType == ItemHelper.equipType.fashion then
					table.insert(param,HeroHelper.leftPanelType.fashion)
				end
	            table.insert(param,self.location)
	            if #param == 2 then
	            	Notifier.dispatchCmd(CmdName.CtrlRoleLeftPanel,param)
	        	end
 		 end
    end)
end

function EquipIcon:setItem(item)
	self.item = item -- 绑定物品数据
	if item ~= nil then
		self:setBaseId(item.mode.base_id)
		if self.location_label then
			self.location_label:setVisible(false)
		end
		self:setPowerNum(item.powered_lev)
		self:setEnchanteffect(item.enchant_lev)
	else
		self:setBaseId(0)
		if self.location_label then
			self.location_label:setVisible(true)
		end
		self:setPowerNum(0)
		self:setEnchanteffect(0)
	end
end

function EquipIcon:create()
	local iconSlot = EquipIcon.new()
	iconSlot:init()
	return iconSlot
end

function EquipIcon:setAddLabelStatus(visible)
	self.add_btn:setEnabled(visible)
	self.add_btn:setVisible(visible)
	if self.item then
		self.location_label:setVisible(false)
	else
		self.location_label:setVisible(not visible)
	end
end

function EquipIcon:setUpImgStatus(visible,isCanTouch)
	-- self.up_btn:setEnabled(visible)
	self.up_btn:setVisible(visible)
	if isCanTouch ~= nil then
		self.up_btn_touch_panel:setTouchEnabled(isCanTouch)
	else
		self.up_btn_touch_panel:setTouchEnabled(visible)
	end
	-- self.up_btn:setTouchEnabled(false)
	self.up_btn:stopAllActions()
	self.up_btn:setPosition(ccp(30,-30))
	if visible == true then
		local act_arr = CCArray:create()
		act_arr:addObject(CCMoveBy:create(1, ccp(0, 15)))
		act_arr:addObject(CCMoveBy:create(1, ccp(0, -15)))
		local forever_seqAction = CCRepeatForever:create(CCSequence:create(act_arr))
		self.up_btn:runAction(forever_seqAction)
	else
		self.up_btn:setPosition(ccp(30,-30))
	end
end

--根据是否上阵修改说明文字
function EquipIcon:changeLocLabel(is_battle)
	if is_battle then
		self.location_label:setText(ItemHelper:getTypeName(self.location))
	else
		self.location_label:setText("未上陣")
	end
end

function EquipIcon:setIsBattle( is_battle )
	self.is_battle = is_battle
	self:changeLocLabel(is_battle)
end

function EquipIcon:setLock(is_lock)
	self.isLock = is_lock
	if self.isLock and self.imgLock == nil then
		self.imgLock = ImageView:create()
		self.imgLock:loadTexture("guild_lock.png",UI_TEX_TYPE_PLIST)
		self.imgLock:setPosition(ccp(30,-30))
		self:addChild(self.imgLock)
	end
	if self.isLock == false and self.imgLock then
		self.imgLock:removeFromParentAndCleanup(true)
		self.imgLock = nil
	end
end

function EquipIcon:isNeedShowFindEqm()
	if self.up_btn:isVisible() or self.add_btn:isVisible() then
		return false
	else
		return true
	end
end

-- function EquipIcon:setPowerNum(powered_lv)
--     if powered_lv > 1 then
--         self.numTxt:setText(string.format("+%d",powered_lv))
--     else
--     	self.numTxt:setText("")
--     end
-- end