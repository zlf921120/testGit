--
-- Author: lvgansheng
-- Date: 2014-06-13 10:46:33
-- 存储卡牌信息的类，测试装备用


HeroInfo = class("HeroInfo")
HeroInfo.id = 0 --卡牌唯一ID
HeroInfo.base_id = 0 
HeroInfo.animat_res_id = 0 -- 动作资源ID
HeroInfo.icon_res_id = 0 --头像资源ID
HeroInfo.img_res_id = 0 --原画资源ID
HeroInfo.name = "英雄名稱"
HeroInfo.pos = 0 -- 卡牌站位类型
HeroInfo.race = 0 -- 英雄种族
HeroInfo.atk_type = 0 -- 英雄攻击方式
HeroInfo.init_lev = 0 --卡牌初始等级
HeroInfo.cur_lev = 1 --卡牌当前等级
HeroInfo.init_stars = 0 --卡牌初始星级
HeroInfo.cur_stars = 0 --卡牌当前星级
HeroInfo.exp = 0 --卡牌经验
HeroInfo.soul_gem_id = 0 --对应的灵魂石ID
HeroInfo.default_skills = nil --卡牌主动技能
HeroInfo.pas_skills = nil --卡牌被动技能
HeroInfo.equipList = nil --卡牌装备列表

HeroInfo.attrs = nil --战斗用的属性,只在存储其它玩家的英雄时才有用,自己身上的英雄attrs由客户端自己计算
HeroInfo.enemy_pos = 0 -- pvp时敌方英雄的战队位置

HeroInfo.skill_id_tab = nil
--受伤音效
HeroInfo.dead_audio_id = 0

HeroInfo._encryptAttrData = nil   --战斗中加密过的属性

HeroInfo._fashionId = 0  --时装ID
HeroInfo._modelId = 0  --模型ID
HeroInfo._fashionData = nil  --当前的时装数据
HeroInfo._fashionDataList = nil --时装数据列表
HeroInfo._fashionSlot = nil --所有时装列表

function HeroInfo:ctor()
	require("HeroSkillInfo")
	self.equipList = EquipListVo.new()
	self.default_skills = {}
	self.pas_skills = {}
	self.skill_id_tab = {}

	self._fashionDataList = {}
	self._fashionSlotEquipsList = {} --每个孔 的时装列表
	self._fashionSlotItemList = {} --每个孔 的代表item
	self._fashionCurWearList = {}

	self._encryptAttrData = BattleEncryptAttrData:create()
end

function HeroInfo:setBaseData(base_id, animat_res_id, icon_res_id, img_res_id, name, pos,
							 init_lev, init_stars, race, atk_type, desc, soul_gem_id)
	self.base_id = base_id
	self.animat_res_id = animat_res_id
	self.icon_res_id = icon_res_id
	self.img_res_id = img_res_id
	self.name = name
	self.pos = pos
	self.race = race
	self.atk_type = atk_type
	self.init_lev = init_lev
	self.init_stars = init_stars
	self.desc = desc
	self.soul_gem_id = soul_gem_id
end

--设置卡牌默认的技能
function HeroInfo:setDefaultSkill(act_skill1, act_skill2, act_skill3, pas_skill1, pas_skill2, pas_skill3)
	local skill_info = HeroSkillInfo:create()
	skill_info:setData(act_skill1,1,true)
	table.insert(self.default_skills,skill_info)
	self.skill_id_tab[act_skill1] = 1

	skill_info = HeroSkillInfo:create()
	skill_info:setData(act_skill2,1,true)
	table.insert(self.default_skills,skill_info)
	self.skill_id_tab[act_skill2] = 2

	skill_info = HeroSkillInfo:create()
	skill_info:setData(act_skill3,1,true)
	table.insert(self.default_skills,skill_info)
	self.skill_id_tab[act_skill3] = 3

	skill_info = HeroSkillInfo:create()
	skill_info:setData(pas_skill1,1,true)
	table.insert(self.pas_skills,skill_info)
	self.skill_id_tab[pas_skill1] = 1

	skill_info = HeroSkillInfo:create()
	skill_info:setData(pas_skill2,1,true)
	table.insert(self.pas_skills,skill_info)
	self.skill_id_tab[pas_skill2] = 2

	skill_info = HeroSkillInfo:create()
	skill_info:setData(pas_skill3,1,true)
	table.insert(self.pas_skills,skill_info)
	self.skill_id_tab[pas_skill3] = 3


end

function HeroInfo:setExtData(id, cur_lev, cur_stars, exp, model_info)
	self.id = id
	self.cur_lev = cur_lev
	self.cur_stars = cur_stars
	self.exp = exp

	self:setFashionFromServer(model_info)
end

function HeroInfo:getEquipList()	
	return self.equipList -- 设置当前卡牌的装备信息
end

--当前卡牌在某位置上是否有装备
function HeroInfo:hasEquip(location)
	if 	self.equipList:getSingleEquip(location) ~= nil then
		return true
	end
	return false
end

--通过ID设置其它角色信息
function HeroInfo:setOtherHeroInfo(base_id, cur_lev, cur_stars, pos_models)
	local hero_mode = HeroManager:getInstance():getHeroInfoByBaseId(base_id)
	
	--设置基础信息
	self:setBaseData(hero_mode.base_id, hero_mode.animat_res_id, hero_mode.icon_res_id, 
		hero_mode.img_res_id, hero_mode.name,hero_mode. pos, hero_mode.init_lev, 
		hero_mode.init_stars, hero_mode.race, hero_mode.atk_type)
	
	--设置基础技能
	self:setDefaultSkill(hero_mode.default_skills[1].skill_id,hero_mode.default_skills[2].skill_id,
		hero_mode.default_skills[3].skill_id,hero_mode.pas_skills[1].skill_id,
		hero_mode.pas_skills[2].skill_id,hero_mode.pas_skills[3].skill_id)

	self:setExtData(base_id, cur_lev, cur_stars, 0, nil)
	self:setCurWear(pos_models)
end

function HeroInfo:setCurWear(pos_models)
	if pos_models == nil then return end

	local hm = HeroManager:getInstance()
	local im = ItemManager:getInstance()
	self._fashionCurWearList = self._fashionCurWearList or {}
	for i,v in ipairs(pos_models) do
		if v.sel_model_id > 0 then
			local mode = hm:getCfgFashionDataById(v.sel_model_id)
			local itemMode = im:getItemModelByBaseId(mode.baseId)
			self._fashionCurWearList[v.pos] = {fashionId=v.sel_model_id,mode=itemMode,fashionMode=mode}
		end
	end
	
	self:makeFashionSkin()
end

function HeroInfo:makeFashionSkin()
	if self._fashionCurWearList[ItemHelper.itemType.fashion_skin] then
		self._fashionId = self._fashionCurWearList[ItemHelper.itemType.fashion_skin].fashionId
	else
		self._fashionId = 0
	end
	if self._fashionId == 0 then
		self._modelId = self.animat_res_id
	else
		local fashionData = HeroManager:getInstance():getConfigFashionData(
		    self.base_id,
		    self._fashionId
		)
		self._modelId = fashionData.actionId
	end
end

function HeroInfo:setSkillInfo(skill_id,lev)
	local idx = self.skill_id_tab[skill_id]
		
	local temp_lev = lev
	if lev == 0 then --该技能未开启 
		temp_lev = 1
	end

	local skill_vo = SkillManager:getInstance():getSkillData(skill_id,temp_lev,3)

	local skill_info = nil
	if skill_vo.skillType == SkillType.ITT then --主动技能
		skill_info = self.default_skills[idx]
	elseif  skill_vo.skillType == SkillType.PASS then --被动技能
		skill_info = self.pas_skills[idx]
	end

	skill_info:setData(skill_id,lev)
end

function HeroInfo:setFashionFromServer(model_info)

	if model_info == nil then return end

	self._fashionSlotItemList = {}
	self._fashionCurWearList = {}
	self._fashionSlotEquipsList = {}
	self._unGetFashionList = {}

	local hm = HeroManager:getInstance()

	for _,v in ipairs(model_info) do
		self._fashionSlotEquipsList[v.pos] = {}
		for _,model in ipairs(v.models) do
			local mode = hm:getCfgFashionDataById(model.id)

			local itemMode = ItemManager:getInstance():getItemModelByBaseId(mode.baseId)
			table.insert(self._fashionSlotEquipsList[v.pos],{fashionId = model.id,stars = model.stars,upgradeExp = v.exp,mode = itemMode,fashionMode=mode})
		end

		local tempItem = HeroManager:getInstance():getFashionItemTab(v.pos,self.id)
		if tempItem == nil then
			tempItem = Item:new()
		end

		if v.sel_model_id > 0 then
			local mode = hm:getCfgFashionDataById(v.sel_model_id)
			local itemMode = ItemManager:getInstance():getItemModelByBaseId(mode.baseId)
			tempItem:setItemInfo(v.sel_model_id,mode.baseId,1)
			self._fashionCurWearList[v.pos] = {fashionId=v.sel_model_id,mode=itemMode,fashionMode=mode}
		else
			tempItem:setItemInfo(v.pos,0,1)
			tempItem.mode = {limit_stand = self.pos} --不能让mode为空
		end
    	
		self._fashionSlotItemList[v.pos] = tempItem
		tempItem:setIdentifyInfo(v.eqm_info.identify_left_num,v.eqm_info.identify_lucky)
		tempItem:setIdentifyAttrs(v.eqm_info.identify_attrs)
		tempItem:setPoweredLev(v.eqm_info.powered_lev)
	    tempItem:setEnchantLev(v.eqm_info.enchant_lev)
	    tempItem:setEnchantEnergy(v.eqm_info.enchant_energy)

	    --更新装备的镶嵌信息
	    local server_gems = v.eqm_info.gems
	    local client_gems = {}
	    local num = #server_gems
	    for i=1,num do
	         client_gems[server_gems[i].pos] = server_gems[i].item_base_id
	    end
	    tempItem:setGems(client_gems)
	    tempItem:setHeroId(self.id)
	    ItemManager:getInstance().equipItemTab[v.sel_model_id] = tempItem
	    HeroManager:getInstance():setFashionItemTab(v.pos,self.id,tempItem)
	    ItemManager:getInstance():setEqmAttrIsChange(tempItem.id,true)
	end

	self:makeFashionSkin()

	local list = hm:getAllCfgFashionData(self.id)
	for _,fashionData in pairs(list) do
		--衣柜没有该时装
		if self:getFashionSlotEquip(fashionData.pos,fashionData.fashionId) == nil then
			self._unGetFashionList[ fashionData.pos ] = self._unGetFashionList[ fashionData.pos ] or {}
			
			local itemMode = ItemManager:getInstance():getItemModelByBaseId(fashionData.baseId)
			table.insert(self._unGetFashionList[ fashionData.pos ],{fashionId = fashionData.fashionId,stars = 1,upgradeExp = 0,mode = itemMode,fashionMode=fashionData})
		end
	end
end

function HeroInfo:setFashionId(location, fashionId)
	self._fashionId = fashionId
	if fashionId > 0 then
		
		local mode = HeroManager:getInstance():getCfgFashionDataById(fashionId)
		local itemMode = ItemManager:getInstance():getItemModelByBaseId(mode.baseId)
		self._fashionCurWearList[location] = {fashionId=fashionId,mode=itemMode,fashionMode=mode}
	else
		self._fashionCurWearList[location] = nil
	end

	self:makeFashionSkin()

	if self:getFashionCurWearItem(location) then
		self:getFashionCurWearItem(location):setViewFashionInfo(self._fashionId >= 0)
	end
end

function HeroInfo:setEncryptSkillData(id, level)

	local decryptId = BattleManager:getInstance():getDecryptValue(id)

	local idx = self.skill_id_tab[decryptId]


	local skill_info = nil
	local skillType = SkillManager:getInstance():getSkillType(decryptId)
	if skillType == SkillType.ITT then --主动技能
		skill_info = self.default_skills[idx]
	elseif skillType== SkillType.PASS then --被动技能
		skill_info = self.pas_skills[idx]
	end

	skill_info:setEncryptData(id, level)
end

function HeroInfo:getSkillIdx( skill_id )
	return self.skill_id_tab[skill_id]
end

--[[
    获取当前等级
]]
function HeroInfo:getCurLevel()
	return self.cur_lev
end

--获取具体参数
function HeroInfo:getAttr(att)

	if self.attrs and att then
		return self.attrs[AttrHelper:getAttrStrFlag(att)]
	end
end

function HeroInfo:getEncryptAttrData()
	return self._encryptAttrData
end

function HeroInfo:setModelId(value)
	self._modelId = value
end

--[[
    获取模型ID
]]
function HeroInfo:getModelId()
	if self._modelId==0 then -- 防止英雄未获取时报错
		return self.animat_res_id
	end

	return self._modelId
end

function HeroInfo:getFashionSlotEquipsList()
	return self._fashionSlotEquipsList
end

function HeroInfo:getFashionSlotEquip(slotId,fashionId)
	if self._fashionSlotEquipsList[slotId] then
		for i,v in ipairs(self._fashionSlotEquipsList[slotId]) do
			if v.fashionId == fashionId then
				return v
			end
		end
	end
	return nil
end

--当前该英雄所穿的 时装列表
function HeroInfo:getFashionCurWearList()
	return self._fashionCurWearList
end
--未获取的时装
function HeroInfo:getUnGetFashionList(slotId)
	if self._unGetFashionList[slotId] then
		return self._unGetFashionList[slotId]
	end
	return nil
end

--该英雄衣柜 孔的属性加成
function HeroInfo:getFashionSlotEquipAddition(slotId)
	local voList = self._fashionSlotEquipsList[ slotId ]
	local ret = {}
	if voList then
		local attrs = {}
		for k,fashionVo in pairs(voList) do
			local addtions = HeroManager:getInstance():getFashionAddtion(fashionVo.mode.base_id,fashionVo.stars,self.id)
	  		for _,v in pairs(addtions) do
	  			attrs[v.key] = attrs[v.key] or 0
	  			attrs[v.key] = attrs[v.key] + v.value
	  		end
		end
		for k,v in pairs(attrs) do
			table.insert(ret,{key=k,value=v})
		end
		table.sort( ret, function(a,b) return a.key<b.key end )
	end
	return ret
end

function HeroInfo:getFashionCurWearCout()
	return Utils.get_length_from_any_table(self._fashionCurWearList)
end

function HeroInfo:getFashionCurWearItem(slotId)
	if self._fashionCurWearList[slotId] then
		return HeroManager:getInstance():getFashionItemTab(slotId,self.id)
	end
	return nil
end