--时装卡牌
FashionImgView = class("FashionImgView",function()
	return Layout:create()
end)

function FashionImgView:create(fashionData)
	local img_view = FashionImgView.new()
	img_view:init(fashionData)
	return img_view	
end

function FashionImgView:dispose()
	if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
end

function FashionImgView:init(fashionData)

	ComResMgr:getInstance():loadResByName("ui/hero/hero.plist","ui/hero/hero.pvr.ccz")
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/fashion_img_view/fashion_img_view.ExportJson")
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())
	
	self.labTitle = tolua.cast(self._widget:getChildByName("lab_title"),"Label")
	local mode = ItemManager:getInstance():getItemModelByBaseId(fashionData.baseId)
	self.labTitle:setText(mode.name)
	self.imgClick = tolua.cast(self._widget:getChildByName("ImageView_336"),"ImageView") --点击区

	local action_data = EffectManager:getInstance():getActionData(fashionData.actionId)
	local armHero = AnimateManager:getInstance():getArmature(action_data._fileFullPathName, action_data._fileName)
	local heroPanel = CCLayer:create()
	local heroBottomPanel = CCLayer:create()

	armHero:setScale(0.3)
	local arr = CCArray:create()
	arr:addObject(CCScaleTo:create(0.12,1.4))
	arr:addObject(CCScaleTo:create(0.1,1.3))
	armHero:runAction(CCSequence:create(arr))

	self._widget:addNode(heroBottomPanel)
	self._widget:addNode(heroPanel)
	heroPanel:setPosition(ccp(138,142))
	heroBottomPanel:setPosition(ccp(138,142))
	heroPanel:addChild(armHero)
	armHero:getAnimation():play("stand")

	local stard_act_list = HeroManager:getInstance():getHeroActListById(fashionData.heroId) 
	local cur_action_idx = 0

	--英雄随即动作播放完成后
    local function playCallBack(armature, movementType, movementID)
		if movementType == AnimationMovementType.COMPLETE then 
			--播放一个动作后，移除关联特效
			if stard_act_list[cur_action_idx] and 
				stard_act_list[cur_action_idx][2] ~= nil then
			 	EffectManager:getInstance():removeEffect(heroPanel,stard_act_list[cur_action_idx][2], nil, 0)
			end

			if stard_act_list[cur_action_idx] and 
				stard_act_list[cur_action_idx][3] ~= nil and
				stard_act_list[cur_action_idx][3] >0 then
			 		EffectManager:getInstance():removeEffect(heroBottomPanel,stard_act_list[cur_action_idx][3], nil, 0)
			end

			cur_action_idx = cur_action_idx +1
			if cur_action_idx>#stard_act_list then
				armHero:getAnimation():play("stand")
				-- TimerManager.addTimer(10000, playCallBack,true)

				self.imgClick:setTouchEnabled(true)
			else
				armHero:getAnimation():play(stard_act_list[cur_action_idx][1],-1,-1,0)
				if stard_act_list[cur_action_idx][2] ~= nil then
			 		EffectManager:getInstance():playEffect(heroPanel,stard_act_list[cur_action_idx][2], nil, 0)
				end

				if stard_act_list[cur_action_idx][3] ~= nil and stard_act_list[cur_action_idx][3]>0 then
			 		EffectManager:getInstance():playEffect(heroBottomPanel,stard_act_list[cur_action_idx][3], nil, 0)
				end
			end
		end
	end

	local function startAnim()
		cur_action_idx = 1

		armHero:getAnimation():setMovementEventCallFunc(playCallBack)
		armHero:getAnimation():play(stard_act_list[cur_action_idx][1],-1,-1,0)

		if stard_act_list[cur_action_idx][2] ~= nil then
		 	EffectManager:getInstance():playEffect(heroPanel,stard_act_list[cur_action_idx][2], nil, 0)
		end
	end

	startAnim() --开始播放


	self.imgClick:setTouchEnabled(false)
	self.imgClick:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then 
			self.imgClick:setTouchEnabled(false)
			startAnim()
		end
	end)
end