--
-- Author: lvgansheng
-- Date: 2014-07-04 10:29:14
-- 附魔物品元件


EnchantItem = class("EnchantItem", function() return Layout:create() end)
EnchantItem.item = nil
EnchantItem.feed_num = 0 --选择使用的物品数
EnchantItem.sub_btn = 0 --选择使用的物品数

function EnchantItem:init()
	--self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/role/enchant_item/enchant_item.ExportJson")
	--self:addChild(self.widget)
	require("ItemIcon")
	
	self.item_icon = ItemIcon:create()
	local icon_bg_width = 110
	local icon_bg_height = 110
	self.item_icon:setPosition(ccp(icon_bg_width/2,-icon_bg_height/2))
	self:addChild(self.item_icon)

	self.sub_btn = Button:create()
	self.sub_btn:setPosition(ccp(icon_bg_width-18,-15))
	self.sub_btn:loadTextures("btn_up_11.png", "btn_down_11.png", "", UI_TEX_TYPE_PLIST)
	self:addChild(self.sub_btn)

	-- self.item_icon = tolua.cast(self.widget:getChildByName("ImageView_1209"),"ImageView")
	self.sub_btn:addTouchEventListener(function(sender,eventType) 
		if eventType == ComConstTab.TouchEventType.ended then
			self:subFeedNum() 
		end	end)
	self.item_icon:setTouchEvent(function(sender,eventType) 
		if eventType == ComConstTab.TouchEventType.ended then
			self:addFeedNum() 
		end end)
	
	self.quantity_label = Label:create()
	self.quantity_label:setFontSize(20)
	self.quantity_label:setPosition(ccp(icon_bg_width/2,-85))
	self:addChild(self.quantity_label)

	-- self:setSize(CCSize(icon_bg_width+15,icon_bg_height+13))
	self:setScale(0.8)
end

function EnchantItem:create()
	local enchant_icon = EnchantItem.new()
	enchant_icon:init()
	return enchant_icon
end

function EnchantItem:setData(item)
	self.item = item
	-- self.location = location
	self.feed_num = 0
	self.sub_btn:setTouchEnabled(false)
	self.sub_btn:setVisible(false)
	self.item_icon:setBaseId(item.mode.base_id)
	self.quantity_label:setText(string.format("%d/%d",0,self.item.quantity))
end

function EnchantItem:addFeedNum() 
	if self.item.quantity == self.feed_num then
		return
	end

	-- self.feed_num = self.feed_num + 1
	-- self.sub_btn:setTouchEnabled(true)
	-- self.sub_btn:setVisible(true)
	-- self.quantity_label:setText(string.format("%d/%d",self.feed_num,self.item.quantity))
	local energy_num = ItemManager:getInstance():getEnchantEnergy(self.item.id)
	-- Notifier.dispatchCmd(CmdName.EqmEnchantEnergy,energy_num)
	local params = {}
	params.view_item = self
	params.change_type = 1
	Notifier.dispatchCmd(CmdName.EqmEnchantEnergy,params)
end

function EnchantItem:changeContent(change_type)
	if change_type == 1 then
		self.feed_num = self.feed_num + 1
		self.sub_btn:setTouchEnabled(true)
		self.sub_btn:setVisible(true)
		self.quantity_label:setText(string.format("%d/%d",self.feed_num,self.item.quantity))
	elseif change_type == 2 then
		if self.feed_num == 1 then
			self.feed_num = 0
			self.sub_btn:setTouchEnabled(false)
			self.sub_btn:setVisible(false)
		else
			self.feed_num = self.feed_num-1
		end
		self.quantity_label:setText(string.format("%d/%d",self.feed_num,self.item.quantity))
	end
end

function EnchantItem:subFeedNum() 
	local params = {}
	params.view_item = self
	params.change_type = 2
	Notifier.dispatchCmd(CmdName.EqmEnchantEnergy,params)

	
	-- local energy_num = ItemManager:getInstance():getEnchantEnergy(self.item.id)
	--Notifier.dispatchCmd(CmdName.EqmEnchantEnergy,params)
end

--是否提供了附魔值
function EnchantItem:isFeed()
	return self.feed_num>0
end


