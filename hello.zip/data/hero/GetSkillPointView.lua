--
-- Author: lvgansheng
-- Date: 2014-09-04 19:20:27
-- 获取技能点引导界面


GetSkillPointView = class("GetSkillPointView", WindowBase)
GetSkillPointView.gem_item_arr = nil

local use_num = 0
local total_num = 0
local item_id = 40011

function GetSkillPointView:init()

    ComResMgr:getInstance():loadResByName("ui/common/other.plist","ui/common/other.pvr.ccz")

	  self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	  self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/get_skill_point/get_skill_point.ExportJson")
    self.uiLayer:addWidget(self.widget)

    local cfm_btn = self.uiLayer:getWidgetByName("cfm_btn")
    cfm_btn:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
          if total_num==0 then
            Alert:show("技能符文石不足")
            return 
          end
          ItemManager:getInstance():sendItemUseReq(2,item_id, use_num, 0)
        end
    end)

    local cancel_btn = self.uiLayer:getWidgetByName("cancel_btn")
    cancel_btn:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
           WindowCtrl:getInstance():close(self.name)
        end
    end)

    local sub_btn = self.uiLayer:getWidgetByName("sub_btn")
    sub_btn:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
         if use_num>0 then
         	use_num =use_num-1
         	self:updateNumLabel()
         end
        end
    end)

    local add_btn = self.uiLayer:getWidgetByName("add_btn")
    add_btn:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
         	if use_num<total_num then
         		use_num =use_num+1
         		self:updateNumLabel()
         	end
        end
    end)

    self.num_label = tolua.cast(self.uiLayer:getWidgetByName("num_label"), "Label")
    
    self.item_icon = ItemIcon:create()
    self.item_icon:setBaseId(item_id)
    self.item_icon:setPosition(ccp(306,345))
    self.widget:addChild(self.item_icon,10)

    self._onUseItemSucs = function()
        total_num = ItemManager:getInstance():getQuantityByBaseId(item_id)
        if total_num>0 then
            use_num = 1
        else
            use_num = 0
        end
        self:updateNumLabel()
    end

end

function GetSkillPointView:create()
	local find_view = GetSkillPointView.new()
	find_view:init()
	return find_view
end

function GetSkillPointView:open()
	total_num = ItemManager:getInstance():getQuantityByBaseId(item_id)
	if total_num>0 then
		use_num = 1
	else
		use_num = 0
	end
	self:updateNumLabel()
    Notifier.regist(CmdName.UseItemSuccess,self._onUseItemSucs)
end

function GetSkillPointView:close()
	Notifier.remove(CmdName.UseItemSuccess,self._onUseItemSucs)
end

function GetSkillPointView:updateNumLabel()
	self.num_label:setText(string.format("%d/%d",use_num,total_num))
end
