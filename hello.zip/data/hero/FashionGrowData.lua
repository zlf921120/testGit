--
-- Author: lvgansheng
-- Date: 2015-04-09 23:37:01
--
FashionGrowData = class("FashionGrowData")

--时装ID
FashionGrowData.fashionId = 0
--星级
FashionGrowData.star = 0
--所需进阶物品数量
FashionGrowData.cost_item = 0
--所需金币数量
FashionGrowData.cost_coin = 0
--成长系数_1（万分比）
FashionGrowData.grow_ration_one = 0
--成长系数_2（万分比）
FashionGrowData.grow_ration_two = 0

function FashionGrowData:ctor()
    
end

function FashionGrowData:create()
    return FashionGrowData.new()
end