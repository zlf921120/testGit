--
-- Author: lvgansheng
-- Date: 2014-07-28 10:11:01
-- 宝石镶嵌界面的3个插槽
require("ItemIcon")

GemIconSlot = class("GemIconSlot",function() return Widget:create() end)
GemIconSlot.open_lev = 0 --开启按钮等级
GemIconSlot.gem_base_id = 0 --宝石数据
GemIconSlot.gem_lv_label = nil --宝石等级

local select_label 
GemIconSlot.is_open = false

function GemIconSlot:init(open_lev)

	local gem_icon_bg = ImageView:create()
	gem_icon_bg:loadTexture("normal_border_2.png", UI_TEX_TYPE_PLIST)	
	self:addChild(gem_icon_bg)

	self.item_icon = ItemIcon:create()
	self:addChild(self.item_icon)

	self.gem_lv_label = Label:create()
    self.gem_lv_label:setFontSize(22)
    self.gem_lv_label:setColor(ccc3(251, 241, 160))
    self:addChild(self.gem_lv_label)
    self.gem_lv_label:setPosition(ccp(-28,-30))

	self.open_lev = open_lev

	self.status_label = CCLabelTTF:create()
	self.status_label:setFontSize(22)
	self.status_label:setColor(ccc3(118, 88, 80))
	self:addNode(self.status_label)

	self.sub_btn = Button:create()
	self.sub_btn:setPosition(ccp(ItemIcon.icon_width/2,ItemIcon.icon_height/2))
	self.sub_btn:loadTextures("btn_up_11.png", "btn_down_11.png", "", UI_TEX_TYPE_PLIST)
	self:addChild(self.sub_btn,10)

	self.upgrade_btn = Button:create()
	self.upgrade_btn:setPosition(ccp(ItemIcon.icon_width/2,-ItemIcon.icon_height/2+10))
	self.upgrade_btn:loadTextures("btn_up_12.png", "btn_down_12.png", "", UI_TEX_TYPE_PLIST)
	self:addChild(self.upgrade_btn,11)
	
	self.attr_label = Label:create()
	self.attr_label:setText("攻擊:+50")
	self.attr_label:setPositionY(-67)
	self.attr_label:setFontSize(20)
	self.attr_label:setColor(ItemHelper.colors.yellow)
	self:addChild(self.attr_label)	

	self:setIsOpen()

	--点击减号按钮时，执行摘除操作
	self.sub_btn:addTouchEventListener(function(sender,eventType) 
		if eventType == ComConstTab.TouchEventType.ended then
			if self.gem_base_id == 0 then
				cclog("當前孔中沒有寶石")
				return
			end

			ItemManager.gem_special_slot_pos = 0

			local off_gem_req = hero_pb.hero_eqm_embed_off_req() 
			off_gem_req.hero_id = self.belong_item.hero_id
			off_gem_req.eqm_pos = self.belong_item.mode.item_type
			off_gem_req.item_id = self.belong_item.id
			off_gem_req.pos = self.slot_pos
      		ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_eqm_embed_off_req,off_gem_req)
			self.gem_base_id = 0
			cclog("點擊減號圖示")
		end	end)

	--点击合成图标时
	self.upgrade_btn:addTouchEventListener(function(sender,eventType) 
		if eventType == ComConstTab.TouchEventType.ended then
			--通知UI当前点击的是哪个宝石槽
			Notifier.dispatchCmd(CmdName.SimuClickOnGemSlot,self.slot_pos)

			--记录当前是哪个孔
			ItemManager.gem_special_slot_pos = self.slot_pos

			local upgrade_gem_req = hero_pb.hero_eqm_embed_upgrade_req() 
			upgrade_gem_req.hero_id = self.belong_item.hero_id
			upgrade_gem_req.eqm_pos = self.belong_item.mode.item_type
			upgrade_gem_req.item_id = self.belong_item.id
			upgrade_gem_req.pos = self.slot_pos
      		ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_eqm_embed_upgrade_req,upgrade_gem_req)
		
			cclog("點擊合成圖示")
		end end)
	
end

function GemIconSlot:create(open_lev,slot_pos)
	local icon_slot = GemIconSlot.new()
	icon_slot.slot_pos = slot_pos
	icon_slot:init(open_lev)
	-- icon_slot:extInit(open_lev)
	return icon_slot
end

--更新按钮状态
function GemIconSlot:updateStatus()
	local team_lv = CharacterManager:getInstance():getTeamData():getLev()
	if team_lv < self.open_lev then
		self.status_label:setString(string.format("戰隊\n%d級",self.open_lev))
	else
		self.status_label:setString("")
	end
end

--宝石数据
function GemIconSlot:setData(gem_base_id,belong_item)
	self.gem_base_id = gem_base_id
	self.item_mode = ItemManager:getInstance():getItemModelByBaseId(gem_base_id)
	if gem_base_id>0 then
		self.item_icon:setBorderVisible(true)
	else
		self.item_icon:setBorderVisible(false)
	end
	self.item_icon:setBaseId(gem_base_id)
	self.belong_item = belong_item
	if gem_base_id>0 then
		--是否有足够能量升级宝石
		if ItemManager:getInstance():isEnoughGemEnergy(gem_base_id) then
				self.upgrade_btn:setEnabled(true)

				--箭头上下运动
				self.upgrade_btn:stopAllActions()
				self.upgrade_btn:setPosition(ccp(ItemIcon.icon_width/2,-ItemIcon.icon_height/2+10))
				local act_arr = CCArray:create()
				act_arr:addObject(CCMoveBy:create(1, ccp(0, 15)))
				act_arr:addObject(CCMoveBy:create(1, ccp(0, -15)))
				local forever_seqAction = CCRepeatForever:create(CCSequence:create(act_arr))
				self.upgrade_btn:runAction(forever_seqAction)
			else
				self.upgrade_btn:stopAllActions()
				self.upgrade_btn:setEnabled(false)
			end

		self.gem_lv_label:setEnabled(true)
		self.gem_info =  ItemManager:getInstance():getGemInfo(gem_base_id)
		self.gem_lv_label:setText(string.format("lv %d",self.gem_info.gem_lev))
		self.attr_label:setVisible(true)
		local gem_info =  ItemManager:getInstance():getGemInfo(gem_base_id)
		self.attr_label:setText(string.format("%s+%d",
				AttrHelper:getAttrNameByFlag(gem_info.attr_type),gem_info.val))
	else
		self.sub_btn:setEnabled(false)
		self.upgrade_btn:setEnabled(false)
		self.gem_lv_label:setEnabled(false)
		self.upgrade_btn:stopAllActions()
		self.attr_label:setVisible(false)
	end
end

function GemIconSlot:tempIcon( gem_base_id )
	if gem_base_id>0 then
		self.item_icon:setBaseId(gem_base_id)
	else
		self.item_icon:setBaseId(0)
	end
end

function GemIconSlot:setSelect(visible)
	self.item_icon:setItemIconSelect(visible)
	if visible and self.gem_base_id>0 then 
		self.sub_btn:setEnabled(true)
	else
		self.sub_btn:setEnabled(false)
	end
end

function GemIconSlot:setIsOpen()
	local team_lv = CharacterManager:getInstance():getTeamData():getLev()
	if team_lv>= self.open_lev then
		self.is_open =  true
		self.status_label:setString("")
	else
		self.is_open = false
		self.status_label:setString(string.format("戰隊\n%d級",self.open_lev))
	end
end

function GemIconSlot:getIsOpen()
	return self.is_open
end

function GemIconSlot:playScalAction()
	local arr = CCArray:create()
	arr:addObject(CCScaleTo:create(0.3,1.5))
	arr:addObject(CCScaleTo:create(0.3,1))

	self.item_icon.icon_img:runAction(CCSequence:create(arr))
end
 
 function GemIconSlot:close()
 	self.item_icon.icon_img:stopAllActions()
 	self.upgrade_btn:stopAllActions()
 end

 function GemIconSlot:setTouchEvent(click_event)
 	self.item_icon:setTouchEvent(click_event)
 end

function GemIconSlot:getClickImg()
    return self.item_icon.icon_bg
end

function GemIconSlot:getGemLv()
	if self.gem_info then
		return self.gem_info.gem_lev
	else
		return 0
	end
end