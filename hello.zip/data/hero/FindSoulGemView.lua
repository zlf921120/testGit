--
-- Author: lvgansheng
-- Date: 2014-09-02 10:51:43
-- 寻找灵魂石的界面 


FindSoulGemView = class("FindSoulGemView", WindowBase)
FindSoulGemView.gem_item_arr = nil
FindSoulGemView.is_dispose = true
FindSoulGemView.isShowHeroView = false

function FindSoulGemView:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
    if self.heroImgView then
      self.heroImgView:close()
      self.heroImgView = nil
    end
end

function FindSoulGemView:init()

  require "HeroImgView"
  require("FindSoulGemItem")
  require("ItemIcon")

  ComResMgr:getInstance():loadRes("ui/dungeon/chapter/dgui_build.plist","ui/dungeon/chapter/dgui_build.pvr.ccz")
  ComResMgr:getInstance():loadRes("ui/activate/activate.plist","ui/activate/activate.pvr.ccz")

	self.gem_item_arr = CCArray:create()
    self.gem_item_arr:retain()

	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/find_soul_gem/find_soul_gem.ExportJson")
    self.uiLayer:addWidget(self.widget)

    local return_btn = self.uiLayer:getWidgetByName("return_btn")
    return_btn:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
           WindowCtrl:getInstance():close(self.name)
        end
    end)

    self.gem_list_view = tolua.cast(self.uiLayer:getWidgetByName("soul_gem_list_view"), "ListView")
    self.gem_list_view:setPositionX( self.gem_list_view:getPositionX()+12)

    self.soul_gem_nam_label = tolua.cast(self.uiLayer:getWidgetByName("soul_gem_nam_label"), "Label")
    self.num_label = tolua.cast(self.uiLayer:getWidgetByName("num_label"), "Label")
    
    self.panelView = tolua.cast(self.uiLayer:getWidgetByName("panel_view"),"Layout")

    self.item_icon = ItemIcon:create()
    self.item_icon:setPosition(ccp(122,463))
    self.panelView:addChild(self.item_icon)

    self.btnShow = tolua.cast(self.uiLayer:getWidgetByName("btn_show"),"Button")
    self.btnShow:addTouchEventListener(function(sender,event_type)
      if event_type == ComConstTab.TouchEventType.ended then

            self.isShowHeroView = not self.isShowHeroView
            if self.isShowHeroView then
               self:createHeroCard()
               self:playAnimRight()
               self:playAnimLeft()
               self.btnShow:setTitleText("關閉卡牌")
            else
               self:reset()
            end
        end
    end)

    --副本进度有改变，刷新界面
    self._onUpdateDungeon = function()
      self:changeContent()
    end
end

function FindSoulGemView:create()
	local find_view = FindSoulGemView.new()
	find_view:init()
	return find_view
end

function FindSoulGemView:open()
	self.hero_id = self.params
	self:changeContent()

  Notifier.regist(CmdName.DUNGEON_UPDATE_ONE_SCHEDULE,self._onUpdateDungeon)

end

function FindSoulGemView:reset()
    self.panelView:stopAllActions()
    self.panelView:setPosition(ccp(226,10))
    if self.heroImgView then
        self.heroImgView:close()
        self.heroImgView:removeFromParentAndCleanup(true)
        self.heroImgView = nil
    end

    self.btnShow:setTitleText("查看卡牌")
end

function FindSoulGemView:createHeroCard()
    if self.heroImgView == nil then
      self.heroImgView = HeroImgView:create()
      self.heroImgView:setData(self.hero_id)
      self.heroImgView:setPosition(ccp(225,58))
      self.widget:addChild(self.heroImgView,5)
    end
end

function FindSoulGemView:playAnimLeft()
    self.panelView:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCMoveTo:create(0.4,ccp(45,10)))
    self.panelView:runAction(CCSequence:create(arr))
end

function FindSoulGemView:playAnimRight()
   self.heroImgView:stopAllActions()
   local arr = CCArray:create()
    arr:addObject(CCMoveTo:create(0.4,ccp(550,58)))
    self.heroImgView:runAction(CCSequence:create(arr))
end

function FindSoulGemView:close()
	 Notifier.remove(CmdName.DUNGEON_UPDATE_ONE_SCHEDULE,self._onUpdateDungeon)

    if self.heroImgView then
        self.heroImgView:close()
        self.heroImgView = nil
    end
end

function FindSoulGemView:changeContent()

	local hero_info = HeroManager:getInstance():getHeroInfoByBaseId(self.hero_id)
	local item_mode = ItemManager:getInstance():getItemModelByBaseId(hero_info.soul_gem_id)
	local item_quantity = ItemManager:getInstance():getQuantityByBaseId(hero_info.soul_gem_id)
	local upgrade_cost_one = HeroManager:getInstance():getUpgradeCost(hero_info.cur_stars+1)

	self.soul_gem_nam_label:setText(item_mode.name)

  if upgrade_cost_one then
	   self.num_label:setText(string.format("(%d/%d)",item_quantity,upgrade_cost_one.soul_gem or 0))
  else
     self.num_label:setText("英雄已經最高階")
  end

	self.item_icon:setBaseId(item_mode.base_id)

	local tempChildArr = self.gem_list_view:getChildren()
	self.gem_item_arr:addObjectsFromArray(tempChildArr)
	self.gem_list_view:removeAllItems()

  local team_lv = CharacterManager:getInstance():getTeamData():getLev()
  local soul_stone_guide_list = HeroManager:getInstance():getSoulStoneGuideInfos(hero_info.base_id, team_lv)
  local num = #soul_stone_guide_list 
  local temp_item = nil
  for i=1,num do
      temp_item = self.gem_item_arr:lastObject()
     if temp_item == nil then
         temp_item = FindSoulGemItem:create()
     else
         self.gem_item_arr:removeObject(temp_item,false) 
     end
     temp_item:setData(soul_stone_guide_list[i])
    self.gem_list_view:pushBackCustomItem(temp_item) 
  end  


end
