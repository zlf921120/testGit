--
-- Author: lvgansheng 
-- Date: 2014-06-18 17:45:57
-- 卡牌图鉴界面 

HeroImgView =  class("HeroImgView",WidgetBase)
HeroImgView.uiLayer = nil
HeroImgView.widget = nil
HeroImgView.enterFun = nil 
HeroImgView.exitFun = nil
HeroImgView._isFull = false --是否全屏卡牌

local cur_path = nil
local img_path = nil

function HeroImgView:init()

    require("SkillIcon")

	self:setPositionX(32)
    
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/hero_img/hero_img.ExportJson")
    self:addChild(self.widget)
    -- self.widget:setPosition(ccp(5,7))

    --ComResMgr:getInstance():loadResByName("ui/hero/hero_img.plist","ui/hero/hero_img.png")

    self.hero_img = tolua.cast(self.widget:getChildByName("hero_img"), "ImageView")
    -- self.hero_img:setPositionX( self.hero_img:getPositionX()+2)
    -- self.hero_img:setPositionY( self.hero_img:getPositionY()-2)

    self.skill_icons = {}
    
    local skill_1 = SkillIcon:create()
    self.widget:addChild(skill_1,5)
    skill_1:setPosition(ccp(320,115))
    self.skill_icons[1] = skill_1

    local skill_2 = SkillIcon:create()
    self.widget:addChild(skill_2,5)
    skill_2:setPosition(ccp(430,115))
    self.skill_icons[2] = skill_2

    local skill_3 = SkillIcon:create()
    self.widget:addChild(skill_3,5)
    skill_3:setPosition(ccp(540,115))
    self.skill_icons[3] = skill_3

    for i=1,#self.skill_icons do
        local icon = self.skill_icons[i]
        icon:setClickEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.ended then
                local skillVo = SkillManager:getInstance():getSkillData(icon.id,icon.lev,3)
                if self._isFull then
                    Alert:show( skillVo:getAlertDesc() or "",ccc3(251,241,160),-90 )
                else
                    Alert:show( skillVo:getAlertDesc() or "",ccc3(251,241,160) )
                end
            end
        end)
    end

    self.star_icons = {}
    local temp_star = nil
    local star_name = nil 
    for i=1,5 do
        star_name = string.format("star_%d",i)
        temp_star = tolua.cast(self.widget:getChildByName(star_name), "ImageView")
        self.star_icons[i] = temp_star
    end

    self.widget:setScale(0.56)
end

function HeroImgView:create()
	local img_view = HeroImgView.new()
	img_view:init()
	return img_view	
end

function HeroImgView:setFull(b)
    self._isFull = b
end

function HeroImgView:setData(hero_id, ext_stars)
    self.hero_id = hero_id
    local hero_info = HeroManager:getInstance():getHeroInfoByBaseId(hero_id)

    local hero_stars = ext_stars or hero_info.cur_stars

    if hero_stars == 0 then
        hero_stars = hero_info.init_stars
    end

    local star_path = HeroHelper.getStarResPath(hero_stars)
    for i=1,5 do
        if hero_stars>=i then
            self.star_icons[i]:setVisible(true)
            self.star_icons[i]:loadTexture(star_path, UI_TEX_TYPE_PLIST)
        else
            self.star_icons[i]:setVisible(false)
        end 
    end

    --设置技能图标
    local temp_skill_icon = nil
    for i=1,3 do
        temp_skill_icon = self.skill_icons[i]
        temp_skill_icon:setSkillId(hero_info.default_skills[i].skill_id)
        temp_skill_icon:setSkillLev(hero_info.default_skills[i].skill_lev)

    end

    --设置图片
    --清空旧的图片
    local old_path = cur_path
    local ext_suf = ""
    if hero_id==HeroManager.LEADING_HERO_ID then
        if CharacterManager:getInstance():getBaseData():getSex() == Helper.sex.male then
            ext_suf = "_m"
        else
            ext_suf = "_f"
        end
    end

    cur_path = string.format("ui/hero/card/i18n_hero_img_%d%s.plist",hero_info.img_res_id, ext_suf)
    img_path = string.format("ui/hero/card/i18n_hero_img_%d%s.pvr.ccz",hero_info.img_res_id, ext_suf)
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile(cur_path,img_path)
    self.hero_img:loadTexture(string.format("i18n_hero_img_%d%s.png",hero_info.img_res_id, ext_suf), UI_TEX_TYPE_PLIST) 

    if old_path then
        CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile(old_path)
        ComResMgr:getInstance():clearCache()
    end

    --设置边框等
    local hero_border =  tolua.cast(self.widget:getChildByName("hero_img_border"), "ImageView")
    img_path = string.format("hero_img_border_%d.png",hero_stars)
    -- ComResMgr:getInstance():loadResByName("ui/hero/hero_img.plist","ui/hero/hero_img.png")
    hero_border:loadTexture(img_path, UI_TEX_TYPE_PLIST)   

    local hero_img_front_bg =  tolua.cast(self.widget:getChildByName("hero_img_front_bg"), "ImageView")
    img_path = string.format("hero_img_front_bg_%d.png",hero_stars)
    hero_img_front_bg:loadTexture(img_path, UI_TEX_TYPE_PLIST) 
    hero_img_front_bg:setVisible(false)
end

function HeroImgView:setClickHandler(func)
    self.widget:setTouchEnabled(true)
    self.widget:addTouchEventListener(func)
end

function HeroImgView:getClickWidget()
    return self.widget
end

function HeroImgView:setAnchorPoint(pos)
    self.widget:setAnchorPoint(pos)
end

function HeroImgView:setScale(value)
    self.widget:setScale(value)
end

function HeroImgView:close()
     if cur_path then
        self.hero_img:loadTexture("hero_img_front_bg_1.png",UI_TEX_TYPE_PLIST)
        CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile(cur_path)
    end    
end