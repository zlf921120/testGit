--
-- Author: thisgf
-- Date: 2015-04-09 20:54:55
-- 英雄时装数据

HeroFashionData = class("HeroFashionData")

--英雄ID
HeroFashionData.heroId = 0
--性别
HeroFashionData.sex = 0
--时装ID
HeroFashionData.fashionId = 0
--动作ID
HeroFashionData.actionId = 0
--星级
HeroFashionData.star = 0
--物品id
HeroFashionData.baseId = 0

HeroFashionData._attrs = nil

HeroFashionData.pos = 0

function  HeroFashionData:ctor()
    self._attrs = {}
end

function HeroFashionData:create()
    return HeroFashionData.new()
end

function HeroFashionData:setOneAttr(attr_key,attr_value)
	 self._attrs[attr_key] = attr_value
end

function HeroFashionData:getAttr()
	return self._attrs
end

function HeroFashionData:getAttrKeys()
	local ret = {}
	for k,v in pairs(self._attrs) do
		if v > 0 then
			table.insert(ret,k)
		end
	end
	table.sort( ret )
	return ret
end