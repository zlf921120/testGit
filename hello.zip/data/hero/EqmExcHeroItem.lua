--
-- Author: lvgansheng
-- Date: 2014-11-18 15:28:25
-- 锻造物品选择页单个英雄装备汇总

EqmExcHeroItem = class("EqmExcHeroItem", DisplayUtil.newLayout)

EqmExcHeroItem.eqm_item_list = nil
EqmExcHeroItem.exch_item_2_item_id = nil
EqmExcHeroItem.exch_item_2_baseid = nil

EqmExcHeroItem.item_height = 65

EqmExcHeroItem.gem_suit_lv = 0
EqmExcHeroItem.gem_count = 0

local gem_suit_effect_path = "ui/effects_ui/baoshitao/baoshitao.ExportJson"
local gem_suit_effect_tag = 1211

local enchant_suit_effect_path = "ui/effects_ui/fumotao/fumotao.ExportJson"
local enchant_suit_effect_tag = 1212

function EqmExcHeroItem:init()
	self.bg_img = ImageView:create()
    self.bg_img:loadTexture("bg_light_1.png",UI_TEX_TYPE_PLIST)
    self.bg_img:setScaleX(8.41)
    self.bg_img:setScaleY(1.24)
    -- self.bg_img:setContentSize(CCSize(400,100))
    self.bg_img:setAnchorPoint(ccp(0,1))
    self:addChild(self.bg_img) 

    self.exch_item_2_item_id = {}
    self.exch_item_2_baseid = {}

    self.conent_layer = DisplayUtil.newLayout()
    self.conent_layer:setScaleX(1/8.41)
    self.conent_layer:setScaleY(1/1.24)
    self.bg_img:addChild(self.conent_layer)
    
    self.head_icon = HeadIcon:create(2)
    self.head_icon:setPosition(ccp(30, -30))
    self.head_icon:setScale(0.5)
    self.conent_layer:addChild(self.head_icon)

    self.hero_pos_img =  ImageView:create()
    self.hero_pos_img:setPosition(ccp(80,-30))
    self.conent_layer:addChild(self.hero_pos_img) 

    self.hero_name = Label:create()
    self.hero_name:setFontSize(22)
    self.hero_name:setColor(ItemHelper.colors.deep_yellow)
    self.hero_name:setAnchorPoint(ccp(0,0.5)) 
    self.hero_name:setPosition(ccp(110,-30))
    self.conent_layer:addChild(self.hero_name)
--宝石套 
    self.gem_suit_panel = DisplayUtil.newLayout()
    self.gem_suit_panel:setPosition(ccp(290,-30))
    self.conent_layer:addChild(self.gem_suit_panel)

    self.gem_suit_effect = EffectManager:getInstance():createUIAnimate("baoshitao")
    self.gem_suit_effect:setTag(gem_suit_effect_tag) 
    self.gem_suit_panel:addNode(self.gem_suit_effect)
    
    self.gem_suit_label = Label:create()
    self.gem_suit_label:setFontSize(22)
    self.gem_suit_label:setTouchEnabled(true)
    self.gem_suit_label:ignoreContentAdaptWithSize(false)
    self.gem_suit_label:setSize(CCSize(50,50))
    self.gem_suit_label:setTextHorizontalAlignment(kCCTextAlignmentCenter)
    self.gem_suit_label:setTextVerticalAlignment(kCCVerticalTextAlignmentCenter)
    self.gem_suit_label:setAnchorPoint(ccp(0.5,0.5)) 
    -- self.hero_name:setPosition(ccp(110,-30))
    -- self.gem_suit_label:setText("10")
    self.gem_suit_panel:addChild(self.gem_suit_label)
    self.gem_suit_label:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.GemSuitDetailView,
              {min_gem_lv=self.gem_suit_lv, gem_count=self.gem_count})
        end
    end)

--附魔套 
    self.enchant_suit_panel = DisplayUtil.newLayout()
    self.enchant_suit_panel:setPosition(ccp(290+50,-30))
    self.conent_layer:addChild(self.enchant_suit_panel)

    self.enchant_suit_effect = EffectManager:getInstance():createUIAnimate("fumotao")
    self.enchant_suit_effect:setTag(enchant_suit_effect_tag) 
    self.enchant_suit_panel:addNode(self.enchant_suit_effect)
    
    self.enchant_suit_label = Label:create()
    self.enchant_suit_label:setFontSize(22)
    self.enchant_suit_label:setTouchEnabled(true)
    self.enchant_suit_label:ignoreContentAdaptWithSize(false)
    self.enchant_suit_label:setSize(CCSize(50,50))
    self.enchant_suit_label:setTextHorizontalAlignment(kCCTextAlignmentCenter)
    self.enchant_suit_label:setTextVerticalAlignment(kCCVerticalTextAlignmentCenter)
    self.enchant_suit_label:setAnchorPoint(ccp(0.5,0.5)) 

    self.enchant_suit_panel:addChild(self.enchant_suit_label)
    self.enchant_suit_label:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.EnchantSuitDesc,
              {equipListVo= HeroManager:getInstance():getBattleHeroEqmList(self.hero_id)})
        end
    end)

    self.eqm_item_list = {}
  --   self.item_layer = DisplayUtil.newLayout()
 	-- self.item_layer:setPosition(ccp(0,-62))
  --   self.conent_layer:addChild(self.item_layer)

  --   local eqm_item_one = nil
  --   for i=1,8 do  
  --   	eqm_item_one = EqmExchItem:create(EqmExchView.widget_seed)
  --   	eqm_item_one:setPosition(ccp(323*((i-1)%2),math.floor((i-1)/2)*-138))
  --   	eqm_item_one:retain()
  --   	self.eqm_item_list[i] =  eqm_item_one
  --   end
end

function EqmExcHeroItem:create()
	local exc_hero_item = EqmExcHeroItem.new()
	exc_hero_item:init()
	return exc_hero_item
end

function EqmExcHeroItem:setHeroId(hero_id, pos_type, view_type)
	self.hero_id = hero_id
	self.hero_info = HeroManager:getInstance():getHeroInfoByBaseId(hero_id)
	self.pos_type = self.hero_info.pos
	self.view_type = view_type
	-- self.item_layer:removeAllChildren()

	self.hero_pos_img:loadTexture(ItemHelper:getHeroPosImgName(self.hero_info.pos),UI_TEX_TYPE_PLIST)
	self.head_icon:setFaceId(self.hero_id)
	self.hero_name:setText(self.hero_info.name.."裝備")

	local eqms = HeroManager:getInstance():getBattleHeroEqmList(self.hero_id)
	local eqm_vo = nil

	local eqm_list = eqms:getEquipList()
	local eqms_count = #eqm_list
	local eqm_item_one = nil
	local eqm_vo = nil
	local eqm_num = 0
	-- for location,eqm_vo in pairs(eqm_list) do
	-- 	if eqm_vo and eqm_vo.item then
	-- 		eqm_num =eqm_num+1
	-- 		eqm_item_one = self.eqm_item_list[eqm_num]
	-- 		eqm_item_one:setData(eqm_vo.item, self.hero_info.pos, self.view_type)
	-- 		self.item_layer:addChild(eqm_item_one)
 --            self.exch_item_2_item_id[eqm_vo.item.id] = eqm_item_one
 --            self.exch_item_2_baseid[eqm_vo.item.mode.base_id] = eqm_item_one
	-- 	end
	-- end

	-- local temp_height = math.ceil(eqm_num/2)*138+78
	-- self:setSize(CCSize(635,temp_height))
	self.bg_img:setPositionY(self.item_height)
    -- cclog("每個的高度~~~~")

  --宝石套图标
  self.gem_suit_lv,self.gem_count =  eqms:getGemSuitLv()
  if self.gem_suit_lv>=HeroManager.MIN_GEM_LV_FOR_SUIT then
    -- self.gem_suit_icon:loadTexture(self:getGemSuitIconPath(self.gem_suit_lv), UI_TEX_TYPE_PLIST)
    self.gem_suit_effect:getAnimation():play(self:getGemSuitIconPath(self.gem_suit_lv))
    self.gem_suit_label:setText(self.gem_suit_lv)
  else
    self.gem_suit_effect:getAnimation():play("grey")
    self.gem_suit_label:setText("5")
  end

  local lv,progress = eqms:getEnchantSuitLv()
  if lv >= HeroManager.MIN_ENCHANT_LV_FOR_SUIT then
      self.enchant_suit_effect:getAnimation():play(self:getEnchantSuitIconPath(lv))
      self.enchant_suit_label:setText(lv)
  else
      self.enchant_suit_effect:getAnimation():play("grey")
      self.enchant_suit_label:setText(HeroManager.MIN_ENCHANT_LV_FOR_SUIT)
  end
end

function EqmExcHeroItem:getGemSuitIconPath(gem_suit_lv)
  if gem_suit_lv<HeroManager.MIN_GEM_LV_FOR_SUIT then
    return "grey"
  elseif gem_suit_lv<7 then
    return "green"
  elseif gem_suit_lv<10 then
    return "blue"
  elseif gem_suit_lv<16 then
    return "purple"
  else
    return "orange"  
  end
end

function EqmExcHeroItem:getEnchantSuitIconPath(lv)
  if lv<HeroManager.MIN_ENCHANT_LV_FOR_SUIT then
    return "grey"
  elseif lv<6 then
    return "green"
  elseif lv<9 then
    return "blue"
  elseif lv<12 then
    return "purple"
  else
    return "orange"  
  end
end

function EqmExcHeroItem:refresh(item_id)
    local eqm_item_one =  self.exch_item_2_item_id[item_id]
    if eqm_item_one then
        eqm_item_one:refreseh()
    end
end

function EqmExcHeroItem:getEqmItemList()
  return self.eqm_item_list
end

function EqmExcHeroItem:setRealPos(real_pos)

  self:setPosition(real_pos)

    -- local eqm_item_one = nil
    -- for i=1,8 do  
    --  eqm_item_one = EqmExchItem:create(EqmExchView.widget_seed)
    --  eqm_item_one:setPosition(ccp(323*((i-1)%2),math.floor((i-1)/2)*-138))
    --  eqm_item_one:retain()
    --  self.eqm_item_list[i] =  eqm_item_one
    -- end
end

function EqmExcHeroItem:setExcItem(idx, one_exc_item)
  self.eqm_item_list[idx] = one_exc_item
end

function EqmExcHeroItem:getExcItemByIdx(idx)
  return  self.eqm_item_list[idx]
end

function EqmExcHeroItem:getExcItemByItemBaseId(base_id)
  for i,v in pairs(self.eqm_item_list) do
    if v:getItemBaseId() == base_id then
      return v
    end
  end
end