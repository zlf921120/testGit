--
-- Author: lvgansehng
-- Date: 2014-06-14 15:05:07
-- 装备信息

EquipVo = class("EquipVo")

EquipVo.location = 0 --装备部位
EquipVo.item = nil --装备的详细信息

function EquipVo:setInfo( location,item )
	self.location = location
	self.item = item
end

function EquipVo:setItem( item )
	self.item = item
end
