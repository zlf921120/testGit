--
-- Author: lvgansheng
-- Date: 2015-05-06 17:45:35
-- 宝石套详细信息界面

GemSuitDetailView = class("GemSuitDetailView",WindowBase)
GemSuitDetailView.is_dispose = true

local __instance = nil

function GemSuitDetailView:create()
    local ret = GemSuitDetailView.new()
    __instance = ret
    return ret   
end

function GemSuitDetailView:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end


function GemSuitDetailView:init()
    ComResMgr:getInstance():loadResByName("ui/hero/hero.plist","ui/hero/hero.pvr.ccz")

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/equip/gem_suit_detail/gem_suit_detail.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self._widget:setTouchEnabled(true)
    self._widget:setSize(CCSize(960,640))
    self._widget:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    for i=1,4 do
        self["lab_attr"..i] = tolua.cast(self._widget:getChildByName("lab_attr"..i),"Label")
        self["lab_attr_v"..i] = tolua.cast(self._widget:getChildByName("lab_attr_v"..i),"Label")
        self["lab_after_attr"..i] = tolua.cast(self._widget:getChildByName("lab_after_attr"..i),"Label")
        self["lab_after_attr_v"..i] = tolua.cast(self._widget:getChildByName("lab_after_attr_v"..i),"Label")
        self["img_attr"..i] = tolua.cast(self.uiLayer:getWidgetByName("img_attr"..i),"ImageView")
        self["img_after_attr"..i] = tolua.cast(self.uiLayer:getWidgetByName("img_after_attr"..i),"ImageView")
    end

    self.cur_lev_label = tolua.cast(self._widget:getChildByName("cur_lev_label"),"Label")
    self.next_lv_label = tolua.cast(self._widget:getChildByName("next_lv_label"),"Label")
    self.next_lv_label_y = self.next_lv_label:getPositionY()
    -- cclog("self.next_lv_label_y=%s",self.next_lv_label_y)
    -- cclog("self.next_lv_label_y=%s",self.next_lv_label_y)
    -- cclog("self.next_lv_label_y=%s",self.next_lv_label_y)
    -- cclog("self.next_lv_label_y=%s",self.next_lv_label_y)
    -- cclog("self.next_lv_label_y=%s",self.next_lv_label_y)
    -- cclog("self.next_lv_label_y=%s",self.next_lv_label_y)
    self.gem_suit_lv_label = tolua.cast(self._widget:getChildByName("gem_suit_lv_label"),"Label")
    self.gem_suit_prog_label = tolua.cast(self._widget:getChildByName("gem_suit_prog_label"),"Label")
    
    self.cur_add_num_img = LabelAtlas:create()
    self.cur_add_num_img:setProperty(0000,"ui/digit/suit_num1.png",35,43,"0")
    self.cur_add_num_img:setStringValue(35)
    self.cur_add_num_img:setPosition(ccp(249,362))
    self._widget:addChild(self.cur_add_num_img)

    self.next_add_num_img = LabelAtlas:create()
    self.next_add_num_img:setProperty(0000,"ui/digit/suit_num2.png",35,43,"0")
    self.next_add_num_img:setStringValue(35)
    self.next_add_num_img:setPosition(ccp(705,366))
    self._widget:addChild(self.next_add_num_img)

    self.gem_suit_prog_bar = tolua.cast(self._widget:getChildByName("gem_suit_prog_bar"), "LoadingBar")

    self.next_add_img = self._widget:getChildByName("next_add_img")
    self.labTips = self._widget:getChildByName("lab_tips")
end

function GemSuitDetailView:open()
    local params = self.params
    self:changeInfo()
    -- print(params["min_gem_lv"], params["gem_count"])
end

function GemSuitDetailView:changeInfo()
    self.cur_lev_label:setText(string.format("%d級寶石套",self.params["min_gem_lv"]))
    local gem_suit_ratio = ItemManager:getInstance():getGemSuitRationByLv(self.params["min_gem_lv"])*100
    self.cur_add_num_img:setStringValue(gem_suit_ratio)
    -- self.gem_suit_lv_label:setText(self.params["gem_suit_lv_txt"])
    self.labTips:setVisible(false)
    if self.params["min_gem_lv"]==0 then
      self.gem_suit_lv_label:setText(string.format("%d級寶石套進度：",5))
      self.labTips:setVisible(true)
    elseif self.params["min_gem_lv"]==HeroManager.MAX_GEM_LV_FOR_SUIT then
      self.gem_suit_lv_label:setText(string.format("%d級寶石套進度：", HeroManager.MAX_GEM_LV_FOR_SUIT))
    else
      self.gem_suit_lv_label:setText(string.format("%d級寶石套進度：",self.params["min_gem_lv"]+1))
    end

    self.gem_suit_prog_label:setText(string.format("%d/%d", self.params["gem_count"],HeroManager.TOTAL_GEM_COUNT))
    self.gem_suit_prog_bar:setPercent(self.params["gem_count"]/HeroManager.TOTAL_GEM_COUNT*100)

    for i=1,4 do
        self["lab_attr"..i]:setVisible(false)
        self["lab_attr_v"..i]:setVisible(false)
        self["lab_after_attr"..i]:setVisible(false)
        self["lab_after_attr_v"..i]:setVisible(false)
        self["img_attr"..i]:setVisible(false)
        self["img_after_attr"..i]:setVisible(false)
    end

    local attrs = ItemManager:getInstance():getGemSuitAttr(self.params["min_gem_lv"])
    local i = 0
    if attrs then
        for k,v in pairs(attrs) do
            i = i + 1
            self["lab_attr"..i]:setVisible(true)
            self["lab_attr"..i]:setText(AttrHelper:getAttrNameByFlag(k))
            self["lab_attr_v"..i]:setVisible(true)
            self["lab_attr_v"..i]:setText(v)
            self["img_attr"..i]:setVisible(true)
            self["img_attr"..i]:loadTexture(string.format("%s.png",AttrHelper:getAttrImgName(k)),UI_TEX_TYPE_PLIST)
        end
    end

    --如果当前已经到了最高级别
    if self.params["min_gem_lv"] >= HeroManager.MAX_GEM_LV_FOR_SUIT then
        self.next_lv_label:setText("當前已經是\n最高等級")
        self.next_lv_label:setPositionY(self.next_lv_label_y-60)
        self.next_add_num_img:setVisible(false)
        self.next_add_img:setVisible(false)
        self.gem_suit_prog_label:setText(string.format("%d/%d",HeroManager.TOTAL_GEM_COUNT,HeroManager.TOTAL_GEM_COUNT))
        self.gem_suit_prog_bar:setPercent(100)

    elseif self.params["min_gem_lv"] < HeroManager.MIN_GEM_LV_FOR_SUIT then

        local next_gem_suit_ratio = ItemManager:getInstance():getGemSuitRationByLv(HeroManager.MIN_GEM_LV_FOR_SUIT)*100
        self.next_add_num_img:setStringValue(next_gem_suit_ratio)

        attrs = ItemManager:getInstance():getGemSuitAttr(HeroManager.MIN_GEM_LV_FOR_SUIT)
        if attrs then
            i = 0
            for k,v in pairs(attrs) do
                i = i + 1
                self["lab_after_attr"..i]:setVisible(true)
                self["lab_after_attr"..i]:setText(AttrHelper:getAttrNameByFlag(k))
                self["lab_after_attr_v"..i]:setVisible(true)
                self["lab_after_attr_v"..i]:setText(v)
                self["img_after_attr"..i]:setVisible(true)
                self["img_after_attr"..i]:loadTexture(string.format("%s.png",AttrHelper:getAttrImgName(k)),UI_TEX_TYPE_PLIST)
            end
        end

    elseif self.params["min_gem_lv"] >= HeroManager.MIN_GEM_LV_FOR_SUIT and self.params["min_gem_lv"] < HeroManager.MAX_GEM_LV_FOR_SUIT then
        self.next_lv_label:setPositionY(self.next_lv_label_y)
        self.next_add_num_img:setVisible(true)
        self.next_add_img:setVisible(true)
        local next_gem_lv = self.params["min_gem_lv"]+1
        if self.params["min_gem_lv"]==0 then
            next_gem_lv = HeroManager.MIN_GEM_LV_FOR_SUIT
        end
        self.next_lv_label:setText(string.format("%d級寶石套",next_gem_lv))
        local next_gem_suit_ratio = ItemManager:getInstance():getGemSuitRationByLv(next_gem_lv)*100
        self.next_add_num_img:setStringValue(next_gem_suit_ratio)

        attrs = ItemManager:getInstance():getGemSuitAttr(self.params["min_gem_lv"] + 1)
        if attrs then
            i = 0
            for k,v in pairs(attrs) do
                i = i + 1
                self["lab_after_attr"..i]:setVisible(true)
                self["lab_after_attr"..i]:setText(AttrHelper:getAttrNameByFlag(k))
                self["lab_after_attr_v"..i]:setVisible(true)
                self["lab_after_attr_v"..i]:setText(v)
                self["img_after_attr"..i]:setVisible(true)
                self["img_after_attr"..i]:loadTexture(string.format("%s.png",AttrHelper:getAttrImgName(k)),UI_TEX_TYPE_PLIST)
            end
        end
    end
end