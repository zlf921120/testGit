--
-- Author: lvgansheng
-- Date: 2014-11-19 17:07:11
-- 批量强化界面

EqmBatchPoweredView = class("EqmBatchPoweredView", WindowBase)

local cur_powered_lv = 1
function EqmBatchPoweredView:init()
	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/equip/batch_powered/batch_powered.ExportJson")
    self.uiLayer:addWidget(self.widget)

    local cancel_btn = self.uiLayer:getWidgetByName("cancel_btn")
    local cfm_btn = self.uiLayer:getWidgetByName("cfm_btn")
    local sub_btn = self.uiLayer:getWidgetByName("sub_btn")
    local add_btn = self.uiLayer:getWidgetByName("add_btn")
    local max_btn = self.uiLayer:getWidgetByName("max_btn")
    self.num_label = tolua.cast(self.uiLayer:getWidgetByName("num_label"), "Label") 
    self.cos_label = tolua.cast(self.uiLayer:getWidgetByName("cos_label"), "Label") 

    cancel_btn:addTouchEventListener(function(sender, eventType) 
    	if eventType == ComConstTab.TouchEventType.ended then
           WindowCtrl:getInstance():close(self.name)
        end
    end)

    cfm_btn:addTouchEventListener(function(sender, eventType) 
    	if eventType == ComConstTab.TouchEventType.ended then
          if self.cos_label:getStringValue()=="0" then
            Alert:show(string.format("您的裝備均已強化至%d級，不需要再強化哦。",cur_powered_lv))
          else
            ItemManager:getInstance():sendBatchPoweredReq(cur_powered_lv)
          end
        end
    end)  

    sub_btn:addTouchEventListener(function(sender, eventType) 
    	if eventType == ComConstTab.TouchEventType.ended then
          if cur_powered_lv>1 then
          	cur_powered_lv = cur_powered_lv - 1
          	self.num_label:setText(cur_powered_lv)
             self:updateCostLabel()
          end
        end
    end)

    add_btn:addTouchEventListener(function(sender, eventType) 
      if eventType == ComConstTab.TouchEventType.ended then
          if cur_powered_lv<CharacterManager:getInstance():getTeamData():getLev() then
            cur_powered_lv = cur_powered_lv + 1
            self.num_label:setText(cur_powered_lv)
             self:updateCostLabel()
          else
            Alert:show("裝備強化等級不能超過戰隊等級哦")
          end
        end
    end)   

    max_btn:addTouchEventListener(function(sender, eventType) 
    	if eventType == ComConstTab.TouchEventType.ended then
          	local tm_lv = CharacterManager:getInstance():getTeamData():getLev()
            local all_cost = 0
            cur_powered_lv,all_cost =  ItemManager:getInstance():getFitMoneyPowered(tm_lv)

            local mini_powered_lv = ItemManager:getInstance():getFitEqmToPowered().powered_lev
            if cur_powered_lv==mini_powered_lv then
              cur_powered_lv = mini_powered_lv
              all_cost = 0
            end

            self.num_label:setText(cur_powered_lv)
            self.cos_label:setColor(ItemHelper.colors.yellow)
            self.cos_label:setText(all_cost)

      end
    end)
end

function EqmBatchPoweredView:create()
	local batch_view = EqmBatchPoweredView.new()
	return batch_view
end

function EqmBatchPoweredView:open()
  local mini_powered_lv = ItemManager:getInstance():getFitEqmToPowered().powered_lev
	cur_powered_lv=CharacterManager:getInstance():getTeamData():getLev()
  if cur_powered_lv>=mini_powered_lv+1 then
    cur_powered_lv = mini_powered_lv+1
  end
	self.num_label:setText(cur_powered_lv)
  self:updateCostLabel()
end

function EqmBatchPoweredView:updateCostLabel()
  local all_cost = ItemManager:getInstance():getAllEqmPoweredCost(cur_powered_lv)
  if CharacterManager:getInstance():getAssetData():getGold()<all_cost then
     self.cos_label:setColor(ItemHelper.colors.red)
  else
    self.cos_label:setColor(ItemHelper.colors.yellow)
  end

  self.cos_label:setText(all_cost)
end