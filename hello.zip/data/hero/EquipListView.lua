--
-- Author: lvgansheng
-- Date: 2014-06-12 16:22:18
-- 可装备的物品筛选界面


EquipListView = class("EquipListView",WidgetBase)
EquipListView.uiLayer = nil
EquipListView.widget = nil
EquipListView._index = EquipListView
EquipListView.enterFun = nil --窗体被显示时需要执行的方法
EquipListView.exitFun = nil --被移除时需要执行的方法
EquipListView.itemArr = nil
EquipListView.listview = nil
EquipListView.cur_hero_id = 0 --当前的英雄ID
EquipListView.location = 0 -- 当前要筛选的装备类型
EquipListView.limitStand = 0 --英雄站位

local cur_idx = 1

local is_show_green_bg = false

function EquipListView:init()

  require("EquipListOneItem")

	self.itemArr = CCArray:create()
	self.itemArr:retain()

  self:setPositionX(32)
        
  self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/eqm_list_view/eqm_list_view.ExportJson")
  self:addChild(self.widget)

  self.list_item_widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/equip_list_item/equip_list_item.ExportJson")
  self.list_item_widget:retain()

  local widget_size = self.widget:getSize()


  self.tips_label = Label:create()
  self.tips_label:setFontSize(22)
  self.tips_label:setColor(ItemHelper.colors.yellow)
  self.tips_label:setText("【沒有可裝備的物品】")
  self.tips_label:setPosition(ccp(widget_size.width/2,widget_size.height/2))
  self.tips_label:setVisible(false)
  self.widget:addChild(self.tips_label)

  self.listview = self.widget:getChildByName("eqm_list")
  tolua.cast(self.listview, "ListView")
  self.listview:setItemsMargin(5)
  self.listview:setClippingEnabled(true)	

    -- --新手引导
    -- Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function EquipListView:create()
	local widget = EquipListView.new()
	widget:init()
	return widget
end

function EquipListView:setItemList(itemList,location)
    local tempChildArr = self.listview:getChildren()
    self.itemArr:addObjectsFromArray(tempChildArr)

      self.listview:removeAllItems()

      local function btnClick(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
             local tempListItem = self.listview:getItem(self.listview:getCurSelectedIndex())
             local param = {}
            
             --Notifier.dispatchCmd(CmdName.EqmOnConfirmView,param)
             --打开是否装备的确认界面
             if self.cur_hero_id == tempListItem.item.hero_id then --如果点击的是自己身上的装备，则返回装备详细属性界面
               param[1] =  HeroHelper.leftPanelType.equipAttrView
               param[2] = {tempListItem.item, tempListItem.location}
               Notifier.dispatchCmd(CmdName.CtrlRoleLeftPanel,param)
             else
              if tempListItem.item.mode.limit_lev>CharacterManager:getInstance():getTeamData():getLev() then
                Alert:show(string.format("您的戰隊等級未滿%d級，努力升級哦。",tempListItem.item.mode.limit_lev))
                return
              end

               param.hero_id = self.cur_hero_id
               param.item = tempListItem.item
               param.location = tempListItem.location
               WindowCtrl:getInstance():open(CmdName.EqmOnConfirmView, param)

                --新手引导事件
                if GuideDataProxy:getInstance().nowMainTutroialEventId == 10105 or
                   GuideDataProxy:getInstance().nowMainTutroialEventId == 10610 then
                    Notifier.dispatchCmd(GuideEvent.StepFinish,"click_eqm")
                end
             end
        end
    end

    local custom_button

   -- if EquipListOneItem.widget_clone == nil then
   --     EquipListOneItem.widget_clone = GUIReader:shareReader():widgetFromJsonFile("ui/hero/equip_list_item/equip_list_item.ExportJson")
  --  end

    local temp_widget_clone = self.widget_clone
    local function eqm_list_step_add()

      local temp_idx = cur_idx
      for i= temp_idx,#itemList do
        custom_button = self.itemArr:lastObject()
        if custom_button == nil then
            custom_button = EquipListOneItem:create(self.list_item_widget)
            custom_button:setClickItem(btnClick)
        else
            self.itemArr:removeObject(custom_button,false) 
        end

        if cur_idx==1 and is_show_green_bg then
          custom_button:setGreenBgVisible(true)
        else
          custom_button:setGreenBgVisible(false)
        end

        custom_button:setItem(itemList[i], location, self.cur_hero_id)
        self.listview:pushBackCustomItem(custom_button)
       
        cur_idx = cur_idx +1
        if cur_idx - temp_idx>10 then
          break
        end
      end

      if cur_idx>#itemList then
        TimerManager.removeTimer(eqm_list_step_add)
        cur_idx = 1
            --新手引导事件
            if ItemHelper.itemType.Weapon == location then
                if GuideDataProxy:getInstance().nowMainTutroialEventId == 10104 then
                    Notifier.dispatchCmd(GuideEvent.StepFinish,"click_eqmgrid")
                end
                if GuideDataProxy:getInstance().nowMainTutroialEventId == 10609 then
                    Notifier.dispatchCmd(GuideEvent.StepFinish,"click_eqmex")
                end
            end
      end
    end

    if #itemList>0 then
      cur_idx = 1
      TimerManager.addTimer(100, eqm_list_step_add,true)
      self.tips_label:setVisible(false)
    else
      self.tips_label:setVisible(true)
      if location == ItemHelper.itemType.Ring then
         self.tips_label:setText("競技場功勳商店可\n兌換紫色戒指哦。")
      elseif location == ItemHelper.itemType.Necklace then
         self.tips_label:setText("榮耀之路勳章商店\n可兌換紫色項鍊哦。")
      else
         self.tips_label:setText(string.format("參加噩夢難度副本\n可獲得紫色%s。",ItemHelper:getTypeName(location)))
      end
    end
  

	self.listview:setGravity(LISTVIEW_GRAVITY_CENTER_VERTICAL)

end

function EquipListView:setData(hero_id, location, limitStand)
   self.cur_hero_id = hero_id
   self.location = location
   self.limitStand = limitStand
end

function EquipListView:refreshData()
    local eqm_list_vo = HeroManager:getInstance():getBattleHeroEqmList(self.cur_hero_id)
    local isAllowExc = false
    local eqm_vo = eqm_list_vo:getSingleEquip(self.location)
    if eqm_vo then
      isAllowExc = true
    end

    local hero_info = HeroManager:getInstance():getHeroInfoById(self.cur_hero_id)
    local eqm_item = nil 
    if eqm_vo and eqm_vo.item then
      eqm_item = eqm_vo.item
    end

    local eqm_status = ItemManager:getInstance():findCanExcEqm(hero_info.pos,self.location,eqm_item)
    if eqm_status==ItemHelper.exc_eqm_status.add or 
      eqm_status==ItemHelper.exc_eqm_status.up then
      is_show_green_bg = true
    else
      is_show_green_bg = false
    end

    local tempArr = ItemManager:getInstance():findFitEquipFromBackPack(self.limitStand,self.location,isAllowExc)
    self:setItemList(tempArr,self.location)
end
