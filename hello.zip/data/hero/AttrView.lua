--
-- Author: lvgansheng
-- Date: 2014-06-18 17:43:05
-- 卡牌详细属性界面

AttrView =  class("AttrView",WidgetBase)
AttrView.uiLayer = nil
AttrView.widget = nil
AttrView.enterFun = nil 
AttrView.exitFun = nil
AttrView.base_id = 0
AttrView.label_arr = nil
AttrView.lev_label = nil
AttrView.exp_label = nil
AttrView.fight_capacity_label = nil
AttrView.hp_label = nil
AttrView.atk_label = nil
AttrView.pdef_label = nil

local attr_list = nil

function AttrView:init()	

    require("AttrLabel")
    require "AttrHelper"

    attr_list = {AttrHelper.attr_flag.hp,AttrHelper.attr_flag.atk,AttrHelper.attr_flag.pdef,
                    AttrHelper.attr_flag.atk_speed}

    self:setPositionX(32)
    self:setPositionY(-2)

	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/hero_attr/hero_attr.ExportJson")
    self:addChild(self.widget)

    --self.label_arr = CCArray:create()
    --self.label_arr:retain()

    -- self.list_view = self.widget:getChildByName("attr_list_view")
    -- tolua.cast(self.list_view, "ListView")
    -- self.list_view:setVisible(false)

    -- local dis_x = 50
    -- local dis_y = 290
    -- self.lev_label = AttrLabel:create()
    -- self.lev_label:setPosition(ccp(dis_x,dis_y))
    -- self:addChild(self.lev_label)

    -- dis_y = dis_y-30
    -- self.exp_label = AttrLabel:create()
    -- self.exp_label:setPosition(ccp(dis_x,dis_y))
    -- self:addChild(self.exp_label)
    
    -- dis_y = dis_y-30
    -- self.fight_capacity_label = AttrLabel:create()
    -- self.fight_capacity_label:setPosition(ccp(dis_x,dis_y))
    -- self:addChild(self.fight_capacity_label)

    self.hp_value_label = tolua.cast(self.widget:getChildByName("hp_value_label"), "Label")
    self.atk_value_label = tolua.cast(self.widget:getChildByName("atk_value_label"), "Label")
    self.pdef_value_label = tolua.cast(self.widget:getChildByName("pdef_value_label"), "Label")
    self.atk_spd_label = tolua.cast(self.widget:getChildByName("atk_spd_label"), "Label")

    self.btnMore = tolua.cast(self.widget:getChildByName("btn_more"),"Button")
    self.btnMore:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.HeroAdvInfoView,{hero_id = self.base_id})
        end
    end)

    require "HeroAdvInfoTips"
    self.propNames = {"hp","atk","pdef","atk_speed"}
    local container = self.widget:getChildByName("ImageView_44")
    for i,v in ipairs(self.propNames) do
        self["img_"..v] = tolua.cast(container:getChildByName("img_"..v),"ImageView")
        self["img_"..v]:addTouchEventListener(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                    
                    HeroAdvInfoTips:show(AttrHelper.attr_flag[v])

            elseif eventType == ComConstTab.TouchEventType.ended or
                    eventType == ComConstTab.TouchEventType.canceled then
                    HeroAdvInfoTips:hide()
            end
        end)
    end
end

function AttrView:create()
	local attr_view = AttrView.new()
	attr_view:init()
	return attr_view	
end

--改变内容
function AttrView:changeContent(base_id)

	self.base_id = base_id
	local hero_info = HeroManager:getInstance():getHeroInfoByBaseId(base_id)
	local attrs = HeroManager:getInstance():getHeroFinalAttr(base_id)

    local desc_label = tolua.cast(self.widget:getChildByName("desc_label"), "Label")
    -- desc_label:ignoreContentAdaptWithSize(false)
    -- local desc_font_size = desc_label:getFontSize()

    -- local str_len = string.len(hero_info.desc)/3
    -- local tips_width = 300
    -- local total_len = desc_font_size*str_len
    -- local tips_height = math.ceil(total_len/tips_width+2)*desc_font_size

    -- -- if tips_height>110 then
    -- --     tips_height =110
    -- -- end

    -- desc_label:setSize(CCSize(tips_width,tips_height))
    desc_label:setText(hero_info.desc)
    -- desc_label:setPositionY((160-tips_height)/2+425)

	-- 不需要滚动时候的处理
	-- self.lev_label:setData("等級",hero_info.cur_lev,0)
	-- self.exp_label:setData("經驗",hero_info.exp,0)
	-- self.fight_capacity_label:setData("戰鬥力",HeroManager:getInstance():getFightCapacity(base_id),0)
	
	self.hp_value_label:setText(attrs[AttrHelper.attr_flag.hp])
	self.atk_value_label:setText(attrs[AttrHelper.attr_flag.atk])
	self.pdef_value_label:setText(attrs[AttrHelper.attr_flag.pdef])
	self.atk_spd_label:setText(AttrHelper:getAtkSpeedDesc(attrs[AttrHelper.attr_flag.atk_speed]))

	--需要滚动的处理
	--local tempChildArr = self.list_view:getChildren()
   -- self.label_arr:addObjectsFromArray(tempChildArr)

   -- self.list_view:removeAllItems()


    --属性部分
	-- local attrs = HeroManager:getInstance():getHeroFinalAttr(base_id)
	-- local label = nil
	-- local flag 
	-- for i=1,3 do
	-- 	flag = attr_list[i]
	-- 	label = self.label_arr:lastObject()
	-- 	if label == nil then
	-- 		label = AttrLabel:create()
	-- 		self.list_view:pushBackCustomItem(label) 
	-- 	end
	-- 	label:setData(flag,attrs[flag],0) 
	-- end
end