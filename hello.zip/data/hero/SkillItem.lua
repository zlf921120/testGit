--
-- Author: lvgansheng
-- Date: 2014-08-09 11:15:34
-- 技能界面元件


SkillItem = class("SkillItem", DisplayUtil.newLayout)

function SkillItem:init()
	require("SkillIcon")
	
	self:setTouchEnabled(true)
	local dis_x = 55
	local dis_y = 70
	local step_x = 70
	self.skill_icon = SkillIcon:create()
	self:addChild(self.skill_icon)
	self.skill_icon:setPosition(ccp(dis_x,dis_y))

	self.name_label = Label:create()
	self.name_label:setAnchorPoint(ccp(0,1))
	self.name_label:setPosition(ccp(120,110))         --120,110
	self.name_label:setFontSize(26)
	self.name_label:setColor(ccc3(210,253,238))
	self.name_label:setText("寒冰箭")
	self:addChild(self.name_label)

	local lev_label = Label:create()
	lev_label:setAnchorPoint(ccp(0.5,1))
	lev_label:setPosition(ccp(38,40))       --65,35`
	lev_label:setFontSize(24)
	lev_label:setColor(ItemHelper.colors.light_blue)
	-- self.lev_label:setText("LV.99")
	self:addChild(lev_label)

	self.real_lev_label = Utils.createStrokeLab({label = lev_label, outlinecolor = ccc3(0,0,0)})
	self.real_lev_label:setPosition(ccp(0,0))
	lev_label:addNode(self.real_lev_label)
	-- self.real_lev_label:setText("LV.99")
	-- self.lev_label:setVisible(false)

	-- self.test_label = CCLabelTTF:create()
	-- self.test_label:setFontSize(24)
	-- self.test_label:setColor(ItemHelper.colors.light_blue)
	-- self.test_label:setString("LV.99")
	-- self.test_label:setPosition(ccp(65,55))
	-- local xxfff = Utils.createStroke(self.test_label,0, ItemHelper.colors.light_blue, 255)
	-- self:addNode(xxfff)

	local function skillUpgrade(sender,event_type)
		if event_type == ComConstTab.TouchEventType.ended then

			--local next_skill_vo = SkillManager:getInstance():getSkillData(self.skill_info.skill_id,self.skill_info.skill_lev+1,3)
				
			if self.next_skill_vo == nil then
				Alert:show("該技能已經到達最高層次")
				return
			end

			if CharacterManager:getInstance():getAssetData():getSkillPoint()<1 then --技能点判断
				Alert:show("您的技能點不足，獲得副本、惡魔塔星級可增加技能點。")
				return
			end

			if self.next_skill_vo:getUpgradeCostGold() > CharacterManager:getInstance():getAssetData():getGold() then
        		Alert:show(string.format("升級需要%d金幣",self.next_skill_vo:getUpgradeCostGold()))
				return 
			end

			-- local hero_info = HeroManager:getInstance():getHeroInfoByBaseId(self.hero_id)
			if self.next_skill_vo:getHeroLev() > self.hero_info.cur_lev then
        		Alert:show(string.format("需要英雄等級%d才可升級",self.next_skill_vo:getHeroLev()),ccc3(255, 0, 0)) 
				return 
			end

			local skill_upgrade_req = hero_pb.hero_skill_upgrade_req()
			skill_upgrade_req.hero_id = self.hero_id
			skill_upgrade_req.skill_id = self.skill_info.skill_id
			ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_skill_upgrade_req,skill_upgrade_req)
        end
	end

	local up_btn_pos = ccp(272,dis_y)

	local upgrade_btn_touch_panel = DisplayUtil.newLayout()
	upgrade_btn_touch_panel:setTouchEnabled(true)
	upgrade_btn_touch_panel:setSize(CCSize(80,80))
	upgrade_btn_touch_panel:setPositionX(up_btn_pos.x-40)
	upgrade_btn_touch_panel:setPositionY(up_btn_pos.y-40)
	self:addChild(upgrade_btn_touch_panel)


	self.upgrade_btn = Button:create()
	self.upgrade_btn:setTouchEnabled(true)

	self.upgrade_btn:setPosition(ccp(262,42))

	self.upgrade_btn:loadTextures("btn_up_9.png", "btn_down_9.png", "btn_disable_9.png", UI_TEX_TYPE_PLIST)
	self:addChild(self.upgrade_btn)
	-- self.upgrade_btn:setBright(false)

	self.upgrade_btn:addTouchEventListener(skillUpgrade)
	upgrade_btn_touch_panel:addTouchEventListener(skillUpgrade)

	self.coin_img = ImageView:create()
	-- self.coin_img:setScale(0.9)
	self.coin_img:loadTexture("gold.png", UI_TEX_TYPE_PLIST)
	self.coin_img:setPosition(ccp(137,42))
	self:addChild(self.coin_img)

	self.con_label = Label:create()
	self.con_label:setColor(ItemHelper.colors.yellow)
	self.con_label:setFontSize(24)
	self.con_label:setAnchorPoint(ccp(0,1))
	self.con_label:setPosition(ccp(163,55))
	self:addChild(self.con_label)

	self.need_lev_label = Label:create()
	self.need_lev_label:setColor(ItemHelper.colors.red)
	self.need_lev_label:setFontSize(24)
	self.need_lev_label:setAnchorPoint(ccp(0,1))
	self.need_lev_label:setPosition(ccp(123,55))
	self.need_lev_label:setVisible(false)
	self:addChild(self.need_lev_label)

	self:setSize(CCSize(310,110))
end

function SkillItem:create()
	local skill_item = SkillItem.new()
	skill_item:init()
	return skill_item
end

--设置元件关联的敌人信息
function SkillItem:setSkillInfo(hero_id,skill_info)
	self.hero_id = hero_id
	self.skill_info = skill_info
	self.skill_icon:setSkillId(skill_info.skill_id)

	local temp_lev = skill_info.skill_lev
	if temp_lev == 0 then
		temp_lev = 1
	end

	self.hero_info = HeroManager:getInstance():getHeroInfoByBaseId(self.hero_id)
	self.next_skill_vo = SkillManager:getInstance():getSkillData(self.skill_info.skill_id,self.skill_info.skill_lev+1,3)
	self.skill_data = SkillManager:getInstance():getSkillData(skill_info.skill_id,temp_lev,3)
	self.name_label:setText(self.skill_data:getName())
	self.real_lev_label:setText(string.format("Lv.%d",skill_info.skill_lev))
	if self.next_skill_vo then
		
		if self.next_skill_vo:getHeroLev() > self.hero_info.cur_lev then
			self.need_lev_label:setText(string.format("英雄等級%d",self.next_skill_vo:getHeroLev()))
			self.need_lev_label:setVisible(true)
			self.con_label:setVisible(false)
			self.coin_img:setVisible(false)
		else
			self.coin_img:setVisible(true)
			self.con_label:setVisible(true)
			self.need_lev_label:setVisible(false)
			self.con_label:setText(self.next_skill_vo:getUpgradeCostGold())

			if self.next_skill_vo:getUpgradeCostGold() > CharacterManager:getInstance():getAssetData():getGold() then
				self.con_label:setColor(ItemHelper.colors.red)
			else
				self.con_label:setColor(ItemHelper.colors.yellow)
			end
		end
	else
		self.con_label:setText("")
		self.coin_img:setVisible(false)
		self.need_lev_label:setVisible(false)
	end

	if skill_info.skill_lev == 0 then
		self.skill_icon:isOpen(false)
		--self.upgrade_btn:setBright(false)
	else
		self.skill_icon:isOpen(true)
	end

	--local next_skill_vo = SkillManager:getInstance():getSkillData(self.skill_info.skill_id,self.skill_info.skill_lev+1,3)
	if self.next_skill_vo == nil or  self.next_skill_vo:getHeroLev() > self.hero_info.cur_lev then
		self.upgrade_btn:setBright(false)
	else
		self.upgrade_btn:setBright(true)
	end		
end

function SkillItem:showSkillFlag(index)
	if self.imgFlag == nil then
		self.imgFlag = ImageView:create()
		self.imgFlag:loadTexture(string.format("hero_skill%d.png",index),UI_TEX_TYPE_PLIST)
		self.imgFlag:setPosition(ccp(80,50))          --130,98
		self:addChild(self.imgFlag)

		self.name_label:setFontSize(25)
		self.name_label:setPositionX(120)
	end
end
