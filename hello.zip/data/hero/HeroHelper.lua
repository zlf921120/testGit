--
-- Author: lvgansheng
-- Date: 2014-06-19 20:09:50
-- 角色界面帮助类

HeroHelper = {}

HeroHelper.Defaule_Hero_Id = 10000

HeroHelper.leftPanelType = {}
HeroHelper.leftPanelType.roleAttrView = 1
HeroHelper.leftPanelType.heroImgView = 2
HeroHelper.leftPanelType.heroUpgradeView = 3
HeroHelper.leftPanelType.skillView = 4
HeroHelper.leftPanelType.equipListView = 5
HeroHelper.leftPanelType.equipAttrView = 6
HeroHelper.leftPanelType.equipConfirmView = 7
HeroHelper.leftPanelType.fashion = 8

HeroHelper.forgePanelType = {}
HeroHelper.forgePanelType.powered = 1 --强化面板
HeroHelper.forgePanelType.identify  = 2 --鉴定
HeroHelper.forgePanelType.enchant = 3 --附魔面板
HeroHelper.forgePanelType.gem = 4 --宝石
HeroHelper.forgePanelType.upgrade = 5 --升级

HeroHelper.hero_race = {} --英雄种族
HeroHelper.hero_race.human = 1 --人类
HeroHelper.hero_race.elf = 2 --精灵
HeroHelper.hero_race.undead  = 3 --亡灵
HeroHelper.hero_race.orc = 4 --兽族
HeroHelper.hero_race.demon = 5 --恶魔

HeroHelper.atk_type = {} --英雄攻击方式
HeroHelper.atk_type.near_atk = 1 --近程
HeroHelper.atk_type.far_atk = 2 --远程

HeroHelper.hero_info_req_type = {}
HeroHelper.hero_info_req_type.all = 1
HeroHelper.hero_info_req_type.base = 2

HeroHelper.fashion_upgrade_type = {} -- 时装进阶类型
HeroHelper.fashion_upgrade_type.normal = 1
HeroHelper.fashion_upgrade_type.auto = 1

HeroHelper.MaxStar = 5

function HeroHelper.getStarResPath(cur_stars)
	local path = "white_star.png"
	if cur_stars==5 then
		path = "orange_star.png"
	elseif cur_stars==4 then
		path = "purple_star.png"
	elseif cur_stars==3 then
		path = "blue_star.png"
	elseif cur_stars==2 then
		path = "green_star.png"
	end
	return path
end

--对比衣柜前后差别
function HeroHelper.checkExtFashion(list1,list2)
	local tbl1 = {}
	for _,v in pairs(list1) do
		for _,vv in pairs(v) do
			table.insert(tbl1,vv.fashionId)
		end
	end
	local tbl2 = {}
	for _,v in pairs(list2) do
		for _,vv in pairs(v) do
			table.insert(tbl2,vv.fashionId)
		end
	end

	if #tbl1 == #tbl2 then
		return nil
	end

	table.sort(tbl1,function(a,b) return a<b end)
	table.sort(tbl2,function(a,b) return a<b end)
	local tmpLongTbl = nil
	local tmpShortTbl = nil
	if #tbl1 > #tbl2 then
		tmpLongTbl = tbl1
		tmpShortTbl = tbl2
	else
		tmpLongTbl = tbl2
		tmpShortTbl = tbl1
	end

	local ret = {}
	for i=#tmpShortTbl+1,#tmpLongTbl do
		table.insert(ret,tmpLongTbl[i])
	end
	return ret[1]
end