-- 装备鉴定  重置
EqmIdentifyResetPanel = class("EqmIdentifyResetPanel",WindowBase)
EqmIdentifyResetPanel.__index = EqmIdentifyResetPanel
EqmIdentifyResetPanel._widget    = nil
EqmIdentifyResetPanel.uiLayer    = nil
EqmIdentifyResetPanel.is_dispose = true

local __instance = nil

function EqmIdentifyResetPanel:create()
    local ret = EqmIdentifyResetPanel.new()
    __instance = ret
    return ret   
end

function EqmIdentifyResetPanel:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end


function EqmIdentifyResetPanel:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/equip/eqm_identify/equip_reset_identify.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

	self.btnClose = tolua.cast(self._widget:getChildByName("btn_cancel"),"Button")
	self.btnClose:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then
			WindowCtrl:getInstance():close(self.name)
		end
	end)

    self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            
            local param = {}
            param.hero_id = self.itemData.hero_id
            param.item_id = self.itemData.id
            param.eqm_pos = self.itemData.mode.item_type
            param.cost_arr = self.materialTbl
            ItemManager:getInstance():sendEquipIdentifyReset(param)

        end
    end)

    self.labTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips"),"Label")
    self.labNum = tolua.cast(self.uiLayer:getWidgetByName("lab_num"),"Label")
    self.scrollView = DisplayUtil.createAdaptScrollView(510,230,105,0,4)
    self.scrollView:setPosition(ccp(249,195))
    self._widget:addChild(self.scrollView,3) 
    --材料
    self.materialTbl = {}
end

function EqmIdentifyResetPanel:isFullMaterial()
    local ret = false
    local total = self:getCurMaterialNum()
    local info = nil
    local equipType = ItemHelper:getEquipTypeWithItemType(self.itemData.mode.item_type)
    if equipType == ItemHelper.equipType.equip then
        info = ItemManager:getInstance():getEqmIdentifyResetInfo(self.itemData.mode.base_id)
    elseif equipType == ItemHelper.equipType.fashion then
        info = ItemManager:getInstance():getFashionIdentifyResetInfo(self.itemData.hero_id,self.itemData.mode.item_type)
    end
    return total >= info.piece_num
end

function EqmIdentifyResetPanel:getCurMaterialNum()
    local total = 0
    for k,v in pairs(self.materialTbl) do
        if v > 0 then
            total = total + v
        end
    end
    return total
end

function EqmIdentifyResetPanel:open()

    self.itemData = self.params["item_data"]

    local arr = ItemManager:getInstance():getItemArrByItemType( ItemHelper.itemType.equip_fragment )
    
    local function createPosArr( len )
        local col = 4
        local row = math.max(2, math.ceil(len / 4))
        local ret = {}

        local baseX = 55
        local baseY = 60

        local idx = 0
        for i=0,row - 1 do

            for j=0,col - 1 do
                idx = idx + 1

                local height = 100
                local width = 130

                table.insert(ret, { x = baseX + j * width , y = baseY + (row - i - 1) * height })
            end
        end
        return ret
    end

    self.scrollView:setScrollHeight(math.max(2,#arr))
    local pos = createPosArr( #arr )

    local idx = 0
    local function step_create()
        idx = idx + 1
        local itemVo = arr[idx]
        if itemVo ~= nil then
            local item = ItemIcon:create()
            item:setBaseId(itemVo.mode.base_id)
            item:setScale(0.9)
            item:isShowNumLabel(false)
            item:setPosition(ccp(pos[idx].x,pos[idx].y))
            item:isShowPercLab(true)
            item:isShowDelBtn(item.tmp_quantity > 0)
            item:setDelBtnFunc(function(pSender,eventType)
                if eventType == ComConstTab.TouchEventType.ended then

                    item.tmp_quantity = math.max(0,item.tmp_quantity - 1)
                    item:setLabPercTxt(string.format("%d/%d",item.tmp_quantity,itemVo.quantity))

                    item:isShowDelBtn(item.tmp_quantity > 0)

                    self.materialTbl[ itemVo.id ] = item.tmp_quantity
                    self:update()
                end
            end)
            item:setTouchEvent(function(pSender,eventType)
                if eventType == ComConstTab.TouchEventType.ended then
                    if self:isFullMaterial() == false then

                        item.tmp_quantity = math.min(itemVo.quantity,item.tmp_quantity + 1)
                        item:setLabPercTxt(string.format("%d/%d",item.tmp_quantity,itemVo.quantity))
                        
                        item:isShowDelBtn(item.tmp_quantity > 0)
                        
                        self.materialTbl[ itemVo.id ] = item.tmp_quantity
                        self:update()
                    end
                end
            end)
            item:setLabPercTxt(string.format("%d/%d",item.tmp_quantity,itemVo.quantity))
            self.scrollView:getInnerContainer():addChild(item)
        else
            self.scrollView:stopAllActions()
        end
    end

    self.scrollView:stopAllActions()
    self.scrollView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
        CCCallFunc:create(step_create),
        CCDelayTime:create(0.05))))

    self:update()
end

function EqmIdentifyResetPanel:update()
    local info = nil
    local equipType = ItemHelper:getEquipTypeWithItemType(self.itemData.mode.item_type)
    if equipType == ItemHelper.equipType.equip then
        info = ItemManager:getInstance():getEqmIdentifyResetInfo(self.itemData.mode.base_id)
    elseif equipType == ItemHelper.equipType.fashion then
        info = ItemManager:getInstance():getFashionIdentifyResetInfo(self.itemData.hero_id,self.itemData.mode.item_type)
    end

    self.labTips:setText(string.format("選擇%d個碎片後，點擊確定即可重置鑒定的次數。",info.piece_num))
    self.labNum:setText(string.format("已選：%d/%d",self:getCurMaterialNum(),info.piece_num))
end