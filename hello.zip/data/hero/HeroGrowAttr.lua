--
-- Author: lvgansheng
-- Date: 2014-06-27 15:49:25
-- 卡牌属性成长信息

HeroGrowAttr = class("HeroGrowAttr")
HeroGrowAttr.grows = nil

function HeroGrowAttr:init()
	self.grows = {}
end

function HeroGrowAttr:create()
	local grow = HeroGrowAttr.new()
	grow:init()
	return grow
end

function HeroGrowAttr:setData(attr_type,value)
	self.grows[attr_type] = tonumber(value)
end

--获取某类型的属性
function HeroGrowAttr:getDataByType(attr_type)
	local value = self.grows[attr_type] 
	if value == nil then 
		value = 0
	end

	return value
end

function HeroGrowAttr:getGrows() 
	return self.grows
end



