--
-- Author: lvgansheng
-- Date: 2014-08-09 12:44:35
-- 英雄技能数据

HeroSkillInfo = class("HeroSkillInfo")

HeroSkillInfo.skill_id = 0 --技能id
HeroSkillInfo.is_open = false
HeroSkillInfo.skill_lev = 0 --技能等级

HeroSkillInfo._encryptId = nil
HeroSkillInfo._encryptLevel = nil

function HeroSkillInfo:setData(skill_id, skill_lev)
	self.skill_id = skill_id
	self.skill_lev = skill_lev
	if skill_lev>0 then
		self.is_open = true
	else
		self.is_open = false
	end
end

function HeroSkillInfo:setEncryptData(id, level)

	self._encryptId = id
    self._encryptLevel = level

    local decryptLevel = self:getSkillLevel()
    if decryptLevel > 0 then
        self.is_open = true
    else
        self.is_open = false
    end

end

function HeroSkillInfo:getSkillId()
	if self._encryptId then
	    return BattleManager:getInstance():getDecryptValue(self._encryptId)
	end

	return self.skill_id
end

function HeroSkillInfo:getSkillLevel()
	if self._encryptLevel then
	    return BattleManager:getInstance():getDecryptValue(self._encryptLevel)
	end

	return self.skill_lev
end

function HeroSkillInfo:isOpen()
	return self.is_open
end

function HeroSkillInfo:create()
	local skill_info = HeroSkillInfo.new()
	-- skill_info:init()
	return skill_info
end