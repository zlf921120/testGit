--
-- Author: lvgansheng
-- Date: 2014-07-28 11:04:24
-- 宝石镶嵌界面的物品

GemItemIcon = class("GemItemIcon",function() return Layout:create() end)

function GemItemIcon:init()
	--测试用 
	self.item_icon = ItemIcon:create()
	local icon_bg_width = self.item_icon.icon_bg:getSize().width
	local icon_bg_height = self.item_icon.icon_bg:getSize().height
	self.item_icon:setPosition(ccp(icon_bg_width/2+10,icon_bg_height/2))
	self:addChild(self.item_icon)

	self.gem_lv_label = Label:create()
    self.gem_lv_label:setFontSize(22)
    self.gem_lv_label:setColor(ccc3(251, 241, 160))
    self:addChild(self.gem_lv_label)
    self.gem_lv_label:setPosition(ccp(38,20))

    self.attr_label = Label:create()
	self.attr_label:setText("攻擊:+50")
	self.attr_label:setPositionX(self.item_icon:getPositionX())
	self.attr_label:setPositionY(-30)
	self.attr_label:setFontSize(24)
	self.attr_label:setColor(ItemHelper.colors.yellow)
	self:addChild(self.attr_label)

	self:setSize(CCSize(icon_bg_width+25,icon_bg_height+13))
end

function GemItemIcon:create()
	local gem_icon = GemItemIcon.new()
	gem_icon:init()
	return gem_icon
end

function GemItemIcon:setData(item)
	self.item = item
	self.item_icon:setBaseId(item.mode.base_id)
	self.item_icon:setItemNum(item.quantity)
	local gem_info =  ItemManager:getInstance():getGemInfo(item.mode.base_id)
	self.gem_lv_label:setText(string.format("lv %d",gem_info.gem_lev))
	self.attr_label:setText(string.format("%s+%d",
	AttrHelper:getAttrNameByFlag(gem_info.attr_type),gem_info.val))
end

function GemItemIcon:setTouchEvent(touch_event)
	self.item_icon:setTouchEvent(touch_event)
end

function GemItemIcon:setSelect(visible)
	self.item_icon:setItemIconSelect(visible)
end

function GemItemIcon:getClickImg()
	return	self.item_icon.icon_bg
end

