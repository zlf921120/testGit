--选择装备的界面的单个选项
-- require "extern"
-- require "helper"

EquipListOneItem = class("EquipListOneItem",function() return Layout:create() end)
EquipListOneItem.icon = nil
-- EquipListOneItem.item_name_label = nil
EquipListOneItem.item = nil
EquipListOneItem.location = 0 --装备位置
EquipListOneItem.isSelf = false --是自己身上的装备
EquipListOneItem.item_icon = nil --物品图标

EquipListOneItem.recom_effect = nil --推荐装备的特效

local recom_effect_path = "ui/hero/effect/tuijianzhuangbei/tuijianzhuangbei.ExportJson"
-- local _isRegistGuideLister = false
function EquipListOneItem:init(widget_clone)

	self.widget = widget_clone:clone()
	-- self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/equip_list_item/equip_list_item.ExportJson")
    
	self:addChild(self.widget)

	self.item_icon = ItemIcon:create()
	self.item_icon:setPosition(ccp(ItemIcon.icon_width-25,ItemIcon.icon_height-12))
	self:addChild(self.item_icon)

	self:setSize(self.widget:getSize())

	--新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

--新手引导动画
function EquipListOneItem:showStepAnim(param)
	if param.target == "eqm_item" then
    	if GuideDataProxy:getInstance().nowMainTutroialEventId == 10610 then
	    	if self.item.mode.base_id == 13010 then --紫装
	        	GuideRenderMgr:getInstance():renderMainFlag(self,param.id,param.target)
	    	end
	    elseif GuideDataProxy:getInstance().nowMainTutroialEventId == 10105 then
	    	if self.item.mode.base_id == 11000 then --小剑
        		GuideRenderMgr:getInstance():renderMainFlag(self,param.id,param.target)
        	end
    	end
    end
end

function EquipListOneItem:setItem(item, location, hero_id)
	self.item = item
	self.location = location
	self.hero_id = hero_id -- 需要替换装备的英雄ID
	self.item_icon:setBaseId(item.mode.base_id)

	 local nameLabel = self.widget:getChildByName("name_label")
	 tolua.cast(nameLabel, "Label")
	 nameLabel:setText(item.mode.name) 
	 nameLabel:setColor(ItemHelper:getColorByQuality(self.item.mode.quality))

	 local limit_lev = self.widget:getChildByName("lev_label")
	 tolua.cast(limit_lev, "Label")
	 --判断等级是否足够
	 if item.mode.limit_lev>CharacterManager:getInstance():getTeamData():getLev()then
	 	limit_lev:setColor(ItemHelper.colors.red)
	 else
	 	limit_lev:setColor(ItemHelper.colors.yellow)
	 end
	 limit_lev:setText(string.format("%d",item.mode.limit_lev))

	 local card_name = self.widget:getChildByName("hero_name_label")
	 tolua.cast(card_name, "Label")
	 
	 if item.hero_id > 0 then
	 	local card_info = HeroManager:getInstance():getHeroInfoByBaseId(item.hero_id)
	 	card_name:setText(card_info.name) 
	 	card_name:setColor(ccc3(0xfe,0x4a,0x38))
	 else
	 	card_name:setText("未裝備英雄") 
	 	card_name:setColor(ItemHelper.colors.yellow)
	 end

	 local attrLabel = self.widget:getChildByName("attr_label")
	 tolua.cast(attrLabel, "Label")
	 local flag = ItemHelper:getAttrFlagByLocation(location)
	 local attr_value = ItemManager:getInstance():getEqmBaseAttrAddQuality(item.mode.base_id)[flag]
	 attrLabel:setText(string.format("%s+%d",AttrHelper:getAttrNameByFlag(flag),attr_value))
end

function EquipListOneItem:create(widget_clone)
	local oneItem = EquipListOneItem.new()
	oneItem:init(widget_clone)
	return oneItem
end	

function EquipListOneItem:setClickItem(clickFun)
	local btn = self.widget:getChildByName("bg_button")
	btn:addTouchEventListener(clickFun)
end

function EquipListOneItem:setGreenBgVisible(is_visible)
	if is_visible then
		if self.recom_effect == nil then
            self.recom_effect = AnimateManager:getInstance():getArmature(recom_effect_path,"tuijianzhuangbei") 
            self.recom_effect:setPosition(ccp(160,78))
            self.recom_effect:retain()
        end
        self.recom_effect:removeFromParentAndCleanup(true)
        self:addNode(self.recom_effect)
        self.recom_effect:getAnimation():playWithIndex(0)
	else
		if self.recom_effect then
            self.recom_effect:getAnimation():stop()
           	self.recom_effect:removeFromParentAndCleanup(true)
		end
	end
end
