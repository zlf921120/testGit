--
-- Author: lvgansheng
-- Date: 2014-08-01 17:26:10
-- 英雄属性单项

AttrLabel = class("AttrLabel",DisplayUtil.newLayout)

AttrLabel.flag_name_label = nil
AttrLabel.value_label = nil
AttrLabel.ext_label = nil

AttrLabel.lev_flag = -1
AttrLabel.fight_capacity_flag = -2
AttrLabel.exp_flag = -3
AttrLabel.team_lev_flag = -4

AttrLabel.arrow_img = nil

local attr_flag_size = 22
local attr_value_size = 22
local ext_value_size = 22

function AttrLabel:setData(attr_flag, attr_value, ext_value, arrow_type)

	self.flag_name_label:setText(attr_flag)

	if attr_value then
		self.value_label:setText(attr_value)
		self.value_label:setVisible(true)
	else
		self.value_label:setVisible(false)
	end

	if ext_value and string.len(tostring(ext_value))>0 then
		ext_value = "+"..ext_value
		self.ext_label:setText(ext_value)
		self.ext_label:setVisible(true)
	else
		self.ext_label:setVisible(false)
	end

	--调整位置
	local one_width = Helper.coutStrWidth(attr_flag)+15							--string.len(attr_flag)/3*attr_flag_size+15
	local two_width = Helper.coutStrWidth(tostring(attr_value))
	self.value_label:setPositionX(one_width)
	self.ext_label:setPositionX(one_width+two_width+25)

	if arrow_type then
		if self.arrow_img == nil then
			self.arrow_img = ImageView:create()
			self.arrow_img:setScale(0.5)
			self.arrow_img:setAnchorPoint(ccp(0.5,0.15))
			
			self:addChild(self.arrow_img)	
		end

		-- local three_width = string.len(tostring(ext_value))/3*attr_flag_size
		local three_width = Helper.coutStrWidth(tostring(ext_value))
		self.arrow_img:setPositionX(one_width+two_width+15+three_width+50)
		self.arrow_img:setVisible(true)
		if arrow_type == 1 then --上升
			self.arrow_img:loadTexture("btn_up_12.png", UI_TEX_TYPE_PLIST)
		elseif arrow_type == 2 then
			self.arrow_img:loadTexture("down_sign.png", UI_TEX_TYPE_PLIST)
		else
			self.arrow_img:setVisible(false)
		end
	else
		if self.arrow_img  then
			self.arrow_img:setVisible(false)
		end
	end
end

function AttrLabel:setEachLabelColor(idx, color)
	if idx == 1 then
		self.flag_name_label:setColor(color)
	elseif idx == 2 then
		self.value_label:setColor(color)
	elseif idx == 3 then
		self.ext_label:setColor(color)
	end
	
end

function AttrLabel:init()
	local dis = 10
	self.flag_name_label = Label:create()
	self.flag_name_label:setAnchorPoint(ccp(0,0))
	self.flag_name_label:setFontSize(22)
	self.flag_name_label:setColor(ItemHelper.colors.deep_yellow)
	self.flag_name_label:setPositionX(dis)
	self:addChild(self.flag_name_label)	

	dis = dis + 120
	self.value_label = Label:create()
	self.value_label:setAnchorPoint(ccp(0,0))
	self.value_label:setFontSize(22)
	self.value_label:setColor(ItemHelper.colors.yellow)
	self.value_label:setPositionX(dis)
	self:addChild(self.value_label)

	dis = dis + 120
	self.ext_label = Label:create()
	self.ext_label:setAnchorPoint(ccp(0,0))
	self.ext_label:setFontSize(22)
	self.ext_label:setColor(ItemHelper.colors.green)
	self.ext_label:setPositionX(dis)
	self:addChild(self.ext_label)

	self:setSize(CCSize(300,35))
end

function AttrLabel:create()
	local attr_label = AttrLabel.new()
	attr_label:init()
	return attr_label
end