--
-- Author: lvgansheng
-- Date: 2014-07-02 11:23:43
-- 装备附魔界面



EqmEnchantView =  class("EqmEnchantView",WidgetBase)
EqmEnchantView.uiLayer = nil
EqmEnchantView.widget = nil
EqmEnchantView.enterFun = nil 
EqmEnchantView.exitFun = nil
EqmEnchantView.item = nil
EqmEnchantView.location = 0
EqmEnchantView.enchant_item_arr = nil
EqmEnchantView.ext_eg = 0 --当前等级额外多出来的能量值
EqmEnchantView.equip_icon = nil
EqmEnchantView.real_total_enegry = nil --实际喂养起到作用的能量总和
EqmEnchantView.item_total_enegry = nil --实际物品的能量总和

local item_mgr = ItemManager:getInstance()
local loading_bar = nil
local locading_bar_label = nil

local step_enegry = 20 --每次前进多少能量值

local def_icon_width = 100
local def_icon_height = 90
local def_sc_height = 206
local def_icon_num = 4

local success_animate_path = "ui/effects_ui/fumo/fumo.ExportJson"

local prog_bar_animate_path = "ui/effects_ui/fumoman/fumoman.ExportJson"

local success_animation_tag = 1211
local prog_bar_animation_tag = 1212

function EqmEnchantView:init()
    require("EnchantItem")
    require("TimerManager")
    require("BatchItemIcon")

    self.is_show_prog_anim = false

	self.enchant_icon_arr = CCArray:create()
	self.enchant_icon_arr:retain()

    self.feed_item_list = {}

    self.remain_enegry = 0

	self.uiLayer = TouchGroup:create() 
    --self:addNode(self.uiLayer)
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/equip/eqm_enchant/eqm_enchant.ExportJson")
    self:addChild(self.widget)

    -- self.equip_icon = EquipIcon:create()
    -- self.equip_icon:setPosition(ccp(180,406))
    -- self:addChild(self.equip_icon)

    -- self.list_view = self.widget:getChildByName("list_view")
    -- tolua.cast(self.list_view, "ListView")

    self.batchItemIcon = BatchItemIcon:create()
    self.batchItemIcon:setIconScal(0.8)
    self.sc_view = self.batchItemIcon:getScView()
    self.sc_view:setPosition(ccp(365,321))
    self.sc_view:setZOrder(10)
    self.widget:addChild(self.sc_view)
    self.batchItemIcon:setAdjustPos()

   loading_bar = tolua.cast(self.widget:getChildByName("loading_bar"), "LoadingBar")
   locading_bar_label = tolua.cast(self.widget:getChildByName("locading_bar_label"), "Label")
   
    local enchant_btn = self.widget:getChildByName("enchant_btn")
    local function sendEnchantReq(sender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            local function progress()

                local tempChildArr = self.batchItemIcon:getItemIconDic()
                -- local num = tempChildArr:count() - 1
                -- local enchant_item = nil
                local enchant_req = hero_pb.hero_eqm_enchant_req() 
                enchant_req.hero_id = self.item.hero_id
                enchant_req.eqm_pos = self.location
                enchant_req.item_id = self.item.id
                local cost_item = nil
                local has_senior_item = false
                for i,enchant_item in pairs(tempChildArr) do
                    if enchant_item:isFeed() then
                        cost_item = enchant_req.items:add();
                        cost_item.id = enchant_item:getItemId()
                        cost_item.quantity = enchant_item:getFeedNum()   

                        if enchant_item:getItemData().mode.quality>ItemHelper.itemQuality.Blue then
                            has_senior_item = true
                        end
                       -- cclog ("其中一個附魔材料：%d-----%d",cost_item.item_id,cost_item.quantity)       
                    end
                end

                if #enchant_req.items>0 then 

                    if has_senior_item then
                        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()
                            ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_eqm_enchant_req,enchant_req)
                        end, txt = "您選擇了紫色或以上品質物品進行附魔，附魔後該物品將消失",btnOkName = "確定"})
                    else
                        ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_eqm_enchant_req,enchant_req)
                    end

                else
                    Alert:show("附魔能量不足，請增加附魔能量")
                end
            end

            ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Enchant,progress)
        end 
    end
    enchant_btn:addTouchEventListener(sendEnchantReq)

    self.btnTips = tolua.cast(self.widget:getChildByName("btn_tips"),"Button")
    self.btnTips:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.EnchantSuitDesc,
                {equipListVo=HeroManager:getInstance():getBattleHeroEqmList(self.item.hero_id)})
        end
    end)

    self.labSuitLv = tolua.cast(self.widget:getChildByName("lab_suit_lv"),"Label")
    self.labSuitLv:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.EnchantSuitDesc,
                {equipListVo=HeroManager:getInstance():getBattleHeroEqmList(self.item.hero_id)})
        end
    end)

   
    self.labSuitLvNext = tolua.cast(self.widget:getChildByName("lab_suit_lv_next"),"Label")
    self.labEnchatSuitProg = tolua.cast(self.widget:getChildByName("lab_enchat_suit_prog"),"Label")
    self.progSuit = tolua.cast(self.widget:getChildByName("prog_suit"),"LoadingBar")

    local auto_add_btn = self.widget:getChildByName("auto_add_btn")
    local function autoAddBtnEvent(sender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            -- Alert:show("顯示")
            --清掉之前选中的物品,以自动附魔的按钮为准
            if #self.feed_item_list>0 then
                if self:isFull() then
                    Alert:show("您的附魔能量已滿，請進行附魔")
                    return 
                end
                local tmp_need_enegry = self.cur_lv_max_enegry - self.ext_eg
                self:findAutoFeedItems(tmp_need_enegry)
            else
                Alert:show("您的背包沒有附魔道具了哦")
            end
        end 
    end
    auto_add_btn:addTouchEventListener(autoAddBtnEvent)

    local function updateLodingBar()
        if self.remain_enegry > step_enegry then
            self.real_total_enegry  = self.real_total_enegry + step_enegry
            self.ext_eg = self.ext_eg + step_enegry
            self.remain_enegry = self.remain_enegry - step_enegry
        else
            self.real_total_enegry  = self.real_total_enegry + self.remain_enegry
            self.ext_eg = self.ext_eg + self.remain_enegry
            self.remain_enegry = 0

        end
        -- cclog("self.real_total_enegry=%d~~~~self.ext_eg=%d",self.real_total_enegry, self.ext_eg)
        if self.ext_eg > self.cur_lv_max_enegry then
            loading_bar:setPercent(100)
            locading_bar_label:setText(string.format("%d/%d",self.cur_lv_max_enegry,self.cur_lv_max_enegry))
            self.remain_enegry = self.ext_eg - self.cur_lv_max_enegry + self.remain_enegry
            --多余出来的部分
            self.real_total_enegry = self.real_total_enegry - (self.ext_eg - self.cur_lv_max_enegry)
        else
            loading_bar:setPercent(self.ext_eg/self.cur_lv_max_enegry*100)
            locading_bar_label:setText(string.format("%d/%d",self.ext_eg,self.cur_lv_max_enegry))
        end

        if loading_bar:getPercent() == 100 then
           
            --判断战队等级是否满足
           local team_lv = ItemManager:getInstance():getEnchantTeamLv(self.cur_lv+2)
           local cur_team_lv = CharacterManager:getInstance():getTeamData():getLev() -- 当前战队等级
           if team_lv==nil or team_lv > cur_team_lv then
            --减去没法作为能量的部分
            -- self.real_total_enegry  = self.real_total_enegry-(self.ext_eg-self.cur_lv_max_enegry)

            self.remain_enegry = 0
            self.ext_eg = self.cur_lv_max_enegry
            TimerManager.removeTimer(updateLodingBar)
            self:isShowProgBarAnim(true)


             -- cclog("100%時候的self.real_total_enegry=%d",self.real_total_enegry)
           -- return 
           end

            self.cur_lv = self.cur_lv +1
            self.ext_eg = 0
            self.cur_lv_max_enegry = ItemManager:getInstance():getEnchantEnergyCost(self.cur_lv+1)

           --显示成下一级的初始状态
           loading_bar:setPercent(0)
           locading_bar_label:setText(string.format("%d/%d",0,self.cur_lv_max_enegry))

            if team_lv==nil then 
                self:changeLvInfo(true)
            else
                self:changeLvInfo(false)
            end

            
            --如果已经满级
            -- if team_lv==nil then
            --      next_lev_label:setText("您的裝備附魔已滿級")
            --      next_value_label:setText("")
            -- end
        end

        if self.remain_enegry == 0 then --能量用光了
            TimerManager.removeTimer(updateLodingBar)
        end
    end

    local function updateLodingBar_sub()
         if self.remain_enegry > step_enegry  then
            if self.ext_eg > step_enegry then 
                 self.ext_eg = self.ext_eg - step_enegry
                 self.remain_enegry = self.remain_enegry - step_enegry
            else
                 self.remain_enegry = self.remain_enegry - self.ext_eg
                 self.ext_eg = 0
            end
        else
           if self.ext_eg > self.remain_enegry then 
                 self.ext_eg = self.ext_eg - self.remain_enegry
                 self.remain_enegry = 0
            else
                 self.remain_enegry = self.remain_enegry - self.ext_eg
                 self.ext_eg = 0
            end
        end

       if self.ext_eg <0 then
            cclog("當前的ext_eg~~~%d",self.ext_eg)
           loading_bar:setPercent(0)
           locading_bar_label:setText(string.format("%d/%d",0,self.cur_lv_max_enegry))
       else
            loading_bar:setPercent(self.ext_eg/self.cur_lv_max_enegry*100)
            locading_bar_label:setText(string.format("%d/%d",self.ext_eg,self.cur_lv_max_enegry))
       end

        --如果已经恢复到物品自带的初始状态，则停止
        if self.item.enchant_lev == self.cur_lv and
            self.item.enchant_energy == self.ext_eg or 
            self.remain_enegry <= 0 then
                self.remain_enegry = 0
                TimerManager.removeTimer(updateLodingBar_sub) 
            return 
        end

        if loading_bar:getPercent() == 0 then
            if self.cur_lv>0 then
                self.cur_lv = self.cur_lv -1
                self.cur_lv_max_enegry = ItemManager:getInstance():getEnchantEnergyCost(self.cur_lv+1)
                
                self.ext_eg = self.cur_lv_max_enegry
                loading_bar:setPercent(100)

                self:changeLvInfo()

            else
                 self.remain_enegry = 0
                 self.ext_eg = 0
            end
        end
    end

    local function changeEnergyNum(param)

        local encht_temp_item = param.view_item
        local energy_num = nil

        if param.is_auto_add then
            energy_num = param.auto_eg_num
        else
            energy_num = ItemManager:getInstance():getEnchantEnergy(encht_temp_item:getItemId())
        end

        self.cur_lv = self.cur_lv or self.item.enchant_lev
        self.cur_lv_max_enegry = ItemManager:getInstance():getEnchantEnergyCost(self.cur_lv+1)

        local need_team_lv = ItemManager:getInstance():getEnchantTeamLv(self.cur_lv+1)
        local cur_team_lv = CharacterManager:getInstance():getTeamData():getLev() 
        local next_need_team_lv = ItemManager:getInstance():getEnchantTeamLv(self.cur_lv+2)
        
        if need_team_lv == nil and param.change_type == 1 then
             Alert:show("裝備附魔已經滿級")
             return 
        elseif param.change_type == 1 and need_team_lv > cur_team_lv  then
            Alert:show(string.format("需要戰隊等級%d",need_team_lv))
            return 
        elseif loading_bar:getPercent() == 100 
            and (next_need_team_lv == nil or next_need_team_lv>cur_team_lv)
            and param.change_type == 1 then
            Alert:show("附魔能量已滿，無須再添加物品")
            return 
        end

        if encht_temp_item then
            encht_temp_item:changeContent(param.change_type)
        end

        if param.change_type == 2 then
           energy_num = self:calcRealSubEnergy(energy_num)
            self.remain_enegry = self.remain_enegry + energy_num
            if energy_num>0 then
                self:isShowProgBarAnim(false)
            end
            TimerManager.addTimer(10,updateLodingBar_sub,true)
        elseif param.change_type == 1 then
            self.item_total_enegry = self.item_total_enegry + energy_num
            self.remain_enegry = self.remain_enegry + energy_num
            TimerManager.addTimer(10,updateLodingBar,true)

            --新手引导事件
            if GuideDataProxy:getInstance().nowMainTutroialEventId == 10806 or
                GuideDataProxy:getInstance().nowMainTutroialEventId == 10807 then
                Notifier.dispatchCmd(GuideEvent.StepFinish,"click_enchant_item")
            end
        end   
    end

    --替换按钮，弹出装备选择界面
    -- local exch_btn = self.widget:getChildByName("exch_btn")
    -- local function onExchBtnClick(sender, eventType)
    --     if eventType == ComConstTab.TouchEventType.ended then
    --        WindowCtrl:getInstance():open(CmdName.EqmExchView,HeroHelper.forgePanelType.enchant)
    --     end
    -- end
    -- exch_btn:addTouchEventListener(onExchBtnClick)

    Notifier.regist(CmdName.EqmEnchantEnergy,changeEnergyNum)
    
    self._onEqmEnchantSuc = function (item_id )
        if self.item.id ~= item_id then
            return 
        end

        self.real_total_enegry = 0
        self.item_total_enegry = 0

        self:isShowProgBarAnim(false)

        --播放强化成功特效
        if self.success_animation == nil then
            self.success_animation = AnimateManager:getInstance():getArmature(success_animate_path,"fumo") 
            self.success_animation:setPosition(ccp(245,406))
            self.success_animation:retain()
            self.success_animation:setTag(success_animation_tag)
        end

        self.success_animation:getAnimation():setMovementEventCallFunc(self._onPlayCallBack )
        -- self.success_animation:removeFromParentAndCleanup(true)
        self:removeNodeByTag(success_animation_tag)
       
        self:addNode(self.success_animation)
        self.success_animation:getAnimation():playWithIndex(0,-1,-1,0)

        self.item = ItemManager:getInstance():getEquipInfoById(item_id)
        self:changeExtInfo() 
        self:freshFeedItem() 
        self:changeBaseInfo()

        --新手引导事件
        if GuideDataProxy:getInstance().nowMainTutroialEventId == 10808 then
            Notifier.dispatchCmd(GuideEvent.StepFinish,"finish_enchant")
        end
        
    end

     self._onPlayCallBack = function( armature, movementType, movementID )
        if movementType == AnimationMovementType.COMPLETE then
            self.success_animation:getAnimation():stop()
            self.success_animation:getAnimation():setMovementEventCallFunc(function() end)
            -- self.success_animation:removeFromParentAndCleanup(true)
            self:removeNodeByTag(success_animation_tag)
        end
    end

    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function EqmEnchantView:create()
    local view = EqmEnchantView.new()
    view:init()
    return view
end

function EqmEnchantView:open()
    Notifier.regist(CmdName.EnchantSuccess,self._onEqmEnchantSuc)
    self.remain_enegry = 0
    -- self.ext_eg = 0
    if self.item then
        self.cur_lv_max_enegry = ItemManager:getInstance():getEnchantEnergyCost(self.item.enchant_lev+1)
        self.cur_lv = self.item.enchant_lev
    end
    self.real_total_enegry = 0
    self.item_total_enegry = 0
end

--新手引导动画
function EqmEnchantView:showStepAnim(param)
    if param.target == "forge_enchant_item1" then
        local item = self.batchItemIcon:getItemIconByRowCol(0,0)
        if item ~= nil then
            GuideRenderMgr:getInstance():renderMainFlag(self.sc_view,param.id,param.target,item:getRealPos())
        else
            GuideRenderMgr:getInstance():forceFinishEvent()
        end
    elseif param.target == "forge_enchant_item2" then
        local item2 = self.batchItemIcon:getItemIconByRowCol(0,1)
        local item1 = self.batchItemIcon:getItemIconByRowCol(0,0)
        if item2 ~= nil then
            GuideRenderMgr:getInstance():renderMainFlag(self.sc_view,param.id,param.target,item2:getRealPos())
        elseif item1 ~= nil then
            GuideRenderMgr:getInstance():renderMainFlag(self.sc_view,param.id,param.target,item1:getRealPos())
        else
            GuideRenderMgr:getInstance():forceFinishEvent()
        end
    elseif param.target == "enchant_btnenchant" then
        local btn = self.widget:getChildByName("enchant_btn")
        GuideRenderMgr:getInstance():renderMainFlag(btn,param.id,param.target)
    elseif param.target == "enchant_exit" then
        GuideRenderMgr:getInstance():renderMainFlag(self.widget,param.id,param.target)
    end
end

function EqmEnchantView:close()
    self.is_show_prog_anim = false
    Notifier.remove(CmdName.EnchantSuccess,self._onEqmEnchantSuc)
    self:disposeSucAnim()
end

--移除并销毁强化成功时的动画
function EqmEnchantView:disposeSucAnim()
    if self.success_animation then
        self.success_animation:getAnimation():stop()
        self.success_animation:getAnimation():setMovementEventCallFunc(function() end)
        -- self.success_animation:removeFromParentAndCleanup(true)
        self:removeNodeByTag(success_animation_tag)
        self.success_animation:release()
        self.success_animation = nil
        AnimateManager:getInstance():clear(success_animate_path)
    end

     if self.prog_bar_animation then
        self.prog_bar_animation:getAnimation():stop()
        self.prog_bar_animation:getAnimation():setMovementEventCallFunc(function() end)
        -- self.prog_bar_animation:removeFromParentAndCleanup(true)
        self:removeNodeByTag(prog_bar_animation_tag)
        self.prog_bar_animation:release()
        self.prog_bar_animation = nil
        AnimateManager:getInstance():clear(prog_bar_animate_path)
    end
end

function EqmEnchantView:isShowProgBarAnim(is_show)
        if self.is_show_prog_anim == is_show  then
            return
        end
        self.is_show_prog_anim = is_show
        
        if is_show then
            if self.prog_bar_animation == nil then
                self.prog_bar_animation = AnimateManager:getInstance():getArmature(prog_bar_animate_path,"fumoman") 
                self.prog_bar_animation:setPosition(ccp(478,255))
                self.prog_bar_animation:retain()
                self.prog_bar_animation:setTag(prog_bar_animation_tag)
            end
            -- self.prog_bar_animation:removeFromParentAndCleanup(true)
            self:removeNodeByTag(prog_bar_animation_tag)
            self:addNode(self.prog_bar_animation)
            self.prog_bar_animation:getAnimation():playWithIndex(0,-1,-1,1)
        else
            if self.prog_bar_animation ~= nil then
                self.prog_bar_animation:getAnimation():stop()
                self.prog_bar_animation:getAnimation():setMovementEventCallFunc(function() end)
                -- self.prog_bar_animation:removeFromParentAndCleanup(true)
                self:removeNodeByTag(prog_bar_animation_tag)
            end
        end
end

--是否已经达到当前附魔上限，不能再添加
function EqmEnchantView:isFull()
    return self.is_show_prog_anim
end

function EqmEnchantView:setData(item,location)
    self.energyNum = 0
	self.item = item
	self.location = location
	self.attr_flag = ItemHelper:getAttrFlagByLocation(location)
	self:changeBaseInfo()
	self:changeExtInfo()
	self:freshFeedItem()
    -- self.equip_icon:setItem(item)
    --初始化数值
  
end

function EqmEnchantView:changeBaseInfo()

    local eqms = HeroManager:getInstance():getBattleHeroEqmList(self.item.hero_id)
    local min_enchant_lv,progress = eqms:getEnchantSuitLv()

    self.labEnchatSuitProg:setText(string.format("%d/%d",progress,HeroManager.TOTAL_ENCHANT_COUNT))
    self.progSuit:setPercent(progress/HeroManager.TOTAL_ENCHANT_COUNT*100)

    if min_enchant_lv >= HeroManager.MIN_ENCHANT_LV_FOR_SUIT and 
        min_enchant_lv < HeroManager.MAX_ENCHANT_LV_FOR_SUIT then
        self.labSuitLv:setText(string.format("當前為%d星附魔套",min_enchant_lv))

        self.labSuitLvNext:setText(string.format("%d星附魔",math.min(min_enchant_lv + 1,HeroManager.MAX_ENCHANT_LV_FOR_SUIT)))
    
    elseif min_enchant_lv >= HeroManager.MAX_ENCHANT_LV_FOR_SUIT then
        self.labSuitLv:setText(string.format("當前為%d星附魔套",HeroManager.MAX_ENCHANT_LV_FOR_SUIT))
        self.labEnchatSuitProg:setText(string.format("%d/%d",HeroManager.TOTAL_ENCHANT_COUNT,HeroManager.TOTAL_ENCHANT_COUNT))
        self.progSuit:setPercent(100)
        self.labSuitLvNext:setText(string.format("%d星附魔",HeroManager.MAX_ENCHANT_LV_FOR_SUIT))
    else
        self.labSuitLvNext:setText(string.format("%d星附魔",HeroManager.MIN_ENCHANT_LV_FOR_SUIT))
        self.labSuitLv:setText("8件裝備附魔5星可獲得附魔套")
    end
end

--修改附魔等的信息显示
function EqmEnchantView:changeLvInfo(is_max)
    local cur_lev_label = self.widget:getChildByName("cur_lev_label")
    tolua.cast(cur_lev_label, "Label")
    cur_lev_label:setText(string.format("附魔:%d星",self.cur_lv))  
    cur_lev_label:setColor(ItemHelper:getEnchantColor(self.cur_lv)) 

    local cur_value_label = self.widget:getChildByName("cur_attr_num_label")
    tolua.cast(cur_value_label, "Label")
    cur_value_label:setText(string.format("+%d%%",ItemManager:getInstance():getEnchantRation(self.cur_lv)*100))   

     --改变下一级附魔预览
    local next_lev_label = self.widget:getChildByName("next_lev_label")
    tolua.cast(next_lev_label, "Label")
    next_lev_label:setText(string.format("附魔:%d星",self.cur_lv+1))
    next_lev_label:setColor(ItemHelper:getEnchantColor(self.cur_lv+1)) 

    local next_value_label = self.widget:getChildByName("next_attr_num_label")
    tolua.cast(next_value_label, "Label")
    next_value_label:setText(string.format("+%d%%",ItemManager:getInstance():getEnchantRation(self.cur_lv+1)*100)) 

    local next_attr_num_label = tolua.cast(self.widget:getChildByName("next_attr_name_label"), "Label")
    --如果已经满级
    if is_max then
        next_attr_num_label:setVisible(false)
        next_lev_label:setText("\n您的裝備附魔已滿級")
        next_value_label:setText("")
    else
        next_attr_num_label:setVisible(true)
    end
            
end

function EqmEnchantView:changeExtInfo()
    -- local powered_label = self.widget:getChildByName("Label_282")
    -- tolua.cast(powered_label, "Label")
    -- powered_label:setText(string.format("+%d",self.item.powered_lev)) 

    local cur_lev_label = self.widget:getChildByName("cur_lev_label")
    tolua.cast(cur_lev_label, "Label")
    cur_lev_label:setText(string.format("附魔:%d星",self.item.enchant_lev))   

    -- local cur_attrs = ItemManager:getInstance():getEqmPoweredAttr(self.item.mode.base_id,self.item.powered_lev)
    local cur_value_label = self.widget:getChildByName("cur_attr_num_label")
    tolua.cast(cur_value_label, "Label")
    cur_value_label:setText(string.format("+%d%%",ItemManager:getInstance():getEnchantRation(self.item.enchant_lev)*100))   

    local next_lev_label = self.widget:getChildByName("next_lev_label")
    tolua.cast(next_lev_label, "Label")
    

    -- local next_attrs = ItemManager:getInstance():getEqmPoweredAttr(self.item.mode.base_id,self.item.powered_lev+1)
    local next_value_label = self.widget:getChildByName("next_attr_num_label")
    tolua.cast(next_value_label, "Label")
    

    local tips_label = tolua.cast(self.widget:getChildByName("tips_label"), "Label")
    local cur_attr_name_label = tolua.cast(self.widget:getChildByName("cur_attr_name_label"), "Label")
    local next_attr_num_label = tolua.cast(self.widget:getChildByName("next_attr_name_label"), "Label")

    local need_team_lv = ItemManager:getInstance():getEnchantTeamLv(self.item.enchant_lev+1)  
    
    local arrow_img = tolua.cast(self.widget:getChildByName("ImageView_39"),"ImageView")

    if need_team_lv == nil then
        tips_label:setText(string.format("您的裝備附魔已滿級"))
        next_lev_label:setText("")
        next_value_label:setText("")
        next_attr_num_label:setText("")
           cur_lev_label:setText("")
       cur_value_label:setText("")
        cur_attr_name_label:setText("")
        arrow_img:setVisible(false)
    elseif need_team_lv > CharacterManager:getInstance():getTeamData():getLev() then
        tips_label:setText(string.format("您的裝備附魔已滿，戰隊等級提升至%d級\n可將裝備附魔至%d星哦。",
                            need_team_lv,self.item.enchant_lev+1))
        next_lev_label:setText("")
        next_value_label:setText("")
        next_attr_num_label:setText("")
        cur_lev_label:setText("")
       cur_value_label:setText("")
        cur_attr_name_label:setText("")
        arrow_img:setVisible(false)
    else
        tips_label:setText("")
        next_lev_label:setText(string.format("附魔:%d星",self.item.enchant_lev+1))
        next_value_label:setText(string.format("+%d%%",ItemManager:getInstance():getEnchantRation(self.item.enchant_lev+1)*100)) 

        local attr_flag = ItemHelper:getAttrFlagById(self.item.mode.base_id)
        local attr_name = AttrHelper:getAttrNameByFlag(attr_flag)..":"
        cur_attr_name_label:setText(attr_name)
        next_attr_num_label:setText(attr_name)
        arrow_img:setVisible(true)
    end

    self.ext_eg = self.item.enchant_energy
    self.cur_lv = self.item.enchant_lev 
    self.cur_lv_max_enegry = ItemManager:getInstance():getEnchantEnergyCost(self.item.enchant_lev+1)
    loading_bar:setPercent(self.ext_eg/self.cur_lv_max_enegry*100)
    locading_bar_label:setText(string.format("%d/%d",self.ext_eg,self.cur_lv_max_enegry))
 
end

function EqmEnchantView:setScrollHeight(itemNum) --设置滚动层高度
    local innerWidth = self.sc_view:getSize().width
    local innerHeight = math.ceil(itemNum/def_icon_num)*def_icon_height --滚动框高度由物品个数决定
        
    if  innerHeight<def_sc_height then
        innerHeight = def_sc_height
    end 
    
    self.sc_view:setInnerContainerSize(CCSize(innerWidth, innerHeight))

end 


--刷新可喂养物品数据
function EqmEnchantView:freshFeedItem()

	self.feed_item_list = ItemManager:getInstance():findEnchantItem() --当前可以附魔的物品数组
    -- local item_num = #item_arrs
    -- self:setScrollHeight(item_num)

    -- local tempChildArr = self.sc_view:getChildren()
    -- self.enchant_icon_arr:addObjectsFromArray(tempChildArr) 
    
    -- self.sc_view:removeAllChildren()

    -- local innerHeight = self.sc_view:getInnerContainerSize().height   
    -- local pos_x = 0
    -- local pos_y = 0
    -- local item_info = nil
    -- local temp_icon = nil
    -- local cur_idx = 1
    self.batchItemIcon:setData(self.feed_item_list)
    -- local function stepShow()
    --     local pos_x = 0
    --     local pos_y = 0
    --     local temp_idx = cur_idx
    --     for i=temp_idx,item_num do
    --         item_info = item_arrs[i]
    --         temp_icon = self.enchant_icon_arr:lastObject()
    --         if temp_icon == nil then 
    --             temp_icon = EnchantItem:create()
    --         else
    --             self.enchant_icon_arr:removeObject(temp_icon,false) 
    --         end
    --         pos_x = def_icon_width*((i-1)%def_icon_num)
    --         pos_y = innerHeight -(def_icon_height*math.modf((i-1)/def_icon_num))-5
    --         temp_icon:setPosition(ccp(pos_x+6,pos_y)) 
    --         self.sc_view:addChild(temp_icon)
    --         temp_icon:setData(item_info)
    --         cur_idx =cur_idx +1
    --         if cur_idx>item_num then
    --             TimerManager.removeTimer(stepShow)

    --             --新手引导事件
    --             if GuideDataProxy:getInstance().nowMainTutroialEventId == 10805 then
    --                 Notifier.dispatchCmd(GuideEvent.StepFinish,"click_btnenchant")
    --             end

    --         end
    --     end 
    -- end

    -- TimerManager.addTimer(200, stepShow, true)

	-- local tempChildArr = self.list_view:getChildren()
 --    self.enchant_item_arr:addObjectsFromArray(tempChildArr)

 --    self.list_view:removeAllItems()

 --    local temp_item = nil
 --    for i,v in pairs(item_arrs) do
 --        temp_item = self.enchant_item_arr:lastObject()
 --       if temp_item == nil then
 --           temp_item = EnchantItem:create()
 --       else
 --           self.enchant_item_arr:removeObject(temp_item,false) 
 --       end
 --      temp_item:setData(v)
	--   self.list_view:pushBackCustomItem(temp_item) 
 --    end   


    --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10805 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"click_btnenchant")
    end
end

-- 计算真实减少的能量
function EqmEnchantView:calcRealSubEnergy(sub_energy)
    -- local tmp_real_enegry = self.real_total_enegry 
    -- local tmp_item_enegry = self.item_total_enegry
    -- local real_energy = sub_energy
    -- local real_sub =  tmp_real_enegry-sub_energy
    -- local item_sub =  tmp_item_enegry-sub_energy
    
    -- if item_sub>real_sub then
    --     real_energy = sub_energy - (item_sub-real_sub)
    --     if real_energy>=0 then
    --         self.real_total_enegry = self.real_total_enegry - real_energy
    --         self.item_total_enegry = self.real_total_enegry
    --     else
    --         self.item_total_enegry = self.item_total_enegry -sub_energy
    --         return 0
    --     end
    -- end

    -- return real_energy

    if self.item_total_enegry-sub_energy>=self.real_total_enegry then
        cclog("這時候self.item_total_enegry=%d, sub_energy=%d ,self.real_total_enegry=%d",self.item_total_enegry,sub_energy,self.real_total_enegry)
        self.item_total_enegry = self.item_total_enegry-sub_energy
        return 0
    else
        local real_sub = self.real_total_enegry - (self.item_total_enegry-sub_energy)
        -- cclog("real_total_enegry=%d~~~~~~item_total_enegry=%d~~~~~~~sub_energy=%d",self.real_total_enegry, self.item_total_enegry, sub_energy)
        self.item_total_enegry = self.item_total_enegry-sub_energy
        self.real_total_enegry = self.item_total_enegry
        -- cclog("real_total_enegry=%d~~~~~~item_total_enegry=%d~~~~~~~sub_energy=%d",self.real_total_enegry, self.item_total_enegry, sub_energy)
        return real_sub
    end

end

--寻找自动喂养的物品
function EqmEnchantView:findAutoFeedItems(need_energy)

    if need_energy<=0 then
        Alert:show("您的附魔能量已滿，請進行附魔")
        return 
    end

    local feed_item_num = #self.feed_item_list
    local tmp_feed_item = nil
    local cur_auto_value = 0
    local is_full = false
    local tmp_icon = nil
    local item_quantity = 0
    local add_item_num = 0
    for i =1,feed_item_num do
        tmp_feed_item = self.feed_item_list[i]
        tmp_icon = self.batchItemIcon:getIconByItemId(tmp_feed_item.id)
        item_quantity = tmp_feed_item.quantity
        for j=1,item_quantity do
            local cur_num = tmp_icon:setFeedNum() --此参数为0，表示这个物品已经没有可附魔数量
            add_item_num = add_item_num + cur_num

            if cur_num>0 then
                cur_auto_value = cur_auto_value + tmp_feed_item.mode.enchant_energy
            end

            if cur_auto_value>=need_energy then
                is_full = true
                break
            elseif cur_num == 0 then
                break
            end
        end
        if is_full then
            break
        end
        cclog("自動餵養選中的物品")
    end

    if add_item_num==0 then
        cur_auto_value = 0
    end

    local params = {}
    params.is_auto_add = true
    params.change_type = 1
    params.auto_eg_num = cur_auto_value
    Notifier.dispatchCmd(CmdName.EqmEnchantEnergy,params)

end