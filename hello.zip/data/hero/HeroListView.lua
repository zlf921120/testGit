﻿--
-- Author: lvgansheng
-- Date: 2014-06-18 17:22:36
-- 卡牌列表界面

HeroListView =  class("HeroListView",WindowBase)
HeroListView.uiLayer = nil
HeroListView.widget = nil
HeroListView.item = nil
HeroListView.location = 0
HeroListView.card_item_dic = nil --单个卡牌
HeroListView.sc_view = nil 
HeroListView.sc_inner = nil 
HeroListView.one_item_widget = nil 

local CardListConstTab = {}
CardListConstTab.DefaultScrollHeight = 475 --滚动层的默认高度
CardListConstTab.DefaultIconWidth = 322 --卡牌元件的默认宽度
CardListConstTab.DefaultIconHeight = 146 --卡牌元件的默认高度
CardListConstTab.DefaultIconNum = 2 --一行显示2个卡牌元件

HeroListView.func_type = 0

local add_exp_suc_path = "ui/effects_ui/jingyantisheng/jingyantisheng.ExportJson"
local lev_up_suc_path = "ui/effects_ui/shengji/shengji.ExportJson"
HeroListView.add_exp_anim = nil
HeroListView.lv_up_anim = nil

function HeroListView:init()

    require("HeroItem")
    require("CustomMenu")
    require("ItemHelper")

    self.card_item_dic = CCDictionary:create()
    self.card_item_dic:retain()

	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)

    ComResMgr:getInstance():loadResByName("ui/hero/hero.plist","ui/hero/hero.pvr.ccz")
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/hero_list/hero_list.ExportJson")
    self.uiLayer:addWidget(self.widget)

    self.sc_view =  tolua.cast(self.uiLayer:getWidgetByName("hero_sc_view"), "ScrollView") 
    self.sc_view:setPositionX(self.sc_view:getPositionX()-10)
    -- self.sc_inner =  tolua.cast(self.uiLayer:getWidgetByName("Panel_123"), "Layout") 

    self.imgTitle = tolua.cast(self.uiLayer:getWidgetByName("ImageView_438"),"ImageView")
    self.division_img = self.uiLayer:getWidgetByName("hero_div_line")
    self.division_img:setVisible(false)
    self.division_img:retain()

    self.imgTitle = tolua.cast(self.uiLayer:getWidgetByName("ImageView_438"),"ImageView")

    local function menuCallback(tag)
        local pos_type = nil
        if tag == 1 then 
            pos_type = ItemHelper.limitStand.Unlimit
        elseif tag == 2 then
            pos_type = ItemHelper.limitStand.Front
        elseif tag == 3 then
            pos_type = ItemHelper.limitStand.Midle
        elseif tag == 4 then   
            pos_type = ItemHelper.limitStand.Back
        else 
            pos_type = ItemHelper.limitStand.Unlimit
        end

        self:changeConentByPosType(pos_type)
    end

    local menu_arr = {}
    table.insert(menu_arr,{txt="全部"})
    table.insert(menu_arr,{txt="前排"})
    table.insert(menu_arr,{txt="中排"})
    table.insert(menu_arr,{txt="後排"})

    self.cus_menu = CustomMenu:create()
    self.cus_menu:setData(menu_arr,menuCallback)
    self.cus_menu:alignItemsVerticallyWithPadding(15)
    self.cus_menu:setPosition(CCPoint(890,320))
    self.uiLayer:addChild(self.cus_menu)         

    self._onUpdateSingleHero = function(hero_id)
    	local temp_hero_item = self.card_item_dic:objectForKey(hero_id)
    	temp_hero_item:refresh(true)
    end

    self._onUpdateHeroListView = function()
    	self:changeConentByPosType(ItemHelper.limitStand.Unlimit)
    end

    self._onHeroInfoInit = function()
    	self:changeConentByPosType(ItemHelper.limitStand.Unlimit)
    end

    self._onPlayCallBack = function( armature, movementType, movementID )
        if movementType == AnimationMovementType.COMPLETE then
            armature:getAnimation():stop()
            armature:getAnimation():setMovementEventCallFunc(function() end)
            armature:removeFromParentAndCleanup(true)
        end
    end


    self._onHeroAddExpSuc = function(params)
        local hero_id = params.hero_id
        local play_type = params.play_type
        local hero_item = self.card_item_dic:objectForKey(hero_id)
        if play_type==1 then
            if self.lv_up_anim == nil then
                self.lv_up_anim = AnimateManager:getInstance():getArmature(lev_up_suc_path,"shengji") 
                self.lv_up_anim:setPosition(ccp(83,-90))
                self.lv_up_anim:retain()
            end
            if self.lv_up_anim:getParent() then
                cclog("已經在播放經驗增加特效")
                return
            end

            self.lv_up_anim:getAnimation():setMovementEventCallFunc(self._onPlayCallBack )
            self.lv_up_anim:removeFromParentAndCleanup(true)
            hero_item:addNode(self.lv_up_anim)
            self.lv_up_anim:getAnimation():playWithIndex(0,-1,-1,0)
            -- self.lv_up_anim:getAnimation():playWithIndex(0,-1,-1,1)
        elseif play_type==2 then
             if self.add_exp_anim == nil then
                self.add_exp_anim = AnimateManager:getInstance():getArmature(add_exp_suc_path,"jingyantisheng") 
                self.add_exp_anim:setPosition(ccp(80,-85))
                self.add_exp_anim:retain()
            end

            if self.add_exp_anim:getParent() then
                cclog("已經在播放英雄升級特效")
                return
            end

            self.add_exp_anim:getAnimation():setMovementEventCallFunc(self._onPlayCallBack )
            self.add_exp_anim:removeFromParentAndCleanup(true)
            hero_item:addNode(self.add_exp_anim)
            self.add_exp_anim:getAnimation():playWithIndex(0,-1,-1,0)
            -- self.add_exp_anim:getAnimation():playWithIndex(0,-1,-1,1)
        end
    end

    self._onUpdateTipsPoint = function(params)
        local tempHeroItem = nil
        local status 
        if params==nil then
            return
        end
        self:checkUpdateTips(params)
    end
    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function HeroListView:create()
    local attr_view = HeroListView.new()
    return attr_view    
end

function HeroListView:checkUpdateTips(params)
    for i,hero_id in pairs(params) do
         tempHeroItem = self.card_item_dic:objectForKey(hero_id)
         tempHeroItem:isShowTipsPoint(HeroManager:getInstance():isShowTipsPoint(hero_id))
         cclog("更新綠色點數據")
    end
end

--新手引导动画
function HeroListView:showStepAnim(param) 
    if param.target == "hero_exitlist" then
        GuideRenderMgr:getInstance():renderMainFlag(self.close_btn,param.id,param.target)
    elseif param.target == "herolist_view" then
        GuideRenderMgr:getInstance():renderMainFlag(self.sc_view,param.id,param.target)
    elseif param.target == "hero_heroitem" then
        self.guideParms = param
    end
end

function HeroListView:open()

    if self.params then
        self.func_type = self.params.func_type or 0
        self.use_item_id = self.params.use_item_id or 0

        if self.func_type == ItemHelper.func_type.exp_medicine then
            self.imgTitle:loadTexture("i18n_hero_list_medicine.png",UI_TEX_TYPE_PLIST)
        end
    else
        self.func_type = 0
        self.use_item_id = 0

        self.imgTitle:loadTexture("i18n_hero_list_ui_title_txt.png",UI_TEX_TYPE_PLIST)
    end
    
	Notifier.regist(CmdName.HeroInfoInit, self._onHeroInfoInit)
    Notifier.regist(CmdName.UpdateHeroListView, self._onUpdateHeroListView)
    Notifier.regist(CmdName.UpdateHeroInfo, self._onUpdateSingleHero)
    self:changeConentByPosType(ItemHelper.limitStand.Unlimit)	
    Notifier.regist(CmdName.HeroAddExpSuc, self._onHeroAddExpSuc)
    Notifier.regist(CmdName.UpdateGreenTipsPoint, self._onUpdateTipsPoint)

    self.cus_menu:setSelectedItem(1)

    --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10305 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"click_item")
    end
end

function HeroListView:close()
    Notifier.remove(CmdName.HeroInfoInit, self._onHeroInfoInit)
    Notifier.remove(CmdName.UpdateHeroListView, self._onUpdateHeroListView)
    Notifier.remove(CmdName.UpdateHeroInfo, self._onUpdateSingleHero)
    Notifier.remove(CmdName.HeroAddExpSuc, self._onHeroAddExpSuc)
    Notifier.remove(CmdName.UpdateGreenTipsPoint, self._onUpdateTipsPoint)
    
    if self.lv_up_anim then
        self.lv_up_anim:release()
        self.lv_up_anim:getAnimation():stop()
        self.lv_up_anim:getAnimation():setMovementEventCallFunc(function() end)
        self.lv_up_anim:removeFromParentAndCleanup(true)
        self.lv_up_anim = nil
        AnimateManager:getInstance():clear(lev_up_suc_path)
    end

    if self.add_exp_anim then
        self.add_exp_anim:release()
        self.add_exp_anim:getAnimation():stop()
        self.add_exp_anim:getAnimation():setMovementEventCallFunc(function() end)
        self.add_exp_anim:removeFromParentAndCleanup(true)
        self.add_exp_anim = nil
        AnimateManager:getInstance():clear(add_exp_suc_path)
    end

    --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10108 or
        GuideDataProxy:getInstance().nowMainTutroialEventId == 10613 then

        if GuideDataProxy:getInstance().nowMainTutroialEventId == 10108 then --特殊处理 需要关掉副本描述面板
            WindowCtrl:getInstance():close(CmdName.DungeonPerpare)
        end
        
        Notifier.dispatchCmd(GuideEvent.StepFinish,"exit_heropanel")
    end
end

function HeroListView:extTouch(enable)
    self.cus_menu:setTouchEnabled(enable)
end

function HeroListView:extTouchPriority(value)
    self.cus_menu:setTouchPriority(value)
end

-- 通过卡牌站位显示相应内容
function HeroListView:changeConentByPosType(pos_type)
    local activeArr,unactiveArr = HeroManager:getInstance():getHeroArrByPos(pos_type)
    self.sc_view:removeAllChildren()
    local tempHeroItem = nil
    local card_item_dic = self.card_item_dic
    local card_info = nil

    self:setScrollHeight(#activeArr,#unactiveArr)

    local innerHeight =  self.sc_view:getInnerContainerSize().height 
    -- local def_mode = HeroItem:create()
    if self.one_item_widget == nil then
        self.one_item_widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/hero_list_item/hero_list_item.ExportJson")
         self.one_item_widget:retain()
    end

    local active_count = #activeArr
    local cur_active_idx = 1
    local ext_posx = 13

    local function stepShowActive()
        local pos_x = 0
        local pos_y = 0
        local temp_idx = cur_active_idx
        for i=temp_idx,active_count do
            card_info = activeArr[i]
            tempHeroItem = card_item_dic:objectForKey(card_info.base_id)
            if tempHeroItem == nil then 

                tempHeroItem = HeroItem:create(self.one_item_widget)
                tempHeroItem:setData(card_info)
                tempHeroItem:changeBaseInfo()
                card_item_dic:setObject(tempHeroItem,card_info.base_id)
                
            end
            if tempHeroItem:getParent() == nil then
                self.sc_view:addChild(tempHeroItem)
            end

            if card_info.base_id == 10000 then 
                --新手引导事件
                if GuideDataProxy:getInstance().nowMainTutroialEventId == 10102 then
                    Notifier.dispatchCmd(GuideEvent.StepFinish,"open_heropanel")
                elseif GuideDataProxy:getInstance().nowMainTutroialEventId == 10403 then
                    Notifier.dispatchCmd(GuideEvent.StepFinish,"open_heropanel")
                elseif GuideDataProxy:getInstance().nowMainTutroialEventId == 10606 then
                    Notifier.dispatchCmd(GuideEvent.StepFinish,"open_heropanel")
                elseif GuideDataProxy:getInstance().nowMainTutroialEventId == 10305 then
                    Notifier.dispatchCmd(GuideEvent.StepFinish,"click_item")
                end
                if self.guideParms and self.guideParms.target == "hero_heroitem" then
                    tempHeroItem:showStepAnim(self.guideParms)
                end
            end

            tempHeroItem:refresh(true)
            pos_x = CardListConstTab.DefaultIconWidth*((i-1)%CardListConstTab.DefaultIconNum)
            pos_y = innerHeight -(CardListConstTab.DefaultIconHeight*math.modf((i-1)/CardListConstTab.DefaultIconNum))+5
            tempHeroItem:setPosition(ccp(pos_x+ext_posx,pos_y)) 
            tempHeroItem:setFuncType(self.func_type, self.use_item_id) 
            cur_active_idx = cur_active_idx + 1

            if cur_active_idx>active_count then
                TimerManager.removeTimer(stepShowActive)
            end

            if cur_active_idx-temp_idx>5 then
                break
            end

        end 
    end


    TimerManager.addTimer(100, stepShowActive, true)


    --已激活卡牌所占的高度
    local ext_height = math.ceil(#activeArr/CardListConstTab.DefaultIconNum)*CardListConstTab.DefaultIconHeight
    ext_height = ext_height +20
    
    --分割条
    self.division_img:setPositionY(innerHeight - ext_height)
    self.division_img:setVisible(true)
    self.sc_view:addChild(self.division_img)

    ext_height = ext_height + 28

    local unactive_count = #unactiveArr
    local cur_unactive_idx = 1

    local function stepShowUnactive( )
        local pos_x = 0
        local pos_y = 0
        local temp_idx = cur_unactive_idx
        for j=temp_idx,unactive_count do
            card_info = unactiveArr[j]
            tempHeroItem = card_item_dic:objectForKey(card_info.base_id)
            if tempHeroItem == nil then 
                tempHeroItem = HeroItem:create(self.one_item_widget)
                tempHeroItem:setData(card_info)
                tempHeroItem:changeBaseInfo()
                card_item_dic:setObject(tempHeroItem,card_info.base_id)
            end

            if tempHeroItem:getParent() == nil then
                self.sc_view:addChild(tempHeroItem)
            end

            tempHeroItem:refresh(false)
            pos_x = CardListConstTab.DefaultIconWidth*((j-1)%CardListConstTab.DefaultIconNum)
            pos_y = innerHeight - ext_height- (CardListConstTab.DefaultIconHeight*math.modf((j-1)/CardListConstTab.DefaultIconNum))+5
            tempHeroItem:setPosition(ccp(pos_x+ext_posx,pos_y)) 
            cur_unactive_idx = cur_unactive_idx + 1

            if cur_unactive_idx>unactive_count then
                TimerManager.removeTimer(stepShowUnactive)
            end

            if cur_unactive_idx-temp_idx>5 then
                break
            end
        end 
    end

    TimerManager.addTimer(130, stepShowUnactive, true)

end

function HeroListView:setScrollHeight(active_num,unactive_num) --设置滚动层高度
    local innerWidth =  self.sc_view:getSize().width
     
    local innerHeight =(math.ceil(active_num/CardListConstTab.DefaultIconNum)+
                        math.ceil(unactive_num/CardListConstTab.DefaultIconNum))*
                        CardListConstTab.DefaultIconHeight + 40 --滚动框高度由物品个数决定
        
    if  innerHeight < CardListConstTab.DefaultScrollHeight then
        innerHeight = CardListConstTab.DefaultScrollHeight
    end 

     self.sc_view:setInnerContainerSize(CCSize(innerWidth, innerHeight))

end 