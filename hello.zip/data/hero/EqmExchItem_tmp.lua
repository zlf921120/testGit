--
-- Author: lvgansheng
-- Date: 2014-07-02 19:42:35
-- 锻造装备替换界面元件
EqmExchItem = class("EqmExchItem",function() return Widget:create() end)
EqmExchItem.item = nil --元件关联的物品
EqmExchItem.pos = nil --元件关联的英雄站位
EqmExchItem.view_type = 0 --当前是从锻造的哪个标签页进来的
EqmExchItem.item_icon = 0 --当前是从锻造的哪个标签页进来的

function EqmExchItem:init(widget_seed)
	--初始化界面相关		
    -- self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/equip/eqm_exch_item/eqm_exch_item.ExportJson")
	self.widget = widget_seed:clone()
    self:addChild(self.widget)
    self.widget:setPosition(ccp(0,-self.widget:getSize().height))

    self.item_icon = ItemIcon:create()
    self.item_icon:setScale(0.8)
    self.item_icon:setPosition(ccp(67,-68))
    self:addChild(self.item_icon)

    self.gem_icon_dic = {}

    local btn = self.widget:getChildByName("bg_btn")
    btn:addTouchEventListener(function(sender, eventType )
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Eqm_Forge_View,{self.item,self.item.mode.item_type, self.view_type})
            --新手引导事件
            if GuideDataProxy:getInstance().nowMainTutroialEventId == 10504 or
                GuideDataProxy:getInstance().nowMainTutroialEventId == 10616 or
                GuideDataProxy:getInstance().nowMainTutroialEventId == 10804 then
                
                Notifier.dispatchCmd(GuideEvent.StepFinish,"click_forgeitem")
            end
        end
    end)

    self.team_lv_label = self.widget:getChildByName("team_lv_label")
    tolua.cast(self.team_lv_label, "Label")

    -- local identify_label = self.widget:getChildByName("identify_label")
    -- identify_label:setPositionX(identify_label:getPositionX()+12)
end

function EqmExchItem:create(widget_seed)
	local exch_item = EqmExchItem.new()
	exch_item:init(widget_seed)
	return exch_item
end

function EqmExchItem:setData(item,pos,view_type)
    self.item = item
    self.pos = pos
    self.view_type = view_type
    self:changeContent()
    self.item_icon:setBaseId(item.mode.base_id)
end

function EqmExchItem:refreseh()
    if self.item then
        self:changeContent()
        self.item_icon:setBaseId(self.item.mode.base_id)
    end
end

function EqmExchItem:changeContent()

	local item_name_label = self.widget:getChildByName("item_name_label")
    tolua.cast(item_name_label, "Label")
    item_name_label:setColor(ItemHelper:getColorByQuality(self.item.mode.quality))
    item_name_label:setText(self.item.mode.name) 

    self.team_lv_label:setText(string.format("等級：%d",self.item.mode.limit_lev))

    local identify_label = self.widget:getChildByName("identify_label")
    tolua.cast(identify_label, "Label")
    if ItemManager:getInstance():canIdentify(self.item) then
        identify_label:setEnabled(true)
        if self.item.total_identify_stars > 0 then
            identify_label:setText(string.format("%d星",self.item.total_identify_stars))
        else
            identify_label:setText("未鑒定")
        end
    else
        identify_label:setEnabled(false)
    end

    --设置附魔特效
    self.item_icon:setEnchanteffect(self.item.enchant_lev)
    self.item_icon:setPowerNum(self.item.powered_lev)
    -- self.item_icon:setVisible(false)

    local gem_item_icon = nil
    local gems = self.item.gems
    local gem_dis = 130
    local temp_gem_data = nil
    for gem_idx =1,3 do
        gem_item_icon = self.gem_icon_dic[gem_idx]
         if gems[gem_idx] then
            if gem_item_icon == nil then
                gem_item_icon = ItemIcon:create()
                gem_item_icon:setScale(0.4)
                gem_item_icon:isShowNumLabel(false)
                self:addChild(gem_item_icon)
                gem_item_icon:retain()
                self.gem_icon_dic[gem_idx] = gem_item_icon
            end

            gem_item_icon:setBaseId(gems[gem_idx])
             gem_item_icon:setVisible(true)
             gem_item_icon:setPositionX(gem_dis+5)
             gem_item_icon:setPositionY(-102)
             gem_dis = gem_dis+60
         elseif gem_item_icon then
             gem_item_icon:setVisible(false)
         end
    end
    -----------------偏移位置--------------------------------------
    if Helper.numEnCnElem( self.item.mode.name ) > 5 then
        self.team_lv_label:setPositionY( 117 - 15)
    else
        self.team_lv_label:setPositionY( 117 )
    end
end
