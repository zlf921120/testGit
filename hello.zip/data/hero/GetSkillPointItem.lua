--
-- Author: lvgansheng
-- Date: 2014-09-04 19:25:20
-- 获取技能点界面单项

GetSkillPointItem = class("GetSkillPointItem", DisplayUtil.newLayout)

function GetSkillPointItem:init()
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/skill_point_item/skill_point_item.ExportJson")
    self:addChild(self.widget)
    -- self.widget:setPosition(ccp(0,-self.widget:getSize().height))

    self:setSize(CCSize(330,100))
end

function GetSkillPointItem:create()
	local one_item = GetSkillPointItem.new()
	one_item:init()
	return one_item
end

function GetSkillPointItem:setData(str)
	local desc_label = tolua.cast(self.widget:getChildByName("desc_label"), "Label")
	desc_label:setText(str)
end

