-- 
-- Author: lvgansheng
-- Date: 2014-11-01 11:50:57
-- 装备掉落引导界面

FindEqmView = class("FindEqmView", WindowBase)
FindEqmView.is_dispose = true
FindEqmView.isShowView = false

function FindEqmView:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
    if self.fashionImgView then
      self.fashionImgView:dispose()
      self.fashionImgView = nil
    end
end

function FindEqmView:init()
  require("FindEqmItem")
  require("ActivateDataProxy")
  require("ActivateCfg")
	require("ActivateLocalReader")
  require "FashionImgView"

  ActivateLocalReader:getInstance():loadInProxy()
  
  ComResMgr:getInstance():loadRes("ui/dungeon/chapter/dgui_build.plist","ui/dungeon/chapter/dgui_build.pvr.ccz")
  ComResMgr:getInstance():loadRes("ui/activate/activate.plist","ui/activate/activate.pvr.ccz")

  self.find_item_arr = CCArray:create()
  self.find_item_arr:retain()

  self.uiLayer = TouchGroup:create() 
  self:addChild(self.uiLayer)
	
  self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/find_eqm/find_eqm.ExportJson")
  self.uiLayer:addWidget(self.widget)

  local return_btn = self.uiLayer:getWidgetByName("return_btn")
  return_btn:addTouchEventListener(function(sender,event_type)
  	 if event_type == ComConstTab.TouchEventType.ended then
         WindowCtrl:getInstance():close(self.name)
      end
  end)

  self.btnShow = tolua.cast(self.uiLayer:getWidgetByName("btn_show"),"Button")
  self.btnShow:addTouchEventListener(function(sender,event_type)
    if event_type == ComConstTab.TouchEventType.ended then
            
          self.isShowView = not self.isShowView
          if self.isShowView then
             self:createFashionCard()
             self:playAnimRight()
             self:playAnimLeft()
             self.btnShow:setTitleText("關閉時裝")
          else
             self:reset()
          end
    end
  end)

  self.panelView = tolua.cast(self.uiLayer:getWidgetByName("panel_view"),"Layout") 
  self.gem_list_view = tolua.cast(self.uiLayer:getWidgetByName("soul_gem_list_view"), "ListView")
  self.gem_list_view:setPositionX( self.gem_list_view:getPositionX()+12)

  self.soul_gem_nam_label = tolua.cast(self.uiLayer:getWidgetByName("soul_gem_nam_label"), "Label")
 -- self.num_label = tolua.cast(self.uiLayer:getWidgetByName("num_label"), "Label")
    
  self._refresh = function()
      self:changeContent()
  end
  require "ItemIcon"
  self.item_icon = ItemIcon:create()
  self.item_icon:setPosition(ccp(128,449))
  self.panelView:addChild(self.item_icon)
end

function FindEqmView:reset()
    self.panelView:stopAllActions()
    self.panelView:setPosition(ccp(226,21))
    if self.fashionImgView then
        self.fashionImgView:dispose()
        self.fashionImgView:removeFromParentAndCleanup(true)
        self.fashionImgView = nil
    end

    self.btnShow:setTitleText("查看時裝")
end

function FindEqmView:createFashionCard()
    local fashionData = HeroManager:getInstance():getCfgFashionDataByBaseId(self.item_icon_base_id)
    self.fashionImgView = FashionImgView:create(fashionData)
    self.fashionImgView:setPosition(ccp(550,120))
    self.widget:addChild(self.fashionImgView)
end

function FindEqmView:playAnimLeft()
    self.panelView:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCMoveTo:create(0.4,ccp(45,21)))
    self.panelView:runAction(CCSequence:create(arr))
end

function FindEqmView:playAnimRight()
   self.fashionImgView:stopAllActions()
   local arr = CCArray:create()
    arr:addObject(CCMoveTo:create(0.4,ccp(587,120)))
    self.fashionImgView:runAction(CCSequence:create(arr))
end

function FindEqmView:create()
	local find_view = FindEqmView.new()
	-- find_view:init()
	return find_view
end

function FindEqmView:open()
  self.find_type = self.params.find_type --引导类型

	self.hero_id = self.params.hero_id
	self.eqm_type = self.params.eqm_type
	self:changeContent()

    Notifier.regist(CmdName.DUNGEON_UPDATE_ONE_SCHEDULE,self._refresh) 
end

function FindEqmView:close()
	 Notifier.remove(CmdName.DUNGEON_UPDATE_ONE_SCHEDULE,self._refresh) 
end

function FindEqmView:changeContent()

	local hero_info = HeroManager:getInstance():getHeroInfoByBaseId(self.hero_id)
	--local item_mode = ItemManager:getInstance():getItemModelByBaseId(hero_info.soul_gem_id)
	--local item_quantity = ItemManager:getInstance():getQuantityByBaseId(hero_info.soul_gem_id)
	--local upgrade_cost_one = HeroManager:getInstance():getUpgradeCost(hero_info.cur_stars+1)

	self.soul_gem_nam_label:setText(ItemHelper:getTypeName(self.eqm_type))

	--self.item_icon:setBaseId(item_mode.base_id)

  local item_icon_base_id = 0

	local tempChildArr = self.gem_list_view:getChildren()
	self.find_item_arr:addObjectsFromArray(tempChildArr)
	self.gem_list_view:removeAllItems()

  local eqm_guide_list = nil
  self.btnShow:setVisible(false)
  self.btnShow:setTouchEnabled(false)

  if self.find_type == ItemHelper.find_type.none_eqm then
    local team_lv = CharacterManager:getInstance():getTeamData():getLev()
    eqm_guide_list = HeroManager:getInstance():getFitFindEqmInfos(hero_info.pos, self.eqm_type, team_lv)

  elseif self.find_type == ItemHelper.find_type.better_eqm then
    eqm_guide_list = HeroManager:getInstance():getBetterEqmGuideInfos(self.params.hero_pos, self.eqm_type)

  elseif self.find_type == ItemHelper.find_type.upgrade_res then

      eqm_guide_list = HeroManager:getInstance():getUpgradeResInfos(self.params.res_baseid)
      item_icon_base_id = self.params.res_baseid

  elseif self.find_type == ItemHelper.find_type.pet_res then

      eqm_guide_list = HeroManager:getInstance():getPetFeedResInfos(self.params.res_baseid)
      item_icon_base_id = self.params.res_baseid

  elseif self.find_type == ItemHelper.find_type.defguard then

      eqm_guide_list = HeroManager:getInstance():getGuideGuardInfos(self.params.res_baseid)
      item_icon_base_id = self.params.res_baseid

  elseif self.find_type == ItemHelper.find_type.fashion then
    
      eqm_guide_list = HeroManager:getInstance():getGuideFashionInfos(self.params.res_baseid)
      item_icon_base_id = self.params.res_baseid

      self.btnShow:setVisible(true)
      self.btnShow:setTouchEnabled(true)
  end

  eqm_guide_list = eqm_guide_list or {}
  local num = #eqm_guide_list 
	local temp_item = nil
    for i=1,num do
        temp_item = self.find_item_arr:lastObject()
       if temp_item == nil then
           temp_item = FindEqmItem:create()
       else
           self.find_item_arr:removeObject(temp_item,false) 
       end
       temp_item:setData(eqm_guide_list[i])

        if self.find_type == ItemHelper.find_type.better_eqm then --获得 更强装备 目标图标
          item_icon_base_id = eqm_guide_list[i].target_base_id
        elseif self.find_type == ItemHelper.find_type.upgrade_res then -- 更强装备 材料图标
          item_icon_base_id = eqm_guide_list[i].base_id
        elseif self.find_type == ItemHelper.find_type.pet_res then --侍宠食物
          item_icon_base_id = eqm_guide_list[i].base_id
        elseif self.find_type == ItemHelper.find_type.defguard then --怪物
          require "ResContendManager"
          local vo = ResContendManager:getInstance():getGuardGoodsByGuardId(eqm_guide_list[i].guard_id,1)
          item_icon_base_id = vo.baseId
        elseif self.find_type == ItemHelper.find_type.fashion then
          item_icon_base_id = eqm_guide_list[i].icon_id
        elseif self.find_type == ItemHelper.find_type.none_eqm then
            item_icon_base_id = eqm_guide_list[i].icon_id
        end

      self.gem_list_view:pushBackCustomItem(temp_item) 
    end  

    if num == 0 then
        self.gem_list_view:pushBackCustomItem(FindEmptyEqmItem:create())
    end

    self.item_icon:setBaseId(item_icon_base_id)
    self.item_icon_base_id = item_icon_base_id
end

