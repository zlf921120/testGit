--
-- Author: lvgansheng
-- Date: 2014-06-18 17:44:42
-- 卡牌进阶界面

HeroUpgradeView =  class("HeroUpgradeView",WidgetBase)
HeroUpgradeView.uiLayer = nil
HeroUpgradeView.widget = nil
HeroUpgradeView.star_icons = nil

local hero_mgr = nil

function HeroUpgradeView:init()	
	self:setPositionX(32)
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/hero_upgrade/hero_upgrade.ExportJson")
    self:addChild(self.widget)

    hero_mgr = HeroManager:getInstance()

    self.star_icons = {}
    local star_icon = nil
    local star_name = nil
    for i=1,HeroHelper.MaxStar do
    	star_name = string.format("star_%d",i)
    	star_icon = tolua.cast(self.widget:getChildByName(star_name), "ImageView")
    	self.star_icons[i] = star_icon
	end

	self.attr_grow_label = tolua.cast(self.widget:getChildByName("attr_grow_label"), "Label")
	self.loading_bar = tolua.cast(self.widget:getChildByName("upgrade_loging_bar"), "LoadingBar")
	self.loading_bar_label = tolua.cast(self.widget:getChildByName("loading_bar_label"), "Label")
	self.panelView = tolua.cast(self.widget:getChildByName("panel_view"),"Label")
	self.cost_label = tolua.cast(self.panelView:getChildByName("cost_label"), "Label")
	self.labNextFix = tolua.cast(self.widget:getChildByName("lab_next_fix"),"Label")
	self.labNextProp = tolua.cast(self.widget:getChildByName("lab_next_prop"),"Label")
	self.labTips = tolua.cast(self.widget:getChildByName("lab_tips"),"Label")

	local upgrade_btn = self.widget:getChildByName("upgrade_btn")
	upgrade_btn:addTouchEventListener(function(sender,event_type)
		if event_type == ComConstTab.TouchEventType.ended then
			HeroManager:getInstance():sendHeroUpgrade(self.hero_id)
		end
	end)

	self.btnPreview = tolua.cast(self.widget:getChildByName("btn_preview"),"Button")
	self.btnPreview:addTouchEventListener(function(sender,event_type)
		if event_type == ComConstTab.TouchEventType.ended then
			WindowCtrl:getInstance():open(CmdName.HeroUpgradePreview,{hero_id=self.hero_id})
		end
	end)

	local function openFindSoulGemView(sender,event_type)
		if event_type == ComConstTab.TouchEventType.ended then
           WindowCtrl:getInstance():open(CmdName.FindSoulGemView,self.hero_id)
        end
    end

    local gem_icon = tolua.cast(self.widget:getChildByName("ImageView_128"),"ImageView")
    gem_icon:setTouchEnabled(true)
    gem_icon:addTouchEventListener(openFindSoulGemView)

	local find_stone_btn = self.widget:getChildByName("find_stone_btn")
	find_stone_btn:addTouchEventListener(openFindSoulGemView)

	self.onUpdateHeroInfo = function(hero_id)
		if self.hero_id == hero_id then
			self:setData(hero_id)
		end
	end

	self._onRoleAssetUpdate = function()
		self:changeContent()
	end

end

function HeroUpgradeView:create()
	local upgrade_view = HeroUpgradeView.new()
	upgrade_view:init()
	return upgrade_view	
end

function HeroUpgradeView:open()
	 Notifier.regist(CmdName.UpdateHeroInfo, self.onUpdateHeroInfo) 
	 Notifier.regist(CmdName.RSP_UPDATE_ROLE_ASSET,self._onRoleAssetUpdate)
end

function HeroUpgradeView:close()
	 Notifier.remove(CmdName.UpdateHeroInfo, self.onUpdateHeroInfo) 
	 Notifier.remove(CmdName.RSP_UPDATE_ROLE_ASSET,self._onRoleAssetUpdate)
end

function HeroUpgradeView:setData(hero_id)
	self.hero_id = hero_id
	self:changeContent()
end


function HeroUpgradeView:changeContent()
	local hero_info = hero_mgr:getHeroInfoById(self.hero_id)
	local hero_star = hero_info.cur_stars
	
	--设置星星
	local star_icon = nil
	for i=1,HeroHelper.MaxStar do
		if hero_star<i then
			self.star_icons[i]:setVisible(false)
		else
			self.star_icons[i]:setVisible(true)
			self.star_icons[i]:loadTexture(HeroHelper.getStarResPath(hero_star), UI_TEX_TYPE_PLIST)
		end
	end

	--设置成长系数
	self.attr_grow_label:setText(string.format("%d%%",hero_mgr:getStarRatioOne(hero_star)*100))

	--设置消耗金币及灵魂石进度条
	local one_cost = hero_mgr:getUpgradeCost(hero_star+1)
	if one_cost then
		local item_quantity = ItemManager:getInstance():getQuantityByBaseId(hero_info.soul_gem_id)
		self.cost_label:setText(one_cost.cost_coin)
		if one_cost.cost_coin>CharacterManager:getInstance():getAssetData():getGold() then
			self.cost_label:setColor(ItemHelper.colors.red)
		else
			self.cost_label:setColor(ItemHelper.colors.yellow)
		end
		local perc_num = item_quantity/one_cost.soul_gem*100
		if perc_num>100 then
			perc_num = 100
		end
		self.loading_bar:setPercent(perc_num)
		self.loading_bar_label:setText(string.format("%d/%d",item_quantity,one_cost.soul_gem))
		
		self.labNextProp:setText(string.format("%d%%",hero_mgr:getStarRatioOne(hero_star+1)*100))
		self.labNextFix:setVisible(true)
		self.labNextProp:setVisible(true)
		self.panelView:setVisible(true)
		self.labTips:setVisible(false)
	else
		self.cost_label:setText("英雄飛升後可繼續升階")
		self.loading_bar:setPercent(0)
		self.loading_bar_label:setText("當前最高階")

		self.labNextFix:setVisible(false)
		self.labNextProp:setVisible(false)
		self.panelView:setVisible(false)
		self.labTips:setVisible(true)
	end
end