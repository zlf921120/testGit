--
-- Author: lvgansheng
-- Date: 2014-06-23 15:10:17
-- 卡牌元件


HeroItem = class("HeroItem",function() return Widget:create() end)
HeroItem.data = nil
HeroItem.hero_icon = nil
HeroItem.func_type = 0
HeroItem.acti_effect = nil --英雄可以激活时的特效 

local HERO_IN_BATTLE = 1
local HERO_IN_STAND_BY = 2
local HERO_CAN_ACTI = 3

local acti_effect_path = "ui/hero/effect/yingxiongbiankuangyindao/yingxiongbiankuangyindao.ExportJson"
function HeroItem:init(clone_widget)
    require("HeroIcon")
    
	--初始化界面相关		
    -- self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/hero_list_item/hero_list_item.ExportJson")
        
    self.virual_lv = 0
    self.virual_exp = 0

	self.widget = clone_widget:clone()
    self:addChild(self.widget)
    self.widget:setPosition(ccp(0,-self.widget:getSize().height))

    self.loading_bar_label = tolua.cast(self.widget:getChildByName("locading_bar_label"), "Label")
    self.loading_bar = tolua.cast(self.widget:getChildByName("hero_loading_bar"), "LoadingBar")
    self.lev_label = tolua.cast(self.widget:getChildByName("lev_label"), "Label")

    local function useItem()
      -- local result =   ItemManager:getInstance():sendItemUseReq(1,self.use_item_id, 1, self.data.base_id)
      -- if result~=false and

        self.is_batch = true
        if self.virual_lv>=CharacterManager:getInstance():getTeamData():getLev() then
            Alert:show("英雄等級不能超過戰隊等級哦")
            return
        end

        local tmp_use_item = ItemManager:getInstance():getItemById(self.use_item_id)
        if tmp_use_item==nil or self._use_item_num>=tmp_use_item.quantity then
            Alert:show("您的物品已經使用完")
            return
        end
      self._use_item_num = self._use_item_num+1
      self:showVirualExp(self.script_args)
       -- self.data.cur_lev<CharacterManager:getInstance():getTeamData():getLev() then
        TimerManager.addTimer(20,useItem)  
      -- end
    end

    local function delayBatchUseItem()
        self._use_item_num = 0
        self.is_batch = false
        TimerManager.addTimer(20,useItem)
    end

    local click_pos_x = 0
    local click_pos_y = 0
    local btn = self.widget:getChildByName("bg_btn")
    btn:addTouchEventListener(function(sender, eventType )
        if eventType == ComConstTab.TouchEventType.ended then
            if self.func_type == 0 then
                if self.data.id > 0 then 
                    WindowCtrl:getInstance():open(CmdName.Hero_View,self.data.base_id)
                    --新手引导事件
                    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10103 or
                        GuideDataProxy:getInstance().nowMainTutroialEventId == 10607 then
                        Notifier.dispatchCmd(GuideEvent.StepFinish,string.format("open_hero%d",self.data.id))
                    end
                elseif  self.solu_gem_perc<100 then
                    WindowCtrl:getInstance():open(CmdName.FindSoulGemView,self.data.base_id)
                else
                    local up_cost = HeroManager:getInstance():getUpgradeCost(self.data.cur_stars+1)
                    local cur_coin = CharacterManager:getInstance():getAssetData():getGold()
                    if cur_coin<up_cost.cost_coin then
                        Alert:show(string.format("您的金幣不足%d",up_cost.cost_coin))
                        return
                    end

                    WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()
                        HeroManager:getInstance():sendHeroUpgrade(self.data.base_id)
                    end, txt = "是否啟動當前英雄?",
                    btnOkName = "啟動"})
                end 
            elseif self.func_type == 1 then
                if self.data.id > 0 then  
                    --新手引导事件
                    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10306 then
                        Notifier.dispatchCmd(GuideEvent.StepFinish,"click_herouse")
                    end

                    if self._use_item_num==0 and self.is_batch==false then
                        ItemManager:getInstance():sendItemUseReq(1,self.use_item_id, 1, self.data.base_id)
                    elseif self.is_batch==true and self._use_item_num>0 then
                        ItemManager:getInstance():sendItemUseReq(1,self.use_item_id, self._use_item_num, self.data.base_id)
                    end
                     cclog("self._use_item_num==%d and self.is_batch==%s",self._use_item_num,self.is_batch)
                else
                    Alert:show("當前英雄未啟動，不可使用經驗藥")
                end
               
            end
            cclog("ComConstTab.TouchEventType.ended")
            self._use_item_num =0
            self.is_batch = false
            TimerManager.removeTimer(useItem)
            TimerManager.removeTimer(delayBatchUseItem)
        elseif eventType==ComConstTab.TouchEventType.began then
            if self.func_type == 1 then
                if self.data.id > 0 then 
                    TimerManager.addTimer(1000,delayBatchUseItem)
                end
            end

            local temp_af = sender:nodeToWorldTransform()
            click_pos_x = temp_af.tx
            click_pos_y = temp_af.ty
        elseif eventType==ComConstTab.TouchEventType.moved then
            -- if self.func_type and (sender:getTouchMovePos().y-click_pos_y>120 
            -- or sender:getTouchMovePos().y-click_pos_y<-120) then
            --     TimerManager.removeTimer(useItem)
            --     TimerManager.removeTimer(delayBatchUseItem)
            --      cclog("eventType==ComConstTab.TouchEventType.moved")
            -- end

            if self.func_type then
                local temp_af = sender:nodeToWorldTransform()
                if temp_af.ty-click_pos_y>120 or temp_af.ty-click_pos_y<-120 then
                    self._use_item_num =0
                    self.is_batch = false
                    TimerManager.removeTimer(useItem)
                    TimerManager.removeTimer(delayBatchUseItem)
                end
            end

        else
            local temp_af = sender:nodeToWorldTransform()
            if temp_af.ty-click_pos_y<120 or temp_af.ty-click_pos_y>-120 then
                    if self.func_type == 1 and self.data.id > 0 then  
                    --新手引导事件
                    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10306 then
                        Notifier.dispatchCmd(GuideEvent.StepFinish,"click_herouse")
                    end

                    if self.is_batch==true and self._use_item_num>0 then
                        ItemManager:getInstance():sendItemUseReq(1,self.use_item_id, self._use_item_num, self.data.base_id)
                    end
                     cclog("self._use_item_num==%d and self.is_batch==%s",self._use_item_num,self.is_batch)
                end
               
            end
            self._use_item_num =0
            self.is_batch = false            

            TimerManager.removeTimer(useItem)
            TimerManager.removeTimer(delayBatchUseItem)
            cclog("eventType==ComConstTab.TouchEventType.cancel")
        end
    end)

    self._clearTimer = function()
        TimerManager.removeTimer(useItem)
        TimerManager.removeTimer(delayBatchUseItem)
    end

    self.hero_icon = HeroIcon:create()
    self.widget:addChild(self.hero_icon,1)
    self.hero_icon:setPosition(ccp(83,70))

    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
    --绿点提示
    Notifier.regist(CmdName.UpdateGreenTipsPoint, function() self:checkShowTipsPoint() end)
end

function HeroItem:create(clone_widget)
	local hero_item = HeroItem.new()
	hero_item:init(clone_widget)
	return hero_item
end

--新手引导动画
function HeroItem:showStepAnim(param)
    if param.target == "hero_heroitem" then
        if self.data.base_id == 10000 then
            GuideRenderMgr:getInstance():renderMainFlag(self,param.id,param.target)
        end
    end
end

function HeroItem:open()
   -- Notifier.regist(CmdName.HeroAddExpSuc, self._onHeroAddExpSuc)
end

function HeroItem:close()
   -- Notifier.remove(CmdName.HeroAddExpSuc, self._onHeroAddExpSuc)
end

function HeroItem:setData(data)
    self.data = data
    self.virual_lv = self.data.cur_lev
    self.virual_exp = self.data.exp
    self.is_batch = false
    self._use_item_num=0
end

function HeroItem:setFuncType(func_type, use_item_id )
    self.func_type = func_type
    self.use_item_id = use_item_id
    self.is_batch = false
    self._use_item_num=0
    if use_item_id>0 then
        if ItemManager:getInstance():isItemInBag(use_item_id) then
            self.script_args = ItemManager:getInstance():getItemModleById(use_item_id).script_args
        else
            self.script_args = 0
        end
    end
end

function HeroItem:changeBaseInfo()

    self.hero_icon:setHeroId(self.data.base_id)

    local pos_img = self.widget:getChildByName("pos_img")
    tolua.cast(pos_img, "ImageView")

    pos_img:loadTexture(ItemHelper:getHeroPosImgName(self.data.pos),UI_TEX_TYPE_PLIST)

    local hero_name_label =  tolua.cast(self.widget:getChildByName("hero_name_label"), "Label")
    hero_name_label:setText(self.data.name)

end

function HeroItem:refresh(is_active)
    -- local lev_label = tolua.cast(self.widget:getChildByName("lev_label"), "Label")
    -- lev_label:setText(self.data.cur_lev)
    
    -- local loading_bar = tolua.cast(self.widget:getChildByName("hero_loading_bar"), "LoadingBar")
    
    -- local locading_bar_label = tolua.cast(self.widget:getChildByName("locading_bar_label"), "Label")
        
    local value_img = tolua.cast(self.widget:getChildByName("value_img"), "ImageView")

   

    if is_active == false then
        self.hero_icon:setIsActive(false)
        local one_cost = HeroManager:getInstance():getUpgradeCost(1)
        local item_quantity = ItemManager:getInstance():getQuantityByBaseId(self.data.soul_gem_id) 
        if self.loding_bar_img_path ~= "progress_bar_4.png" then
            self.loding_bar_img_path =  "progress_bar_4.png"
            self.loading_bar:loadTexture( self.loding_bar_img_path, UI_TEX_TYPE_PLIST)
        end

        -- if self.value_img_path ~= "soul_gem.png" then
        --     self.value_img_path =  "soul_gem.png"
        --     value_img:loadTexture( self.value_img_path, UI_TEX_TYPE_PLIST)
        -- end

        -- value_img:setVisible(true)
        self.solu_gem_perc = item_quantity/one_cost.soul_gem*100
        if  self.solu_gem_perc>=100 then
            self.solu_gem_perc = 100
            self:isShowActiEffect(true)
            self:setHeroStatusFlag(HERO_CAN_ACTI)
            self.hero_icon:setIsActive(true)
        end
        self.loading_bar:setPercent( self.solu_gem_perc)
        self.loading_bar_label:setText(string.format("%d/%d",item_quantity,one_cost.soul_gem))
        self.lev_label:setVisible(false)
    else
        self.virual_lv = self.data.cur_lev
        self.virual_exp = self.data.exp
        self:isShowActiEffect(false)
        self.hero_icon:setIsActive(true)
        local need_exp = HeroManager:getInstance():getLevExp(self.data.cur_lev+1)
        local exp_percent = self.data.exp/need_exp*100
        self.loading_bar_label:setText(string.format("%d%%",exp_percent))
        if self.loding_bar_img_path ~= "progress_bar_1.png" then
            self.loding_bar_img_path =  "progress_bar_1.png"
            self.loading_bar:loadTexture(self.loding_bar_img_path, UI_TEX_TYPE_PLIST)
        end

        -- if self.value_img_path ~= "hero_exp_txt.png" then
        --     self.value_img_path =  "hero_exp_txt.png"
        --     value_img:loadTexture( self.value_img_path, UI_TEX_TYPE_PLIST)
        -- end

        value_img:setVisible(false)

        self.loading_bar:setPercent(exp_percent)

        --设置星星
        self.hero_icon:updateExtInfo()

        self.lev_label:setVisible(true)
        self.lev_label:setText(string.format("Lv.%d",self.data.cur_lev))

        --设置战队中的状态
        if TeamManager:getInstance():isHeroInBattle(self.data.base_id)>0 then
            -- if self.team_status_img == nil then
            --    self.team_status_img = ImageView:create()
            --    self.team_status_img:setPosition(ccp(75,-40))
            --    self:addChild(self.team_status_img)
            -- end
            -- self.team_status_img:setVisible(true)
            -- self.team_status_img:loadTexture("i18n_tmui_battle_logo.png", UI_TEX_TYPE_PLIST)
            self:setHeroStatusFlag(HERO_IN_BATTLE)
        elseif TeamManager:getInstance():isHeroInStandBy(self.data.base_id)>0 then 
            -- if self.team_status_img == nil then
            --    self.team_status_img = ImageView:create()
            --    self.team_status_img:setPosition(ccp(75,-40))
            --    self:addChild(self.team_status_img)
            -- end
            -- self.team_status_img:setVisible(true)
            -- self.team_status_img:loadTexture("tmui_standby_logo.png", UI_TEX_TYPE_PLIST)
            self:setHeroStatusFlag(HERO_IN_STAND_BY)
        else
            -- if  self.team_status_img then
            --     self.team_status_img:setVisible(false)
            -- end
            self:setHeroStatusFlag(0)
        end
    end
    
    self:checkShowTipsPoint()
end

function HeroItem:checkShowTipsPoint()
    --检测是否有装备升级对应的英雄 要显示绿点
    local isVisible = HeroManager:getInstance():isShowTipsPoint(self.data.base_id) or
                         ItemManager:getInstance():isCanUpgradeByHeroId(self.data.base_id)
    self:isShowTipsPoint(isVisible)
end

--是否显示绿色小点
function HeroItem:isShowTipsPoint(is_visible)
    if is_visible then
        if self.tips_point_img == nil then
            self.tips_point_img = ImageView:create()
            self.tips_point_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
            self.tips_point_img:setZOrder(10)
            -- self.tips_point_img:setScale(0.7)
            self.tips_point_img:setPosition(ccp(20,-23))
            self:addChild(self.tips_point_img)
        end

        self.tips_point_img:setVisible(true)
        self:tipsPointPlayAct(self.tips_point_img)
    else
         if self.tips_point_img then
            self.tips_point_img:setVisible(false)
            self.tips_point_img:stopAllActions()
         end
    end
end

function HeroItem:isShowActiEffect(is_show)
    if is_show then
        if self.acti_effect == nil then
            self.acti_effect = AnimateManager:getInstance():getArmature(acti_effect_path,"yingxiongbiankuangyindao") 
            self.acti_effect:setPosition(ccp(175,-88))
            self.acti_effect:retain()
        end
        self.acti_effect:removeFromParentAndCleanup(true)
        self:addNode(self.acti_effect)
        self.acti_effect:getAnimation():playWithIndex(0)
    else
        if self.acti_effect then
            self.acti_effect:getAnimation():stop()
            self.acti_effect:removeFromParentAndCleanup(true)
        end
    end
end

-- local cur_path = nil
function HeroItem:setHeroStatusFlag(status)
    
    if status==0 then
        if self.team_status_img then
            self.team_status_img:setVisible(false)
        end
        self.cur_path=nil
        return
    end

    local temp_path = nil
    if status==HERO_IN_BATTLE then
        temp_path="i18n_tmui_battle_logo.png"
    elseif status==HERO_IN_STAND_BY then
        temp_path="i18n_tmui_standby_logo.png"
    elseif status==HERO_CAN_ACTI then
        temp_path="i18n_hero_can_acti_txt.png"
    end   

    if self.cur_path==temp_path then
       -- cclog("cur_path==temp_path英雄ID~~~%d~~~~%s~~~~%s",self.data.base_id,temp_path,cur_path)
        return
    end

    self.cur_path=temp_path 

    if self.team_status_img == nil then
       self.team_status_img = ImageView:create()
       self.team_status_img:setPosition(ccp(27,-72))
       self:addChild(self.team_status_img)
    end
    self.team_status_img:setVisible(true)
    self.team_status_img:loadTexture(self.cur_path, UI_TEX_TYPE_PLIST)
    -- cclog("英雄ID~~~%d",self.data.base_id)
end

function HeroItem:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

function HeroItem:clearTimer()
     self._clearTimer()
end
 
function HeroItem:showVirualExp(add_exp)
    local old_lev = self.virual_lv
    local is_max_lv = false
    self.virual_lv, self.virual_exp, is_max_lv = HeroManager:getInstance():getVirualLvExp(self.virual_lv, self.virual_exp, add_exp)
        
    if is_max_lv then
        TimerManager.removeTimer(useItem)
        TimerManager.removeTimer(delayBatchUseItem)
    end

    local exp_params = {}
    exp_params.hero_id = self.data.base_id

    if self.virual_lv>old_lev then -- 升级
        exp_params.play_type =1 
        Notifier.dispatchCmd(CmdName.HeroAddExpSuc,exp_params)
    else --没升级，只是增加经验
        exp_params.play_type =2 
        Notifier.dispatchCmd(CmdName.HeroAddExpSuc,exp_params)
    end

    local need_exp = HeroManager:getInstance():getLevExp(self.virual_lv+1)
    local exp_percent = self.virual_exp/need_exp*100
    self.loading_bar_label:setText(string.format("%d%%",exp_percent))
    self.loading_bar:setPercent(exp_percent)
    self.lev_label:setText(string.format("Lv.%d",self.virual_lv))
end