--
-- Author: lvgansheng
-- Date: 2014-06-27 15:49:25
-- 卡牌基础信息

HeroBaseAttr = class("HeroBaseAttr")
HeroBaseAttr.attrs = nil

function HeroBaseAttr:init()
	self.attrs = {}
end

function HeroBaseAttr:create()
	local attr = HeroBaseAttr.new()
	attr:init()
	return attr
end

function HeroBaseAttr:setData(attr_type,value)
	self.attrs[attr_type] = value
end

--获取某类型的属性
function HeroBaseAttr:getDataByType(attr_type)
	local value = self.attrs[attr_type] 
	if value == nil then 
		value = 0
	end

	return value
end

function HeroBaseAttr:getAttrs() 
	return self.attrs
end


