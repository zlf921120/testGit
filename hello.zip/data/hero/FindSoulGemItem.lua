--
-- Author: lvgansheng
-- Date: 2014-09-02 11:26:35
-- 寻找灵魂石单项

FindSoulGemItem = class("FindSoulGemItem", DisplayUtil.newLayout)

function FindSoulGemItem:init()   
   	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/soul_gem_item/soul_gem_item.ExportJson")
    self:addChild(self.widget)

    local bg_img = tolua.cast(self.widget:getChildByName("chapter_bg"), "ImageView")
    bg_img:setTouchEnabled(true)
    bg_img:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
	    	if self.soul_guide_data.dungeon_id==22000 then
	    		if self.is_open then
					WindowCtrl:getInstance():open(CmdName.Arena_View)
				else
					Alert:show("競技場尚未開啟")
				end
			elseif self.soul_guide_data.dungeon_id==23000 then
				if self.is_open then
					WindowCtrl:getInstance():open(CmdName.Glory_Scene)
				else
					Alert:show("星空神殿尚未開啟")
				end
			elseif self.soul_guide_data.dungeon_id==20000 then
				if self.is_open then
					WindowCtrl:getInstance():open(CmdName.Tower_Scene)
				else
					Alert:show("惡魔塔未尚開啟")
				end
			elseif self.soul_guide_data.dungeon_id==27000 then --召唤法阵
				if self.is_open then
					WindowCtrl:getInstance():open(CmdName.Lottery_Scene)
				else
					Alert:show("召喚法陣未尚開啟")
				end
			else
				if self.is_open then 
					WindowCtrl:getInstance():open(CmdName.Dungeon_View,{dungeonId=self.soul_guide_data.dungeon_id, 
													diff=self.soul_guide_data.diff})
				else
					Alert:show("該副本尚未開啟")
				end
			end
	    		
	    end
	end)

    self:setSize(CCSize(330,100))
end

function FindSoulGemItem:create()
	local one_item = FindSoulGemItem.new()
	one_item:init()
	return one_item
end

function FindSoulGemItem:setData(data)
	self.soul_guide_data = data

	self.dungeon_data = DungeonManager:getInstance():getDungeonData(self.soul_guide_data.dungeon_id, self.soul_guide_data.diff)

	local chapter_icon = tolua.cast(self.widget:getChildByName("chapter_icon"), "ImageView")
	local chapter_name_label = tolua.cast(self.widget:getChildByName("chapter_name_label"), "Label")
	local desc_label = tolua.cast(self.widget:getChildByName("desc_label"), "Label")
	local dungeon_name_label = tolua.cast(self.widget:getChildByName("dungeon_name_label"), "Label")
	local dungeon_status_label = tolua.cast(self.widget:getChildByName("dungeon_status_label"), "Label")

	self.is_open = true

	--特殊处理某些副本ID的显示
	if self.soul_guide_data.dungeon_id==22000 then
		chapter_name_label:setText("競技場")
		desc_label:setText("")
		dungeon_name_label:setText("競技場功勳商店")	
		chapter_icon:loadTexture("activate_arena.png", UI_TEX_TYPE_PLIST)
		chapter_icon:setScale(0.5)
		if ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Arena,nil,false) then
			dungeon_status_label:setText("")
		else
			dungeon_status_label:setText("未開放")
			self.is_open = false
		end
		return
	elseif self.soul_guide_data.dungeon_id==23000 then
		chapter_name_label:setText("星空神殿")
		desc_label:setText("")
		dungeon_name_label:setText("星空神殿商店")
		chapter_icon:loadTexture("activate_glory.png", UI_TEX_TYPE_PLIST)
		chapter_icon:setScale(0.5)
		if ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Glory,nil,false) then
			dungeon_status_label:setText("")
		else
			dungeon_status_label:setText("未開放")
			self.is_open = false
		end
		return
	elseif self.soul_guide_data.dungeon_id==20000 then
		chapter_name_label:setText("惡魔塔")
		desc_label:setText("")
		dungeon_name_label:setText("惡魔塔商店")
		chapter_icon:loadTexture("activate_tower.png", UI_TEX_TYPE_PLIST)
		chapter_icon:setScale(0.5)
		if ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Tower,nil,false) then
			dungeon_status_label:setText("")
		else
			dungeon_status_label:setText("未開放")
			self.is_open = false
		end
		return
	elseif self.soul_guide_data.dungeon_id==27000 then
		chapter_name_label:setText("召喚法陣")
		desc_label:setText("")
		dungeon_name_label:setText("召喚法陣")
		chapter_icon:loadTexture("activate_altar.png", UI_TEX_TYPE_PLIST)
		chapter_icon:setScale(0.5)
		if ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Altar,nil,false) then
			dungeon_status_label:setText("")
		else
			dungeon_status_label:setText("未開放")
			self.is_open = false
		end
		return
	end

	chapter_icon:setScale(0.6)
	chapter_icon:loadTexture(string.format("%s.png", self.dungeon_data._icon_name), UI_TEX_TYPE_PLIST)
	chapter_name_label:setText(string.format("第%s章",Utils.toChinese(self.dungeon_data._chapterId)))

	local cur_dung_data = DungeonManager:getInstance():isCanOpenDungeon(self.soul_guide_data.dungeon_id, self.soul_guide_data.diff)

	if cur_dung_data.is_unlimit then
		desc_label:setText(string.format("%s(無限制)",DungeonType[self.soul_guide_data.diff]))
	else
		desc_label:setText(string.format("%s(%d/%d)",
				DungeonType[self.soul_guide_data.diff],
				cur_dung_data.remainTimes,cur_dung_data.maxTimes))
	end

	dungeon_name_label:setText(self.dungeon_data._name)

	if cur_dung_data.isOpen then
		dungeon_status_label:setText("")
	else
		dungeon_status_label:setText("未開放")
		self.is_open=false
	end
end
