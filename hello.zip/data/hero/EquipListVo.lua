--
-- Author: lvgansheng
-- Date: 2014-06-13 19:20:37
-- 卡牌装备列表数据

EquipListVo = class("EquipListVo")
EquipListVo.list = nil
EquipListVo.hero_id = 0 
EquipListVo.team_pos = 0 --战队上阵位置

function EquipListVo:ctor()
	self.eqms_count = 0 --装备个数
	self.list = {}
end

--设置单个位置的装备信息
function EquipListVo:setSingleEquip(equipVo)
	if self.list[equipVo.location]==nil 
	and equipVo and equipVo.item then --是否新增的装备(目前装备放上去后，不可卸下来)
		self.eqms_count = self.eqms_count +1
	end
	self.list[equipVo.location] = equipVo
end

--获取单个位置的装备信息
function EquipListVo:getSingleEquip(location)
	return self.list[location]
end	

function EquipListVo:getEquipList()
	return self.list
end

function EquipListVo:setTeamPos(team_pos)
	self.team_pos = team_pos
end

function EquipListVo:getEqmsCount()
	return self.eqms_count
end

--获取宝石套 等级
function EquipListVo:getGemSuitLv()

	-- --未凑齐八件装备，不需要考虑宝石套
	-- if self:getEqmsCount()<8 then
	-- 	return 0,0
	-- end

	-- local min_gem_lv = 999
	-- local tmp_item = nil
	-- local gem_info = nil
	-- local item_mgr = ItemManager:getInstance()
	-- local gem_num = 0
	-- local all_gem_lv_tab = {} --存储所有宝石等级的临时表
	-- local is_enable_gem_suit = true -- 是否满足最低的宝石套条件
	-- for location,eqm_vo in pairs(self.list) do
	-- 	if eqm_vo and eqm_vo.item then
	-- 		tmp_item = eqm_vo.item
	-- 		gem_num = 0
	-- 		for gem_pos,gem_base_id in pairs(tmp_item.gems) do
	-- 			gem_info = item_mgr:getGemInfo(gem_base_id)
	-- 			if gem_info.gem_lev<min_gem_lv then
	-- 				min_gem_lv = gem_info.gem_lev
	-- 			end
	-- 			gem_num = gem_num +1
	-- 			table.insert(all_gem_lv_tab,gem_info.gem_lev)
	-- 		end

	-- 		--有装备未凑齐3块宝石，所以无法显示宝石套
	-- 		if gem_num~=3 then
	-- 			is_enable_gem_suit = false
	-- 		end

	-- 		--最低宝石等级不满足宝石套最低要求
	-- 		if min_gem_lv<HeroManager.MIN_GEM_LV_FOR_SUIT then
	-- 			is_enable_gem_suit = false
	-- 		end

	-- 	end
	-- end

	-- if is_enable_gem_suit==false then
	-- 	min_gem_lv = 0
	-- end

	-- --找出大于等于最小宝石等级的宝石数
	-- local comp_num = min_gem_lv
	-- local prog_left_count = 0
	-- if is_enable_gem_suit==false then
	-- 	comp_num = HeroManager.MIN_GEM_LV_FOR_SUIT
	-- elseif min_gem_lv==HeroManager.MAX_GEM_LV_FOR_SUIT then
	-- 	comp_num = HeroManager.MAX_GEM_LV_FOR_SUIT
	-- else
	-- 	comp_num = min_gem_lv+1
	-- end

	-- for i,tmp_gem_lv in pairs(all_gem_lv_tab) do
	-- 	if tmp_gem_lv>=comp_num then
	-- 		prog_left_count = prog_left_count +1
	-- 	end
	-- end
------------------------------------------------------
	local tmp_item = nil
	local prog_left_count = 0
	local min_gem_lv = 0
	local tmpTbl = {}
	local item_mgr = ItemManager:getInstance()

	for location,eqm_vo in pairs(self.list) do
		if eqm_vo and eqm_vo.item then
			tmp_item = eqm_vo.item
			for gem_pos,gem_base_id in pairs(tmp_item.gems) do
				gem_info = item_mgr:getGemInfo(gem_base_id)

				tmpTbl[ gem_info.gem_lev ] = tmpTbl[ gem_info.gem_lev ] or {}
				table.insert(tmpTbl[ gem_info.gem_lev ],string.format("%d_%d",gem_pos,gem_base_id))
			end
		end
	end

	--递归统计
	local function cmpGemLev(checkLev)
		local cout = 0
		for gem_lev,list in pairs(tmpTbl) do
			if gem_lev >= checkLev then
				cout = cout + #list
			end
		end
		if cout >= HeroManager.TOTAL_GEM_COUNT then
			return cmpGemLev(checkLev + 1)
		else
			return checkLev
		end
	end

	local cmp = cmpGemLev(HeroManager.MIN_GEM_LV_FOR_SUIT)
	if cmp and cmp > HeroManager.MIN_GEM_LV_FOR_SUIT then
		min_gem_lv = cmp - 1
	end

	for gem_lev,list in pairs(tmpTbl) do
		if min_gem_lv == 0 then
			if gem_lev >= HeroManager.MIN_GEM_LV_FOR_SUIT then
				prog_left_count = prog_left_count + #list
			end
		else
			if gem_lev > min_gem_lv then
				prog_left_count = prog_left_count + #list
			end
		end
	end
	return min_gem_lv,prog_left_count
end

--获取附魔套 等级
function EquipListVo:getEnchantSuitLv()

	local tmp_item = nil
	local prog_left_count = 0
	local min_enchant_lv = 0
	local tmpTbl = {}
	local item_mgr = ItemManager:getInstance()

	for location,eqm_vo in pairs(self.list) do
		if eqm_vo and eqm_vo.item then
			tmp_item = eqm_vo.item

			tmpTbl[ tmp_item.enchant_lev ] = tmpTbl[ tmp_item.enchant_lev ] or {}
			table.insert(tmpTbl[ tmp_item.enchant_lev ],tmp_item)
		end
	end

	--递归统计
	local function cmpEnchantLev(checkLev)
		local cout = 0
		for gem_lev,list in pairs(tmpTbl) do
			if gem_lev >= checkLev then
				cout = cout + #list
			end
		end
		if cout >= HeroManager.TOTAL_ENCHANT_COUNT then
			return cmpEnchantLev(checkLev + 1)
		else
			return checkLev
		end
	end

	local cmp = cmpEnchantLev(HeroManager.MIN_ENCHANT_LV_FOR_SUIT)
	if cmp and cmp > HeroManager.MIN_ENCHANT_LV_FOR_SUIT then
		min_enchant_lv = cmp - 1
	end

	for enchant_lev,list in pairs(tmpTbl) do
		if min_enchant_lv == 0 then
			if enchant_lev >= HeroManager.MIN_ENCHANT_LV_FOR_SUIT then
				prog_left_count = prog_left_count + #list
			end
		else
			if enchant_lev > min_enchant_lv then
				prog_left_count = prog_left_count + #list
			end
		end
	end
	return min_enchant_lv,prog_left_count
end