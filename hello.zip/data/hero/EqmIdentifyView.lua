--
-- Author: lvgansheng
-- Date: 2014-07-26 17:18:47
-- 装备鉴定界面
require("WidgetBase")

EqmIdentifyView =  class("EqmIdentifyView", WidgetBase)
EqmIdentifyView.equip_icon = nil
local name_label_dic = nil
local value_label_dic = nil

local total_count = 5 --总次数

local success_animate_path = "ui/effects_ui/jianding/jianding.ExportJson"

local success_animation_tag = 1211

local total_lockNum = 0

function EqmIdentifyView:init()     
    self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/equip/eqm_identify/eqm_identify.ExportJson")
    self:addChild(self.widget)

    attr_label_dic = {}
    value_label_dic = {}
    attr_label_dic[1] = tolua.cast(self.widget:getChildByName("attr_name_one_label"), "Label")
    value_label_dic[1] = tolua.cast(self.widget:getChildByName("attr_value_one_label"), "Label")
    attr_label_dic[2] = tolua.cast(self.widget:getChildByName("attr_name_two_label"), "Label")
    value_label_dic[2] = tolua.cast(self.widget:getChildByName("attr_value_two_label"), "Label")
    attr_label_dic[3] = tolua.cast(self.widget:getChildByName("attr_name_three_label"), "Label")
    value_label_dic[3] = tolua.cast(self.widget:getChildByName("attr_value_three_label"), "Label")
    attr_label_dic[4] = tolua.cast(self.widget:getChildByName("attr_name_four_label"), "Label")
    value_label_dic[4] = tolua.cast(self.widget:getChildByName("attr_value_four_label"), "Label")
    attr_label_dic[5] = tolua.cast(self.widget:getChildByName("attr_name_five_label"), "Label")
    value_label_dic[5] = tolua.cast(self.widget:getChildByName("attr_value_five_label"), "Label")


    local function onLock_btnClick(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            local attr_vo = nil
           
            attr_vo = self.item.identify_attrs[sender:getTag()]
            if attr_vo then
                ItemManager:sendIdentifyAttrLockReq(self.item.hero_id, self.location, self.item.id, attr_vo.attr_id, attr_vo.is_locked, self.item.identify_attrs)
            end         
        end
    end



    local function addLock_Btn(attr_label)
        for i=1,5 do
            name_label = attr_label[i]
            local lock_btn = Button:create()
            lock_btn:setTouchEnabled(false)
            --lock_btn:setAnchorPoint(ap)
            -- lock_btn:setContentSize(CCSize(300,30))
            -- lock_btn:addTouchEventListener(onLock_btnClick)
            lock_btn:setTag(255)                    
            lock_btn:setPosition(ccp(20,15))

            local lock_btn_touch_panel = DisplayUtil.newLayout()
                lock_btn_touch_panel:setTouchEnabled(false)
                lock_btn_touch_panel:setSize(CCSize(150,34))
               lock_btn_touch_panel:setPosition(ccp(-35,-25))    ---35,-20
                lock_btn_touch_panel:setTag(i)
                lock_btn_touch_panel:addTouchEventListener(onLock_btnClick)
                lock_btn_touch_panel:addChild(lock_btn)

            name_label:addChild(lock_btn_touch_panel)
        end
    end

    addLock_Btn(attr_label_dic)

    -- self.equip_icon = EquipIcon:create()
    -- self.equip_icon:setPosition(ccp(180,406))
    -- self:addChild(self.equip_icon)

    self.panel_reset = tolua.cast(self.widget:getChildByName("panel_reset"),"Layout")
    self.panel_identify = tolua.cast(self.widget:getChildByName("panel_identify"),"Layout")

    self.labLucky = LabelAtlas:create()
    self.labLucky:setAnchorPoint(ccp(0, 0.5))
    self.labLucky:setProperty(0,"ui/digit/guild_fight_atk_num.png",24,31,"0")
    self.labLucky:setPosition(ccp(328,248))
    self.widget:addChild(self.labLucky)

    self.labStar = LabelAtlas:create()
    self.labStar:setAnchorPoint(ccp(0, 0.5))
    self.labStar:setProperty(0,"ui/digit/guild_fight_atk_num.png",24,31,"0")
    self.labStar:setPosition(ccp(637,248))
    self.widget:addChild(self.labStar)

    self.reset_identify_btn = self.panel_reset:getChildByName("btn_reset")
    self.identify_btn = self.panel_identify:getChildByName("identify_btn")
    local last_click_time =0 
    local function onSendIdentifyReq(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            local function progress()
                local params = {}
                if self.item.mode.quality < ItemHelper.itemQuality.Purple then
                    params["txt"] ="很遺憾的通知你，紫色及以上品質裝備才可鑒定"
                    WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
                    return 
                end

                if self.item.identify_left_num == 0 then
                    -- params["txt"] ="悄悄告訴你,該裝備鑒定次數已滿"
                    -- WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
                    Alert:show("裝備鑒定次數已滿5次哦")
                    return         
                end
                --防止太频繁点击
                -- if os.clock()-last_click_time<1 then
                --     return
                -- end

                last_click_time = os.clock()
                local cost_tab = ItemManager:getInstance():getIdentifyCostByTime(6-self.item.identify_left_num)  --鉴定的钻石花费
                local cost_lock_tab = ItemManager:getInstance():getIdentifyLockCostByNum(total_lockNum)          --鉴定锁的钻石费用
                local totalCost_diamond = 0  --鉴定总花费
                if cost_lock_tab then
                    totalCost_diamond = cost_tab.cost_diamond + cost_lock_tab.addt_diamond
                    else
                    totalCost_diamond = cost_tab.cost_diamond
                end
                --二次确认
                if totalCost_diamond>0 then

                    if totalCost_diamond>CharacterManager:getInstance():getAssetData():getDiamond() then
                        Alert:show("您的鑽石不足")
                        return
                    end
                    local params = {}
                        params["txt"] = string.format("您確定要花費%d鑽石鑒定裝備嗎",totalCost_diamond)

                    params.okFunc = function()
                        -- 发送鉴定协议
                         ItemManager:getInstance():sendIdentifyReq(self.item.hero_id, self.location, self.item.id)
                    end
                    WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
                else
                    ItemManager:getInstance():sendIdentifyReq(self.item.hero_id, self.location, self.item.id)
                end
            end

            ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Authenticate,progress) --判断该功能是否开放
            
        end
    end
    self.identify_btn:addTouchEventListener(onSendIdentifyReq)

    -- local exch_btn = self.widget:getChildByName("exch_btn")
    -- local function onExchBtnClick(sender, eventType)
    --     if eventType == ComConstTab.TouchEventType.ended then
    --        WindowCtrl:getInstance():open(CmdName.EqmExchView,HeroHelper.forgePanelType.identify)
    --     end
    -- end
    -- exch_btn:addTouchEventListener(onExchBtnClick)

    self.reset_identify_btn:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            -- local resetInfo = ItemManager:getInstance():getEqmIdentifyResetInfo( self.item.mode.base_id )
            -- local resetCostInfo = ItemManager:getInstance():getItemModelByBaseId( resetInfo.cost_base_id )
            -- local hasNum = ItemManager:getInstance():getQuantityByBaseId( resetInfo.cost_base_id )
            -- local resetCostNumLabColor = nil
            -- if resetInfo.cost_num <= hasNum then --满足材料
            --     resetCostNumLabColor = ccc3(11,212,81)
            -- else
            --     resetCostNumLabColor = ccc3(255,0,0)
            -- end

            -- local params = {}
            -- params.labAlign = kCCVerticalTextAlignmentBottom
            -- params.txt = "（重置後第一次鑒定免費）"
            -- params.rtf ={{txt="消耗"},{txt= tostring(resetInfo.cost_num),color=ccc3(245,204,85)},{txt="個"},
            --             {txt= resetCostInfo.name .. "（當前剩餘"},{txt= tostring(hasNum),color=resetCostNumLabColor},{txt="個）"},
            --             {txt="可重置此裝備的鑒定資料，重置後原來的鑒定屬性和已鑒定次數將被清空，是否確定重置鑒定？"}}
            -- -- params.isOkClose = false
            -- params.okFunc = function()
            --     local param = {}
            --     param.hero_id = self.item.hero_id
            --     param.item_id = self.item.id
            --     param.eqm_pos = self.item.mode.item_type
            --     ItemManager:getInstance():sendEquipIdentifyReset(param)
            -- end
            -- WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)

            WindowCtrl:getInstance():open(CmdName.EqmIdentifyResetPanel,{item_data = self.item})
        end
    end)

     self._onEqmIdentifySuc = function (item_id )
        if self.item.id ~= item_id then
            return 
        end

        --播放强化成功特效
        if self.success_animation == nil then
            self.success_animation = AnimateManager:getInstance():getArmature(success_animate_path,"jianding") 
            self.success_animation:setPosition(ccp(245,406))
            self.success_animation:retain()
            self.success_animation:setTag(success_animation_tag)
        end

        self.success_animation:getAnimation():setMovementEventCallFunc(self._onPlayCallBack )
        -- self.success_animation:removeFromParentAndCleanup(true)
        self:removeNodeByTag(success_animation_tag)
        self:addNode(self.success_animation)
        self.success_animation:getAnimation():playWithIndex(0)

        self.item = ItemManager:getInstance():getEquipInfoById(item_id)

        table.sort(self.item.identify_attrs, function(a, b) if a.is_locked > b.is_locked then return true end end )
        self:changeExtInfo() 

        --新手引导事件
        if GuideDataProxy:getInstance().nowMainTutroialEventId == 10618 then
            Notifier.dispatchCmd(GuideEvent.StepFinish,"click_identity_btnidentity")
        end
    end

     self._onPlayCallBack = function( armature, movementType, movementID )
        if movementType == AnimationMovementType.COMPLETE then
            self.success_animation:getAnimation():stop()
            self.success_animation:getAnimation():setMovementEventCallFunc(function() end)
            -- self.success_animation:removeFromParentAndCleanup(true)
            self:removeNodeByTag(success_animation_tag)
        end
    end

    self._onEqmIdentifyResetSuc = function(item_id)
        if self.item.id ~= item_id then
            return 
        end
        self:changeExtInfo() 
    end

    self._onEqmIdentifyAttrLockSuc = function(item_id)
        if self.item.id ~= item_id then
            return 
        end
        self:changeExtInfo() 
    end


    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function EqmIdentifyView:create()
    local view = EqmIdentifyView.new()
    view:init()
    return view
end

--新手引导动画
function EqmIdentifyView:showStepAnim(param)
    if param.target == "identity_btnidentity" then
        GuideRenderMgr:getInstance():renderMainFlag(self.identify_btn,param.id,param.target)
    elseif param.target == "identity_exit" then
        GuideRenderMgr:getInstance():renderMainFlag(self.widget,param.id,param.target)
    end
end

function EqmIdentifyView:open()
    Notifier.regist(CmdName.IdentifySuccess,self._onEqmIdentifySuc)
    Notifier.regist(CmdName.IdentifyResesSuc,self._onEqmIdentifyResetSuc)
    Notifier.regist(CmdName.IdentifyAttrLockSuc,self._onEqmIdentifyAttrLockSuc)
     --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10617 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"click_btnidentity")
    end
end

function EqmIdentifyView:close()
     Notifier.remove(CmdName.IdentifySuccess,self._onEqmIdentifySuc)
     Notifier.remove(CmdName.IdentifyResesSuc,self._onEqmIdentifyResetSuc)
     Notifier.remove(CmdName.IdentifyAttrLockSuc,self._onEqmIdentifyAttrLockSuc)
     self:disposeSucAnim()
    
end

--移除并销毁强化成功时的动画
function EqmIdentifyView:disposeSucAnim()
    if self.success_animation then
        self.success_animation:getAnimation():stop()
        self.success_animation:getAnimation():setMovementEventCallFunc(function() end)
        -- self.success_animation:removeFromParentAndCleanup(true)
        self:removeNodeByTag(success_animation_tag)
        self.success_animation:release()
        self.success_animation = nil
        AnimateManager:getInstance():clear(success_animate_path)
    end
end

function EqmIdentifyView:setData(item,location)
    self.item = item
    self.location = location
    self.attr_flag = ItemHelper:getAttrFlagByLocation(location)
    self:changeBaseInfo()
    self:changeExtInfo()
    -- self.equip_icon:setItem(item)
end

function EqmIdentifyView:changeBaseInfo()

end

function EqmIdentifyView:changeExtInfo()
    local name_label = nil
    local value_label = nil
    local attr_vo = nil
    total_lockNum = 0 --装备锁定属性数量
    for i=1,5 do
        name_label = attr_label_dic[i]
        value_label = value_label_dic[i]
        attr_vo = self.item.identify_attrs[i]

        local lock_btn_touch_panel = name_label:getChildByTag(i)
        local lock_btn = lock_btn_touch_panel:getChildByTag(255)
        if attr_vo then

            lock_btn_touch_panel:setTouchEnabled(true)
            if attr_vo.is_locked == 1 then
                lock_btn:loadTextures("eqm_locked.png", "eqm_locked.png", "eqm_locked.png", UI_TEX_TYPE_PLIST)
                total_lockNum = total_lockNum+1
            else
                lock_btn:loadTextures("eqm_unlocked.png", "eqm_unlocked.png", "eqm_unlocked.png", UI_TEX_TYPE_PLIST)
            end


            name_label:setVisible(true)
            value_label:setVisible(true)
            name_label:setText(string.format("%s",AttrHelper:getAttrNameByFlag(attr_vo.flag)))
            value_label:setText(string.format("+%d(%d星)",attr_vo.value,attr_vo.stars))
        else
            lock_btn_touch_panel:setTouchEnabled(false)

            name_label:setVisible(false)
            value_label:setVisible(false)
        end
    end

    --是否能鉴定重置
    if ItemManager:getInstance():isCanResetIdentify(self.item) or 
        ItemManager:getInstance():isCanFashionResetIdentify(self.item) then
        self.panel_reset:setEnabled(true)
    else
        self.panel_reset:setEnabled(false)
    end

    local time_label = tolua.cast(self.widget:getChildByName("time_label"), "Label")
    local cost_label = tolua.cast(self.panel_identify:getChildByName("cost_label"), "Label")

    --不需要修改，只是在不可鉴定时隐藏的部分
    local cost_desc_label = tolua.cast(self.panel_identify:getChildByName("Label_49_Copy0"), "Label")
    local diamond_img = tolua.cast(self.panel_identify:getChildByName("ImageView_51_Copy0"), "ImageView")
    local time_desc_label = tolua.cast(self.widget:getChildByName("Label_199_Copy1"), "Label")
    local attr_desc_label = tolua.cast(self.widget:getChildByName("Label_199_Copy2"), "Label")
    local identify_btn = self.panel_identify:getChildByName("identify_btn")

    if self.item.mode.quality > ItemHelper.itemQuality.Blue then --紫色以上装备
        time_label:setVisible(true)
        cost_label:setVisible(true)
        cost_label:setVisible(true)
        cost_desc_label:setVisible(true)
        diamond_img:setVisible(true)
        time_desc_label:setVisible(true)
        attr_desc_label:setText("鑒定屬性")
        identify_btn:setVisible(true)
        time_label:setText(string.format("%d/5",total_count-self.item.identify_left_num))
    else
        time_label:setVisible(false)
        cost_label:setVisible(false)
        cost_label:setVisible(false)
        cost_desc_label:setVisible(false)
        time_desc_label:setVisible(false)
        identify_btn:setVisible(false)
        diamond_img:setVisible(false)
        attr_desc_label:setText("紫色及以上品質裝備可鑒定")
        return
    end
    local cost_data = ItemManager:getInstance():getIdentifyCostByTime(total_count-self.item.identify_left_num+1)
    local cost_lock_data = ItemManager:getInstance():getIdentifyLockCostByNum(total_lockNum)
    cost_label:setPositionX(154)
    if self.item.identify_left_num == 0 then
        cost_label:setText("裝備可鑒定次數已滿")
        cost_label:setPositionX(0)
        diamond_img:setVisible(false)
        cost_desc_label:setVisible(false)
    elseif cost_data.cost_diamond == 0 then
        if cost_lock_data then
            cost_label:setText(cost_lock_data.addt_diamond)
            else
            cost_label:setText("首次鑒定免費")
        end
    elseif cost_data.cost_diamond >0 then
        if cost_lock_data then
            cost_label:setText(cost_data.cost_diamond + cost_lock_data.addt_diamond)
        else
            cost_label:setText(cost_data.cost_diamond)
        end
         
    end
   
    self.labLucky:setStringValue(self.item.identify_lucky)

    local info = ItemManager:getInstance():getEqmIdentifyLuckyInfo(self.item.identify_lucky,self.item.mode.limit_lev,self.item.mode.item_type)
    self.labStar:setStringValue( info.min_stars )
end