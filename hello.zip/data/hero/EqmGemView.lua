--
-- Author: lvgansheng
-- Date: 2014-07-26 20:46:23
-- 宝石界面
require("GemIconSlot")
require("GemItemIcon")
require("WidgetBase")

EqmGemView = class("EqmGemView",WidgetBase)
EqmGemView.equip_icon = nil
EqmGemView.gem_slot_dic = nil
EqmGemView.select_slot = nil --当前选中的插槽
EqmGemView.select_item = nil --当前选中的宝石
EqmGemView.gem_types = nil --选中的插槽可以放置的宝石类型
EqmGemView.min_gem_lv = 0
EqmGemView.gem_count = 0

local _instance 

local success_animate_path = "ui/effects_ui/baoshixiangqian/baoshixiangqian.ExportJson"

local success_animation_tag = 1211

local isOneKeyInsert = false      --判断是否一键镶嵌

function EqmGemView:init()

    _instance = self

    self.gem_item_arr = CCArray:create()
    self.gem_item_arr:retain()

	  self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/equip/eqm_gem/eqm_gem.ExportJson")
    self:addChild(self.widget)

    self.onekeyInsert_btn = tolua.cast(self.widget:getChildByName("onekey_insert_btn"), "Button")

    self.gem_slot_dic = {}
    local slot_x = 420
    local slot_y = 405 
    local slot_dis = 140
    local gem_slot_one = GemIconSlot:create(30,ItemHelper.gem_location.one)
    gem_slot_one:setPosition(ccp(slot_x,slot_y))
    self.gem_slot_dic[ItemHelper.gem_location.one] = gem_slot_one
    self:addChild(gem_slot_one)

    local gem_slot_two = GemIconSlot:create(35,ItemHelper.gem_location.two)
    slot_x=slot_x+slot_dis
    gem_slot_two:setPosition(ccp(slot_x,slot_y))
    self.gem_slot_dic[ItemHelper.gem_location.two] = gem_slot_two
    self:addChild(gem_slot_two,1)

    local gem_slot_three = GemIconSlot:create(40,ItemHelper.gem_location.three)
    slot_x=slot_x+slot_dis
    gem_slot_three:setPosition(ccp(slot_x,slot_y))
    self.gem_slot_dic[ItemHelper.gem_location.three] = gem_slot_three
    self:addChild(gem_slot_three)

    --local gem_btn = tolua.cast(self.widget:getChildByName("gem_btn"), "Button") 
    --点击一键镶嵌宝石后的响应事件
 local function onClickOnekeyInsert(sender, eventType)
      if eventType == ComConstTab.TouchEventType.ended then

        local GemTypeCount = 0    --计算背包中宝石中的种类
        local GemInsertCount = 0    --计算一键镶嵌时替换宝石的次数

        for _,v in pairs(self.gem_slot_dic) do
          while true do
          --print("孔裡面的寶石等級==",v.gem_info.gem_lev)
          local gemInSlot = v
          local gem_types = nil
          if gemInSlot.slot_pos == nil then
            gem_types = {ItemHelper.gem_type.hp,ItemHelper.gem_type.atk,ItemHelper.gem_type.pdef}
          else
            gem_types = self:findGemTypesForOneKey(gemInSlot.slot_pos)
          end
          local oneGem_type = nil
          oneGem_type = {}
          local item_arrs = nil
          for i,ver in pairs(gem_types) do
            while true do
              oneGem_type[1] = ver
              item_arrs = ItemManager:getInstance():findGemItems(oneGem_type)
              -- if item_arrs  == nil then
              --     break
              -- end
              break
            end
            if item_arrs[1] then
              break
            end
          end

          -- oneGem_type[1] = gem_types[1]
          -- print("寶石類型========",oneGem_type[1])
          -- local item_arrs = ItemManager:getInstance():findGemItems(oneGem_type)

          if item_arrs[1] == nil then
            break
          end
          GemTypeCount = GemTypeCount + 1
          local oneGem_item = nil
          oneGem_item = item_arrs[1]
          local gem_info =  ItemManager:getInstance():getGemInfo(oneGem_item.mode.base_id)
          if gemInSlot.gem_info  then
            if gemInSlot.gem_base_id ~= 0 then
              if gem_info.gem_lev <= gemInSlot.gem_info.gem_lev then
                  print("等級原因跳出來了")
                  break
              end
            end
          end

          GemInsertCount = GemInsertCount + 1
          self._onClientSimuClcik(gemInSlot.slot_pos)
           local temp_item = GemItemIcon:create()
           temp_item:setData(oneGem_item)
            -- if self.select_item ~= nil then
            --   --去除选中框
            --   self.select_item:setSelect(false)
            -- end
            self.select_item = nil
            self.select_item = temp_item:getClickImg():getParent():getParent()
            self.select_item:setSelect(true)

            if self.select_slot then
              isOneKeyInsert = true
            -- _instance.select_slot:tempIcon(_instance.select_item.item.mode.base_id)
              ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Inlay,function()
              self.onSendGemReq()
              end)
              gemInSlot:setData(oneGem_item.mode.base_id,self.item)
            end
            break
          end
        end
        -- Alert:show("一鍵鑲嵌成功！")
        self._onClientSimuClcik(self.gem_slot_dic[1].slot_pos)
        self.select_item = nil
        print("已經清空self.select_item")
        if GemTypeCount == 0 then
          Alert:show("背包中沒有寶石")   
         elseif GemInsertCount == 0 then
            Alert:show("所有寶石已達到最高等級")
        end
      end
  end
    
    self.onekeyInsert_btn:addTouchEventListener(onClickOnekeyInsert)

    local function onTouchGemSlot(sender,eventType)
       if eventType == ComConstTab.TouchEventType.ended then
          local slot = sender:getParent():getParent()
          local slot_pos = slot.slot_pos
       
          if slot:getIsOpen() == false then
            -- local params = {}
            -- params["txt"] = "當前戰隊等級過低，請努力升級"
            -- WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
            Alert:show("當前戰隊等級過低，先努力升級吧~")
            return
          end

           --刷新
           if self.select_slot~=nil then
            if self.select_slot.gem_base_id == 0 then
              self.select_slot:tempIcon(0)
            end
              self.select_slot:setSelect(false)
           end

           slot:setSelect(true)
           self.select_slot = slot --默认选中第一个
           self:freshGemItem(slot_pos)

           --如果当前已经镶嵌了宝石，则改变按钮文字
          -- if self.select_slot.gem_base_id>0 then
          --   gem_btn:setTitleText("替換")
          -- else
          --   gem_btn:setTitleText("鑲嵌")
          -- end

        end
    end

    gem_slot_one:setTouchEvent(onTouchGemSlot)
    gem_slot_two:setTouchEvent(onTouchGemSlot)
    gem_slot_three:setTouchEvent(onTouchGemSlot)

    -- self.equip_icon = EquipIcon:create()
    -- self.equip_icon:setPosition(ccp(180,406))
    -- self:addChild(self.equip_icon)

    self.gem_list_view = self.widget:getChildByName("gem_list")
    tolua.cast(self.gem_list_view, "ListView")

	
	self.onSendGemReq = function()
	  -- if eventType == ComConstTab.TouchEventType.ended then
        if self.select_slot == nil then
         local params = {}
        params["txt"] = "當前未選擇鑲嵌部位"
        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
          return
        end 

      if isOneKeyInsert ==false then
        if self.select_item == nil then
            local params = {}
            params["txt"] = "當前未選中任何寶石"
            WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
            return
          end
      end
        
        
			local embed_gem_req = hero_pb.hero_eqm_embed_on_req() 

			embed_gem_req.hero_id = self.item.hero_id
			embed_gem_req.eqm_pos = self.item.mode.item_type
			embed_gem_req.item_id = self.item.id

      ItemManager.gem_special_slot_pos = self.select_slot.slot_pos

      local one_embed_gem_data =  embed_gem_req.gems:add()
      --目前只允许同时镶嵌一个插槽
      one_embed_gem_data.pos = self.select_slot.slot_pos
      one_embed_gem_data.item_base_id = self.select_item.item.mode.base_id
      ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_eqm_embed_on_req,embed_gem_req)
	 --   end
	end
	-- gem_btn:addTouchEventListener(onSendGemReq)

    -- local exch_btn = self.widget:getChildByName("exch_btn")
    -- local function onExchBtnClick(sender, eventType)
    --     if eventType == ComConstTab.TouchEventType.ended then
    --        WindowCtrl:getInstance():open(CmdName.EqmExchView,HeroHelper.forgePanelType.gem)
    --     end
    -- end
    -- exch_btn:addTouchEventListener(onExchBtnClick)

  

    self._onGemSucEvent = function( item_id )
        if self.item.id ~= item_id then
            return 
        end
        self.item = ItemManager:getInstance():getEquipInfoById(item_id)
        self:changeExtInfo() 
        self._onClientSimuClcik(self.select_slot.slot_pos)
        if ItemManager.gem_special_slot_pos>0 then
          --播放宝石操作成功特效
          if self.success_animation == nil then
              self.success_animation = AnimateManager:getInstance():getArmature(success_animate_path,"baoshixiangqian") 
              self.success_animation:setPositionX(2)
              self.success_animation:retain()
              self.success_animation:setTag(success_animation_tag)
          end
            self.success_animation:getAnimation():setMovementEventCallFunc(self._onPlayCallBack)
            -- self.success_animation:removeFromParentAndCleanup(true)
            self.gem_slot_dic[ItemHelper.gem_location.one]:removeNodeByTag(success_animation_tag)
            self.gem_slot_dic[ItemHelper.gem_location.two]:removeNodeByTag(success_animation_tag)
            self.gem_slot_dic[ItemHelper.gem_location.three]:removeNodeByTag(success_animation_tag)

            self.gem_slot_dic[ItemManager.gem_special_slot_pos]:addNode(self.success_animation)
            self.success_animation:getAnimation():playWithIndex(0,-1,-1,0)
            self.gem_slot_dic[ItemManager.gem_special_slot_pos]:playScalAction()
        end
    end

    self._onGemSucEventMsgShow = function()
        if isOneKeyInsert then
          Alert:show("一鍵鑲嵌成功！")
        else
          Alert:show("寶石鑲嵌成功")
        end
        -- Alert:show("寶石鑲嵌成功")
    end

     self._onPlayCallBack = function( armature, movementType, movementID )
        if movementType == AnimationMovementType.COMPLETE then
            self.success_animation:getAnimation():stop()
            self.success_animation:getAnimation():setMovementEventCallFunc(function() end)
            -- self.success_animation:removeFromParentAndCleanup(true)
            self.gem_slot_dic[ItemManager.gem_special_slot_pos]:removeNodeByTag(success_animation_tag)
        end
    end

    self._onTeamLvUpdate = function()
    	for _,gem_icon_slot in pairs(self.gem_slot_dic) do
    		gem_icon_slot:setIsOpen()
    	end
    end

    --客户端模拟点击
    self._onClientSimuClcik = function(slot_pos)
      local sender = self.gem_slot_dic[slot_pos]:getClickImg() 
      onTouchGemSlot(sender,ComConstTab.TouchEventType.ended)
    end

    self.gem_suit_prog_bg = tolua.cast(self.widget:getChildByName("ImageView_3420"),"ImageView")

    self.gem_suit_tips_btn = tolua.cast(self.widget:getChildByName("gem_suit_tips_btn"),"Button")
    self.gem_suit_tips_btn:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.GemSuitDetailView,
              {min_gem_lv=self.min_gem_lv, gem_count=self.gem_count,gem_suit_lv_txt=self.gem_suit_lv_label:getStringValue()})
        end
    end)

    self.gem_suit_tips_label = tolua.cast(self.widget:getChildByName("gem_suit_tips_label"),"Label")
    self.gem_suit_addition = tolua.cast(self.widget:getChildByName("gem_suit_addition"),"Label")
    self.gem_suit_lv_label = tolua.cast(self.widget:getChildByName("gem_suit_lv_label"),"Label")
    self.gem_suit_prog_label = tolua.cast(self.widget:getChildByName("gem_suit_prog_label"),"Label")
    self.gem_suit_prog_bar = tolua.cast(self.widget:getChildByName("gem_suit_prog_bar"), "LoadingBar")

    self.gem_suit_tips_label:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended and sender:isVisible() then
            WindowCtrl:getInstance():open(CmdName.GemSuitDetailView,
              {min_gem_lv=self.min_gem_lv, gem_count=self.gem_count,gem_suit_lv_txt=self.gem_suit_lv_label:getStringValue()})
        end
    end)
end

function EqmGemView:create()
	local view = EqmGemView.new()
    view:init()
	return view
end
 
 function EqmGemView:open()
    Notifier.regist(CmdName.GemSuccess,self._onGemSucEvent)
    Notifier.regist(CmdName.GemSuccessMsgShow,self._onGemSucEventMsgShow)
    --Notifier.regist(CmdName.SimuClickOnGemSlot,self._onClientSimuClcik)

    _instance = self
    
    if CharacterManager:getInstance():getTeamData():getLev()<40 then
    	Notifier.regist(CmdName.CHARACTER_RSP_UPDATE_TEAM,self._onTeamLvUpdate)	
   	end

   	self:_onTeamLvUpdate()
    -- self:freshGemItem()
    self:autoSelGemSlot()
 end


 function EqmGemView:autoSelGemSlot()
    local temp_gem_slot = nil
    local has_ungem_slot = false
    local gem_slot_idx = 0
    for i=1,3 do
      temp_gem_slot = self.gem_slot_dic[i]
      if temp_gem_slot:getIsOpen() then
          gem_slot_idx = 1
          if temp_gem_slot.gem_base_id == 0 then
              has_ungem_slot = true
              gem_slot_idx = i
              break
          end
      end
    end 

    if gem_slot_idx>0 then
      -- temp_gem_slot = self.gem_slot_dic[gem_slot_idx]
      self._onClientSimuClcik(gem_slot_idx)
    end
    
 end

 function EqmGemView:close()
  if self.select_slot then
    self.select_slot:setSelect(false)
    self.select_slot = nil
  end

  --停止可能的运动
  for gem_loc,temp_slot in pairs(self.gem_slot_dic) do
    temp_slot:close()
  end

  self:disposeSucAnim()

  Notifier.remove(CmdName.GemSuccess,self._onGemSucEvent)
  Notifier.remove(CmdName.GemSuccess,self._onGemSucEventMsgShow)
  Notifier.remove(CmdName.CHARACTER_RSP_UPDATE_TEAM,self._onTeamLvUpdate)
  Notifier.remove(CmdName.SimuClickOnGemSlot,self._onClientSimuClcik)
 end

 --移除并销毁强化成功时的动画
function EqmGemView:disposeSucAnim()
    if self.success_animation then
        self.success_animation:getAnimation():stop()
        self.success_animation:getAnimation():setMovementEventCallFunc(function() end)
        -- self.success_animation:removeFromParentAndCleanup(true)
        if self.gem_slot_dic[ItemManager.gem_special_slot_pos] then
          self.gem_slot_dic[ItemManager.gem_special_slot_pos]:removeNodeByTag(success_animation_tag)
        end
        
        self.success_animation:release()
        self.success_animation = nil
        AnimateManager:getInstance():clear(success_animate_path)
    end
end

function EqmGemView:setData(item,location)
	self.item = item
	self.location = location
	self.attr_flag = ItemHelper:getAttrFlagByLocation(location)
	self:changeBaseInfo()
  self:changeExtInfo(true)
  -- self.equip_icon:setItem(item)
end

function EqmGemView:changeBaseInfo()
	-- local nameLabel = self.widget:getChildByName("name_label")
 --  tolua.cast(nameLabel, "Label")
 --  nameLabel:setText(self.item.mode.name)

end

function EqmGemView:changeExtInfo(is_init)
    local temp_gems = self.item.gems
    local gem_base_id = nil
    local need_scal = false --是否从无到有，是的话播放相应action
    local cur_gem_count = 0 -- 当前的宝石数量
    local is_less_then_five = false -- 是否有小于5级的宝石
    for gem_loc,temp_slot in pairs(self.gem_slot_dic) do
        gem_base_id = temp_gems[gem_loc]
        if gem_base_id then
          
          need_scal = false
          if temp_slot.gem_base_id == 0 then
            need_scal = true
          end

          temp_slot:setData(gem_base_id,self.item)
          -- if is_init ~= true and need_scal then
          --   temp_slot:playScalAction()
          -- end
          cur_gem_count = cur_gem_count +1
          if HeroManager.MIN_GEM_LV_FOR_SUIT>temp_slot:getGemLv() then
            is_less_then_five = true
          end
        else
            temp_slot:setData(0,nil)
        end
    end

    --如果是重新点击标签页，则重置为初始状态
    if self.select_slot == nil then
      self:clearGemItems()
    else
      self:freshGemItem(self.select_slot.slot_pos)
    end

    --设置宝石套相关显示
    local eqms = HeroManager:getInstance():getBattleHeroEqmList(self.item.hero_id)
    local min_gem_lv,gem_count =  eqms:getGemSuitLv()
    self.min_gem_lv = min_gem_lv
    self.gem_count = gem_count or 0
    if min_gem_lv==0 then
      self.gem_suit_lv_label:setText(string.format("%d級寶石套進度：",5))
      self.gem_suit_prog_label:setText(string.format("%d/%d",self.gem_count,HeroManager.TOTAL_GEM_COUNT))
      self.gem_suit_prog_bar:setPercent(self.gem_count/HeroManager.TOTAL_GEM_COUNT*100)
    elseif min_gem_lv==HeroManager.MAX_GEM_LV_FOR_SUIT then
      self.gem_suit_lv_label:setText(string.format("%d級寶石套進度：", HeroManager.MAX_GEM_LV_FOR_SUIT))
      self.gem_suit_prog_label:setText(string.format("%d/%d",HeroManager.TOTAL_GEM_COUNT,HeroManager.TOTAL_GEM_COUNT))
      self.gem_suit_prog_bar:setPercent(100)
    else
      self.gem_suit_lv_label:setText(string.format("%d級寶石套進度：",min_gem_lv+1))
      self.gem_suit_prog_label:setText(string.format("%d/%d",self.gem_count,HeroManager.TOTAL_GEM_COUNT))
      self.gem_suit_prog_bar:setPercent(self.gem_count/HeroManager.TOTAL_GEM_COUNT*100)
    end

    self.gem_suit_addition:setVisible(false)
    -- --当前宝石孔未满 
    if cur_gem_count<3 then
      -- self.gem_suit_tips_label:setText("同一個英雄鑲嵌滿3個寶石有寶石套效果哦~")
      self.gem_suit_tips_label:setText("該英雄8件裝備全鑲嵌滿5級寶石有寶石套效果")
    elseif is_less_then_five then
      -- self.gem_suit_tips_label:setText("所有寶石都在5級以上就可以獲得寶石套效果啦")
      self.gem_suit_tips_label:setText("該英雄8件裝備全鑲嵌滿5級寶石有寶石套效果")
    elseif min_gem_lv ==0 then
      -- self.gem_suit_tips_label:setText("所有裝備的寶石都在5級以上有寶石套效果哦~")
      self.gem_suit_tips_label:setText("該英雄8件裝備全鑲嵌滿5級寶石有寶石套效果")
    else 
      local gem_suit_ratio = ItemManager:getInstance():getGemSuitRationByLv(min_gem_lv)*100
      self.gem_suit_tips_label:setText(string.format("當前為%d級寶石套    效果：獲得    加成",min_gem_lv))
      self.gem_suit_addition:setText(string.format("%d%%",gem_suit_ratio))
      self.gem_suit_addition:setVisible(true)
      self.gem_suit_addition:setColor(ItemHelper:getGemSuitAttrLabelColor(min_gem_lv))
    end

    --如果是时装，则不显示宝石套相关
    if self.item.mode.item_type == ItemHelper.itemType.fashion_skin or 
      self.item.mode.item_type == ItemHelper.itemType.miracle then
        self.gem_suit_lv_label:setText("")
        self.gem_suit_prog_label:setText("")
        self.gem_suit_tips_label:setText("")
        self.gem_suit_prog_bar:setPercent(0)
        self.gem_suit_tips_btn:setVisible(false)
        self.gem_suit_tips_btn:setTouchEnabled(false)
        self.gem_suit_prog_bg:setVisible(false)
    else
        self.gem_suit_tips_btn:setVisible(true)
        self.gem_suit_tips_btn:setTouchEnabled(true)
        self.gem_suit_prog_bg:setVisible(true)
    end

end
--找出当前槽位可以镶嵌的宝石类型
function EqmGemView:findGemTypesForOneKey(slot_pos)
    local gem_types = {}
    local gem_slot = self.gem_slot_dic[slot_pos]
    local gems =  self.item.gems
    local gem_base_id = gems[slot_pos]
    local gem_info = nil
    if gem_slot.gem_base_id>0 then
      gem_info = ItemManager:getInstance():getGemInfo(gem_slot.gem_base_id)
      table.insert(gem_types, gem_info.gem_type)
    else
      --默认是所有宝石类型
      gem_types = {ItemHelper.gem_type.hp,ItemHelper.gem_type.atk,ItemHelper.gem_type.pdef}
      local idx = 0
      --查看另外两个孔是否有宝石，有则排除相应类型，同种宝石只能存在一个
      for _,gem_slot in pairs(self.gem_slot_dic) do
        if gem_slot.slot_pos ~= slot_pos and gem_slot.gem_base_id>0 then
          gem_info =  ItemManager:getInstance():getGemInfo(gem_slot.gem_base_id)
          idx = Helper.findArrIndexByValue(gem_types,gem_info.gem_type)
          table.remove(gem_types,idx)
        end
      end

    end 
    return gem_types
end

--找出当前槽位可以镶嵌的宝石类型
function EqmGemView:findGemTypes(slot_pos)
    local gem_types = {}
    local gem_slot = self.gem_slot_dic[slot_pos]
    local gems =  self.item.gems
    local gem_base_id = gems[slot_pos]
    local gem_info = nil
    -- if gem_slot.gem_base_id>0 then
    --   gem_info = ItemManager:getInstance():getGemInfo(gem_slot.gem_base_id)
    --   table.insert(gem_types, gem_info.gem_type)
    -- else
      --默认是所有宝石类型
      gem_types = {ItemHelper.gem_type.hp,ItemHelper.gem_type.atk,ItemHelper.gem_type.pdef}
      local idx = 0
      --查看另外两个孔是否有宝石，有则排除相应类型，同种宝石只能存在一个
      for _,gem_slot in pairs(self.gem_slot_dic) do
        if gem_slot.slot_pos ~= slot_pos and gem_slot.gem_base_id>0 then
          gem_info =  ItemManager:getInstance():getGemInfo(gem_slot.gem_base_id)
          idx = Helper.findArrIndexByValue(gem_types,gem_info.gem_type)
          table.remove(gem_types,idx)
        end
      end

    -- end 
    return gem_types
end
--点击可镶嵌宝石后的响应事件
local function onClickGemItem(sender, eventType)
    if eventType == ComConstTab.TouchEventType.ended then
      isOneKeyInsert = false
      if _instance.select_item ~= nil then
          --去除选中框
          _instance.select_item:setSelect(false)
      end
      _instance.select_item = sender:getParent():getParent()
       _instance.select_item:setSelect(true)

      if _instance.select_slot then
       -- _instance.select_slot:tempIcon(_instance.select_item.item.mode.base_id)

          ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Inlay,function()
            _instance.onSendGemReq()
          end)
      end
    end
end


--预览宝石镶嵌之后的样子
function EqmGemView:reviewGemSlot()

end

--刷新可镶嵌物品
function EqmGemView:freshGemItem(slot_pos)
    local gem_types = nil
    if slot_pos == nil then
      gem_types = {ItemHelper.gem_type.hp,ItemHelper.gem_type.atk,ItemHelper.gem_type.pdef}
    else
      gem_types = self:findGemTypes(slot_pos)
    end
    local item_arrs = ItemManager:getInstance():findGemItems(gem_types)

    self:clearGemItems()

    local temp_item = nil
    for i,v in pairs(item_arrs) do
        temp_item = self.gem_item_arr:lastObject()
       if temp_item == nil then
           temp_item = GemItemIcon:create()
           temp_item:setTouchEvent(onClickGemItem)
       else
           self.gem_item_arr:removeObject(temp_item,false) 
       end
      temp_item:setData(v)

      self.gem_list_view:pushBackCustomItem(temp_item) 
    end   
end

function EqmGemView:clearGemItems()
  local tempChildArr = self.gem_list_view:getChildren()
  self.gem_item_arr:addObjectsFromArray(tempChildArr)
  self.gem_list_view:removeAllItems()

  --去除原本的选中状态
  if isOneKeyInsert == false then
    if self.select_item then
        self.select_item:setSelect(false)
        self.select_item = nil
    end
  end
end