-- 装备升级界面
require("WidgetBase")

EqmUpgradeView = class("EqmIdentifyView", WidgetBase)
EqmUpgradeView.item = nil

function EqmUpgradeView:create()
	local ret = EqmUpgradeView.new()
	ret:init()
	return ret
end

function EqmUpgradeView:init()		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/equip/eqm_upgrade/eqm_upgrade.ExportJson")
    self:addChild(self.widget)

    self.panelHandle = tolua.cast(self.widget:getChildByName("panel_handle"),"Layout")
    self.panelErr = tolua.cast(self.widget:getChildByName("panel_err"),"Layout")
    self.panelTip = tolua.cast(self.widget:getChildByName("panel_tips"),"Layout")
    self.labTips = tolua.cast(self.panelTip:getChildByName("lab_tips"),"Label")

    self.resIcon = ItemIcon:create()
    self.resIcon:setPosition(ccp(self.panelHandle:getChildByName("p_1"):getPosition()))
    self.panelHandle:addChild(self.resIcon)
    self.resIcon:setTouchEvent(function(sender, eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	local param = {}
            param.res_baseid = self.upgradeInfo.cost_base_id
            param.find_type = ItemHelper.find_type.upgrade_res
            param.eqm_type = ItemHelper.itemType.equip_fragment
            WindowCtrl:getInstance():open(CmdName.FindEqmView,param)
	    end
    end)

    require "ItemInfoPanel"
    self.AfterEquip = ItemIcon:create()
    
    self.AfterEquip:setTouchEvent(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.began then
            ItemInfoPanel:show(pSender:getTag())

        elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then
            ItemInfoPanel:hide()
        end
    end)
    self.AfterEquip:setPosition(ccp(self.panelHandle:getChildByName("p_2"):getPosition()))
    self.panelHandle:addChild(self.AfterEquip)

    self.labNum = tolua.cast(self.panelHandle:getChildByName("lab_num"),"Label")
    self.labCost = tolua.cast(self.widget:getChildByName("lab_cost"),"Label")
    self.labResName = tolua.cast(self.panelHandle:getChildByName("lab_name"),"Label")

    self.btnOk = tolua.cast(self.widget:getChildByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(function(sender, eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	local param = {}
	        param.hero_id = self.item.hero_id
	        param.item_id = self.item.id
	        param.eqm_pos = self.item.mode.item_type
	        ItemManager:getInstance():sendEquipUpgradeReq(param)
	    end
	end)

	Notifier.regist(CmdName.EqmUpgradeSuc,function(param) self:setData(param.item,param.location) end)
end

function EqmUpgradeView:setData(item,location)
	self.item = item
	self.location = location

	local im = ItemManager:getInstance()

	self.upgradeInfo = im:getEqmUpgradeInfo(self.item.mode.base_id)

	if self.upgradeInfo == nil then --不符合升级要求(没配置)
		self.panelHandle:setEnabled(false)
		self.panelErr:setEnabled(true)
		self.btnOk:setBright(false)
    	self.btnOk:setTouchEnabled(false)

	else
		self.panelHandle:setEnabled(true)
		self.panelErr:setEnabled(false)

    	self.AfterEquip:setBaseId(self.upgradeInfo.target_base_id)
    	self.AfterEquip:getClickImg():setTag(self.upgradeInfo.target_base_id)
    	self.resIcon:setBaseId(self.upgradeInfo.cost_base_id)

    	local resMode = im:getItemModelByBaseId( self.upgradeInfo.cost_base_id )

    	local num = im:getQuantityByBaseId(self.upgradeInfo.cost_base_id)
		self.labNum:setText(string.format("%d/%d",num,self.upgradeInfo.cost_num))
		self.labCost:setText(self.upgradeInfo.coin)
		self.labResName:setText(resMode.name)
		self.labResName:setColor(ItemHelper:getColorByQuality(self.item.mode.quality))

		if num < self.upgradeInfo.cost_num then
		    self.labNum:setColor(ItemHelper.colors.red)
		else
		    self.labNum:setColor(ItemHelper.colors.yellow)
		end

		local isCanUpgrade,err = im:isCanEqmUpgradeByBaseId( self.item.mode.base_id )

		self.panelTip:setVisible( not err.teamLev )
  		self.labTips:setText(self.upgradeInfo.team_lev)

		if CharacterManager:getInstance():getAssetData():getGold() < self.upgradeInfo.coin then
		    self.labCost:setColor(ItemHelper.colors.red)
		else
		    self.labCost:setColor(ItemHelper.colors.yellow)
		end

		self.btnOk:setBright(isCanUpgrade)
  		self.btnOk:setTouchEnabled(isCanUpgrade)
	end

end