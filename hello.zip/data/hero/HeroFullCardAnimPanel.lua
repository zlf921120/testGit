--英雄全屏整卡动画

HeroFullCardAnimPanel = class("HeroFullCardAnimPanel",WindowBase)
HeroFullCardAnimPanel.__index = HeroFullCardAnimPanel
HeroFullCardAnimPanel._widget    = nil
HeroFullCardAnimPanel.uiLayer    = nil
HeroFullCardAnimPanel.is_dispose = true

function HeroFullCardAnimPanel:create()
	return HeroFullCardAnimPanel.new()
end

function HeroFullCardAnimPanel:init()

    self.uiLayer = TouchGroup:create()
    self.uiLayer:setTouchPriority(-500)
    self:addChild(self.uiLayer,0)

    self._widget = Layout:create()
    self._widget:setZOrder(10)
    self._widget:setTouchEnabled(true)
    self._widget:setSize(CCSize(960,640))
    self.uiLayer:addWidget(self._widget)

end

function HeroFullCardAnimPanel:open()

    local heroId = self.params["hero_id"] 
    self.imgCard = HeroImgView:create()
    self.imgCard:setData(heroId)
    self.imgCard:setAnchorPoint(ccp(0.5,0.5))
    self.imgCard:setPosition(ccp(220,260))
    self.imgCard:setFull(true)
    
    self._widget:addChild(self.imgCard)

    local arr1 = CCArray:create()
    arr1:addObject( CCRotateTo:create(0.3, -90) )
    local arr2 = CCArray:create()
    arr2:addObject( CCScaleTo:create(0.3,1.81) )
    arr2:addObject( CCCallFunc:create(function()
        self.imgCard:setClickHandler(function(pSender,eventType) 
            if eventType == ComConstTab.TouchEventType.ended then
                self.imgCard:getClickWidget():setTouchEnabled(false)
                self.imgCard:close()
                self.imgCard:setPositionY(1000) --移出屏幕
                self.imgCard:setVisible(false)

                WindowCtrl:getInstance():close(self.name)
            end
        end)
    end ))
    local arr3 = CCArray:create()
    arr3:addObject( CCMoveTo:create(0.3,ccp(480,320)))

    self.imgCard:stopAllActions()
    self.imgCard:runAction(CCSequence:create(arr1))
    self.imgCard:runAction(CCSequence:create(arr2))
    self.imgCard:runAction(CCSequence:create(arr3))
end

function HeroFullCardAnimPanel:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end
