--英雄高级属性面板
HeroAdvInfoView = class("HeroAdvInfoView",WindowBase)
HeroAdvInfoView.__index = HeroAdvInfoView
HeroAdvInfoView._widget     = nil
HeroAdvInfoView.uiLayer    = nil
HeroAdvInfoView.is_dispose = true

local __instance = nil

function HeroAdvInfoView:create()
    local ret = HeroAdvInfoView.new()
    __instance = ret
    return ret   
end

function HeroAdvInfoView:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end

function HeroAdvInfoView:init()
	require "HeroAdvInfoTips"
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/hero_adv_info/hero_adv_info.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

	self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
	self.btnClose:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then
			WindowCtrl:getInstance():close(self.name)
		end
	end)
end

function HeroAdvInfoView:open()

	local heroId = self.params["hero_id"]
	self.propNames = {"crit","block","def_break","tought","break_atk","evasion","real_harm","suck_blood"}

	local attrs = HeroManager:getInstance():getHeroFinalAttr(heroId)
	
	for i,v in ipairs(self.propNames) do
		self["lab_"..v] = tolua.cast(self.uiLayer:getWidgetByName("lab_"..v),"Label")
		self["lab_"..v]:setText( attrs[ AttrHelper.attr_flag[v] ] )

		self["img_"..v] = tolua.cast(self.uiLayer:getWidgetByName("img_"..v),"ImageView")
		self["img_"..v]:addTouchEventListener(function(pSender,eventType)
			if eventType == ComConstTab.TouchEventType.began then
                    
                    HeroAdvInfoTips:show(AttrHelper.attr_flag[v])

            elseif eventType == ComConstTab.TouchEventType.ended or
                    eventType == ComConstTab.TouchEventType.canceled then
                	HeroAdvInfoTips:hide()
            end
		end)
	end

end

function HeroAdvInfoView:close()

end