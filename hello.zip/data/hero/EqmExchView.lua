--
-- Author: lvgansheng
-- Date: 2014-07-02 19:16:42
-- 装备替换界面，替换锻造的物品

EqmExchView =  class("EqmExchView", WindowBase)
EqmExchView.uiLayer = nil
EqmExchView.widget = nil
EqmExchView.enterFun = nil 
EqmExchView.exitFun = nil
EqmExchView.sc_view = nil
EqmExchView.view_type = 0 --记录是从锻造的哪个标签页点进来的

EqmExchView.DefaultScrollHeight = 476 --滚动层最小的高度
EqmExchView.DefaultIconHeight = 140 -- 每个元件的高度
EqmExchView.DefaultIconWidth = 320 -- 每个元件的宽度
EqmExchView.DefaultIconNum = 2 -- 一行的元件个数
EqmExchView._isScrolling = false

local item_mgr = ItemManager:getInstance()
local pos_type
local exch_item_2_hero_id = nil
local is_all_create = false
local last_compare_value = 0
function EqmExchView:init()
    require("EqmExchItem")
    require("CustomMenu")
    require("ItemIcon")
    require("EqmExcHeroItem")

     ComResMgr:getInstance():loadRes("ui/common/common_2.plist","ui/common/common_2.pvr.ccz")

    self.exch_item_arr = CCArray:create()
    self.exch_item_arr:retain()

    self.exch_item_dic = {}

    exch_item_2_hero_id = {}

    self.name_label_arr = CCArray:create()
    self.name_label_arr:retain()

    self.lv_label_arr = CCArray:create()
    self.lv_label_arr:retain()

    self.identify_label_arr = CCArray:create()
    self.identify_label_arr:retain()

    self.powered_label_arr = CCArray:create()
    self.powered_label_arr:retain()

    self.item_lv_label_arr = CCArray:create()
    self.item_lv_label_arr:retain()

    self.hero_mgr = HeroManager:getInstance()

	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/equip/equip_exc_def/equip_exc_def.ExportJson")
    self.uiLayer:addWidget(self.widget)

    EqmExchView.widget_seed = GUIReader:shareReader():widgetFromJsonFile("ui/equip/eqm_exch_item/eqm_exch_item.ExportJson")
    EqmExchView.widget_seed:retain()

    -- self.sc_view = ScrollView:create()
    -- self.sc_view:setSize(CCSize(700, 470))
    -- self.sc_view:setDirection(SCROLLVIEW_DIR_VERTICAL)
    -- self.sc_view:setBounceEnabled(true)
    -- self.sc_view:setPosition(ccp(115,50))
    -- self.sc_view:setClippingEnabled(true)
    -- self.uiLayer:addWidget(self.sc_view)
    self.eqm_sc_view = tolua.cast(self.uiLayer:getWidgetByName("eqm_sc_view"), "ScrollView")
    -- self.container = DisplayUtil.newLayer()
    
    self.hero_container = DisplayUtil.newLayout()
    self.icon_bg_batch_node = CCSpriteBatchNode:create("ui/common/common_2.pvr.ccz",48) --整个元件的背景
    self.item_bg_batch_node = CCSpriteBatchNode:create("ui/common/common.pvr.ccz",48) -- 物品图标背景
    self.item_icon_batch_node = CCSpriteBatchNode:create("ui/common/item_icon.pvr.ccz",48) --物品图标
    self.item_border_batch_node = CCSpriteBatchNode:create("ui/common/common.pvr.ccz",48) --物品图标品质框

    self.green_efc_border = CCBatchNode:create() -- 绿色附魔特效
    self.blue_efc_border = CCBatchNode:create() -- 蓝色附魔特效
    self.purple_efc_border = CCBatchNode:create() -- 紫色附魔特效
    self.orange_efc_border = CCBatchNode:create() -- 橙色附魔特效

    self.unidentify_efc_border = CCBatchNode:create() -- 未鉴定文字特效

    self.label_layer = DisplayUtil.newLayer()

    self.eqm_sc_view:addChild(self.hero_container)
    self.eqm_sc_view:addNode(self.icon_bg_batch_node)
    self.eqm_sc_view:addNode(self.item_bg_batch_node)
    self.eqm_sc_view:addNode(self.item_icon_batch_node)
    self.eqm_sc_view:addNode(self.item_border_batch_node)
    self.eqm_sc_view:addNode(self.label_layer)
    self.eqm_sc_view:addNode(self.green_efc_border)
    self.eqm_sc_view:addNode(self.blue_efc_border)
    self.eqm_sc_view:addNode(self.purple_efc_border)
    self.eqm_sc_view:addNode(self.orange_efc_border)
    self.eqm_sc_view:addNode(self.unidentify_efc_border)

    self.old_pos_y = 0

    local temp_af = self.eqm_sc_view:nodeToWorldTransform()
    local tmp_af_x = temp_af.tx 
    local tmp_af_y = temp_af.ty 

    self.eqm_sc_view:addTouchEventListener(function(sender, eventType) 
        if eventType == ComConstTab.TouchEventType.ended and self._isScrolling == false then
            local tmp_y = self.eqm_sc_view:getInnerContainer():getPositionY()
            local touch_pos = self.eqm_sc_view:getTouchEndPos()
            local begin_touch_pos = self.eqm_sc_view:getTouchStartPos()
            local diff_value = begin_touch_pos.y-touch_pos.y
            if diff_value>100 or diff_value<-100 then
                return
            end
            -- local innerHeight = self.eqm_sc_view:getInnerContainerSize().height
            cclog("實際點擊的位置~~~x=%f~~~~y=%f",touch_pos.x-tmp_af_x ,touch_pos.y-tmp_af_y-tmp_y)
            self:findClickItem(touch_pos.x-tmp_af_x ,touch_pos.y-tmp_af_y-tmp_y)
        elseif eventType == ComConstTab.TouchEventType.moved  then
            if -self.eqm_sc_view:getInnerContainer():getPositionY()-self.old_pos_y>-300 and 
                -self.eqm_sc_view:getInnerContainer():getPositionY()-self.old_pos_y<300 and 
                self.old_pos_y~=0 then
                return
            end
            self.old_pos_y = -self.eqm_sc_view:getInnerContainer():getPositionY()
            self:showEqmLabel()
        elseif eventType == ComConstTab.TouchEventType.began  then
            -- self.begin_touch_pos = self.eqm_sc_view:getInnerContainer():getPosition()
        end
    end)

    pos_type = ItemHelper.limitStand.Unlimit

    --卡牌类型切换按钮

    local function menuCallback(tag, sender)
       -- local pos_type = nil
        if tag == 1 then 
            pos_type = ItemHelper.limitStand.Unlimit
        elseif tag == 2 then
            pos_type = ItemHelper.limitStand.Front
        elseif tag == 3 then
            pos_type = ItemHelper.limitStand.Midle
        elseif tag == 4 then   
            pos_type = ItemHelper.limitStand.Back
        else 
            pos_type = ItemHelper.limitStand.Unlimit
        end
        
        self:changeConentByPosType(pos_type)
       
    end

    -- self.exc_item_list_view:

    local menu_arr = {}
    table.insert(menu_arr,{txt="全部"})
    table.insert(menu_arr,{txt="前排"})
    table.insert(menu_arr,{txt="中排"})
    table.insert(menu_arr,{txt="後排"})

    self.cus_menu = CustomMenu:create()
    self.cus_menu:setData(menu_arr,menuCallback)
    self.cus_menu:alignItemsVerticallyWithPadding(15)
    self.cus_menu:setPosition(CCPoint(889,300))
    self.uiLayer:addChild(self.cus_menu)        

    self._onTeamUpgradeSuc = function(team_type)
        if team_type ~= TeamType.Normal then
            return
        end
        self:changeConentByPosType(ItemHelper.limitStand.Unlimit)
    end

    self._onUpdateSingleItem = function(item_id)
        self:changeConentByPosType(ItemHelper.limitStand.Unlimit)
    end

    --批量强化成功，刷新
    self._onEqmBatchPoweredSucc = function()
        self:showEqmLabel()
    end

    --鉴定成功 
    self._onEqmIdentifyResetSuc = function(item_id)
        self:showEqmLabel()
    end

    --宝石操作成功
    self._onGemSucEvent = function()
        self:changeConentByPosType(ItemHelper.limitStand.Unlimit)
    end

    --装备升级成功
    self._onEqmUpgradeSuc = function(param)
        self:changeConentByPosType(param.item.mode.limit_stand)
    end
    --处理scrollView滑动
    self._progressSchedScene = function()
        local nowY = self.eqm_sc_view:getInnerContainer():getPositionY()
        self._isScrolling = self._lastY ~= nowY
        if self._lastY == nowY then return end
        self._lastY = nowY
    end

    self.open = function()
        local cur_view_type = nil
        local cur_hero_id = nil
        if self.params then
           cur_view_type = self.params.cur_view_type
           cur_hero_id = self.params.cur_hero_id
        end

        self.cur_hero_id = cur_hero_id
        self.view_type =  cur_view_type or HeroHelper.forgePanelType.powered --默认是打开强化界面
        self:changeConentByPosType(pos_type)
        Notifier.regist(CmdName.TEAM_UPGRADE_HERO_SUCCESS,self._onTeamUpgradeSuc)
        Notifier.regist(CmdName.EqmPoweredSuccess,self._onUpdateSingleItem)
        Notifier.regist(CmdName.IdentifySuccess,self._onUpdateSingleItem)
        Notifier.regist(CmdName.EnchantSuccess,self._onGemSucEvent)
        Notifier.regist(CmdName.IdentifyResesSuc,self._onEqmIdentifyResetSuc)
        Notifier.regist(CmdName.EqmBatchPoweredSucc,self._onEqmBatchPoweredSucc)
        Notifier.regist(CmdName.GemSuccess,self._onGemSucEvent)
        Notifier.regist(CmdName.EqmUpgradeSuc,self._onEqmUpgradeSuc)

        self:startSchedule()
    end

    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

--新手引导动画
function EqmExchView:showStepAnim(param) 
    if param.target == "forge_item" then
        local pos = self:getItemPosByIndex(1)
        if pos == nil then
            GuideRenderMgr:getInstance():forceFinishEvent()
        else
            GuideRenderMgr:getInstance():renderMainFlag(self.eqm_sc_view,param.id,param.target,pos)
            self.cus_menu:setSelectedItem(1) --强制选择第一个
            --滑动
            local percent = DisplayUtil.getScrollViewPercentWithPos(self.eqm_sc_view, pos)
            self.eqm_sc_view:stopAllActions()
            self.eqm_sc_view:runAction(CCSequence:createWithTwoActions(
                CCDelayTime:create(0.05),
                CCCallFunc:create(function()
                    self.eqm_sc_view:scrollToPercentVertical(100 - percent + 1,0.2,true)
                end)))
        end
    elseif param.target == "forge_item_13010" then
        local pos = self:getItemPosByBaseId(13010)
        if pos == nil then
            GuideRenderMgr:getInstance():forceFinishEvent()
        else
            GuideRenderMgr:getInstance():renderMainFlag(self.eqm_sc_view,param.id,param.target,pos)
            self.cus_menu:setSelectedItem(1)
            --滑动
            local percent = DisplayUtil.getScrollViewPercentWithPos(self.eqm_sc_view, pos)
            self.eqm_sc_view:stopAllActions()
            self.eqm_sc_view:runAction(CCSequence:createWithTwoActions(
                CCDelayTime:create(0.05),
                CCCallFunc:create(function()
                    self.eqm_sc_view:scrollToPercentVertical(100 - percent + 1,0.2,true)
                end)))
        end
    elseif param.target == "forge_exit" then
        GuideRenderMgr:getInstance():renderMainFlag(self.close_btn,param.id,param.target)
    end
end

function EqmExchView:create()
	local ech_view = EqmExchView.new()
	-- ech_view:init()
	return ech_view
end

function EqmExchView:startSchedule()
    self:clearSchedule()
    TimerManager.addTimer(50,self._progressSchedScene,true)
end

function EqmExchView:clearSchedule()
    TimerManager.removeTimer(self._progressSchedScene)
end

function EqmExchView:close()
    Notifier.remove(CmdName.TEAM_UPGRADE_HERO_SUCCESS,self._onTeamUpgradeSuc)
    Notifier.remove(CmdName.EqmPoweredSuccess,self._onUpdateSingleItem)
    Notifier.remove(CmdName.IdentifySuccess,self._onUpdateSingleItem)
    Notifier.remove(CmdName.EnchantSuccess,self._onGemSucEvent)
    Notifier.remove(CmdName.IdentifyResesSuc,self._onEqmIdentifyResetSuc)
    Notifier.remove(CmdName.EqmBatchPoweredSucc,self._onEqmBatchPoweredSucc)
    Notifier.remove(CmdName.GemSuccess,self._onGemSucEvent)
    Notifier.remove(CmdName.EqmUpgradeSuc,self._onEqmUpgradeSuc)

    self:clearSchedule()
end

function EqmExchView:returnFun()
    WindowCtrl:getInstance():close(self.name)
     --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10622 or
        GuideDataProxy:getInstance().nowMainTutroialEventId == 10509 or
        GuideDataProxy:getInstance().nowMainTutroialEventId == 10812 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"exit_forge")
    end
end

function EqmExchView:extTouch(enable)
    self.cus_menu:setTouchEnabled(enable)
end

function EqmExchView:extTouchPriority(value)
    self.cus_menu:setTouchPriority(value)
end

-- 通过卡牌站位显示相应内容
function EqmExchView:changeConentByPosType(pos_type)
    self.hero_container:removeAllChildrenWithCleanup(true)
    self.icon_bg_batch_node:removeAllChildrenWithCleanup(true)
    self.item_bg_batch_node:removeAllChildrenWithCleanup(true)
    self.item_icon_batch_node:removeAllChildrenWithCleanup(true)
    self.item_border_batch_node:removeAllChildrenWithCleanup(true)
    self.green_efc_border:removeAllChildrenWithCleanup(true)
    self.blue_efc_border:removeAllChildrenWithCleanup(true)
    self.purple_efc_border:removeAllChildrenWithCleanup(true)
    self.orange_efc_border:removeAllChildrenWithCleanup(true)
    self.unidentify_efc_border:removeAllChildrenWithCleanup(true)

    local hero_id_list = TeamManager:getInstance():getHeroIdByLimitStand(pos_type, nil, 2)

    local count = #hero_id_list
    local cur_hero_idx = 0

    local size_tab = {}
    local hero_id_data_one = nil
    local eqms = nil
   
    for i = 1, count do
        hero_id_data_one = hero_id_list[i]
        eqms = self.hero_mgr:getBattleHeroEqmList(hero_id_data_one.hero_id) 
        
        --插入时装
        local heroInfo = self.hero_mgr:getHeroInfoById(hero_id_data_one.hero_id)
        table.insert(size_tab, eqms:getEqmsCount() + heroInfo:getFashionCurWearCout())
        if self.cur_hero_id and self.cur_hero_id == hero_id_data_one.hero_id then
            cur_hero_idx = i
        end
    end

    self:setScrollHeight(size_tab)

    local innerHeight = self.eqm_sc_view:getInnerContainerSize().height
    local exch_item = nil
    local tmp_row_value = 0
    local tmp_col_value = 0
    local eqm_num = 0
    local cur_heigh = 0
    local eqm_item_one = nil
    local tmp_hero_info = nil
    for i = 1, count do
        hero_id_data_one = hero_id_list[i]
        eqms = self.hero_mgr:getBattleHeroEqmList(hero_id_data_one.hero_id) 
        exch_item =  self.exch_item_dic[hero_id_data_one.team_pos]
        if exch_item == nil then 
            exch_item = EqmExcHeroItem:create()
            exch_item:retain()
            self.exch_item_dic[hero_id_data_one.team_pos] = exch_item
        end 
        exch_item_2_hero_id[hero_id_data_one.hero_id] = exch_item
        cur_heigh = cur_heigh + EqmExcHeroItem.item_height
        self.hero_container:addChild(exch_item)
        exch_item:setHeroId(hero_id_data_one.hero_id,hero_id_data_one.hero_pos, self.view_type)
        -- exch_item:setPosition(ccp(0,innerHeight-cur_heigh))
        
        tmp_hero_info = self.hero_mgr:getHeroInfoByBaseId(hero_id_data_one.hero_id)
 ---------------------------------------------------------------------------------------------
 --装备 部分
        eqm_num = 0  
        local eqm_item_list =  exch_item:getEqmItemList()
        for location,eqm_vo in pairs(eqms:getEquipList()) do
         if eqm_vo and eqm_vo.item then
            eqm_num = eqm_num+1
            eqm_item_one = eqm_item_list[eqm_num]
            if eqm_item_one==nil then
                eqm_item_one = EqmExchItem:create()
                eqm_item_list[eqm_num] = eqm_item_one
            end
            
            eqm_item_one:setData(eqm_vo.item, tmp_hero_info.pos, self.view_type)
            exch_item:setExcItem(eqm_num, eqm_item_one)

            self.icon_bg_batch_node:addChild(eqm_item_one:getEqmIconBg())
            self.item_bg_batch_node:addChild(eqm_item_one:getEqmItemBg())
            self.item_icon_batch_node:addChild(eqm_item_one:getEqmItemIcon())
            self.item_border_batch_node:addChild(eqm_item_one:getEqmItemBorder())

            if (eqm_item_one:isShowEnchantEct()) then
                self:getEctLayerByEnchatLv(eqm_item_one:getEnchantLv()):addChild(eqm_item_one:getEnchantEct())
            end

            --未鉴定文字特效
            if eqm_item_one:isShowUnIdentifyEffect() then
                self.unidentify_efc_border:addChild(eqm_item_one:getUnIdentifyEct())
            end

            -- 处理物品镶嵌宝石
            local gems = eqm_vo.item.gems
            local gem_count = 1
            for gem_idx =1,3 do
                if gems[gem_idx] then
                    self.item_bg_batch_node:addChild(eqm_item_one:getGemIconBgByIdx(gem_count))
                    self.item_icon_batch_node:addChild(eqm_item_one:getGemIconByIdx(gem_count))
                    self.item_border_batch_node:addChild(eqm_item_one:getGemIconBorderByIdx(gem_count))
                    gem_count = gem_count+1
                end
            end

            eqm_item_one:setRealPos(ccp(EqmExchView.DefaultIconWidth*(1-eqm_num%2) ,innerHeight-cur_heigh-(math.ceil(eqm_num/2)*EqmExchView.DefaultIconHeight)))
         end
        end
        -- exch_item:setRealPos(ccp(0,innerHeight-cur_heigh))
        -- cur_heigh = cur_heigh + self:getEachItemHeight(size_tab[i])
 ---------------------------------------------------------------------------------------------
 --时装 部分
        local eqm_item_list = exch_item:getEqmItemList()
        local fashion_list = tmp_hero_info:getFashionCurWearList()
        for location,fashion_vo in pairs(fashion_list) do
         if fashion_vo then

            eqm_num = eqm_num+1
            eqm_item_one = eqm_item_list[eqm_num]
            if eqm_item_one==nil then
                eqm_item_one = EqmExchItem:create()
                eqm_item_list[eqm_num] = eqm_item_one
            end
            
            eqm_item_one:setData(tmp_hero_info:getFashionCurWearItem(location), location, self.view_type)
            exch_item:setExcItem(eqm_num, eqm_item_one)

            self.icon_bg_batch_node:addChild(eqm_item_one:getEqmIconBg())
            self.item_bg_batch_node:addChild(eqm_item_one:getEqmItemBg())
            self.item_icon_batch_node:addChild(eqm_item_one:getEqmItemIcon())
            self.item_border_batch_node:addChild(eqm_item_one:getEqmItemBorder())
            self.item_border_batch_node:addChild(eqm_item_one:getFashionFlag())

            if (eqm_item_one:isShowEnchantEct()) then
                self:getEctLayerByEnchatLv(eqm_item_one:getEnchantLv()):addChild(eqm_item_one:getEnchantEct())
            end
            -- 处理物品镶嵌宝石
            local gems = tmp_hero_info:getFashionCurWearItem(location).gems
            local gem_count = 1
            for gem_idx =1,3 do
                if gems[gem_idx] then
                    self.item_bg_batch_node:addChild(eqm_item_one:getGemIconBgByIdx(gem_count))
                    self.item_icon_batch_node:addChild(eqm_item_one:getGemIconByIdx(gem_count))
                    self.item_border_batch_node:addChild(eqm_item_one:getGemIconBorderByIdx(gem_count))
                    gem_count = gem_count+1
                end
            end

            eqm_item_one:setRealPos(ccp(EqmExchView.DefaultIconWidth*(1-eqm_num%2) ,innerHeight-cur_heigh-(math.ceil(eqm_num/2)*EqmExchView.DefaultIconHeight)))
         end
        end
        exch_item:setRealPos(ccp(0,innerHeight-cur_heigh))
        cur_heigh = cur_heigh + self:getEachItemHeight(size_tab[i])
    end

    if self.cur_hero_id then
        -- local tmp_hero_item =  exch_item_2_hero_id[self.cur_hero_id]
        
        local tmp_total_y = 0
        for tmp_hero_idx=1,cur_hero_idx-1 do
            tmp_total_y = tmp_total_y + EqmExcHeroItem.item_height + 95
            tmp_total_y = tmp_total_y + math.ceil(size_tab[tmp_hero_idx]/EqmExchView.DefaultIconNum)*EqmExchView.DefaultIconHeight
        end

        -- local tmp_perc = (tmp_total_y)/cur_heigh*100
        local tmp_perc =  (tmp_total_y - 15 )/cur_heigh*100                 
        -- self.eqm_sc_view:scrollToPercentVertical(tmp_perc,0.1,true)
        self.eqm_sc_view:jumpToPercentVertical(tmp_perc)
        self.cur_hero_id = nil
        TimerManager.addTimer(150,function()
            self.old_pos_y = -self.eqm_sc_view:getInnerContainer():getPositionY()
            self:showEqmLabel()
        end)
    else
        self.old_pos_y = -self.eqm_sc_view:getInnerContainer():getPositionY()
        self:showEqmLabel()
    end

    --新手引导
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10503 or
        GuideDataProxy:getInstance().nowMainTutroialEventId == 10615 or
        GuideDataProxy:getInstance().nowMainTutroialEventId == 10803 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"click_forgeview")
    end


    -- if count==0 then
    --     is_all_create =true
    -- end

    -- local exch_item = nil
    
    -- local cur_idx = 1
    -- local step_num = 1 --步进值
    -- local temp_idx = 1

    -- if is_all_create then --如果已经创建过了
    --     step_num = 100
    -- end

    -- local function step_show()
    --     temp_idx = cur_idx
    --     for i = temp_idx, count do
    --         hero_id_data_one = hero_id_list[i]
    --         exch_item =  self.exch_item_dic[hero_id_data_one.team_pos]
    --         if exch_item == nil then 
    --             exch_item = EqmExcHeroItem:create()
    --             exch_item:retain()
    --             self.exch_item_dic[hero_id_data_one.team_pos] = exch_item
    --         end 
    --         exch_item_2_hero_id[hero_id_data_one.hero_id] = exch_item
    --         exch_item:setHeroId(hero_id_data_one.hero_id,hero_id_data_one.hero_pos, self.view_type)
    --          self.container:addChild(exch_item)
    --          cclog("英雄ID~~~%d",hero_id_data_one.hero_id)

    --         -- if cur_idx == 1 then --(新手引导用)记录第一条
    --         --     self.first_hero_exch_item = exch_item
    --         -- end
    --         -- if eqm_arr[i].mode.base_id == 13010 then --(新手引导用)记录紫装
    --         --     self.purple_exch_item = exch_item
    --         -- end

    --         cur_idx = cur_idx +1

    --         if cur_idx>count then
    --             TimerManager.removeTimer(step_show)
    --             self:hideOrShowHeroItem()
    --             is_all_create = true
    --             if GuideDataProxy:getInstance().nowMainTutroialEventId == 10503 or
    --                 GuideDataProxy:getInstance().nowMainTutroialEventId == 10615 or
    --                 GuideDataProxy:getInstance().nowMainTutroialEventId == 10803 then
    --                 Notifier.dispatchCmd(GuideEvent.StepFinish,"click_forgeview")
    --             end

    --             if self.cur_hero_id then
    --                 local tmp_hero_item =  exch_item_2_hero_id[self.cur_hero_id]
    --                 local tmp_idx = self.exc_item_list_view:getIndex(tmp_hero_item)-1
    --                 local list_items = self.exc_item_list_view:getItems()

    --                 local tmp_total_y = 0
    --                 for i=0,tmp_idx do
    --                     tmp_hero_item = list_items:objectAtIndex(i)
    --                     tmp_total_y = tmp_total_y + tmp_hero_item:getSize().height +95
    --                 end

    --                 local tmp_perc = (tmp_total_y)/self.exc_item_list_view:getInnerContainerSize().height*100
                    
    --                 self.exc_item_list_view:scrollToPercentVertical(tmp_perc,0.1,true)
    --                 self.cur_hero_id = nil
    --                 self:hideOrShowHeroItem()
    --             end
    --         else

    --             -- TimerManager.addTimer(130,function() self:hideOrShowHeroItem() end)
    --             -- self.exc_item_list_view:scrollToPercentVertical(0,0.1,true)
    --         end

    --         if cur_idx-temp_idx>=step_num then
    --             break
    --         end
    --     end
    -- end

    -- if count>0 then
    --     -- if count-self.exch_item_arr:count() <2 then
    --     --     step_num = 48
    --     --     step_show()
    --     -- else
    --         if is_all_create then
    --             step_show()
    --         else
    --             TimerManager.addTimer(200, step_show, true)
    --         end 
    -- end

end

--根据base_id 获取子节点
function EqmExchView:getItemPosByBaseId(baseId)
    local exc_one_item = exch_item_2_hero_id[10000]:getExcItemByItemBaseId(baseId)
    if exc_one_item then
        return exc_one_item:getRealPos()
    end
    return nil
end

--根据下标 获取子节点
function EqmExchView:getItemPosByIndex(idx)
    local exc_one_item = exch_item_2_hero_id[10000]:getExcItemByIdx(idx)
    if exc_one_item then
        return exc_one_item:getRealPos()
    end
    return nil
end

function EqmExchView:hideOrShowHeroItem()
    local nowY = self.exc_item_list_view:getInnerContainer():getPositionY()
    local all_height =  self.exc_item_list_view:getInnerContainerSize().height
    local item_one = nil
    local items = self.exc_item_list_view:getItems()
    local count = items:count()-1
    local view_height = self.exc_item_list_view:getSize().height
    local ext_height = view_height+200
    for i=0,count do
        item_one = items:objectAtIndex(i)
        -- ext_height = ext_height+item_one:getSize().height
        -- if ext_height<all_height+nowY or ext_height-(all_height+nowY)>1500  then
        --     item_one:setVisible(false)
        --     if  i==0 then
        --         -- cclog("這時候的~~~%f~~%f~~~~%f",ext_height,all_height+nowY,item_one:getSize().height)
        --     end
        -- else
        --     item_one:setVisible(true)
        -- end
        -- cclog("~~%d~~~~%d~~~%d",all_height,nowY,view_height)
        local temp_af = item_one:nodeToWorldTransform()
        cclog("英雄ID:%d~~~~世界座標:%d",item_one.hero_id,temp_af.ty)
        if temp_af.ty<800 and temp_af.ty>-800 then
            item_one:setVisible(true)
        else
            item_one:setVisible(false)
        end 
    end
end

function EqmExchView:setScrollHeight(size_tab) --设置背包滚动层高度
    local innerWidth = self.eqm_sc_view:getSize().width
    
    local innerHeight = 0

    for i,num in pairs(size_tab) do
        innerHeight = innerHeight + EqmExcHeroItem.item_height
        innerHeight = innerHeight + math.ceil(num/EqmExchView.DefaultIconNum)*EqmExchView.DefaultIconHeight
    end
            
    if  innerHeight<EqmExchView.DefaultScrollHeight then
        innerHeight = EqmExchView.DefaultScrollHeight
    end 
    
    self.eqm_sc_view:setInnerContainerSize(CCSize(innerWidth, innerHeight))
end 

function EqmExchView:getEachItemHeight(eqm_num)
    return math.ceil(eqm_num/EqmExchView.DefaultIconNum)*EqmExchView.DefaultIconHeight
end

function EqmExchView:getEctLayerByEnchatLv(enchant_lev)
    if enchant_lev>2 and enchant_lev<6   then --3 4 5 
        return self.green_efc_border
    elseif enchant_lev>5 and enchant_lev<9 then --6 7 8
        return self.blue_efc_border
    elseif enchant_lev>8 and enchant_lev<12 then -- 9 10 11
        return self.purple_efc_border
    elseif enchant_lev>11 then
        return self.orange_efc_border  
    end    
end

function EqmExchView:findClickItem(click_pos_x, click_pos_y)
    local half_width = EqmExchView.DefaultIconWidth
    local half_height = EqmExchView.DefaultIconHeight
    local eqm_item_list = nil
    for i,tmp_icon in pairs(self.exch_item_dic) do
        eqm_item_list = tmp_icon:getEqmItemList()
        if tmp_icon:getParent() then
            for j,temp_exch_item in pairs(eqm_item_list) do
                if temp_exch_item:getRealPos().x+half_width>click_pos_x and 
                    temp_exch_item:getRealPos().x<click_pos_x and 
                    temp_exch_item:getRealPos().y+half_height>click_pos_y and 
                    temp_exch_item:getRealPos().y<click_pos_y then
                    WindowCtrl:getInstance():open(CmdName.Eqm_Forge_View,
                        {temp_exch_item:getItemData(), temp_exch_item:getItemData().mode.item_type, self.view_type})
                    break
                else
                    cclog("實際元件位置~~~~%f~~~%f",temp_exch_item:getRealPos().x,temp_exch_item:getRealPos().y)
                end
            end
        end
    end
end

function EqmExchView:showEqmLabel()
    self.label_layer:removeAllChildrenWithCleanup(true)
    -- local old_pos_y = -self.eqm_sc_view:getInnerContainer():getPositionY()
    -- local idx = 0
    local tmp_label = nil
    local name_count = self.name_label_arr:count()
    local lv_count = self.lv_label_arr:count()
    local identify_count = self.identify_label_arr:count()
    local powered_count = self.powered_label_arr:count()
    local item_lv_count = self.item_lv_label_arr:count()
    local eqm_item_list = nil
    local name_idx = 0
    local lv_idx = 0
    local identify_idx = 0
    local powered_idx = 0
    local item_lv_idx = 0
    for i,tmp_icon in pairs(self.exch_item_dic) do
        eqm_item_list = tmp_icon:getEqmItemList()
        
        for j,temp_exch_item in pairs(eqm_item_list) do
            if temp_exch_item:getRealPos().y>self.old_pos_y-700 and 
                temp_exch_item:getRealPos().y<self.old_pos_y+1200 and 
                temp_exch_item:getEqmIconBg():getParent() then

                local equipType = ItemHelper:getEquipTypeWithItemType(temp_exch_item.item.mode.item_type)
                -- 物品名称
                if name_idx>=name_count then
                    tmp_label = CCLabelTTF:create()
                    tmp_label:setAnchorPoint(ccp(0,0))
                    tmp_label:setFontSize(22)
                    self.name_label_arr:addObject(tmp_label)
                else
                    tmp_label = self.name_label_arr:objectAtIndex(name_idx)
                end
                tmp_label:setColor(temp_exch_item:getNameLabelQuality())
                tmp_label:setString(temp_exch_item:getNameDesc())
                tmp_label:setPosition(temp_exch_item:getRealPos().x+112,temp_exch_item:getRealPos().y+90)        --+100
                self.label_layer:addChild(tmp_label)
                name_idx = name_idx+1

                -- if equipType == ItemHelper.equipType.equip then
                --     -- 装备等级
                --     if lv_idx>=lv_count then
                --         tmp_label = CCLabelTTF:create()
                --         tmp_label:setAnchorPoint(ccp(0,0))
                --         tmp_label:setFontSize(22)
                --         tmp_label:setColor(ItemHelper.colors.deep_yellow)
                --         self.lv_label_arr:addObject(tmp_label)
                --     else
                --         tmp_label = self.lv_label_arr:objectAtIndex(lv_idx)
                --     end
                --     tmp_label:setString(temp_exch_item:getLvDesc())
                --     tmp_label:setPosition(temp_exch_item:getRealPos().x+112,temp_exch_item:getRealPos().y+80)
                --     self.label_layer:addChild(tmp_label)
                --     lv_idx = lv_idx+1
                -- end

                -- 是否鉴定
                if ItemManager:getInstance():canIdentify(temp_exch_item:getItemData()) then
                    if identify_idx>=identify_count then
                        tmp_label = CCLabelTTF:create()
                        tmp_label:setAnchorPoint(ccp(0,0))
                        tmp_label:setFontSize(22)
                        tmp_label:setColor(ccc3(0x31,0xE2, 0xAE))
                        self.identify_label_arr:addObject(tmp_label)
                    else
                        tmp_label = self.identify_label_arr:objectAtIndex(identify_idx)
                    end
               
                    tmp_label:setString(temp_exch_item:getIdentifyDesc())
                    tmp_label:setPosition(temp_exch_item:getRealPos().x+112,temp_exch_item:getRealPos().y+65)
                    self.label_layer:addChild(tmp_label)
                    identify_idx = identify_idx+1
                end
                
                --强化等级
                if powered_idx>=powered_count then
                    tmp_label = CCLabelTTF:create()
                    tmp_label:setAnchorPoint(ccp(1,0))
                    tmp_label:setFontSize(22)
                    tmp_label:setScale(0.8)
                    tmp_label:setColor(ItemHelper.colors.deep_yellow)
                    self.powered_label_arr:addObject(tmp_label)
                else
                    tmp_label = self.powered_label_arr:objectAtIndex(powered_idx)
                end
               
                tmp_label:setString(temp_exch_item:getPoweredDesc())
                tmp_label:setPosition(temp_exch_item:getRealPos().x+100,temp_exch_item:getRealPos().y+35)
                self.label_layer:addChild(tmp_label)
                powered_idx = powered_idx+1               

                 --装备等级
                if equipType == ItemHelper.equipType.equip then
                    if item_lv_idx>=item_lv_count then
                        tmp_label = CCLabelTTF:create()
                        tmp_label:setAnchorPoint(ccp(1,1))
                        tmp_label:setFontSize(22)
                        tmp_label:setScale(0.8)
                        tmp_label:setColor(ItemHelper.colors.deep_yellow)
                        self.item_lv_label_arr:addObject(tmp_label)
                    else
                        tmp_label = self.item_lv_label_arr:objectAtIndex(item_lv_idx)
                    end
                
                    tmp_label:setString(temp_exch_item:getItemLvDesc())
                    tmp_label:setPosition(temp_exch_item:getRealPos().x+100,temp_exch_item:getRealPos().y+105)
                    self.label_layer:addChild(tmp_label)
                    item_lv_idx = item_lv_idx+1
                end
            end
        end

    end
end