--英雄高级属性 描述提示
HeroAdvInfoTips = class("HeroAdvInfoTips",function()
    return DisplayUtil.newFitLayout()
end)
HeroAdvInfoTips.__index = HeroAdvInfoTips
HeroAdvInfoTips._widget     = nil

local __instance = nil

function HeroAdvInfoTips:getInstance()
    if not __instance then
        local ret = HeroAdvInfoTips.new()
        __instance = ret
        ret:init()
        ret:retain()
    end
    return __instance
end

function HeroAdvInfoTips:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/common/Alert.ExportJson")
    self:addChild(self._widget)

    self.img9bg = tolua.cast(self._widget:getChildByName("img_bgaleart"),"ImageView")

    self.labTxt = tolua.cast(self.img9bg:getChildByName("lab_title"),"Label")
    self.labTxt:setColor(ccc3(251,241,160))

end

function HeroAdvInfoTips:setId(id)

    local txt = HeroManager:getInstance():getAttrDescById(id)
    self.labTxt:setText(Helper.insertnl(txt,10))
    self.img9bg:setSize(CCSizeMake( self.labTxt:getSize().width + 50, self.labTxt:getSize().height + 20 ))
end


function HeroAdvInfoTips:show(id)

    local layer = GameLayerMgr:getInstance():getMsgLayer()
    local child = layer:getChildByTag(2505)
    if child ~= nil then
        layer:removeChildByTag(2505,false)
    end

    local panel = HeroAdvInfoTips:getInstance()
    panel:setId(id)
    panel:setTag(2505)
    panel:setPosition(ccp(480,320))
    layer:addChild(panel)
end

function HeroAdvInfoTips:hide()

    local layer = GameLayerMgr:getInstance():getMsgLayer()
    local child = layer:getChildByTag(2505)
    if child ~= nil then
        layer:removeChildByTag(2505,false)
    end
end