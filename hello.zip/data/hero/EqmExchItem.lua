--
-- Author: lvgansheng
-- Date: 2014-07-02 19:42:35
-- 锻造装备替换界面元件
EqmExchItem = class("EqmExchItem")
EqmExchItem.item = nil --元件关联的物品
EqmExchItem.pos = nil --元件关联的英雄站位
EqmExchItem.view_type = 0 --当前是从锻造的哪个标签页进来的
EqmExchItem.item_icon = 0 --当前是从锻造的哪个标签页进来的

function EqmExchItem:init()
  self.gem_icon_bg_dic = {}
  self.gem_icon_dic = {}
	self.gem_icon_border_dic = {}
  self.effect_path = nil
end

function EqmExchItem:create()
	local exch_item = EqmExchItem.new()
	exch_item:init(widget_seed)
	return exch_item
end

function EqmExchItem:setData(item,pos,view_type)

    self.item = item
    self.pos = pos
    self.view_type = view_type
    self:changeContent()
    -- self.item_icon:setBaseId(item.mode.base_id)
end

function EqmExchItem:refreseh()
    if self.item then
        self:changeContent()
        -- self.item_icon:setBaseId(self.item.mode.base_id)
    end
end

function EqmExchItem:changeContent()
  if self.eqm_item_bg  then
      self.eqm_item_bg:initWithSpriteFrameName(string.format("quality_bg_%d.png",self.item.mode.quality))
  end

  if self.eqm_item_icon  then
    self.eqm_item_icon:initWithSpriteFrameName(string.format("item_%d.png",self.item.mode.icon_id))
  end

  if self.eqm_item_border  then
      self.eqm_item_border:initWithSpriteFrameName(string.format("quality_border_%d.png",self.item.mode.quality))
  end

  local gems = self.item.gems
  local gem_item_mode 
  local gem_count = 1
  for gem_idx =1,3 do
      if gems[gem_idx] then
          gem_item_mode = ItemManager:getInstance():getItemModelByBaseId(gems[gem_idx])
          self:getGemIconBgByIdx(gem_count):initWithSpriteFrameName(string.format("quality_bg_%d.png",gem_item_mode.quality))
          self:getGemIconByIdx(gem_count):initWithSpriteFrameName(string.format("item_%d.png",gem_item_mode.icon_id))
          self:getGemIconBorderByIdx(gem_count):initWithSpriteFrameName(string.format("quality_border_%d.png",gem_item_mode.quality))
          gem_count = gem_count+1
      end
  end
end

function EqmExchItem:getEqmIconBg()
  if self.eqm_icon_bg then
    return self.eqm_icon_bg
  else
    self.eqm_icon_bg = CCSprite:createWithSpriteFrameName("eqm_exc_icon_bg_up.png")
    self.eqm_icon_bg:setAnchorPoint(ccp(0,0))
    self.eqm_icon_bg:retain()
    return self.eqm_icon_bg
  end
end

function EqmExchItem:getEqmItemBg()
  if self.eqm_item_bg then
    return self.eqm_item_bg
  else
    self.eqm_item_bg = CCSprite:createWithSpriteFrameName(string.format("quality_bg_%d.png",self.item.mode.quality))
  self.eqm_item_bg:setScale(0.8)    
  self.eqm_item_bg:retain()
    return self.eqm_item_bg
  end
end

function EqmExchItem:getEqmItemIcon()
  if self.eqm_item_icon then
    return self.eqm_item_icon
  else
    self.eqm_item_icon = CCSprite:createWithSpriteFrameName(string.format("item_%d.png",self.item.mode.icon_id))
    -- self.eqm_item_icon:setAnchorPoint(ccp(0,0))
    self.eqm_item_icon:setScale(0.8)
    self.eqm_item_icon:retain()
    return self.eqm_item_icon
  end
end

function EqmExchItem:getEqmItemBorder()
  if self.eqm_item_border then
    return self.eqm_item_border
  else
    self.eqm_item_border = CCSprite:createWithSpriteFrameName(string.format("quality_border_%d.png",self.item.mode.quality))
    -- self.eqm_item_border:setAnchorPoint(ccp(0,0))
      self.eqm_item_border:setScale(0.8)
    self.eqm_item_border:retain()
    return self.eqm_item_border
  end
end

function EqmExchItem:getFashionFlag()
  if self.fashion_flag then
    return self.fashion_flag
  else
    self.fashion_flag = CCSprite:createWithSpriteFrameName("i18n_fashion.png")
      self.fashion_flag:setScale(0.8)
    self.fashion_flag:retain()
    return self.fashion_flag
  end
end

function EqmExchItem:getGemIconBgByIdx(gem_idx)
    local tmp_gem_icon_bg = self.gem_icon_bg_dic[gem_idx]
    if tmp_gem_icon_bg then
      return tmp_gem_icon_bg
    else
      tmp_gem_icon_bg = CCSprite:createWithSpriteFrameName("quality_bg_1.png")
      tmp_gem_icon_bg:retain()
      tmp_gem_icon_bg:setScale(0.4)
      self.gem_icon_bg_dic[gem_idx] = tmp_gem_icon_bg
      return tmp_gem_icon_bg
    end
end

function EqmExchItem:getGemIconByIdx(gem_idx)
    local tmp_gem_icon = self.gem_icon_dic[gem_idx]
    if tmp_gem_icon then
      return tmp_gem_icon
    else
      tmp_gem_icon = CCSprite:createWithSpriteFrameName("item_10000.png")
      tmp_gem_icon:retain()
      tmp_gem_icon:setScale(0.4)
      self.gem_icon_dic[gem_idx] = tmp_gem_icon
      return tmp_gem_icon
    end
end

function EqmExchItem:getGemIconBorderByIdx(gem_idx)
    local tmp_gem_icon_border = self.gem_icon_border_dic[gem_idx]
    if tmp_gem_icon_border then
      return tmp_gem_icon_border
    else
      tmp_gem_icon_border = CCSprite:createWithSpriteFrameName("quality_border_1.png")
      tmp_gem_icon_border:retain()
      tmp_gem_icon_border:setScale(0.4)
      self.gem_icon_border_dic[gem_idx] = tmp_gem_icon_border
      return tmp_gem_icon_border
    end
end

function EqmExchItem:getNameLabelQuality()
  return ItemHelper:getColorByQuality(self.item.mode.quality)
end

function EqmExchItem:setRealPos(real_pos)

  self.real_pos = real_pos

  if self.eqm_icon_bg then
    self.eqm_icon_bg:setPosition(real_pos)
  end

  if self.eqm_item_bg then
    self.eqm_item_bg:setPosition(ccp(real_pos.x+65,real_pos.y+75))
  end

  if self.eqm_item_icon then
    self.eqm_item_icon:setPosition(ccp(real_pos.x+65,real_pos.y+75))
  end

  if self.eqm_item_border then
    self.eqm_item_border:setPosition(ccp(real_pos.x+65,real_pos.y+75))
  end

  if self.fashion_flag then
    self.fashion_flag:setPosition(ccp(real_pos.x+32,real_pos.y+110))
  end

  for gem_idx =1,3 do
    if self.gem_icon_bg_dic[gem_idx] then
      self.gem_icon_bg_dic[gem_idx]:setPosition(ccp(real_pos.x+83+(55*gem_idx),real_pos.y+35))
    end

    if self.gem_icon_dic[gem_idx] then
      self.gem_icon_dic[gem_idx]:setPosition(ccp(real_pos.x+83+(55*gem_idx),real_pos.y+35))
    end

    if self.gem_icon_border_dic[gem_idx] then
      self.gem_icon_border_dic[gem_idx]:setPosition(ccp(real_pos.x+83+(55*gem_idx),real_pos.y+35))
    end
  end

  if self.enchant_effect then
     self.enchant_effect:setPosition(ccp(real_pos.x+65,real_pos.y+75))
  end

  if self.unidentify_ect then
    self.unidentify_ect:setPosition(ccp(real_pos.x+104,real_pos.y+94))
  end
end

function EqmExchItem:getEnchantEct()
  local effect_name = ItemHelper:getEnchentEffectName(self.item.enchant_lev)
  local effect_path = string.format("ui/effects_ui/%s/%s.ExportJson",effect_name,effect_name)

  if self.item.enchant_lev>0 and effect_name then
    if self.enchant_effect and self.effect_path == effect_name then
      return self.enchant_effect
    else
      if self.enchant_effect then
        self.enchant_effect:release()
      end
      self.enchant_effect = AnimateManager:getInstance():getArmature(effect_path,effect_name)
      self.enchant_effect:getAnimation():playWithIndex(0,-1,-1,1)
      self.enchant_effect:setScale(0.8)
      self.effect_path = effect_name
      self.enchant_effect:retain()
      return self.enchant_effect
    end
  end
end

function EqmExchItem:getUnIdentifyEct()

  if self.unidentify_ect then
    return self.unidentify_ect
  else
    if self.unidentify_ect then
      self.unidentify_ect:release()
    end
    self.unidentify_ect = EffectManager:getInstance():createUIAnimate("weijianding")
    self.unidentify_ect:getAnimation():playWithIndex(0,-1,-1,1)
    self.unidentify_ect:retain()
    self.unidentify_ect:setAnchorPoint(ccp(0,1))
    return self.unidentify_ect
  end
  
end


function EqmExchItem:getRealPos()
  return self.real_pos
end

function EqmExchItem:getNameDesc()
  return self.item.mode.name
end

function EqmExchItem:getLvDesc()
  return "等級:  "..self.item.mode.limit_lev
end

function EqmExchItem:getIdentifyDesc()
    if self.item.total_identify_stars > 0 then
          return string.format("%d星",self.item.total_identify_stars)
    elseif ItemManager:getInstance():canIdentify(self.item) then
          return ""
    else
        return ""
    end
end

--是否显示未鉴定特效
function EqmExchItem:isShowUnIdentifyEffect()
  if self.item.total_identify_stars <= 0 and
  ItemManager:getInstance():canIdentify(self.item) then
    return true
  end

  return false
end

function EqmExchItem:isShowEnchantEct()
  if self.item.enchant_lev>2 then
    return true
  end
  return false
end

function EqmExchItem:getEnchantLv()
  return self.item.enchant_lev
end

function EqmExchItem:hasParent()
  return self.eqm_icon_bg:getParent()
end

function EqmExchItem:getItemData()
  return self.item
end

function EqmExchItem:getItemBaseId()
  return self.item.mode.base_id
end

function EqmExchItem:getPoweredDesc()
  if self.item.powered_lev>0 then
    return "+"..self.item.powered_lev
  else
    return ""
  end
end

function EqmExchItem:getItemLvDesc()
  return "lv."..self.item.mode.limit_lev
end
