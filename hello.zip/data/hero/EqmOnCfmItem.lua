--
-- Author: lvgansheng
-- Date: 2014-09-15 14:44:34
-- 装备确认界面

EqmOnCfmItem = class("EqmOnCfmItem", WidgetBase)

function EqmOnCfmItem:init()
	--self.uiLayer = TouchGroup:create() 
    --self:addChild(self.uiLayer)
    require("AttrLabel")
    
    -- self.win_type = win_type or 0

	self.attr_label_dic = CCDictionary:create()
	self.attr_label_dic:retain()	

	-- self.gem_icon_dic = CCDictionary:create()
	-- self.gem_icon_dic:retain()

	-- self.gem_layer = DisplayUtil.newLayout()
	-- self.gem_layer:setSize(CCSize(200,70))
	-- self.gem_layer:retain()

	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/backpack/eqm_info_comp/eqm_info_comp.ExportJson")
    self:addChild(self.widget)

    self.item_icon = ItemIcon:create()
    self.item_icon:setPosition(ccp(75,455))
    self:addChild(self.item_icon)

    self.attr_list_view = tolua.cast(self.widget:getChildByName("attr_listview"), "ListView") 

    self.team_lv_label = AttrLabel:create()
    self.team_lv_label:retain()
    self.team_lv_label:setData("戰隊等級:",10)
    --self.attr_list_view:pushBackCustomItem(self.team_lv_label)

    self.item_type_label = AttrLabel:create()
    self.item_type_label:setData("裝備類型:","武器")
    self.item_type_label:retain()
   -- self.attr_list_view:pushBackCustomItem(self.item_type_label)

    self.base_attr_label = AttrLabel:create()
    self.base_attr_label:setData("基礎屬性","100")
     self.base_attr_label:retain()
   -- self.attr_list_view:pushBackCustomItem(self.item_type_label)

    self.powered_lv_label = AttrLabel:create()
    self.powered_lv_label:setData("強化等級：","1")
    self.powered_lv_label:retain()

    self.powered_attr_label = AttrLabel:create()
    self.powered_attr_label:setData("強化屬性：","1")
    self.powered_attr_label:retain()
   -- self.attr_list_view:pushBackCustomItem(self.item_type_label)

    self.enchant_label = AttrLabel:create()
    self.enchant_label:setData("附魔等級:1級")
    -- self.enchant_label:setEachLabelColor(ItemHelper.colors.deep_yellow, 
    --  					ItemHelper.colors.green, ItemHelper.colors.green)
    self.enchant_label:retain()
   -- self.attr_list_view:pushBackCustomItem(self.item_type_label)



    self.identify_dec_label = AttrLabel:create()
    self.identify_dec_label:setData("鑒定屬性:")
    self.identify_dec_label:retain()
   -- self.attr_list_view:pushBackCustomItem(self.identify_dec_label)

    -- self.gem_dec_label = AttrLabel:create()
    -- self.gem_dec_label:setData("鑲嵌寶石:")
    -- self.gem_dec_label:setSize(CCSize(300,38))
    -- self.gem_dec_label:retain()

    self.gem_one_label =  AttrLabel:create()
    self.gem_one_label:setData("11級防禦石:","+800氣血")
    self.gem_one_label:setSize(CCSize(300,38))
    self.gem_one_label:retain()

    self.gem_two_label =  AttrLabel:create()
    self.gem_two_label:setData("11級防禦石:","+800氣血")
    self.gem_two_label:setSize(CCSize(300,38))
    self.gem_two_label:retain()

    self.gem_three_label =  AttrLabel:create()
    self.gem_three_label:setData("11級防禦石:","+800氣血")
    self.gem_three_label:setSize(CCSize(300,38))
    self.gem_three_label:retain()

   	self.desc_layout = DisplayUtil.newLayout()
   	self.desc_layout:retain()
   	self.desc_layout:setSize(CCSize(300,105))

   	self.item_desc = Label:create()
   	self.item_desc:setColor(ItemHelper.colors.yellow)
   	self.item_desc:ignoreContentAdaptWithSize(false)
	self.item_desc:setAnchorPoint(ccp(0,0.4))
	self.item_desc:setPositionX(10)
	self.item_desc:setSize(CCSize(282,105))
   	self.item_desc:setFontSize(24)
  	-- self.desc_layout:retain()
   	self.desc_layout:addChild(self.item_desc)

end

function EqmOnCfmItem:create(win_type)
	local item_info_view = EqmOnCfmItem.new()
	item_info_view:init(win_type)
	return item_info_view
end

function EqmOnCfmItem:setItemData(item, cur_item)
	self.itemData = item 
	self.cur_item = cur_item 
	self.attr_flag = ItemHelper:getAttrFlagByLocation(item.mode.item_type)
	
	self:changeContent()
end

function EqmOnCfmItem:changeContent()
	self.item_icon:setBaseId(self.itemData.mode.base_id)

	local namelabel = self.widget:getChildByName("name_label")
	tolua.cast(namelabel,"Label")
	namelabel:setText(self.itemData.mode.name)
	namelabel:setColor(ItemHelper:getColorByQuality(self.itemData.mode.quality))

	self.attr_list_view:removeAllItems()

	if self.itemData.mode.limit_lev>0 then
		self.team_lv_label:setData("戰隊等級:",self.itemData.mode.limit_lev)
		self.attr_list_view:pushBackCustomItem(self.team_lv_label)
	end

	--local fc_txt_img = self.widget:getChildByName("ImageView_55")
	--local fc_txt_label = tolua.cast(self.widget:getChildByName("fight_capacity_label"), "Label") 

	local temp_item = self.cur_item or self.itemData
	local enchant_ratio = ItemManager:getInstance():getEnchantRation(temp_item.enchant_lev)+1 -- 附魔系数

	self.item_type_label:setData("裝備類型:",ItemHelper:getTypeName(temp_item.mode.item_type))
	
	local attr_name = AttrHelper:getAttrNameByFlag(self.attr_flag)
 	local attrs = ItemManager:getInstance():getEqmBaseAttrAddQuality(self.itemData.mode.base_id)
 	local base_attr_comp = nil
 	
 	if self.cur_item then
 		local value_one = ItemManager:getInstance():getEqmBaseAttrAddQuality(self.itemData.mode.base_id)[self.attr_flag]
 		local value_two = ItemManager:getInstance():getEqmBaseAttrAddQuality(self.cur_item.mode.base_id)[self.attr_flag]
 		if value_one > value_two then
 			base_attr_comp = 1
 		elseif value_one < value_two then
 			base_attr_comp =2
 		end
 	end

 	if enchant_ratio>1 then
		self.base_attr_label:setData(attr_name..":", attrs[self.attr_flag],
			math.ceil(attrs[self.attr_flag]*enchant_ratio), base_attr_comp)
	else
		self.base_attr_label:setData(attr_name..":",math.ceil(attrs[self.attr_flag]), "", base_attr_comp)
	end

	self.attr_list_view:pushBackCustomItem(self.item_type_label)
	self.attr_list_view:pushBackCustomItem(self.base_attr_label)

	--强化等级处理
	if temp_item.powered_lev>0 then
		 local powered_attrs =  ItemManager:getInstance():getEqmPoweredAttr(self.itemData.mode.base_id,
		 						temp_item.powered_lev)
		 self.powered_lv_label:setData("強化等級:",temp_item.powered_lev)
		 self.attr_list_view:pushBackCustomItem(self.powered_lv_label)
		 if enchant_ratio>1 then
		 	self.powered_attr_label:setData(attr_name..":",powered_attrs[self.attr_flag],
		 										math.ceil(powered_attrs[self.attr_flag]*enchant_ratio))
		 else
		 	self.powered_attr_label:setData(attr_name..":",math.ceil(powered_attrs[self.attr_flag]))
		 end
		 self.attr_list_view:pushBackCustomItem(self.powered_attr_label)
	end 

	--附魔等级处理
	if temp_item.enchant_lev>0 then
		self.enchant_label:setEachLabelColor(2,ItemHelper:getEnchantColor(temp_item.enchant_lev))
		self.powered_attr_label:setEachLabelColor(3,ItemHelper:getEnchantColor(temp_item.enchant_lev))
		self.base_attr_label:setEachLabelColor(3,ItemHelper:getEnchantColor(temp_item.enchant_lev))

		self.enchant_label:setData("附魔等級:",string.format("%d級",temp_item.enchant_lev))
		self.attr_list_view:pushBackCustomItem(self.enchant_label)
		-- self.enchant_label:set
	end

	--鉴定属性处理
	local identify_attrs = self.itemData.identify_attrs
	local count = #identify_attrs
	local attr_vo = nil
	local attr_label = nil
	if count>0 then
		self.attr_list_view:pushBackCustomItem(self.identify_dec_label)

		for key=1,count do
			attr_vo = identify_attrs[key]
			attr_label = self.attr_label_dic:objectForKey(key)
			if attr_label == nil then
				attr_label = AttrLabel:create()
				self.attr_label_dic:setObject(attr_label, key)
			end
			attr_label:setData(AttrHelper:getAttrNameByFlag(attr_vo.flag)..":",string.format("%d   (%d星)",
								attr_vo.value,attr_vo.stars))
			--attr_label:setData(AttrHelper:getAttrNameByFlag(attr_vo.flag)..":",
									-- attr_vo.value,string.format("(%d星)",attr_vo.stars))
			self.attr_list_view:pushBackCustomItem(attr_label)
		end
	end

	-- local gem_item_icon = nil
	-- local gems = temp_item.gems
	-- local gem_dis = 0
	-- local temp_gem_data = nil
	-- for gem_idx =1,3 do
	-- 	gem_item_icon = self.gem_icon_dic:objectForKey(gem_idx)
	-- 	if gem_item_icon == nil then
	-- 		gem_item_icon = ImageView:create()
	-- 		gem_item_icon:setScale(0.7)
	-- 		gem_item_icon:setAnchorPoint(ccp(0,0))
	-- 		self.gem_icon_dic:setObject(gem_item_icon, gem_idx)
	-- 		self.gem_layer:addChild(gem_item_icon)
	-- 	end

	-- 	if gems[gem_idx] then
	-- 		temp_gem_data = ItemManager:getInstance():getItemModelByBaseId(gems[gem_idx])
	-- 		gem_item_icon:loadTexture(string.format("item_%d.png",temp_gem_data.icon_id), UI_TEX_TYPE_PLIST)
	-- 		gem_item_icon:setVisible(true)
	-- 		gem_item_icon:setPositionX(gem_dis+5)
	-- 		gem_dis = gem_dis+70
	-- 	else
	-- 		gem_item_icon:setVisible(false)
	-- 	end
	-- end

	-- if gem_dis>0 then
	-- 	self.attr_list_view:pushBackCustomItem(self.gem_dec_label)
	-- 	self.attr_list_view:pushBackCustomItem(self.gem_layer)

	-- end

	local gems = temp_item.gems
	local gem_label_status ={}
	local temp_item_mode = nil
	local temp_gem_data = nil
	local gem_attr_name = nil
	local gem_value_str = nil
	for gem_idx =1,3 do
		if gems[gem_idx] then
			temp_item_mode = ItemManager:getInstance():getItemModelByBaseId(gems[gem_idx])
			temp_gem_data =  ItemManager:getInstance():getGemInfo(gems[gem_idx])

			if self.gem_one_label:getParent()==nil then
				self.gem_one_label:setData(temp_item_mode.name..":",string.format(" +%d",
						temp_gem_data.val,AttrHelper:getAttrNameByFlag(temp_gem_data.attr_type)))
				self.attr_list_view:pushBackCustomItem(self.gem_one_label)
			elseif self.gem_two_label:getParent()==nil then
				self.gem_two_label:setData(temp_item_mode.name..":",string.format(" +%d",
						temp_gem_data.val,AttrHelper:getAttrNameByFlag(temp_gem_data.attr_type)))
				self.attr_list_view:pushBackCustomItem(self.gem_two_label)
			elseif self.gem_three_label:getParent()==nil then	
				self.gem_three_label:setData(temp_item_mode.name..":",string.format(" +%d",
						temp_gem_data.val,AttrHelper:getAttrNameByFlag(temp_gem_data.attr_type)))
				self.attr_list_view:pushBackCustomItem(self.gem_three_label)
			end

		end
	end

	self.item_desc:setText(self.itemData.mode.desc)
	self.attr_list_view:pushBackCustomItem(self.desc_layout)

end