--
-- Author: lvgansheng
-- Date: 2014-07-02 11:02:12
-- 装备强化界面

EqmPoweredView =  class("EqmPoweredView",WidgetBase)
EqmPoweredView.uiLayer = nil
EqmPoweredView.widget = nil
EqmPoweredView.enterFun = nil 
EqmPoweredView.exitFun = nil
EqmPoweredView.item = nil
EqmPoweredView.location = 0
EqmPoweredView.equip_icon = nil

local item_mgr = ItemManager:getInstance()
local success_animate_path = "ui/effects_ui/zhuangbeiqianghua/zhuangbeiqianghua.ExportJson"
local success_animation_tag = 1211

function EqmPoweredView:init()

	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/equip/equip_powered/equip_powered.ExportJson")
    self:addChild(self.widget)

    self.panel_one = self.widget:getChildByName("panel_one")

    self.tips_label_one = tolua.cast(self.widget:getChildByName("tips_label_one"), "Label")
    -- self.tips_label_two = tolua.cast(self.widget:getChildByName("tips_label_two"), "Label")

    self.tips_label_one:setText("您的裝備強化等級已滿，提高戰隊\n等級可提升裝備強化等級上限哦")

    -- self.equip_icon = EquipIcon:create()
    -- self.equip_icon:setPosition(ccp(162,408))
    -- -- self:addChild(self.equip_icon)

    self.cost_label = self.widget:getChildByName("cost_label")
    tolua.cast(self.cost_label, "Label")

	self.powered_btn = self.widget:getChildByName("powered_btn")
	local function onSendPowerReq(sender, eventType)
	    if eventType == ComConstTab.TouchEventType.ended then

            local function progress()
                if self.isLock == true then
                    cclog("不給你點擊")
                    return
                end
                
                self._onLockBtn()

    	        ItemManager:getInstance():sendPoweredReq(self.item.hero_id, self.location, self.item.id)
                -- cclog("發送強化協議")
            end

            ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Forge,progress) --判断该功能是否开放
        end
	end
	self.powered_btn:addTouchEventListener(onSendPowerReq)


    local batch_powered_btn = self.widget:getChildByName("batch_powered_btn")

    batch_powered_btn:addTouchEventListener(function(sender, eventType) 
        if eventType == ComConstTab.TouchEventType.ended then
           WindowCtrl:getInstance():open(CmdName.EqmBatchPoweredView)
        end
    end)

    local single_full_powered_btn = self.widget:getChildByName("single_full_powered_btn")
    single_full_powered_btn:addTouchEventListener(function(sender, eventType) 
        if eventType == ComConstTab.TouchEventType.ended then
            local can_powered_lv=CharacterManager:getInstance():getTeamData():getLev()
            local cur_powered_lv=self.item.powered_lev
            if cur_powered_lv==can_powered_lv then
                Alert:show(string.format("當前裝備已強化至%d級，不需要再強化哦。",cur_powered_lv))
            else
                local cost = ItemManager:getInstance():getSingleFullPoweredCost(cur_powered_lv,can_powered_lv)
                local cur_coin = CharacterManager:getInstance():getAssetData():getGold()
                local params = {}
                if cost>cur_coin then --不够钱时
                    -- params["txt"] = string.format("強化消耗%d金幣,你的金幣不足購買地精的金礦可獲得大量金幣",cost)
                    params["rtf"]={{txt="單件滿級需消耗", color=ItemHelper.colors.yellow, fontSize=22},
                                {txt=cost, color=ItemHelper.colors.red, fontSize=22},
                                {txt="金幣,", color=ItemHelper.colors.yellow, fontSize=22},
                                {txt="您的金幣不足，可前往地精的金礦購買大量金幣哦。", color=ItemHelper.colors.yellow, fontSize=22}}
                    params["okFunc"] = function()
                        WindowCtrl:getInstance():open(CmdName.Character_buyCoin)
                    end
                else
                    params["txt"] = string.format("將單件裝備強化至 %d 級\n強化消耗 %d 金幣",can_powered_lv,cost)
                    params["okFunc"] = function()
                        -- WindowCtrl:getInstance():open(CmdName.Character_buyCoin)
                        ItemManager:getInstance():sendBatchPoweredReq(can_powered_lv, self.item.hero_id, self.location)
                    end    
                    -- params["rtf"]={{txt=string.format("將單件裝備強化至 %d 級\n強化消耗",can_powered_lv), color=ItemHelper.colors.yellow, fontSize=22},
                    --             {txt=cost, color=ItemHelper.colors.red, fontSize=22},
                    --             {txt="金幣", color=ItemHelper.colors.yellow, fontSize=22}}
                    -- params["okFunc"] = function()
                    --     WindowCtrl:getInstance():open(CmdName.Character_buyCoin)
                    -- end
                end
                WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
            end
        end
    end)


    -- local exch_btn = self.widget:getChildByName("exch_btn")
    -- local function onExchBtnClick(sender, eventType)
    --     if eventType == ComConstTab.TouchEventType.ended then
    --        WindowCtrl:getInstance():open(CmdName.EqmExchView,HeroHelper.forgePanelType.powered)
    --     end
    -- end
    -- exch_btn:addTouchEventListener(onExchBtnClick)

    self._onEqmPoweredSuc = function (item_id )
        if self.item.id ~= item_id then
            return 
        end

        --播放强化成功特效
        if self.success_animation == nil then
            self.success_animation = AnimateManager:getInstance():getArmature(success_animate_path,"zhuangbeiqianghua") 
            self.success_animation:setPosition(ccp(245,407))
            self.success_animation:retain()
            self.success_animation:setTag(success_animation_tag)
        end

        self.success_animation:getAnimation():setMovementEventCallFunc(self._onPlayCallBack )
        -- self.success_animation:removeFromParentAndCleanup(true)
        self:removeNodeByTag(success_animation_tag)
        self:addNode(self.success_animation)
        self.success_animation:getAnimation():playWithIndex(0)

        self.item = ItemManager:getInstance():getEquipInfoById(item_id)
        self:changeExtInfo() 
        --新手引导事件
        if GuideDataProxy:getInstance().nowMainTutroialEventId == 10505 then
            Notifier.dispatchCmd(GuideEvent.StepFinish,"click_strongbtn")
        end
    end

     self._onPlayCallBack = function( armature, movementType, movementID )
        if movementType == AnimationMovementType.COMPLETE then
            self.success_animation:getAnimation():stop()
            self.success_animation:getAnimation():setMovementEventCallFunc(function() end)
            self:removeNodeByTag(success_animation_tag)
        end
    end

    self._onLockBtn = function()
        self.isLock = true
        self.powered_btn:setBright(false)
        TimerManager.addTimer(3000, self._onShowLoading)
    end

    self._onShowLoading = function()
       Loading:show()
       TimerManager.addTimer(7000, self._onShowTryAgain)
    end
   
    self._onShowTryAgain = function()
        Loading:hide()
        self._onUnlock()
        -- local params = {}
        -- params["txt"] = "您那渣一般的網路啊，是否重試？"
        -- params.okFunc = function()
        --   onSendPowerReq(self.powered_btn,ComConstTab.TouchEventType.ended)
        -- end
        -- WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
    end
    
    self._onUnlock = function()
        TimerManager.removeTimer(self._onShowLoading)
        TimerManager.removeTimer(self._onShowTryAgain)
        Loading:hide()
        self.isLock = false
        self.powered_btn:setBright(true)
    end

    self._onEqmBatchPoweredSucc = function()
        self.item = ItemManager:getInstance():getEquipInfoById(self.item.id)
        self:changeExtInfo()

    end

    self._onUpdateAsset = function()
        self:setCoseLabelColor()
    end

    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function EqmPoweredView:create()
	local view = EqmPoweredView.new()
	view:init()
	return view
end

--新手引导动画
function EqmPoweredView:showStepAnim(param)
    if param.target == "forge_strongbtn" then
        GuideRenderMgr:getInstance():renderMainFlag(self.powered_btn,param.id,param.target)
    elseif param.target == "power_exit" then
        GuideRenderMgr:getInstance():renderMainFlag(self.widget,param.id,param.target)
    end
end

function EqmPoweredView:open()
    Notifier.regist(CmdName.EqmPoweredSuccess,self._onEqmPoweredSuc)
    Notifier.regist(CmdName.Eqm_UnLocked,self._onUnlock)
    Notifier.regist(CmdName.EqmBatchPoweredSucc,self._onEqmBatchPoweredSucc)
    Notifier.regist(CmdName.RSP_UPDATE_ROLE_ASSET,self._onUpdateAsset)
end

function EqmPoweredView:close()
    self._onUnlock()
    Notifier.remove(CmdName.EqmPoweredSuccess,self._onEqmPoweredSuc)
    Notifier.remove(CmdName.Eqm_UnLocked,self._onUnlock)
    Notifier.remove(CmdName.EqmBatchPoweredSucc,self._onEqmBatchPoweredSucc)     
    Notifier.remove(CmdName.RSP_UPDATE_ROLE_ASSET,self._onUpdateAsset)

    self:disposeSucAnim()
    --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10508 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"exit_power")
    end
end

--移除并销毁强化成功时的动画
function EqmPoweredView:disposeSucAnim()
    if self.success_animation then
        self.success_animation:getAnimation():stop()
        self.success_animation:getAnimation():setMovementEventCallFunc(function() end)
        self:removeNodeByTag(success_animation_tag)
        self.success_animation:release()
        self.success_animation = nil
        AnimateManager:getInstance():clear(success_animate_path)
    end
end

function EqmPoweredView:setData(item,location)
	self.item = item
	self.location = location
	self.attr_flag = ItemHelper:getAttrFlagByLocation(location)
	self:changeBaseInfo()
	self:changeExtInfo()
    -- self.equip_icon:setItem(item)
end

function EqmPoweredView:changeBaseInfo()
	--local nameLabel = self.widget:getChildByName("name_label")
  --  tolua.cast(nameLabel, "Label")
   -- nameLabel:setText(self.item.mode.name)
end

function EqmPoweredView:changeExtInfo()

   -- local powered_label = self.widget:getChildByName("Label_282")
   -- tolua.cast(powered_label, "Label")
   -- powered_label:setText(string.format("+%d",self.item.powered_lev)) 

    local cur_lev_label = self.panel_one:getChildByName("cur_lev_label")
    tolua.cast(cur_lev_label, "Label")
    cur_lev_label:setText(string.format("lv.%d",self.item.powered_lev))   

    local next_lev_label = self.panel_one:getChildByName("next_lev_label")
    tolua.cast(next_lev_label, "Label")
    next_lev_label:setText(string.format("lv.%d",self.item.powered_lev+1))
    
    local cur_attrs = nil
    local equipType = ItemHelper:getEquipTypeWithItemType(self.location)
    if equipType == ItemHelper.equipType.equip then
        cur_attrs = ItemManager:getInstance():getEqmPoweredAttr(self.item.mode.base_id,self.item.powered_lev)
    elseif equipType == ItemHelper.equipType.fashion then
        cur_attrs = ItemManager:getInstance():getFashionPoweredAttr(self.item.hero_id,self.location,self.item.powered_lev)
    end
    for k,v in pairs(cur_attrs) do
        if v > 0 then
            self.attr_flag = k
            break
        end
    end
    local attr_name = AttrHelper:getAttrNameByFlag(self.attr_flag)

    local cur_attr_name_label =  tolua.cast(self.panel_one:getChildByName("cur_attr_name_label"), "Label")
    local cur_value_label =  tolua.cast(self.panel_one:getChildByName("cur_value_label"), "Label")
  
    cur_attr_name_label:setText(attr_name)   
    cur_value_label:setText(string.format("+%d",cur_attrs[self.attr_flag]))   

    local next_attrs = nil
   
    if equipType == ItemHelper.equipType.equip then
        next_attrs = ItemManager:getInstance():getEqmPoweredAttr(self.item.mode.base_id,self.item.powered_lev+1)
    elseif equipType == ItemHelper.equipType.fashion then
        next_attrs = ItemManager:getInstance():getFashionPoweredAttr(self.item.hero_id,self.location,self.item.powered_lev+1)
    end
    local next_value_label = tolua.cast(self.panel_one:getChildByName("next_value_label"), "Label")
    local next_attr_name_label = tolua.cast(self.panel_one:getChildByName("next_attr_name_label"), "Label")
    next_attr_name_label:setText(attr_name) 
    next_value_label:setText(string.format("+%d",next_attrs[self.attr_flag])) 

    self.cost_label:setText(ItemManager:getInstance():getPoweredCostCoin(self.item.powered_lev+1))
    self:setCoseLabelColor()
     -- local need_team_lv = ItemManager:getInstance():getPoweredCostCoin(self.item.powered_lev+1)
     -- local need_team_lv = ItemManager:getInstance():getPoweredTeamLv(self.item.powered_lev+1)
      
     if CharacterManager:getInstance():getTeamData():getLev()<self.item.powered_lev+1 then
        self.tips_label_one:setVisible(true)
        -- self.tips_label_two:setVisible(true)
        self.panel_one:setVisible(false)
        self.powered_btn:setBright(false)
        self.powered_btn:setTouchEnabled(false)
        return
    else
        self.tips_label_one:setVisible(false)
        -- self.tips_label_two:setVisible(false)
        self.panel_one:setVisible(true)
        self.powered_btn:setBright(true)
        self.powered_btn:setTouchEnabled(true)
    end
   
end

function EqmPoweredView:setCoseLabelColor()
    local cost_coin = ItemManager:getInstance():getPoweredCostCoin(self.item.powered_lev+1)
    if cost_coin>CharacterManager:getInstance():getAssetData():getGold() then
        self.cost_label:setColor(ItemHelper.colors.red)
    else
        self.cost_label:setColor(ItemHelper.colors.yellow)
    end
end