--装备锁屏特效

EqmCommAnimPanel = class("EqmCommAnimPanel",WindowBase)
EqmCommAnimPanel.__index = EqmCommAnimPanel
EqmCommAnimPanel._widget    = nil
EqmCommAnimPanel.uiLayer    = nil
EqmCommAnimPanel.is_dispose = true

local alert_str = ""

function EqmCommAnimPanel:create()
	return EqmCommAnimPanel.new()
end

function EqmCommAnimPanel:init()

	self:addDefaultShadow()

    self.uiLayer = TouchGroup:create()
    self.uiLayer:setTouchPriority(-500)
    self:addChild(self.uiLayer,0)

    self._widget = Layout:create()
    self._widget:setZOrder(10)
    self._widget:setTouchEnabled(true)
    self._widget:setSize(CCSize(960,640))
    self.uiLayer:addWidget(self._widget)

    --批量强化特效
    local suc_anim_batchpower_path = "ui/effects_ui/piliangqianghua/piliangqianghua.ExportJson"
    local suc_anim_batchpower = AnimateManager:getInstance():getArmature(suc_anim_batchpower_path,"piliangqianghua")
    suc_anim_batchpower:getAnimation():playWithIndex(0)
    suc_anim_batchpower:setPosition(ccp(480,320 - 50))
    self._widget:addNode( suc_anim_batchpower,10 )
    suc_anim_batchpower:getAnimation():setMovementEventCallFunc(function( armature, movementType, movementID)
        if movementType == AnimationMovementType.COMPLETE or 
            movementType == AnimationMovementType.LOOP_COMPLETE then

            armature:getAnimation():stop()
            armature:getAnimation():setMovementEventCallFunc(function() end)
            -- suc_anim_batchpower:removeFromParentAndCleanup(true)

            AnimateManager:getInstance():clear(suc_anim_batchpower_path)

            WindowCtrl:getInstance():close(self.name)

            Alert:show(alert_str)
        end
    end)
end

function EqmCommAnimPanel:open()
    if self.params and self.params.is_batch_powered==false then
        alert_str = "單件強化滿級成功"
    else
        alert_str = "批量強化成功"
    end
end

function EqmCommAnimPanel:dispose()
	if self._widget then
		self._widget:removeFromParentAndCleanup(true)
	end
end
