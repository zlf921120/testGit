--
-- Author: lvgansheng
-- Date: 2014-06-13 10:48:29
-- 卡牌信息管理器
require("TeamEnum")
require "HeroFashionData"
require "FashionGrowData"

HeroManager = class("HeroManager")

HeroManager.MAX_HERO_LEVEL = 99 --目前最大英雄等级
HeroManager.LEADING_HERO_ID = 10000--主角ID
HeroManager.MAX_HERO_STAR = 5--英雄最大星级

HeroManager.PLOT_HERO_ID = 50000 --剧情主角ID

HeroManager.isHeroListInit = false
HeroManager.hero_list = nil
HeroManager.isread = false
HeroManager.HeroInfoDic = nil --记录卡牌基础信息
HeroManager.base_attr_Dic = nil --记录卡牌基础属性
HeroManager.grow_attr_Dic = nil --记录卡牌成长属性值
HeroManager.lev_up_dic = nil --记录英雄升级经验
HeroManager.upgrade_cost_dic = nil --记录英雄升级经验
HeroManager.hero_act_list = nil --英雄
HeroManager.hero_skill_eff_data = nil --英雄界面，技能特效列表

HeroManager.battle_hero_eqm_list = nil --上阵英雄的装备列表

local is_load_hero_plist = false -- 是否已经加载过英雄头像资源
local is_load_skill_icon_plist = false -- 是否已经加载过技能图标资源

local item_mgr = nil 

local _instance = nil
local _allowInstance = false

HeroManager.final_attrs = nil -- 存储英雄的最终属性，避免频繁计算
HeroManager.attr_ischange = nil -- 是否需要重新计算某英雄的属性

HeroManager.battle_eqm_status = nil  --记录上阵部位是否存在可更换的新装备的状态
HeroManager.hero_upgrade_status = nil -- 记录英雄是否当前可以进阶
HeroManager.soul_stone_list = nil --灵魂石跟英雄ID的对应
HeroManager.better_eqm_guide_id_list = nil

HeroManager._fashionDataDict = nil --时装数据字典(主键是hero_id)
HeroManager._fashionDataDict2 = nil --时装数据字典(主键是base_id)
HeroManager._fashionDataDict3 = nil --时装数据字典(主键是fashion_id)
HeroManager._attrDescDict = nil --属性描述

HeroManager.MIN_GEM_LV_FOR_SUIT = 5 --宝石套装需要的所有宝石最低等级
HeroManager.MAX_GEM_LV_FOR_SUIT = 20 --宝石套装的最高等级
HeroManager.TOTAL_GEM_COUNT = 24 --总的宝石数量
HeroManager.MIN_ENCHANT_LV_FOR_SUIT = 5 --附魔套装需要的所有宝石最低等级
HeroManager.MAX_ENCHANT_LV_FOR_SUIT = 12 --附魔套装的最高等级
HeroManager.TOTAL_ENCHANT_COUNT = 8

local is_eqm_status_init = false

function HeroManager:ctor()

    if not _allowInstance then
        error("HeroManager is a singleton class,please call getInstance method")
        -- return
    end

    require("HeroInfo")
    require("EquipListVo")
    require("EquipVo")
    require("HeroBaseAttr")
    require("HeroGrowAttr")
    require("AttrHelper")
    require("fnt_hero_data_pb")
    require("fnt_find_eqm_data_pb")
    require("hero_pb")
    require("ItemManager")
    require("TeamManager")
    require("TeamEnum")

    item_mgr = ItemManager:getInstance()
    self.HeroInfoDic = {}
    self.base_attr_Dic = {}
    self.grow_attr_Dic = {}
    self.final_attrs = {}
    self.attr_ischange = {}
    self.lev_up_dic = {}
    self.upgrade_cost_dic = {}
    self.hero_act_list = {}
    self.hero_skill_eff_data = {}
    self.battle_hero_eqm_list = {}
    self.battle_eqm_status = {}
    self.hero_upgrade_status = {}
    self.soul_stone_list = {}
    self.find_eqm_list = {}
    self.soul_stone_guide_list = {}
    self.better_eqm_guide_list = {} --更好装备引导列表
    self.upgrade_res_guide_list = {} --装备升级 材料 引导列表
    self.pet_feed_guide_list = {} --侍宠喂养 材料 引导列表
    self.better_eqm_guide_id_list = {} --根据id 获取 更好装备列表
    self.defguard_guide_list = {} --守卫引导
    self.fashion_guide_list = {}
    self._fashionDataDict = {}
    self._fashionDataDict2 = {}
    self._fashionDataDict3 = {}
    self._fashionGrowDict = {} --时装进阶属性
    self._attrDescDict = {}

    self:readHeroData()
    self:addEvent()

end

function HeroManager:getInstance()

    if _instance == nil then
        _allowInstance = true
        _instance = HeroManager.new()
        _allowInstance = false
    end

    return _instance

end

function HeroManager:loadHeroIconPlist()
  if is_load_hero_plist then
    return
  end

  CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/common/hero_icon.plist", "ui/common/hero_icon.pvr.ccz")
  is_load_hero_plist = true
end

function HeroManager:loadSkillIconPlist()
  if is_load_skill_icon_plist then
    return
  end

  CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/common/skill_icon.plist", "ui/common/skill_icon.pvr.ccz")
  is_load_skill_icon_plist = true
end

--读取卡牌列表数据
function HeroManager:readHeroData()
     if self.isread then
        return  
     end

    --[[local dataFile = CCFileUtils:sharedFileUtils():fullPathForFilename("fnt_hero_data.dat")
    datafile_handle = io.open(dataFile, "rb")
    pbdata = datafile_handle:read("*a")
    datafile_handle:close()--]]

	  local pbdata = Global:getAssetFileData("fnt_hero_data.dat", "rb")

    local msg = fnt_hero_data_pb.fnt_hero_data()
    msg:ParseFromString(pbdata)

    --卡牌基础信息
    local hero_base_rows = msg.hero_base_rows
    local hero_one_data = nil

    for i, v in pairs(hero_base_rows) do
        if v.base_id~=nil then 
            hero_one_data = HeroInfo.new()
            hero_one_data:setBaseData(v.base_id, v.animat_res_id, v.icon_res_id, v.img_res_id, 
                                      v.name, v.pos, v.lev, v.stars,v.race,v.atk_type,v.desc,v.soul_gem_id)
            hero_one_data.dead_audio_id = v.dead_audio_id
            hero_one_data.charm = v.charm
            hero_one_data:setDefaultSkill(v.act_skill1, v.act_skill2, v.act_skill3, v.pas_skill1, v.pas_skill2, v.pas_skill3)
            self.HeroInfoDic[hero_one_data.base_id] = hero_one_data
            self.soul_stone_list[v.soul_gem_id] = v.base_id
        end
    end
 
    --卡牌基础属性
    local base_attr_rows = msg.base_attr_rows
    local one_attr_data = nil

    for i, v in pairs(base_attr_rows) do
        if v.base_id~=nil then 
             one_attr_data = HeroBaseAttr:create()
             one_attr_data:setData(AttrHelper.attr_flag.hp,v.hp_max)
             one_attr_data:setData(AttrHelper.attr_flag.atk,v.atk)
             one_attr_data:setData(AttrHelper.attr_flag.pdef,v.pdef)
             one_attr_data:setData(AttrHelper.attr_flag.crit,v.crit)
             one_attr_data:setData(AttrHelper.attr_flag.block,v.block)
             one_attr_data:setData(AttrHelper.attr_flag.def_break,v.def_break)
             one_attr_data:setData(AttrHelper.attr_flag.evasion,v.evasion)
             one_attr_data:setData(AttrHelper.attr_flag.atk_speed,v.atk_speed)

             one_attr_data:setData(AttrHelper.attr_flag.fight_back,v.fight_back)
             one_attr_data:setData(AttrHelper.attr_flag.reduce_harm,v.reduce_harm)
             one_attr_data:setData(AttrHelper.attr_flag.real_harm,v.real_harm)
             one_attr_data:setData(AttrHelper.attr_flag.anti_stun,v.anti_stun)
             one_attr_data:setData(AttrHelper.attr_flag.anti_silent,v.anti_silent)
             one_attr_data:setData(AttrHelper.attr_flag.anti_chaos,v.anti_chaos)
             one_attr_data:setData(AttrHelper.attr_flag.anti_stone,v.anti_stone)
             one_attr_data:setData(AttrHelper.attr_flag.anti_polymorph,v.anti_polymorph)
             one_attr_data:setData(AttrHelper.attr_flag.anti_taunt,v.anti_taunt)
             one_attr_data:setData(AttrHelper.attr_flag.anti_sleep,v.anti_sleep)

             one_attr_data:setData(AttrHelper.attr_flag.tought,v.tought)
             one_attr_data:setData(AttrHelper.attr_flag.break_atk,v.break_atk)
             one_attr_data:setData(AttrHelper.attr_flag.suck_blood,v.suck_blood)
             one_attr_data:setData(AttrHelper.attr_flag.stare,v.stare)

             --配置表用千分比, 代码计算用万分比
             one_attr_data:setData(AttrHelper.attr_flag.anti_breakarmour, v.anti_breakarmour*10)
             one_attr_data:setData(AttrHelper.attr_flag.anti_poisoning, v.anti_poisoning*10)
             one_attr_data:setData(AttrHelper.attr_flag.anti_burn, v.anti_burn*10)
             one_attr_data:setData(AttrHelper.attr_flag.anti_bleed, v.anti_bleed*10)
             one_attr_data:setData(AttrHelper.attr_flag.anti_sacred_burn, v.anti_sacred_burn*10)
             self.base_attr_Dic[v.base_id] = one_attr_data
        end
    end 

    --卡牌属性成长
    local attr_grow_rows = msg.attr_grow_rows
    local one_attr_grow = nil

    for i, v in pairs(attr_grow_rows) do
        if v.base_id~=nil then 
            one_attr_grow = HeroGrowAttr:create()
            one_attr_grow:setData(AttrHelper.attr_flag.hp,v.hp_max)
            one_attr_grow:setData(AttrHelper.attr_flag.atk,v.atk)
            one_attr_grow:setData(AttrHelper.attr_flag.pdef,v.pdef)
            one_attr_grow:setData(AttrHelper.attr_flag.crit,v.crit)
            one_attr_grow:setData(AttrHelper.attr_flag.block,v.block)
            one_attr_grow:setData(AttrHelper.attr_flag.def_break,v.def_break)
            one_attr_grow:setData(AttrHelper.attr_flag.evasion,v.evasion)
            one_attr_grow:setData(AttrHelper.attr_flag.atk_speed,v.atk_speed)
            one_attr_grow:setData(AttrHelper.attr_flag.fight_back,v.fight_back)
            one_attr_grow:setData(AttrHelper.attr_flag.reduce_harm,v.reduce_harm)
            one_attr_grow:setData(AttrHelper.attr_flag.real_harm,v.real_harm)
            one_attr_grow:setData(AttrHelper.attr_flag.anti_stun,v.anti_stun)
            one_attr_grow:setData(AttrHelper.attr_flag.anti_silent,v.anti_silent)
            one_attr_grow:setData(AttrHelper.attr_flag.anti_chaos,v.anti_chaos)
            one_attr_grow:setData(AttrHelper.attr_flag.anti_stone,v.anti_stone)
            one_attr_grow:setData(AttrHelper.attr_flag.anti_polymorph,v.anti_polymorph)
            one_attr_grow:setData(AttrHelper.attr_flag.anti_taunt,v.anti_taunt)
            one_attr_grow:setData(AttrHelper.attr_flag.anti_sleep,v.anti_sleep)
            one_attr_grow:setData(AttrHelper.attr_flag.tought,v.tought)
            one_attr_grow:setData(AttrHelper.attr_flag.break_atk,v.break_atk)
            one_attr_grow:setData(AttrHelper.attr_flag.suck_blood,v.suck_blood)
            one_attr_grow:setData(AttrHelper.attr_flag.stare,v.stare)
            one_attr_grow:setData(AttrHelper.attr_flag.anti_breakarmour,v.anti_breakarmour)
            one_attr_grow:setData(AttrHelper.attr_flag.anti_poisoning,v.anti_poisoning)
            one_attr_grow:setData(AttrHelper.attr_flag.anti_burn,v.anti_burn)
            one_attr_grow:setData(AttrHelper.attr_flag.anti_bleed,v.anti_bleed)
            one_attr_grow:setData(AttrHelper.attr_flag.anti_sacred_burn,v.anti_sacred_burn)

             self.grow_attr_Dic[v.base_id] = one_attr_grow
        end
    end

    --英雄升级
    local lev_up_rows = msg.lev_up_rows
    for i, v in pairs(lev_up_rows) do
        if v.lev~=nil then 
             self.lev_up_dic[v.lev] = v.exp
        end
    end
 
    --英雄进阶消耗
    local upgrade_cost = msg.upgrade_cost_rows
    local one_upgrade_cost = nil
    for i, v in pairs(upgrade_cost) do
        if v.star~=nil then 
             one_upgrade_cost = {}
             one_upgrade_cost.soul_gem = v.soul_gem
             one_upgrade_cost.cost_coin = v.cost_coin
             one_upgrade_cost.grow_ration_one = v.grow_ration_one/10000
             one_upgrade_cost.grow_ration_two = v.grow_ration_two/10000
             self.upgrade_cost_dic[v.star] = one_upgrade_cost
        end
    end

    --英雄界面动作界面
    local hero_act_list_rows = msg.hero_act_list_rows
    local one_act_data = nil
    for i, v in pairs(hero_act_list_rows) do
        if v.hero_id~=nil then 
             one_act_data = {}
             one_act_data = Helper.stringToTable("{"..v.act_list.."}")
             self.hero_act_list[v.hero_id] = one_act_data
        end
    end

    --技能动作相关特效
    local hero_skill_act_list_rows = msg.hero_skill_act_list_rows
    local one_skill_eff_data = nil
    for i, v in pairs(hero_skill_act_list_rows) do
        if v.skill_id~=nil then 
             self.hero_skill_eff_data[v.skill_id] = v.effect_id
             cclog("技能特效%d",v.effect_id)
        end
    end

    --英雄时装初始属性
    local fashionData
    for k, v in pairs(msg.fashion_base_rows) do
        if v.base_id then
            fashionData = HeroFashionData:create()
            fashionData.heroId = v.base_id
            fashionData.sex = v.sex
            fashionData.fashionId = v.fashion_id
            fashionData.actionId = v.action_id
            fashionData.baseId = v.item_base
            fashionData.pos = v.pos
            --设置属性
            fashionData:setOneAttr(AttrHelper.attr_flag.hp,v.hp_max)
            fashionData:setOneAttr(AttrHelper.attr_flag.atk,v.atk)
            fashionData:setOneAttr(AttrHelper.attr_flag.pdef,v.pdef)
            fashionData:setOneAttr(AttrHelper.attr_flag.crit,v.crit)
            fashionData:setOneAttr(AttrHelper.attr_flag.block,v.block)
            fashionData:setOneAttr(AttrHelper.attr_flag.def_break,v.def_break)
            fashionData:setOneAttr(AttrHelper.attr_flag.evasion,v.evasion)
            fashionData:setOneAttr(AttrHelper.attr_flag.atk_speed,v.atk_speed)
            fashionData:setOneAttr(AttrHelper.attr_flag.tought,v.tought)
            fashionData:setOneAttr(AttrHelper.attr_flag.break_atk,v.break_atk)
            fashionData:setOneAttr(AttrHelper.attr_flag.fight_back,v.fight_back)
            fashionData:setOneAttr(AttrHelper.attr_flag.reduce_harm,v.reduce_harm)
            fashionData:setOneAttr(AttrHelper.attr_flag.real_harm,v.real_harm)
            fashionData:setOneAttr(AttrHelper.attr_flag.anti_stun,v.anti_stun)
            fashionData:setOneAttr(AttrHelper.attr_flag.anti_silent,v.anti_silent)
            fashionData:setOneAttr(AttrHelper.attr_flag.anti_chaos,v.anti_chaos)
            fashionData:setOneAttr(AttrHelper.attr_flag.anti_stone,v.anti_stone)
            fashionData:setOneAttr(AttrHelper.attr_flag.anti_polymorph,v.anti_polymorph)
            fashionData:setOneAttr(AttrHelper.attr_flag.anti_taunt,v.anti_taunt)
            fashionData:setOneAttr(AttrHelper.attr_flag.anti_sleep,v.anti_sleep)
            fashionData:setOneAttr(AttrHelper.attr_flag.suck_blood,v.suck_blood)
            fashionData:setOneAttr(AttrHelper.attr_flag.stare,v.stare)
            fashionData:setOneAttr(AttrHelper.attr_flag.anti_breakarmour,v.anti_breakarmour)
            fashionData:setOneAttr(AttrHelper.attr_flag.anti_poisoning,v.anti_poisoning)
            fashionData:setOneAttr(AttrHelper.attr_flag.anti_burn,v.anti_burn)
            fashionData:setOneAttr(AttrHelper.attr_flag.anti_bleed,v.anti_bleed)
            fashionData:setOneAttr(AttrHelper.attr_flag.anti_sacred_burn,v.anti_sacred_burn)


            local heroDict = self._fashionDataDict[fashionData.heroId] or {}
            self._fashionDataDict[fashionData.heroId] = heroDict
            self._fashionDataDict2[string.format("%d_%d",fashionData.baseId,fashionData.sex)] = fashionData
            self._fashionDataDict3[string.format("%d_%d",v.fashion_id,fashionData.sex)] = fashionData

            local fashionDict = heroDict[fashionData.fashionId] or {}
            heroDict[fashionData.fashionId] = fashionDict

            fashionDict[tostring(v.sex)] = fashionData
        end
    end


    --英雄时装进阶属性
    for k, v in pairs(msg.fashion_grow_rows) do
      if v.fashion_id then

        local fashion_grow_data_one = FashionGrowData:create()
        fashion_grow_data_one.fashionId = v.fashion_id
        fashion_grow_data_one.star = v.star
        fashion_grow_data_one.cost_item = v.cost_item
        fashion_grow_data_one.cost_coin = v.cost_coin
        fashion_grow_data_one.grow_ration_one = v.grow_ration_one/10000
        fashion_grow_data_one.grow_ration_two = v.grow_ration_two/10000

        if self._fashionGrowDict[v.fashion_id]==nil then
          self._fashionGrowDict[v.fashion_id] = {}
        end

        self._fashionGrowDict[v.fashion_id][v.star] = fashion_grow_data_one

      end
    end

    --英雄属性描述
    for k,v in pairs(msg.attr_desc_rows) do
        if v.attr_id then
            self._attrDescDict[v.attr_id] = v.attr_content
        end
    end
end

--向服务端请求卡牌信息
function HeroManager:sendHeroInfoReq(req_type)
  Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_all_info_req+1, "onGetHeroInfoRsp()") 
  local hero_all_info_req = hero_pb.hero_all_info_req() 
  hero_all_info_req.type = req_type 
  -- Global:sendPkg(proto_cmd_pb.msg_cmd.hero_all_info_req, hero_all_info_req:SerializeToString() , hero_all_info_req:ByteSize())
  ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_all_info_req, hero_all_info_req)
  cclog("請求英雄列表")

end

function onGetHeroInfoRsp(pbPkgData)
  Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_all_info_req+1, "onGetHeroInfoRsp()")

  local  hero_all_info_rsp = hero_pb.hero_all_info_rsp()
  hero_all_info_rsp:ParseFromString(pbPkgData)

  -- local count = #hero_all_info_rsp.heros
  -- local tempHeroItem = nil
  -- local tempHeroInfo = nil
  -- local rsp_type = hero_all_info_rsp.type 

  HeroManager:getInstance():initHeroList(hero_all_info_rsp.heros, hero_all_info_rsp.type) 

  ComSender:getInstance():dealExtInfo(hero_all_info_rsp.ext)

  cclog ("收到卡牌資料清單")
end

--请求上阵英雄的装备信息
function HeroManager:sendHeroAllEqmReq()
  if self.is_int_all_eqm then
    return
  end
  Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_all_eqm_req+1, "onGetHeroAllEqmRsp()") 

  local hero_all_eqm_req = hero_pb.hero_all_eqm_req() 
  ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_all_eqm_req, hero_all_eqm_req)

end

function onGetHeroAllEqmRsp(pbPkgData)
  
  Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_all_eqm_req+1, "onGetHeroAllEqmRsp()")
  local  hero_all_eqm_rsp = hero_pb.hero_all_eqm_rsp()
  hero_all_eqm_rsp:ParseFromString(pbPkgData)

  if hero_all_eqm_rsp.ret ~= error_code_pb.msg_ret.success then
    cclog("獲取上陣英雄裝備資料失敗~~%d",hero_all_eqm_rsp.ret)
    return
  end

  _instance:setHeroAllEqms(hero_all_eqm_rsp.eqms)

  ComSender:getInstance():dealExtInfo(hero_all_eqm_rsp.ext)

end

function HeroManager:setHeroAllEqms(srv_eqms)
  _instance.is_int_all_eqm = true
  local stand_eqm_one = nil
  local eqm_list_vo = nil
  local count = #srv_eqms 
  local eqmsCount = 0
  local team_hero_vo = nil

  for i=1,count do
      stand_eqm_one = srv_eqms[i]
      eqm_list_vo = _instance.battle_hero_eqm_list[stand_eqm_one.pos]
      team_hero_vo = TeamManager:getInstance():getTeamHeroVoByPos(stand_eqm_one.pos)          
      if eqm_list_vo == nil then
        eqm_list_vo =  EquipListVo.new()
        eqm_list_vo:setTeamPos(stand_eqm_one.pos)
        _instance.battle_hero_eqm_list[stand_eqm_one.pos] = eqm_list_vo
      end

      eqmsCount = #stand_eqm_one.eqms
      for j = 1, eqmsCount do 
        tempEquipVo = EquipVo:new()
        tempOneEqm = stand_eqm_one.eqms[j]
        -- tempEquipVo.location = tempOneEqm.eqm_pos

        tempItem = ItemManager:getInstance():addEqmItem(0,tempOneEqm.item)
         -- cclog("裝備名稱~~%s~~~iD:%d~~~~",tempItem.mode.name, tempItem.id)
        -- if team_hero_vo then
        --   tempItem:setHeroId(team_hero_vo.heroId)
        -- end
        -- tempEquipVo.item = tempItem
        tempEquipVo:setInfo(tempOneEqm.eqm_pos,tempItem) 
        eqm_list_vo:setSingleEquip(tempEquipVo)
      end  
  end

  _instance:resetEqmHeroId()
  Notifier.dispatchCmd(CmdName.InitBattleHeroEqm) 
end

--设置装备关联的英雄
function HeroManager:resetEqmHeroId()
  if self.is_int_all_eqm ~= true then
    cclog("未獲取上陣英雄裝備資料")
    return
  end

  local hero_id = nil
  local team_hero_vo = nil
  local eqm_list = nil
  for pos=1,6 do 
    team_hero_vo = TeamManager:getInstance():getTeamHeroVoByPos(pos)
    
    --战队信息未返回
    if team_hero_vo ~= nil then
      hero_id = team_hero_vo.heroId 
      eqm_list = self.battle_hero_eqm_list[pos]:getEquipList()
      for location, eqm_vo in pairs(eqm_list) do
        if eqm_vo and eqm_vo.item then
           eqm_vo.item:setHeroId(hero_id)
          -- cclog("裝備ID~~~%d，裝備對應的英雄~~~%d",eqm_vo.item.mode.base_id,hero_id)
        end
      end
    else -- 如果该位置没有上阵英雄 
      eqm_list = self.battle_hero_eqm_list[pos]:getEquipList()
      for location, eqm_vo in pairs(eqm_list) do
        if eqm_vo and eqm_vo.item then
           eqm_vo.item:setHeroId(0)
          -- cclog("裝備ID~~~%d，裝備對應的英雄~~~%d",eqm_vo.item.mode.base_id,hero_id)
        end
      end
    end  
  end
  
end



--通过卡牌base_id获取卡牌信息
function HeroManager:getHeroInfoByBaseId(base_id)
  return self.HeroInfoDic[base_id]
end

--通过卡牌ID获取卡牌信息
function HeroManager:getHeroInfoById(hero_id)
	return self.HeroInfoDic[hero_id]
end

--设置卡牌信息
function HeroManager:setHeroInfo(newHeroInfo)
    self.hero_list[newHeroInfo.id] = newHeroInfo
end

--初始化卡牌列表
function HeroManager:initHeroList(srv_heros, srv_type)
    --self.hero_list[newHeroInfo.id] = newHeroInfo
   self.isHeroListInit = true 
   -- local  hero_all_info_rsp = hero_pb.hero_all_info_rsp()
   -- hero_all_info_rsp:ParseFromString(pbPkgData)

   local count = #srv_heros
   local tempHeroItem = nil
   local tempHeroInfo = nil
   local rsp_type = srv_type

   for i = 1 ,count do
         tempHeroItem = srv_heros[i]
         tempHeroInfo = self.HeroInfoDic[tempHeroItem.base_id]
         tempHeroInfo:setExtData(
             tempHeroItem.id, 
             tempHeroItem.lev,  
             tempHeroItem.stars, 
             tempHeroItem.exp,
             tempHeroItem.pos_models
         )

         _instance:setHeroAttrChange(tempHeroItem.base_id,true) 
         
         --如果当前返回的是英雄的所有数据，则处理，如果只是base则不需要
         if rsp_type == HeroHelper.hero_info_req_type.all then 
           -- --装备列表处理
           -- local eqms = tempHeroItem.eqms
           -- local eqmsCount = #eqms
           -- local tempOneEqm = nil
           -- local tempEquipVo = nil
           -- local tempItem = nil
           -- local item_eqm_info
           -- local team_pos = TeamManager:getInstance():isHeroInBattle(tempHeroItem.base_id)
           -- if team_pos>0 then
           --      local eqm_list_vo = self.battle_hero_eqm_list[team_pos]
                
           --      if eqm_list_vo == nil then
           --        eqm_list_vo =  EquipListVo.new()
           --        eqm_list_vo:setTeamPos(team_pos)
           --        self.battle_hero_eqm_list[team_pos] = eqm_list_vo
           --      end

           --      for j = 1, eqmsCount do 
           --        tempEquipVo = EquipVo:new()
           --        tempOneEqm = eqms[j]
           --        tempEquipVo.location = tempOneEqm.eqm_pos
           --        tempItem = ItemManager:getInstance():addEqmItem(tempHeroItem.base_id,tempOneEqm.item)
           --        -- tempItem:setHeroId()
           --        tempEquipVo.item = tempItem
           --        eqm_list_vo:setSingleEquip(tempEquipVo)
           --      end  
           -- end
    
           --技能列表处理
           local skills = tempHeroItem.skills
           local skill_info = nil
           for k = 1, #skills do
              skill_info = skills[k]
              tempHeroInfo:setSkillInfo(skill_info.id,skill_info.lev)
           end

           -- tempHeroInfo:setFashionFromServer(tempHeroItem.models)

          end
   end
   --通知角色界面更新
    Notifier.dispatchCmd(CmdName.HeroInfoInit)
end

--收到战队信息更新
local function onInitTeamInfo(params)
  if params.team_type ~= TeamType.Normal then
    return
  end

  _instance:resetEqmHeroId()

end

local function onTeamUpgradeSuc(team_type)

  if team_type ~= TeamType.Normal then
    return
  end

   _instance:resetEqmHeroId()
end

--初始化相关状态
local function onInitBattleEqmStatus()
  is_eqm_status_init = true
  Notifier.remove(CmdName.GameStar, onInitBattleEqmStatus)
  _instance.battle_eqm_status = {}    

  local all_bag_items = ItemManager:getInstance():getAllBagItems()
  local temp_battle_eqms = _instance.battle_hero_eqm_list
  local eqm_vo = nil
  local pos_one
  local pos_two
  local eqm_vo_list_one
  local eqm_vo_list_two
  local team_mgr =  TeamManager:getInstance()
  local item_mgr =  ItemManager:getInstance()
  local temp_eqm_vo = nil

  local eqm_comp_status 

  local eqm_status_one = nil

  for team_pos=1,6 do
    eqm_status_one = {}
    _instance.battle_eqm_status[team_pos] = eqm_status_one
  end


  --从背包中取出各个物品，找到物品对应能装备的位置，然后跟已存在装备比较
  --一个装备能对应两个战队位置，例如前1+前2
  for id,item in pairs(all_bag_items) do
    if item_mgr:isEqm(item.mode.item_type) then --只有装备才需要做相应判断
      pos_one,pos_two = team_mgr:limStand2TeamPos(item.mode.limit_stand)
      eqm_vo_list_one = temp_battle_eqms[pos_one]
      eqm_vo_list_two = temp_battle_eqms[pos_two]

      --前1/中1/后1
      if eqm_vo_list_one then
        temp_eqm_vo = eqm_vo_list_one:getSingleEquip(item.mode.item_type)
        if temp_eqm_vo then
           eqm_comp_status = item_mgr:eqmComp(item.mode.limit_stand, item.mode.item_type, item, temp_eqm_vo.item)
            --如果状态是从无到有或者有更高级装备的话，则更新对应位置的值
            if _instance.battle_eqm_status[pos_one][item.mode.item_type] == nil or 
              _instance.battle_eqm_status[pos_one][item.mode.item_type]<eqm_comp_status then
                 _instance.battle_eqm_status[pos_one][item.mode.item_type] = eqm_comp_status
            end
        else
          eqm_comp_status = item_mgr:eqmComp(item.mode.limit_stand, item.mode.item_type, item, nil)
            --如果状态是从无到有或者有更高级装备的话，则更新对应位置的值
            if _instance.battle_eqm_status[pos_one][item.mode.item_type] == nil or 
              _instance.battle_eqm_status[pos_one][item.mode.item_type]<eqm_comp_status then
                 _instance.battle_eqm_status[pos_one][item.mode.item_type] = eqm_comp_status
            end
        end
      end

      --前2/中2/后2
      if eqm_vo_list_two then
        temp_eqm_vo = eqm_vo_list_two:getSingleEquip(item.mode.item_type)
        if temp_eqm_vo then
           eqm_comp_status = item_mgr:eqmComp(item.mode.limit_stand, item.mode.item_type, item, temp_eqm_vo.item)
            --如果状态是从无到有或者有更高级装备的话，则更新对应位置的值
            if _instance.battle_eqm_status[pos_two][item.mode.item_type] == nil or 
              _instance.battle_eqm_status[pos_two][item.mode.item_type]<eqm_comp_status then
                 _instance.battle_eqm_status[pos_two][item.mode.item_type] = eqm_comp_status
            end
        else
           eqm_comp_status = item_mgr:eqmComp(item.mode.limit_stand, item.mode.item_type, item, nil)
            --如果状态是从无到有或者有更高级装备的话，则更新对应位置的值
            if _instance.battle_eqm_status[pos_two][item.mode.item_type] == nil or 
              _instance.battle_eqm_status[pos_two][item.mode.item_type]<eqm_comp_status then
                 _instance.battle_eqm_status[pos_two][item.mode.item_type] = eqm_comp_status
            end
        end
      end
    end

  end

end

function HeroManager:initInitBattleEqmStatus()
  onInitBattleEqmStatus()
end

--背包添加新物品，需要重新检测绿点状态
local function onBagAddNewEqmItem(new_eqm_item)
  
  if is_eqm_status_init==false then
    return
  end

  local pos_one,pos_two = TeamManager:getInstance():limStand2TeamPos(new_eqm_item.mode.limit_stand)
  --跟当前位置的状态做比较，如果该状态比原本状态更好，则替换
  local eqm_vo_list_one = _instance.battle_hero_eqm_list[pos_one]
  local eqm_vo_list_two = _instance.battle_hero_eqm_list[pos_two]

  --前1/中1/后1
  local temp_eqm_vo = nil
  local eqm_comp_status
  if eqm_vo_list_one then
    temp_eqm_vo = eqm_vo_list_one:getSingleEquip(new_eqm_item.mode.item_type)
    if temp_eqm_vo then
       eqm_comp_status = ItemManager:getInstance():eqmComp(new_eqm_item.mode.limit_stand, 
                            new_eqm_item.mode.item_type, new_eqm_item, temp_eqm_vo.item)
        --如果状态是从无到有或者有更高级装备的话，则更新对应位置的值
        if _instance.battle_eqm_status[pos_one][new_eqm_item.mode.item_type] == nil or 
          _instance.battle_eqm_status[pos_one][new_eqm_item.mode.item_type]<eqm_comp_status then
             _instance.battle_eqm_status[pos_one][new_eqm_item.mode.item_type] = eqm_comp_status
        end
    else
       eqm_comp_status = ItemManager:getInstance():eqmComp(new_eqm_item.mode.limit_stand, 
                            new_eqm_item.mode.item_type, new_eqm_item, nil)
        --如果状态是从无到有或者有更高级装备的话，则更新对应位置的值
        if _instance.battle_eqm_status[pos_one][new_eqm_item.mode.item_type] == nil or 
          _instance.battle_eqm_status[pos_one][new_eqm_item.mode.item_type]<eqm_comp_status then
             _instance.battle_eqm_status[pos_one][new_eqm_item.mode.item_type] = eqm_comp_status
        end
    end
  end

  --前2/中2/后2
  if eqm_vo_list_two then
    temp_eqm_vo = eqm_vo_list_two:getSingleEquip(new_eqm_item.mode.item_type)
    if temp_eqm_vo then
       eqm_comp_status = ItemManager:getInstance():eqmComp(new_eqm_item.mode.limit_stand, 
                      new_eqm_item.mode.item_type,new_eqm_item, temp_eqm_vo.item)
        --如果状态是从无到有或者有更高级装备的话，则更新对应位置的值
        if _instance.battle_eqm_status[pos_two][new_eqm_item.mode.item_type] == nil or 
          _instance.battle_eqm_status[pos_two][new_eqm_item.mode.item_type]<eqm_comp_status then
             _instance.battle_eqm_status[pos_two][new_eqm_item.mode.item_type] = eqm_comp_status
        end
    else
      eqm_comp_status = ItemManager:getInstance():eqmComp(new_eqm_item.mode.limit_stand, 
                      new_eqm_item.mode.item_type,new_eqm_item, nil)
        --如果状态是从无到有或者有更高级装备的话，则更新对应位置的值
        if _instance.battle_eqm_status[pos_two][new_eqm_item.mode.item_type] == nil or 
          _instance.battle_eqm_status[pos_two][new_eqm_item.mode.item_type]<eqm_comp_status then
             _instance.battle_eqm_status[pos_two][new_eqm_item.mode.item_type] = eqm_comp_status
        end
    end
  end

  local params = {}
  local id_pos_list = TeamManager:getInstance():getHeroIdByLimitStand(new_eqm_item.mode.limit_stand)
  if id_pos_list[1] then
    table.insert(params, id_pos_list[1].hero_id)
  end

  if id_pos_list[2] then
    table.insert(params, id_pos_list[2].hero_id)
  end

  Notifier.dispatchCmd(CmdName.UpdateGreenTipsPoint, params)
end

--相应需要监听的事件
function HeroManager:addEvent()
  Notifier.regist(CmdName.ChangeItemStorage,function(param) self:sendHeroEqmOnReq(param) end)
  Notifier.regist(CmdName.TEAM_INIT_HERO, onInitTeamInfo)
  -- Notifier.regist(CmdName.TEAM_ADD_HERO_BATTLE, onTeamChange)
  -- Notifier.regist(CmdName.TEAM_ADD_HERO_BATTLE, onTeamChange)
  Notifier.regist(CmdName.TEAM_UPGRADE_HERO_SUCCESS,onTeamUpgradeSuc)
  Notifier.regist(CmdName.GameStar, onInitBattleEqmStatus)
  Notifier.regist(CmdName.BagAddNewEqmItem, onBagAddNewEqmItem)

  Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_add_rsp, "onHeroAddRsp()")
  Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_info_rsp, "onUpdateHeroInfoRsp()")
 
  Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_skill_upgrade_rsp, "onSkillUpgradeRsp()")
  -- Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_stars_upgrade_rsp, "onGetHeroUpgradeRsp()") 
end

--服务端更新单个卡牌信息
function onUpdateHeroInfoRsp(pbPkgData)
    local hero_info_rsp = hero_pb.hero_info_rsp() 
    hero_info_rsp:ParseFromString(pbPkgData)

  if hero_info_rsp.ret ~= error_code_pb.msg_ret.success then
    cclog("update hero_info fail,i don't know why")
    return 
  end  

  _instance:updateHeroInfoByClient(
      hero_info_rsp.hero.id, 
      hero_info_rsp.hero.lev, 
      hero_info_rsp.hero.exp, 
      hero_info_rsp.hero.stars,
      hero_info_rsp.pos_models,
      hero_info_rsp.models
  )

  ComSender:getInstance():dealExtInfo(hero_info_rsp.ext)
end

--发送装备请求
function HeroManager:sendHeroEqmOnReq(param)
  
  if param.item.hero_id > 0 then  --两个英雄交换装备
    local eqm_switch_req = hero_pb.hero_eqm_switch_req() 
    --当前英雄
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_switch_rsp, "onEqmSwitchRsp()")
    local eqms =  HeroManager:getInstance():getBattleHeroEqmList(param.hero_id)
    local old_item = eqms:getSingleEquip(param.location).item
    eqm_switch_req.hero_id_1 = param.hero_id
    eqm_switch_req.eqm_pos_1 = param.location
    eqm_switch_req.item_id_1 = old_item.id 
    --要交换装备的英雄
    eqm_switch_req.hero_id_2 = param.item.hero_id
    eqm_switch_req.eqm_pos_2 = param.location
    eqm_switch_req.item_id_2 = param.item.id
    ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_eqm_switch_req,eqm_switch_req)
    -- Global:sendPkg(proto_cmd_pb.msg_cmd.hero_eqm_switch_req, eqm_switch_req:SerializeToString() , eqm_switch_req:ByteSize())
  else --从背包取出来
    
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_on_req+1, "onGetHeroEqmOnRsp()")  
    local hero_eqm_on_req = hero_pb.hero_eqm_on_req() 
    hero_eqm_on_req.hero_id = param.hero_id
    hero_eqm_on_req.eqm_pos = param.location
    hero_eqm_on_req.item_id = param.item.id
    ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_eqm_on_req,hero_eqm_on_req)
    -- Global:sendPkg(proto_cmd_pb.msg_cmd.hero_eqm_on_req, hero_eqm_on_req:SerializeToString() , hero_eqm_on_req:ByteSize())
  end
end

--服务端返回交换装备的结果
function onEqmSwitchRsp(pbPkgData)

   Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_switch_rsp, "onEqmSwitchRsp()")

  local eqm_switch_rsp = hero_pb.hero_eqm_switch_rsp() 
  eqm_switch_rsp:ParseFromString(pbPkgData)

  if eqm_switch_rsp.ret ~= error_code_pb.msg_ret.success then
    Alert:show(Helper.getErrStr(eqm_switch_rsp.ret))
    cclog("eqm switch fail,i don't know why-----%d",eqm_switch_rsp.ret)
    return 
  end     

  --local HeroInfo_one = HeroManager:getInstance():getHeroInfoById(eqm_switch_rsp.hero_id_1)
  --local HeroInfo_two = HeroManager:getInstance():getHeroInfoById(eqm_switch_rsp.hero_id_2)

  local eqm_list_one = _instance:getBattleHeroEqmList(eqm_switch_rsp.hero_id_1)
  local eqm_list_two = _instance:getBattleHeroEqmList(eqm_switch_rsp.hero_id_2)

  local item_one = item_mgr:getEquipInfoById(eqm_switch_rsp.item_id_1)
  local item_two = item_mgr:getEquipInfoById(eqm_switch_rsp.item_id_2)

  --交换两个物品的强化等级、附魔等级、镶嵌宝石、所属英雄,其余保持原状
  local powered_lv = item_one.powered_lev --交换强化
  item_one:setPoweredLev(item_two.powered_lev)
  item_two:setPoweredLev(powered_lv)

  local enchant_lev = item_one.enchant_lev --交换附魔
  local enchant_energy = item_one.enchant_energy
  item_one:setEnchantLev(item_two.enchant_lev)
  item_one:setEnchantEnergy(item_two.enchant_energy)
  item_two:setEnchantLev(enchant_lev)
  item_two:setEnchantEnergy(enchant_energy)

  local gems = item_one.gems --交换宝石
  item_one:setGems(item_two.gems)
  item_two:setGems(gems)

  item_one:setHeroId(eqm_switch_rsp.hero_id_1)--交换所属英雄
  item_two:setHeroId(eqm_switch_rsp.hero_id_2)

  local equipVo_one = eqm_list_one:getSingleEquip(eqm_switch_rsp.eqm_pos_1)
  local equipVo_two = eqm_list_two:getSingleEquip(eqm_switch_rsp.eqm_pos_2)

  equipVo_one:setInfo(eqm_switch_rsp.eqm_pos_1,item_one)
  equipVo_two:setInfo(eqm_switch_rsp.eqm_pos_2,item_two)

  _instance:setHeroAttrChange(eqm_switch_rsp.hero_id_1,true)
  _instance:setHeroAttrChange(eqm_switch_rsp.hero_id_2,true)
  --重新计算物品属性
  ItemManager:getInstance():setEqmAttrIsChange(eqm_switch_rsp.item_id_1,true)
  ItemManager:getInstance():setEqmAttrIsChange(eqm_switch_rsp.item_id_2,true)
  --通知相应界面更新
   local param = {}
   param.hero_id = eqm_switch_rsp.hero_id_1
   param.location = eqm_switch_rsp.eqm_pos_1

   Notifier.dispatchCmd(CmdName.EqmInfoUpdate,param) 

   _instance:excBattleEqmStatus(item_one.mode.limit_stand, item_one.mode.item_type,
                                 eqm_switch_rsp.hero_id_1, eqm_switch_rsp.hero_id_2)
   --关闭装备穿戴界面
   WindowCtrl:getInstance():close(CmdName.EqmOnConfirmView)

   ComSender:getInstance():dealExtInfo(eqm_switch_rsp.ext)
end

--服务端返回穿上装备的结果
function onGetHeroEqmOnRsp(pbPkgData)
  Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_on_req+1, "onGetHeroEqmOnRsp()")
  local hero_eqm_on_rsp = hero_pb.hero_eqm_on_rsp() 
  hero_eqm_on_rsp:ParseFromString(pbPkgData)

  if hero_eqm_on_rsp.ret ~= error_code_pb.msg_ret.success then
     Alert:show(Helper.getErrStr(hero_eqm_on_rsp.ret))
    cclog("hero dress eqm fail,i don't know why.error_code_id:%d",hero_eqm_on_rsp.ret)
    return 
  end     

  ComSender:getInstance():dealExtInfo(hero_eqm_on_rsp.ext)


    if hero_eqm_on_rsp.eqm_pos >= 100 then --时装 

        local heroInfo = HeroManager:getInstance():getHeroInfoById(hero_eqm_on_rsp.hero_id)
        heroInfo:setFashionId(hero_eqm_on_rsp.eqm_pos,hero_eqm_on_rsp.off_item_id) --先脱后穿
        heroInfo:setFashionId(hero_eqm_on_rsp.eqm_pos,hero_eqm_on_rsp.on_item_id)

        if hero_eqm_on_rsp.on_item_id > 0 then --穿
            local fashionData = HeroManager:getInstance():getCfgFashionDataById(hero_eqm_on_rsp.on_item_id)
            local tempItem = HeroManager:getInstance():getFashionItemTab(hero_eqm_on_rsp.eqm_pos,hero_eqm_on_rsp.hero_id)
            tempItem:setItemInfo(fashionData.fashionId,fashionData.baseId,1)

            ItemManager:getInstance().equipItemTab[fashionData.fashionId] = tempItem
            ItemManager:getInstance():setEqmAttrIsChange(tempItem.id,true)
        else --脱
            --不处理  因为是客户端显示
        end

        local param = {on = hero_eqm_on_rsp.on_item_id ,off = hero_eqm_on_rsp.off_item_id}
        Notifier.dispatchCmd(CmdName.Upadate_Fashion_Skin,param)
    else  --普通装备

      local eqms = _instance:getBattleHeroEqmList(hero_eqm_on_rsp.hero_id)
      if eqms == nil then
        cclog ("eqms is nil，該英雄未上陣%d",hero_eqm_on_rsp.hero_id)
        return
      end 

      local onItem = ItemManager:getInstance():getItemById(hero_eqm_on_rsp.on_item_id) -- 从背包中取出数据
      ItemManager:getInstance():setEquipItem(onItem) --装备列表中增加装备
      onItem:setHeroId(hero_eqm_on_rsp.hero_id) --设置装备所属英雄
      ItemManager:getInstance():delSingleItem(onItem.id) -- 从背包中删除

      local offItem = ItemManager:getInstance():getEquipInfoById(hero_eqm_on_rsp.off_item_id)
      if offItem then
        --交换强化、附魔、镶嵌、所属英雄
        onItem:setEnchantEnergy(offItem.enchant_energy)
        onItem:setPoweredLev(offItem.powered_lev)
        onItem:setEnchantLev(offItem.enchant_lev)
        onItem:setEnchantEnergy(offItem.enchant_energy)
        onItem:setGems(offItem.gems)
        --清空旧的
        offItem:setHeroId(0)
        offItem:setPoweredLev(0)
        offItem:setEnchantLev(0)
        offItem:setEnchantEnergy(0)
        offItem:setGems(nil)

        ItemManager:getInstance():setBagItem(offItem) --背包中增加
        ItemManager:getInstance():delEquipItem(offItem)  --装备列表中删除
      end

      local equipVo = eqms:getSingleEquip(hero_eqm_on_rsp.eqm_pos)
      if equipVo == nil then
        equipVo = EquipVo.new()
        -- eqms:setSingleEquip(equipVo)
      end
      equipVo:setInfo(hero_eqm_on_rsp.eqm_pos,onItem)
      eqms:setSingleEquip(equipVo) 

      _instance:setHeroAttrChange(hero_eqm_on_rsp.hero_id,true)

      --通知相应界面更新
       local param = {}
       param.hero_id = hero_eqm_on_rsp.hero_id
       param.location = hero_eqm_on_rsp.eqm_pos

       Notifier.dispatchCmd(CmdName.EqmInfoUpdate,param) 

       _instance:UpdateSingleBattleEqmStatus(onItem)

       --关闭装备穿戴界面
       WindowCtrl:getInstance():close(CmdName.EqmOnConfirmView)

   end
end

function HeroManager:excBattleEqmStatus(limit_stand, item_type, hero_id_one, hero_id_two)
  local pos_one,pos_two = TeamManager:getInstance():limStand2TeamPos(limit_stand)
  local temp_status = self.battle_eqm_status[pos_one][item_type]
  self.battle_eqm_status[pos_one][item_type] = self.battle_eqm_status[pos_two][item_type]
  self.battle_eqm_status[pos_two][item_type] = temp_status

  local params = {}
  table.insert(params, hero_id_one)
  table.insert(params, hero_id_two)

  Notifier.dispatchCmd(CmdName.UpdateGreenTipsPoint, params)
end

--更新单个上阵装备的状态
function HeroManager:UpdateSingleBattleEqmStatus(cur_eqm_item)
  local all_bag_items = ItemManager:getInstance():getAllBagItems()
  local temp_battle_eqms = self.battle_hero_eqm_list
  local eqm_vo = nil
  local pos_one
  local pos_two
  local eqm_vo_list_one
  local eqm_vo_list_two
  local team_mgr =  TeamManager:getInstance()
  local item_mgr =  ItemManager:getInstance()
  local temp_eqm_vo = nil
  local eqm_comp_status 
  local eqm_status_one = nil

  --从背包中取出各个物品，找到物品对应能装备的位置，然后跟已存在装备比较
  --一个装备能对应两个战队位置，例如前1+前2
  pos_one,pos_two = team_mgr:limStand2TeamPos(cur_eqm_item.mode.limit_stand)
  self.battle_eqm_status[pos_one][cur_eqm_item.mode.item_type] = nil
  self.battle_eqm_status[pos_two][cur_eqm_item.mode.item_type] = nil

  local comp_eqm_item = nil
  for id,item in pairs(all_bag_items) do
    if cur_eqm_item.mode.item_type == item.mode.item_type and 
       cur_eqm_item.mode.limit_stand == item.mode.limit_stand  then --比初始化少的是，只需要查看当前部位的装备
      
      eqm_vo_list_one = temp_battle_eqms[pos_one]
      eqm_vo_list_two = temp_battle_eqms[pos_two]

      --前1/中1/后1
      if eqm_vo_list_one then
        temp_eqm_vo = eqm_vo_list_one:getSingleEquip(item.mode.item_type)
        comp_eqm_item = nil
        if temp_eqm_vo and temp_eqm_vo.item then
          comp_eqm_item = temp_eqm_vo.item
        end
       
        eqm_comp_status = item_mgr:eqmComp(item.mode.limit_stand, item.mode.item_type, item, comp_eqm_item)
        --如果状态是从无到有或者有更高级装备的话，则更新对应位置的值
        if self.battle_eqm_status[pos_one][item.mode.item_type] == nil or 
          self.battle_eqm_status[pos_one][item.mode.item_type]<eqm_comp_status then
             self.battle_eqm_status[pos_one][item.mode.item_type] = eqm_comp_status
        end
      
      end

      --前2/中2/后2
      if eqm_vo_list_two then
        temp_eqm_vo = eqm_vo_list_two:getSingleEquip(item.mode.item_type)
        comp_eqm_item = nil
        if temp_eqm_vo and temp_eqm_vo.item then
          comp_eqm_item = temp_eqm_vo.item
        end

        eqm_comp_status = item_mgr:eqmComp(item.mode.limit_stand, item.mode.item_type, item, comp_eqm_item)
        --如果状态是从无到有或者有更高级装备的话，则更新对应位置的值
        if self.battle_eqm_status[pos_two][item.mode.item_type] == nil or 
          self.battle_eqm_status[pos_two][item.mode.item_type]<eqm_comp_status then
             self.battle_eqm_status[pos_two][item.mode.item_type] = eqm_comp_status
        end
       
      end
    end
  end

  local params = {}
  local id_pos_list = TeamManager:getInstance():getHeroIdByLimitStand(cur_eqm_item.mode.limit_stand)
  if id_pos_list[1] then
    table.insert(params, id_pos_list[1].hero_id)
  end

  if id_pos_list[2] then
    table.insert(params, id_pos_list[2].hero_id)
  end

  Notifier.dispatchCmd(CmdName.UpdateGreenTipsPoint, params)

end

--技能升级结果
function onSkillUpgradeRsp( pbPkgData )
  local skill_upgrade_rsp = hero_pb.hero_skill_upgrade_rsp() 
  skill_upgrade_rsp:ParseFromString(pbPkgData)

  if skill_upgrade_rsp.ret ~= error_code_pb.msg_ret.success then
    local params = {}
   -- params["txt"] = Helper.getErrStr(skill_upgrade_rsp.ret)
   -- WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
    Alert:show(Helper.getErrStr(skill_upgrade_rsp.ret))
    cclog("skill upgrade fail,i don't know why.error_code_id:%d",skill_upgrade_rsp.ret)
    return 
  end     

  ComSender:getInstance():dealExtInfo(skill_upgrade_rsp.ext)

  local hero_info = HeroManager:getInstance():getHeroInfoById(skill_upgrade_rsp.hero_id)
  if hero_info == nil then
    cclog ("hero_info is nil")
    return
  end 

  hero_info:setSkillInfo(skill_upgrade_rsp.skill_id, skill_upgrade_rsp.skill_lev,true)

  CharacterManager:getInstance():updateRoleAssets(skill_upgrade_rsp.assets)

  _instance:setHeroAttrChange(skill_upgrade_rsp.hero_id,true)

  --通知UI技能更新
   local param = {}
   param.hero_id = skill_upgrade_rsp.hero_id
   param.skill_id = skill_upgrade_rsp.skill_id
   param.lev = skill_upgrade_rsp.skill_lev
   Notifier.dispatchCmd(CmdName.HeroSkillUpgradeSuccess,param) 
   --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10406 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"click_skillitem")
    end
end

local function activeHeroInfoSort(info_one,info_two)
  --优先级：是否上阵>等级>星级>战力>基础ID
  local team_pos_one = TeamManager:getInstance():isHeroInBattle(info_one.base_id)
  local team_pos_two = TeamManager:getInstance():isHeroInBattle(info_two.base_id)
  if team_pos_one>0 and team_pos_two==0 then
    return true
  elseif team_pos_one==0 and team_pos_two>0 then
    return false
  end

  if info_one.cur_lev ~= info_two.cur_lev then
    return info_one.cur_lev > info_two.cur_lev
  end

  if info_one.cur_stars ~= info_two.cur_stars then
    return info_one.cur_stars > info_two.cur_stars
  end

  local fc_one = _instance:getFightCapacity(info_one.base_id)
  local fc_two = _instance:getFightCapacity(info_two.base_id)

  if fc_one~=fc_two then
    return fc_one>fc_two
  end

  return info_one.base_id < info_two.base_id
end

local function unactiveHeroInfoSort(info_one,info_two)
  local cost_data = HeroManager:getInstance():getUpgradeCost(1)
  local item_quantity_one = ItemManager:getInstance():getSoulStoneNum(info_one.soul_gem_id)
  local item_quantity_two= ItemManager:getInstance():getSoulStoneNum(info_two.soul_gem_id)

  if item_quantity_one>=cost_data.soul_gem and 
    item_quantity_two>=cost_data.soul_gem then
    return info_one.base_id < info_two.base_id
  elseif item_quantity_one>=cost_data.soul_gem and
    item_quantity_two<cost_data.soul_gem then
    return true
  elseif item_quantity_one<cost_data.soul_gem and
    item_quantity_two>=cost_data.soul_gem then
    return false
  elseif item_quantity_one~=item_quantity_two then
    return item_quantity_one>item_quantity_two
  end

  return info_one.base_id < info_two.base_id
end

--根据卡牌站位类型返回相应数据
--is_sort,是否排序，避免初始化TeamManager:_initHeroData时，没有战队技能导致报错
function HeroManager:getHeroArrByPos(pos, is_sort)
  local activeArr = {}
  local unactiveArr = {}
    
  local HeroInfoDic = self.HeroInfoDic  

  local pos = pos or  ItemHelper.limitStand.Unlimit

  for i,v in pairs(HeroInfoDic) do
    if(v.pos == pos or pos == ItemHelper.limitStand.Unlimit) then 
      if v.id>0 then --id为0表示未激活
        table.insert(activeArr,v)
      else 
        table.insert(unactiveArr,v)
      end
    end
  end
  
  --升序排列
  if is_sort~=false then
    table.sort(activeArr,activeHeroInfoSort)
    table.sort(unactiveArr,unactiveHeroInfoSort)
  end

  return activeArr,unactiveArr
end

--判断是否特殊属性
function HeroManager:isSpecialAttr(attr_flg)
    return AttrHelper:isSpecialAttr(attr_flg)
end

--获取英雄自身属性，只计算英雄等级+星级+被动技能值
function HeroManager:getHeroSelfAttr(base_id,stars)
  local attrs = {} 
  local hero_info = self.HeroInfoDic[base_id]
  local base_attr = self.base_attr_Dic[base_id]
  local grow_attr = self.grow_attr_Dic[base_id]
  local star_ratio_one = nil
  local star_ratio_two = nil
  if stars then
    star_ratio_one = self:getStarRatioOne(stars)
    star_ratio_two = self:getStarRatioTwo(stars)
  else
    star_ratio_one = self:getStarRatioOne(hero_info.cur_stars)
    star_ratio_two = self:getStarRatioTwo(hero_info.cur_stars)
  end
  --计算卡牌基础+卡牌成长,卡牌属性= (基础属性+成长值*(等级-1))*成长系数 + 成长值*成长系数2
  for flag,value in pairs(base_attr:getAttrs()) do
    if self:isSpecialAttr(flag) then --特殊抗性计算不受英雄星级影响
      attrs[flag] = value + grow_attr:getDataByType(flag)*(hero_info.cur_lev-1)
    else
      attrs[flag] = (value + grow_attr:getDataByType(flag)*(hero_info.cur_lev-1))*star_ratio_one 
                    + (grow_attr:getDataByType(flag)*star_ratio_two)
     --cclog ("屬性名:%s,屬性值:%d",AttrHelper:getAttrNameByFlag(flag), attrs[flag])
    end
  end

  --计算被动技能的附加属性，如果技能表增加额外列，需要在这里增加，而且得保证该列属性在英雄基础属性中存在
  local pas_skills = hero_info.pas_skills
  local pas_skill_vo = nil
  local flag_name = nil
  for _,skill_info in pairs(pas_skills) do
    if skill_info.is_open then --当前技能已经开启了
      pas_skill_vo =  SkillManager:getInstance():getSkillData(skill_info.skill_id,skill_info.skill_lev)     
      --目前一个被动技能只对应一个属性，所以找到后直接break
      for flag,value in pairs(attrs) do
        flag_name = AttrHelper:getAttrStrFlag(flag)
        if pas_skill_vo[flag_name] and pas_skill_vo[flag_name]>0 then
          attrs[flag] = attrs[flag] + pas_skill_vo[flag_name]
          --cclog("被動技能加成~~~%s~~~%d",flag_name, pas_skill_vo[flag_name])
          break
        end
      end
    end
  end

  for flag,value in pairs(attrs) do
   -- attrs[flag] = math.ceil(value)
    if value>0 then
     --cclog ("英雄基礎屬性名:%s,屬性值:%d",AttrHelper:getAttrNameByFlag(flag), value)
    end
  end

  return attrs
end

local attr_team_skill_id_list = {TeamSkillID.MAGIC_STRIKE, TeamSkillID.STRONG_PHYSIQUE, TeamSkillID.STRONG_BONE}
local attr_flag_team_skill_list = {AttrHelper.attr_flag.atk, AttrHelper.attr_flag.hp, AttrHelper.attr_flag.pdef}
local team_skill_attr_key = {"attack", "hpMax", "defense"}

--获取卡牌最终属性,包含卡牌基础+卡牌成长+装备属性
function HeroManager:getHeroFinalAttr(base_id, team_type, value_is_calc_pet,stars)

  local team_type = team_type or TeamType.Normal

  local is_calc_pet = true
  local is_calc_guard = true

  if value_is_calc_pet==false then
    is_calc_pet = false
  end

  --暂时注释[]
	-- if self:isHeroAttrChange(base_id) == false then
	-- 	return self.final_attrs[base_id]
	-- end

	local attrs = self:getHeroSelfAttr(base_id,stars)
	local hero_info = self.HeroInfoDic[base_id]
	-- local base_attr = self.base_attr_Dic[base_id]
	-- local grow_attr = self.grow_attr_Dic[base_id]
	-- local star_ratio = self:getStarRatio(hero_info.cur_stars)

	-- --计算卡牌基础+卡牌成长,卡牌属性= (基础属性+成长值*(等级-1))*成长系数
	-- for flag,value in pairs(base_attr:getAttrs()) do
	--   if isSpecialAttr(flag) then --特殊抗性计算不受英雄星级影响
	--     attrs[flag] = value + grow_attr:getDataByType(flag)*(hero_info.cur_lev-1)
	--   else
	--     attrs[flag] = (value + grow_attr:getDataByType(flag)*(hero_info.cur_lev-1))*star_ratio
	--    --cclog ("屬性名:%s,屬性值:%d",AttrHelper:getAttrNameByFlag(flag), attrs[flag])
	--   end
	-- end

  --英雄时装增加的属性，是否上阵都会增加
  -- local fashion_list = hero_info:getFashionSlotEquipsList()
  -- local fashion_grow_attr = nil
  -- for _,list in pairs(fashion_list) do
  --   for _,vo in pairs(list) do
  --       -- fashion_grow_attr = self:getFashionGrowData(vo.fashionId,vo.stars)
  --       -- -- cclog("我是時裝%d,星級=%d,成長係數%d,成長係數2=%d",fashionData.fashionId,fashionData.stars,
  --       --   -- fashion_grow_attr.grow_ration_one,fashion_grow_attr.grow_ration_two)
  --       -- local fashionData = self:getCfgFashionDataById(vo.fashionId)
  --       -- local fashion_attrs = fashionData._attrs

  --       -- for flag,value in pairs(fashion_attrs) do
  --         -- attrs[flag] = value*(fashion_grow_attr.grow_ration_one+fashion_grow_attr.grow_ration_two)+attrs[flag]
  --       --   -- cclog("屬性名=%s,具體值=%s",AttrHelper:getAttrStrFlag(flag),attrs[flag])
  --       -- end

  --   end
  -- end

    local voList = hero_info:getFashionSlotEquipsList()
    for _,list in pairs(voList) do
        for _,v in pairs(list) do
            local addtions = self:getFashionAddtion(v.mode.base_id,v.stars,base_id)

            for i,v in ipairs(addtions) do
                attrs[v.key] = attrs[v.key] + v.value 
            end

        end
    end

  --判断英雄是否上阵，以下加成只有上阵英雄才有
  local team_pos = TeamManager:getInstance():isHeroInBattle(base_id, team_type)
  if team_pos>0 then
     
      --计算装备属性
      local battle_eqms = self:getBattleHeroEqmList(base_id, team_type)
      local gem_suit_lv = 0
      local enchantLv = 0
      if battle_eqms then
        gem_suit_lv = battle_eqms:getGemSuitLv()
        enchantLv = battle_eqms:getEnchantSuitLv()
        local eqms = battle_eqms:getEquipList()
      	local temp_item = nil
      	for location,eqm_vo in pairs(eqms) do
      	  temp_item = eqm_vo.item
        	local temp_attrs = {}
          if temp_item then
            temp_attrs = ItemManager:getInstance():getEqmFinalAttrById(temp_item.id, gem_suit_lv)
          end
        	for flag,value in pairs(temp_attrs) do
            --cclog("居然有裝備？%d~~~%d",flag,value)
        	  if attrs[flag] == nil then
        	    attrs[flag] = value 
        	  else
        	    attrs[flag] = attrs[flag] + value
        	  end
        	end
      	end

        --宝石套 属性
        local gemAttr = ItemManager:getInstance():getGemSuitAttr(gem_suit_lv)
        if gemAttr then
            for k,v in pairs(gemAttr) do
                attrs[k] = attrs[k] or 0
                attrs[k] = attrs[k] + v
            end
        end
        --附魔套 属性
        local enchantAttr = ItemManager:getInstance():getEnchantSuitAttr(enchantLv)
        if enchantAttr then
            for k,v in pairs(enchantAttr) do
                attrs[k] = attrs[k] or 0
                attrs[k] = attrs[k] + v
            end
        end
        -- cclog("hero_name=%s,gem_suit_lv=%s",hero_info.name, battle_eqms:getGemSuitLv())
      end

      --计算助阵加成
      local stand_data = TeamManager:getInstance():getStandbyData(team_type)
      local hp_value, attack_value, defense_value = stand_data:getAttrAddition()
      attrs[AttrHelper.attr_flag.hp] = attrs[AttrHelper.attr_flag.hp] + hp_value
      attrs[AttrHelper.attr_flag.atk] = attrs[AttrHelper.attr_flag.atk] + attack_value
      attrs[AttrHelper.attr_flag.pdef] = attrs[AttrHelper.attr_flag.pdef] + defense_value

      --计算战队技能加成
      -- local team_skill_vo
      -- local team_skill_num = #attr_team_skill_id_list
      -- for i=1,team_skill_num do
      --   team_skill_vo = TeamManager:getInstance():getTeamSkillData(attr_team_skill_id_list[i])
      --   if team_skill_vo then --如果是已学的
      --     attrs[attr_flag_team_skill_list[i]] = attrs[attr_flag_team_skill_list[i]]+
      --                                           team_skill_vo[team_skill_attr_key[i]]
      --    -- cclog("戰隊技能加成~~%s~~~~%d",team_skill_attr_key[i], team_skill_vo[team_skill_attr_key[i]])
      --   end
      -- end

      --计算侍宠精灵加成
      if is_calc_pet then
        local pet_attrs = PetDataProxy:getInstance():getAttrAddition()
        attrs[AttrHelper.attr_flag.hp] = attrs[AttrHelper.attr_flag.hp] + pet_attrs.hp
        attrs[AttrHelper.attr_flag.atk] = attrs[AttrHelper.attr_flag.atk] + pet_attrs.act
        attrs[AttrHelper.attr_flag.pdef] = attrs[AttrHelper.attr_flag.pdef] + pet_attrs.def
      end


      --计算公会技能加成
      local guild_proxy = GuildDataProxy:getInstance()
      local self_guild_skill_list = GuildDataProxy:getInstance():getMeSkillVoList()
      local guild_skill_passive_vo = nil
      local flag_name = nil
     
      for guild_skill_id, guild_skill_vo in pairs(self_guild_skill_list) do
        cclog("公會技能ID=%d,公會等級=%d",guild_skill_vo.id, guild_skill_vo.lev)
        guild_skill_passive_vo = guild_proxy:getSkillPassiveVoByLev(guild_skill_vo.id, guild_skill_vo.lev)
        if guild_skill_passive_vo then

           for flag,value in pairs(attrs) do
            flag_name = AttrHelper:getAttrStrFlag(flag)
            if guild_skill_passive_vo[flag_name] and guild_skill_passive_vo[flag_name]>0 then
              attrs[flag] = attrs[flag] + guild_skill_passive_vo[flag_name]
              cclog("幫會技能加成~~~%s~~~%d",flag_name, guild_skill_passive_vo[flag_name])
              break
            end
          end

        end
      end

      --计算守卫加成
      local guardIsAttr = ResContendManager:getInstance():getAcquireIsAttr()
      for _, v in pairs(guardIsAttr) do
          for k, av in pairs(v:getAttrs()) do
              attrs[k] = attrs[k] + av
          end
      end

  end

  --计算被动技能的附加属性，如果技能表增加额外列，需要在这里增加，而且得保证该列属性在英雄基础属性中存在
	-- local pas_skills = hero_info.pas_skills
	-- local pas_skill_vo = nil
	-- local flag_name = nil
	-- for _,skill_info in pairs(pas_skills) do
	--   if skill_info.is_open then --当前技能已经开启了
	--     pas_skill_vo =  SkillManager:getInstance():getSkillData(skill_info.skill_id,skill_info.skill_lev)     
	--     --目前一个被动技能只对应一个属性，所以找到后直接break
	--     for flag,value in pairs(attrs) do
	--       flag_name = AttrHelper:getAttrStrFlag(flag)
	--       if pas_skill_vo[flag_name] and pas_skill_vo[flag_name]>0 then
	--         attrs[flag] = attrs[flag] + pas_skill_vo[flag_name]
	--         break
	--       end
	--     end
	--   end
	-- end

	--对最终属性做向上取整处理
	for flag,value in pairs(attrs) do
	  attrs[flag] = math.ceil(value)
    if value>0 then
     --cclog ("戰鬥用最終屬性名:%s,屬性值:%d",AttrHelper:getAttrNameByFlag(flag), value)
    end
	end

	self.final_attrs[base_id] = attrs
  
  if hero_info.id>0 then
	 self:setHeroAttrChange(base_id,false)
  end
  
  return attrs

end

--计算其它玩家英雄的属性
function HeroManager:getOtherHeroFinalAttr(hero_info)
  local attrs = {} 
  local hero_info = hero_info
  local base_attr = self.base_attr_Dic[hero_info.base_id]
  local grow_attr = self.grow_attr_Dic[hero_info.base_id]
  local star_ratio_one = self:getStarRatioOne(hero_info.cur_stars)
  local star_ratio_two = self:getStarRatioTwo(hero_info.cur_stars)

  --计算卡牌基础+卡牌成长,卡牌属性= (基础属性+成长值*(等级-1))*成长系数
  for flag,value in pairs(base_attr:getAttrs()) do
      if self:isSpecialAttr(flag) then --特殊抗性计算不受英雄星级影响
        attrs[flag] = value + grow_attr:getDataByType(flag)*(hero_info.cur_lev-1)
      else
        attrs[flag] = (value + grow_attr:getDataByType(flag)*(hero_info.cur_lev-1))*star_ratio_one 
                      + (grow_attr:getDataByType(flag)*star_ratio_two)
      -- cclog ("屬性名:%s,屬性值:%d",AttrHelper:getAttrNameByFlag(flag), attrs[flag])
      end
  end

  --计算装备属性
  local eqms = hero_info:getEquipList():getEquipList()
  local temp_item = nil
  for location,eqm_vo in pairs(eqms) do
      temp_item = eqm_vo.item
    local temp_attrs =  ItemManager:getInstance():getEqmFinalAttrById(temp_item.id)
    for flag,value in pairs(temp_attrs) do
      if attrs[flag] == nil then
        attrs[flag] = value 
      else
        attrs[flag] = attrs[flag] + value
      end
    end
  end

  return attrs

end

function HeroManager:sendAddHeroReq()
  -- Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_stars_upgrade_rsp, "onGetHeroUpgradeRsp()") 
  local hero_add_req = hero_pb.hero_add_req() 
  ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_add_req,hero_add_req)
end

--服务端通知新激活了一张卡牌
function onHeroAddRsp(pbPkgData)
  local hero_add_rsp = hero_pb.hero_add_rsp() 
  hero_add_rsp:ParseFromString(pbPkgData)

  if hero_add_rsp.ret ~= error_code_pb.msg_ret.success then
    cclog("add hero fail,i don't know why")
    return 
  end   

  _instance:addHerosBySrv(hero_add_rsp.heroes)

  ComSender:getInstance():dealExtInfo(hero_add_rsp.ext)

  -- local srv_heros = hero_add_rsp.heroes
  -- local hero_num = #srv_heros
  -- local srv_hero_one = nil
  -- for i=1,hero_num do
  --   srv_hero_one = hero_add_rsp.heroes[i]
  --   _instance:addHero(srv_hero_one.id, srv_hero_one.lev, 
  --              srv_hero_one.stars, srv_hero_one.exp,
  --              srv_hero_one.skills)
  -- end
end

function HeroManager:addHerosBySrv(srv_heros)
  local srv_heros = srv_heros
  local hero_num = #srv_heros
  local srv_hero_one = nil
  local temp_hero_info = nil
  for i=1,hero_num do
    srv_hero_one = srv_heros[i]
    temp_hero_info = self:getHeroInfoByBaseId(srv_hero_one.id)
    --判断当前英雄是否已经激活，未激活则add
    if temp_hero_info.id>0 then
        _instance:updateHeroInfoByClient(
            srv_hero_one.id, 
            srv_hero_one.lev, 
            srv_hero_one.exp, 
            srv_hero_one.stars,
            srv_hero_one.pos_models,
            srv_hero_one.models
        )
    else
        _instance:addHero(
            srv_hero_one.id, 
            srv_hero_one.lev, 
            srv_hero_one.stars, 
            srv_hero_one.exp,
            srv_hero_one.skills,
            srv_hero_one.pos_models,
            srv_hero_one.models
        )
    end


  end
end

--英雄从未激活到激活状态
function HeroManager:addHero(id, lev, stars, exp, server_skills, fashionId, models)
    local tempHeroInfo = nil
    tempHeroInfo = HeroManager:getInstance().HeroInfoDic[id]
    tempHeroInfo:setExtData(id, lev, stars, exp, fashionId)
 
    --技能列表处理
    local skills = server_skills
    local skill_info = nil
    for k = 1, #skills do
       skill_info = skills[k]
       tempHeroInfo:setSkillInfo(skill_info.id,skill_info.lev)
    end

    tempHeroInfo:setFashionFromServer(models)

    -- Alert:show(string.format("已經啟動的卡牌是-----%d",id))

    Notifier.dispatchCmd(CmdName.UpdateHeroListView,id)
end

--根据卡牌星级获取相应成长系数_1
function HeroManager:getStarRatioOne(star)

  local up_cost = self:getUpgradeCost(star)
  if up_cost then
    return up_cost.grow_ration_one
  end

  return 1

  -- if star == 1 then
  --   return 1
  -- elseif star == 2 then
  --   return 1.2
  -- elseif star == 3 then
  --   return 1.4
  -- elseif star == 4 then
  --   return 1.7
  -- elseif star == 5 then   
  --   return 2
  -- else  --找不到的时候默认成长系数为1
  --   return 1  
  -- end
end

--根据卡牌星级获取相应成长系数_2
function HeroManager:getStarRatioTwo(star)
  local up_cost = self:getUpgradeCost(star)
  if up_cost then
    return up_cost.grow_ration_two
  end

  return 0
end

--战斗力计算的系数
local fc_ratio_list = nil
-- 涉及战斗力计算的属性
local fc_attr_list = nil

--获取英雄战斗力
--@params is_calc_pet 是否计算侍宠精灵提供的属性，默认计算
--@params stars 英雄星级
function HeroManager:getFightCapacity(base_id, team_type, is_calc_pet,stars)
--属性战斗力=(1*生命+6.5*攻击+5*防御+5*暴击+5*格挡+5*反击+3*忽视防御+6*闪避+5*坚韧+5*破击+13*真实伤害)/5

--英雄技能对战斗力的影响:主动1~3：每级战斗力+5
--                       被动1：每级+5，被动2：每级+10，被动3：每级+20

--总战斗力=属性战斗力+技能战斗力

  local hero_info = self:getHeroInfoByBaseId(base_id)
  local attrs = self:getHeroFinalAttr(base_id, team_type, is_calc_pet,stars)

  -- 需要校对战斗力时可以输出
  -- if hero_info.base_id==10016 then
  --   cclog("英雄名稱=%s",hero_info.name)
  --   for i,v in pairs(attrs) do
  --     cclog("  屬性名:%s,屬性數值:%s",AttrHelper:getAttrNameByFlag(i),v)
  --   end
  -- end

  local num = self:calculateHeroFc(hero_info, attrs)


  return num
end

--计算属性产生的战斗力
function HeroManager:calHeroAttrFc(attrs)
  if self.fc_ratio_list == nil then
    self.fc_ratio_list = {1, 6.5, 5, 5, 5, 5, 3, 6, 5, 5, 13}
  end

  if self.fc_attr_list == nil then
    self.fc_attr_list = {AttrHelper.attr_flag.hp, AttrHelper.attr_flag.atk, 
                      AttrHelper.attr_flag.pdef, AttrHelper.attr_flag.crit,
                      AttrHelper.attr_flag.block, AttrHelper.attr_flag.fight_back,
                      AttrHelper.attr_flag.def_break, AttrHelper.attr_flag.evasion,
                      AttrHelper.attr_flag.tought, AttrHelper.attr_flag.break_atk,
                      AttrHelper.attr_flag.real_harm}
  end

  local num = 0

  local attrs = attrs
  local fc_ratio = 0
  
  --计算属性对战斗力的影响
  for i,attr_flag in pairs(self.fc_attr_list) do
    if attrs[attr_flag] then
      fc_ratio = self.fc_ratio_list[i] or 0
      num = num+ attrs[attr_flag]*fc_ratio
    end
  end

  num = math.ceil(num/5)

  return num

end

--计算英雄技能提供的战斗力
function HeroManager:calHeroSkillFc(hero_info)
  local skill_fc = 0 
  skill_fc = skill_fc+hero_info.default_skills[1].skill_lev*5
  skill_fc = skill_fc+hero_info.default_skills[2].skill_lev*5
  skill_fc = skill_fc+hero_info.default_skills[3].skill_lev*5
  skill_fc = skill_fc+hero_info.pas_skills[1].skill_lev*5
  skill_fc = skill_fc+hero_info.pas_skills[2].skill_lev*10
  skill_fc = skill_fc+hero_info.pas_skills[3].skill_lev*20
  return skill_fc
end

function HeroManager:calculateHeroFc(hero_info, attrs)

  --属性产生的战斗力
  local attr_fc = self:calHeroAttrFc(attrs)
  local skill_fc = self:calHeroSkillFc(hero_info)

  local total_fc = attr_fc+skill_fc 
 
  return total_fc
end

function HeroManager:setHeroAtkAttr( baseId, atkBaseArgs, team_type )
	local attrInfo = self:getHeroFinalAttr(baseId, team_type)
	self:transHeroAttrs(attrInfo,atkBaseArgs)
end

function HeroManager:transHeroAttrs(base_attrs,trans_attrs)
  -- trans_attrs.hp = base_attrs[AttrHelper.attr_flag.hp]  --气血
  -- trans_attrs.atk = base_attrs[AttrHelper.attr_flag.atk]    --攻击力
  -- trans_attrs.pdef = base_attrs[AttrHelper.attr_flag.pdef]    --防御力
  -- trans_attrs.def_break = base_attrs[AttrHelper.attr_flag.def_break]  --忽视防御
  -- trans_attrs.crit = base_attrs[AttrHelper.attr_flag.crit]    --暴击
  -- trans_attrs.block = base_attrs[AttrHelper.attr_flag.block]    --格挡
  -- trans_attrs.evasion = base_attrs[AttrHelper.attr_flag.evasion]    --闪避
  -- trans_attrs.atk_speed = base_attrs[AttrHelper.attr_flag.atk_speed]  --攻击速度
  -- trans_attrs.fight_back = base_attrs[AttrHelper.attr_flag.fight_back]  --反击
  -- trans_attrs.reduce_harm = base_attrs[AttrHelper.attr_flag.reduce_harm]  --伤害豁免/减伤
  -- trans_attrs.real_harm = base_attrs[AttrHelper.attr_flag.real_harm]  --真实伤害/法伤
  -- trans_attrs.anti_stun = base_attrs[AttrHelper.attr_flag.anti_stun]  --眩晕抵抗
  -- trans_attrs.anti_silent = base_attrs[AttrHelper.attr_flag.anti_silent] --沉默抵抗
  -- trans_attrs.anti_chaos = base_attrs[AttrHelper.attr_flag.anti_chaos]  --混乱抵抗
  -- trans_attrs.anti_stone = base_attrs[AttrHelper.attr_flag.anti_stone]  --石化抵抗
  -- trans_attrs.anti_polymorph = base_attrs[AttrHelper.attr_flag.anti_polymorph]  --变形抵抗
  -- trans_attrs.anti_taunt = base_attrs[AttrHelper.attr_flag.anti_taunt]  --嘲讽抵抗
  -- trans_attrs.anti_sleep = base_attrs[AttrHelper.attr_flag.anti_sleep]  --睡眠抵抗
  -- trans_attrs.tought = base_attrs[AttrHelper.attr_flag.tought]  --坚韧
  -- trans_attrs.break_atk = base_attrs[AttrHelper.attr_flag.break_atk]  --破击   

  for attr_flag,value in pairs(base_attrs) do
       local flag_name = AttrHelper:getAttrStrFlag(attr_flag)
       trans_attrs[flag_name] = value
  end

end

--[[
@param hero_id 英雄ID或base_id
@param lev 英雄等级
@param exp 英雄经验
@param stars 英雄星级，不填则为原本星数
--]]

function HeroManager:updateHeroInfoByClient(hero_id, lev, exp, stars, pos_models, models)
    local hero_info = HeroManager:getInstance().HeroInfoDic[hero_id]
    if hero_info == nil then
      cclog("此ID的英雄資訊不存在")
      return
    end

    _instance:setHeroAttrChange(hero_id,true)

    if models then
        hero_info:setFashionFromServer(models)
    end
    
    local stars = stars or hero_info.cur_stars
    -- local fashionId = fashionId or hero_info._fashionId

    --判断是新增的英雄还是原有英雄改变属性
    if hero_info.id >0 then
        local list1 = clone(hero_info:getFashionSlotEquipsList())
        hero_info:setExtData(hero_id, lev, stars, exp, pos_models)
        Notifier.dispatchCmd(CmdName.UpdateHeroInfo,hero_info.base_id)  
        local list2 = clone(hero_info:getFashionSlotEquipsList())
        local fashionId = HeroHelper.checkExtFashion(list1,list2)
        if fashionId ~= nil then
            local fashionData = self:getCfgFashionDataById(fashionId)
            local mode = ItemManager:getInstance():getItemModelByBaseId(fashionData.baseId)
            Alert:show(string.format("你獲得了英雄時裝【%s】，可以在英雄介面處查看啦！",mode.name))
        end
    else
      -- Alert("")
     -- --技能列表处理
     -- local skills = hero_add_rsp.hero.skills
     -- local skill_info = nil
     -- for k = 1, #skills do
     --    skill_info = skills[k]
     --    tempHeroInfo:setSkillInfo(skill_info.id,skill_info.lev)
     -- end

     --  Notifier.dispatchCmd(CmdName.UpdateHeroListView,hero_info.base_id)
    end

    cclog("更新英雄資訊")

end

--[[
    英雄升级
]]
function HeroManager:upgradeHero(id, lev, exp)
    local hero_info = HeroManager:getInstance().HeroInfoDic[id]
    if hero_info == nil then
      cclog("此ID的英雄資訊不存在")
      return
    end

    hero_info.lev = cur_lev
    hero_info.exp = exp

end

--返回该ID的英雄属性是否需要重新计算的标识
function HeroManager:isHeroAttrChange(hero_id)
	local eqm_is_change = false
	-- local hero_info = self:getHeroInfoByBaseId(hero_id)
 --  if hero_info == nil then

 --  end
--	local eqms = self:getBattleHeroEqmList(hero_id):getEquipList()
	local temp_item = nil
	
  if self:getBattleHeroEqmList(hero_id) then
    local eqms = self:getBattleHeroEqmList(hero_id):getEquipList()
  	for _,eqm_vo in pairs(eqms) do
  		if eqm_vo.item and ItemManager:getInstance():getEqmAttrIsChange(eqm_vo.item.id) then
  			eqm_is_change = true
  			break
  		end
  	end
  end

	if self.attr_ischange[hero_id] ~= false or eqm_is_change then
		return true
	end

	return false
end

--返回该ID的英雄属性是否需要重新计算的标识
function HeroManager:setHeroAttrChange(hero_id,is_change)
	self.attr_ischange[hero_id] = is_change
end

function HeroManager:getLevExp(lev)
  local exp = self.lev_up_dic[lev]

  return exp or 1
end

function HeroManager:getUpgradeCost(star)
  return self.upgrade_cost_dic[star]
end

function HeroManager:sendHeroUpgrade(hero_id)
  --判断是否足够的金币
  local cur_coin = CharacterManager:getInstance():getAssetData():getGold()
  local hero_info = self:getHeroInfoByBaseId(hero_id)

  if hero_info.cur_stars == HeroManager.MAX_HERO_STAR then
    Alert:show("英雄飛升後可繼續進階")
    return 
  end

  local up_cost = self:getUpgradeCost(hero_info.cur_stars+1)
  if cur_coin<up_cost.cost_coin then
    Alert:show(string.format("您的金幣不足%d",up_cost.cost_coin))
    return
  end

  Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_stars_upgrade_rsp, "onGetHeroUpgradeRsp()") 
  local hero_upgrade_req = hero_pb.hero_stars_upgrade_req() 
  hero_upgrade_req.hero_id = hero_id 
  ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_stars_upgrade_req,hero_upgrade_req)
  -- Global:sendPkg(proto_cmd_pb.msg_cmd.hero_stars_upgrade_req, hero_upgrade_req:SerializeToString() , hero_upgrade_req:ByteSize())
end

function onGetHeroUpgradeRsp( pbPkgData )
   Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_stars_upgrade_rsp, "onGetHeroUpgradeRsp()") 

   local hero_upgrade_rsp = hero_pb.hero_stars_upgrade_rsp() 
    hero_upgrade_rsp:ParseFromString(pbPkgData)

  if hero_upgrade_rsp.ret ~= error_code_pb.msg_ret.success then
    if hero_upgrade_rsp.ret == error_code_pb.msg_ret.err_not_enough_coin then
      Alert:show("您的金幣不足")
    elseif hero_upgrade_rsp.ret == error_code_pb.msg_ret.err_not_enough_item then
      Alert:show("您的靈魂石不足")
    else
       Alert:show(Helper.getErrStr(hero_upgrade_rsp.ret))
    end

    return
  end  

   --更新资产
  CharacterManager:getInstance():updateRoleAssets(hero_upgrade_rsp.assets)
  --更新背包物品
  ItemManager:getInstance():updateOrDelMultiItems(hero_upgrade_rsp.cost_items)

  --更新进阶后英雄信息
  local temp_hero_info = _instance:getHeroInfoByBaseId(hero_upgrade_rsp.hero.id)
  
  local attrChange = nil
  local updateParam = nil
  --判断当前英雄是否已经激活，未激活则add
  if temp_hero_info.id>0 then
      local oldAttr = HeroManager:getInstance():getHeroFinalAttr(hero_upgrade_rsp.hero.id)

    _instance:updateHeroInfoByClient(
        hero_upgrade_rsp.hero.id, 
        hero_upgrade_rsp.hero.lev, 
        hero_upgrade_rsp.hero.exp, 
        hero_upgrade_rsp.hero.stars,
        hero_upgrade_rsp.hero.pos_models,
        hero_upgrade_rsp.hero.models
    )

     local nowAttr = HeroManager:getInstance():getHeroFinalAttr(hero_upgrade_rsp.hero.id)
     --计算差值
    attrChange = {}
    attrChange[AttrHelper.attr_flag.hp] = nowAttr[AttrHelper.attr_flag.hp] - oldAttr[AttrHelper.attr_flag.hp]
    attrChange[AttrHelper.attr_flag.atk] = nowAttr[AttrHelper.attr_flag.atk] - oldAttr[AttrHelper.attr_flag.atk]
    attrChange[AttrHelper.attr_flag.pdef] = nowAttr[AttrHelper.attr_flag.pdef] - oldAttr[AttrHelper.attr_flag.pdef]
    updateParam = {attr = attrChange,hero_id = hero_upgrade_rsp.hero.id}
  else

    _instance:addHero(
        hero_upgrade_rsp.hero.id, 
        hero_upgrade_rsp.hero.lev, 
        hero_upgrade_rsp.hero.stars, 
        hero_upgrade_rsp.hero.exp,
        hero_upgrade_rsp.hero.skills,
        hero_upgrade_rsp.hero.pos_models,
        hero_upgrade_rsp.hero.models
    )
      WindowCtrl:getInstance():open(CmdName.GuideHeroAnimScene,{hero_id = hero_upgrade_rsp.hero.id,area = GuideGetHeroArea.HeroListView})
  end
 
  Notifier.dispatchCmd(CmdName.HeroUpgradeSuccess,updateParam)

  ComSender:getInstance():dealExtInfo(hero_upgrade_rsp.ext)
end

--获取英雄的动作序列
function HeroManager:getHeroActListById( hero_id )
  return  self.hero_act_list[hero_id]
end

--获取英雄技能相关的特效ID
function HeroManager:getHeroSkillEffect( skill_id )
  return  self.hero_skill_eff_data[skill_id]
end

function HeroManager:getBattleHeroEqmList(hero_id, team_type)
    local team_type = team_type or TeamType.Normal
    local team_pos = TeamManager:getInstance():isHeroInBattle(hero_id, team_type)
    local battle_eqm_list = nil
    if team_pos>0 then
      battle_eqm_list = self.battle_hero_eqm_list[team_pos]
      if battle_eqm_list then
        return self.battle_hero_eqm_list[team_pos]
      else
        -- self:sendHeroAllEqmReq() --已经上阵的却没有装备数据，再请求一次
        cclog("HeroManager:sendHeroAllEqmReq()--已經上陣的卻沒有裝備資料，再請求一次")
      end
    end
    -- cclog("當前英雄%d",team_pos)
end

--通过装备ID查找对应上阵位置，然后找到所属英雄ID
-- function HeroManager:getHeroIdByEqmId(eqm_id)
--   local 
-- end

--通过灵魂石找到对应的英雄ID
function HeroManager:findHeroByGemId(gem_base_id)
    -- local hero_id = 0
    -- for i,v in pairs(self.HeroInfoDic) do
    --   if v.soul_gem_id == gem_base_id then
    --     hero_id = v.id
    --     break
    --   end
    -- end


    return self.soul_stone_list[gem_base_id]
end

--为当前装备寻找合适的英雄
function HeroManager:findFitHeroToEqmOn(cur_item)
  local limit_stand = cur_item.mode.limit_stand  --该装备对应的英雄站位类型:前/中/后
  local id_pos_list = TeamManager:getInstance():getHeroIdByLimitStand(limit_stand)
  local temp_hero_id = 0
  if #id_pos_list>0 then
    local eqm_list_one = nil   
    local eqm_list_two = nil

    if #id_pos_list==1 then
     -- eqm_list_one = self.battle_hero_eqm_list[id_pos_list[1].team_pos]
     temp_hero_id = id_pos_list[1].hero_id
      
    elseif #id_pos_list==2 then
      eqm_list_one = self.battle_hero_eqm_list[id_pos_list[1].team_pos]  
      eqm_list_two = self.battle_hero_eqm_list[id_pos_list[2].team_pos]  

      local attr_flag =  ItemHelper:getAttrFlagByLocation(cur_item.mode.item_type)
      local eqm_vo_one = eqm_list_one:getSingleEquip(cur_item.mode.item_type)
      local eqm_vo_two = eqm_list_two:getSingleEquip(cur_item.mode.item_type)
      local item_one = nil
      local item_two = nil

      local attrs_one = nil
      local attrs_two = nil

      if eqm_vo_one then
        item_one = eqm_vo_one.item
      end

      if eqm_vo_two then
        item_two = eqm_vo_two.item
      end

      if item_one then
        attrs_one = ItemManager:getInstance():getEqmBaseAttrAddQuality(item_one.mode.base_id)
      end

      if item_two then
        attrs_two = ItemManager:getInstance():getEqmBaseAttrAddQuality(item_two.mode.base_id)
      end

      if attrs_one == nil and attrs_two == nil then
        temp_hero_id = id_pos_list[1].hero_id --两个英雄都没装备，选站位前的
      elseif attrs_one~=nil and attrs_two==nil then
        temp_hero_id = id_pos_list[2].hero_id --其中一个没有装备
      elseif attrs_one == nil and attrs_two~=nil then
        temp_hero_id = id_pos_list[1].hero_id --其中一个没有装备
      else -- 两个英雄在该位置都有装备，可以比较属性
        if attrs_one[attr_flag]>attrs_two[attr_flag] then
          temp_hero_id = id_pos_list[2].hero_id
        else
          temp_hero_id = id_pos_list[1].hero_id
        end
      end
      
    end
  -- else
  --   Alert:show("您的戰隊x排沒有上陣英雄，不能穿戴裝備哦")
  --   return
  end

      -- local params = {}
      -- params.hero_id = temp_hero_id
      -- params.item = cur_item
      -- params.location = cur_item.mode.item_type
      -- WindowCtrl:getInstance():open(CmdName.EqmOnConfirmView, params) 
      return temp_hero_id
end

--英雄是否需要显示绿色提示点
function HeroManager:isShowTipsPoint(hero_id)
  
  --是否可进阶
  local is_can_upgrade = self:isHeroCanUpgrade(hero_id)
  if is_can_upgrade then
    return true
  end

  --是否有可替换装备
  local team_pos = TeamManager:getInstance():isHeroInBattle(hero_id)
  if team_pos==0 then --当前英雄未上阵
    return false 
  end

  local status_list =  self.battle_eqm_status[team_pos]

  for location,status in pairs(status_list) do
      if status == ItemHelper.exc_eqm_status.add or
        status == ItemHelper.exc_eqm_status.up then
          return true 
      end
  end

  return false
end

function HeroManager:isHeroCanUpgrade(hero_id)
  local hero_info = self:getHeroInfoByBaseId(hero_id)
  if hero_info.cur_stars < HeroManager.MAX_HERO_STAR then
    local one_cost = nil
    
    one_cost=self:getUpgradeCost(hero_info.cur_stars+1) 
    
    local cur_soul_stone_num = ItemManager:getInstance():getSoulStoneNum(hero_info.soul_gem_id)
    if cur_soul_stone_num>=one_cost.soul_gem then
      return true
    end
  end
  return false
end

function HeroManager:isHeroListViewNeedTipsPoint()
  for i,v in pairs(self.HeroInfoDic) do
      if self:isShowTipsPoint(v.base_id) then
        return true
      end
  end  

  return false
end

--[[
已经激活的英雄是否学习过技能了
true 表示已经点击过学习按钮
--]]
function HeroManager:isHeroLearnSkill()
  local active_arr = self:getHeroArrByPos(ItemHelper.limitStand.Unlimit, false)

  local skills = nil
  local temp_skill_one = nil
  for i,hero_info in pairs(active_arr) do
    skills =  hero_info.default_skills
    for j=1,#skills do
      temp_skill_one = skills[j]
      if temp_skill_one.skill_lev>1 then
        return true
      end
    end
  end

  return false
end

function HeroManager:readFindEqmData()
  if self.read_find_eqm_data then
    return
  end

  self.read_find_eqm_data = true
  local pbdata = Global:getAssetFileData("fnt_find_eqm_data.dat", "rb")

    local msg = fnt_find_eqm_data_pb.fnt_find_eqm_data()
    msg:ParseFromString(pbdata)

    local eqm_guide_rows = msg.eqm_guide_rows
    local eqm_guide_data_one = nil
    local sort_tab=nil

    for i, v in pairs(eqm_guide_rows) do
        if v.hero_pos~=nil then 
            eqm_guide_data_one = {}
            eqm_guide_data_one.hero_pos= v.hero_pos
            eqm_guide_data_one.eqm_type= v.eqm_type
            eqm_guide_data_one.dungeon_id= v.dungeon_id
            eqm_guide_data_one.diff= v.diff
            eqm_guide_data_one.min_lev= v.min_lev
            eqm_guide_data_one.max_lev= v.max_lev
            eqm_guide_data_one.icon_id= v.icon_id
            sort_tab = self.find_eqm_list[v.hero_pos..v.eqm_type] or {}
            table.insert(sort_tab,eqm_guide_data_one)
            self.find_eqm_list[v.hero_pos..v.eqm_type] = sort_tab
        end
    end

    local soul_stone_guide_rows = msg.soul_stone_guide_rows
    local soul_stone_guide_data_one = nil
    local soul_stone_sort_tab=nil

    for i, v in pairs(soul_stone_guide_rows) do
        if v.hero_id~=nil then 
            soul_stone_guide_data_one = {}
            soul_stone_guide_data_one.hero_id= v.hero_id
            soul_stone_guide_data_one.dungeon_id= v.dungeon_id
            soul_stone_guide_data_one.diff= v.diff
            soul_stone_guide_data_one.min_lev= v.min_lev
            soul_stone_guide_data_one.max_lev= v.max_lev
            soul_stone_sort_tab = self.soul_stone_guide_list[v.hero_id] or {}
            table.insert(soul_stone_sort_tab,soul_stone_guide_data_one)
            self.soul_stone_guide_list[v.hero_id] = soul_stone_sort_tab
        end
    end

    local better_eqm_guide_rows = msg.better_eqm_guide_rows
    local better_eqm_guide_tab = nil
    for i, v in pairs(better_eqm_guide_rows) do
        if v.team_lev~=nil then 
            local better_eqm_guide_obj = {}
            better_eqm_guide_obj.team_lev = v.team_lev
            better_eqm_guide_obj.hero_pos = v.hero_pos
            better_eqm_guide_obj.eqm_type = v.eqm_type
            better_eqm_guide_obj.dungeon_id = v.dungeon_id
            better_eqm_guide_obj.diff = v.diff
            better_eqm_guide_obj.target_base_id = v.target_base_id
            better_eqm_guide_obj.icon_id = v.icon_id

            better_eqm_guide_tab = self.better_eqm_guide_list[ v.team_lev ] or {}
            table.insert(better_eqm_guide_tab,better_eqm_guide_obj)
            self.better_eqm_guide_list[ v.team_lev ] = better_eqm_guide_tab
            self.better_eqm_guide_id_list[ v.target_base_id ] = better_eqm_guide_obj
        end
    end

    local upgrade_res_guide_rows = msg.upgrade_res_guide_rows
    local upgrade_res_guide_tab = nil
    for k,v in pairs(upgrade_res_guide_rows) do
        if v.base_id ~= nil then
            local upgrade_res_guide_obj = {}
            upgrade_res_guide_obj.base_id = v.base_id
            upgrade_res_guide_obj.icon_id = v.icon_id
            upgrade_res_guide_obj.dungeon_id = v.dungeon_id
            upgrade_res_guide_obj.diff = v.diff
            upgrade_res_guide_tab = self.upgrade_res_guide_list[ v.base_id ] or {}
            table.insert(upgrade_res_guide_tab,upgrade_res_guide_obj)
            self.upgrade_res_guide_list[ v.base_id ] = upgrade_res_guide_tab
        end
    end

    local pet_feed_guide_rows = msg.pet_feed_guide_rows
    local pet_feed_guide_tab = nil
    for k,v in pairs(pet_feed_guide_rows) do
        if v.base_id ~= nil then
            local pet_feed_guide_obj = {}
            pet_feed_guide_obj.base_id = v.base_id
            pet_feed_guide_obj.icon_id = v.icon_id
            pet_feed_guide_obj.dungeon_id = v.dungeon_id
            pet_feed_guide_obj.diff = v.diff
            pet_feed_guide_tab = self.pet_feed_guide_list[ v.base_id ] or {}
            table.insert(pet_feed_guide_tab,pet_feed_guide_obj)
            self.pet_feed_guide_list[ v.base_id ] = pet_feed_guide_tab
        end
    end

    local defguard_guide_rows = msg.defguard_guide_rows
    local defguard_guide_tab = nil
    for k,v in pairs(defguard_guide_rows) do
      if v.guard_id ~= nil then
          local defguard_guide_obj = {}
          defguard_guide_obj.guard_id = v.guard_id
          defguard_guide_obj.dungeon_id = v.dungeon_id
          defguard_guide_obj.diff = v.diff
          defguard_guide_tab = self.defguard_guide_list[ v.guard_id ] or {}
          table.insert(defguard_guide_tab,defguard_guide_obj)
          self.defguard_guide_list[ v.guard_id ] = defguard_guide_tab
      end
    end

    local fashion_guide_rows = msg.fashion_guide_rows
    local fashion_guide_tab = nil
    for k,v in pairs(fashion_guide_rows) do
        if v.base_id ~= nil then
            local fashion_guide_obj = {}
          fashion_guide_obj.fashion_id = v.fashion_id
          fashion_guide_obj.hero_id = v.base_id
          fashion_guide_obj.pos = v.pos
          fashion_guide_obj.diff = v.diff
          fashion_guide_obj.icon_id = v.icon_id
          fashion_guide_obj.dungeon_id = v.dungeon_id
          fashion_guide_tab = self.fashion_guide_list[ v.fashion_id ] or {}
          table.insert(fashion_guide_tab,fashion_guide_obj)
          self.fashion_guide_list[ v.fashion_id ] = fashion_guide_tab
        end
    end
end

function HeroManager:getFitFindEqmInfos(hero_pos, eqm_type, team_lv)
  if self.read_find_eqm_data ~= true then
    self:readFindEqmData()
  end

  local eqm_tabs = self.find_eqm_list[hero_pos..eqm_type]
  local temp_data = {}
  local data_one = nil
  local num =#eqm_tabs
  for i=1,num do
    data_one = eqm_tabs[i]
    if data_one.min_lev<=team_lv and data_one.max_lev>=team_lv then
      table.insert(temp_data,data_one)
    end
  end

  return temp_data

end

function HeroManager:getSoulStoneGuideInfos(hero_id, team_lv)
  if self.read_find_eqm_data ~= true then
    self:readFindEqmData()
  end

  local soul_stone_tabs = self.soul_stone_guide_list[hero_id]
  local temp_data = {}
  local data_one = nil
  local num =#soul_stone_tabs
  for i=1,num do
    data_one = soul_stone_tabs[i]
    if data_one.min_lev<=team_lv and data_one.max_lev>=team_lv then
      table.insert(temp_data,data_one)
    end
  end

  return temp_data

end

--获取更强装备 指引数据
function HeroManager:getBetterEqmGuideInfos(hero_pos,eqm_type)
  if self.read_find_eqm_data ~= true then
    self:readFindEqmData()
  end
    local ret = {}
    local teamLev = CharacterDataProxy:getInstance():getTeamLev()
    local fitLev = math.floor( math.min( teamLev,40 ) / 10 ) * 10 --向下取整
    local tbl = self.better_eqm_guide_list[ fitLev ]
    if tbl == nil then
        return nil
    else
        for k,v in pairs(tbl) do
            if v.hero_pos == hero_pos and v.eqm_type == eqm_type then
               table.insert(ret ,v)
            end
        end
        if #ret == 0 then ret = nil end
    end
    return ret
end

function HeroManager:getBetterEqmGuideInfoById(base_id)
   return self.better_eqm_guide_id_list[ base_id ]
end

--获取装备升级材料 引导数据
function HeroManager:getUpgradeResInfos(res_id)
  if self.read_find_eqm_data ~= true then
    self:readFindEqmData()
  end
  local ret = {}
  local tbl = self.upgrade_res_guide_list[ res_id ]
  if tbl == nil then
      return nil
  else
      for k,v in pairs(tbl) do
          if v.base_id == res_id then
              table.insert(ret, v)
          end
      end
      if #ret == 0 then ret = nil end
  end
  return ret
end

--获取侍宠 喂养材料 引导数据
function HeroManager:getPetFeedResInfos(res_id)
    if self.read_find_eqm_data ~= true then
      self:readFindEqmData()
    end
    local ret = {}
    local tbl = self.pet_feed_guide_list[ res_id ]
    if tbl == nil then
        return nil
    else
        for k,v in pairs(tbl) do
            if v.base_id == res_id then
                table.insert(ret, v)
            end
        end
        if #ret == 0 then ret = nil end
    end
    return ret
end

function HeroManager:getGuideGuardInfos(guard_id)

   if self.read_find_eqm_data ~= true then
      self:readFindEqmData()
    end
    local ret = {}
    local tbl = self.defguard_guide_list[ guard_id ]
    if tbl == nil then
        return nil
    else
        for k,v in pairs(tbl) do
            if v.guard_id == guard_id then
                table.insert(ret, v)
            end
        end
        if #ret == 0 then ret = nil end
    end
    return ret
end

function HeroManager:getGuideFashionInfos(fashion_id)

    if self.read_find_eqm_data ~= true then
        self:readFindEqmData()
    end
    local ret = {}
    local tbl = self.fashion_guide_list[ fashion_id ]
    if tbl == nil then
        return nil
    else
        for k,v in pairs(tbl) do
            if v.fashion_id == fashion_id then
                table.insert(ret, v)
            end
        end
        if #ret == 0 then ret = nil end
    end
    return ret
end

function HeroManager:getVirualLvExp(cur_lv, cur_exp, add_exp)
    local next_lv_exp = self:getLevExp(cur_lv+1)-cur_exp
    local virual_lv = cur_lv
    local virual_exp = cur_exp
    local remain_add = add_exp
    local max_lv = CharacterManager:getInstance():getTeamData():getLev()
    local is_max_lv =false
    while true do
      next_lv_exp = self:getLevExp(virual_lv+1)-virual_exp
      if max_lv<=virual_lv then
        cclog("已經跟戰隊等級一致")
        is_max_lv=true
        break
      end

      if remain_add>=next_lv_exp then
        virual_lv = virual_lv+1
        virual_exp = 0
        remain_add = remain_add-next_lv_exp
      else
        virual_exp = virual_exp+remain_add
        break
      end
    end

    return virual_lv, virual_exp, is_max_lv
end

--刷新所有英雄数据
function HeroManager:refreshAllHero(svr_heros)
  for i=1,#svr_heros do
      local v = svr_heros[i]
       --更新进阶后英雄信息
      local temp_hero_info = self:getHeroInfoByBaseId(v.id)
      --判断当前英雄是否已经激活，未激活则add
      if temp_hero_info.id>0 then
          self:updateHeroInfoByClient(v.id, v.lev, v.exp, v.stars, v.pos_models, v.models)
      else
          self:addHero(v.id, v.lev, v.stars, v.exp,v.skills, v.pos_models, v.models)
      end
  end
end

--[[
    获取配置的时装数据
    @param heroId 英雄ID
    @param fashionId 时装ID
    @param sex 性别
]]
function HeroManager:getConfigFashionData(heroId, fashionId, sex)
    if not sex then
        sex = CharacterManager:getInstance():getBaseData():getSex()
    end

    local heroDict = self._fashionDataDict[heroId]
    if not heroDict then
        return nil
    end

    local fashionDict = heroDict[fashionId]
    if not fashionDict then
        return nil
    end

    if fashionDict[tostring(sex)] then
        return fashionDict[tostring(sex)]
    end

    return fashionDict[tostring(2)]

end

--获取该英雄所有配的时装
function HeroManager:getAllCfgFashionData(heroId,sex)
    if not sex then
        sex = CharacterManager:getInstance():getBaseData():getSex()
    end
    local ret = {}
    if self._fashionDataDict[heroId] then
        for heroId,dic in pairs(self._fashionDataDict[heroId]) do
            if dic[tostring(sex)] then
                table.insert(ret,dic[tostring(sex)])
            elseif dic[tostring(2)] then
                table.insert(ret,dic[tostring(2)])
            end
        end
    end
    return ret
end

function HeroManager:getFashionGrowData(fashion_id, stars)
  if self._fashionGrowDict[fashion_id] then
    return self._fashionGrowDict[fashion_id][stars]
  end
  
  return nil
end

function HeroManager:getFashionGrowDataByBaseId(base_id,sex,star)
    local fashionData = self:getCfgFashionDataByBaseId(base_id,sex)
    return self._fashionGrowDict[fashionData.fashionId][star]
end

--根据物品id 获取时装属性
function HeroManager:getCfgFashionDataByBaseId(base_id,sex)
    if sex == nil then
        sex = CharacterManager:getInstance():getBaseData():getSex()
    end
    if self._fashionDataDict2[string.format("%d_%d",base_id,sex)] == nil then
        return self._fashionDataDict2[string.format("%d_%d",base_id,2)]
    end
    return self._fashionDataDict2[string.format("%d_%d",base_id,sex)]
end

--根据时装id 获取时装属性
function HeroManager:getCfgFashionDataById(id,sex)
    if sex == nil then
        sex = CharacterManager:getInstance():getBaseData():getSex()
    end
    if self._fashionDataDict3[string.format("%d_%d",id,sex)] == nil then
        return self._fashionDataDict3[string.format("%d_%d",id,2)]
    end
    return self._fashionDataDict3[string.format("%d_%d",id,sex)]
end

--获取 某英雄 时装属性数据
function HeroManager:getFashionItemTab(pos,heroId)
    return ItemManager:getInstance().fashionItemTab[ pos.."_"..heroId ]
end

function HeroManager:setFashionItemTab(pos,heroId,value)
    ItemManager:getInstance().fashionItemTab[ pos.."_"..heroId ] = value
end

function HeroManager:getFashionBaseAddtion(base_id,star,heroId)
    local ret = {}
    local fashionData = self:getCfgFashionDataByBaseId(base_id)
    local heroInfo = self:getHeroInfoById(heroId)
    local itemVo = self:getFashionItemTab(fashionData.pos,heroId)

    local totalTbl = {}
    if itemVo then
        local tm = ItemManager:getInstance()
        --成长属性
        local growData = self:getFashionGrowDataByBaseId(base_id,nil,star)
        for i,key in ipairs(fashionData:getAttrKeys()) do
            totalTbl[ key ] = totalTbl[ key ] or 0
            totalTbl[ key ] = totalTbl[ key ] + fashionData:getAttr()[ key ] * growData.grow_ration_one + fashionData:getAttr()[ key ] * growData.grow_ration_two
        end
    end
    local ret = {}
    for key,value in pairs(totalTbl) do
        table.insert(ret,{key=key,value=math.ceil(value)})
    end
    table.sort(ret,function(a,b) return a.key<b.key end)
    return ret
end

--获取时装加成属性
function HeroManager:getFashionAddtion(base_id,star,heroId)
    local ret = {}
    local fashionData = self:getCfgFashionDataByBaseId(base_id)
    local heroInfo = self:getHeroInfoById(heroId)
    local itemVo = self:getFashionItemTab(fashionData.pos,heroId)

    local totalTbl = {}

    if itemVo then
        local tm = ItemManager:getInstance()
        --成长属性
        local growData = self:getFashionGrowDataByBaseId(base_id,nil,star)
        for i,key in ipairs(fashionData:getAttrKeys()) do
            totalTbl[ key ] = totalTbl[ key ] or 0
            totalTbl[ key ] = totalTbl[ key ] + fashionData:getAttr()[ key ] * growData.grow_ration_one + fashionData:getAttr()[ key ] * growData.grow_ration_two
        end
        --强化属性
        local powered_atrrs = tm:getFashionPoweredAttr(heroId,fashionData.pos,itemVo.powered_lev)
        for flag,value in pairs(powered_atrrs) do
            if value >0 then
                totalTbl[flag] = totalTbl[flag] or 0
                totalTbl[flag] = totalTbl[flag] + value
            end
        end
        ---------------------------------------------------------------------
        local enchantBaseAttr = tm:getFashionEnchantAttr(heroId,fashionData.pos)
        local tmpList2 = powered_atrrs
        local tmpList1 = enchantBaseAttr
        local tmpList = {}
        for k,v in pairs(tmpList1) do
            tmpList[k] = v
        end
        for k,v in pairs(tmpList2) do
            tmpList[k] = tmpList[k] or 0
            tmpList[k] = tmpList[k] + v
        end
        --附魔
        local enchant_ratio = tm:getEnchantRation(itemVo.enchant_lev) -- 附魔系数
        for flag,value in pairs(tmpList) do
            if value>0 then
                tmpList[flag] = value * enchant_ratio

                -- print("原始值---附魔後",tmpList[flag] )
            end
        end
        ---------------------------------------------------------------------   
        for flag,value in pairs(tmpList) do
            if value >0 then
                totalTbl[flag] = totalTbl[flag] or 0
                totalTbl[flag] = totalTbl[flag] + value
            end
        end
        --鉴定
        for _,attr_vo in ipairs(itemVo.identify_attrs) do
            totalTbl[ attr_vo.flag ] = totalTbl[ attr_vo.flag ] or 0
            totalTbl[ attr_vo.flag ] = totalTbl[ attr_vo.flag ] + attr_vo.value
        end
        --宝石附加属性
        local gems = itemVo.gems
        local gem_item_mode = nil
        local gem_info 
        for _,base_id in pairs(gems) do
            gem_info = tm:getGemInfo(base_id)
            totalTbl[gem_info.attr_type] = totalTbl[gem_info.attr_type] or 0
            totalTbl[gem_info.attr_type] = totalTbl[gem_info.attr_type] + gem_info.val
           -- cclog ("寶石類型%d---具體%f",gem_info.attr_type,gem_info.val)
        end
    end

    local ret = {}
    for key,value in pairs(totalTbl) do
        table.insert(ret,{key=key,value=math.ceil(value)})
    end
    table.sort(ret,function(a,b) return a.key<b.key end)
    return ret
end
--获取属性描述
function HeroManager:getAttrDescById(id)
    return self._attrDescDict[id] or ""
end