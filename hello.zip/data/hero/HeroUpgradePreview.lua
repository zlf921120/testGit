--英雄 升阶 预览
HeroUpgradePreview = class("HeroUpgradePreview",WindowBase)
HeroUpgradePreview._widget = nil
HeroUpgradePreview.uiLayer = nil
HeroUpgradePreview.is_dispose = true

function HeroUpgradePreview:create()
    local ret = HeroUpgradePreview.new()
    return ret   
end

function HeroUpgradePreview:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end

function HeroUpgradePreview:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("hero/hero_upgrade_preview/hero_upgrade_preview.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then
		    self:addCloseAnim()
		end
    end)

    for i=1,5 do
    	self["img_b_star"..i] = tolua.cast(self.uiLayer:getWidgetByName("img_b_star"..i),"ImageView")
    	self["img_a_star"..i] = tolua.cast(self.uiLayer:getWidgetByName("img_a_star"..i),"ImageView")
    end

    self.labFightBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_fight_before"),"Label")
    self.labActBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_act_before"),"Label")
    self.labDefBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_def_before"),"Label")
    self.labHpBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_hp_before"),"Label")

    self.labFightAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_fight_after"),"Label")
    self.labActAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_act_after"),"Label")
    self.labDefAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_def_after"),"Label")
    self.labHpAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_hp_after"),"Label")
    self.labTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips"),"Label")

    self.panelLeft = tolua.cast(self.uiLayer:getWidgetByName("panel_left"),"Layout")
    self.panelRight = tolua.cast(self.uiLayer:getWidgetByName("panel_right"),"Layout")
end

function HeroUpgradePreview:open()
	local hero_id = self.params["hero_id"]
	local heroInfo = HeroManager:getInstance():getHeroInfoById(hero_id) 

	local starPathTbl = {"white_star.png","green_star.png","blue_star.png","purple_star.png","orange_star.png"}
	local cur_stars = heroInfo.cur_stars

	for i=1,5 do
		self["img_b_star"..i]:setVisible(i <= cur_stars)
		self["img_b_star"..i]:loadTexture(starPathTbl[cur_stars],UI_TEX_TYPE_PLIST)
	end
	self.labFightBefore:setText(HeroManager:getInstance():getFightCapacity(hero_id))
	local beforeAttr = HeroManager:getInstance():getHeroFinalAttr(hero_id)
	self.labActBefore:setText(beforeAttr[AttrHelper.attr_flag.atk])
	self.labDefBefore:setText(beforeAttr[AttrHelper.attr_flag.pdef])
	self.labHpBefore:setText(beforeAttr[AttrHelper.attr_flag.hp])
	local color = ItemHelper:getColorByQuality(cur_stars - 1)
	self.labActBefore:setColor(color)
	self.labDefBefore:setColor(color)
	self.labHpBefore:setColor(color)

	if cur_stars == HeroManager.MAX_HERO_STAR then -- 满阶了
		self.panelRight:setVisible(false)
		self.panelLeft:setPositionX(379)
		self.labTips:setVisible(true)
	else
		for i=1,5 do
			self["img_a_star"..i]:setVisible(i <= cur_stars + 1)
			self["img_a_star"..i]:loadTexture(starPathTbl[cur_stars + 1],UI_TEX_TYPE_PLIST)
		end
		self.labFightAfter:setText(HeroManager:getInstance():getFightCapacity(hero_id,nil,nil,cur_stars + 1))
		local afterAttr = HeroManager:getInstance():getHeroFinalAttr(hero_id,nil,nil,cur_stars + 1)
		self.labActAfter:setText(afterAttr[AttrHelper.attr_flag.atk])
		self.labDefAfter:setText(afterAttr[AttrHelper.attr_flag.pdef])
		self.labHpAfter:setText(afterAttr[AttrHelper.attr_flag.hp])

		local color = ItemHelper:getColorByQuality(cur_stars)
		self.labActAfter:setColor(color)
		self.labDefAfter:setColor(color)
		self.labHpAfter:setColor(color)
	end
	self:addOpenAnim()
end
