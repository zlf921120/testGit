-----------------------------------------------------------
--时装 项
FashionListItem = class("FashionListView",function()
	return Layout:create()
end)
FashionListItem._widget = nil
FashionListItem.fashionVo = nil

function FashionListItem:create(widget)
	local ret = FashionListItem.new()
	ret:init(widget)
	return ret
end

function FashionListItem:init(widget)

	self._widget = widget
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

  	self.item_icon = ItemIcon:create()
  	self.item_icon:setScale(0.8)
	self.item_icon:setPosition(ccp(52,68))
	self:addChild(self.item_icon)

	self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
	self.labStar = tolua.cast(self._widget:getChildByName("lab_star"),"Label")
	for i=1,4 do
		self["lab_attr"..i] = tolua.cast(self._widget:getChildByName("lab_attr"..i),"Label")
		self["lab_attr_v"..i] = tolua.cast(self._widget:getChildByName("lab_attr_v"..i),"Label")
	end

	self.panelGet = tolua.cast(self._widget:getChildByName("panel_get"),"Layout")
	self.imgSelect = tolua.cast(self.panelGet:getChildByName("img_select"),"ImageView")
	self.imgSelect:setVisible(false)
	self.labTips = tolua.cast(self._widget:getChildByName("lab_tips"),"Label")

	self.btnBg = tolua.cast(self._widget:getChildByName("btn_bg"),"Button")
	self.btnBg:addTouchEventListener(function(sender, eventType)
    	if eventType == ComConstTab.TouchEventType.ended then
    		if self.isGet then
				Notifier.dispatchCmd(CmdName.Fashion_Skin_Select_Item,self.fashionVo)
			else
				local param = {}
	            param.res_baseid = self.fashionVo.fashionId
	            param.find_type = ItemHelper.find_type.fashion
	            param.eqm_type = ItemHelper.itemType.fashion_skin
	            WindowCtrl:getInstance():open(CmdName.FindEqmView,param)

			end
		end
	end)
end

function FashionListItem:setSelect(b)
	if b ~= nil then
		self.imgSelect:setVisible(b)
	else
		local isVis = self.imgSelect:isVisible()
		self.imgSelect:setVisible(not isVis)
	end
	return self:isSelect()
end

function FashionListItem:isSelect()
	return self.imgSelect:isVisible()
end

function FashionListItem:setItem(fashionVo, location, hero_id)
	self.fashionVo = fashionVo
	self.location = location
	self.hero_id = hero_id -- 需要替换时装的英雄ID
	self.item_icon:setBaseId(self.fashionVo.mode.base_id)

	local hm = HeroManager:getInstance()
	local additionVo = hm:getFashionBaseAddtion(self.fashionVo.mode.base_id,self.fashionVo.stars,hero_id)
	self.labStar:setText(string.format("%d階",self.fashionVo.stars))
	self.labName:setText(self.fashionVo.mode.name)
	--初始化
	for i=1,4 do
		self[string.format("lab_attr%d",i)]:setVisible(false)
		self[string.format("lab_attr_v%d",i)]:setVisible(false)
	end

	for i,v in ipairs(additionVo) do
		if i <= 4 then
			self[string.format("lab_attr%d",i)]:setVisible(true)
			self[string.format("lab_attr%d",i)]:setText(AttrHelper:getAttrNameByFlag(v.key))
			self[string.format("lab_attr_v%d",i)]:setVisible(true)
			self[string.format("lab_attr_v%d",i)]:setText(v.value)
		end
	end

	self.isGet = true
	self.labTips:setVisible(false)
	self.panelGet:setVisible(true)
end

function FashionListItem:unGet()
	self.isGet = false
	self.labTips:setVisible(true)
	self.panelGet:setVisible(false)
end
-----------------------------------------------------------
--时装 列表
FashionListView = class("FashionListView",WidgetBase)
FashionListView._widget = nil
FashionListView._index = FashionListView
FashionListView.cur_hero_id = 0
FashionListView.dic = nil
FashionListView.dicCache = nil

function FashionListView:init()

	self._item_widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/fashion_list_item/fashion_list_item.ExportJson")
	self._item_widget:retain()

  	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/fashion_list/fashion_list.ExportJson")
  	self:addChild(self._widget)

  	self.dic = CCDictionary:create()	
	self.dic:retain()	

	self.dicCache = CCDictionary:create()	
	self.dicCache:retain()

	self.voCacheWidget = {}

  	self.panelAddition = tolua.cast(self._widget:getChildByName("panel_addition"),"Layout")
  	self.panelAddition:addTouchEventListener(function(sender, eventType)
  		local isVisible = self.panelAddition:isVisible()
  		if isVisible then return end
  		
    	-- if eventType == ComConstTab.TouchEventType.began then
    	-- 	require "FashionAdditionPanel"
     --        FashionAdditionPanel:show(self.cur_hero_id)

     --    elseif eventType == ComConstTab.TouchEventType.ended or
     --            eventType == ComConstTab.TouchEventType.canceled then

     --        FashionAdditionPanel:hide()
     --    end

        if eventType == ComConstTab.TouchEventType.ended then
        	WindowCtrl:getInstance():open(CmdName.FashionAdditionView,
        		{location=self.location,hero_id=self.cur_hero_id})
       	end
  	end)

  	self.btnDesc = tolua.cast(self._widget:getChildByName("btn_desc"),"Button")
  	self.btnDesc:addTouchEventListener(function(sender, eventType)
    	if eventType == ComConstTab.TouchEventType.ended then
    		require "IntroTips"
    		WindowCtrl:getInstance():open(CmdName.IntroTips,{txt=IntroTipsCfg.FashionTips,widthChar=25})
        end
  	end)

  	self.listView = tolua.cast(self._widget:getChildByName("list_view"),"ListView")
  	self.imgTips = tolua.cast(self._widget:getChildByName("no_fashion_tips"),"ImageView")
  	self.labAdditon = tolua.cast(self._widget:getChildByName("lab_addition"),"Label")

  	for i=1,9 do
  		self["lab_attr"..i] = tolua.cast(self._widget:getChildByName("lab_attr"..i),"Label")
  		self["lab_attr_v"..i] = tolua.cast(self._widget:getChildByName("lab_attr_v"..i),"Label")
  	end

  	Notifier.regist(CmdName.Fashion_Skin_Select_Item,function(itemData) self:onTouchItem(itemData) end)
  	Notifier.regist(CmdName.Upadate_Fashion_Skin,function(param) self:updateOnOffEqm(param)
  																self:refreshData() end)
end

function FashionListView:updateOnOffEqm(param)
	local onId = param.on
	local offId = param.off
	local cellOn = self.dic:objectForKey(string.format("fashion_%d",onId))
	local cellOff = self.dic:objectForKey(string.format("fashion_%d",offId))

	print(" onId ,offId " ,onId ,offId)
	if cellOff then
		cellOff:setSelect(false)
	end
	if cellOn then
		cellOn:setSelect(true)
	end
end

function FashionListView:onTouchItem(itemData)

	self.selectIdx = itemData.fashionId
	
	local heroInfo = HeroManager:getInstance():getHeroInfoById(self.cur_hero_id)
	local voList = heroInfo:getFashionSlotEquipsList(self.location)

	for _,list in pairs(voList) do
		for _,v in pairs(list) do
			if self.selectIdx ~= v.fashionId then
				self.dic:objectForKey(string.format("fashion_%d",v.fashionId)):setSelect(false)
			end
		end
	end

	-- 发送更换装备协议
    local param = {}
    local tmpItem = {}
    param.hero_id = self.cur_hero_id
	local isVis = self.dic:objectForKey(string.format("fashion_%d",self.selectIdx)):isSelect()
	if not isVis then
		tmpItem.id = self.selectIdx
		tmpItem.hero_id = 0
		print(" 穿！！ ")
	else
		self.selectIdx = nil
		tmpItem.id = 0
		tmpItem.hero_id = 0
		print(" 脫！！ ")
	end
	
    param.location = self.location
    param.item = tmpItem
    Notifier.dispatchCmd(CmdName.ChangeItemStorage,param)
end

function FashionListView:setData(hero_id, location)
   self.cur_hero_id = hero_id
   self.location = location

   local heroInfo = HeroManager:getInstance():getHeroInfoById(self.cur_hero_id)
   local item = heroInfo:getFashionCurWearItem(self.location)

   if item then
   	 	local fashionVo = heroInfo:getFashionCurWearList()[ self.location ]
   		self.selectIdx = fashionVo.fashionId
   else
   		self.selectIdx = nil
   end

end

function FashionListView:refreshData()

	self:makeCleanNormalList()
	self.listView:removeAllItems()
	self.dic:removeAllObjects()

	for i=1,9 do
  		self["lab_attr"..i]:setVisible(false)
  		self["lab_attr_v"..i]:setVisible(false)
  	end

	local heroInfo = HeroManager:getInstance():getHeroInfoById(self.cur_hero_id)
	local voList = heroInfo:getFashionSlotEquipsList()[ self.location ]

	if voList then
		self.panelAddition:setVisible(false)
		local hm = HeroManager:getInstance()
		local arr = CCArray:create()
		for i,v in ipairs(voList) do
	 		local cell = self.dic:objectForKey(string.format("fashion_%d",v.fashionId))
			if cell == nil then
				cell = self:getCacheItem()
				self.dic:setObject(cell,string.format("fashion_%d",v.fashionId))
			end
			cell:setItem(v,self.location,self.cur_hero_id)
			self.listView:pushBackCustomItem(cell)
		end

		if self.selectIdx then
			self.dic:objectForKey(string.format("fashion_%d",self.selectIdx)):setSelect(true)
		end

		local attrs = heroInfo:getFashionSlotEquipAddition(self.location)
		for i,v in ipairs(attrs) do
	  		self["lab_attr"..i]:setVisible(true)
	  		self["lab_attr_v"..i]:setVisible(true)
	  		self["lab_attr"..i]:setText(AttrHelper:getAttrNameByFlag(v.key))
	  		self["lab_attr_v"..i]:setText(v.value)
	  	end
	else
	 	self.panelAddition:setVisible(true)
  	end

  	self.labAdditon:setVisible(voList ~= nil)

  	local unGetListVo = heroInfo:getUnGetFashionList(self.location)
  	if unGetListVo then

  		local hm = HeroManager:getInstance()
		local arr = CCArray:create()
		for i,v in ipairs(unGetListVo) do
	 		local cell = self.dic:objectForKey(string.format("fashion_%d",v.fashionId))
			if cell == nil then
				cell = self:getCacheItem()
				self.dic:setObject(cell,string.format("fashion_%d",v.fashionId))
			end
			cell:setItem(v,self.location,self.cur_hero_id)
			cell:unGet()
			self.listView:pushBackCustomItem(cell)
		end
  	else

  	end
  	self.imgTips:setVisible(not( unGetListVo or voList )) 
end

function FashionListView:getCacheItem()
	local freeIdx = 0
	for i=1,#self.voCacheWidget do
		local v = self.voCacheWidget[i]
		if v.isFree == 1 then
			freeIdx = v.idx
			break
		end
	end
	local item = nil
	if freeIdx == 0 then
		item = FashionListItem:create(self._item_widget:clone())
		table.insert(self.voCacheWidget,{isFree = 0,idx = #self.voCacheWidget + 1})
		self.dicCache:setObject(item,string.format("cache_normal%d",#self.voCacheWidget))
	else
		item = self.dicCache:objectForKey(string.format("cache_normal%d",freeIdx))
	end
	return item
end

function FashionListView:makeCleanNormalList()
	for i=1,#self.voCacheWidget do
		local v = self.voCacheWidget[i]
		v.isFree = 1
	end
end

function FashionListView:create()
	local ret = FashionListView.new()
	ret:init()
	return ret
end