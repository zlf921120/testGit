--时装总加成 标题 条目
FashionAdditionViewTitleItem = class("FashionAdditionViewTitleItem",function()
	return Layout:create()
end)

function FashionAdditionViewTitleItem:create(widget)
    local ret = FashionAdditionViewTitleItem.new()
    ret:init(widget)
    return ret
end

function FashionAdditionViewTitleItem:init(widget)
	self._widget = widget:clone()
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	self.labTitle = tolua.cast(self._widget:getChildByName("lab_title"),"Label")
end

function FashionAdditionViewTitleItem:setData(txt)
	self.labTitle:setText(txt)
end

--时装总加成 条目
FashionAdditionViewItem = class("FashionAdditionViewItem",function()
	return Layout:create()
end)

function FashionAdditionViewItem:create(widget)
    local ret = FashionAdditionViewItem.new()
    ret:init(widget)
    return ret
end

function FashionAdditionViewItem:init(widget)

	self._widget = widget:clone()
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	for i=1,2 do
		self["lab_attr"..i] = tolua.cast(self._widget:getChildByName("lab_attr"..i),"Label") 
		self["lab_attr_v"..i] = tolua.cast(self._widget:getChildByName("lab_attr_v"..i),"Label") 
	end
end

function FashionAdditionViewItem:setData(vo)
	for i=1,2 do
		self["lab_attr"..i]:setVisible(false)
		self["lab_attr_v"..i]:setVisible(false)
	end

	for i,v in ipairs(vo) do
		if i <= 2 then
			self["lab_attr"..i]:setVisible(true)
			self["lab_attr"..i]:setText(AttrHelper:getAttrNameByFlag(v.key)..":")
			self["lab_attr_v"..i]:setVisible(true)
			self["lab_attr_v"..i]:setText(v.value)
		end
	end
end

--时装总加成 面板
FashionAdditionView = class("FashionAdditionView",WindowBase)
FashionAdditionView.__index = FashionAdditionView
FashionAdditionView._widget     = nil
FashionAdditionView.uiLayer    = nil
FashionAdditionView.is_dispose = true

local __instance = nil

function FashionAdditionView:create()
    local ret = FashionAdditionView.new()
    __instance = ret
    return ret   
end

function FashionAdditionView:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end

    self._widget_title:release()
    self._widget_title = nil
    self._widget_item:release()
    self._widget_item = nil
    self.base_attr_label:release()
    self.base_attr_label = nil
    self.powered_lv_label:release()
    self.powered_lv_label = nil
    self.powered_attr_label:release()
    self.powered_attr_label = nil
    self.enchant_label:release()
    self.enchant_label = nil
    self.identify_dec_label:release()
    self.identify_dec_label = nil
    self.gem_one_label:release()
    self.gem_one_label = nil
    self.gem_two_label:release()
    self.gem_two_label = nil
    self.gem_three_label:release()
    self.gem_three_label = nil
    self.attr_label_dic:release()
    self.attr_label_dic = nil
end

function FashionAdditionView:init()

	require "AttrLabel"
    self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/fashion_list/fashion_addition_view.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self._widget_title = GUIReader:shareReader():widgetFromJsonFile("ui/hero/fashion_list/fashion_addition_item_title.ExportJson")
    self._widget_title:retain()

    self._widget_item = GUIReader:shareReader():widgetFromJsonFile("ui/hero/fashion_list/fashion_addition_item.ExportJson")
    self._widget_item:retain()

    local btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    btnClose:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then 
	       WindowCtrl:getInstance():close(self.name)
	    end
	end)

    self.attr_label_dic = CCDictionary:create()
	self.attr_label_dic:retain()	

    self.attr_list_view = tolua.cast(self._widget:getChildByName("list_view"),"ListView")

    self.base_attr_label = AttrLabel:create()
    self.base_attr_label:setData("基礎屬性","100")
    self.base_attr_label:retain()

    self.powered_lv_label = AttrLabel:create()
    self.powered_lv_label:setData("強化等級：","1")
    self.powered_lv_label:setEachLabelColor(1, ItemHelper.colors.deep_orange)
    self.powered_lv_label:retain()

    self.powered_attr_label = AttrLabel:create()
    self.powered_attr_label:setData("強化屬性：","1")
    self.powered_attr_label:retain()

    self.enchant_label = AttrLabel:create()
    self.enchant_label:setData("附魔等級:1級")
    self.enchant_label:setEachLabelColor(1, ItemHelper.colors.deep_orange)

    self.enchant_label:retain()

    self.identify_dec_label = AttrLabel:create()
    self.identify_dec_label:setData("鑒定屬性:")
    self.identify_dec_label:retain()
     self.identify_dec_label:setEachLabelColor(1, ItemHelper.colors.deep_orange)

    self.gem_one_label =  AttrLabel:create()
    self.gem_one_label:setData("11級防禦石:","+800氣血")
    self.gem_one_label:setSize(CCSize(300,38))
    self.gem_one_label:retain()

    self.gem_two_label =  AttrLabel:create()
    self.gem_two_label:setData("11級防禦石:","+800氣血")
    self.gem_two_label:setSize(CCSize(300,38))
    self.gem_two_label:retain()

    self.gem_three_label =  AttrLabel:create()
    self.gem_three_label:setData("11級防禦石:","+800氣血")
    self.gem_three_label:setSize(CCSize(300,38))
    self.gem_three_label:retain()

end

function FashionAdditionView:open()

	local location = self.params["location"]
	local hero_id = self.params["hero_id"]

	local hm = HeroManager:getInstance()
	self.itemData = hm:getFashionItemTab(location,hero_id)
	self.attr_list_view:removeAllItems()

	local heroInfo = hm:getHeroInfoByBaseId(hero_id)
	for _,v in pairs(heroInfo:getFashionSlotEquipsList()[location]) do

		local additionVo = hm:getFashionBaseAddtion(v.mode.base_id,v.stars,hero_id)
		local cellTitle = FashionAdditionViewTitleItem:create(self._widget_title)
		local cellItem = FashionAdditionViewItem:create(self._widget_item)
		cellItem:setData(additionVo)
		cellTitle:setData(v.mode.name)
		self.attr_list_view:pushBackCustomItem(cellTitle)
		self.attr_list_view:pushBackCustomItem(cellItem)
	end

	local cellTitle = FashionAdditionViewTitleItem:create(self._widget_title)
	cellTitle:setData("鍛造加成")
	self.attr_list_view:pushBackCustomItem(cellTitle)

	local cur_attrs = nil
    local equipType = ItemHelper:getEquipTypeWithItemType(location)
    if equipType == ItemHelper.equipType.equip then
        cur_attrs = ItemManager:getInstance():getEqmPoweredAttr(self.itemData.mode.base_id,self.itemData.powered_lev)
    elseif equipType == ItemHelper.equipType.fashion then
        cur_attrs = ItemManager:getInstance():getFashionPoweredAttr(hero_id,location,self.itemData.powered_lev)
    end
    for k,v in pairs(cur_attrs) do
        if v > 0 then
            self.attr_flag = k
            break
        end
    end

	local enchant_ratio = ItemManager:getInstance():getEnchantRation(self.itemData.enchant_lev) -- 附魔系数
	local attr_name = AttrHelper:getAttrNameByFlag(self.attr_flag)

	--强化等级处理
	if self.itemData.powered_lev>0 then
		
		 local powered_attrs = ItemManager:getInstance():getFashionPoweredAttr(hero_id,location,self.itemData.powered_lev)
		 self.powered_lv_label:setData("強化等級:",self.itemData.powered_lev)
		 self.attr_list_view:pushBackCustomItem(self.powered_lv_label)
		 if enchant_ratio>0 then
		 	self.powered_attr_label:setData(attr_name..":",math.ceil(powered_attrs[self.attr_flag]),
		 										math.ceil(powered_attrs[self.attr_flag]*enchant_ratio))
		 else
		 	self.powered_attr_label:setData(attr_name..":",math.ceil(powered_attrs[self.attr_flag]))
		 end
		 self.attr_list_view:pushBackCustomItem(self.powered_attr_label)
	end 

	--附魔等级处理
	if self.itemData.enchant_lev>0 then
		self.enchant_label:setEachLabelColor(2,ItemHelper:getEnchantColor(self.itemData.enchant_lev))
		self.powered_attr_label:setEachLabelColor(3,ItemHelper:getEnchantColor(self.itemData.enchant_lev))

		self.enchant_label:setData("附魔等級:",string.format("%d級",self.itemData.enchant_lev))
		self.attr_list_view:pushBackCustomItem(self.enchant_label)
	end

	--鉴定属性处理
	local identify_attrs = self.itemData.identify_attrs
	local count = #identify_attrs
	local attr_vo = nil
	local attr_label = nil
	if count>0 then
		self.identify_dec_label:setData("鑒定屬性:")
		self.attr_list_view:pushBackCustomItem(self.identify_dec_label)

		for key=1,count do
			attr_vo = identify_attrs[key]
			attr_label = self.attr_label_dic:objectForKey(key)
			if attr_label == nil then
				attr_label = AttrLabel:create()
				self.attr_label_dic:setObject(attr_label, key)
			end
			attr_label:setData(AttrHelper:getAttrNameByFlag(attr_vo.flag)..":",string.format("%d   (%d星)",
								attr_vo.value,attr_vo.stars))
			attr_label:setEachLabelColor(2,ItemHelper.colors.blue)

			self.attr_list_view:pushBackCustomItem(attr_label)
		end
	elseif self.itemData.mode.quality>ItemHelper.itemQuality.Blue then
		self.identify_dec_label:setData("鑒定屬性：","尚未鑒定")
		self.attr_list_view:pushBackCustomItem(self.identify_dec_label)
	end

	local gems = self.itemData.gems
	local gem_label_status ={}
	local temp_item_mode = nil
	local temp_gem_data = nil
	local gem_attr_name = nil
	local gem_value_str = nil
	for gem_idx =1,3 do
		if gems[gem_idx] then
			temp_item_mode = ItemManager:getInstance():getItemModelByBaseId(gems[gem_idx])
			temp_gem_data =  ItemManager:getInstance():getGemInfo(gems[gem_idx])

			if self.gem_one_label:getParent()==nil then
				self.gem_one_label:setData(temp_item_mode.name..":",string.format(" +%d",
						temp_gem_data.val,AttrHelper:getAttrNameByFlag(temp_gem_data.attr_type)))
				self.attr_list_view:pushBackCustomItem(self.gem_one_label)
			elseif self.gem_two_label:getParent()==nil then
				self.gem_two_label:setData(temp_item_mode.name..":",string.format(" +%d",
						temp_gem_data.val,AttrHelper:getAttrNameByFlag(temp_gem_data.attr_type)))
				self.attr_list_view:pushBackCustomItem(self.gem_two_label)
			elseif self.gem_three_label:getParent()==nil then	
				self.gem_three_label:setData(temp_item_mode.name..":",string.format(" +%d",
						temp_gem_data.val,AttrHelper:getAttrNameByFlag(temp_gem_data.attr_type)))
				self.attr_list_view:pushBackCustomItem(self.gem_three_label)
			end

		end
	end


end