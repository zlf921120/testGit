--
-- Author: lvgansheng
-- Date: 2014-06-18 17:22:53
-- 单个卡牌界面

HeroView =  class("HeroView", function() return WindowBase:create() end)
HeroView.uiLayer = nil
HeroView.widget = nil
HeroView.eqmSlotTab = nil  --存储八个装备槽
HeroView.curHeroId = 0 --当前查看的卡牌ID
HeroView.curCardData = nil --当前查看的卡牌详细数据
HeroView.limitStand = ItemHelper.limitStand.Front 
HeroView.curOpenViewFlag = 0 -- 当前打开左侧界面标示
HeroView.leftViewDic = nil --存放左侧界面
HeroView.hero_animation = nil -- 角色动画[bug]
HeroView.hero_panel = nil -- 角色上层面板
HeroView.hero_back_panel = nil -- 角色下层面板
HeroView._isShowFashion = false --是否展示时装状态

local itemMgr = nil
local cardMgr = nil

local _instance = nil

local posArr = {} -- 八个装备插槽的位置数组
posArr[ItemHelper.itemType.Weapon] = ccp(63,358)
posArr[ItemHelper.itemType.Clothes] = ccp(63,251)
posArr[ItemHelper.itemType.Trousers] =ccp (63,144)
posArr[ItemHelper.itemType.Shoes] = ccp(63,37)
posArr[ItemHelper.itemType.Ring] = ccp(462,358)
posArr[ItemHelper.itemType.Jewelry] =ccp(462,251)
posArr[ItemHelper.itemType.Amulet] = ccp(462,144)
posArr[ItemHelper.itemType.Necklace] = ccp(462,37)

local action_list = nil --正在执行的动作列表
local stard_act_list = nil --英雄表里填的标准动作
local cur_action_idx = 0
local is_play_act_list = false
local activeArr

local upgrade_btn_tips_img -- 进阶按钮上的绿色提示点

local skill_upgrade_time = 0 --最后技能升级的时间


local hero_anim_path = nil

HeroView.cur_part_view = nil

function HeroView:init()

	require("SkillView")
	require("HeroUpgradeView")
	require("AttrView")
	require("HeroImgView")
	require("EquipListView")
	-- require("EquipAttrView")
	require("EquipIcon")
	require("EquipOnConfirmView")
	require("HeroHelper")
	require("WindowBase")
	require "ItemHelper"
	require "EffectManager"
	require "AnimateManager"
	require "TeamEnum"
	require "TeamManager"
	require "ItemInfoView"
	require "FashionListView"
	
	ComResMgr:getInstance():loadResByName("ui/hero/hero.plist","ui/hero/hero.pvr.ccz")

	--初始化相关数据
	itemMgr = ItemManager:getInstance()
	cardMgr = HeroManager:getInstance()

	self.eqmSlotTab = {}
	self.fashionSlotTab = {}
	self.leftViewDic = CCDictionary:create()	
	self.leftViewDic:retain()		

	--初始化界面相关
	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	self.down_layout = DisplayUtil.newLayout()
	local up_layout = DisplayUtil.newLayout()

	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/hero_base/hero_base.ExportJson")
	self.widget:setPositionX(9)
	self.widget:setZOrder(5)
	self.down_layout:addChild(self.widget)
    self.uiLayer:addWidget(self.down_layout )
    self.uiLayer:addWidget(up_layout)

    --战斗力数字图片
    self.fc_num_img = LabelAtlas:create()
    self.fc_num_img:setProperty(0000,"ui/digit/digit_4.png",24,32,"0")
    -- self.fc_num_img:setStringValue(6782)
    self.fc_num_img:setPosition(ccp(675,147))
    self.fc_num_img:setScale(0.8)
    self.uiLayer:addChild(self.fc_num_img)

    self.panelEqm = tolua.cast(self.uiLayer:getWidgetByName("panel_eqm"),"Layout")
    self.panelFashion = tolua.cast(self.uiLayer:getWidgetByName("panel_fashion"),"Layout")
    self.animTbl = {} --进阶 动画元素

    local left_arrow = Button:create()
    left_arrow:setScaleX(-1)
    left_arrow:loadTextures("btn_up_14.png", "btn_down_14.png", "", UI_TEX_TYPE_PLIST)
    up_layout:addChild(left_arrow)
    left_arrow:setPosition(ccp(27,305))

    local right_arrow = Button:create()
    right_arrow:loadTextures("btn_up_14.png", "btn_down_14.png", "", UI_TEX_TYPE_PLIST)
    up_layout:addChild(right_arrow)
    right_arrow:setPosition(ccp(930,305))


    
    --英雄随即动作播放完成后
    local function playCallBack(armature, movementType, movementID)
		if movementType == AnimationMovementType.COMPLETE then 
			-- self.hero_animation:getAnimation():play("stand")
			-- self.hero_animation:getAnimation():setMovementEventCallFunc(function()end)
			--播放一个动作后，移除关联特效
			if action_list[cur_action_idx] and 
				action_list[cur_action_idx][2] ~= nil then
			 		EffectManager:getInstance():removeEffect(self.hero_panel,action_list[cur_action_idx][2], nil, 0)
			end

			if action_list[cur_action_idx] and 
				action_list[cur_action_idx][3] ~= nil and
				action_list[cur_action_idx][3] >0 then
			 		EffectManager:getInstance():removeEffect(self.hero_back_panel,action_list[cur_action_idx][3], nil, 0)
			end

			cur_action_idx = cur_action_idx +1
			if cur_action_idx>#action_list then
				is_play_act_list = false
				self.hero_animation:getAnimation():setMovementEventCallFunc(function()end)
				self.hero_animation:getAnimation():play("stand")
				TimerManager.addTimer(10000, self._onPlayActList,true)
			else
				self.hero_animation:getAnimation():play(action_list[cur_action_idx][1],-1,-1,0)
				if action_list[cur_action_idx][2] ~= nil then
			 		EffectManager:getInstance():playEffect(self.hero_panel,action_list[cur_action_idx][2], nil, 0)
				end

				if action_list[cur_action_idx][3] ~= nil and action_list[cur_action_idx][3]>0 then
			 		EffectManager:getInstance():playEffect(self.hero_back_panel,action_list[cur_action_idx][3], nil, 0)
				end
			end
		end
	end

	--点击英雄位置，随机播放一个动作
    local hero_bg = tolua.cast(_instance.uiLayer:getWidgetByName("hero_anim_layer"), "ImageView")
    hero_bg:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
    		if is_play_act_list then
				cclog("已經在播放動作序列")
				return
			end
			self._onPlayActList()
		end
    end)

	--local up_btn = self.uiLayer:getWidgetByName("up_change_btn")
	-- up_btn:setScaleX(-0.5)
    left_arrow:addTouchEventListener(function(sender, eventType )
		if eventType == ComConstTab.TouchEventType.ended then
			--local activeArr = HeroManager:getInstance():getHeroArrByPos(ItemHelper.limitStand.Unlimit)
			local next_idx 
			for i = 1,#activeArr do
				if activeArr[i].base_id == self.curHeroId then
					next_idx = i-1
				end
			end
			if next_idx < 1 then
				next_idx = #activeArr
			end

			self:changeHero(activeArr[next_idx].base_id)
			-- WindowCtrl:getInstance():open(CmdName.Hero_View,activeArr[next_idx].base_id)
		end
	end)

	--local down_change_btn = self.uiLayer:getWidgetByName("down_change_btn")
    right_arrow:addTouchEventListener(function(sender, eventType )
		if eventType == ComConstTab.TouchEventType.ended then
			--local activeArr = HeroManager:getInstance():getHeroArrByPos(ItemHelper.limitStand.Unlimit)

			local next_idx 
			for i = 1,#activeArr do
				if activeArr[i].base_id == self.curHeroId then
					next_idx = i+1
				end
			end
			if next_idx > #activeArr then
				next_idx = 1
			end
			-- WindowCtrl:getInstance():open(CmdName.Hero_View,activeArr[next_idx].base_id)
			self:changeHero(activeArr[next_idx].base_id)
		end
	end)

	--装备槽按钮的点击响应
	self._onEqmSlotClick = function(sender, eventType)
    	 if eventType == ComConstTab.TouchEventType.ended then
   			local team_pos = TeamManager:getInstance():isHeroInBattle(self.curHeroId)
   			if team_pos == 0 then
   				Alert:show("當前英雄未上陣，不能穿戴裝備哦")
				return 
   			end
    		local slot = sender:getParent()
		 	local location = slot.location
		 	if slot.isLock then 
   				Alert:show( ItemHelper:getTypeName(location) .. "功能暫未開放，敬請期待哦~")
   				return
   			end

		 	if slot.item == nil then
		 		--self:ctrLeftPanel(HeroHelper.leftPanelType.equipListView,location)
		 		if slot:isNeedShowFindEqm() then -- 如果没有任何可穿戴装备，则显示装备掉落引导界面
			 		local equipType = ItemHelper:getEquipTypeWithItemType(slot.location)
		 			if equipType == ItemHelper.equipType.equip then
		 				local params = {}
				 		params.hero_id = self.curHeroId
				 		params.eqm_type = slot.location
				 		params.find_type = ItemHelper.find_type.none_eqm
				 		WindowCtrl:getInstance():open(CmdName.FindEqmView, params)
		 			elseif equipType == ItemHelper.equipType.fashion then
		 				self:ctrLeftPanel(HeroHelper.leftPanelType.fashion)
		 			end
			 	else
			 		self:ctrLeftPanel(HeroHelper.leftPanelType.equipListView,location)
			 	end
			else
				local equipType = ItemHelper:getEquipTypeWithItemType(location)
				if equipType == ItemHelper.equipType.equip then
					self:ctrLeftPanel(HeroHelper.leftPanelType.equipAttrView,{slot.item, location})
				elseif equipType == ItemHelper.equipType.fashion then
					self:ctrLeftPanel(HeroHelper.leftPanelType.fashion,{slot.item, location})
				end
			end
		 end
    end

    self:createSlot(nil)
-------------------------------------------------------------------
	--装备栏下方四个按钮的事件（详细属性+图鉴+升级+技能）
	local function openRelateView( sender, eventType )
		if eventType == ComConstTab.TouchEventType.ended then
			self:ctrLeftPanel(sender:getTag())
		end
	end

	local attrViewBtn = self.uiLayer:getWidgetByName("attr_btn")
	attrViewBtn:setTag(HeroHelper.leftPanelType.roleAttrView)
	attrViewBtn:addTouchEventListener(openRelateView)

	local imgViewBtn = self.uiLayer:getWidgetByName("img_btn")
	imgViewBtn:setTag(HeroHelper.leftPanelType.heroImgView)
	imgViewBtn:addTouchEventListener(openRelateView)

	local upgradeViewBtn = self.uiLayer:getWidgetByName("upgrade_btn")
	upgradeViewBtn:setTag(HeroHelper.leftPanelType.heroUpgradeView)
	upgradeViewBtn:addTouchEventListener(openRelateView)

	self.btnFashion = self.uiLayer:getWidgetByName("btn_fashion")
	self.btnFashion:setTag(HeroHelper.leftPanelType.fashion)
	self.btnFashion:addTouchEventListener(openRelateView)

	upgrade_btn_tips_img = ImageView:create()
    upgrade_btn_tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
    upgradeViewBtn:addChild(upgrade_btn_tips_img)
    upgrade_btn_tips_img:setPosition(ccp(45,20))
    -- upgrade_btn_tips_img:setScale(0.5)
    -- upgrade_btn_tips_img:setVisible(false)

	local skillBtn = self.uiLayer:getWidgetByName("skill_btn")
	skillBtn:setTag(HeroHelper.leftPanelType.skillView)
	skillBtn:addTouchEventListener(openRelateView)

	self._onPlayActList = function(param_tab)
		if self.hero_animation then
			-- if is_play_act_list then
			-- 	cclog("已經在播放動作序列")
			-- 	return
			-- end

			if is_play_act_list then
				cclog("已經在播放動作序列")
				return
			end

			is_play_act_list = true
			cur_action_idx = 1
			action_list = param_tab or stard_act_list

			self.hero_animation:getAnimation():setMovementEventCallFunc(playCallBack)
			self.hero_animation:getAnimation():play(action_list[cur_action_idx][1],-1,-1,0)

			if action_list[cur_action_idx][2] ~= nil then
			 EffectManager:getInstance():playEffect(self.hero_panel,action_list[cur_action_idx][2], nil, 0)
			end

			if action_list[cur_action_idx][3] ~= nil and action_list[cur_action_idx][3] >0 then
			 EffectManager:getInstance():playEffect(self.hero_back_panel,action_list[cur_action_idx][3], nil, 0)
			end
		end
	end

	self._onSkillUpgrade = function(params)
		local skill_idx = self.curHeroInfo:getSkillIdx(params.skill_id)
		local skill_info = self.curHeroInfo.default_skills[skill_idx]
		if skill_info and skill_info.skill_id == params.skill_id then
			local temp_act_one = {}
			table.insert(temp_act_one,string.format("attack0%d",skill_idx))
			local skill_eff_id = HeroManager:getInstance():getHeroSkillEffect(params.skill_id)
			if skill_eff_id then
				table.insert(temp_act_one,skill_eff_id)
			end
			local temp_act_list = {}
			table.insert(temp_act_list,temp_act_one)
			if os.clock() - skill_upgrade_time>1 then
				self._onPlayActList(temp_act_list)
				skill_upgrade_time = os.clock()
			end
		end
		self:updateHeroFc()

	end

	self._onInitTeamInfo = function()

	end

	self._onHeroUpgrade = function(params)
		local temp_act_one = {}
		table.insert(temp_act_one,Helper.ModelActionType.CELEBRATE1)
		local temp_act_two = {}
		table.insert(temp_act_two,Helper.ModelActionType.CELEBRATE2)
		local temp_act_list = {}
		table.insert(temp_act_list,temp_act_one)
		table.insert(temp_act_list,temp_act_two)
		self._onPlayActList(temp_act_list)

		if params then
			self:playHeroUpgradeAnim(params) --播放升阶动画
		end
		self:setUpgradeTipsPoint(self.curHeroId)
	end

	--更新时装皮肤
	self._onUpdateFashionSkin = function(params)
		--刷新形象
		self:setCurCardId(self.curHeroId)
		self:setFashionSlotData(self.curHeroId)
	end

	--战斗助阵变化
	self._onTeamStandByUpdate = function()
		--刷新属性界面显示
		if self.curOpenViewFlag == HeroHelper.leftPanelType.roleAttrView then
			self:ctrLeftPanel(self.curOpenViewFlag,0,false,true)
		end
		--更新战斗力
		self:updateHeroFc()
	end

	--战对技能变化
	self._onTeamSkilUpdate = function(skill_id)
		if skill_id == TeamSkillID.ASSIST or --这几个技能的提升才对英雄战斗力跟属性
			skill_id == TeamSkillID.MAGIC_STRIKE or 
			skill_id == TeamSkillID.STRONG_PHYSIQUE or 
			skill_id == TeamSkillID.STRONG_BONE then
			
			--刷新属性界面显示
			if self.curOpenViewFlag == HeroHelper.leftPanelType.roleAttrView then
				self:ctrLeftPanel(self.curOpenViewFlag,0,false,true)
			end
			--更新战斗力
			self:updateHeroFc()

		end
	end

	--检测装备状态(是否可 替换/升级/穿上 )
	self._onUpdateEqmStatus = function()
		self:findEqm()
	end

	--批量强化成功
	self._onEqmBatchPoweredSucc = function()
		--更新战斗力
			self:updateHeroFc()
	end

	self.hero_back_panel = DisplayUtil.newLayer()
	self.uiLayer:addChild(self.hero_back_panel)
	self.hero_back_panel:setPosition(ccp(650,250))

	self.hero_panel = DisplayUtil.newLayer()
	self.uiLayer:addChild(self.hero_panel)
	self.hero_panel:setPosition(ccp(650,250))

	self.hero_anim_panel = DisplayUtil.newLayer()
	self.uiLayer:addChild(self.hero_anim_panel)
	self.hero_anim_panel:setPosition(ccp(650,250))



	--新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function HeroView:create()
	_instance = HeroView.new()
	return _instance
end

--新手引导动画
function HeroView:showStepAnim(param) 
	if param.target == "hero_eqmgrid" then
        local slot = self.eqmSlotTab[ItemHelper.itemType.Weapon]
        GuideRenderMgr:getInstance():renderMainFlag(slot,param.id,param.target)
    elseif param.target == "hero_exitinfo" then
    	GuideRenderMgr:getInstance():renderMainFlag(self.close_btn,param.id,param.target)
    elseif param.target == "hero_upskill" then
    	local btn = self.uiLayer:getWidgetByName("skill_btn")
    	GuideRenderMgr:getInstance():renderMainFlag(btn,param.id,param.target)
   	elseif param.target == "backpack_ex" then
   		local view = self.leftViewDic:objectForKey(HeroHelper.leftPanelType.equipAttrView)
    	GuideRenderMgr:getInstance():renderMainFlag(view.apply_btn,param.id,param.target)
    end
end

--单个装备信息更新
local function onUpdateSingleEqm(param) 
	-- local hero_info = HeroManager:getInstance():getHeroInfoById(param.hero_id) 

	if param.hero_id ~= _instance.curHeroId then
		return
	end

	local equipType = ItemHelper:getEquipTypeWithItemType(param.location)
	if equipType == ItemHelper.equipType.equip then

		local eqms = HeroManager:getInstance():getBattleHeroEqmList(param.hero_id) 
		local iconSlot = _instance.eqmSlotTab[param.location]
		local equipVo = eqms:getSingleEquip(param.location)
		iconSlot:setItem(equipVo.item)	

		-- cclog("英雄ID%d~~~物品位置%d~~~~強化等級%d",param.hero_id, param.location, equipVo.item.powered_lev)

		--更新是否需要add的标识
		local add_visible = ItemManager:getInstance():findCanExcEqm(_instance.curHeroInfo.pos,param.location,equipVo.item)
		if add_visible == ItemHelper.exc_eqm_status.normal then
			iconSlot:setAddLabelStatus(false)
			iconSlot:setUpImgStatus(false)
		elseif add_visible == ItemHelper.exc_eqm_status.add then
			iconSlot:setAddLabelStatus(true)
			iconSlot:setUpImgStatus(false)
		else
			iconSlot:setAddLabelStatus(false)
			iconSlot:setUpImgStatus(true)
		end

		--通知左侧界面
		_instance:ctrLeftPanel(HeroHelper.leftPanelType.equipAttrView,{equipVo.item, param.location})

		--更新战斗力
		_instance:updateHeroFc()

	elseif equipType == ItemHelper.equipType.fashion then
		
		--更新战斗力
		_instance:updateHeroFc()
	end

	--新手引导事件
	if GuideDataProxy:getInstance().nowMainTutroialEventId == 10106 then
    	Notifier.dispatchCmd(GuideEvent.StepFinish,"click_eqmwear")
    end
	--新手引导保底操作
	if GuideDataProxy:getInstance().nowMainTutroialEventId >= 10100 and 
		GuideDataProxy:getInstance().nowMainTutroialEventId <= 10105 then
		GuideRenderMgr:getInstance():forceFinishEvent()
	end
	if GuideDataProxy:getInstance().nowMainTutroialEventId >= 10601 and 
		GuideDataProxy:getInstance().nowMainTutroialEventId <= 10610 then
		GuideRenderMgr:getInstance():forceFinishEvent()
	end
end

--外部控制左边面板显示的事件
local function onCtrlLeftPanel(param)
	_instance:ctrLeftPanel(param[1],param[2])
end

local function getStarResPath(cur_stars)
	local path = "white_star.png"
	if cur_stars==5 then
		path = "orange_star.png"
	elseif cur_stars==4 then
		path = "purple_star.png"
	elseif cur_stars==3 then
		path = "blue_star.png"
	elseif cur_stars==2 then
		path = "green_star.png"
	end
	return path
end

--更新等级/星级/经验
local function onUpdateHeroInfo(base_id) 
	if _instance.curHeroId ~= base_id then return end

	local hero_info = HeroManager:getInstance():getHeroInfoById(base_id) 
	local lev_label = tolua.cast(_instance.uiLayer:getWidgetByName("lev_label"), "Label")
	lev_label:setText("Lv."..hero_info.cur_lev)
	
	local star_path = getStarResPath(hero_info.cur_stars)
	--设置星级，星星从上到下,一星的不用判断
	local white_star = tolua.cast(_instance.uiLayer:getWidgetByName("white_star"), "ImageView")
	white_star:loadTexture(star_path, UI_TEX_TYPE_PLIST)

	local green_star = tolua.cast(_instance.uiLayer:getWidgetByName("green_star"), "ImageView")
	if hero_info.cur_stars > 1 then
		green_star:loadTexture(star_path, UI_TEX_TYPE_PLIST)
		green_star:setVisible(true)
	else
		green_star:setVisible(false)
	end

	local blue_star = tolua.cast(_instance.uiLayer:getWidgetByName("blue_star"), "ImageView")
	if hero_info.cur_stars > 2 then
		blue_star:loadTexture(star_path, UI_TEX_TYPE_PLIST)
		blue_star:setVisible(true)
	else
		blue_star:setVisible(false)
	end

	local purple_star = tolua.cast(_instance.uiLayer:getWidgetByName("purple_star"), "ImageView")
	if hero_info.cur_stars > 3 then
		purple_star:loadTexture(star_path, UI_TEX_TYPE_PLIST)
		purple_star:setVisible(true)
	else
		purple_star:setVisible(false)
	end

	local orange_star = tolua.cast(_instance.uiLayer:getWidgetByName("orange_star"), "ImageView")
	if hero_info.cur_stars > 4 then
		orange_star:loadTexture(star_path, UI_TEX_TYPE_PLIST)
		orange_star:setVisible(true)
	else
		orange_star:setVisible(false)
	end

	_instance:updateHeroFc()

end

--更新战斗力
 function HeroView:updateHeroFc()
	--更新战斗力
	-- local fight_capacity_label = tolua.cast(_instance.uiLayer:getWidgetByName("fight_capacity_label"),"Label")
	-- fight_capacity_label:setText()
	self.fc_num_img:setStringValue(HeroManager:getInstance():getFightCapacity(_instance.curHeroId))
 end

--根据卡牌信息，设置装备槽的数据
local function setEqmSlotData(hero_id)
	local hero_id = hero_id or _instance.curHeroId
	
	local HeroInfo = HeroManager:getInstance():getHeroInfoById(hero_id)
	if HeroInfo == nil then
		cclog ("不存在的卡牌資訊")
		return
	end	

	local eqms = HeroManager:getInstance():getBattleHeroEqmList(hero_id)
	local eqm_vo = nil
	for location,eqm_slot in pairs(_instance.eqmSlotTab) do
		if eqms then
			eqm_vo = eqms:getSingleEquip(location)
			eqm_slot:setIsBattle(true)
		else
			eqm_vo = nil
			eqm_slot:setIsBattle(false)
		end
		
		if eqm_vo ~= nil then
			eqm_slot:setItem(eqm_vo.item) 	
		else
			eqm_slot:setItem(nil) 	
		end
	end
end

--设置时装 孔 数据
function HeroView:setFashionSlotData(hero_id)
	local hero_id = hero_id or self.curHeroId
	
	local heroInfo = HeroManager:getInstance():getHeroInfoById(hero_id)
	if heroInfo == nil then
		cclog ("不存在的卡牌資訊")
		return
	end	

	local im = ItemManager:getInstance()
	local voList = heroInfo:getFashionCurWearList()
	for location,eqm_slot in pairs(self.fashionSlotTab) do
		if voList[location] ~= nil then
			local item = im.equipItemTab[voList[location].fashionId]
			eqm_slot:setItem(item)
		else
			eqm_slot:setItem(nil) 	
		end
	end
end

local function getPosImgPath(hero_pos)
	return ItemHelper:getHeroPosImgName(hero_pos)
end

--设置卡牌界面上的基本信息，名称、等级、星级等
local function setBaseInfo(hero_id)
	local hero_id = hero_id or _instance.curHeroId
	local name_label = tolua.cast(_instance.uiLayer:getWidgetByName("hero_name_label"), "Label")
	name_label:setText(_instance.curHeroInfo.name) 

	local pos_img =  tolua.cast(_instance.uiLayer:getWidgetByName("hero_pos_img"), "ImageView")
	local pos_img_path = getPosImgPath(_instance.curHeroInfo.pos)
	pos_img:loadTexture(pos_img_path,UI_TEX_TYPE_PLIST)

end

--查看一张新卡牌时，重置界面信息
local function resetViewInfo(hero_id)
	local hero_id = hero_id or _instance.curHeroId
	setEqmSlotData(hero_id)
	setBaseInfo(hero_id)
	onUpdateHeroInfo(hero_id)
end

function HeroView:open()
	Notifier.regist(CmdName.EqmInfoUpdate,onUpdateSingleEqm)
    Notifier.regist(CmdName.CtrlRoleLeftPanel, onCtrlLeftPanel) 
    Notifier.regist(CmdName.UpdateHeroInfo, onUpdateHeroInfo) 
    Notifier.regist(CmdName.HeroSkillUpgradeSuccess, self._onSkillUpgrade) 
    Notifier.regist(CmdName.HeroUpgradeSuccess, self._onHeroUpgrade)
    Notifier.regist(CmdName.UpdateGreenTipsPoint,self._onUpdateEqmStatus)
    Notifier.regist(CmdName.Upadate_Fashion_Skin,self._onUpdateFashionSkin)
    --监听助阵变化
    Notifier.regist(CmdName.TEAM_ADD_HERO_STANDBY, self._onTeamStandByUpdate)
	Notifier.regist(CmdName.TEAM_REMOVE_HERO_STANDBY, self._onTeamStandByUpdate)
	--监听战队技能变化
	 Notifier.regist(CmdName.TEAM_UPGRADE_SKILL_RSP, self._onTeamSkilUpdate)
	 Notifier.regist(CmdName.EqmBatchPoweredSucc,self._onEqmBatchPoweredSucc)
    -- self:setCurCardId(self.params)
	-- resetViewInfo()

	-- if self.curOpenViewFlag == HeroHelper.leftPanelType.roleAttrView or 
	-- 	self.curOpenViewFlag == HeroHelper.leftPanelType.heroImgView or 
	-- 	self.curOpenViewFlag == HeroHelper.leftPanelType.heroUpgradeView or 
	-- 	self.curOpenViewFlag == HeroHelper.leftPanelType.skillView then
	-- 	self:ctrLeftPanel(self.curOpenViewFlag)
	-- else
	-- 	self:ctrLeftPanel(HeroHelper.leftPanelType.heroImgView)
	-- end

	-- --测试，需要优化为用timermanger
	-- self:findEqm() 
	--请求战队信息
	activeArr = HeroManager:getInstance():getHeroArrByPos(ItemHelper.limitStand.Unlimit)
	self:changeHero(self.params)
	local battle_data = TeamManager:getInstance():getBattleData(TeamType.Normal)
    if battle_data == nil then --如果不存在normal竞技信息
    	 Notifier.regist(CmdName.TEAM_INIT_HERO, self._onInitTeamInfo)
         TeamManager:getInstance():reqTeamAllInfo(TeamType.Normal)
         return
    end

    if HeroManager:getInstance():isShowTipsPoint(self.params) then
    	cclog("英雄ID~~%d~~需要顯示綠點~~",self.params)
    else
    	cclog("英雄ID~~%d~~啥都沒有~~",self.params)
    end

    --新手引导
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10404 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"open_heroview")
    end
end

function HeroView:changeHero(hero_id)
	self:setCurCardId(hero_id)
	resetViewInfo()

	if self.curOpenViewFlag == HeroHelper.leftPanelType.roleAttrView or 
		self.curOpenViewFlag == HeroHelper.leftPanelType.heroImgView or 
		self.curOpenViewFlag == HeroHelper.leftPanelType.heroUpgradeView or 
		self.curOpenViewFlag == HeroHelper.leftPanelType.skillView or
		self.curOpenViewFlag == HeroHelper.leftPanelType.fashion then
		self:ctrLeftPanel(self.curOpenViewFlag,0,false,true)
	else
		self:ctrLeftPanel(HeroHelper.leftPanelType.heroImgView,0,false,true)
	end

	--测试，需要优化为用timermanger
	self:findEqm()

	--设置进阶按钮的绿色提示点
	self:setUpgradeTipsPoint(hero_id)
end

--英雄升级动画
function HeroView:playHeroUpgradeAnim(params)
	self.hero_upgrade_anim_path = "ui/effects_ui/yingxiongjinjie/yingxiongjinjie.ExportJson"
	self:clearHeroUpgradAnim()

	self.hero_upgrade_anim = AnimateManager:getInstance():getArmature(self.hero_upgrade_anim_path, "yingxiongjinjie")
	self.hero_upgrade_anim:getAnimation():play("Animation1",0,-1,0)
	self.hero_anim_panel:addChild( self.hero_upgrade_anim )

	local attr = params.attr

	self.animTbl = self.animTbl or {}
	require "ActionManager"
	local hpAnimNode = Widget:create()
	self.labAtlasHp = LabelAtlas:create()
    self.labAtlasHp:setProperty(attr[AttrHelper.attr_flag.hp] or 0,"ui/digit/digit_6.png",15,32,"0")
    self.labAtlasHp:setAnchorPoint(ccp(0,0))
    self.labAtlasHp:setPositionY(-15)
    self.labAtlasHp:setScale(1.4)
    self.labImgHp = ImageView:create()
    self.labImgHp:loadTexture("i18n_hp_add_img.png",UI_TEX_TYPE_PLIST)
    self.labImgHp:setAnchorPoint(ccp(1,0))
    hpAnimNode:addChild(self.labImgHp)
    -- self.labAtlasHp:setPosition( ccp(math.random(-20, 20),math.random(-20, 20)) )
    hpAnimNode:addChild(self.labAtlasHp)
    table.insert(self.animTbl,hpAnimNode)

    local actAnimNode = Widget:create()
    self.labAtlasAct = LabelAtlas:create()
    self.labAtlasAct:setProperty(attr[AttrHelper.attr_flag.atk] or 0,"ui/digit/digit_6.png",15,32,"0")
    self.labAtlasAct:setAnchorPoint(ccp(0,0))
   	self.labAtlasAct:setScale(1.4)
   	self.labAtlasAct:setPositionY(-15)
    self.labImgAct = ImageView:create()
    self.labImgAct:loadTexture("i18n_act_add_img.png",UI_TEX_TYPE_PLIST)
    self.labImgAct:setAnchorPoint(ccp(1,0))
    actAnimNode:addChild(self.labImgAct)
    actAnimNode:addChild(self.labAtlasAct)
    table.insert(self.animTbl,actAnimNode)

    local pdefAnimNode = Widget:create()
    self.labAtlasDef = LabelAtlas:create()
    self.labAtlasDef:setProperty(attr[AttrHelper.attr_flag.pdef] or 0,"ui/digit/digit_6.png",15,32,"0")
    self.labAtlasDef:setAnchorPoint(ccp(0,0))
    self.labAtlasDef:setScale(1.4)
    self.labAtlasDef:setPositionY(-15)
    self.labImgDef = ImageView:create()
    self.labImgDef:loadTexture("i18n_def_add_img.png",UI_TEX_TYPE_PLIST)
    self.labImgDef:setAnchorPoint(ccp(1,0))
    pdefAnimNode:addChild(self.labImgDef)
    pdefAnimNode:addChild(self.labAtlasDef)
    table.insert(self.animTbl,pdefAnimNode)

    local fcAnimNode = Widget:create()
    self.labAtlasFc = LabelAtlas:create()
    self.labAtlasFc:setProperty(HeroManager:getInstance():getFightCapacity(self.curHeroId,TeamType.Normal) or 0,"ui/digit/digit_4.png",24,32,"0")
    self.labAtlasFc:setAnchorPoint(ccp(0,0))
    self.labAtlasFc:setPosition(ccp(5,0))
    self.labAtlasFc:setScale(0.9)
    self.labImgFc = ImageView:create()
    self.labImgFc:loadTexture("i18n_fc_txt_2.png",UI_TEX_TYPE_PLIST)
    self.labImgFc:setAnchorPoint(ccp(1,0))
    self.labImgFc:setScale(0.76)
    fcAnimNode:addChild(self.labImgFc)
    fcAnimNode:addChild(self.labAtlasFc)
    table.insert(self.animTbl,fcAnimNode)

    for i=1,#self.animTbl do
    	self.animTbl[i]:setVisible(false)
    	self.hero_anim_panel:addChild(self.animTbl[i])

    	local delayAction = CCDelayTime:create((i - 1) * 0.4)
    	local showAction = CCShow:create()
		local moveAction = CCMoveBy:create(0.4, ccp(0, 200))
		local zoomInAction = CCScaleTo:create(0.4, 1.4)
		local spawnAction = CCSpawn:createWithTwoActions(moveAction, zoomInAction)
		local easeAction = CCEaseIn:create(spawnAction, 0.2)
		local delayAction2 = CCDelayTime:create(0.4)
		local zoomOutAction = CCScaleTo:create(0.2, 1)
		local callAction = CCCallFuncN:create(function(node)
	    	node:removeFromParentAndCleanup(true)
	    end)
	    ActionManager:getInstance():runSequenceActions(
	    	self.animTbl[i], 
	    	delayAction, 
	    	showAction,
	    	easeAction, 
	    	delayAction2,
	    	zoomOutAction, 
	    	callAction
	    )
    end
end

function HeroView:clearHeroUpgradAnim()
	if self.hero_upgrade_anim ~= nil then
		self.hero_upgrade_anim:getAnimation():stop()
		self.hero_upgrade_anim:getAnimation():setMovementEventCallFunc(function() end)
		self.hero_upgrade_anim:removeFromParentAndCleanup(true)
		self.hero_upgrade_anim = nil
		AnimateManager:getInstance():clear(self.hero_upgrade_anim_path)
	end

	self.hero_anim_panel:removeAllChildrenWithCleanup(true)   
	self.animTbl = {}
end

function HeroView:close()

	self:ctrLeftPanel(self.curOpenViewFlag,nil,true) --关闭已经打开的界面

	if self.hero_animation then
		self.hero_animation:getAnimation():stop()
		self.hero_animation:getAnimation():setMovementEventCallFunc(function() end)
		self.hero_animation:removeFromParentAndCleanup(true)
		self.hero_animation = nil
		AnimateManager:getInstance():clear(hero_anim_path)
	end
	self:clearHeroUpgradAnim()
	--停止装备槽的附魔特效
	for location,eqm_slot in pairs(_instance.eqmSlotTab) do
		eqm_slot:setItem(nil) 	
	end

	if self.cur_part_view then
		self.cur_part_view:stopAllActions()
		self.cur_part_view:close()
	end
	
	if upgrade_btn_tips_img then
		upgrade_btn_tips_img:stopAllActions()
	end

	TimerManager.removeTimer(self._onPlayActList) --移除动作序列定时器
	-- self:ctrLeftPanel(self.curOpenViewFlag,nil,true) --关闭已经打开的界面
	Notifier.remove(CmdName.EqmInfoUpdate,onUpdateSingleEqm)
    Notifier.remove(CmdName.CtrlRoleLeftPanel, onCtrlLeftPanel)
    Notifier.remove(CmdName.UpdateHeroInfo, onUpdateHeroInfo) 
    Notifier.remove(CmdName.HeroSkillUpgradeSuccess, self._onSkillUpgrade) 
    Notifier.remove(CmdName.TEAM_INIT_HERO, self._onInitTeamInfo)
    Notifier.remove(CmdName.EqmPoweredSuccess,self._onEqmPoweredSuc) 
    Notifier.remove(CmdName.TEAM_ADD_HERO_STANDBY, self._onTeamStandByUpdate)
	Notifier.remove(CmdName.TEAM_REMOVE_HERO_STANDBY, self._onTeamStandByUpdate)
	Notifier.remove(CmdName.TEAM_UPGRADE_SKILL_RSP, self._onTeamSkilUpdate)
	Notifier.remove(CmdName.UpdateGreenTipsPoint,self._onUpdateEqmStatus)
	 Notifier.remove(CmdName.EqmBatchPoweredSucc,self._onEqmBatchPoweredSucc)
	 Notifier.remove(CmdName.Upadate_Fashion_Skin,self._onUpdateFashionSkin)
    activeArr = nil

    --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10107 or
    	GuideDataProxy:getInstance().nowMainTutroialEventId == 10612 then
    	Notifier.dispatchCmd(GuideEvent.StepFinish,"exit_heroinfo")
	end
end

function HeroView:setUpgradeTipsPoint(hero_id)
	local is_visible = HeroManager:getInstance():isHeroCanUpgrade(hero_id)
	upgrade_btn_tips_img:setVisible(is_visible)
	if is_visible then
		self:tipsPointPlayAct(upgrade_btn_tips_img)
	else
		upgrade_btn_tips_img:stopAllActions()
	end
	-- upgrade_btn_tips_img:setVisible(true)
end

--寻找是否有可以更换掉的装备
function HeroView:findEqm()
	local item_arr = nil
	local exc_value = 0
	for location, eqm_icon in pairs(self.eqmSlotTab) do
		exc_value = ItemManager:getInstance():findCanExcEqm(self.curHeroInfo.pos,location,eqm_icon.item)
		if exc_value == ItemHelper.exc_eqm_status.normal or
			eqm_icon.is_battle == false then
			eqm_icon:setAddLabelStatus(false)
			eqm_icon:setUpImgStatus(false)
			--装备可以升级
			if ItemManager:getInstance():isCanEqmUpgrade(eqm_icon.item) then
				eqm_icon:setUpImgStatus(true,false)
			end

		elseif exc_value == ItemHelper.exc_eqm_status.add then
			eqm_icon:setAddLabelStatus(true)
			eqm_icon:setUpImgStatus(false)
		else
			eqm_icon:setAddLabelStatus(false)
			eqm_icon:setUpImgStatus(true)
		end
	end
end

-- --寻找是否可以升级装备
-- function HeroView:checkEqmUpgrade()
-- 	for location, eqm_icon in pairs(self.eqmSlotTab) do
-- 		local ret = ItemManager:getInstance():isCanEqmUpgrade(eqm_icon.item)
-- 		eqm_icon:setUpImgStatus(ret)
-- 	end
-- end

--进入英雄界面后才开始加载
local function delayLoadHeroAnim()
    local action_data = EffectManager:getInstance():getActionData(_instance.curHeroInfo:getModelId())
    cclog("英雄骨骼動畫路徑~~~~%s",action_data._fileFullPathName)
	hero_anim_path = action_data._fileFullPathName
	_instance.hero_animation = AnimateManager:getInstance():getArmature(action_data._fileFullPathName, action_data._fileName)
	_instance.hero_panel:addChild(_instance.hero_animation)
	_instance.hero_animation:getAnimation():play("stand")
	-- self.hero_animation:setPosition(ccp(650,250))
	_instance.hero_animation:setScale(1.3)

	TimerManager.addTimer(5000, _instance._onPlayActList)
end

function HeroView:setCurCardId(card_id)
	self.curHeroId = card_id
    -- self.curHeroInfo = cardMgr:getHeroInfoByBaseId(self.curHeroId)
    self.curHeroInfo= cardMgr:getHeroInfoByBaseId(self.curHeroId)

    -- action_list = cardMgr:getHeroActListById(self.curHeroId)
    stard_act_list = cardMgr:getHeroActListById(self.curHeroId)
    is_play_act_list = false
    
    --显示英雄模型 
   	TimerManager.removeTimer(delayLoadHeroAnim) --移除动作序列定时器
   	
    --移除技能特效
    if action_list and  action_list[cur_action_idx] and 
		action_list[cur_action_idx][2] ~= nil then
			EffectManager:getInstance():removeEffect(self.hero_panel,action_list[cur_action_idx][2], nil, 0)
	end

	if action_list and  action_list[cur_action_idx] and 
		action_list[cur_action_idx][3] ~= nil and
		action_list[cur_action_idx][3]>0 then
			EffectManager:getInstance():removeEffect(self.hero_back_panel,action_list[cur_action_idx][3], nil, 0)
	end
	
    if self.hero_animation then
    	self.hero_animation:getAnimation():stop()
    	self.hero_animation:getAnimation():setMovementEventCallFunc(function() end)
    	self.hero_animation:removeFromParentAndCleanup(true)
    	self.hero_animation = nil
    	TimerManager.removeTimer(self._onPlayActList) --移除动作序列定时器
    	AnimateManager:getInstance():clear(hero_anim_path)
    	-- ComResMgr:getInstance():clearCache()
    	TimerManager.addTimer(200, delayLoadHeroAnim)
    else
    	TimerManager.addTimer(200, delayLoadHeroAnim)
    end

    self:clearHeroUpgradAnim()
 
end

function HeroView:extTouchPriority(value)
	
end

local is_child_panel_action = false --是否正在执行显示的action，是的话不响应其它
local move_x = 300
local def_left_x = {}
--控制左边面板的显示/隐藏
function HeroView:ctrLeftPanel(openPanelType,param,just_close,is_show)

	if openPanelType<=0 then
		return
	end

	--首次打开，创建相应界面
	-- local cur_view = nil
	if self.leftViewDic:objectForKey(openPanelType) == nil then

		if openPanelType == HeroHelper.leftPanelType.roleAttrView then 
			self.leftViewDic:setObject(AttrView:create(),openPanelType)
		elseif openPanelType == HeroHelper.leftPanelType.heroImgView then
			local heroImgView = HeroImgView:create()
			heroImgView:setPositionY(heroImgView:getPositionY()+5)
			heroImgView:setClickHandler(function(pSender,eventType) self:onClickHeroImgView(pSender,eventType) end)
			self.leftViewDic:setObject(heroImgView,openPanelType)

		elseif openPanelType == HeroHelper.leftPanelType.heroUpgradeView then
			self.leftViewDic:setObject(HeroUpgradeView:create(),openPanelType)

		elseif openPanelType == HeroHelper.leftPanelType.skillView then
			self.leftViewDic:setObject(SkillView:create(),openPanelType)
			
		elseif openPanelType == HeroHelper.leftPanelType.equipListView then
			self.leftViewDic:setObject(EquipListView:create(),openPanelType)

		elseif openPanelType == HeroHelper.leftPanelType.equipAttrView then
			self.leftViewDic:setObject(ItemInfoView:create(1),openPanelType)
		elseif openPanelType == HeroHelper.leftPanelType.fashion then
			self.leftViewDic:setObject(FashionListView:create(),openPanelType)
		end
		self.cur_part_view = self.leftViewDic:objectForKey(openPanelType)
		def_left_x[openPanelType] = self.cur_part_view:getPositionX()
	end

	 self.cur_part_view = self.leftViewDic:objectForKey(openPanelType)
	 self:showEquipLayout(openPanelType)
	 --新手引导事件
	if openPanelType == HeroHelper.leftPanelType.equipAttrView then
		if GuideDataProxy:getInstance().nowMainTutroialEventId == 10608 then
			Notifier.dispatchCmd(GuideEvent.StepFinish,"click_eqmgrid")
		end
	end

	if self.curOpenViewFlag > 0 then --关闭当前已经打开的界面
		local old_win = self.leftViewDic:objectForKey(self.curOpenViewFlag)
		old_win:stopAllActions()
		old_win:close()
		old_win:removeFromParentAndCleanup(true)
	end

	if self.curOpenViewFlag == openPanelType and 
		(openPanelType ~= HeroHelper.leftPanelType.equipListView and
		openPanelType ~= HeroHelper.leftPanelType.equipAttrView and
		openPanelType ~= HeroHelper.leftPanelType.fashion) or
		just_close == true  then
			if is_show ~= true then
				self.curOpenViewFlag = 0
				return
			end
	end

	move_x = def_left_x[openPanelType]+300
	self.cur_part_view:setPositionX(move_x)
	self.cur_part_view:open()
	self.down_layout:addChild(self.cur_part_view)
	self.curOpenViewFlag = openPanelType

	if openPanelType == HeroHelper.leftPanelType.equipListView then
		self.cur_part_view:setData(self.curHeroId,param,self.curHeroInfo.pos)
		self.cur_part_view:refreshData()
	elseif openPanelType == HeroHelper.leftPanelType.equipAttrView then
		self.cur_part_view:setItemData(param[1])
	elseif openPanelType == HeroHelper.leftPanelType.roleAttrView then
		self.cur_part_view:changeContent(self.curHeroId)
	elseif openPanelType == HeroHelper.leftPanelType.skillView then
		self.cur_part_view:setData(self.curHeroId)
	elseif openPanelType == HeroHelper.leftPanelType.heroImgView then
		self.cur_part_view:setData(self.curHeroId)	
	elseif openPanelType == HeroHelper.leftPanelType.heroUpgradeView then
		self.cur_part_view:setData(self.curHeroId)	
	elseif openPanelType == HeroHelper.leftPanelType.fashion then 
		self.cur_part_view:setData(self.curHeroId,ItemHelper.itemType.fashion_skin)
		self.cur_part_view:refreshData()
	end

	self.cur_part_view:runAction(CCMoveBy:create(0.1, ccp(-300, 0)))
end

function HeroView:showEquipLayout(openPanelType)
	self.panelEqm:setZOrder(0)
	self.panelEqm:setVisible(false)
	self.panelFashion:setZOrder(0)
	self.panelFashion:setVisible(false)

	self:createSlot(openPanelType)

	if openPanelType == HeroHelper.leftPanelType.fashion then
		self.panelFashion:setZOrder(2)
		self.panelFashion:setVisible(true)

		self:setFashionSlotData(self.curHeroId)

		-- self.curEquipLayout = ItemHelper.equipType.fashion
	else
		self.panelEqm:setZOrder(2)
		self.panelEqm:setVisible(true)

		-- self.curEquipLayout = ItemHelper.equipType.equip
	end
end

function HeroView:createSlot(openPanelType)
	if openPanelType == HeroHelper.leftPanelType.fashion then

		if self.fashionSlot == nil then
			self.fashionSlot = EquipIcon:create()
			self.fashionSlot:extInit(ItemHelper.itemType.fashion_skin)
			self.fashionSlot:setTouchEvent(self._onEqmSlotClick)
			self.fashionSlot:setPosition(posArr[ItemHelper.itemType.Weapon])
			self.panelFashion:addChild(self.fashionSlot)
			self.fashionSlotTab[ItemHelper.itemType.fashion_skin] = self.fashionSlot
		end
		if self.miracleSlot == nil then
			self.miracleSlot = EquipIcon:create()
			self.miracleSlot:extInit(ItemHelper.itemType.miracle)
			self.miracleSlot:setTouchEvent(self._onEqmSlotClick)
			self.miracleSlot:setPosition(posArr[ItemHelper.itemType.Clothes])
			self.panelFashion:addChild(self.miracleSlot)
			self.miracleSlot:setLock(true)
			self.fashionSlotTab[ItemHelper.itemType.miracle] = self.miracleSlot
		end
	else
		--装备栏位置
		if self.weaponSlot == nil then
			self.weaponSlot = EquipIcon:create()
			self.weaponSlot:extInit(ItemHelper.itemType.Weapon)
			self.weaponSlot:setTouchEvent(self._onEqmSlotClick)
			self.weaponSlot:setPosition(posArr[ItemHelper.itemType.Weapon])
			self.panelEqm:addChild(self.weaponSlot)
			self.eqmSlotTab[ItemHelper.itemType.Weapon] = self.weaponSlot
		end
		
		if self.clothesSlot == nil then
			self.clothesSlot = EquipIcon:create()
			self.clothesSlot:extInit(ItemHelper.itemType.Clothes)
			self.clothesSlot:setTouchEvent(self._onEqmSlotClick)
			self.clothesSlot:setPosition(posArr[ItemHelper.itemType.Clothes])
			self.panelEqm:addChild(self.clothesSlot)
			self.eqmSlotTab[ItemHelper.itemType.Clothes] = self.clothesSlot
		end
		
		if self.trousersSlot == nil then
			self.trousersSlot = EquipIcon:create()
			self.trousersSlot:extInit(ItemHelper.itemType.Trousers)
			self.trousersSlot:setTouchEvent(self._onEqmSlotClick)
			self.trousersSlot:setPosition(posArr[ItemHelper.itemType.Trousers])
			self.panelEqm:addChild(self.trousersSlot)
			self.eqmSlotTab[ItemHelper.itemType.Trousers] = self.trousersSlot
		end
		
		if self.shoesSlot == nil then
			self.shoesSlot = EquipIcon:create()
			self.shoesSlot:extInit(ItemHelper.itemType.Shoes)
			self.shoesSlot:setTouchEvent(self._onEqmSlotClick)
			self.shoesSlot:setPosition(posArr[ItemHelper.itemType.Shoes])
			self.panelEqm:addChild(self.shoesSlot)
			self.eqmSlotTab[ItemHelper.itemType.Shoes] = self.shoesSlot
		end

		if self.ringSlot == nil then
			self.ringSlot = EquipIcon:create()
			self.ringSlot:extInit(ItemHelper.itemType.Ring)
			self.ringSlot:setTouchEvent(self._onEqmSlotClick)
			self.ringSlot:setPosition(posArr[ItemHelper.itemType.Ring])
			self.panelEqm:addChild(self.ringSlot)
			self.eqmSlotTab[ItemHelper.itemType.Ring] = self.ringSlot
		end
		
		if self.jewelrySlot == nil then
			self.jewelrySlot = EquipIcon:create()
			self.jewelrySlot:extInit(ItemHelper.itemType.Jewelry)
			self.jewelrySlot:setTouchEvent(self._onEqmSlotClick)
			self.jewelrySlot:setPosition(posArr[ItemHelper.itemType.Jewelry])
			self.panelEqm:addChild(self.jewelrySlot)
			self.eqmSlotTab[ItemHelper.itemType.Jewelry] = self.jewelrySlot
		end
		
		if self.amuletSlot == nil then
			self.amuletSlot = EquipIcon:create()
			self.amuletSlot:extInit(ItemHelper.itemType.Amulet)
			self.amuletSlot:setTouchEvent(self._onEqmSlotClick)
			self.amuletSlot:setPosition(posArr[ItemHelper.itemType.Amulet])
			self.panelEqm:addChild(self.amuletSlot)
			self.eqmSlotTab[ItemHelper.itemType.Amulet] = self.amuletSlot
		end

		if self.necklaceSlot == nil then
			self.necklaceSlot = EquipIcon:create()
			self.necklaceSlot:extInit(ItemHelper.itemType.Necklace)
			self.necklaceSlot:setTouchEvent(self._onEqmSlotClick)
			self.necklaceSlot:setPosition(posArr[ItemHelper.itemType.Necklace])
			self.panelEqm:addChild(self.necklaceSlot)
			self.eqmSlotTab[ItemHelper.itemType.Necklace] = self.necklaceSlot
		end
	end
end

function HeroView:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

--处理点击卡牌
function HeroView:onClickHeroImgView(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		WindowCtrl:getInstance():open(CmdName.HeroFullCardAnimPanel,{hero_id = self.curHeroId})
	end
end