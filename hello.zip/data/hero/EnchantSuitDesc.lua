--附魔套 描述面板
EnchantSuitDesc = class("EnchantSuitDesc",WindowBase)
EnchantSuitDesc.__index = EnchantSuitDesc
EnchantSuitDesc._widget     = nil
EnchantSuitDesc.uiLayer    = nil
EnchantSuitDesc.is_dispose = true

local __instance = nil

function EnchantSuitDesc:create()
    local ret = EnchantSuitDesc.new()
    __instance = ret
    return ret   
end

function EnchantSuitDesc:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end

function EnchantSuitDesc:init()
	ComResMgr:getInstance():loadResByName("ui/hero/hero.plist","ui/hero/hero.pvr.ccz")
	--加载纹理
    ComResMgr:getInstance():loadOtherRes()
	require "ItemIcon"
	require "ItemInfoPanel"

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/equip/enchant_suit_desc/enchant_suit_desc.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

	self._widget:setTouchEnabled(true)
    self._widget:setSize(CCSize(960,640))
    self._widget:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    for i=1,6 do
    	self["img_attr"..i] = tolua.cast(self.uiLayer:getWidgetByName("img_attr"..i),"ImageView")
    	self["lab_attr"..i] = tolua.cast(self.uiLayer:getWidgetByName("lab_attr"..i),"Label")
    	self["lab_attr_v"..i] = tolua.cast(self.uiLayer:getWidgetByName("lab_attr_v"..i),"Label")
    	self["img_after_attr"..i] = tolua.cast(self.uiLayer:getWidgetByName("img_after_attr"..i),"ImageView")
    	self["lab_after_attr"..i] = tolua.cast(self.uiLayer:getWidgetByName("lab_after_attr"..i),"Label")
    	self["lab_after_attr_v"..i] = tolua.cast(self.uiLayer:getWidgetByName("lab_after_attr_v"..i),"Label")
    end

    self.labProg = tolua.cast(self.uiLayer:getWidgetByName("lab_prog"),"Label")
    self.progBar = tolua.cast(self.uiLayer:getWidgetByName("prog_bar"),"LoadingBar")
    self.labProgDesc = tolua.cast(self.uiLayer:getWidgetByName("lab_prog_desc"),"Label")
    self.labCur = tolua.cast(self.uiLayer:getWidgetByName("lab_cur"),"Label")
    self.labNext = tolua.cast(self.uiLayer:getWidgetByName("lab_next"),"Label")
    self.labTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips"),"Label")
    self.labCurTips = tolua.cast(self.uiLayer:getWidgetByName("lab_cur_tips"),"Label")
    self.panelNext = tolua.cast(self.uiLayer:getWidgetByName("panel_next"),"Layout")
    self.panelCur = tolua.cast(self.uiLayer:getWidgetByName("panel_cur"),"Layout")
    self.labTips2 = tolua.cast(self.uiLayer:getWidgetByName("lab_tips2"),"Label")
end

function EnchantSuitDesc:open()

	self.equipListVo = self.params["equipListVo"]
	local lv,prog = self.equipListVo:getEnchantSuitLv()
	self.labCur:setText(string.format("%d星附魔套",lv))
	self.labNext:setText(string.format("%d星附魔套",lv + 1))

	for i=1,6 do
    	self["img_attr"..i]:setVisible(false)
    	self["lab_attr"..i]:setVisible(false)
    	self["lab_attr_v"..i]:setVisible(false)
    	self["img_after_attr"..i]:setVisible(false)
    	self["lab_after_attr"..i]:setVisible(false)
    	self["lab_after_attr_v"..i]:setVisible(false)
    end
    self.labTips:setVisible(false)
    self.labCurTips:setVisible(false)

    self.labProg:setText(string.format("%d/%d",prog,HeroManager.TOTAL_ENCHANT_COUNT))
    self.progBar:setPercent(prog/HeroManager.TOTAL_ENCHANT_COUNT*100)

	local i = 0
	local attr = ItemManager:getInstance():getEnchantSuitAttr(lv)
	if attr then
		print("i ",i)
		for k,v in pairs(attr) do
			i = i + 1
			self["img_attr"..i]:setVisible(true)
			self["lab_attr"..i]:setVisible(true)
			self["lab_attr_v"..i]:setVisible(true)
			self["img_attr"..i]:loadTexture(string.format("%s.png",AttrHelper:getAttrImgName(k)),UI_TEX_TYPE_PLIST)
			self["lab_attr"..i]:setText(AttrHelper:getAttrNameByFlag(k))
			self["lab_attr_v"..i]:setText(v)
		end
	end

	if lv >= HeroManager.MIN_ENCHANT_LV_FOR_SUIT and lv < HeroManager.MAX_ENCHANT_LV_FOR_SUIT then
		i = 0
		attr = ItemManager:getInstance():getEnchantSuitAttr(lv + 1)
		if attr then
			for k,v in pairs(attr) do
				i = i + 1
				self["img_after_attr"..i]:setVisible(true)
				self["lab_after_attr"..i]:setVisible(true)
				self["lab_after_attr_v"..i]:setVisible(true)
				self["img_after_attr"..i]:loadTexture(string.format("%s.png",AttrHelper:getAttrImgName(k)),UI_TEX_TYPE_PLIST)
				self["lab_after_attr"..i]:setText(AttrHelper:getAttrNameByFlag(k))
				self["lab_after_attr_v"..i]:setText(v)
			end
		end

		self.labProgDesc:setText(string.format("%d星附魔",lv + 1))

	elseif lv < HeroManager.MIN_ENCHANT_LV_FOR_SUIT then
		self.panelCur:setVisible(false)
		self.labCurTips:setVisible(true)
		self.labTips2:setVisible(true)
		self.labProgDesc:setText(string.format("%d星附魔",HeroManager.MIN_ENCHANT_LV_FOR_SUIT))
		self.labNext:setText(string.format("%d星附魔套",HeroManager.MIN_ENCHANT_LV_FOR_SUIT))
		i = 0
		attr = ItemManager:getInstance():getEnchantSuitAttr(HeroManager.MIN_ENCHANT_LV_FOR_SUIT)
		if attr then
			for k,v in pairs(attr) do
				i = i + 1
				self["img_after_attr"..i]:setVisible(true)
				self["lab_after_attr"..i]:setVisible(true)
				self["lab_after_attr_v"..i]:setVisible(true)
				self["img_after_attr"..i]:loadTexture(string.format("%s.png",AttrHelper:getAttrImgName(k)),UI_TEX_TYPE_PLIST)
				self["lab_after_attr"..i]:setText(AttrHelper:getAttrNameByFlag(k))
				self["lab_after_attr_v"..i]:setText(v)
			end
		end

	elseif lv >= HeroManager.MAX_ENCHANT_LV_FOR_SUIT then
		self.panelNext:setVisible(false)
		self.labTips:setVisible(true)
		self.progBar:setPercent(100)
		self.labProg:setText(string.format("%d/%d",HeroManager.TOTAL_ENCHANT_COUNT,HeroManager.TOTAL_ENCHANT_COUNT))
	end
end