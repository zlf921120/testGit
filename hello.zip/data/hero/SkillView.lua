--
-- Author: lvgansheng
-- Date: 2014-06-18 17:41:30
-- 卡牌技能界面

SkillView =  class("SkillView", WidgetBase)
SkillView.uiLayer = nil
SkillView.widget = nil
SkillView.act_skill_items = nil 
SkillView.pas_skill_items = nil
SkillView.tips_view = nil
SkillView.success_animation = nil

local success_animate_path = "ui/hero/hero_skill/skill_upgrade/jinengshengji.ExportJson"

function SkillView:init()
    require("SkillItem")
    require("WidgetBase")
    require("SkillTipsView")

    self:setPositionX(40)

    self.act_skill_items = {}
    self.pas_skill_items = {}

	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/hero_skill/hero_skill.ExportJson")
    self:addChild(self.widget)

    self.tips_view = SkillTipsView:create()
    self.tips_view:retain()

    self.list_view = tolua.cast(self.widget:getChildByName("skill_list_view"), "ListView")
    -- self.list_view:setClippingToBounds(false)

    self.old_pos_y = 0
    self.sc_diff = 0
    self.list_view:addEventListenerScrollView(function(sender,event_type)
        -- if event_type == ComConstTab.ScrollViewEventType.scroll_scrolling then
            
            self.sc_diff = self.list_view:getInnerContainer():getPositionY() - self.old_pos_y
         
            
            if self.tips_view and self.tips_view:getParent() and 
                (self.sc_diff>10 or self.sc_diff<-10)then
                self.tips_view:removeFromParentAndCleanup(true)
            end
        -- end

        -- cclog("self.list_view~~~~%s",event_type)
    end)

    self.list_view:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            if self.tips_view and self.tips_view:getParent() then
                self.tips_view:removeFromParentAndCleanup(true)
                cclog(" if event_type == ComConstTab.TouchEventType.ended then")
            end
        end
    end)

    -- self.list_view:setItemsMargin(20)
    --主动技能分割线
    local act_skill_txt_img = self.widget:getChildByName("act_skill_div_line")
    act_skill_txt_img:removeFromParentAndCleanup(true)
    local act_txt_layout = Layout:create()
    act_txt_layout:setSize(CCSize(295,50))
    act_txt_layout:addChild(act_skill_txt_img)
    act_skill_txt_img:setPositionY(30)
    act_skill_txt_img:setPositionX(act_skill_txt_img:getPositionX()-30)
    self.list_view:pushBackCustomItem(act_txt_layout)

    for i =1,3 do
        local skill_item = SkillItem:create()
        self.act_skill_items[i] = skill_item
        self.list_view:pushBackCustomItem(skill_item)
        skill_item:addTouchEventListener(function(sender,event_type)
            if event_type == ComConstTab.TouchEventType.began then
                local skill_vo = sender.skill_data
                if skill_vo then
                    -- Alert:show(skill_vo:getDesc())
                     self.old_pos_y = self.list_view:getInnerContainer():getPositionY()
                     self.tips_view:removeFromParentAndCleanup(true)
                     self.tips_view:setTips(skill_vo:getDesc())
                     local temp_af = sender:nodeToWorldTransform()
                     self.tips_view:setPosition(ccp(temp_af.tx+400,temp_af.ty+50))
                     GameLayerMgr:getInstance():getMsgLayer():addChild(self.tips_view)
                else
                    Alert:show("未學習當前技能")
                end
            elseif event_type == ComConstTab.TouchEventType.ended then
                 self.tips_view:removeFromParentAndCleanup(true)
            end
        end)
    end 

    --被动技能分割线
    local pas_skill_txt_img = self.widget:getChildByName("pas_skill_div_line")
    pas_skill_txt_img:removeFromParentAndCleanup(true)
    local pas_txt_layout = Layout:create()
    pas_txt_layout:setSize(CCSize(295,50))
    pas_txt_layout:addChild(pas_skill_txt_img)
    pas_skill_txt_img:setPositionY(38)
    pas_skill_txt_img:setPositionX(pas_skill_txt_img:getPositionX()-30)
    self.list_view:pushBackCustomItem(pas_txt_layout)

    for i =1,3 do
    	local skill_item = SkillItem:create()
        self.pas_skill_items[i] = skill_item
    	self.list_view:pushBackCustomItem(skill_item)
        skill_item:addTouchEventListener(function(sender,event_type)
            if event_type == ComConstTab.TouchEventType.began then
                local skill_vo = sender.skill_data
                if skill_vo then
                    self.old_pos_y = self.list_view:getInnerContainer():getPositionY()
                     self.tips_view:removeFromParentAndCleanup(true)
                     self.tips_view:setTips(skill_vo:getDesc())
                     local temp_af = sender:nodeToWorldTransform()
                     self.tips_view:setPosition(ccp(temp_af.tx+400,temp_af.ty+50))
                     GameLayerMgr:getInstance():getMsgLayer():addChild(self.tips_view)

                else
                    Alert:show("未學習當前技能")
                end
            elseif event_type == ComConstTab.TouchEventType.ended then
                self.tips_view:removeFromParentAndCleanup(true)  
            end
        end)
    end

    local skill_point_btn = self.widget:getChildByName("skill_point_btn")
    skill_point_btn:addTouchEventListener(function( sender,event_type )
        if event_type == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.GetSkillPointView)
        end 
    end)

    self._onSkillUpgrade = function(params)
    	if params.hero_id ~=  self.hero_id then
            return 
        end
        
        self:setData(params.hero_id)
        --播放升级特效
        if self.success_animation == nil then
            self.success_animation = AnimateManager:getInstance():getArmature(success_animate_path,"jinengshengji") 
            self.success_animation:setPosition(ccp(63,71))
            self.success_animation:retain()
        end
 
        if self.success_animation:getParent() then
        	cclog("已經在播放升級特效")
        	return
        end
        
        self.success_animation:getAnimation():setMovementEventCallFunc(self._onPlayCallBack )
        self.success_animation:removeFromParentAndCleanup(true)
        local skill_item = self:getSkillItemById(params.skill_id)
        skill_item:addNode(self.success_animation)
        self.success_animation:getAnimation():playWithIndex(0,-1,-1,0)
    end

    self._onPlayCallBack = function( armature, movementType, movementID )
        if movementType == AnimationMovementType.COMPLETE then
            self.success_animation:getAnimation():stop()
            self.success_animation:getAnimation():setMovementEventCallFunc(function() end)
            self.success_animation:removeFromParentAndCleanup(true)
        end
    end

    local skill_point_label = tolua.cast(self.widget:getChildByName("skill_point_label"), "Label") 
    skill_point_label:setText(CharacterManager:getInstance():getAssetData():getSkillPoint())
    --角色资产更新，更新技能点
    self._onRoleAssetUpdate = function()
        skill_point_label:setText(CharacterManager:getInstance():getAssetData():getSkillPoint())
    end

    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function SkillView:showStepAnim(param)
    if param.target == "hero_skillitem" then
        GuideRenderMgr:getInstance():renderMainFlag(self.act_skill_items[1],param.id,param.target)
    end
end

--移除并销毁技能升级成功时的动画
function SkillView:disposeSucAnim()
    if self.success_animation then
        self.success_animation:release()
        self.success_animation:getAnimation():stop()
        self.success_animation:getAnimation():setMovementEventCallFunc(function() end)
        self.success_animation:removeFromParentAndCleanup(true)
        self.success_animation = nil
        AnimateManager:getInstance():clear(success_animate_path)
    end
end

function SkillView:create()
	local skill_view = SkillView.new()
	skill_view:init()
	return skill_view	
end

function SkillView:setData(hero_id)
    self.hero_id = hero_id
    local skill_item
    local hero_info = HeroManager:getInstance():getHeroInfoByBaseId(hero_id)
    local default_skills = hero_info.default_skills
    local pas_skills = hero_info.pas_skills

    for i =1,3 do
        skill_item = self.act_skill_items[i]
        skill_item:setSkillInfo(hero_id,default_skills[i])
        skill_item:showSkillFlag(i)
    end 

    for j =1,3 do
        skill_item = self.pas_skill_items[j]
        skill_item:setSkillInfo(hero_id,pas_skills[j])
    end 
end

function SkillView:open()
     Notifier.regist(CmdName.HeroSkillUpgradeSuccess,self._onSkillUpgrade) 
     Notifier.regist(CmdName.RSP_UPDATE_ROLE_ASSET,self._onRoleAssetUpdate)
     self._onRoleAssetUpdate()

    --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10405 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"click_heroskill")
    end
end

function SkillView:close()
     --移除监听
    Notifier.remove(CmdName.HeroSkillUpgradeSuccess,self._onSkillUpgrade)
    Notifier.remove(CmdName.RSP_UPDATE_ROLE_ASSET,self._onRoleAssetUpdate)
    self:disposeSucAnim()

    if self.tips_view and self.tips_view:getParent() then
                self.tips_view:removeFromParentAndCleanup(true)
    end
end

function SkillView:getSkillItemById( skill_id )
    local skill_item = nil
    local hero_info = HeroManager:getInstance():getHeroInfoByBaseId(self.hero_id)
   
    for i =1,3 do
        skill_item = self.act_skill_items[i]
        if skill_item.skill_info.skill_id == skill_id then
            return skill_item
        end
    end 

    for j =1,3 do
        skill_item = self.pas_skill_items[j]
        if skill_item.skill_info.skill_id == skill_id then
            return skill_item
        end
    end 
end

