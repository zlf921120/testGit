--时装进阶 面板
FashionUpgradePanel = class("FashionUpgradePanel",WindowBase)
FashionUpgradePanel.__index = FashionUpgradePanel
FashionUpgradePanel._widget     = nil
FashionUpgradePanel.uiLayer    = nil
FashionUpgradePanel.is_dispose = true

local __instance = nil

function FashionUpgradePanel:create()
    local ret = FashionUpgradePanel.new()
    __instance = ret
    return ret   
end

function FashionUpgradePanel:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end

    Notifier.removeByName(CmdName.Update_Fashion_Upgrade)
    Notifier.removeByName(CmdName.Update_Fashion_Star)
end

function FashionUpgradePanel:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/fashion_upgrade/fashion_upgrade.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

	self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
	self.btnClose:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then
			self:addCloseAnim()
		end
	end)

	for i=1,10 do
		self[string.format("lab_attr%d_before",i)] = tolua.cast(self.uiLayer:getWidgetByName(string.format("lab_attr%d_before",i)),"Label")
		self[string.format("lab_attr%d_v_before",i)] = tolua.cast(self.uiLayer:getWidgetByName(string.format("lab_attr%d_v_before",i)),"Label")
		self[string.format("lab_attr%d_after",i)] = tolua.cast(self.uiLayer:getWidgetByName(string.format("lab_attr%d_after",i)),"Label")
		self[string.format("lab_attr%d_v_after",i)] = tolua.cast(self.uiLayer:getWidgetByName(string.format("lab_attr%d_v_after",i)),"Label")
	end

	self.btnAutoUpgrade = tolua.cast(self.uiLayer:getWidgetByName("btn_auto"),"Button")
	self.btnAutoUpgrade:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then

			self.btnAutoUpgrade:setBright(false)
	        self.btnAutoUpgrade:setTouchEnabled(false)

			-- local costVo = dp:getUpgradeCostVoById( dp:getCurPetVo().star + 1 )
   --          PetNetTask:getInstance():requestPetUpgrade(HeroHelper.fashion_upgrade_type.auto,costVo.base_id)
		end
    end)

    self.btnAdd = tolua.cast(self.uiLayer:getWidgetByName("btn_ok"),"Button")
    self.btnAdd:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then

            self.btnAdd:setBright(false)
            self.btnAdd:setTouchEnabled(false)

			-- local costVo = dp:getUpgradeCostVoById( dp:getCurPetVo().star + 1 )
   --          PetNetTask:getInstance():requestPetUpgrade(HeroHelper.fashion_upgrade_type.normal,costVo.base_id)
		end
    end)

    self.btnFind = tolua.cast(self.uiLayer:getWidgetByName("btn_find"),"Button")
    self.btnFind:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            local param = {}
            param.res_baseid = self.costAfterVo.base_id
            param.find_type = ItemHelper.find_type.pet_res
            param.eqm_type = ItemHelper.itemType.Normal
            WindowCtrl:getInstance():open(CmdName.FindEqmView,param)
        end
    end)


	self.labPerc = tolua.cast(self.uiLayer:getWidgetByName("lab_perc"),"Label")
	self.labLeft = tolua.cast(self.uiLayer:getWidgetByName("lab_left"),"Label")
	self.labCost = tolua.cast(self.uiLayer:getWidgetByName("lab_cost"),"Label")
	self.labStarBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_star_before"),"Label")
	self.labStarAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_star_after"),"Label")
	self.progCost = tolua.cast(self.uiLayer:getWidgetByName("prog_cost"),"LoadingBar")
	self.panelLeft = tolua.cast(self.uiLayer:getWidgetByName("panel_left"),"Layout")
	self.panelRight = tolua.cast(self.uiLayer:getWidgetByName("panel_right"),"Layout")
	self.panelCost = tolua.cast(self.uiLayer:getWidgetByName("panel_cost"),"Layout")
	self.labTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips"),"Label")

	Notifier.regist(CmdName.Update_Fashion_Upgrade,function() self:update() end)
    Notifier.regist(CmdName.Update_Fashion_Star,function(params) self:update_star(params) end)
end

function FashionUpgradePanel:open()

	self.item_data = self.params["item_data"]

	self:addOpenAnim(function()
		self:update()
	end)
end

function FashionUpgradePanel:update()

	local curStar = 1
	local hm = HeroManager:getInstance()
	local costBeforeVo = hm:getFashionGrowDataByBaseId(self.item_data.mode.base_id,curStar)
	local costAfterVo = hm:getFashionGrowDataByBaseId(self.item_data.mode.base_id,curStar+1)
	local fashionData = hm:getCfgFashionDataByBaseId(self.item_data.mode.base_id)
	local additionBeforeVo = hm:getFashionAddtion(self.item_data.mode.base_id,curStar)

	self.btnAdd:setBright(true)
    self.btnAdd:setVisible(true)
    self.btnAdd:setTouchEnabled(true)
    self.btnAutoUpgrade:setBright(true)
    self.btnAutoUpgrade:setVisible(true)
    self.btnAutoUpgrade:setTouchEnabled(true)
    self.btnFind:setTouchEnabled(true)
	--初始化
	for i=1,10 do
		self[string.format("lab_attr%d_before",i)]:setVisible(false)
		self[string.format("lab_attr%d_v_before",i)]:setVisible(false)
		self[string.format("lab_attr%d_after",i)]:setVisible(false)
		self[string.format("lab_attr%d_v_after",i)]:setVisible(false)
	end

	for i,v in ipairs(additionBeforeVo) do
		self[string.format("lab_attr%d_before",i)]:setVisible(true)
		self[string.format("lab_attr%d_before",i)]:setText(AttrHelper:getAttrNameByFlag(v.key))
		self[string.format("lab_attr%d_v_before",i)]:setVisible(true)
		self[string.format("lab_attr%d_v_before",i)]:setText(v.value)
	end
	self.labStarBefore:setText(string.format("第%s階",Helper.converNumToChinese(curStar)))

	if costAfterVo then
		self.labStarAfter:setText(string.format("第%s階",Helper.converNumToChinese(curStar+1)))
		local additionAfterVo = hm:getFashionUpgradeAddtion(self.item_data.mode.base_id,curStar+1)

		for i,v in ipairs(additionAfterVo) do
			self[string.format("lab_attr%d_after",i)]:setVisible(true)
			self[string.format("lab_attr%d_after",i)]:setText(AttrHelper:getAttrNameByFlag(v.key))
			self[string.format("lab_attr%d_v_after",i)]:setVisible(true)
			self[string.format("lab_attr%d_v_after",i)]:setText(v.value)
		end
		self.panelCost:setVisible(true)
		self.panelRight:setVisible(true)
		self.panelLeft:setPositionX(246)
		self.labTips:setVisible(false)
	else  --已满阶
		self.panelCost:setVisible(false)
		self.panelRight:setVisible(false)
		self.panelLeft:setPositionX(377)
		self.labTips:setVisible(true)

		self.btnAdd:setBright(false)
	    self.btnAdd:setVisible(false)
	    self.btnAdd:setTouchEnabled(false)
	    self.btnAutoUpgrade:setBright(false)
	    self.btnAutoUpgrade:setVisible(false)
	    self.btnAutoUpgrade:setTouchEnabled(false)
	    self.btnFind:setTouchEnabled(false)
	end

end

function FashionUpgradePanel:update_star(params)
	 if params.type == HeroHelper.fashion_upgrade_type.normal then
            -- self:playAnimFeed(params.param.cirType)
            self:update()
    elseif params.type == HeroHelper.fashion_upgrade_type.auto then
        self:playProgressAnim(self._widget,params.param,
            function() self:update() end)
    end
end

--渲染升阶 增加消耗物品/进度条 动画
function FashionUpgradePanel:playProgressAnim(container,params,func,funcShow)

	local progCost = tolua.cast(container:getChildByName("prog_cost"),"LoadingBar")
	local labPerc = tolua.cast(container:getChildByName("lab_perc_cost"),"Label")

	-- local dp = HeroManager:getInstance()
	local max = 0
	local costVo = nil
	local nowLimit = 0
	local nowSche = 0

	nowLimit = dp:getCurPetVo().star
	costVo = dp:getUpgradeCostVoById( params.oldLimit + 1 )
	max = costVo.lucky
	nowSche = dp:getCurPetVo().curStarSche

	local arr = CCArray:create()

	local step = (nowSche - params.oldValue) / 5 -- 5等份动画
	for i=1,5 do
		arr:addObject(CCCallFunc:create(function()
			labPerc:setText(string.format("%d/%d", params.oldValue + i*step,max))
			progCost:setPercent( (params.oldValue + i*step) / max * 100)

		end))
		arr:addObject(CCDelayTime:create(0.15))
	end

	arr:addObject(CCCallFunc:create(func)) -- 刷新最新状态

	container:stopAllActions()
	container:runAction(CCSequence:create(arr))
end


function FashionUpgradePanel:close()

end