--
-- Author: lvgansheng
-- Date: 2014-08-27 19:33:04
-- 技能tips界面

SkillTipsView = class("SkillTipsView", DisplayUtil.newFitLayout)

local tips_width = 300
local font_size = 22
local min_height = 126

function SkillTipsView:init()
	-- self:setPosition(ccp(240,50))

	self.tips_bg = ImageView:create()
	self.tips_bg:setScale9Enabled(true)
	self.tips_bg:setCapInsets(CCRect(70,64,19,8))
	self.tips_bg:loadTexture("chat_bg.png", UI_TEX_TYPE_PLIST)
	self:addChild(self.tips_bg)

	self.tips_label = Label:create()
	self.tips_label:setPosition(ccp(28,-15))
	self.tips_label:setColor(ItemHelper.colors.yellow)
	self.tips_label:setFontSize(font_size)
	-- self.tips_label:setAnchorPoint(ccp(0,1))
	self.tips_label:ignoreContentAdaptWithSize(false)
	self:addChild(self.tips_label)

	self.lev_label = Label:create()
	-- self.lev_label:setPosition(ccp(28,-15))
	
	self.lev_label:setFontSize(font_size-2)
	self.lev_label:setAnchorPoint(ccp(0,0))
	self:addChild(self.lev_label)
end

function SkillTipsView:create()
	local tips_view = SkillTipsView.new()
	tips_view:init()
	return tips_view
end

function SkillTipsView:setTips(tips_str,next_skill_vo,cur_hero_lv)

	local labSize = Helper.makeStrSize(tips_str,tips_width)
	local tips_height = math.max(labSize.height,min_height) + Helper.nlCount(tips_str) * 22

	self.tips_label:setSize(CCSize(tips_width,tips_height))
	self.tips_label:setText(tips_str)
	-- self.tips_bg:setSize(self.tips_label:getSize())

	if next_skill_vo ~= nil then
		tips_height = tips_height+(font_size*2)
		self.tips_bg:setSize(CCSize(tips_width+60,tips_height+20))
		self.lev_label:setPositionX(-tips_width/2+30)
		self.lev_label:setPositionY(-tips_height/2+15)
		self.lev_label:setText(string.format("升級條件：英雄%d級",next_skill_vo:getHeroLev()))
		if next_skill_vo:getHeroLev()>cur_hero_lv then
			self.lev_label:setColor(ItemHelper.colors.red)
		else
			self.lev_label:setColor(ItemHelper.colors.yellow)
		end
		self.lev_label:setVisible(true)
	else
		tips_height = tips_height
		self.tips_bg:setSize(CCSize(tips_width+60,tips_height))
		self.lev_label:setVisible(false)	
	end
	
end
