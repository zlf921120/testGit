
StoneVO = class("StoneVO")

StoneVO.key = nil --uid
StoneVO.row = 0  --所在行
StoneVO.col = 0  --所在列
StoneVO.adjacencies = nil --邻接的石头表
StoneVO.adjaceneyLen = 0  --邻接的石头表长度
StoneVO.bindStone = nil  --绑定的石头显示单元

function StoneVO:ctor(row, col, key)

	self.row, self.col, self.key = row, col, key

	-- self.key = string.format("%s_%s", self.row, self.col)
	self.adjacencies = {}

end

--[[
    绑定显示的石头对象
]]
function StoneVO:bindStoneView(stone)
	self.bindStone = stone
end

--[[
    添加相邻的石头
]]
function StoneVO:addAdjacency(stoneData)

	self.adjacencies[#self.adjacencies + 1] = stoneData
	self.adjaceneyLen = self.adjaceneyLen + 1

end

--[[
    判断是否相邻
    @return true/false
]]
function StoneVO:isAdjacency(stoneData)
	for _,v in ipairs(self.adjacencies) do
		if v.key == stoneData.key then
			return true
		end
	end

	return false
end

--[[
	获取邻接石头的长度
]]
function StoneVO:getAdjacencyLen()
	return self.adjaceneyLen
end

function StoneVO:create(row, col, key)
	return StoneVO.new(row, col, key)
end