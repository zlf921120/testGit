--
-- Author: thisgf
-- Date: 2014-08-19 10:14:30
-- 战斗抽卡结算界面

require "ItemInfoPanel"
require "ItemIcon"

BattleSettlementCardView = class("BattleSettlementCardView", AbstView.create)


BattleSettlementCardView._bm = nil

BattleSettlementCardView._starImageList = nil

--免费抽奖列表(显示)
BattleSettlementCardView._freeLotteryCardList = nil

--收费抽奖列表(显示)
BattleSettlementCardView._payLotteryCardList = nil

BattleSettlementCardView._freeAwardIndex = 1
BattleSettlementCardView._payAwardIndex = 1

BattleSettlementCardView._tempPayLotteryList = nil

--延迟播放动画函数
BattleSettlementCardView._delayPlayAnimationFunc = nil

--移动卡牌回调函数
BattleSettlementCardView._moveCardFunc = nil

BattleSettlementCardView._moveCardIndex = 0
--移动卡牌完成
BattleSettlementCardView._isMoveCardComplete = false

--点击卡牌回调
BattleSettlementCardView._touchCardFunc = nil

--显示免费卡牌函数
BattleSettlementCardView._showFreeCardFunc = nil

--显示付费卡牌函数
BattleSettlementCardView._showPayCardFunc = nil

--自动选择免费卡牌
BattleSettlementCardView._autoSelectCardFunc = nil


BattleSettlementCardView._titleAnimate = nil

BattleSettlementCardView._perfectClearanceTitle = nil
BattleSettlementCardView._clearanceTitle = nil

BattleSettlementCardView._starLayer = nil

BattleSettlementCardView._freeLotteryLayer = nil
BattleSettlementCardView._payLotteryLayer = nil

BattleSettlementCardView._payLotteryTitleLabel = nil

BattleSettlementCardView._dataButton = nil
BattleSettlementCardView._confirmButton = nil

BattleSettlementCardView._payLabel = nil
BattleSettlementCardView._goldImage = nil
BattleSettlementCardView._diamondImage = nil
BattleSettlementCardView._payCostLabel = nil
BattleSettlementCardView._lotteryLabel = nil


--最大抽奖卡
local MAX_LOTTERY = 4

local MAX_STAR = 3


local SettlementCardView

local _widgetPath = "ui/battleui/battle_settlement_card.json"

function BattleSettlementCardView:ctor()

	self:init()
end

function BattleSettlementCardView:init()

	self:_initData()
	self:_initUI()

	self:adjustScal()

end

function BattleSettlementCardView:_initData()

	self._bm = BattleManager:getInstance()


	self._starImageList = {}
	self._freeLotteryCardList = {}
	self._payLotteryCardList = {}


	self._delayPlayAnimationFunc = function()
	    
	    self:playAnimation()
	end

	self._moveCardFunc = function(cardView)

	    self._moveCardIndex = self._moveCardIndex + 1

	    if self._moveCardIndex > MAX_LOTTERY then

	    	TimerManager.removeTimerWithToken("move_card")

	    	self:_moveCardComplete()
	    end

	end

	--点击卡牌
	self._touchCardFunc = function(sender)

		local item
		local awardData
		local awardCount = 0

	    if sender._lotteryType == BattleAwardType.FREE then

	        self:_showCardAward(sender)

	    elseif sender._lotteryType == BattleAwardType.PAY then

	        if self._payLotteryLayer:isVisible() == false then
		        return
		    end

		    local function payLottery()
		    	for k, v in pairs(self._tempPayLotteryList) do
		        	if v == sender then
		        	    return
		        	end
		         end

		         table.insert(self._tempPayLotteryList, sender)
		         self._bm:reqLotteryPayCard()
		    end

		    local costTip

		    if self.params.payCardCostType == 1 then
		    	payLottery()
		    	-- costTip = string.format("確定要花費%d銅錢抽獎1次嗎？", self.params.payCardCostValue)
		    else

		    	if Alert:getInstance():checkCostDiamond(self.params.payCardCostValue) then
			    	costTip = string.format("確定要花費%d鑽石抽獎1次嗎？", self.params.payCardCostValue)
				    WindowCtrl:getInstance():open(
				    	CmdName.Comm_MsgBox, 
				    	{
				    	    okFunc = payLottery, 
		                    txt = costTip
		                }
		            )
		    	end
		    end

	        -- for k, v in pairs(self._tempPayLotteryList) do
	        -- 	if v == sender then
	        -- 	    return
	        -- 	end
	        -- end

	        -- table.insert(self._tempPayLotteryList, sender)
	        -- self._bm:reqLotteryPayCard()

	    end
	end

	self._showFreeCardFunc = function(params)

	    local awardList = params[1]
	    local cardList = params[2]

		for _, award in ipairs(awardList) do

    		if award.isAward == BattleCardAwardType.SHOW then

    			for i, v in ipairs(cardList) do

	        		if v:getItemData() == nil then

	    				v:setItemData(award.itemData)
				        v:playAction()
				        v:setEnabled(false)

				        break
	        		end
	        	end
    		end
		end

		self:_showPayLotteryLayer()
		self._dataButton:setEnabled(true)
		self._confirmButton:setEnabled(true)
		if SdkManager:getSdkPlatform() ~= SdkHelper.channel.lunplay and SdkManager:getSdkPlatform() ~= SdkHelper.channel.cp then
			print("不是lunplay,也不是测试")
			self._shareButton:setEnabled(false)
			self._label_share:setVisible(false)
			self._Label_share_tips:setVisible(false)
		else
			self._shareButton:setEnabled(true)
			self._label_share:setVisible(true)
		end

	end

	self._showPayCardFunc = function(params)

		local awardList = params[1]
	    local cardList = params[2]

		for _, award in ipairs(awardList) do

    		if award.isAward == BattleCardAwardType.SHOW then

    			for i, v in ipairs(cardList) do

	        		if v:getItemData() == nil then

	    				v:setItemData(award.itemData)
				        v:playAction()
				        v:setEnabled(false)

				        break
	        		end
	        	end
    		end
		end

	end

	self._onPayRspFunc = function(ret)

	    if ret ~= error_code_pb.msg_ret.success then
	    	return
	    end

	    if not self._tempPayLotteryList or #self._tempPayLotteryList == 0 then
	    	return
	    end

	    local sender = table.remove(self._tempPayLotteryList, 1)
	    self:_showCardAward(sender)

	    self._bm:reqAddAwardToBackpack(BattleAwardType.PAY)

	end

	self._autoSelectCardFunc = function()

	    local sender = self._freeLotteryCardList[math.random(1, MAX_LOTTERY)]

	    self:_showCardAward(sender)
	end

end

function BattleSettlementCardView:_initUI()

	-- self:addDefaultShadow()
	-- self.shadow:setOpacity(200)

	self:_initWidget(_widgetPath)

	local titleLayer = self:_getWidget("panel_title", ComponentType.LAYOUT)
	titleLayer:setVisible(false)
	self._titleAnimate = EffectManager:getInstance():createUIAnimate("wanmeitongguan")
	titleLayer:addNode(self._titleAnimate)

	self._perfectClearanceTitle = self:_getWidget("image_perfect_clearance_title", ComponentType.IMAGE_VIEW)
	self._perfectClearanceTitle:setZOrder(1)
	self._clearanceTitle = self:_getWidget("image_clearance_title", ComponentType.IMAGE_VIEW)
	self._clearanceTitle:setZOrder(1)

	self._starLayer = self:_getWidget("panel_star", ComponentType.LAYOUT)
	self._starLayer:setVisible(false)

	-- local starImage
	-- for i = 1, MAX_STAR do

	-- 	starImage = ImageView:create()
	-- 	starImage:loadTexture("orange_star.png", UI_TEX_TYPE_PLIST)
	-- 	starImage:setVisible(false)
	-- 	self._starLayer:addChild(starImage)

	-- 	self._starImageList[i] = starImage

	-- end

	self._freeLotteryLayer = self:_getWidget("panel_lottery_free", ComponentType.LAYOUT)
	self._payLotteryLayer = self:_getWidget("panel_lottery_pay", ComponentType.LAYOUT)

	self._payLotteryTitleLabel = self:_getWidget("label_lottery_pay_title", ComponentType.LABEL)


	local cardView
	for i = 1, MAX_LOTTERY do

		cardView = SettlementCardView:create(BattleAwardType.FREE, i)
		cardView:setTargetPos(98 + (i - 1) * 212, 65)

		self._freeLotteryLayer:addNode(cardView)

		self._freeLotteryCardList[#self._freeLotteryCardList + 1] = cardView
		cardView:addTouchEventListener(self._touchCardFunc)

	end

	for i = 1, MAX_LOTTERY do

		cardView = SettlementCardView:create(BattleAwardType.PAY, i)
		cardView:setTargetPos(98 + (i - 1) * 212, 65)

		self._payLotteryLayer:addNode(cardView)

		self._payLotteryCardList[#self._payLotteryCardList + 1] = cardView
		cardView:addTouchEventListener(self._touchCardFunc)
	end

	self._dataButton = self:_getWidget("button_data", ComponentType.BUTTON)
	self._dataButton:addTouchEventListener(function(sender, event)
	    if event ~= TOUCH_EVENT_ENDED then
	    	return
	    end

	    Notifier.dispatchCmd(CmdName.BATTLE_OPEN_STATISTIC_VIEW)
	 end)

	self._confirmButton = self:_getWidget("button_confirm", ComponentType.BUTTON)
	self._confirmButton:addTouchEventListener(function(sender, event)
	    if event == TOUCH_EVENT_ENDED then
	    	self._bm:reqBattleEnd()
	    end 
	 end)

	self._label_share = self:_getWidget("Label_share", ComponentType.LABEL)
	self._shareButton = self:_getWidget("button_share", ComponentType.BUTTON)
	self._shareButton:addTouchEventListener(function(sender, event)
	    if event == TOUCH_EVENT_ENDED then
	    	print("分享按钮被点击")
	    	if SdkManager:getSdkPlatform() == SdkHelper.channel.cp then
	    		require("FbRewardMgr")
	    		local share_data = {}
	    		share_data.type = 2
	    		share_data.num = 1
	    		FbRewardMgr:getInstance():sendFbReward(share_data)
	    	elseif
	    		--先调用SDK，SDK回调回来再发送协议
	    		SdkManager:getSdkPlatform() == SdkHelper.channel.lunplay then
	    		Global:excSdkFunc(1)
	    	end
	    end 
	 end)

	
	local payPanelSize = self._payLotteryLayer:getContentSize()

	self._payLabel = Label:create()
	self._payLabel:setColor(ccc3(0xf5, 0xcc, 0x55))
	self._payLabel:setText("花費")
	self._payLabel:setAnchorPoint(ccp(0, 1))
	self._payLabel:setPosition(ccp(0, payPanelSize.height))
	self._payLabel:setFontSize(24)
	self._payLotteryLayer:addChild(self._payLabel)

	self._goldImage = ImageView:create()
	self._goldImage:setPosition(ccp(70, payPanelSize.height - 12))
	self._payLotteryLayer:addChild(self._goldImage)

	self._payCostLabel = Label:create()
	self._payCostLabel:setAnchorPoint(ccp(0, 1))
	self._payCostLabel:setFontSize(24)
	self._payCostLabel:setPosition(ccp(95, payPanelSize.height))
	self._payLotteryLayer:addChild(self._payCostLabel)

	self._lotteryLabel = Label:create()
	self._lotteryLabel:setColor(ccc3(0xf5, 0xcc, 0x55))
	self._lotteryLabel:setAnchorPoint(ccp(0, 1))
	self._lotteryLabel:setFontSize(24)
	self._lotteryLabel:setText("抽獎1次")
	self._lotteryLabel:setPosition(ccp(168, payPanelSize.height))
	self._payLotteryLayer:addChild(self._lotteryLabel)

	self._Label_share_tips = Label:create()	
	self._Label_share_tips:setColor(ccc3(0xf5, 0xcc, 0x55))
	self._Label_share_tips:setAnchorPoint(ccp(0, 1))
	self._Label_share_tips:setFontSize(24)
	self._Label_share_tips:setText("玩家可無限次分享，但獎勵只能領取一次")
	self._Label_share_tips:setPosition(ccp(280, payPanelSize.height))
	self._payLotteryLayer:addChild(self._Label_share_tips)

end

function BattleSettlementCardView:_reset()

	self._payLotteryLayer:setVisible(false)

	self._tempPayLotteryList = {}
	self._freeAwardIndex = 1
	self._payAwardIndex = 1
	
	for i, v in ipairs(self._freeLotteryCardList) do

		v:stopAllActions()
		
		v:setPosition(ccp(445, 65))
		v:reset()
		v:setEnabled(false)

	end

	for i, v in ipairs(self._payLotteryCardList) do

		v:stopAllActions()
		
		v:setPosition(ccp(445, 65))
		v:reset()
		v:setEnabled(false)

	end

end

function BattleSettlementCardView:open()

	if self._isOpen then
		return
	end

	self._isOpen = true

	Notifier.regist(CmdName.BATTLE_PAY_LOTTERY_RSP, self._onPayRspFunc)

	-- self._titleAnimate:getAnimation():playWithIndex(0)

	self._freeAwardList = self.params.freeAwardList
	self._payAwardList = self.params.payAwardList

	self._dataButton:setEnabled(false)
	self._confirmButton:setEnabled(false)
	self._shareButton:setEnabled(false)
	self._label_share:setVisible(false)

	--金币
	if self.params.payCardCostType == 1 then

		self._goldImage:loadTexture("gold.png", UI_TEX_TYPE_PLIST)
		self._payCostLabel:setColor(ccc3(0xc2, 0x15, 0xc8))

		-- self._payLotteryTitleLabel:setText(string.format("花費%d金幣抽獎一次", self.params.payCardCostValue))
	else
		self._goldImage:loadTexture("diamond.png", UI_TEX_TYPE_PLIST)
		self._payCostLabel:setColor(ccc3(0xff, 0x99, 0x07))
		-- self._payLotteryTitleLabel:setText(string.format("花費%d鑽石抽獎一次", self.params.payCardCostValue))
	end

	self._payCostLabel:setText(tostring(self.params.payCardCostValue))

	if self.params.payCardCostType == 1 then
	end

	self:_reset()

	--延迟播放动画
	TimerManager.addTimer(100, self._delayPlayAnimationFunc, false)

end


function BattleSettlementCardView:close()

	if self._isOpen == false then
		return
	end

	self._isOpen = false

	-- self._titleAnimate:getAnimation():stop()

	Notifier.remove(CmdName.BATTLE_PAY_LOTTERY_RSP, self._onPayRspFunc)

	TimerManager.removeTimer(self._delayPlayAnimationFunc)
	TimerManager.removeTimer(self._showFreeCardFunc)
	TimerManager.removeTimer(self._showPayCardFunc)
	
	TimerManager.removeTimerWithToken("move_card")

end

--播放卡牌移动动画
function BattleSettlementCardView:playAnimation()

	self._moveCardIndex = 1
	self._isMoveCardComplete = false

	TimerManager.addTimer(300, function()
		self:_moveCardComplete()
	 end, false, nil, "move_card")

	for i, v in ipairs(self._freeLotteryCardList) do
		
		v:moveToTargetPos(self._moveCardFunc)
	end

	for i, v in ipairs(self._payLotteryCardList) do
		
		v:moveToTargetPos(self._moveCardFunc)
	end

end

function BattleSettlementCardView:_moveCardComplete()

	if self._isMoveCardComplete then
		return
	end
	
	self._isMoveCardComplete = true

	for i, v in ipairs(self._freeLotteryCardList) do
		
		v:setEnabled(true)
	end

	for i, v in ipairs(self._payLotteryCardList) do
		
		v:setEnabled(true)
	end

	TimerManager.addTimer(5000, self._autoSelectCardFunc, false)

end

--显示卡牌奖励
function BattleSettlementCardView:_showCardAward(sender)

    TimerManager.removeTimer(self._autoSelectCardFunc)

    local awardList
    local awardIndex
    local awardCount = 0

    local cardList

    local lotteryType = sender._lotteryType
    if lotteryType == BattleAwardType.FREE then

    	awardList = self._freeAwardList
    	awardIndex = self._freeAwardIndex

    	cardList = self._freeLotteryCardList

    else
     	awardList = self._payAwardList
     	awardIndex = self._payAwardIndex

     	cardList = self._payLotteryCardList

    end

    if not awardList or #awardList == 0 then
    	return
    end

    if awardIndex > #awardList then
    	return
    end

    for i = awardIndex, #awardList do

    	awardData = awardList[i]

    	if awardData.isAward == BattleCardAwardType.AWARD then

    		awardCount = awardCount + 1

    		if lotteryType == BattleAwardType.FREE then
	    		self._freeAwardIndex = i + 1
	    	else
	    		self._payAwardIndex = i + 1
	    	end

    		sender:setItemData(awardData.itemData)
    		sender:setSelected(true)
	        sender:playAction()
	        sender:setEnabled(false)

	        self._bm:reqAddAwardToBackpack(BattleAwardType.FREE)

	        break

    	end
    end

    --没有奖励的卡牌显示非奖励的
    if awardCount == 1 then

    	awardIndex = #awardList + 1

    	if lotteryType == BattleAwardType.FREE then
    		self._freeAwardIndex = awardIndex
	        TimerManager.addTimer(1100, self._showFreeCardFunc, false, {awardList, cardList})
    	else
    		self._payAwardIndex = awardIndex
    		TimerManager.addTimer(1100, self._showPayCardFunc, false, {awardList, cardList})
    	end
	end

end

function BattleSettlementCardView:_showPayLotteryLayer()

	self._payLotteryLayer:setVisible(true)

	-- self._payLotteryLayer:stopAllActions()
	-- self._payLotteryLayer:setOpacity(0)
	-- self._payLotteryLayer:runAction(CCFadeIn:create(0.5))

end

function BattleSettlementCardView:create()

	local bscv = BattleSettlementCardView.new()

	return bscv
end


SettlementCardView = class("SettlementCardView", DisplayUtil.newLayer)
-- SettlementCardView = class("SettlementCardView", function() return CCLayerColor:create(ccc4(0xff, 0xff, 0, 0xff)) end)

SettlementCardView.SIZE = CCSizeMake(210, 119)

--抽奖类型(免费和付费)
SettlementCardView._lotteryType = 0

--第几张牌
SettlementCardView._index = 1
--是否播放动作中
SettlementCardView._isAction = false
SettlementCardView._targetPos = nil
--显示结果动作
SettlementCardView._resultAction = nil
SettlementCardView._moveAction = nil
SettlementCardView._moveCallFunc = nil

SettlementCardView._isEnabled = true

SettlementCardView._touchFunc = nil

SettlementCardView._itemData = nil

--是否选中
SettlementCardView._isSelected = false

SettlementCardView._isOpen = false

SettlementCardView._lockCardSprite = nil
SettlementCardView._openCardSprite = nil
SettlementCardView._selectCardSprite = nil

--卡牌动画
SettlementCardView._cardAnimation = nil

SettlementCardView._itemIcon = nil
SettlementCardView._itemLabel = nil


function SettlementCardView:ctor(lotteryType, index)

    self._lotteryType = lotteryType
	self._index = index

	self._targetPos = ccp(0, 0)

	self:setContentSize(SettlementCardView.SIZE)
	self:ignoreAnchorPointForPosition(false)
	self:setAnchorPoint(ccp(0.5, 0.5))

	self._cardAnimation = EffectManager:getInstance():createUIAnimate("fanpai")
	self:addChild(self._cardAnimation)

	if self._lotteryType == BattleAwardType.FREE then
		-- self._lockCardSprite = CCSprite:createWithSpriteFrameName("btsui_free_card.png")
		-- self._openCardSprite = CCSprite:createWithSpriteFrameName("btsui_free_card_open.png")
		-- self._selectCardSprite = CCSprite:createWithSpriteFrameName("btsui_free_card_selected.png")

		self._cardAnimation:getAnimation():play("chengweixuan")
		self._cardAnimation:getAnimation():gotoAndPause(1)

	else
		-- self._lockCardSprite = CCSprite:createWithSpriteFrameName("btsui_pay_card.png")
		-- self._openCardSprite = CCSprite:createWithSpriteFrameName("btsui_pay_card_open.png")
		-- self._selectCardSprite = CCSprite:createWithSpriteFrameName("btsui_pay_card_selected.png")

		self._cardAnimation:getAnimation():play("jinweixuan")
		self._cardAnimation:getAnimation():gotoAndPause(1)

	end

	self._cardAnimation:setPosition(ccp(110, 65))

	-- self:addChild(self._lockCardSprite)
	-- self._lockCardSprite:setAnchorPoint(ccp(0, 0))

	-- self._openCardSprite:setVisible(false)
	-- self._openCardSprite:setAnchorPoint(ccp(0, 0))
	-- self:addChild(self._openCardSprite)

	-- self._selectCardSprite:setVisible(false)
	-- self._selectCardSprite:setAnchorPoint(ccp(0, 0))
	-- self:addChild(self._selectCardSprite)

	self._itemIcon = ItemIcon:create()
	self._itemIcon:setIsBattleAward(true)
	self._itemIcon:setPosition(ccp(SettlementCardView.SIZE.width * 0.5, SettlementCardView.SIZE.height * 0.65))
	self._itemIcon:setScale(0.8)
	self._itemIcon:setVisible(false)
	self:addChild(self._itemIcon)
	self._itemIcon:isShowIconOnly(true)

	local label = CCLabelTTF:create()
	label:setPosition(ccp(SettlementCardView.SIZE.width * 0.5, 25))

	self._itemLabel = Utils.createStrokeLab({label = label})
	self._itemLabel:setColor(ItemHelper.colors.white)
	self._itemLabel:setFontSize(22)
	self._itemLabel:setVisible(false)
	self:addChild(self._itemLabel)

	local function touchHandler(event, x, y)

		if DisplayUtil.isTouch(self, x, y) then

			if event == ComConstTab.TouchEventType2.BEGAN then
				if self._isOpen then
					-- ItemInfoPanel:getInstance():show(
					-- 	self._itemData.mode.base_id, 
					-- 	ccp(x, y)
					-- )
				end

			elseif event == ComConstTab.TouchEventType2.ENDED then
				if self._isEnabled == false then
					return
				end
				if self._touchFunc ~= nil then
					self._touchFunc(self)
				end
			end
		end

		return true

	end

	self:setTouchEnabled(true)
	self:registerScriptTouchHandler(touchHandler, false, 0)


end

function SettlementCardView:reset()

	self._itemData = nil
	self:setRotation(0)
	self:setScale(1)
	self:stopAllActions()
	self:_changeStatus(false)
	self:setEnabled(true)
	self._isSelected = false

end

function SettlementCardView:setSelected(value)

	self._isSelected = value
end

function SettlementCardView:_changeStatus(isOpen)

	self._isOpen = isOpen

	if isOpen then
		-- self._lockCardSprite:setVisible(false)

		-- if self._isSelected then
		-- 	self._selectCardSprite:setVisible(true)
		-- else
		-- 	self._openCardSprite:setVisible(true)
		-- end

		-- self._itemIcon:setVisible(true)
		
		self._itemLabel:setVisible(true)
		self._itemIcon:setVisible(true)

	else
		-- self._lockCardSprite:setVisible(true)
		-- self._selectCardSprite:setVisible(false)
		-- self._openCardSprite:setVisible(false)
		-- self._itemIcon:setVisible(false)

		self._itemIcon:setVisible(false)
		self._itemLabel:setVisible(false)

		if self._lotteryType == BattleAwardType.FREE then
			self._cardAnimation:getAnimation():play("chengweixuan")
			self._cardAnimation:getAnimation():gotoAndPause(0)

		else
			self._cardAnimation:getAnimation():play("jinweixuan")
			self._cardAnimation:getAnimation():gotoAndPause(0)

		end

	end

end

function SettlementCardView:playAction()

	local animation = self._cardAnimation:getAnimation()

	local function movementCallback(armature, movementType, movementID)

		if movementType == ComConstTab.MovementEventType.COMPLETE then

			animation:setMovementEventCallFunc(Helper.tempAction)

			self:_changeStatus(true)

		end
	end

	self._cardAnimation:getAnimation():setMovementEventCallFunc(movementCallback)

	if self._lotteryType == BattleAwardType.FREE then
		if self._isSelected then
			animation:play("chengxuan", -1, -1, 0)
		else
			animation:play("chengweixuan", -1, -1, 0)
		end
	else
		if self._isSelected then
			animation:play("jinxuan", -1, -1, 0)
		else
			animation:play("jinweixuan", -1, -1, 0)
		end
	end

	-- if self._isAction then
	-- 	return
	-- end

	-- self._isAction = true

	-- if not self._resultAction then

	-- 	local actionCallFunc = function()
	-- 	    self._isAction = false
	-- 	end

	-- 	local middleCallFunc = function()

	-- 	    self:_changeStatus(true)

	-- 	end

		
	-- 	local rotateAction1 = CCRotateBy:create(0.3, 720)
	-- 	local scaleAction1 = CCScaleBy:create(0.2, 0.2)

	-- 	local spawnAction1 = CCSpawn:createWithTwoActions(rotateAction1, scaleAction1)

	-- 	local rotateAction2 = CCRotateBy:create(0.3, 360)
	-- 	local scaleAction2 = CCScaleTo:create(0.3, 1)

	-- 	local spawnAction2 = CCSpawn:createWithTwoActions(rotateAction2, scaleAction2)

	-- 	local middleAction = CCCallFunc:create(middleCallFunc)
	-- 	local callAction = CCCallFunc:create(actionCallFunc)

	-- 	local actionArray = CCArray:create()
	-- 	actionArray:addObject(spawnAction1)
	-- 	actionArray:addObject(middleAction)
	-- 	actionArray:addObject(spawnAction2)
	-- 	actionArray:addObject(callAction)

	-- 	local seqAction = CCSequence:create(actionArray)

	-- 	self._resultAction = seqAction
	-- 	self._resultAction:retain()

	-- end

	-- self:runAction(self._resultAction)

end

function SettlementCardView:moveToTargetPos(callFunc)

	self._moveCallFunc = callFunc

	if not self._moveAction then

		local onMoveComplete = function()
		    if self._moveCallFunc then
		    	self._moveCallFunc(self)
		    end
		end

		local moveAction = CCMoveTo:create(0.15, self._targetPos)
		local easeAction = CCEaseIn:create(moveAction, 0.5)
		local callAction = CCCallFunc:create(onMoveComplete)

		self._moveAction = CCSequence:createWithTwoActions(easeAction, callAction)
		self._moveAction:retain()

	end

	self:runAction(self._moveAction)

end

--[[
    设置物品数据
]]
function SettlementCardView:setItemData(itemData)

	self._itemData = itemData
	self._itemIcon:setBaseId(itemData.mode.base_id)
	self._itemLabel:setColor(ItemHelper:getColorByQuality(itemData.mode.quality))
	self._itemLabel:setText(string.format("%sx%s", self._itemData.mode.name, self._itemData.quantity))

end

function SettlementCardView:getItemData()

	return self._itemData
end

function SettlementCardView:setEnabled(value)

	if self._isEnabled == value then
		return
	end

	self._isEnabled = value

	-- if self._isEnabled then
	-- 	self:setTouchEnabled(true)
	-- else
	-- 	self:setTouchEnabled(false)
	-- end

end

function SettlementCardView:setTargetPos(x, y)
	self._targetPos.x = x
	self._targetPos.y = y
end

function SettlementCardView:getTargetPos()
	return self._targetPos
end

function SettlementCardView:getLotteryType()
	return self._lotteryType
end

function SettlementCardView:getIndex()
	return self._index
end

function SettlementCardView:addTouchEventListener(func)

	self._touchFunc = func
end

function SettlementCardView:dispose()
	
	if self._resultAction then
		self._resultAction:release()
	end

	if self._moveAction then
		self._moveAction:release()
	end

end

function SettlementCardView:create(lotteryType, index)
	
	local dccv = SettlementCardView.new(lotteryType, index)

	return dccv

end