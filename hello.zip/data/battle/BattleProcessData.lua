--
-- Author: thisgf
-- Date: 2014-10-22 14:38:05
-- 战斗过程数据, 维持周期为开始战斗和结束

BattleProcessData = class("BattleProcessData")

--第几回合
BattleProcessData._roundIndex = 1

--第几波战斗
BattleProcessData._waveIndex = 0

--一共多少波
BattleProcessData._waveTotalIndex = 0

--跟人还是怪打
BattleProcessData._pvType = 0

--是否己方先出手
BattleProcessData._isAllyAttackFirst = nil


function BattleProcessData:ctor()

	self._roundIndex = 1

end

--[[
    增加回合数
]]
function BattleProcessData:increaseRound()
	
	self._roundIndex = self._roundIndex + 1

	Notifier.dispatchCmd(CmdName.BATTLE_UPDATE_ROUND)

end

--[[
    重置回合数
]]
function BattleProcessData:resetRound()
	self._roundIndex = 1
end

--[[
    获取回合数
]]
function BattleProcessData:getRoundIndex()
	return self._roundIndex
end

function BattleProcessData:setPvType(value)
	self._pvType = value
end

function BattleProcessData:getPvType()
	return self._pvType
end

function BattleProcessData:setAllyAttackFirst(value)
	self._isAllyAttackFirst = value
end

function BattleProcessData:isAllyAttackFirst()
	return self._isAllyAttackFirst
end

function BattleProcessData:setWaveTotalIndex(value)
	self._waveTotalIndex = value
end

--[[
    设置下一波
]]
function BattleProcessData:setNextWave()
	
	self._waveIndex = self._waveIndex + 1

	Notifier.dispatchCmd(CmdName.BATTLE_UPDATE_WAVE)

end

--[[
    获取一共多少波敌人
]]
function BattleProcessData:getWaveTotalIndex()
	return self._waveTotalIndex
end

function BattleProcessData:getWaveIndex()
	return self._waveIndex
end

function BattleProcessData:dispose()

end

function BattleProcessData:create()

	return BattleProcessData.new()
end
