--
-- Author: thisgf
-- Date: 2014-10-18 15:39:41
-- 战斗统计界面

require "HeroIcon"
require "MonsterIcon"
require "ResContendGuardIcon"
require "ResContendManager"

BattleStatisticView = class("BattleStatisticView", AbstView.create)

BattleStatisticView._allyItemList = nil
BattleStatisticView._enemyItemList = nil

BattleStatisticView._closeButton = nil

BattleStatisticView._imageView = nil

BattleStatisticView._recordView = nil

BattleStatisticView._allyItemContainer = nil
BattleStatisticView._enemyItemContainer = nil


local _widgetPath = "ui/battleui/battle_statistic_ui_1.json"

local MAX_ITEM = 6

local BattleHurtRecordItem = nil

function BattleStatisticView:ctor()

	self:init()

end

function BattleStatisticView:init()

	self:_initData()
	self:_initUI()

	self:adjustScal()

end

function BattleStatisticView:_initData()

	self._allyItemList = {}
	self._enemyItemList = {}

end

function BattleStatisticView:_initUI()

	self:addDefaultShadow()
	self.shadow:setOpacity(200)

	self:_initWidget(_widgetPath)

	self._closeButton = self:_getWidget("button_close", ComponentType.BUTTON)
	self._closeButton:addTouchEventListener(function(sender, event)
	        if event ~= TOUCH_EVENT_ENDED then
	            return
	         end

	         self:close() 
	         self:removeFromParentAndCleanup(true)
		end)

	self._imageView = self:_getWidget("ImageView_23", ComponentType.IMAGE_VIEW)

	self._recordView = BattleHurtRecordView:create()
	self._imageView:addChild(self._recordView)

end

function BattleStatisticView:open()

	self._recordView:open(self.params)
end

function BattleStatisticView:close()

	self._recordView:close()
end

function BattleStatisticView:create()

	return BattleStatisticView.new()

end


--伤害记录界面
BattleHurtRecordView = class("BattleHurtRecordView", DisplayUtil.newWidget)

BattleHurtRecordView._allyItemList = nil
BattleHurtRecordView._enemyItemList = nil

BattleHurtRecordView._allyItemContainer = nil
BattleHurtRecordView._enemyItemContainer = nil

function BattleHurtRecordView:ctor()
end

function BattleHurtRecordView:init()

	self._allyItemList = {}
	self._enemyItemList = {}

	self._allyItemContainer = DisplayUtil.newWidget()
	self._allyItemContainer:setPosition(ccp(-215, -165))
	self:addChild(self._allyItemContainer)

	self._enemyItemContainer = DisplayUtil.newWidget()
	self._enemyItemContainer:setPosition(ccp(105, -165))
	self:addChild(self._enemyItemContainer)

	local recordItem
	for i = 1, MAX_ITEM do

		recordItem = BattleHurtRecordItem:create(true)
		recordItem:setPosition(ccp(0, 65 * (i - 1)))

		self._allyItemContainer:addChild(recordItem)

		self._allyItemList[i] = recordItem

	end

	for i = 1, MAX_ITEM do

		recordItem = BattleHurtRecordItem:create(false)
		recordItem:setPosition(ccp(0, 65 * (i - 1)))

		self._enemyItemContainer:addChild(recordItem)

		self._enemyItemList[i] = recordItem

	end


end

function BattleHurtRecordView:open(params)

	self.params = params

	local allyTeam = self.params.allyTeam
	local enemyTeam = self.params.enemyTeam

	local maxHurtValue = 0

	for _, v in pairs(allyTeam) do
		if v.hurt > maxHurtValue then
			maxHurtValue = v.hurt
		end
	end

	for _, v in pairs(enemyTeam) do
		if v.hurt > maxHurtValue then
			maxHurtValue = v.hurt
		end
	end

	local item 

	for i = MAX_ITEM, 1, -1 do

		item = self._allyItemList[i]

		local j = MAX_ITEM - i
		local itemData = allyTeam[j + 1]

		if itemData then
			item:setVisible(true)
			item:setFighterType(BattleType.ROLE)
			item:setIconId(itemData.baseInfo.base_id)
			item:setHurtNum(itemData.hurt, maxHurtValue)
		else
			item:setVisible(false)
		end

	end

	local fighterType
	if self.params.pvType == BattleType.PVP then
		fighterType = BattleType.ROLE
	else
		if self.params.type == BattleType.RES_DUNGEON then
			if self.params.resDungeonStatus == 2 then
				fighterType = BattleType.GUARD
			else
				fighterType = BattleType.MONSTER
			end
		else
			fighterType = BattleType.MONSTER
		end

	end

	for i = MAX_ITEM, 1, -1 do

		item = self._enemyItemList[i]

		local j = MAX_ITEM - i
		local itemData = enemyTeam[j + 1]

		if itemData then
			item:setVisible(true)
			item:setFighterType(fighterType)
			if fighterType == BattleType.ROLE then
				item:setIconInfo(itemData.baseInfo)
			elseif fighterType == BattleType.MONSTER then
				item:setIconId(itemData.baseInfo.base_id)
			else
				item:setIconId(itemData.baseInfo.baseId)
			end
			item:setHurtNum(itemData.hurt, maxHurtValue)
		else
			item:setVisible(false)
		end

	end

end

function BattleHurtRecordView:setWideSpace(value)

	self._allyItemContainer:setPosition(ccp(-215 - value, -165))
	self._enemyItemContainer:setPosition(ccp(105 + value, -165))

end

function BattleHurtRecordView:close()

end

function BattleHurtRecordView:create()
	local rv = BattleHurtRecordView.new()
	rv:init()
	return rv
end



--伤害记录项
BattleHurtRecordItem = class("BattleHurtRecordItem", DisplayUtil.newWidget)

BattleHurtRecordItem._isAlly = nil

BattleHurtRecordItem._fighterType = false

BattleHurtRecordItem._heroIcon = nil
BattleHurtRecordItem._monsterIcon = nil
BattleHurtRecordItem._guardIcon = nil

BattleHurtRecordItem._progressBg = nil
BattleHurtRecordItem._progress = nil

BattleHurtRecordItem._hurtText = nil

function BattleHurtRecordItem:ctor(isAlly)

	self._isAlly = isAlly

	self._heroIcon = HeroIcon:create()
	self._heroIcon:setScale(0.5)
	self._heroIcon:setVisible(false)
	self:addChild(self._heroIcon)

	self._monsterIcon = MonsterIcon:create()
	self._monsterIcon:setScale(0.5)
	self:addChild(self._monsterIcon)

	self._guardIcon = ResContendGuardIcon:create()
	self._guardIcon:setScale(0.5)
	self:addChild(self._guardIcon)

	self._progressBg = ImageView:create()
	self._progressBg:loadTexture("progress_bar_bg.png", UI_TEX_TYPE_PLIST)
	self._progressBg:setScale9Enabled(true)
	self._progressBg:setCapInsets(CCRectMake(10, 10, 325, 6))
	self._progressBg:setSize(CCSizeMake(169, 20))
	self:addChild(self._progressBg)

	self._hurtText = CCLabelTTF:create()
	self._hurtText:setFontSize(16)
	-- self._hurtText:setString(MathUtil.getThreeSectionNum("1234567"))

	local progressSprite

	if self._isAlly then
		progressSprite = CCSprite:createWithSpriteFrameName("progress_bar_2.png")
		self._progressBg:setPosition(ccp(120, -15))

		self._hurtText:setAnchorPoint(ccp(0, 0.5))
		self._hurtText:setPosition(ccp(45, 8))
	else
		progressSprite = CCSprite:createWithSpriteFrameName("progress_bar_1.png")
		self._heroIcon:setPosition(ccp(120, 0))
		self._monsterIcon:setPosition(ccp(120, 0))
		self._guardIcon:setPosition(ccp(120, 0))
		self._progressBg:setPosition(ccp(0, -15))
		self._progressBg:setScaleX(-1)

		self._hurtText:setAnchorPoint(ccp(1, 0.5))
		self._hurtText:setPosition(ccp(75, 8))
	end

	self._progress = CCProgressTimer:create(progressSprite)
	self._progress:setBarChangeRate(CCPointMake(1, 0))
	self._progress:setType(kCCProgressTimerTypeBar)
	self._progress:setMidpoint(CCPointMake(0, 0))
	self._progressBg:addNode(self._progress)

	self:addNode(self._hurtText)

end

function BattleHurtRecordItem:setFighterType(value)

	self._fighterType = value

	self._heroIcon:setVisible(false)
	self._monsterIcon:setVisible(false)
	self._guardIcon:setVisible(false)
	if self._fighterType == BattleType.ROLE then
		self._heroIcon:setVisible(true)
	elseif self._fighterType == BattleType.MONSTER then
		self._monsterIcon:setVisible(true)
	else
		self._guardIcon:setVisible(true)
	end

end

function BattleHurtRecordItem:setIconInfo(value)
	self._heroIcon:setOtherHeroInfo(value)
end

function BattleHurtRecordItem:setIconId(value)

	if self._fighterType == BattleType.ROLE then
		self._heroIcon:setHeroId(value)
	elseif self._fighterType == BattleType.MONSTER then
		self._monsterIcon:setMonsterId(value)
	else
		local guardData = ResContendManager:getInstance():getGuardData(value)
		self._guardIcon:setIconData(guardData.avatarId, 0)
	end

end

function BattleHurtRecordItem:setHurtNum(value, maxValue)
	self._hurtText:setString(MathUtil.getThreeSectionNum(value))

	self._progress:setPercentage(0)
	local to1 = CCProgressTo:create(0.5, value * 100 / maxValue)
	self._progress:runAction(to1)
	
end

function BattleHurtRecordItem:create(isAlly)

	return BattleHurtRecordItem.new(isAlly)

end
