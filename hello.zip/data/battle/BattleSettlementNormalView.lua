--
-- Author: thisgf
-- Date: 2014-08-18 17:19:13
-- 战斗普通结算界面

require "EffectManager"
require "TeamManager"
require "HeroIcon"
require "ItemIcon"
require "AbstView"
require "ItemInfoPanel"


BattleSettlementNormalView = class("BattleSettlementNormalView", AbstView.create)

BattleSettlementNormalView._tm = nil
BattleSettlementNormalView._bm = nil

BattleSettlementNormalView._onShowAwardFunc = nil

BattleSettlementNormalView._onShowHeroIconFunc = nil
BattleSettlementNormalView._onShowItemIconFunc = nil

BattleSettlementNormalView._heroIconPool = nil
BattleSettlementNormalView._heroIconPoolIndex = 1

BattleSettlementNormalView._showHeroIconIndex = 0
BattleSettlementNormalView._showHeroIconList = nil

BattleSettlementNormalView._itemIconPool = nil
BattleSettlementNormalView._itemIconPoolIndex = 1

BattleSettlementNormalView._showItemIconIndex = 0
BattleSettlementNormalView._showItemIconList = nil

BattleSettlementNormalView._isShowHeroIconComplete = false
BattleSettlementNormalView._isShowItemIconComplete = false

BattleSettlementNormalView._showCardViewFunc = nil

BattleSettlementNormalView._titleImage = nil

BattleSettlementNormalView._titleAnimate = nil

BattleSettlementNormalView._starLayer = nil

--战队等级标签
BattleSettlementNormalView._teamLevelLabel = nil

--战队经验标签
BattleSettlementNormalView._teamExpLabel = nil

--获得金币标签
BattleSettlementNormalView._goldLabel = nil

BattleSettlementNormalView._dataButton = nil

BattleSettlementNormalView._heroIconPanel = nil
BattleSettlementNormalView._itemIconPanel = nil

BattleSettlementNormalView._confirmButton = nil

local MAX_STAR = 3


--结算英雄图标
local SettlementHeroIcon


local _widgetPath = "ui/battleui/battle_settlement_normal.json"

function BattleSettlementNormalView:ctor()

	self:init()

end

function BattleSettlementNormalView:init()

	self:_initData()
	self:_initUI()

	self:adjustScal()

end


function BattleSettlementNormalView:_initData()

	self._tm = TeamManager:getInstance()
	self._bm = BattleManager:getInstance()

	self._heroIconPool = {}
	self._showHeroIconList = {}
	self._itemIconPool = {}
	self._showItemIconList = {}

	self._starImageList = {}

	self._onShowAwardFunc = function()
	    self:_showAwardFunc()
	end

	self._onShowHeroIconFunc = function()
	    self:_showHeroIconFunc()
	end

	self._onShowItemIconFunc = function()
	    self:_showItemIconFunc()
	end

end

function BattleSettlementNormalView:_initUI()

	-- self:addDefaultShadow()
	-- self.shadow:setOpacity(200)

	self:_initWidget(_widgetPath)

	local titleLayer = self:_getWidget("panel_title", ComponentType.LAYOUT)
	titleLayer:setVisible(false)

	self._titleImage = self:_getWidget("image_victory_title", ComponentType.IMAGE_VIEW)
	self._titleImage:setZOrder(1)

	self._titleAnimate = EffectManager:getInstance():createUIAnimate("wanmeitongguan")
	titleLayer:addNode(self._titleAnimate)

	self._teamLevelLabel = self:_getWidget("label_team_level", ComponentType.LABEL)
	self._teamExpLabel = self:_getWidget("label_team_exp", ComponentType.LABEL)
	self._goldLabel = self:_getWidget("label_gold", ComponentType.LABEL)

	self._dataButton = self:_getWidget("button_data", ComponentType.BUTTON)
	self._dataButton:addTouchEventListener(function(sender, event)
	    if event ~= TOUCH_EVENT_ENDED then
	    	return
	    end

	    Notifier.dispatchCmd(CmdName.BATTLE_OPEN_STATISTIC_VIEW)
	 end)

	self._confirmButton = self:_getWidget("button_confirm", ComponentType.BUTTON)
	self._confirmButton:addTouchEventListener(function(sender, event)
	    if event == TOUCH_EVENT_ENDED then
	    	self._bm:reqBattleEnd()
	    end 
	 end)


	self._heroIconPanel = self:_getWidget("panel_hero_icon", ComponentType.LAYOUT)
	self._itemIconPanel = self:_getWidget("panel_item_icon", ComponentType.LAYOUT)

	self._starLayer = self:_getWidget("panel_star", ComponentType.LAYOUT)
	self._starLayer:setVisible(false)

	local starImage
	for i = 1, MAX_STAR do

		starImage = ImageView:create()
		starImage:loadTexture("orange_star.png", UI_TEX_TYPE_PLIST)
		starImage:setVisible(false)
		self._starLayer:addChild(starImage)

		self._starImageList[i] = starImage

	end
	

end

function BattleSettlementNormalView:_showAwardFunc()

	local startData = self._bm:getStartData()

	local heroList = self._tm:getBattleHeroList(startData.teamType)

	local heroIcon
	local index = 0

	--test
	-- heroList = {}
	-- for i = 1, 6 do
	-- 	heroList[i] = 10000 + i - 1
	-- end
	--test end

	for k, v in pairs(heroList) do

		heroIcon = self:_getHeroIcon()
		heroIcon:setPosition(ccp(78 + index * 120, 15))
		heroIcon:setHeroId(v)
		heroIcon:setAddExp(self.params.heroExp)
		self._heroIconPanel:addChild(heroIcon)

		index = index + 1

		table.insert(self._showHeroIconList, heroIcon)
		heroIcon:setVisible(false)

	end

	local function onItemTouch(sender, event)
	    if event == TOUCH_EVENT_BEGAN then
	    	local pos = DisplayUtil.getWorldPos(sender)
		    ItemInfoPanel:getInstance():show(sender.base_id, ccp(pos.x, pos.y))
		elseif event == TOUCH_EVENT_ENDED or 
			   event == TOUCH_EVENT_CANCELED then
			ItemInfoPanel:getInstance():hide()
	    end
	end

	local itemList = self.params.itemList

	local itemIcon

	index = 0

	for k, v in pairs(itemList) do

		itemIcon = self:_getItemIcon()
		itemIcon:setPosition(ccp(78 + index * 100, 65))
		itemIcon:setBaseId(v.mode.base_id)
		itemIcon:setItemNum(v.quantity)
		self._itemIconPanel:addChild(itemIcon)

		index = index + 1
		table.insert(self._showItemIconList, itemIcon)
		itemIcon:setEnabled(false)
		itemIcon:setTouchEnabled(true)
		itemIcon:setSize(CCSizeMake(100, 100))
		itemIcon:ignoreContentAdaptWithSize(false)
		itemIcon:addTouchEventListener(onItemTouch)

	end

	TimerManager.addTimer(100, self._onShowHeroIconFunc, true)
	TimerManager.addTimer(100, self._onShowItemIconFunc, true)

end

function BattleSettlementNormalView:_showHeroIconFunc()

	self._showHeroIconIndex = self._showHeroIconIndex + 1

	if self._showHeroIconIndex > #self._showHeroIconList then
		TimerManager.removeTimer(self._onShowHeroIconFunc)
		self._isShowHeroIconComplete = true
		self:_showIconComplete()

		return
	end

	local heroIcon = self._showHeroIconList[self._showHeroIconIndex]
	heroIcon:playAction()

end

function BattleSettlementNormalView:_showItemIconFunc()

	self._showItemIconIndex = self._showItemIconIndex + 1

	if self._showItemIconIndex > #self._showItemIconList then
		TimerManager.removeTimer(self._onShowItemIconFunc)
		self._isShowItemIconComplete = true
		self:_showIconComplete()

		return
	end

	local itemIcon = self._showItemIconList[self._showItemIconIndex]
	self:_playItemIconAction(itemIcon)

end

function BattleSettlementNormalView:_playItemIconAction(itemIcon)

	itemIcon:setEnabled(true)
end

function BattleSettlementNormalView:_showIconComplete()

	if self._isShowHeroIconComplete == false or self._isShowItemIconComplete == false then
		return
	end

	TimerManager.addTimer(1500, function()
		if self.params.settlementType == BattleSettlementType.NORMAL then
			self._confirmButton:setEnabled(true)
		else
			if #self.params.freeAwardList == 0 then
				self._confirmButton:setEnabled(true)
			else
				self._showCardViewFunc(self.params)
			end
		end
	end, false)

end

function BattleSettlementNormalView:_resetIcon()

	self._isShowHeroIconComplete = false
	self._isShowItemIconComplete = false

	self._showHeroIconIndex = 0
	self._showHeroIconList = {}
	self._heroIconPoolIndex = 1

	self._showItemIconIndex = 0
	self._showItemIconList = {}
	self._itemIconPoolIndex = 1

	for _, icon in ipairs(self._heroIconPool) do
		icon:removeFromParentAndCleanup(false)
	end

	for _, icon in ipairs(self._itemIconPool) do
		icon:removeFromParentAndCleanup(false)
	end

end

function BattleSettlementNormalView:_getHeroIcon()

	local heroIcon = self._heroIconPool[self._heroIconPoolIndex]

	if not heroIcon then
		heroIcon = SettlementHeroIcon:create()
		heroIcon:retain()
		self._heroIconPool[#self._heroIconPool + 1] = heroIcon
	end

	self._heroIconPoolIndex = self._heroIconPoolIndex + 1
	heroIcon:setVisible(true)

	return heroIcon

end

function BattleSettlementNormalView:_getItemIcon()

	local itemIcon = self._itemIconPool[self._itemIconPoolIndex]

	if not itemIcon then
		itemIcon = ItemIcon:create()
		itemIcon:retain()
		self._itemIconPool[#self._itemIconPool + 1] = itemIcon
	end

	self._itemIconPoolIndex = self._itemIconPoolIndex + 1
	itemIcon:setEnabled(false)

	return itemIcon

end

--[[
    设置显示翻牌界面回调
]]
function BattleSettlementNormalView:setShowCardViewFunc(func)

	self._showCardViewFunc = func
end

function BattleSettlementNormalView:open()

	if self._isOpen then
		return
	end

	self._isOpen = true

	-- self._titleAnimate:getAnimation():playWithIndex(0)

	self._teamLevelLabel:setText(string.format("Lv.%d", CharacterManager:getInstance():getTeamData():getLev()))

	self._teamExpLabel:setText(string.format("+%d", self.params.exp))
	self._goldLabel:setText(string.format("+%d", self.params.gold))
		
	self._confirmButton:setEnabled(false)


	-- for i, v in ipairs(self._starImageList) do
	-- 	v:setVisible(false)
	-- end

	if self.params.settlementType == BattleSettlementType.NORMAL then

		-- self._titleImage:loadTexture("i18n_btsui_victory_logo.png", UI_TEX_TYPE_PLIST)

		self._dataButton:setEnabled(true)

		self._itemIconPanel:setVisible(true)
	else

		-- if self.params.numStars == MAX_STAR then
		-- 	self._titleImage:loadTexture("i18n_btsui_perfect_clearance_title.png", UI_TEX_TYPE_PLIST)
		-- else
		-- 	self._titleImage:loadTexture("i18n_btsui_clearance_title.png", UI_TEX_TYPE_PLIST)
		-- end

		self._dataButton:setEnabled(false)

		self._itemIconPanel:setVisible(false)

		-- local width_dist = 270 / (self.params.numStars + 1)
		-- local starImage
		-- for i = 1, self.params.numStars do

		-- 	starImage = self._starImageList[i]

		-- 	starImage:setVisible(true)
		-- 	starImage:setPosition(ccp(width_dist * i, 40))
		-- end

	end

	self:_resetIcon()

	TimerManager.addTimer(200, self._onShowAwardFunc, false)

end

function BattleSettlementNormalView:close()

	if self._isOpen == false then
		return
	end

	self._isOpen = false

	-- self._titleAnimate:getAnimation():stop()
	
	TimerManager.removeTimer(self._onShowAwardFunc)

	TimerManager.removeTimer(self._onShowHeroIconFunc)
	TimerManager.removeTimer(self._onShowItemIconFunc)

end

function BattleSettlementNormalView:create()

	local bsnv = BattleSettlementNormalView.new()

	return bsnv

end



SettlementHeroIcon = class("SettlementHeroIcon", DisplayUtil.newWidget)

SettlementHeroIcon.SIZE = CCSizeMake(110, 150)

SettlementHeroIcon._addExp = 0

SettlementHeroIcon.SCALE_BASE = 0.6

SettlementHeroIcon._heroIcon = nil
SettlementHeroIcon._expProgress = nil
SettlementHeroIcon._expSprite = nil
SettlementHeroIcon._addExpLabel = nil

function SettlementHeroIcon:ctor()

	self:setSize(SettlementHeroIcon.SIZE)
	-- self:setCascadeOpacityEnabled(true)
	-- self:setCascadeColorEnabled(true)

	self._addExpLabel = Label:create()
	self._addExpLabel:setFontName("微軟雅黑")
	self._addExpLabel:setFontSize(20)
	self._addExpLabel:setColor(ccc3(0xe5, 0xc3, 0x30))
	self:addChild(self._addExpLabel)

	-- self._expProgress = LoadingBar:create()
	-- self._expProgress:loadTexture("progress_bar_1.png", UI_TEX_TYPE_PLIST)
	-- self._expProgress:setPosition(ccp(0, 30))
	-- self._expProgress:setScaleX(0.6)
	-- self:addChild(self._expProgress)

	self._expSprite = CCSprite:createWithSpriteFrameName("progress_bar_1.png")
	self._expSprite:setAnchorPoint(ccp(0, 0.5))
	self._expSprite:setPosition(ccp(-51, 30))
	self._expSprite:setScaleX(SettlementHeroIcon.SCALE_BASE)
	self:addNode(self._expSprite)

	self._heroIcon = HeroIcon:create()
	self._heroIcon:setScale(0.8)
	self._heroIcon:setPosition(ccp(0, 90))
	self:addChild(self._heroIcon)

end

function SettlementHeroIcon:setHeroId(value)

	self._heroIcon:setHeroId(value)

	self._heroData = HeroManager:getInstance():getHeroInfoByBaseId(value)

end

function SettlementHeroIcon:setAddExp(exp)

	self._addExp = exp
	
	self._addExpLabel:setText(string.format("EXP+%d", self._addExp))

end

function SettlementHeroIcon:_getExpPercent()

	local currentExp = self._heroData.exp

	currentExp = currentExp + self._addExp

	local nextLevel = self._heroData.cur_lev + 1

	local nextExp = HeroManager:getInstance():getLevExp(nextLevel)

	local percent = 0

	while true do

		if currentExp < nextExp then

			percent = currentExp / nextExp

			break
		else

			nextLevel = nextLevel + 1

			if nextLevel >= nextLevel then
				percent = 1
				break
			end

			currentExp = currentExp - nextExp

			nextExp = HeroManager:getInstance():getLevExp(nextLevel)

		end
	end

	return percent

end

function SettlementHeroIcon:playAction()

	self:setVisible(true)
	self._heroIcon:stopAllActions()
	-- self:setOpacity(0)
	-- self:runAction(CCFadeTo:create(0.5, 255))
	self._heroIcon:setScale(0.1)
	self._heroIcon:runAction(CCScaleTo:create(0.05, 0.8))

	local expPercent = self:_getExpPercent()*SettlementHeroIcon.SCALE_BASE

	self._expSprite:setScaleX(0)
	local scaleAction = CCScaleTo:create(0.3, expPercent, 1)
	self._expSprite:runAction(scaleAction)

end

function SettlementHeroIcon:create()

	local shi = SettlementHeroIcon.new()
	return shi

end
