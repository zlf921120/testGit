--
-- Author: thisgf
-- Date: 2014-12-17 17:40:35
-- 战斗回放界面

require "HeadIcon"
require "BattleStatisticView"

BattlePlaybackView = class("BattlePlaybackView", AbstView.create)

BattlePlaybackView._closeButton = nil
BattlePlaybackView._quitButton = nil
BattlePlaybackView._againButton = nil

BattlePlaybackView._allyResultItem = nil
BattlePlaybackView._enemyResultItem = nil

BattlePlaybackView._imageView = nil

BattlePlaybackView._recordView = nil

local _widgetPath = "ui/battleui/battle_playback_1.json"

local BattlePlaybackResultItem

function BattlePlaybackView:ctor()
end

function BattlePlaybackView:init()

    self:_initData()
    self:_initUI()

    self:adjustScal()
end

function BattlePlaybackView:_initData()
end

function BattlePlaybackView:_initUI()

    self:addDefaultShadow()
    self.shadow:setOpacity(200)

    self:_initWidget(_widgetPath)

    self._allyResultItem = BattlePlaybackResultItem:create()
    self._allyResultItem:setPosition(ccp(264, 558))
    self._widgetGroup:addChild(self._allyResultItem)

    self._enemyResultItem = BattlePlaybackResultItem:create()
    self._enemyResultItem:setPosition(ccp(595, 558))
    self._widgetGroup:addChild(self._enemyResultItem)

    local function quitFunc(sender, event)
        if event ~= TOUCH_EVENT_ENDED then
            return
        end

        BattleManager:getInstance():reqBattleEnd()
    end

    self._closeButton = self:_getWidget("button_close", ComponentType.BUTTON)
    self._quitButton = self:_getWidget("button_quit", ComponentType.BUTTON)
    self._closeButton:addTouchEventListener(quitFunc)
    self._quitButton:addTouchEventListener(quitFunc)

    self._againButton = self:_getWidget("button_again", ComponentType.BUTTON)
    self._againButton:addTouchEventListener(function(sender, event)
        if event ~= TOUCH_EVENT_ENDED then
            return
        end

        BattleManager:getInstance():reqBattleEnd()
        BattleManager:getInstance():reqObserveAgain()
        
    end)
    

    self._imageView = self:_getWidget("ImageView_23", ComponentType.IMAGE_VIEW)

    self._recordView = BattleHurtRecordView:create()
    self._recordView:setWideSpace(15)
    self._imageView:addChild(self._recordView)


end

function BattlePlaybackView:open()

    self._recordView:open(self.params)

    self._allyResultItem:setData(self.params.myHeroInfo)

    if self.params.pvType == BattleType.PVP then
        self._enemyResultItem:setVisible(true)
        self._enemyResultItem:setData(self.params.enemyHeroInfo)
    else
        self._enemyResultItem:setVisible(false)
    end

    if self.params.result == BattleResultType.VICTORY then
        self._allyResultItem:setResult(BattleResultType.VICTORY)
        self._enemyResultItem:setResult(BattleResultType.FAIL)
    else
        self._allyResultItem:setResult(BattleResultType.FAIL)
        self._enemyResultItem:setResult(BattleResultType.VICTORY)
    end

end

function BattlePlaybackView:create()
    local pbView = BattlePlaybackView.new()
    pbView:init()
    return pbView
end


BattlePlaybackResultItem = class("BattlePlaybackResultItem", DisplayUtil.newWidget)

BattlePlaybackResultItem._resultLogo = nil

BattlePlaybackResultItem._heroIcon = nil
BattlePlaybackResultItem._levelLabel = nil
BattlePlaybackResultItem._nameLabel = nil

function BattlePlaybackResultItem:ctor()

    local nameBgImage = ImageView:create()
    nameBgImage:loadTexture("bg_light_2.png", UI_TEX_TYPE_PLIST)
    nameBgImage:setScaleX(2.9)
    nameBgImage:setScaleY(0.8)
    nameBgImage:setAnchorPoint(ccp(0, 0.5))
    nameBgImage:setPosition(ccp(15, -10))
    self:addChild(nameBgImage)

    self._heroIcon = HeadIcon:create()
    self._heroIcon:setScale(0.5)
    self:addChild(self._heroIcon)

    self._levelLabel = Label:create()
    self._levelLabel:setColor(ccc3(0xFB, 0xF1, 0xA0))
    self._levelLabel:setFontSize(20)
    self._levelLabel:setAnchorPoint(ccp(0, 0.5))
    self._levelLabel:setPosition(ccp(29, 15))
    self:addChild(self._levelLabel)


    self._nameLabel = Label:create()
    self._nameLabel:setColor(ccc3(0xFB, 0xF1, 0xA0))
    self._nameLabel:setFontSize(20)
    self._nameLabel:setAnchorPoint(ccp(0, 0.5))
    self._nameLabel:setPosition(ccp(29, -10))
    self:addChild(self._nameLabel)

    self._resultLogo = ImageView:create()
    self._resultLogo:setPosition(ccp(-35, 17))
    self:addChild(self._resultLogo)

end

function BattlePlaybackResultItem:setData(data)

    self._heroIcon:setFaceId(data.faceId)
    self._levelLabel:setText(string.format("Lv.%d", data.level))
    self._nameLabel:setText(data.name)

end

function BattlePlaybackResultItem:setResult(value)

    if value == BattleResultType.VICTORY then
        self._resultLogo:loadTexture("i18n_bui_win_logo.png", UI_TEX_TYPE_PLIST)
    else
        self._resultLogo:loadTexture("i18n_bui_lost_logo.png", UI_TEX_TYPE_PLIST)
    end

end

function BattlePlaybackResultItem:create()
    return BattlePlaybackResultItem.new()
end
