--
-- Author: thisgf
-- Date: 2014-06-09 15:42:28
-- 从服务器获取的战斗宝石数据

CombatGemMsg = class("CombatGemMsg")

--序号
CombatGemMsg.id = 0

--宝石类型
CombatGemMsg.gemType = 0

--对应技能类型
CombatGemMsg.forSkillType = 0

function CombatGemMsg:ctor(id, gemType)
	self.id = id
	self.gemType = gemType
	require "BattleStoneEnum"
	self.forSkillType = BattleStoneType.forSkillType[self.gemType]
end

function CombatGemMsg:create(id, gemType)

	local cgm = CombatGemMsg.new(id, gemType)

	return cgm
end