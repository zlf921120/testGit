--
-- Author: thisgf
-- Date: 2014-12-09 16:05:24
-- 战斗中的窗口管理器

require "combatConfig"

BattleWindowManager = class("BattleWindowManager")

BattleWindowManager._windowSeedDict = nil

BattleWindowManager._windowDict = nil

BattleWindowManager._windowLayer = nil

local _instance

function BattleWindowManager:ctor()

    self._windowDict = {}
    self._windowSeedDict = {}


    self._windowSeedDict[BattleWindowType.SETTLEMENT_VIEW] = BattleSettlementView
    self._windowSeedDict[BattleWindowType.FAIL_VIEW] = BattleFailView
    self._windowSeedDict[BattleWindowType.STATISTIC_VIEW] = BattleStatisticView
    self._windowSeedDict[BattleWindowType.PLAYBACK_VIEW] = BattlePlaybackView

end

function BattleWindowManager:getInstance()
    if not _instance then
        _instance = BattleWindowManager.new()
    end

    return _instance
end

function BattleWindowManager:setWindowLayer(layer)

    self._windowLayer = layer
end

--[[
    打开窗口
]]
function BattleWindowManager:openWindow(wName, wParams)

    local view = self._windowDict[wName]
    if not view then

        local viewSeed = self._windowSeedDict[wName]
        if not viewSeed then
            return
        end

        view = viewSeed:create()
        view:retain()
        self._windowDict[wName] = view
    end

    view:setParam(wParams)
    view:open()
    self._windowLayer:addChild(view)

end

function BattleWindowManager:closeWindow(wName)

    local view = self._windowDict[wName]
    if not view then
        return
    end

    if not view:getParent() then
        return
    end

    view:close()
    view:removeFromParentAndCleanup(false)

end

function BattleWindowManager:closeAllWindow()

    for wName, view in pairs(self._windowDict) do
        if view:getParent() then
            view:close()
        end
        view:removeFromParentAndCleanup(false)
    end

end

