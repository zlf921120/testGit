--
-- Author: thisgf
-- Date: 2014-06-09 14:04:53
-- 战斗管理器

require "IManager"
require "ResContendData"
require "HeroManager"

BattleManager = class("BattleManager", IManager:create())

--参战者ID种子
BattleManager._fighterIdSeed = 0

--是否战斗中
BattleManager._isBattle = false

--是否等待战斗回应
BattleManager._isWaitRsp = false

--每次最大付费抽奖次数
BattleManager.MAX_PAY_LOTTERY = 1

--付费抽奖消耗钻石
BattleManager.PAY_LOTTERY_COST_DIAMOND = 30


--初始化的宝石列表
BattleManager._initGemList = nil
BattleManager._initGemLen = 0

--等待的宝石列表
BattleManager._waitGemList = nil
BattleManager._waitIndex = 0

--等待的宝石每回合出现的个数列表
BattleManager._waitGemNumList = nil
BattleManager._waitGemNumIndex = 0


--是否宝藏副本
BattleManager._treasureDungeonType = nil

--宝箱副本物品列表
BattleManager._treasureItemList = nil
--宝箱副本物品索引
-- BattleManager._treasureItemIndex = 0


--战斗结果类型
BattleManager._resultType = -1

--付费抽奖次数
BattleManager._numPayLottery = 0

--战斗开始数据
BattleManager._startData = nil

--战斗结果数据
BattleManager._resultData = nil

--免费奖励物品列表
BattleManager._freeAwardItemList = nil

--付费奖励物品列表
BattleManager._payAwardItemList = nil

--是否有进入剧情
BattleManager._hasIntoPlot = false

--是否自动战斗
BattleManager._isAutoPlay = false

--是否暂停战斗
BattleManager._isPause = nil

--过程数据
BattleManager._processData = nil

--战斗第几波
BattleManager._waveIndex = 0

--当前回合数
BattleManager._roundIndex = 0


BattleManager._reportData = nil
BattleManager._reportRawData = nil

BattleManager._isOB = false
BattleManager._rm = nil

BattleManager._randSeed = 0
BattleManager._recordKey = ""

BattleManager._onNetworkErrorFunc = nil

--是否暂停加速
BattleManager._isPauseAccelerate = false

--当前游戏加速
BattleManager._currentTimeScale = 1

--游戏加速最大值
BattleManager._maxTimeScale = 1
--是否能加速
BattleManager._canAccelerate = false
--是否显示加速
BattleManager._showAccelerate = false

BattleManager._encryptMask = 0
BattleManager._lastPkg = nil
BattleManager._lastPkgCmd = 0

BattleManager._srvBattleType = -1


local _instance = nil
local _allowInstance = false

function BattleManager:ctor()

	if not _allowInstance then
		error("BattleManager is a singleton class")
	end

	self._logPrefix = "戰鬥調試"
	self:_requireFile()

	self._rm = BattleReportManager:getInstance()

	self:registerNetCmdCallback()

	self._onNetworkErrorFunc = function()
	    self._isWaitRsp = false
	end

end

function BattleManager:getInstance()

	if not _instance then
		_allowInstance = true
		_instance = BattleManager.new()
		_allowInstance = false
	end

	return _instance

end

function BattleManager:_requireFile()

	require "proto_cmd_pb"
	require "combat_pb"
	require "error_code_pb"

	require "CharacterManager"
	require "ItemManager"
	require "CombatGemMsg"
	require "ItemHelper"
	require "Item"
	require "BattleResultData"
	require "DungeonManager"
	require "combatDataStorage"
	require "combatConfig"
	require "battleInterface"
	require "TeamEnum"
	require "OtherRoleInfo"
	require "GuideDataProxy"
	require "BattleReportManager"
	require "CombatVO"

end

--重置数据
function BattleManager:_resetData()

	self._numPayLottery = 0
	self._startData = nil
	self._resultData = nil

	self._isAutoPlay = false

	self._waveIndex = 0

	self._roundIndex = 0

	self._isOB = false

	self._isPause = false

	self._isPauseAccelerate = false
	self._currentTimeScale = 1
	self._maxTimeScale = 1
	self._canAccelerate = false

end

--[[
    请求开始战斗
    @param id 副本id
    @param subId
    @param teamType 战队类型 @see TeamType
    @param 额外参数 {roleId=roleId, ...}
]]
function BattleManager:reqBattleStart(id, subId, teamType, params)

	-- if self._resultData then
	-- 	LuaCollect(false)
	-- else
	-- 	LuaCollect(true)
	-- end

	if self._isWaitRsp then
		return
	end

	self._isWaitRsp = true
	Notifier.regist(CmdName.ERR_SERVER, self._onNetworkErrorFunc)
	--防止超时
	TimerManager.addTimer(20000, self._onNetworkErrorFunc, false)

	if not self:_validBattleStart(BattleType.DUNGEON) then
		return
	end

	params = params or {}

	local id = id
	local subId = subId

	local initData = CombatDataStorage:getInstance():getCombatInitData(id, subId)
	if not initData then
		self:log("無法找到此戰鬥配置資料, id:%d, subId:%d", id, subId)
		return
	end

	self._startData = initData
	self._startData.teamType = teamType or TeamType.Normal
	self._startData.roleId = params.roleId
	self._startData.resDungeonStatus = nil

	local battleType = 0
	

	if initData.battleType == BattleType.DUNGEON then
		battleType = combat_pb.combat_info.normal_dungeon
	elseif initData.battleType == BattleType.CLIMBING then
		battleType = combat_pb.combat_info.climbing
	elseif initData.battleType == BattleType.ARENA then
		battleType = combat_pb.combat_info.arena
	elseif initData.battleType == BattleType.GLORY_ROAD then
		battleType = combat_pb.combat_info.glory
	elseif initData.battleType == BattleType.GUILD_BOSS then
		battleType = combat_pb.combat_info.guild_boss
	elseif initData.battleType == BattleType.GUILD_FIGHT then
		battleType = combat_pb.combat_info.guild_combat
	elseif initData.battleType == BattleType.RES_DUNGEON then
		battleType = combat_pb.combat_info.res_dungeon
	elseif initData.battleType == BattleType.RIDDLE_DUNGEON then
		battleType = combat_pb.combat_info.puzzle_dungeon
	elseif initData.battleType == BattleType.SKY_WAR then
		battleType = combat_pb.combat_info.sky_battle
	elseif initData.battleType == BattleType.FRIEND then
		battleType = combat_pb.combat_info.challenge_friend
	else
		battleType = combat_pb.combat_info.other
	end

	local startReq = combat_pb.combat_start_req()
	startReq.info.type = battleType
	-- if initData.battleType ~= BattleType.FRIEND then
		startReq.info.dun_id = id
	-- end

	if initData.battleType == BattleType.GLORY_ROAD then
		startReq.info.dun_difficulty = params.level
	else
		startReq.info.dun_difficulty = subId
	end

	if initData.battleType == BattleType.ARENA or 
		initData.battleType == BattleType.SKY_WAR or
		initData.battleType == BattleType.FRIEND then
		print("uin=", params.roleId.uin)
		print("channel_id=", params.roleId.channel_id)
		print("zone_id=", params.roleId.zone_id)
		startReq.info.target_id.uin = params.roleId.uin
		startReq.info.target_id.channel_id = params.roleId.channel_id
		startReq.info.target_id.zone_id = params.roleId.zone_id
	elseif initData.battleType == BattleType.GUILD_BOSS then

		startReq.info.boss_id = params.bossId
		self._startData.boss = {id = params.bossId, hp = params.bossHp}
	elseif initData.battleType == BattleType.GUILD_FIGHT then
		startReq.info.target_id.uin = params.roleId.uin
		startReq.info.target_id.channel_id = params.roleId.channel_id
		startReq.info.target_id.zone_id = params.roleId.zone_id
		self._startData.fightArea = params.fightArea
		self._startData.cheerPercent = params.cheerPerc/100
	end

	local cm = CharacterManager:getInstance()

	--未登录
	--[[
	if cm:getLoginData():getAcctId() == 0 then

		self:simulateGenerateGem()

	else
		Global:sendPkg(proto_cmd_pb.msg_cmd.combat_start_req, startReq:SerializeToString(), startReq:ByteSize())
	end
	]]--

	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.combat_start_rsp, "onBattleStartRsp()")
	self:sendProto(startReq)

end

--[[
    请求战斗测试
]]
function BattleManager:reqBattleTest(initData)

	if not self:_validBattleStart(BattleType.DUNGEON) then
		return
	end

	self._isBattle = true

	self._startData = initData
	self._startData.test = true
	self._startData.teamType = TeamType.Normal

	local heroList = TeamManager:getInstance():getBattleHeroList(
		self._startData.teamType
	)

	local battleRoleData = BattleEncryptRoleData:create()
	local battleHeroData

	for pos, heroId in pairs(heroList) do
		battleHeroData = BattleEncryptHeroData:create()
		rawHeroData = HeroManager:getInstance():getHeroInfoByBaseId(
			heroId
		)
		battleHeroData.id = heroId
		battleHeroData.base_id = rawHeroData.base_id
		battleHeroData.animat_res_id = rawHeroData.animat_res_id
		battleHeroData.icon_res_id = rawHeroData.icon_res_id
		battleHeroData.img_res_id = rawHeroData.img_res_id 		
		battleHeroData.pos = rawHeroData.pos
		battleHeroData.race = rawHeroData.race
		battleHeroData.atk_type = rawHeroData.atk_type
		battleHeroData.cur_lev = rawHeroData:getCurLevel()
		battleHeroData.default_skills = rawHeroData.default_skills 		
		battleHeroData.pas_skills = rawHeroData.pas_skills
		battleHeroData.modelId = rawHeroData:getModelId()
		local attrs = {}
		HeroManager:getInstance():setHeroAtkAttr(
			rawHeroData.base_id, 
			attrs, 
			self._startData.teamType
		)
		attrs.hp_cur = attrs.hp
		battleHeroData:getEncryptAttrData():setIsEncrypt(false)
		battleHeroData:getEncryptAttrData():setClientAttrs(attrs)
		battleRoleData.heroDict[heroId] = battleHeroData
	end
	self._startData.selfRoleData = battleRoleData

	self:_initStartParam()

	self:simulateGenerateGem()

	self:_enterBattle()

	Notifier.dispatchCmd(CmdName.BATTLE_RSP_START)

end

--[[
    请求剧情战斗
]]
function BattleManager:reqBattlePlot()

	if not self:_validBattleStart(BattleType.PLOT) then
		return
	end

	self._isBattle = true

	local initData = CombatDataStorage:getInstance():getCombatInitData(50000, 1)

	self._startData = initData
	self._startData.test = true
	self._startData.teamType = TeamType.PLOT

	self:_initStartParam()

	-- self:simulateGenerateGem()

	self._initGemList = GuideDataProxy:getInstance():getInitGemList()
	self._initGemLen = #self._initGemList

	self._waitGemList = GuideDataProxy:getInstance():getWaitGemList()
	self._waitGemNumList = GuideDataProxy:getInstance():getWaitGemNumList()
	self._waitIndex = 0
	self._waitGemNumIndex = 0

	self:_checkHasPrePlot()

	self:_enterBattle()

	Notifier.dispatchCmd(CmdName.BATTLE_RSP_START)

end

--[[
    请求观战
]]
function BattleManager:reqBattleObserve(reportData)

	if not self:_validBattleStart(BattleType.OBSERVE) then
		return
	end

	local function compareVersion(version, oldVersion)

		if not oldVersion then
			return true
		end

		local vl = Utils.split(version, ".")
		local ovl = Utils.split(oldVersion, ".")
		if tonumber(vl[1]) > tonumber(ovl[1]) then
			return true
		end

		return false
	end

	if compareVersion(BattleReportManager.VERSION, reportData.version) then
		Alert:show("此錄影已過期, 無法觀看")
		return
	end

	self._reportRawData = reportData

	self._reportData = BattlePlayReportData:create()
	self._reportData:setSeedData(reportData)

	self._processData = BattleProcessData:create()

	self._isOB = true
	self._isBattle = true

	local initData = CombatDataStorage:getInstance():getCombatInitData(reportData.id, reportData.subId)
	self._startData = initData
	self._startData.resDungeonStatus = reportData.resDungeonStatus

	self._processData:setPvType(reportData.pvType)
	self._processData:setWaveTotalIndex(#self._startData.waveList)
	self._processData:setNextWave()

	self:_enterBattle()

	Notifier.dispatchCmd(CmdName.BATTLE_RSP_START)

end

--[[
    请求再次观战
]]
function BattleManager:reqObserveAgain()
	if not self._reportRawData then
		return
	end

	self:reqBattleObserve(self._reportRawData)
end

--[[
    校验战斗开始
]]
function BattleManager:_validBattleStart(reqType)

	if self._isBattle then
		return false
	end

	if reqType ~= BattleType.PLOT and
		reqType ~= BattleType.OBSERVE and
		table.maxn(TeamManager:getInstance():getBattleHeroList(TeamType.Normal)) == 0 then
		self:log("發起戰鬥失敗, 無上陣英雄")
		return false
	end

	self:_resetData()

	if not self._battleInterface then
		--解析配置数据
		CombatDataStorage:getInstance():parseConfigData()
		self._battleInterface = BattleInterface:create()
	end

	return true

end

function BattleManager:_checkHasPrePlot()
	if self._startData.battleType == BattleType.DUNGEON or 
	   self._startData.battleType == BattleType.PLOT then
    	--是否有进入剧情
    	local eventId = GuideDataProxy:getInstance():isHasPerStoryDungeon(_instance._startData.id, _instance._startData.subId)
    	if eventId ~= nil then
	    	_instance._hasIntoPlot = true		
    	end
    end

end

--初始化开始参数
function BattleManager:_initStartParam()

	self._processData = BattleProcessData:create()

	local battleType = self._startData.battleType

	local pvType
	local allyAttackFirst

	if battleType == BattleType.ARENA or
	   battleType == BattleType.GLORY_ROAD or 
	   battleType == BattleType.GUILD_FIGHT or 
	   battleType == BattleType.SKY_WAR or
	   battleType == BattleType.FRIEND then
	    
	    pvType = BattleType.PVP

	    local allyAgility = 0

	    -- local teamSkillData = TeamManager:getInstance():getTeamSkillData(TeamSkillID.AGILITY)
	    -- if teamSkillData then
	    -- 	allyAgility = teamSkillData.agility
	    -- end

	    local decryptId
	    local decryptLevel
	    for i, v in ipairs(self._startData.teamSkills) do
	    	decryptId = self:getDecryptValue(v.id)
	    	decryptLevel = self:getDecryptValue(v.lev)
	    	if decryptId == TeamSkillID.AGILITY then
		    	local tsData = TeamManager:getInstance():getConfigSkillData(
		    		decryptId, 
		    		decryptLevel
		    	)
		    	if tsData then
		    		allyAgility = tsData.agility
		    	end
		    	break
		    end
	    end

	    local enemyAgility = self._startData.otherRoleInfo.agility

	    if allyAgility == enemyAgility then
	    	if math.random(1, 100) > 50 then
	    		allyAttackFirst = true
	    	else
	    		allyAttackFirst = false
	    	end
	    else
	    	allyAttackFirst = allyAgility > enemyAgility
	    end

	else

	    pvType = BattleType.PVE

	    allyAttackFirst = true
	end

	self._processData:setPvType(pvType)
	print("pve", #self._startData.waveList)
	print("pve", #self._startData.waveList)
	print("pve", #self._startData.waveList)
	print("pve", #self._startData.waveList)
	self._processData:setWaveTotalIndex(#self._startData.waveList)
	self._processData:setNextWave()
	self._processData:setAllyAttackFirst(allyAttackFirst)

	self._treasureDungeonType = nil
	if battleType == BattleType.DUNGEON then
		local dungeonData = DungeonManager:getInstance():getDungeonData(
			self._startData.id, 
			self._startData.subId
		)

		if dungeonData and dungeonData:getType() == DungeonEnumType.Treasure then
			self._treasureDungeonType = self._treasureItemList[1].mode.item_type
		end

	end

	--添加观战信息
	self._rm:reset()
	
	self._rm:setInitData({
		pvType = pvType,
		id = self._startData.id,
		subId = self._startData.subId,
		resDungeonStatus = self._startData.resDungeonStatus
	})

end

function BattleManager:_enterBattle()

	local battleType = self._startData.battleType

	self._canAccelerate = false

	if self._isOB then
		self._canAccelerate = true
		self._maxTimeScale = 3
		self._showAccelerate = true
	else
		if battleType == BattleType.ARENA or 
		   battleType == BattleType.GUILD_FIGHT or
		   battleType == BattleType.GLORY_ROAD or 
		   battleType == BattleType.SKY_WAR or 
		   battleType == BattleType.FRIEND then
		   self._canAccelerate = false
		   self._showAccelerate = false
		else

			self._showAccelerate = true

			local vipLevel = CharacterManager:getInstance():getBaseData():getVipLv()
			local maxScale = 1

			if vipLevel >= 3 then
				maxScale = 3
			elseif vipLevel >= 1 then
				maxScale = 2
			end

			self._maxTimeScale = maxScale

			if self._maxTimeScale > 1 then
				self._canAccelerate = true
			end
		end
	end

	BattleController:getInstance():beginBattle()

	self._battleInterface:beginBattle()

end

--[[
    请求战斗结束
]]
function BattleManager:reqBattleEnd()

	self._lastPkg = nil
	self._lastPkgCmd = 0

	self._hasIntoPlot = false

	self:reqAddAwardToBackpack(BattleAwardType.FREE)

	self._isBattle = false

	BattleStatisticManager:getInstance():clearData()

	BattleController:getInstance():endBattle()
	self._battleInterface:endBattle()

	self:pauseAccelerate()

	Notifier.dispatchCmd(CmdName.BATTLE_RSP_END)

end

--[[
	战斗中途请求宝石
]]
function BattleManager:reqGem()

	self:log("中途請求寶石")

	local gemReq = combat_pb.combat_gem_req()

	self:sendProto(gemReq)

end

--模拟创建宝石
function BattleManager:simulateGenerateGem()

	self._initGemLen = 10

	_instance._initGemList = {}

	local gemType = 0
	local randomValue = 0

	local initGemList = {2, 2, 3, 1, 3, 3, 1, 3, 2, 1}

    for i = 1, self._initGemLen do

	    -- local gemMsg = self:_simluateRandomGem(i)
	    local gemMsg = CombatGemMsg:create(i, initGemList[i])

		table.insert(_instance._initGemList, gemMsg)

    end

    self:simulateGenerateWaitGem()

end

--模拟产生宝石
function BattleManager:simulateGenerateWaitGem()

	local gemType = 0
	local gemIndex = 0
	local gemNum = 0
	local randomValue = 0

	_instance._waitIndex = 0
	_instance._waitGemNumIndex = 0

	_instance._waitGemList = {}
	_instance._waitGemNumList = {}

    for i = 1, 500 do

    	if gemNum == 0 then

    		gemIndex = 0
    		gemNum = math.random(8, 10)

    		table.insert(_instance._waitGemNumList, gemNum)

    	end

    	gemIndex = gemIndex + 1

    	if gemIndex >= gemNum then
    		gemNum = 0
    	end

		gemMsg = self:_simluateRandomGem(i)

		table.insert(_instance._waitGemList, gemMsg)

    end

end

function BattleManager:_simluateRandomGem(index)

	local randomValue = math.random()
	local gemType
	if randomValue < 0.5 then
		gemType = BattleStoneType.colorType.RED
	elseif randomValue < 0.6 then
		gemType = BattleStoneType.colorType.BLUE
	elseif randomValue < 0.7 then
		gemType = BattleStoneType.colorType.PURPLE
	elseif randomValue < 0.8 then
		gemType = BattleStoneType.colorType.RED_ADD
	elseif randomValue < 0.9 then
		gemType = BattleStoneType.colorType.BLUE_ADD
	else
		gemType = BattleStoneType.colorType.UNIVERSAL
	end

    local gemMsg = CombatGemMsg:create(index, gemType)

    return gemMsg
end

function BattleManager:registerNetCmdCallback()


	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.combat_gem_rsp, "onGetGemRsp()")

end

--[[
    请求战斗结果
    @param result 0-失败, 1-成功
    @param otherParams 其他参数
]]
function BattleManager:reqBattleResult(result, otherParams)
	print("战斗结果")
	print("战斗结果")
	print("战斗结果")
	print("战斗结果")
	print("战斗结果")
	print("战斗结果")
	self:pauseAccelerate()

	--战斗测试
	if self._startData.test then
		self:reqBattleEnd()
		return
	end

	self:log("請求戰鬥結果%d", result)

	self._resultType = result

	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.combat_result_rsp, "onBattleResultRsp()")

	local deadSummaryData = BattleStatisticManager:getInstance():getDeadSummaryData()

	local resultReq = combat_pb.combat_result_req()
	resultReq.combat_result.combat_result = result
	resultReq.combat_result.dead_nums = deadSummaryData.allyNumDead

    --统计信息
    local battleType = self._startData.battleType
    if battleType == BattleType.GLORY_ROAD or 
    	battleType == BattleType.GUILD_FIGHT  then
        local selfHeros, targetHeros = BattleStatisticManager:getInstance():getTeamHpData()

        local hero_info
        for k, v in pairs(selfHeros) do
            hero_info = resultReq.combat_result.self_heroes:add()
            hero_info.hero_id = k
            hero_info.molecular = v[1]
            hero_info.denominator = v[2]
        end

        for k, v in pairs(targetHeros) do
            hero_info = resultReq.combat_result.target_heroes:add()
            hero_info.hero_id = k
            hero_info.molecular = v[1]
            hero_info.denominator = v[2]
        end
    elseif battleType == BattleType.DUNGEON then
		local dungeonData = DungeonManager:getInstance():getDungeonData(
			self._startData.id, 
			self._startData.subId
		)

		if dungeonData then

			if self._resultType == BattleResultType.VICTORY then
				CharacterManager:getInstance():addRolePhysical(
					-dungeonData._physicalCost
				)
			else
				CharacterManager:getInstance():addRolePhysical(
					-dungeonData._physicalCostFail
				)
			end
		end

	elseif battleType == BattleType.GUILD_BOSS then

		local allyTotalHurt = BattleStatisticManager:getInstance():getAllyTotalHurt()

		resultReq.combat_result.hp.id = self._startData.boss.id
		resultReq.combat_result.hp.att_num = allyTotalHurt
		resultReq.combat_result.hp.att_hp = (
			self:getDecryptValue(self._startData.boss.hp) - otherParams
		)

    end

    if self:getPvType() == BattleType.PVE then

    	local killMonsterInfo
    	for k, v in pairs(deadSummaryData.monsterDeadDict) do

    		killMonsterInfo = resultReq.combat_result.killed_monsters:add()
    		killMonsterInfo.base_id = k
    		killMonsterInfo.num = v

    	end

    end

    resultReq.combat_result.att_num = BattleStatisticManager:getInstance():getEnemyHurtTimes()

    local encryptKey = Global:encryptBattleResult(
    	string.format(
    		"%d%d%d", 
    		self._randSeed, 
    		result,
    		deadSummaryData.allyNumDead
    	)
    )

    resultReq.combat_result.checksum = encryptKey
    resultReq.combat_result.rand_seed = self._randSeed

    self._lastPkg = resultReq
    self._lastPkgCmd = proto_cmd_pb.msg_cmd.combat_result_req

    self:sendProto(resultReq)

    -- ComSender:getInstance():send(proto_cmd_pb.msg_cmd.combat_result_req, resultReq)

end

--[[
    请求付费抽奖
]]
function BattleManager:reqLotteryPayCard()

	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.combat_pay_card_rsp, "onBattleLotteryPayRsp()")

	local payReq = combat_pb.combat_pay_card_req()

	self:sendProto(payReq)

    --test code
	-- Notifier.dispatchCmd(CmdName.BATTLE_PAY_LOTTERY_RSP, error_code_pb.msg_ret.success)

end

--[[
    请求添加奖励到背包
    @param awardType 奖励类型
]]
function BattleManager:reqAddAwardToBackpack(awardType)

	if awardType == BattleAwardType.FREE then

		if not self._freeAwardItemList then
			return
		end

		for i, v in ipairs(self._freeAwardItemList) do

			if ItemManager:getInstance():isVirtualItem(v.mode.base_id) == false then
				ItemManager:getInstance():changeDataByClient(
					v.id, 
					v.mode.base_id, 
					v.quantity, 
					ItemHelper.change_type.add
				)
			end
		end

		self._freeAwardItemList = nil

	elseif awardType == BattleAwardType.PAY then

		if not self._payAwardItemList then
			return
		end

		for i, v in ipairs(self._payAwardItemList) do

			ItemManager:getInstance():changeDataByClient(
				v.id, 
				v.mode.base_id, 
				v.quantity, 
				ItemHelper.change_type.add
			)

		end

		self._payAwardItemList = nil

	end

end



--[[
    请求战斗开始响应
]]
function onBattleStartRsp(protoData)

	if _instance._isBattle then
		return
	end

	_instance._isWaitRsp = false
	Notifier.remove(CmdName.ERR_SERVER, _instance._onNetworkErrorFunc)
	TimerManager.removeTimer(_instance._onNetworkErrorFunc)

	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.combat_start_rsp, "onBattleStartRsp()")

	local startRsp = combat_pb.combat_start_rsp()
	startRsp:ParseFromString(protoData)

	_instance._randSeed = startRsp.rand_seed
	-- _instance._recordKey = startRsp.record_key

	if startRsp.ret ~= error_code_pb.msg_ret.success then
		_instance:log("開始戰鬥失敗:%d", startRsp.ret)
		if error_code_pb.msg_ret.err_not_physical == startRsp.ret then --体力不足直接弹面板
			CharacterNetTask:getInstance():requestCheckBuyPhysical() --请求购买体力
			Notifier.dispatchCmd(CmdName.DUNGEON_UPDATE_RAIDS, nil)
		else
			Helper.showErrMsg(startRsp.ret)
		end
		return
	end
	
	require "GuideEvent"
	if GuideDataProxy:getInstance().nowMainTutroialEventId == 10002 then
		Notifier.dispatchCmd(GuideEvent.StepFinish,"click_startbattle") --新手引导事件
	end

	_instance._srvBattleType = startRsp.info.type

	_instance._isBattle = true
	
	_instance._initGemLen = #startRsp.init_gems

	_instance._initGemList = {}

	_instance._waitIndex = 0
	_instance._waitGemList = {}
	_instance._waitGemNumIndex = 0
	_instance._waitGemNumList = {}

	local gem_msg = combat_pb.combat_gem

	local gemMsg
	local gem

	for i = 1, #startRsp.init_gems do
		
		gem = startRsp.init_gems[i]

		gemMsg = CombatGemMsg:create(gem.id, gem.type)

		table.insert(_instance._initGemList, gemMsg)

	end

	-- test
	-- _instance._initGemList = {}
	-- for i = 1, #startRsp.init_gems do

	-- 	gemMsg = CombatGemMsg:create(i, combat_pb.combat_gem.purple)

	-- 	table.insert(_instance._initGemList, gemMsg)

	-- end
	-- test end

	for i = 1, #startRsp.backup_gems do
		
		gem = startRsp.backup_gems[i]

		gemMsg = CombatGemMsg:create(gem.id, gem.type)

		table.insert(_instance._waitGemList, gemMsg)

	end

	for i = 1, #startRsp.round_gems do

		table.insert(_instance._waitGemNumList, startRsp.round_gems[i])
	end


	_instance._encryptMask = startRsp.encrypt_mask

	local battleRoleData = BattleEncryptRoleData:create()
	local battleHeroData
	local rawHeroData
	--上阵英雄
	for i, v in ipairs(startRsp.self_info.heroes) do
		battleHeroData = BattleEncryptHeroData:create()
		rawHeroData = HeroManager:getInstance():getHeroInfoByBaseId(v.hero_id)
		battleHeroData.id = v.hero_id
		battleHeroData.base_id = rawHeroData.base_id
		battleHeroData.animat_res_id = rawHeroData.animat_res_id
		battleHeroData.icon_res_id = rawHeroData.icon_res_id
		battleHeroData.img_res_id = rawHeroData.img_res_id 		
		battleHeroData.pos = rawHeroData.pos
		battleHeroData.race = rawHeroData.race
		battleHeroData.atk_type = rawHeroData.atk_type
		battleHeroData.cur_lev = rawHeroData:getCurLevel()
		battleHeroData.default_skills = rawHeroData.default_skills 		
		battleHeroData.pas_skills = rawHeroData.pas_skills
		battleHeroData.modelId = rawHeroData:getModelId()
		battleHeroData:getEncryptAttrData():setIsEncrypt(true)
		battleHeroData:getEncryptAttrData():setServerAttrs(v.attrs)
		battleRoleData.heroDict[v.hero_id] = battleHeroData

	end
	_instance._startData.selfRoleData = battleRoleData

	_instance._startData.teamSkills = {}
	--战队技能
	for i, v in ipairs(startRsp.self_info.team_skills) do
		_instance._startData.teamSkills[i] = v
	end


	if _instance._startData.battleType == BattleType.GLORY_ROAD or 
		_instance._startData.battleType == BattleType.ARENA or
		_instance._startData.battleType == BattleType.GUILD_FIGHT or
		_instance._startData.battleType == BattleType.SKY_WAR or 
		_instance._startData.battleType == BattleType.FRIEND then

		local client_role_info = OtherRoleInfo:create()
        local server_role_info = startRsp.target

        print("id=",server_role_info.id)
        print("name=",server_role_info.name)
        print("team_lev=",server_role_info.team_lev)
        print("fc=",#server_role_info.heroes)

        client_role_info:setBaseInfo(
        	server_role_info.id, 
        	server_role_info.name, 
            server_role_info.team_lev, 
            server_role_info.fc, 
            server_role_info.face_id, 
            server_role_info.rank, 
            server_role_info.win_num, 
            server_role_info.guild_name,
            server_role_info.sex
        )

        client_role_info:setHeros(server_role_info.heroes)
        client_role_info:setTeamSkills(server_role_info.team_skills)
        client_role_info:setPetAttr(
        	server_role_info.sprite_lev, 
        	server_role_info.sprite_stars
        )

        -- for pos, heroInfo in pairs(client_role_info:getBattleData()) do
        -- 	heroInfo.attrData = BattleEncryptAttrData:create()
        -- 	heroInfo.attrData:setIsEncrypt(true)
        -- 	heroInfo.attrData:setServerAttrs(heroInfo.attrs)
        -- end

        _instance._startData.otherRoleInfo = client_role_info

    elseif _instance._startData.battleType == BattleType.GUILD_BOSS then
    	_instance._startData.boss.hp = startRsp.boss.hp[1].encrypted_hp
    elseif _instance._startData.battleType == BattleType.RES_DUNGEON then

    	if startRsp.info.res_dungeon_status == 0 then
	    else
	    	local guards = {}
	    	for _, guardInfo in ipairs(startRsp.guards) do
	    		local gd = ResContendManager:getInstance():getGuardData(guardInfo.base_id)
	    		gd = clone(gd)
	    		gd.stars = guardInfo.stars
	    		gd.pos = TEAM_POS_FOR_BATTLE_DICT[guardInfo.pos]
	    		gd.exp = guardInfo.exp

	    		-- local attrData = ResGuardAttrData:create()
	    		local attrData = gd:getEncryptAttrData()
	    		attrData:setIsEncrypt(true)
	    		attrData:setServerAttrs(guardInfo.attrs)

	    		-- local attrs = guardInfo.attrs

	    		-- for _, attr in ipairs(attrs) do
	    		-- 	attrData:setData(AttrHelper:getAttrStrFlag(attr.name), attr.val)
	    		-- end

	    		-- gd.attrs = attrData:getAttrs()

	    		guards[gd.pos] = gd

	    	end

	    	_instance._startData.guards = guards
	    end
    	_instance._startData.resDungeonStatus = startRsp.info.res_dungeon_status

	end

	--宝箱副本奖励
	_instance._treasureItemList = {}
	-- _instance._treasureItemIndex = 0

	if startRsp.info.items then
		for i, v in ipairs(startRsp.info.items) do
			local itemModel = ItemManager:getInstance():getItemModelByBaseId(v.base_id)
			if itemModel then
				local item = Item.new()
				if itemModel.item_type == ItemHelper.itemType.diamond then
					item:setItemInfo(v.id, v.base_id, v.quantity/100)
				else
					item:setItemInfo(v.id, v.base_id, v.quantity)
				end

				table.insert(_instance._treasureItemList, item)
			end
		end
	end

	_instance:_checkHasPrePlot()

	_instance:_initStartParam()

	WindowCtrl:getInstance():close(CmdName.Team_View)

	_instance:_enterBattle()

	ComSender:getInstance():dealExtInfo(startRsp.ext)
	
	CharacterManager:getInstance():updateRoleAssets(startRsp.assets)

	Notifier.dispatchCmd(CmdName.BATTLE_RSP_START)

	_instance:reqStartSuccess()

end

--战斗中途获取到宝石
function onGetGemRsp(protoData)

	local gemRsp = combat_pb.combat_gem_rsp()
	gemRsp:ParseFromString(protoData)

	if protoData.ret == error_code_pb.msg_ret.failed then
		_instance:log("中途請求寶石失敗")
		return
	end

	_instance._waitIndex = 0
	_instance._waitGemList = {}
	_instance._waitGemNumIndex = 0
	_instance._waitGemNumList = {}


	local gem

	for i = 1, #gemRsp.backup_gems do
		
		gem = gemRsp.backup_gems[i]

		gemMsg = CombatGemMsg:create(gem.id, gem.type)

		table.insert(_instance._waitGemList, gemMsg)

	end

	for i = 1, #gemRsp.round_gems do

		table.insert(_instance._waitGemNumList, gemRsp.round_gems[i])

	end

	ComSender:getInstance():dealExtInfo(gemRsp.ext)

	Notifier.dispatchCmd(CmdName.BATTLE_RSP_GET_GEM)

end

--战斗结果响应
function onBattleResultRsp(protoData)

	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.combat_result_rsp, "onBattleResultRsp()")

	if _instance._lastPkg then
		if _instance._lastPkgCmd == proto_cmd_pb.msg_cmd.combat_result_req then
			_instance._lastPkg = nil
			_instance._lastPkgCmd = 0
		end
	end

	local resultRsp = combat_pb.combat_result_rsp()
	resultRsp:ParseFromString(protoData)

	_instance:log("戰鬥結果:%d", resultRsp.ret)

	if resultRsp.ret ~= error_code_pb.msg_ret.success then
		--结果响应失败直接退出战斗
		WindowCtrl:getInstance():open(
			CmdName.Comm_MsgBox, {
				txt = "戰鬥結果異常,點擊確定退出",
			    okBtnName = "確定",
			    isSingleBtn = 1,
			    isCloseAnimate = false,
			    okFunc = function()
				    _instance:reqBattleEnd()
				end
		    }
		)
		
		return
	end

	_instance._recordKey = resultRsp.record_key

	_instance._resultData = BattleResultData:create()
	_instance._resultData.resultType = _instance._resultType
	_instance._resultData.numStars = resultRsp.stars_num
	_instance._resultData.settlementType = _instance._startData.settlementType

	if _instance._treasureDungeonType then
		_instance._resultData.isTreasureDungeon = true
	else
		_instance._resultData.isTreasureDungeon = false
	end

	
	local exp = 0
	local heroExp = 0
	-- local gold = resultRsp.mustcoin or 0
	local itemModel
	local gold = 0

	local mustList = resultRsp.must --必定掉落物品
	for i=1,#mustList do
		local mode = ItemManager:getInstance():getItemModelByBaseId(mustList[i].base_id)
		if mode.item_type == ItemHelper.itemType.skill_point then --技能点
			_instance._resultData.skillPoint = mustList[i].quantity
		elseif mode.item_type == ItemHelper.itemType.gold then --必定掉落的金币
			gold = mustList[i].quantity
		end
	end
	
	local item

	for k, v in ipairs(resultRsp.must) do
		itemModel = ItemManager:getInstance():getItemModelByBaseId(v.base_id)
		if itemModel then
			if itemModel.item_type == ItemHelper.itemType.skill_point then
				_instance._resultData.skillPoint = v.quantity
			elseif itemModel.item_type == ItemHelper.itemType.gold then
				gold = v.quantity
			end
		end
	end
	
	_instance._freeAwardItemList = {}
	for k, v in ipairs(resultRsp.reward_info) do

		itemModel = ItemManager:getInstance():getItemModelByBaseId(v.base_id)

		if itemModel then

			if itemModel.item_type == ItemHelper.itemType.team_exp then
				exp = v.quantity
			elseif itemModel.item_type == ItemHelper.itemType.gold and _instance._treasureDungeonType == nil then
				-- gold = v.quantity
			elseif itemModel.item_type == ItemHelper.itemType.hero_exp then
				heroExp = v.quantity
			elseif itemModel.item_type == ItemHelper.itemType.diamond and _instance._treasureDungeonType == nil then
			else

				item = Item.new()
				item:setItemInfo(v.id, v.base_id, v.quantity)
				
				table.insert(_instance._freeAwardItemList, item)
				table.insert(_instance._resultData.itemList, item)
			end 
		end
	end

	_instance._resultData.exp = exp
	_instance._resultData.gold = gold
	_instance._resultData.heroExp = heroExp

	local awardData
	

	-- cclog( "combat result rsp Len:%d", Utils.get_length_from_any_table(resultRsp.free_reward_info) )

	
	for k, v in ipairs(resultRsp.free_reward_info) do

		awardData = BattleAwardCardData:create()
		awardData.isAward = v.is_award

		itemModel = ItemManager:getInstance():getItemModelByBaseId(v.card_info.base_id)
		if itemModel then

			item = Item.new()
			item:setItemInfo(v.card_info.id, v.card_info.base_id, v.card_info.quantity)
			awardData.itemData = item

		end

		table.insert(_instance._resultData.freeAwardList, awardData)

	end

	for k, v in ipairs(resultRsp.pay_reward_info) do

		awardData = BattleAwardCardData:create()
		awardData.isAward = v.is_award

		itemModel = ItemManager:getInstance():getItemModelByBaseId(v.card_info.base_id)

		if itemModel then

			item = Item.new()
			item:setItemInfo(v.card_info.id, v.card_info.base_id, v.card_info.quantity)
			awardData.itemData = item

		end

		table.insert(_instance._resultData.payAwardList, awardData)

	end

	if resultRsp.pay_card_loss_info then
		_instance._resultData.payCardCostType = resultRsp.pay_card_loss_info.type
		_instance._resultData.payCardCostValue = resultRsp.pay_card_loss_info.loss_value
	end

	--更新英雄信息
	local hero_upgrades = resultRsp.hero_upgrades
	local hero_num = #resultRsp.hero_upgrades
	for i=1,hero_num do
		HeroManager:getInstance():upgradeHero(
			hero_upgrades[i].id, 
			hero_upgrades[i].lev,
			hero_upgrades[i].exp
		)
		-- print("英雄ID~~~",hero_upgrades[i].id,"~~~~等級~~~", hero_upgrades[i].lev,"~~~經驗~~~",hero_upgrades[i].exp)
	end

	if resultRsp.res_rob_info then
		_instance._resultData.resContendData = {
		    baseId = resultRsp.res_rob_info.base_id,
		    num = resultRsp.res_rob_info.res
		}
	end

	if resultRsp.ext.sky_battle_info.is_filled then
		_instance._resultData.skywarUpdateScore = resultRsp.ext.sky_battle_info.mark_changed
	end

	CharacterManager:getInstance():updateRoleAssets(resultRsp.assets)
	
	TeamManager:getInstance():_initBaseData(resultRsp.team_base)

	ComSender:getInstance():dealExtInfo(resultRsp.ext)

	Notifier.dispatchCmd(CmdName.BATTLE_RSP_RESULT)

	if _instance._startData.battleType == BattleType.ARENA or 
		_instance._startData.battleType == BattleType.RES_DUNGEON then
		_instance:reqHandleRecord(1, _instance._recordKey)
	end

end

--[[
    付费抽奖响应
]]
function onBattleLotteryPayRsp(protoData)

	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.combat_pay_card_rsp, "onBattleLotteryPayRsp()")

	local payRsp = combat_pb.combat_pay_card_rsp()
	payRsp:ParseFromString(protoData)

	if payRsp.ret ~= error_code_pb.msg_ret.success then
		Helper.showErrMsg(payRsp.ret)
		return
	end

	_instance._numPayLottery = _instance._numPayLottery + 1

	CharacterManager:getInstance():updateRoleAssets(payRsp.assets)

	local itemModel

	local item

	_instance._payAwardItemList = {}

	for i, v in ipairs(payRsp.reward_info) do

		itemModel = ItemManager:getInstance():getItemModelByBaseId(v.base_id)

		if itemModel then

			if ItemManager:getInstance():isVirtualItem(v.base_id) == false then

				item = Item.new()
				item:setItemInfo(v.id, v.base_id, v.quantity)
				table.insert(_instance._payAwardItemList, item)
			end
		end
	end

	ComSender:getInstance():dealExtInfo(payRsp.ext)

	Notifier.dispatchCmd(CmdName.BATTLE_PAY_LOTTERY_RSP, payRsp.ret)

end

function BattleManager:reqUpdateAutoPlay(value)

	if self._isAutoPlay == value then
		return
	end

	if value == true then
		if CharacterManager:getInstance():getTeamData():getLev() < 12 then
			Alert:getInstance():show("自動戰鬥12級開啟")
			return
		end
	end

	self._isAutoPlay = value

	Notifier.dispatchCmd(CmdName.BATTLE_UPDATE_AUTO_PLAY)

end

function BattleManager:reqPause(value)

	if self._isPause == value then
		return
	end

	self._isPause = value

	Notifier.dispatchCmd(CmdName.BATTLE_UPDATE_PAUSE_STATUS)

end

--[[
    请求操作战斗录像
    @param hType 1:上传/2:下载
]]
function BattleManager:reqHandleRecord(hType, recordKey)

	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.combat_record_rsp, "onBattleRecordRsp()")

	local recordReq = combat_pb.combat_record_req()
	recordReq.type = hType
	recordReq.record_key = recordKey
	-- recordReq.record_key = "101@113cr14219980409700957761"
	if hType == 1 then

		local reportStr = BattleReportManager:getInstance():generateReport()
		-- local reportStr = "abcdefg1234"
		local compData = SCompressStrData()
		Global:compressStr(reportStr, compData)
		recordReq.bin_content = compData.cs
		recordReq.size_before_zip = compData.sourceLen
		recordReq.size_after_zip = compData.compressLen
	end

	self:sendProto(recordReq)
	if compData then
		compData:dispose()
		compData = nil
	end

end

function onBattleRecordRsp(protoData)

	local recordRsp = combat_pb.combat_record_rsp()
	recordRsp:ParseFromString(protoData)
	
	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.combat_record_rsp, "onBattleRecordRsp()")
	if recordRsp.ret ~= error_code_pb.msg_ret.success then
		Helper.showErrMsg(recordRsp.ret)
		return
	end

	ComSender:getInstance():dealExtInfo(recordRsp.ext)

	if recordRsp.type == 2 then
		local zipData = SCompressStrData()
		zipData.cs = recordRsp.bin_content
		zipData.sourceLen = recordRsp.size_before_zip
		zipData.compressLen = recordRsp.size_after_zip
		local reportStr = Global:uncompressStr(zipData)

		--test
		-- do
  --           local file = io.open("battle_report.txt", "wb+")
  --           if not file then
  --               print("can't open file")
  --           else
  --               file:write(reportStr)
  --               file:close()
  --           end
  --       end

        repeat
	        
	        local ld = loadstring(reportStr)
        	if not ld then
				Alert:getInstance():show("觀看錄影失敗")
        		break
        	end

			local reportData = ld()

			if not reportData then
				Alert:getInstance():show("觀看錄影失敗")
				break
			end

			print("===============解壓錄影成功")
			_instance:reqBattleObserve(reportData)
			zipData = nil

        until true

	end

end


--[[
    是否剧情控制石头
]]
function BattleManager:isPlotControlStone()

	if self._isBattle == false then
		return false
	end

	if self._startData.battleType == BattleType.DUNGEON or 
	   self._startData.battleType == BattleType.PLOT then
		if GuideDataProxy:getInstance():isControlStoneByTutorial(self._startData.id, self._startData.subId) then
			return true
		end
	end

	return false
end


--[[
    通过id获取宝石
    @param id
    @param listType 1:初始化列表 2:等候列表
]]
function BattleManager:getGemListById(id, listType)
	
	local list

	if listType == 1 then
		list = self._initGemList
	else
		list = self._waitGemList
	end

	local gemMsg
	for i = 1, #list do
		gemMsg = list[i]

		if gemMsg.id == id then
			return gemMsg
		end

	end

	return nil

end

--[[
    获取等候列表中下一个宝石
]]
function BattleManager:getWaitNextGem()

	if self._waitIndex == #_instance._waitGemList then
		self._waitIndex = 0
	end

	self._waitIndex = self._waitIndex + 1

	return self:getGemListById(self._waitIndex, 2)

end

--[[
    获取等候列表中下一个序列的宝石
]]
function BattleManager:getWaitNextSeqGem()

	--到底了
	if self._waitGemNumIndex >= #_instance._waitGemNumList then

		--重置位置
		self._waitGemNumIndex = 0
	end

	self._waitGemNumIndex = self._waitGemNumIndex + 1

	local num = self._waitGemNumList[self._waitGemNumIndex]

	local seq = {}

	for i = 1, num do
		seq[#seq + 1] = self:getWaitNextGem()
	end

	return seq

end

--[[
    获取重置的宝石序列
    @param num 宝石数量
]]
function BattleManager:getResetGemSeq(num)

	local initList = {}

	local seq

	local isEnough = false

	while true do

		seq = self:getWaitNextSeqGem()

		if #seq == 0 then
			break
		end

		for i = 1, #seq do

			initList[#initList + 1] = seq[i]

			if #initList >= num then
				isEnough = true

				break
			end
		end

		if isEnough then
			break
		end

	end

	return initList

end

--[[
    发起战斗成功通知
]]
function BattleManager:reqStartSuccess()

	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.combat_start_success_rsp, "onStartSuccessRsp()")

	local req = combat_pb.combat_start_success_req()
	req.info.type = self._srvBattleType

	self:sendProto(req)

end

function onStartSuccessRsp(pc)
	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.combat_start_success_rsp, "onStartSuccessRsp()")

	local rsp = combat_pb.combat_start_success_rsp()
	rsp:ParseFromString(pc)

	if rsp.ret ~= error_code_pb.msg_ret.success then
		Helper.showErrMsg(rsp.ret)
		return
	end

	ComSender:getInstance():dealExtInfo(rsp.ext)
end

--[[
    获取初始化宝石列表
    @param table
]]
function BattleManager:getInitGemList()
	return _instance._initGemList
end

--[[
    获取初始的宝石长度
    @return
]]
function BattleManager:getInitGemLen()
	return _instance._initGemLen
end

--[[
    获取等待的宝石列表
    @return table
]]
function BattleManager:getWaitGemList()
	return _instance._waitGemList
end


function BattleManager:getNumPayLottery()
	return self._numPayLottery
end

--[[
    获取战斗开始数据
]]
function BattleManager:getStartData()

	return self._startData
end

--[[
    获取战斗结果类型
]]
function BattleManager:getBattleResultType()
	return self._resultType
end

function BattleManager:getBattleResultData()
	return self._resultData
end

--[[
    本场战斗是否有进入剧情
]]
function BattleManager:hasIntoPlot()
	return self._hasIntoPlot
end

--[[
    是否战斗中
]]
function BattleManager:isBattle()
	return self._isBattle
end

--[[
    获取是否自动战斗
]]
function BattleManager:getAutoPlay()
	return self._isAutoPlay
end

--[[
    请求打下一波敌人
]]
function BattleManager:reqFightNextWaveEnemy()

	self._processData:resetRound()
	self._processData:setNextWave()

end

--[[
    获取当前战斗第几波敌人
]]
function BattleManager:getWaveIndex()
	return self._processData:getWaveIndex()
end

--[[
    请求下一个回合
]]
function BattleManager:reqNextRound()
	self._processData:increaseRound()
end

function BattleManager:getRoundIndex()
	return self._processData:getRoundIndex()
end

function BattleManager:getPvType()
	return self._processData:getPvType()
end

--[[
    请求加速
]]
function BattleManager:reqAccelerate()

	if self._canAccelerate == false then
		Alert:show("升級為VIP1即可享受戰鬥加速")
		return
	end
	self._currentTimeScale = self._currentTimeScale + 1

	if self._currentTimeScale > self._maxTimeScale then
		self._currentTimeScale = 1
	end

	if self._isPauseAccelerate == false then
		CCDirector:sharedDirector():getScheduler():setTimeScale(self._currentTimeScale)
	end

	Notifier.dispatchCmd(CmdName.BATTLE_UPDATE_ACCELERATE, self._currentTimeScale)

end

function BattleManager:pauseAccelerate()
	if self._isPauseAccelerate then
		return
	end

	self._isPauseAccelerate = true
	CCDirector:sharedDirector():getScheduler():setTimeScale(1)
end

function BattleManager:resumeAcclerate()
	if not self._isPauseAccelerate then
		return
	end
	
	self._isPauseAccelerate = false
	CCDirector:sharedDirector():getScheduler():setTimeScale(self._currentTimeScale)
end

--[[
    是否己方先出手
]]
function BattleManager:isAllyAttackFirst()
	return self._processData:isAllyAttackFirst()
end

function BattleManager:getProcessData()
	return self._processData
end

function BattleManager:getTreasureItem()

	-- self._treasureItemIndex = self._treasureItemIndex + 1

	local index = BattleStatisticManager:getInstance():getEnemyHurtTimes()

	index = index % #self._treasureItemList

	if index == 0 then
		index = #self._treasureItemList
	end

	return self._treasureItemList[index]

end

--[[
    宝藏副本奖励类型
    @return nil 不是宝藏副本
]]
function BattleManager:getTreasureDungeonType()
	return self._treasureDungeonType
end

--[[
    获取战斗类型
]]
function BattleManager:getType()
	return self._startData.battleType
end

--[[
    是否观战
]]
function BattleManager:getIsOB()
	return self._isOB
end

--[[
    获取战报数据
]]
function BattleManager:getReportData()
	return self._reportData
end

function BattleManager:generateFighterId()
	self._fighterIdSeed = self._fighterIdSeed + 1
	return self._fighterIdSeed
end

function BattleManager:isPause()
	return self._isPause
end

--获取当前速度
function BattleManager:getCurrentSpeed()
	return self._currentTimeScale
end

--是否能加速
function BattleManager:canAccelerate()
	return self._canAccelerate
end

--[[
    是否显示加速
]]
function BattleManager:showAccelerate()
	return self._showAccelerate
end

function BattleManager:getEncryptMask()
	return self._encryptMask
end

function BattleManager:getDecryptValue(encryptValue)
	return MathUtil.decryptNumber(encryptValue, self._encryptMask)
end

function BattleManager:getEncryptValue(rawValue)
	return MathUtil.encryptNumber(rawValue, self._encryptMask)
end

--[[
    区别于普通的重试, 因为怕战斗过程中被顶包了就卡在战斗里面
]]
function BattleManager:sendLastPkg()
    if not self._lastPkg then
    	ComSender:getInstance():sendLastPkg()
    	return
    end

    self:sendProto(self._lastPkg, 1)
end
