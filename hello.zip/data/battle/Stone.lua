
Stone = class("Stone", DisplayUtil.newNode)

Stone.key = nil --表示唯一标记
Stone._type = 0  --类型 @see BattleStoneType.colorType
Stone._forSkillType = 0  --对应技能类型
Stone.data = nil --对应的数据
Stone._adjacencySameList = nil --同类型的石头表
Stone.moveToCallback = nil  --移动完成的回调
Stone.disappearCallback = nil
Stone.disappearCallbackParam = nil

--状态
Stone._status = nil

--是否可用
Stone._enable = true

Stone._sprite = nil

--大能量球
Stone._largeEnergyArmature = nil
--小能量球
Stone._litterEnergyArmature = nil

--加成数值
Stone._additionPercent = 0

Stone._additionLabel = nil

function Stone:ctor(stoneType)

	self._adjacencySameList = {}

	self._type = stoneType
	self._forSkillType = BattleStoneType.forSkillType[self._type]

	local energyList = BattleStoneType.energyNameDict[self._type]
	self._largeEnergyArmature = EffectManager:getInstance():createUIAnimate(energyList[1])
	self:addChild(self._largeEnergyArmature)

	self._litterEnergyArmature = EffectManager:getInstance():createUIAnimate(energyList[2])
	self:addChild(self._litterEnergyArmature)

	self:setContentSize(CCSizeMake(BattleStoneType.stoneSize.WIDTH, BattleStoneType.stoneSize.HEIGHT))

	self:setStatus(BattleStoneType.stoneStatus.NORMAL)

	if self._type == BattleStoneType.colorType.RED_ADD then
		-- self._additionPercent = math.random(5, 10)
		self._additionPercent = 10
		-- local numLabel = CCLabelAtlas:create(10, "ui/digit/bui_red_3_num.png", 20, 25, 48)
		-- numLabel:setPosition(ccp(-27, -10))
		-- local percentLabel = CCSprite:createWithSpriteFrameName("bui_red_percent_label.png")
		-- self._additionLabel = CCNode:create()
		-- self._additionLabel:addChild(percentLabel)
		-- self._additionLabel:addChild(numLabel)
		-- self._additionLabel:setVisible(false)
		-- self:addChild(self._additionLabel)
	elseif self._type == BattleStoneType.colorType.BLUE_ADD then
		-- self._additionPercent = math.random(1, 2)
		self._additionPercent = 2
		-- self._additionLabel = CCSprite:createWithSpriteFrameName("i18n_bui_blue_hp_label.png")
  --       self._additionLabel:setVisible(false)
		-- self:addChild(self._additionLabel)
	end

end

--[[
	设置显示对象的数据
]]
function Stone:setData(stoneData)
	self.data = stoneData
end

--[[
    添加邻接的同类型的石头
]]
function Stone:addAdjacencySameStone(other)

	for _,v in ipairs(self._adjacencySameList) do

		if v.key == other.key then
			return
		end
	end

	table.insert(self._adjacencySameList, other)

end


--[[
	判断是否可以连接的类型
	@return true/false
]]
function Stone:isSameType(other)

	if self._type == BattleStoneType.colorType.UNIVERSAL or 
		other._type == BattleStoneType.colorType.UNIVERSAL then
    	return true
    end

    local skillType = BattleStoneType.forSkillType[self._type]
    local otherSkillType = BattleStoneType.forSkillType[other._type]

    if skillType == otherSkillType then
    	return true
    end

    return false	

end

--[[
	判断类型和是否邻接
]]
function Stone:isAdjacencySameType(other)

	if not self:isSameType(other) then
		return false
	else
		for _,v in ipairs(self._adjacencySameList) do
			if v.key == other.key then
				return true
			end
		end
	end

	return false

end

--[[
   清除同类型的石头表
]]
function Stone:clearSameTypeStones()
	self._adjacencySameList = {}

end

--[[
    显示消失动画
    @param callback 完成回调 callback(self, param)
]]
function Stone:disappear(callback, param)

	local function doneCallback()

		if self.disappearCallback then
			self.disappearCallback(self, self.disappearCallbackParam)
		end

	end

	self.disappearCallback = callback
	self.disappearCallbackParam = param

	self:setStatus(BattleStoneType.stoneStatus.DISAPPEAR)

	local animation = self._largeEnergyArmature:getAnimation()

	local function playFunc(armature, movementType, movementID)
		
		if movementType == ComConstTab.MovementEventType.COMPLETE then

			animation:setMovementEventCallFunc(Helper.tempAction)
			doneCallback()
		end
	end

	animation:setMovementEventCallFunc(playFunc)
	animation:play(BattleStoneType.actionType.XIAO_CHU, -1, -1, 0)

end

function Stone:moveTo(pos, time, callback)

	local function doneCallback()

		if self.moveToCallback then
			self.moveToCallback(self)
		end
	end

	time = time or 0.5

	self.moveToCallback = callback

	local moveAction = CCMoveTo:create(time, pos)
	local easeAction = CCEaseBackOut:create(moveAction)
	local doneAction = CCCallFunc:create(doneCallback)

	self:runAction(CCSequence:createWithTwoActions(easeAction, doneAction))

end

--[[
    播放破碎效果
    @param callback (callback(self.key))
]]
function Stone:playCrush(callback)

	local animation = self._largeEnergyArmature:getAnimation()

	local function playFunc(armature, movementType, movementID)
		
		if movementType == ComConstTab.MovementEventType.COMPLETE then

			animation:setMovementEventCallFunc(Helper.tempAction)
			if callback then
				callback(self)
			end
		end
	end

	animation:setMovementEventCallFunc(playFunc)
	animation:play(BattleStoneType.actionType.PO_SUI, -1, -1, 0)

end

--邻接相同类型的石头列表
function Stone:getAdjacencySameList()
	return self._adjacencySameList
end

function Stone:setAlpha(value)
	-- self._sprite:setOpacity(value)
end

function Stone:setColor(value)
	-- self._sprite:setColor(value)
end

function Stone:getStoneType()
	return self._type
end

--[[
    对应的技能类型
]]
function Stone:getForSkillType()
	return self._forSkillType
end

function Stone:setStatus(value)

	if self._status == BattleStoneType.stoneStatus.DISAPPEAR then
		return
	end

	if self._status == value then
		return
	end

	self._status = value

	-- if self._additionLabel then
	-- 	self._additionLabel:setVisible(false)
	-- end

	if self._status == BattleStoneType.stoneStatus.NORMAL then

		self._largeEnergyArmature:getAnimation():play(BattleStoneType.actionType.DAI_JI)
		self._litterEnergyArmature:getAnimation():play(BattleStoneType.actionType.XUAN_ZHONG)

		self._largeEnergyArmature:setOpacity(BattleStoneType.selectedColor.NORMAL_ALPHA)
		self._litterEnergyArmature:setOpacity(BattleStoneType.selectedColor.NORMAL_ALPHA)
		self._largeEnergyArmature:setColor(BattleStoneType.selectedColor.NORMAL)

		self._litterEnergyArmature:setVisible(true)

	elseif self._status == BattleStoneType.stoneStatus.WAIT_SELECTED then

		self._largeEnergyArmature:setColor(BattleStoneType.selectedColor.NORMAL)
		self._largeEnergyArmature:setOpacity(BattleStoneType.selectedColor.NORMAL_ALPHA)
		self._litterEnergyArmature:setOpacity(BattleStoneType.selectedColor.NORMAL_ALPHA)

		self._largeEnergyArmature:getAnimation():play(BattleStoneType.actionType.XUAN_ZHONG)
		self._litterEnergyArmature:getAnimation():play(BattleStoneType.actionType.DAI_JI)

	elseif self._status == BattleStoneType.stoneStatus.SELECTED then

		self._largeEnergyArmature:setColor(BattleStoneType.selectedColor.SELECTED)

		self._largeEnergyArmature:getAnimation():play(BattleStoneType.actionType.XUAN_ZHONG)
		self._litterEnergyArmature:getAnimation():play(BattleStoneType.actionType.DAI_JI)

		-- if self._additionLabel then
		-- 	self._additionLabel:setVisible(true)
		-- end

	elseif self._status == BattleStoneType.stoneStatus.STOP then

		self._largeEnergyArmature:getAnimation():stop()
		self._litterEnergyArmature:getAnimation():stop()

		self._largeEnergyArmature:setOpacity(BattleStoneType.selectedColor.STOP_ALPHA)
		self._litterEnergyArmature:setOpacity(BattleStoneType.selectedColor.STOP_ALPHA)

	elseif self._status == BattleStoneType.stoneStatus.DISABLE then

		self._largeEnergyArmature:getAnimation():play(BattleStoneType.actionType.BU_KE_XUAN_ZE)
		self._litterEnergyArmature:setVisible(false)

		self._largeEnergyArmature:setOpacity(BattleStoneType.selectedColor.NORMAL_ALPHA)

	elseif self._status == BattleStoneType.stoneStatus.DISAPPEAR then

		self._largeEnergyArmature:setOpacity(BattleStoneType.selectedColor.NORMAL_ALPHA)
		self._litterEnergyArmature:setOpacity(BattleStoneType.selectedColor.NORMAL_ALPHA)
		self._largeEnergyArmature:setColor(BattleStoneType.selectedColor.NORMAL)

	end

end

function Stone:getStatus()
	return self._status
end

function Stone:getAdditionPercent()
	return self._additionPercent
end

function Stone:create(stoneType)

	local stone = Stone.new(stoneType)
	return stone

end

--[[
	释放资源
]]
function Stone:dispose()

	self.disappearCallback = nil
	self.disappearCallbackParam = nil

	self.moveToCallback = nil

	self.data = nil

	self:stopAllActions()

end