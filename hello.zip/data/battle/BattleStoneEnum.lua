--
-- Author: thisgf
-- Date: 2014-09-16 17:01:55
-- 战斗消除石头定义

BattleStoneType = {}

--宝石颜色
BattleStoneType.colorType = 
{
	--红色
	RED = 1,
	--蓝色
	BLUE = 2,
	--紫色
	PURPLE = 3,
	--红色加成
	RED_ADD = 4,
	--蓝色加成
	BLUE_ADD = 5,
	--万能
	UNIVERSAL = 6
}

BattleStoneType.stoneStatus = 
{
	--常态
	NORMAL = 1,
	--等待选择
	WAIT_SELECTED = 2,
	--选中
	SELECTED = 3,
	--未选中
	STOP = 4,
	--消失
	DISAPPEAR = 5,
	--不可用
	DISABLE = 6,
}

BattleStoneType.stoneSize = 
{
	WIDTH = 94,
	HEIGHT = 91,
	SIZE = 94
}

--能量石头名称
BattleStoneType.energyNameDict = {}
BattleStoneType.energyNameDict[BattleStoneType.colorType.RED] = {"nengliangxiaochu_gongji", "nengliangxiaochu_gongji_tubiao"}
BattleStoneType.energyNameDict[BattleStoneType.colorType.BLUE] = {"nengliangxiaochu_fangyu", "nengliangxiaochu_fangyu_tubiao"}
BattleStoneType.energyNameDict[BattleStoneType.colorType.PURPLE] = {"nengliangxiaochu_juesha", "nengliangxiaochu_juesha_tubiao"}
BattleStoneType.energyNameDict[BattleStoneType.colorType.RED_ADD] = {"nengliangxiaochu_gongji_add", "nengliangxiaochu_gongji_add_tubiao"}
BattleStoneType.energyNameDict[BattleStoneType.colorType.BLUE_ADD] = {"nengliangxiaochu_fangyu_add", "nengliangxiaochu_fangyu_add_tubiao"}
BattleStoneType.energyNameDict[BattleStoneType.colorType.UNIVERSAL] = {"nengliangxiaochu_wannengqiu", "nengliangxiaochu_wannengqiu_tubiao"}

BattleStoneType.selectedColor = 
{
	SELECTED = ccc3(64, 64, 128),
    NORMAL = ccc3(255, 255, 255),
    NORMAL_ALPHA = 255,
    STOP_ALPHA = 64
}

--宝石动作类型
BattleStoneType.actionType = 
{
	--待机
	DAI_JI = "daiji",
	--选中
	XUAN_ZHONG = "xuanzhong",
	--消除
	XIAO_CHU = "xiaochu",
	--不可选择
	BU_KE_XUAN_ZE = "bukexuanze",
	--破碎
	PO_SUI = "posui"
}

--对应技能类型
BattleStoneType.forSkillType = {}
BattleStoneType.forSkillType[BattleStoneType.colorType.RED] = BattleStoneType.colorType.RED
BattleStoneType.forSkillType[BattleStoneType.colorType.BLUE] = BattleStoneType.colorType.BLUE
BattleStoneType.forSkillType[BattleStoneType.colorType.PURPLE] = BattleStoneType.colorType.PURPLE
BattleStoneType.forSkillType[BattleStoneType.colorType.RED_ADD] = BattleStoneType.colorType.RED
BattleStoneType.forSkillType[BattleStoneType.colorType.BLUE_ADD] = BattleStoneType.colorType.BLUE
BattleStoneType.forSkillType[BattleStoneType.colorType.UNIVERSAL] = BattleStoneType.colorType.UNIVERSAL

BattleStoneType.level = {}
BattleStoneType.level.LEVEL1 = 3
BattleStoneType.level.LEVEL2 = 6
BattleStoneType.level.LEVEL3 = 9


