--
-- Author: thisgf
-- Date: 2014-07-26 15:11:05
-- 战斗结果数据

BattleResultData = class("BattleResultData")

BattleResultData.resultType = -1

--结算方式
BattleResultData.settlementType = 1

--星星数
BattleResultData.numStars = 0

--奖励的战队经验
BattleResultData.exp = 0

--奖励铜钱
BattleResultData.gold = 0

--奖励英雄经验
BattleResultData.heroExp = 0

--奖励的物品列表
BattleResultData.itemList = nil

--免费奖励列表
BattleResultData.freeAwardList = nil

--付费奖励列表
BattleResultData.payAwardList = nil

--付费抽卡消耗金币/钻石
BattleResultData.payCardCostType = 1
BattleResultData.payCardCostValue = 0

--技能点
BattleResultData.skillPoint = 0

--是否宝藏副本
BattleResultData.isTreasureDungeon = false

--资源掠夺的数量
BattleResultData.resContendData = nil

--天空之役积分变化
BattleResultData.skywarUpdateScore = 0


function BattleResultData:ctor()

	self.itemList = {}

	self.freeAwardList = {}
	self.payAwardList = {}

end

function BattleResultData:create()

	local resultData = BattleResultData.new()

	return resultData
end

--战斗奖励数据
BattleAwardCardData = class("BattleAwardCardData")

BattleAwardCardData.isAward = 0
BattleAwardCardData.itemData = nil


function BattleAwardCardData:create()

	local awardData = BattleAwardCardData.new()

	return awardData
end