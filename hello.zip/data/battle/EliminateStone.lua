--[[
    消除石头
    初始填充规则:
     3
    1
     2
    后续填充规则:
     2
    1
     3
]]

require "DisplayUtil"
require "Stone"
require "StoneVO"
require "BattleStoneEnum"
require "BattleManager"

EliminateStone = class("EliminateStone", DisplayUtil.newLayer)

--初始化成员变量 begin
EliminateStone.touchStone = nil  --点击中的石头
EliminateStone._selectStoneType = nil --选择中的石头类型
EliminateStone._stoneDataList = nil --石头数据列表
EliminateStone._stoneList = nil --显示的石头列表 key存储
EliminateStone._everyRowStoneList = nil --每行的剩余石头列表, 顺序存储
EliminateStone._stoneTypeNumDict = nil --石头类型数量字典
EliminateStone.visitedList = nil --访问中的石头
EliminateStone._isFillComplete = false  --是否填充石头完成
EliminateStone.isTouched = false
EliminateStone.enableSelect = true --是否允许选择石头
EliminateStone.disappearIndex = 0  --消失石头索引
EliminateStone.visitedLen = 0    --访问的长度

EliminateStone._lineList = nil  --线列表
EliminateStone._currentLineList = nil  --当前的线列表

EliminateStone._isShowResult = false --显示结果

EliminateStone._isBeginPlay = false --是否开始

EliminateStone._stoneEffectDict = nil --石头效果

EliminateStone._stoneLayer = nil  --石头层
EliminateStone._connectLineLayer = nil  --连线层
EliminateStone._stoneEffectLayer = nil --石头效果层

EliminateStone.score = 0  --分数

--是否自动选择
EliminateStone._isAutoPlay = false

EliminateStone._playCallFunc = nil

--是否在战斗中
EliminateStone._isBattling = false

--服务器是否响应战斗
EliminateStone._isRspBattleStart = false

--是否需要整理宝石
EliminateStone._isNeedCollectStone = false

--是否需要添加剩余的宝石
EliminateStone._isNeedAddRemainStone = false

EliminateStone._numAdditionStone = 0
EliminateStone._additionPercent = 0

--石头相关收益显示容器
EliminateStone._stoneNumLabelDict = nil
EliminateStone._stoneEffectLabelDict = nil

EliminateStone._stoneGainContainer = nil

EliminateStone._stoneEffectContainer = nil
EliminateStone._stoneAdditionContainer = nil

EliminateStone._stoneRedAddContainer = nil
EliminateStone._stonePurpleAddContainer = nil

EliminateStone._lastNumStoneLabel = nil
EliminateStone._lastEffectStoneLabel = nil

EliminateStone._stoneRedAddLabel = nil
EliminateStone._stonePurpleAddLabel = nil

---------------------
EliminateStone._stoneGainLeftContainer = nil
EliminateStone._stoneGainRightContainer = nil
EliminateStone._stoneTotalAttackContainer = nil

EliminateStone._stoneTypeLogo = nil
EliminateStone._stoneMultiplyLogo = nil

EliminateStone._threeStoneLabel = nil
EliminateStone._sixStoneLabel = nil
EliminateStone._nightStoneLabel = nil

EliminateStone._addPercentLogo = nil
EliminateStone._addPercentSprite = nil

EliminateStone._addAttackPercentLabel = nil
EliminateStone._addHpPercentLabel = nil

EliminateStone._addTotalAttackPercentLabel = nil

EliminateStone._onCountdown = nil
EliminateStone._maxHandleTime = 0


--初始化成员变量 end


local ROW = 3

local MAX_COL = 7
local MIN_COL = 6

--行差异
local COL_DIFF = 0.5

local MAX_STONE = 19

local ROW_DISTANCE = 82
local COL_DISTANCE = 84

local MOVE_TIME = 0.15 --移动的时间

local ELIMINATE_MIN = 3  --最少消除数量

--倒计时
local MAX_COUNTDOWN = 15

local bm = nil


--获取石头的位置
local function getStonePos(row, col)
	return (col - 1) * COL_DISTANCE, (row - 1) * ROW_DISTANCE
end

--[[
    生成石头的key
]]
local function generateStoneKey(row, col)
	return string.format("%s_%s", row, col)
end

function EliminateStone:ctor(...)

	bm = BattleManager:getInstance()

	self:_initData()
	self:_initUI()

	-- self:scheduleUpdateWithPriorityLua(render, 0)

end

function EliminateStone:_initData()
	
	self._lineList = {}
	self._currentLineList = {}

	self._stoneNumLabelDict = {}
	self._stoneEffectLabelDict = {}

	self._stoneEffectDict = {}

	self:initStoneData()

end

--进入战斗
function EliminateStone:enterBattle()

	if self._isBattling == true then
		return
	end

	local function controlStone(value)
		self:setEnableSelect(value)
	end

	Notifier.regist(CmdName.BATTLE_CONTROL_STONE, controlStone)

	self._isRspBattleStart = false
	
	self._isBattling = true

	self._maxHandleTime = BattleManager:getInstance():getStartData().maxHandleTime

	self:onRspBattleStart()

end

--退出战斗
function EliminateStone:quitBattle()

	if self._isBattling == false then
		return
	end

	self._isBattling = false

end


function EliminateStone:onRspBattleStart()

	self._isRspBattleStart = true

	self:_initStoneList()

end

--初始化石头数据
function EliminateStone:initStoneData()

	self._stoneTypeNumDict = {}

	self._stoneDataList = {}
	self._everyRowStoneList = {}

	local stoneData = nil

	local col_off = 0
	local col = 0

	for i = 1, ROW do

		if i % 2 == 0 then
			col = MAX_COL
			col_off = 0
		else
			col = MIN_COL
			col_off = COL_DIFF
		end

		for j = 1, col do

			col = j + col_off
			
			stoneData = StoneVO:create(i, col, generateStoneKey(i, col))

			self._stoneDataList[#self._stoneDataList + 1] = stoneData

		end
	end

    --确定石头周围的石头

	local MAX_ADJACENCY = 6

	for i,v in ipairs(self._stoneDataList) do

		for j, tv in ipairs(self._stoneDataList) do

			if v.key ~= tv.key and 
				(math.abs(v.row - tv.row) <= 1 and 
					math.abs(v.col - tv.col) <= 1) then
				v:addAdjacency(tv)
			end

			if v:getAdjacencyLen() == MAX_ADJACENCY then
				break
			end
		end
	end

end

function EliminateStone:init()

	local function updateTouchStone(x, y)

		local touchStone = nil

		for k, v in pairs(self._stoneList) do

			if DisplayUtil.isTouchWithRadius(v, x, y) then

				touchStone = v

				break
			end

		end

		--未选中
		if not touchStone then
			return 
		end

		-- --已经选择一个石头
		if self.touchStone then

			--不是相邻的石头
			if self.touchStone:isAdjacencySameType(touchStone) == false then
				return
			else
				if self:_validAdjacencyStone(touchStone) == false then
					return
				end
			end

		end

		local hasIndex = 0

		--判断是否已经在选中列表中
		for i,v in ipairs(self.visitedList) do

			if v.key == touchStone.key then

				hasIndex = i

				break	
			end
		end

		if hasIndex ~= 0 then

			--如果是倒数第二个则退回上一个
			if hasIndex == #self.visitedList - 1 then

				self:_removeSelectStone()
			end

		else

			self:_addSelectStone(touchStone)
		end

	end

	local function onTouchBegan(x, y)

		self.visitedList = {}
		self.isTouched = true

		updateTouchStone(x, y)
		
		return true
	end

	local function onTouchMoved(x, y)

		updateTouchStone(x, y)

	end

	local function onTouchEnded(x, y)

		self._isTimeOut = false
		self:_endSelect()

	end

	local function onTouch(event, x, y)
		-- print(event, x, y)

		-- if self._isAutoPlay then
		-- 	self:setAutoPlay(false)
		-- end

		if self.enableSelect == false then
			return
		end

		if event == "began" then
			onTouchBegan(x, y)
		elseif event == "moved" then
			onTouchMoved(x, y)
		elseif event == "ended" then
			onTouchEnded(x, y)
		end

		return true

	end

	self._stoneLayer:setTouchEnabled(true)
	self._stoneLayer:registerScriptTouchHandler(onTouch, false, 0, false)

	-- self:_initStoneList()

end

function EliminateStone:_addSelectStone(touchStone)

	if self.touchStone then

		local startPos = ccp(self.touchStone:getPosition())
		local endPos = ccp(touchStone:getPosition())

		local lineArmature = self:_createLine()
		lineArmature:setPosition(startPos)

		local deg = MathUtil.getAngleWithTwoPoint(startPos, endPos)

		lineArmature:setRotation(MathUtil.rad2deg(deg))

		local lineDist = ccpDistance(startPos, endPos)

		lineArmature:setScale(lineDist / COL_DISTANCE)

	end

	self.visitedList[#self.visitedList + 1] = touchStone

	self.touchStone = touchStone

	self:_updateSelectStoneType()

	touchStone:setStatus(BattleStoneType.stoneStatus.SELECTED)

	if touchStone:getStoneType() == BattleStoneType.colorType.RED_ADD then
		self:_createStoneEffectLogo(touchStone, BattleStoneType.colorType.RED)
	elseif touchStone:getStoneType() == BattleStoneType.colorType.BLUE_ADD then
		self:_createStoneEffectLogo(touchStone, BattleStoneType.colorType.BLUE)
	end

	self:_updateLineAction()

end

function EliminateStone:_removeSelectStone()

	local lastStone = table.remove(self.visitedList)

	if #self.visitedList > 0 then
		self.touchStone = self.visitedList[#self.visitedList]
	end

	self:_updateSelectStoneType()

	lastStone:setStatus(BattleStoneType.stoneStatus.WAIT_SELECTED)

	local line = table.remove(self._currentLineList)
	if line then
		self:_recycleLine(line)
	end

	self:_updateLineAction()

	local effectLogo = self._stoneEffectDict[lastStone.key]
	if effectLogo then
		effectLogo:removeFromParentAndCleanup(true)
		self._stoneEffectDict[lastStone.key] = nil
	end

end

function EliminateStone:_updateLineAction()
	local lineAction = ""
	local lineLen = #self.visitedList
	if lineLen >= BattleStoneType.level.LEVEL3 then
		lineAction = "03"
	elseif lineLen >= BattleStoneType.level.LEVEL2 then
		lineAction = "02"
	else
		lineAction = "01"
	end

	for _, v in ipairs(self._currentLineList) do
		v:getAnimation():play(lineAction)
	end
end

--更新选择的石头类型
function EliminateStone:_updateSelectStoneType()

	local additionLen = 0
	local additionPercent = 0

	self._selectStoneType = -1
	for i, v in ipairs(self.visitedList) do

		if self._selectStoneType == -1 and 
			self:isNormalType(v:getForSkillType()) then
			self._selectStoneType = v:getForSkillType()
		end

		if v:getStoneType() == BattleStoneType.colorType.RED_ADD or 
			v:getStoneType() == BattleStoneType.colorType.BLUE_ADD then
			additionLen = additionLen + 1
			additionPercent = additionPercent + v:getAdditionPercent()
		end

	end

	self._additionPercent = additionPercent
	self._numAdditionStone = additionLen

	for _,v in pairs(self._stoneList) do

		if self:_validAdjacencyStone(v) then
			if v ~= self.touchStone and 
				v:getStatus() ~= BattleStoneType.stoneStatus.SELECTED then
				v:setStatus(BattleStoneType.stoneStatus.WAIT_SELECTED)
			end
		else
			v:setStatus(BattleStoneType.stoneStatus.STOP)
		end
	end

	local selectLen = #self.visitedList


	--处理加成等显示
	if self._selectStoneType == -1 or selectLen < 3 then
		self._stoneGainContainer:setVisible(false)
	else
		self._stoneGainContainer:setVisible(true)
	end

	local colorName
	local effectColorName
	if self._selectStoneType == BattleStoneType.colorType.RED then
		colorName = "red"
	elseif self._selectStoneType == BattleStoneType.colorType.BLUE then
		colorName = "blue"
	else
		colorName = "purple"
	end

	local addPercent = (selectLen - BattleStoneType.level.LEVEL1) * 5 + self._additionPercent

	if addPercent > 0 then
		if self._selectStoneType == BattleStoneType.colorType.RED then
			self._stoneRedAddContainer:setVisible(true)
			self._stoneRedAddLabel:setString(tostring(addPercent))
		    self._stoneEffectContainer:setPosition(ccp(0, 40))
		elseif self._selectStoneType == BattleStoneType.colorType.PURPLE then
			self._stonePurpleAddContainer:setVisible(true)
			self._stonePurpleAddLabel:setString(tostring(addPercent))
		    self._stoneEffectContainer:setPosition(ccp(0, 40))
		else
			self._stoneRedAddContainer:setVisible(false)
			self._stonePurpleAddContainer:setVisible(false)
			self._stoneEffectContainer:setPosition(ccp(0, 0))
		end
	else
		self._stoneRedAddContainer:setVisible(false)
		self._stonePurpleAddContainer:setVisible(false)
		self._stoneEffectContainer:setPosition(ccp(0, 0))
	end

	local numName
	if selectLen < BattleStoneType.level.LEVEL2 then
		numName = 3
	elseif selectLen < BattleStoneType.level.LEVEL3 then
		numName = 6
	else
		numName = 9
	end

	local key = string.format("%s_%d", colorName, numName)
	local numLabel = self._stoneNumLabelDict[key]
	if self._lastNumStoneLabel and self._lastNumStoneLabel ~= numLabel then
		self._lastNumStoneLabel:setVisible(false)
	end

	self._lastNumStoneLabel = numLabel
	self._lastNumStoneLabel:setVisible(true)
	self._lastNumStoneLabel:setString(tostring(selectLen))

	local effectLabel = self._stoneEffectLabelDict[key]
	if self._lastEffectStoneLabel and self._lastEffectStoneLabel ~= effectLabel then
		self._lastEffectStoneLabel:setVisible(false)
	end

	local numWidth = self._lastNumStoneLabel:getContentSize().width

	self._lastEffectStoneLabel = effectLabel
	self._lastEffectStoneLabel:setVisible(true)
	self._lastEffectStoneLabel:setPosition(ccp(numWidth + 5, 0))

	-- local logoName
	-- local multiName

	-- if self._selectStoneType == BattleStoneType.colorType.RED then
	-- 	logoName = "bui_stone_attack_logo.png"
		
	-- elseif self._selectStoneType == BattleStoneType.colorType.BLUE then
	-- 	logoName = "bui_stone_shield_logo.png"
	-- 	multiName = "bui_stone_multi_6.png"
	-- else
	-- 	logoName = "bui_stone_upanisad_logo.png"
	-- 	multiName = "bui_stone_multi_9.png"
	-- end


	-- self._threeStoneLabel:setVisible(false)
	-- self._sixStoneLabel:setVisible(false)
	-- self._nightStoneLabel:setVisible(false)

	-- local stoneLabel = nil

	-- if selectLen < BattleStoneType.level.LEVEL2 then
	-- 	multiName = "bui_stone_multi_3.png"
	-- 	stoneLabel = self._threeStoneLabel
	-- elseif selectLen < BattleStoneType.level.LEVEL3 then
	-- 	multiName = "bui_stone_multi_6.png"
	-- 	stoneLabel = self._sixStoneLabel
	-- else
	-- 	multiName = "bui_stone_multi_9.png"
	-- 	stoneLabel = self._nightStoneLabel
	-- end

	-- stoneLabel:setVisible(true)
	-- stoneLabel:setString(tostring(selectLen))

	-- local labelWidth = stoneLabel:getContentSize().width
	-- self._stoneGainRightContainer:setPosition(ccp(120 + labelWidth - 40, 0))

	-- local function getFrame(name)
	-- 	return CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(name)
	-- end

	-- self._addAttackPercentLabel:setVisible(false)
	-- self._addHpPercentLabel:setVisible(false)
	-- if additionLen > 0 then
	-- 	if self._selectStoneType == BattleStoneType.colorType.RED then
	-- 		self._addPercentLogo:setDisplayFrame(getFrame("bui_stone_attack_logo2.png"))
	-- 		self._addPercentSprite:setDisplayFrame(getFrame("i18n_bui_stone_attack_label.png"))
	-- 		self._addAttackPercentLabel:setString(tostring(additionPercent))
	-- 		self._addAttackPercentLabel:setVisible(true)
	-- 	else
	-- 		self._addPercentLogo:setDisplayFrame(getFrame("bui_stone_shield_logo2.png"))
	-- 		self._addPercentSprite:setDisplayFrame(getFrame("i18n_bui_stone_hp_label.png"))
	-- 		self._addHpPercentLabel:setString(tostring(additionPercent))
	-- 		self._addHpPercentLabel:setVisible(true)
	-- 	end
	-- 	self._addPercentLogo:setVisible(true)
	-- 	self._addPercentSprite:setVisible(true)
	-- else
	-- 	self._addPercentLogo:setVisible(false)
	-- 	self._addPercentSprite:setVisible(false)
	-- end

	-- self._stoneTypeLogo:setDisplayFrame(getFrame(logoName))
	-- self._stoneMultiplyLogo:setDisplayFrame(getFrame(multiName))

end

function EliminateStone:_validAdjacencyStone(stone)

	if self._selectStoneType == -1 or 
	   stone:getForSkillType() == BattleStoneType.colorType.UNIVERSAL or 
	   stone:getForSkillType() == self._selectStoneType then
		   return true
	end

	return false

end

--结束选择
function EliminateStone:_endSelect()

	self._stoneGainContainer:setVisible(false)

	for _, v in pairs(self._stoneEffectDict) do
		v:removeFromParentAndCleanup(true)
	end
	self._stoneEffectDict = {}

	if self.visitedList and 
		#self.visitedList >= ELIMINATE_MIN and 
		self._selectStoneType ~= -1 then

		self.disappearIndex = 0
		self.visitedLen = #self.visitedList
		self:setFillComplete(false)
		self:setBeginPlay(false)

		self:_stopCountdown()

		local selectColor = -1

		local visitedLen = #self.visitedList

		if self._selectStoneType == BattleStoneType.colorType.RED or 
			self._selectStoneType == BattleStoneType.colorType.PURPLE then

			local num = 0
			if visitedLen >= BattleStoneType.level.LEVEL3 then
				num = visitedLen - 9
			elseif visitedLen >= BattleStoneType.level.LEVEL2 then
				num = visitedLen - 6
			else
				num = visitedLen - 3
			end

			local addAttackPercent = num * 5 + self._additionPercent

            if addAttackPercent ~= 0 then

            	self._additionPercent = addAttackPercent

    --         	self._stoneTotalAttackContainer:setVisible(true)
    --         	self._stoneTotalAttackContainer:setPosition(ccp(0, 200))
				-- self._addTotalAttackPercentLabel:setString(tostring(addAttackPercent))

				-- local moveAction = CCEaseBounceOut:create(CCMoveTo:create(0.3, ccp(0, 240)))
				-- local delayAction = CCDelayTime:create(1)
				-- local callAction = CCCallFunc:create(function() 
				-- 		self._stoneTotalAttackContainer:setVisible(false)
				-- 	end)

				-- ActionManager:getInstance():runSequenceActions(
				-- 	self._stoneTotalAttackContainer, 
				-- 	moveAction,
				-- 	delayAction,
				-- 	callAction
				-- )
            end
			
		end


		self._isShowResult = true
		self:_playDisappearStone()

		if self._playCallFunc then
			self._playCallFunc(
				self._selectStoneType, 
				visitedLen, 
				self._additionPercent, 
				self._isTimeOut
			)
		end

	end

	self:resetPlay()

end

function EliminateStone:_playDisappearStone()

	if self._isShowResult == false then
		return
	end

	local function stoneDisappearCallback(stone)

		local stoneData = stone.data
		if stoneData then
			stoneData:bindStoneView(nil)
		end
		--解除绑定
		stone:setData(nil)

		self._stoneList[stone.key] = nil

		stone:dispose()
		stone:removeFromParentAndCleanup(true)

		self.disappearIndex = self.disappearIndex + 1

		if self.disappearIndex >= self.visitedLen then

			self._isShowResult = false

			self:_fillStone()

		end
	end

	for i, stone in ipairs(self.visitedList) do
		stone:disappear(stoneDisappearCallback)
	end

end

--[[
    重置
]]
function EliminateStone:resetPlay()

	if self._isShowResult == false then
		for k, v in pairs(self._stoneList) do
			v:setStatus(BattleStoneType.stoneStatus.NORMAL)
		end
	end

	self.isTouched = false
	-- self.visitedList = {}
	self.touchStone = nil

	for k, v in ipairs(self._currentLineList) do
		self:_recycleLine(v)
	end

	self._currentLineList = {}

	self._numAdditionStone = 0
	self._additionPercent = 0

end

--[[
	设置分数
	@param esNum 消灭的数量
]]
function EliminateStone:setScore(esNum)

	local score = esNum * 10 + math.max(esNum - ELIMINATE_MIN, 0) / 2 * 10

	self.score = self.score + score

	self.scoreLabel:setString("分數 : " .. self.score)

end

--初始化石头列表
function EliminateStone:_initStoneList()

	self._stoneList = {}

	local initGemList = bm:getInitGemList()

	self:_initFillStone(initGemList)

end

--重置石头列表
function EliminateStone:_resetStoneList()

	local initLen = bm:getInitGemLen()

	local initList = bm:getResetGemSeq(initLen)

	if not initList then

		Notifier.regist(CmdName.BATTLE_RSP_GET_GEM, 
			function() 
				self:_resetStoneList() 
				return true 
			end
		)

		return
	end

	local stoneTypeNumDict = {}

	local numUniversal = 0

	local skillType
	for i, gemMsg in ipairs(initList) do

		if gemMsg.forSkillType == BattleStoneType.colorType.UNIVERSAL then

			numUniversal = numUniversal + 1
		else
			skillType = gemMsg.forSkillType

			if stoneTypeNumDict[skillType] then
				stoneTypeNumDict[skillType] = stoneTypeNumDict[skillType] + 1
			else
				stoneTypeNumDict[skillType] = 1
			end
		end

	end

	local minLen = 2^53
	local minType = 0

	for k,v in pairs(stoneTypeNumDict) do

		if self:isNormalType(k) then
			--计算加上万能球
			if v > 0 and v + numUniversal >= ELIMINATE_MIN then
				if v < minLen then

					minLen = v
					minType = k

				end
			end
		end
	end

	if minType == 0 then
		print("------------------原來是你", initLen, #initList)
	else

		local stoneData = nil

		for k, v in pairs(self._stoneList) do

			stoneData = v.data
			if stoneData then
				stoneData:bindStoneView(nil)
			end

			v:setData(nil)
			v:dispose()
			v:removeFromParentAndCleanup(true)

		end

		self._stoneList = {}

		local endIndex = initLen - minLen

		local beginIndex = math.random(1, endIndex)

		local minList = {}

		--找出天命颜色类型的石头
		for i,v in ipairs(initList) do

			if v.forSkillType == minType or 
				v.forSkillType == BattleStoneType.colorType.UNIVERSAL then
				minList[#minList + 1] = i
			end
		end

		-- for i,v in ipairs(minList) do
		-- 	print(i,v)
		-- end

		local tempMsg
		local minIndex = 1

		--交换位置
		for i = beginIndex, beginIndex + minLen - 1 do

			tempMsg = initList[i]
			initList[i] = initList[minList[minIndex]]
			initList[minList[minIndex]] = tempMsg

			minIndex = minIndex + 1

			-- print("-----------", minIndex)

		end

		self:_initFillStone(initList)

	end

end

--初始化填充石头
function EliminateStone:_initFillStone(msgList)

	local stone

	local stoneData = nil

	local initGemList = msgList

	local gemMsg = nil

	local colIndexT = {1, 1, 1}
	local rowOrderList = {2, 1, 3}

	local rowOrderIndex = 1

	local colIndex = 0
	local rowIndex = 1
	local initIndex = 1

	while true do

		if initIndex > #initGemList then
			break
		end

		if colIndexT[1] > MIN_COL and colIndexT[2] > MAX_COL and colIndexT[3] > MIN_COL then
			break
		end

		stoneData = nil

		rowIndex = rowOrderList[rowOrderIndex]

		colIndex = colIndexT[rowIndex]

		if rowIndex % 2 == 0 then

			if colIndex <= MAX_COL then
				stoneData = self:getStoneData(rowIndex, colIndex)
			end
		else
			if colIndex <= MIN_COL then
				stoneData = self:getStoneData(rowIndex, colIndex + COL_DIFF)
		    end
		end

		colIndexT[rowIndex] = colIndexT[rowIndex] + 1
		rowOrderIndex = rowOrderIndex + 1
		if rowOrderIndex > ROW then
			rowOrderIndex = 1
		end

		if stoneData ~= nil then

			gemMsg = initGemList[initIndex]
			initIndex = initIndex + 1

			stone = self:createStone(gemMsg.gemType)

			self:initStone(stone, stoneData)

			self._stoneLayer:addChild(stone)
			
		end

	end

	self:_fillStoneComplete()


end

function EliminateStone:createStone(stoneType)

	local stone = Stone:create(stoneType)

	return stone

end

--创建线条
function EliminateStone:_createLine()

	local lineArmature

	if #self._lineList > 0 then

		lineArmature = table.remove(self._lineList)
		lineArmature:setVisible(true)
	else
		lineArmature = EffectManager:getInstance():createUIAnimate("UInenglianglianxian")
		self._connectLineLayer:addChild(lineArmature)
	end

	lineArmature:getAnimation():playWithIndex(0)
	table.insert(self._currentLineList, lineArmature)
	return lineArmature

end

--回收线
function EliminateStone:_recycleLine(line)

	line:getAnimation():stop()
	line:setVisible(false)
	line:setScale(1)
	table.insert(self._lineList, line)

end

function EliminateStone:_createStoneEffectLogo(stone, stoneType)
	local stoneEffect
	if stoneType == BattleStoneType.colorType.RED then
		local numLabel = CCLabelAtlas:create(10, "ui/digit/bui_red_3_num.png", 20, 25, 48)
		numLabel:setPosition(ccp(-27, -10))
		local percentLabel = CCSprite:createWithSpriteFrameName("bui_red_percent_label.png")
		stoneEffect = CCNode:create()
		stoneEffect:addChild(percentLabel)
		stoneEffect:addChild(numLabel)
	elseif stoneType == BattleStoneType.colorType.BLUE then
		stoneEffect = CCSprite:createWithSpriteFrameName("i18n_bui_blue_hp_label.png")
	end

	if stoneEffect then
		stoneEffect:setPosition(ccp(stone:getPosition()))
		self._stoneEffectLayer:addChild(stoneEffect)
		self._stoneEffectDict[stone.key] = stoneEffect
	end

end

function EliminateStone:initStone(stone, data, isInitPos)

	if isInitPos == nil then
		isInitPos = true
	end

	if isInitPos then
		stone:setPosition(getStonePos(data.row, data.col))
	end

	stone.key = data.key
	stone:setData(data)
	data:bindStoneView(stone)

	self._stoneList[data.key] = stone

end

--重置宝石
function EliminateStone:resetStone(fromData, targetData, stone)

	self._stoneList[fromData.key] = nil
	stone:setData(nil)
	fromData:bindStoneView(nil)

	stone.key = targetData.key
	stone:setData(targetData)
	targetData:bindStoneView(stone)

	self._stoneList[targetData.key] = stone

end

function EliminateStone:_fillStone()

	self._isNeedCollectStone = true

	--剩余的石头索引
	local remainStoneDict = {1 + COL_DIFF, 1, 1 + COL_DIFF}

	local len = 0

	local stone = nil

	local tempData = nil

	local oldIndex = 0

	local moveTable = {}

    --先直塞剩下的石头
	for i,v in ipairs(self._stoneDataList) do

		stone = self._stoneList[v.key]
		if stone then

			if stone.data.row ~= v.row or stone.data.col ~= remainStoneDict[v.row] then

				tempData = self:getStoneData(v.row, remainStoneDict[v.row])

				self:resetStone(v, tempData, stone)

				table.insert(moveTable, stone)

			end

			remainStoneDict[v.row] = remainStoneDict[v.row] + 1

		end
	end

	local moveToLen = #moveTable
	local moveToIndex = 0

	local function moveToCallback(stone)

		moveToIndex = moveToIndex + 1

		if moveToIndex >= moveToLen then

			moveTable = nil

			-- self:_fillStoneComplete()

			self:_collectRemainStone()

		end

	end

	if #moveTable == 0 then
		self:_collectRemainStone()
	else
		for i,v in ipairs(moveTable) do

			v:moveTo(
				ccp(getStonePos(v.data.row, v.data.col)), 
				MOVE_TIME, 
				moveToCallback
			)

		end
	end


end

--整理剩下的石头
function EliminateStone:_collectRemainStone()

	--先统计每行的石头
	self:_countEveryRowStone()

	local numT = {
	    #self._everyRowStoneList[1], 
	    #self._everyRowStoneList[2], 
	    #self._everyRowStoneList[3]
	}

    -- print(numT[1], numT[2], numT[3])

    if numT[2] - numT[1] < 2 and 
    	numT[1] - numT[2] < 1 and 
    	numT[2] - numT[3] < 2 and 
    	numT[3] - numT[2] < 1 then

		self:_collectStoneComplete()

	else

		local stone
		local targetData = nil
		local fromData = nil
		local targetRow = 0
		local targetCol = 0
		local fromRow = 0
		local fromCol = 0

		--先统计每行的石头
		self:_countEveryRowStone()

		if numT[2] - numT[1] > 1 then
		--中间行应该向下移动一个

		    targetRow = 1
		    targetCol = numT[1] + 1 + COL_DIFF

			fromRow = 2
			fromCol = targetCol + COL_DIFF

		elseif numT[2] - numT[3] > 1 then
		--中间行应该向上移动一个

		    targetRow = 3
		    targetCol = numT[3] + 1 + COL_DIFF

			fromRow = 2
			fromCol = targetCol + COL_DIFF

		elseif numT[3] - numT[2] > 0 then
		--上行应该向中间移动一个

		    targetRow = 2
		    targetCol = numT[2] + 1

			fromRow = 3
			fromCol = targetCol + COL_DIFF

		elseif numT[1] - numT[2] > 0 then
		--下行应该向中间移动一个

			targetRow = 2
		    targetCol = numT[2] + 1

			fromRow = 1
			fromCol = targetCol + COL_DIFF

		end

		targetData = self:getStoneData(targetRow, targetCol)
		stone = self:getStone(generateStoneKey(fromRow, fromCol))
		fromData = self:getStoneData(fromRow, fromCol)

		self:resetStone(fromData, targetData, stone)
        
    	local moveRemainLen = 0
		local moveRemainIndex = 0

		local function moveRemainStoneComplete()

			moveRemainIndex = moveRemainIndex + 1

			if moveRemainIndex >= moveRemainLen then

				self:_collectRemainStone()

			end

		end

		--移动剩下的石头
		local function moveAssistStoneComplete()

			local rTargetData = nil
			local moveRemainT = {}

			for i, v in ipairs(self._everyRowStoneList[fromRow]) do
				
				if v.data.col > fromCol then

					-- print("-------------------", v.data.col, fromCol)

					moveRemainLen = moveRemainLen + 1

					rTargetData = self:getStoneData(fromRow, v.data.col - 1)

					self:resetStone(v.data, rTargetData, v)

					table.insert(moveRemainT, v)
				end
			end

			if moveRemainLen == 0 then
				self:_collectRemainStone()
			else
				for i,v in pairs(moveRemainT) do

					v:moveTo(
						ccp(getStonePos(v.data.row, v.data.col)), 
						MOVE_TIME, 
						moveRemainStoneComplete
					)
				end
			end

		end

		stone:moveTo(
			ccp(getStonePos(targetData.row, targetData.col)), 
			MOVE_TIME, 
			moveAssistStoneComplete
		)

	end

end

--统计行宝石数量
function EliminateStone:_countRowStone()

	local stone = nil

	local numRow1 = 0
	local numRow2 = 0
	local numRow3 = 0

	for i,v in ipairs(self._stoneDataList) do

		stone = self._stoneList[v.key]

		if stone then
			if v.row == 1 then
				numRow1 = numRow1 + 1
			elseif v.row == 2 then
				numRow2 = numRow2 + 1
			else
				numRow3 = numRow3 + 1
			end
		end
	end

	return {numRow1, numRow2, numRow3}

end

--整理石头完成
function EliminateStone:_collectStoneComplete()

	self._isNeedCollectStone = false

	if self._isNeedAddRemainStone then
		self:_appendRemainStone()
	end

end

--添加石头到剩余的格子
function EliminateStone:_appendRemainStone()

    if self._isShowResult == true then
    	return
    end

    if self._isNeedCollectStone then
    	return
    end

	local waitGemSeq = bm:getWaitNextSeqGem()
	if not waitGemSeq then
		Notifier.regist(CmdName.BATTLE_RSP_GET_GEM, 
			function()
				self:_appendRemainStone()
			    return true 
			end
		)
		return
	end

    local moveTable = {}
	local gemMsg
	local stoneData

	local moveToLen = 0
	local moveToIndex = 0

	local function moveToCallback(stone)

		moveToIndex = moveToIndex + 1

		if moveToIndex >= moveToLen then

			moveTable = nil

			self:_fillStoneComplete()

		end

	end

	-- local waitGemSeq = bm:getWaitNextSeqGem()

	self:_countEveryRowStone()

	local colIndexT = {
	    #self._everyRowStoneList[1] + 1, 
	    #self._everyRowStoneList[2] + 1, 
	    #self._everyRowStoneList[3] + 1
    }

	local rowOrderList = {2, 3, 1}

	if colIndexT[1] == colIndexT[2] and colIndexT[2] == colIndexT[3] then
		rowOrderList = {2, 3, 1}
	elseif colIndexT[1] == colIndexT[3] and colIndexT[2] > colIndexT[1] then
		rowOrderList = {3, 1, 2}
	elseif colIndexT[1] == colIndexT[2] and colIndexT[2] > colIndexT[3] then
		rowOrderList = {3, 2, 1}
	elseif colIndexT[3] == colIndexT[2] and colIndexT[2] > colIndexT[1] then
		rowOrderList = {1, 2, 3}
	end

	local rowOrderIndex = 1

	local colIndex = 0
	local rowIndex = 1
	local initIndex = 1

	while true do

		if initIndex > #waitGemSeq then
			break
		end

		if colIndexT[1] > MIN_COL and colIndexT[2] > MAX_COL and colIndexT[3] > MIN_COL then
			break
		end

		stoneData = nil

		rowIndex = rowOrderList[rowOrderIndex]
		colIndex = colIndexT[rowIndex]

		if rowIndex % 2 == 0 then

			if colIndex <= MAX_COL then
				stoneData = self:getStoneData(rowIndex, colIndex)
			end
		else
			if colIndex <= MIN_COL then
				stoneData = self:getStoneData(rowIndex, colIndex + COL_DIFF)
		    end
		end

		colIndexT[rowIndex] = colIndexT[rowIndex] + 1
		rowOrderIndex = rowOrderIndex + 1
		if rowOrderIndex > ROW then
			rowOrderIndex = 1
		end

		if stoneData ~= nil then

			gemMsg = waitGemSeq[initIndex]
			initIndex = initIndex + 1

			stone = self:createStone(gemMsg.gemType)

			self:initStone(stone, stoneData, false)

			self._stoneLayer:addChild(stone)

			if self.enableSelect == true then
				stone:setStatus(BattleStoneType.stoneStatus.NORMAL)
			else
				stone:setStatus(BattleStoneType.stoneStatus.DISABLE)
			end

			table.insert(moveTable, stone)

		end

	end

	local targetPos = nil

	moveToLen = #moveTable

	if moveToLen == 0 then
		self:_fillStoneComplete()
	else
		local worldPos = DisplayUtil.getWorldPos(self._stoneLayer)

		for i,v in ipairs(moveTable) do

			v:setPosition(
				DisplayUtil.visibleSize.width - worldPos.x + BattleStoneType.stoneSize.SIZE, 
				(v.data.row - 1) * ROW_DISTANCE
			)

			targetPos = ccp(getStonePos(v.data.row, v.data.col))

			v:moveTo(targetPos, MOVE_TIME, moveToCallback)

		end
	end

end

function EliminateStone:_fillStoneComplete()

	self._isNeedCollectStone = false
	self._isNeedAddRemainStone = false

	self:_findSameTypeStone()
	self:_setStoneTypeNum()
	self:_countEveryRowStone()

	if self:_checkHasConnectStone() then

		self:setFillComplete(true)

		if self._isBeginPlay then
			if self._isAutoPlay then
				self:_autoHelpPlay()
			end
		end
	else
		cclog("----------------------不能愉快的玩耍了")

		self:_playCrushStone()

		-- self:_resetStoneList()
		
	end

end

--播放石头破碎
function EliminateStone:_playCrushStone()

	local index = 1

	local function crushFunc(stone)

		index = index - 1

		if index <= 0 then

			self:_resetStoneList()

		end
	end

	for k, stone in pairs(self._stoneList) do

		index = index + 1
		stone:playCrush(crushFunc)
	end

	crushFunc(nil)

end

--[[
	找出石头周围相同的类型的石头
]]
function EliminateStone:_findSameTypeStone()

	local stoneData = nil
	for k,stone in pairs(self._stoneList) do

		stoneData = stone.data
		if stoneData then

			stone:clearSameTypeStones()

			for _,v in ipairs(stoneData.adjacencies) do

				if v.bindStone and stone:isSameType(v.bindStone) then

					stone:addAdjacencySameStone(v.bindStone)
				end
			end
		end

	end

end

--设置石头各类型数量
function EliminateStone:_setStoneTypeNum()

	self._stoneTypeNumDict = {}

	local forSkillType

	for k,stone in pairs(self._stoneList) do

		forSkillType = stone:getForSkillType()

		if self._stoneTypeNumDict[forSkillType] then
			self._stoneTypeNumDict[forSkillType] = self._stoneTypeNumDict[forSkillType] + 1
		else
			self._stoneTypeNumDict[forSkillType] = 1
		end
	end

end

--统计每行石头
function EliminateStone:_countEveryRowStone()

	self._everyRowStoneList = {}

	for i = 1, ROW do

		self._everyRowStoneList[i] = {}

	end

	local stone

	for i,v in ipairs(self._stoneDataList) do

		stone = self._stoneList[v.key]
		if stone then

			table.insert(self._everyRowStoneList[v.row], stone)

		end
	end

end

function EliminateStone:_initUI()

	self._stoneLayer = CCLayer:create()
	self:addChild(self._stoneLayer, 0)

	self._connectLineLayer = CCLayer:create()
	self:addChild(self._connectLineLayer)

	self._stoneEffectLayer = CCLayer:create()
	self:addChild(self._stoneEffectLayer)

	--普通收益
	self._stoneGainContainer = CCNode:create()
	self._stoneGainContainer:setPosition(ccp(0, 240))
	self:addChild(self._stoneGainContainer)

	self._stoneEffectContainer = CCNode:create()
	self._stoneEffectContainer:setPosition(ccp(0, 40))
	self._stoneGainContainer:addChild(self._stoneEffectContainer)

	self._stoneAdditionContainer = CCNode:create()
	self._stoneAdditionContainer:setPosition(ccp(0, -15))
	self._stoneGainContainer:addChild(self._stoneAdditionContainer)

	self._stoneRedAddContainer = CCNode:create()
	self._stoneRedAddContainer:setVisible(false)
	self._stoneAdditionContainer:addChild(self._stoneRedAddContainer)
	
	self._stonePurpleAddContainer = CCNode:create()
	self._stonePurpleAddContainer:setVisible(false)
	self._stoneAdditionContainer:addChild(self._stonePurpleAddContainer)

	--数字标签
	local colorList = {"red", "blue", "purple"}
	local numList = {
	    BattleStoneType.level.LEVEL1, 
	    BattleStoneType.level.LEVEL2, 
	    BattleStoneType.level.LEVEL3
	}
	local sizeList = {{w = 20, h = 25}, {w = 23, h = 29}, {w = 30, h = 34}}
	local numYList = {-10, -13, -17}
	local numName
	local numLabel
	local effectName
	local effectLabel
	local numKey
	for i = 1, 3 do
		for j = 1, 3 do
			numKey = string.format("%s_%d", colorList[i], numList[j])

			numName = string.format("ui/digit/bui_%s_%d_num.png", colorList[i], numList[j])
			numLabel = CCLabelAtlas:create(i, numName, sizeList[j].w, sizeList[j].h, 48)
			numLabel:setPosition(ccp(0, numYList[j]))
			numLabel:setVisible(false)

			self._stoneNumLabelDict[numKey] = numLabel

			effectName = string.format("i18n_bui_%s_%d_label.png", colorList[i], numList[j])
			effectLabel = CCSprite:createWithSpriteFrameName(effectName)
			effectLabel:setAnchorPoint(ccp(0, 0.5))
			effectLabel:setPosition(ccp(30, 0))
			effectLabel:setVisible(false)
			self._stoneEffectLabelDict[numKey] = effectLabel

			self._stoneEffectContainer:addChild(numLabel)
			self._stoneEffectContainer:addChild(effectLabel)

		end
	end

	local redLabel = CCSprite:createWithSpriteFrameName("i18n_bui_red_add_label.png")
	redLabel:setAnchorPoint(ccp(0, 0))
	self._stoneRedAddContainer:addChild(redLabel)

	local percentLabel = CCSprite:createWithSpriteFrameName("bui_red_percent_label.png")
    percentLabel:setAnchorPoint(ccp(0, 0.5))
    percentLabel:setPosition(ccp(redLabel:getContentSize().width + 10, 20))
	self._stoneRedAddContainer:addChild(percentLabel)

	self._stoneRedAddLabel = CCLabelAtlas:create(1, "ui/digit/bui_red_3_num.png", 20, 25, 48)
	self._stoneRedAddLabel:setAnchorPoint(ccp(0.5, 0))
	self._stoneRedAddLabel:setPosition(
		ccp(
			percentLabel:getPositionX() + 35, 10
		)
	)
	self._stoneRedAddContainer:addChild(self._stoneRedAddLabel)

	local purpleLabel = CCSprite:createWithSpriteFrameName("i18n_bui_purple_add_label.png")
	purpleLabel:setAnchorPoint(ccp(0, 0))
	self._stonePurpleAddContainer:addChild(purpleLabel)

	percentLabel = CCSprite:createWithSpriteFrameName("bui_purple_percent_label.png")
    percentLabel:setAnchorPoint(ccp(0, 0.5))
    percentLabel:setPosition(ccp(redLabel:getContentSize().width + 10, 20))
	self._stonePurpleAddContainer:addChild(percentLabel)

	self._stonePurpleAddLabel = CCLabelAtlas:create(0, "ui/digit/bui_purple_3_num.png", 20, 25, 48)
	self._stonePurpleAddLabel:setAnchorPoint(ccp(0.5, 0))
	self._stonePurpleAddLabel:setPosition(
		ccp(
			percentLabel:getPositionX() + 35, 10
		)
	)
	self._stonePurpleAddContainer:addChild(self._stonePurpleAddLabel)

	-- self._stoneTypeLogo = CCSprite:create()
	-- self._stoneGainContainer:addChild(self._stoneTypeLogo)

	-- self._stoneMultiplyLogo = CCSprite:create()
	-- self._stoneMultiplyLogo:setPosition(ccp(40, 0))
	-- self._stoneGainContainer:addChild(self._stoneMultiplyLogo)

	-- self._threeStoneLabel = CCLabelAtlas:create("", "ui/digit/bui_stone_3_num.png", 32, 40, 48)
	-- self._threeStoneLabel:setAnchorPoint(ccp(0, 0.5))
	-- self._threeStoneLabel:setPosition(ccp(55, 0))
	-- self._stoneGainContainer:addChild(self._threeStoneLabel)

	-- self._sixStoneLabel = CCLabelAtlas:create("", "ui/digit/bui_stone_6_num.png", 36, 46, 48)
	-- self._sixStoneLabel:setAnchorPoint(ccp(0, 0.5))
	-- self._sixStoneLabel:setPosition(ccp(55, 0))
	-- self._stoneGainContainer:addChild(self._sixStoneLabel)

	-- self._nightStoneLabel = CCLabelAtlas:create("", "ui/digit/bui_stone_9_num.png", 40, 46, 48)
	-- self._nightStoneLabel:setAnchorPoint(ccp(0, 0.5))
	-- self._nightStoneLabel:setPosition(ccp(55, 0))
	-- self._stoneGainContainer:addChild(self._nightStoneLabel)

	-- self._stoneGainRightContainer = DisplayUtil.newNode()
	-- self._stoneGainRightContainer:setPosition(ccp(120, 0))
	-- self._stoneGainContainer:addChild(self._stoneGainRightContainer)

	-- self._addPercentLogo = CCSprite:create()
	-- -- self._addPercentLogo:setPosition(ccp(120, 0))
	-- self._stoneGainRightContainer:addChild(self._addPercentLogo)

	-- self._addPercentSprite = CCSprite:create()
	-- self._addPercentSprite:setAnchorPoint(ccp(0, 0.5))
	-- self._addPercentSprite:setPosition(ccp(
	-- 	self._addPercentLogo:getPositionX() + 30, 
	-- 	0)
	-- )
	-- self._stoneGainRightContainer:addChild(self._addPercentSprite)

	-- self._addAttackPercentLabel = CCLabelAtlas:create("", "ui/digit/bui_stone_red_num.png", 20, 26, 48)
	-- self._addAttackPercentLabel:setAnchorPoint(ccp(0.5, 0.5))
	-- self._addAttackPercentLabel:setPosition(ccp(
	-- 	100, 
	-- 	18)
	-- )
	-- self._addPercentSprite:addChild(self._addAttackPercentLabel)

	-- self._addHpPercentLabel = CCLabelAtlas:create("", "ui/digit/bui_stone_blue_num.png", 20, 26, 48)
	-- self._addHpPercentLabel:setAnchorPoint(ccp(0.5, 0.5))
	-- self._addHpPercentLabel:setPosition(ccp(self._addAttackPercentLabel:getPosition()))
	-- self._addPercentSprite:addChild(self._addHpPercentLabel)


	-- --总攻击力加成
	-- self._stoneTotalAttackContainer = CCNodeRGBA()
	-- self._stoneTotalAttackContainer:setPosition(ccp(0, 240))
	-- self._stoneTotalAttackContainer:setVisible(false)
	-- self._stoneTotalAttackContainer:setCascadeOpacityEnabled(true)
	-- self:addChild(self._stoneTotalAttackContainer)

	-- local addTotalAttackLogo = CCSprite:createWithSpriteFrameName("bui_stone_attack_logo2.png")
	-- self._stoneTotalAttackContainer:addChild(addTotalAttackLogo)

	-- local addTotalAttackSprite = CCSprite:createWithSpriteFrameName("i18n_bui_stone_attack_label.png")
	-- addTotalAttackSprite:setAnchorPoint(ccp(0, 0.5))
	-- addTotalAttackSprite:setPosition(ccp(25, 0))
	-- addTotalAttackSprite:setCascadeOpacityEnabled(true)
	-- self._stoneTotalAttackContainer:addChild(addTotalAttackSprite)

	-- self._addTotalAttackPercentLabel = CCLabelAtlas:create("10", "ui/digit/bui_stone_red_num.png", 20, 26, 48)
	-- self._addTotalAttackPercentLabel:setAnchorPoint(ccp(0.5, 0.5))
	-- self._addTotalAttackPercentLabel:setPosition(ccp(98, 18))
	-- addTotalAttackSprite:addChild(self._addTotalAttackPercentLabel)

end

function EliminateStone:setBeginPlay(value)
	
	if self._isBeginPlay == value then
		return
	end

	self._isBeginPlay = value

	self:_checkEnabelSelect()

end

function EliminateStone:setFillComplete(value)

	if self._isFillComplete == value then
		return
	end

	self._isFillComplete = value
	-- print("----------------------", self._isFillComplete)

	self:_checkEnabelSelect()

end

function EliminateStone:_checkEnabelSelect()

	if self._isBeginPlay == true and 
		self._isFillComplete == true and 
		self._isShowResult == false then

		-- --剧情控制
		if BattleManager:getInstance():isPlotControlStone() then
			return
		end
		self:setEnableSelect(true)
	else
		self:setEnableSelect(false)
	end
end

--[[
    锁定选择
    @param value true:锁定/false:解锁 
]]
function EliminateStone:setEnableSelect(value)
	
	if self.enableSelect == value then
		return
	end

	self.enableSelect = value

	if self.enableSelect == true then
		for k, v in pairs(self._stoneList) do
			v:setStatus(BattleStoneType.stoneStatus.NORMAL)
		end
	else
		for k, v in pairs(self._stoneList) do
			v:setStatus(BattleStoneType.stoneStatus.DISABLE)
		end
	end

end

--[[
    获取一个石头
]]
function EliminateStone:getStone(key)

	for _, v in pairs(self._stoneList) do
		if v.key == key then
			return v
		end
	end

	return nil
end

--[[
	获取一个石头数据
]]
function EliminateStone:getStoneData(row, col)
	for i,v in ipairs(self._stoneDataList) do
		if v.row == row and v. col == col then
			return v
		end
	end

	return nil

end


EliminateStone._countdownHandler = nil
EliminateStone._isTimeOut = false

function EliminateStone:_countdown()

	self._currentTime = self._currentTime + 1

	if self._currentTime <= self._maxHandleTime then
		return
	end

	self:_stopCountdown()

	self._isTimeOut = true
	self:setAutoPlay(true)

end

function EliminateStone:_stopCountdown()

	TimerManager.removeTimer(self._onCountdown)
end

--是否自动玩
function EliminateStone:setAutoPlay(value)

	if self._isAutoPlay == value then
		return
	end

	self._isAutoPlay = value

	if self._isAutoPlay == true then
		if self.enableSelect == true then
			self:_autoHelpPlay()
		end
	end

end

--自动帮玩家选择
function EliminateStone:_autoHelpPlay()

    local adjacencyList

    --访问中的列表
    local visited = {}
    --记录的列表
    local recordList = {}
    --记录的类型列表
    local recordTypeList = {}

    local tempStone = nil
    local stoneType = 0

    visited = self:_getConnectStoneList(true)

    if visited and #visited >= ELIMINATE_MIN then

    	self.visitedList = visited
    	self:_updateSelectStoneType()
    	self:_endSelect()

    else
    	cclog("---------------自動幫玩家選擇沒發現可選寶石%d, %d", stoneType, #visited)
    end

end

--检测是否有可以连接的石头
function EliminateStone:_checkHasConnectStone()

	local visited = self:_getConnectStoneList(false)
	if visited and #visited >= ELIMINATE_MIN then
		return true
	end

	return false
end

--[[
    获取可以连接的石头列表
    @param isLimit 是否获取程序能自动连接最大数量 false最大取三个
    @return
]]
function EliminateStone:_getConnectStoneList(isLimit)

    local adjacencyList

    --访问中的列表
    local visited = {}
    --记录的列表
    local recordList = {}
    --记录的类型列表
    local recordTypeList = {}


    local tempStone = nil
    local stoneType = 0
    

    local function getStoneType()

	    local maxNum = 0
	    local maxNumType = 0

    	local recordType = false

	    for k, v in pairs(self._stoneTypeNumDict) do

	    	recordType = false

	    	for k1, v1 in pairs(recordTypeList) do
	    		if k == v1 then
	    			recordType = true
	    			break
	    		end
	    	end

	    	if not recordType then

		    	if v > maxNum and self:isNormalType(k) then
		    		maxNumType = k
		    		maxNum = v
		    	end
	    	end
	    
	    end

	    if maxNumType ~= 0 then
	    	recordTypeList[#recordTypeList + 1] = maxNumType
	    end

	    return maxNumType

    end

    local function getHeadStone(st)
    	
    	local headStone = nil
    	local record = false

	    for k, v in pairs(self._stoneList) do

	    	record = false
	    	
	    	for k1, v1 in pairs(recordList) do
	    		if v.key == v1.key then
	    			record = true
	    			break
	    		end
	    	end

			if v:getForSkillType() == st and record == false then
				
				headStone = v

				visited[#visited + 1] = headStone
				recordList[#recordList + 1] = headStone

				break
			end
		end

		return headStone

    end

    stoneType = getStoneType()
    tempStone = getHeadStone(stoneType)


	local hasVisited = false
	local nextStone = nil

    while tempStone do

    	adjacencyList = tempStone:getAdjacencySameList()

		nextStone = nil

		for i, v in ipairs(adjacencyList) do

			hasVisited = false
			if v:getForSkillType() ~= stoneType and v:getForSkillType() ~= BattleStoneType.colorType.UNIVERSAL then
				hasVisited = true
			else
				for i1,v1 in ipairs(visited) do

					if v1.key == v.key then
						hasVisited = true

						break
					end
					
				end
			end

			if hasVisited == false then

				nextStone = v

				tempStone = v

				visited[#visited + 1] = tempStone
				recordList[#recordList + 1] = tempStone

				break

			end
			
		end

		if isLimit == false then
			if #visited >= ELIMINATE_MIN then
				break
			end
		end

		--没有找到下一个了
		if not nextStone then
			--够数了
			if #visited >= ELIMINATE_MIN then
				break
			else

				--重置
				visited = {}
				tempStone = getHeadStone(stoneType)
				if not tempStone then

					--拿另外一种类型的石头
					stoneType = getStoneType()
					tempStone = getHeadStone(stoneType)
				end

			end
		end

    end

    return visited

end

--是否普通类型(红蓝紫)
function EliminateStone:isNormalType(stoneType)
	return stoneType == BattleStoneType.colorType.RED or 
           stoneType == BattleStoneType.colorType.BLUE or 
           stoneType == BattleStoneType.colorType.PURPLE
end

--[[
    玩家可以选择石头时调用
]]
function EliminateStone:beginPlay()

	-- print("=======================開始選擇石頭")

	self:setBeginPlay(true)

	if self._isFillComplete then
		if self._isAutoPlay then
			self:_autoHelpPlay()
			return
		end
	else
		if self._isRspBattleStart then

			self._isNeedAddRemainStone = true
			self:_appendRemainStone()
		end
	end

	if self._maxHandleTime > 0 then

		if not self._onCountdown then
			self._onCountdown = function()
			    self:_countdown()
			end
		end

		self._currentTime = 0
		self:_countdown()
		TimerManager.addTimer(1000, self._onCountdown, true)
	end

end

--[[
    注册玩家操作的结果回调函数
    @param func eg: func(stoneColor, stoneLen)
]]
function EliminateStone:registPlayCallFunc(func)

	self._playCallFunc = func

end

--[[
    清空石头
]]
function EliminateStone:clearStone()

	local stoneData

	for k, stone in pairs(self._stoneList) do
		stoneData = stone.data
		if stoneData then
			stoneData:bindStoneView(nil)
		end

		stone:setData(nil)
		stone:dispose()
		stone:removeFromParentAndCleanup(true)

	end

	self._stoneList = {}

end

function EliminateStone:isFillComplete()
	return self._isFillComplete
end

function EliminateStone:dispose()

	for k, stone in pairs(self._stoneList) do
		stone:dispose()
	end

	self._lineList = {}
	self._currentLineList = {}

	Notifier.removeByName(CmdName.BATTLE_RSP_GET_GEM)
	Notifier.removeByName(CmdName.BATTLE_CONTROL_STONE)

	self._playCallFunc = nil

	self:_stopCountdown()
	
end

function EliminateStone:create()
	local es = EliminateStone.new()

	es:init()

	return es
end


