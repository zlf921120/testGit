--
-- Author: thisgf
-- Date: 2014-10-28 10:30:44
-- 结算界面, 包含普通结果或抽卡结算引用

require "combatConfig"

BattleSettlementView = class("BattleSettlementView", DisplayUtil.newWidget)

BattleSettlementView._starImageList = nil

BattleSettlementView._treasureImage = nil

BattleSettlementView._shadowLayer = nil

BattleSettlementView._titleContainer = nil

BattleSettlementView._titleAnimate = nil

BattleSettlementView._titleImage = nil
BattleSettlementView._imageSectionScore = nil
BattleSettlementView._labelSectionScore = nil

BattleSettlementView._skillPointContainer = nil
BattleSettlementView._skillPointNumLabel = nil

BattleSettlementView._normalView = nil
BattleSettlementView._cardView = nil

BattleSettlementView._openCardViewFunc = nil

local MAX_STAR = 3

function BattleSettlementView:ctor()

	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/battleui/battle_settlement_ui.plist")

	self._shadowLayer = CCLayerColor:create(ccc4(0, 0, 0, 164))
	self:addNode(self._shadowLayer)

	self._starImageList = {}

	self._titleContainer = DisplayUtil.newFitLayout()
	self._titleContainer:setPosition(ccp(DisplayUtil.visibleSize.width*0.5, 545))
	self:addChild(self._titleContainer, 10)

	self._titleAnimate = EffectManager:getInstance():createUIAnimate("wanmeitongguan")
	self._titleContainer:addNode(self._titleAnimate)

	self._titleImage = ImageView:create()
	self._titleContainer:addChild(self._titleImage)

	local starContainer = DisplayUtil.newWidget()
	starContainer:setPosition(ccp(-146, -80))
	self._titleContainer:addChild(starContainer)

	local starImage
	for i = 1, MAX_STAR do

		starImage = ImageView:create()
		starImage:loadTexture("orange_star.png", UI_TEX_TYPE_PLIST)
		starImage:setVisible(false)
		starContainer:addChild(starImage)

		self._starImageList[i] = starImage

	end

	self._treasureImage = ImageView:create()
	self._treasureImage:setPosition(ccp(0, -80))
	self._treasureImage:setVisible(false)
	self._titleContainer:addChild(self._treasureImage)

	self._skillPointContainer = DisplayUtil.newWidget()
	self._skillPointContainer:setPosition(ccp(250, -30))
	self._titleContainer:addChild(self._skillPointContainer)

	local skillPointBg = ImageView:create()
	skillPointBg:loadTexture("btsui_skill_point_bg.png", UI_TEX_TYPE_PLIST)
	self._skillPointContainer:addChild(skillPointBg)

	local skillPointText = ImageView:create()
	skillPointText:loadTexture("i18n_btsui_skill_point.png", UI_TEX_TYPE_PLIST)
	self._skillPointContainer:addChild(skillPointText)

	self._skillPointNumLabel = CCLabelAtlas:create("", "ui/digit/btsui_skill_point_num.png", 40, 50, 48)
	self._skillPointNumLabel:setPosition(ccp(73, -25))
	self._skillPointContainer:addNode(self._skillPointNumLabel)

	self._openCardViewFunc = function()
	    if self._normalView then
		    self._normalView:removeFromParentAndCleanup(false)
	    end

		if not self._cardView then
			self._cardView = BattleSettlementCardView:create()
			self._cardView:retain()
		end

		self._cardView.params = self.params
		self._cardView:open()
		self:addNode(self._cardView)
	end


end

function BattleSettlementView:setParam(params)

	self.params = params

	if BattleManager:getInstance():getType() == BattleType.SKY_WAR then
		local titleTexture = string.format("i18n_bui_sw_victory_%d.png", self.params.numStars)
		self._titleImage:loadTexture(titleTexture, UI_TEX_TYPE_PLIST)
		if not self._imageSectionScore then
			self._imageSectionScore = ImageView:create()
			self._imageSectionScore:setPosition(ccp(-20, -80))
			self._imageSectionScore:loadTexture("i18n_sw_section_score.png", UI_TEX_TYPE_PLIST)
			self._titleContainer:addChild(self._imageSectionScore)
		end

		if not self._labelSectionScore then
			self._labelSectionScore = CCLabelAtlas:create(
				"0", 
				"ui/digit/bui_section_score_num.png", 
				28, 
				39, 
				48
			)
			self._labelSectionScore:setPosition(ccp(70, -100))
			self._titleContainer:addNode(self._labelSectionScore)
		end
		local pm = {plus = ";", minus = ":"} --枚举 加 减
		local symbol
		if self.params.skywarUpdateScore < 0 then
			symbol = pm.plus
		else
			symbol = pm.minus
		end
		self._labelSectionScore:setString(
			string.format(
				"%s%d", 
				symbol, 
				math.abs(self.params.skywarUpdateScore)
			)
		)

	else
		if self.params.settlementType == BattleSettlementType.NORMAL then
			self._titleImage:loadTexture("i18n_btsui_victory_logo.png", UI_TEX_TYPE_PLIST)
		else
			if self.params.numStars == MAX_STAR then
				self._titleImage:loadTexture("i18n_btsui_perfect_clearance_title.png", UI_TEX_TYPE_PLIST)
			else
				self._titleImage:loadTexture("i18n_btsui_clearance_title.png", UI_TEX_TYPE_PLIST)
			end
		end
	end

	if self.params.isTreasureDungeon then
		if self.params.numStars > 0 then
			self._treasureImage:loadTexture(
				string.format(
					"i18n_bui_treasure_level_%d.png", 
					self.params.numStars
				), 
				UI_TEX_TYPE_PLIST
			)

		end
	end

end

function BattleSettlementView:open()

	self._titleAnimate:getAnimation():playWithIndex(0)

	local delayAction
	local showAction
	local scaleAction

	self._titleImage:setScale(4)
	self._titleImage:setVisible(false)
	delayAction = CCDelayTime:create(0.1)
	showAction = CCShow:create()
	local easeAction = CCEaseBackOut:create(CCScaleTo:create(0.4, 1))

	ActionManager:getInstance():runSequenceActions(
		self._titleImage,
		delayAction,
		showAction,
		easeAction
	)


	for i, v in ipairs(self._starImageList) do
		v:setVisible(false)
	end

	self._treasureImage:setVisible(false)

	if self.params.isTreasureDungeon then
		self._treasureImage:setScale(3)
		delayAction = CCDelayTime:create(0.7)
		showAction = CCShow:create()
		scaleAction = CCEaseBackOut:create(CCScaleTo:create(0.4, 1))
		ActionManager:getInstance():runSequenceActions(
			self._treasureImage, 
			delayAction,
			showAction,
			scaleAction
		)
	else

		if BattleManager:getInstance():getType() == BattleType.SKY_WAR then
			self._imageSectionScore:setEnabled(true)
			self._labelSectionScore:setVisible(true)
		else
			if self._imageSectionScore then
				self._imageSectionScore:setEnabled(false)
			end

			if self._labelSectionScore then
				self._labelSectionScore:setVisible(false)
			end

			local widthDist = 300 / (self.params.numStars + 1)
			local starImage
			for i = 1, self.params.numStars do

				starImage = self._starImageList[i]

				-- starImage:setVisible(true)
				starImage:setPosition(ccp(widthDist * i, 0))
				starImage:setScale(4)

				delayAction = CCDelayTime:create(0.5 + 0.2 * i)
				showAction = CCShow:create()
				scaleAction = CCScaleTo:create(0.2, 0.6)
				local scaleAction2 = CCScaleTo:create(0.1, 1)

				ActionManager:getInstance():runSequenceActions(
					starImage, 
					delayAction,
					showAction,
					scaleAction, 
					scaleAction2
				)

			end
		end

	end

	if not self._normalView then
		self._normalView = BattleSettlementNormalView:create()
		self._normalView:retain()
		self._normalView:setShowCardViewFunc(self._openCardViewFunc)

	end

	self._normalView.params = self.params
	self._normalView:open()
	self:addNode(self._normalView)


	if self.params.skillPoint > 0 then

		local currentSkillPoint = 0

		self._skillPointNumLabel:setString(currentSkillPoint)

		local function addSkillPoint()
			currentSkillPoint = currentSkillPoint + 1
			self._skillPointNumLabel:setString(currentSkillPoint)

			if currentSkillPoint >= self.params.skillPoint then
				TimerManager.removeTimer(addSkillPoint)
			end

		end

		self._skillPointContainer:setVisible(false)

		self._skillPointContainer:setScale(4)
		delayAction = CCDelayTime:create(0.6)
		showAction = CCShow:create()
		local easeAction = CCEaseBackOut:create(CCScaleTo:create(0.25, 1))
		local callAction = CCCallFunc:create(function() 
			TimerManager.addTimer(80, addSkillPoint, true)
	    end)
		
		ActionManager:getInstance():runSequenceActions(
			self._skillPointContainer,
			delayAction,
			showAction,
			easeAction,
			callAction
		)

	else
		self._skillPointContainer:setVisible(false)
	end



end

function BattleSettlementView:close()

	self._titleAnimate:getAnimation():stop()

	if self._normalView then
		self._normalView:close()
		self._normalView:removeFromParentAndCleanup(false)
	end

	if self._cardView then
		self._cardView:close()
		self._cardView:removeFromParentAndCleanup(false)
	end

end

function BattleSettlementView:dispose()

	if self._normalView then
		self._normalView:release()
		self._normalView = nil
	end

	if self._cardView then
		self._cardView:release()
		self._cardView = nil
	end

end

function BattleSettlementView:create()

	local title = BattleSettlementView.new()

	return title
end
