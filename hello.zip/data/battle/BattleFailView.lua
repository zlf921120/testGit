--
-- Author: thisgf
-- Date: 2014-08-05 14:18:43
-- 战斗失败界面

require "AbstView"
require "combatConfig"

BattleFailView = class("BattleFailView", AbstView.create)

-- BattleFailView._functionCardList = nil
BattleFailView._functionIconList = nil

BattleFailView._itemIconPool = nil
BattleFailView._itemIconPoolIndex = 1

BattleFailView._imageTitle = nil
BattleFailView._imageSectionScore = nil
BattleFailView._labelSectionScore = nil
BattleFailView._teamExpLabel = nil
BattleFailView._goldLabel = nil

BattleFailView._dataButton = nil
BattleFailView._confirmButton = nil

BattleFailView._functionPanel = nil

local _widgetPath = "ui/battleui/battle_fail_ui_1.json"

local MAX_FUNCTION = 3

--功能名片
local FunctionCard = nil

--功能图标
local FunctionIcon = nil

function BattleFailView:ctor()

	-- self._functionCardList = {}
	self._functionIconList = {}
	self._itemIconPool = {}
	self._itemIconPoolIndex = 1

end

function BattleFailView:init()

	--加载图标资源
	ComResMgr:getInstance():loadResByName("ui/task/task_icon.plist", "ui/task/task_icon.pvr.ccz")

	self:_initUI()

	self:adjustScal()

end

function BattleFailView:_initUI()

	self:addDefaultShadow()
	self.shadow:setOpacity(225)

	self:_initWidget(_widgetPath)

	self._imageTitle = self:_getWidget("ImageView_23", ComponentType.IMAGE_VIEW)

	local teamExpImage = ImageView:create()
	teamExpImage:loadTexture("i18n_team_exp_txt.png", UI_TEX_TYPE_PLIST)
	teamExpImage:setPosition(ccp(420, 422))
	self._widgetGroup:addWidget(teamExpImage)

	self._teamExpLabel = Label:create()
	self._teamExpLabel:setPosition(ccp(475, 420))
	self._teamExpLabel:setColor(ccc3(0xf5, 0xcc, 0x55))
	self._teamExpLabel:setFontSize(24)
	self._teamExpLabel:setAnchorPoint(ccp(0, 0.5))
	self._widgetGroup:addWidget(self._teamExpLabel)

	local goldImage = ImageView:create()
	goldImage:loadTexture("gold.png", UI_TEX_TYPE_PLIST)
	goldImage:setPosition(ccp(617, 421))
	self._widgetGroup:addWidget(goldImage)

	self._goldLabel = Label:create()
	self._goldLabel:setPosition(ccp(643, 420))
	self._goldLabel:setColor(ccc3(0xf5, 0xcc, 0x55))
	self._goldLabel:setFontSize(24)
	self._goldLabel:setAnchorPoint(ccp(0, 0.5))
	self._widgetGroup:addWidget(self._goldLabel)

	self._dataButton = Button:create()
	self._dataButton:loadTextureNormal("btn_up_1.png", UI_TEX_TYPE_PLIST)
	self._dataButton:loadTexturePressed("btn_down_1.png", UI_TEX_TYPE_PLIST)
	self._dataButton:setPosition(ccp(673, 55))
	self._dataButton:addTouchEventListener(function(sender, event)
	    if event ~= TOUCH_EVENT_ENDED then
	    	return
	    end

	    Notifier.dispatchCmd(CmdName.BATTLE_OPEN_STATISTIC_VIEW)
	end)

	self._dataButton:setTouchEnabled(true)
	self._dataButton:setTitleText("數 據")
	self._dataButton:setTitleColor(ccc3(0xFB, 0xF1, 0xA0))
	self._dataButton:setTitleFontSize(24)
	self._widgetGroup:addWidget(self._dataButton)

	-- self._confirmButton = self:_getWidget("button_confirm", ComponentType.BUTTON)

	self._confirmButton = Button:create()
	self._confirmButton:loadTextureNormal("btn_up_1.png", UI_TEX_TYPE_PLIST)
	self._confirmButton:loadTexturePressed("btn_down_1.png", UI_TEX_TYPE_PLIST)
	self._confirmButton:addTouchEventListener(function(sender, event)
	    self:_confirmButtonTouch(event) 
	end)

	self._confirmButton:setPosition(ccp(860, 55))
	self._confirmButton:setTitleText("確 定")
	self._confirmButton:setTitleColor(ccc3(0xFB, 0xF1, 0xA0))
	self._confirmButton:setTitleFontSize(24)
	self._widgetGroup:addWidget(self._confirmButton)

	-- self._functionPanel = self:_getWidget("panel_function", ComponentType.LAYOUT)

	local funcIcon

	local function onIconTouch(sender, event)
	    if event ~= TOUCH_EVENT_ENDED then
	    	return
	    end

	    BattleManager:getInstance():reqBattleEnd()

	    local windoId = sender:getData().windowId

	    if windoId == TaskHelper.link_wins.eqm_powered then
	        local powered_item = ItemManager:getInstance():getFitEqmToPowered()
	        if powered_item then
	            WindowCtrl:getInstance():open(CmdName.Eqm_Forge_View,
	                                    {powered_item,powered_item.mode.item_type,HeroHelper.forgePanelType.powered})
	        else
	            Alert:show("您沒有穿戴裝備，裝備穿戴後可強化")
	        end
	    elseif windoId == TaskHelper.link_wins.hero_skill then
	        WindowCtrl:getInstance():open(CmdName.Hero_View,HeroManager.LEADING_HERO_ID)
	        local param = {}
	        table.insert(param,HeroHelper.leftPanelType.skillView)
	        Notifier.dispatchCmd(CmdName.CtrlRoleLeftPanel,param)
	    elseif windoId == TaskHelper.link_wins.eqm_enchant then
	        --打开附魔面板
	        local enchat_item = ItemManager:getInstance():getFitEqmToEnchant()
	        if enchat_item then
	            WindowCtrl:getInstance():open(CmdName.Eqm_Forge_View,
	                        {enchat_item,enchat_item.mode.item_type,HeroHelper.forgePanelType.enchant})
	        else
	            Alert:show("您沒有穿戴裝備，裝備穿戴後可附魔")
	        end
	    elseif windoId == TaskHelper.link_wins.eqm_identify then
	        --打开鉴定面板
	        local identify_item = ItemManager:getInstance():getFitEqmToIdentity()
	        if identify_item then
	            WindowCtrl:getInstance():open(CmdName.Eqm_Forge_View,
	                        {identify_item,identify_item.mode.item_type,HeroHelper.forgePanelType.identify})
	        else
	            Alert:show("您沒有穿戴可鑒定的裝備(紫色以上可鑒定)")
	        end    
	     elseif windoId == TaskHelper.link_wins.eqm_gem then
	        --打开宝石镶嵌面板
	        local gem_item = ItemManager:getInstance():getFitEqmToGem(41400)
	        if gem_item then
	            WindowCtrl:getInstance():open(CmdName.Eqm_Forge_View,
	                        {gem_item,gem_item.mode.item_type,HeroHelper.forgePanelType.gem})
	        else
	            Alert:show("您沒有穿戴裝備，裝備穿戴後鑲嵌寶石")
	        end
	    elseif windoId == TaskHelper.link_wins.hero_upgrade then
	        --打开英雄
	        WindowCtrl:getInstance():open(CmdName.Hero_List_View)
	    end

	end

	for i = 1, MAX_FUNCTION do

		funcIcon = FunctionIcon:create()
		funcIcon:addTouchEventListener(onIconTouch)

		self._widgetGroup:addWidget(funcIcon)

		self._functionIconList[i] = funcIcon

	end

end

function BattleFailView:_confirmButtonTouch(event)

	if event ~= TOUCH_EVENT_ENDED then
		return
	end

	BattleManager:getInstance():reqBattleEnd()

end

function BattleFailView:open()

	if BattleManager:getInstance():getType() == BattleType.SKY_WAR then
		self._imageTitle:loadTexture("i18n_bui_sw_fail.png", UI_TEX_TYPE_PLIST)
		if not self._imageSectionScore then
			self._imageSectionScore = ImageView:create()
			self._imageSectionScore:setScale(0.8)
			self._imageSectionScore:setPosition(ccp(445, 458))
			self._imageSectionScore:loadTexture("i18n_sw_section_score.png", UI_TEX_TYPE_PLIST)
			self._widgetGroup:addWidget(self._imageSectionScore)
		end
		self._imageSectionScore:setEnabled(true)

		if not self._labelSectionScore then
			self._labelSectionScore = CCLabelAtlas:create(
				"0", 
				"ui/digit/bui_section_score_num.png", 
				28, 
				39, 
				48
			)
			self._labelSectionScore:setScale(0.8)
			self._labelSectionScore:setPosition(ccp(515, 440))
			self._widgetGroup:addChild(self._labelSectionScore)
		end
		self._labelSectionScore:setVisible(true)
		local pm = {plus = ";", minus = ":"} --枚举 加 减
		local symbol
		if self.params.skywarUpdateScore < 0 then
			symbol = pm.plus
		else
			symbol = pm.minus
		end
		self._labelSectionScore:setString(
			string.format(
				"%s%d", 
				symbol, 
				math.abs(self.params.skywarUpdateScore)
			)
		)
	else
		if self._imageSectionScore then
			self._imageSectionScore:setEnabled(false)
		end

		if self._labelSectionScore then
			self._labelSectionScore:setVisible(false)
		end

		self._imageTitle:loadTexture("i18n_bfui_title.png", UI_TEX_TYPE_PLIST)
	end


	self._teamExpLabel:setText(string.format("+%d", self.params.exp))
	self._goldLabel:setText(string.format("+%d", self.params.gold))

	for i = 1, MAX_FUNCTION do
		self._functionIconList[i]:setEnabled(false)
	end

	local randomFuncList = CombatDataStorage:getInstance():getRandomOpenFuncData(3)

	local widthDist = 658 / (#randomFuncList + 1)

	local icon
	for i, v in ipairs(randomFuncList) do
		icon = self._functionIconList[i]
		icon:setEnabled(true)
		icon:setData(v)
		icon:setPosition(ccp(240 + i * widthDist, 335))
	end

	for i, v in ipairs(self.params.itemList) do

		itemIcon = self:_getItemIcon()
		itemIcon:setPosition(ccp(433 + (i - 1) * 115, 150))
		itemIcon:setBaseId(v.mode.base_id)
		itemIcon:setItemNum(v.quantity)
		self._widgetGroup:addChild(itemIcon)

	end

end

function BattleFailView:_getItemIcon()

	local itemIcon = self._itemIconPool[self._itemIconPoolIndex]

	if not itemIcon then
		itemIcon = ItemIcon:create()
		itemIcon:retain()
		self._itemIconPool[#self._itemIconPool + 1] = itemIcon
	end

	self._itemIconPoolIndex = self._itemIconPoolIndex + 1
	itemIcon:setVisible(true)

	return itemIcon

end

function BattleFailView:close()

	self._itemIconPoolIndex = 1

	for _, icon in ipairs(self._itemIconPool) do
		icon:removeFromParentAndCleanup(false)
	end

end

function BattleFailView:create()

	local failView = BattleFailView.new()
	failView:init()
	return failView
end


FunctionIcon = class("FunctionIcon", DisplayUtil.newWidget)

FunctionIcon._data = nil

FunctionIcon._iconImage = nil
FunctionIcon._iconLabel = nil


function FunctionIcon:ctor()

	self:setTouchEnabled(true)
	self:setSize(CCSizeMake(119, 119))
	self:ignoreContentAdaptWithSize(false)

	local iconOutLine = ImageView:create()
	iconOutLine:loadTexture("bfui_func_outline.png", UI_TEX_TYPE_PLIST)
	self:addChild(iconOutLine)

	local iconCover = ImageView:create()
	iconCover:loadTexture("bfui_func_cover.png", UI_TEX_TYPE_PLIST)
	self:addChild(iconCover)

	self._iconImage = ImageView:create()
	self:addChild(self._iconImage)

	self._iconLabel = ImageView:create()
	self._iconLabel:setPosition(ccp(0, -82))
	self:addChild(self._iconLabel)

end

function FunctionIcon:setData(value)

	self._data = value

	self._iconImage:loadTexture(string.format("task_icon_%d.png", self._data.iconId), UI_TEX_TYPE_PLIST)
	self._iconLabel:loadTexture(string.format("i18n_bfui_func_%d.png", self._data.iconId), UI_TEX_TYPE_PLIST)

end

function FunctionIcon:getData()
	return self._data
end

function FunctionIcon:create()

	local icon = FunctionIcon.new()

	return icon
end

