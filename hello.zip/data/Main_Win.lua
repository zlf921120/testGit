require("Utils")
require("CmdName")
require("Timer")
require("Notifier") 
require("XArray")
require("extern")
require("TimerManager")
require("DisplayUtil")
require("LoginChannelScene")
require("FileUtils")
require("MathUtil")
require("error_code_pb")
require("helper")
require("requireLoad")
require("UpdateScene")
require("SysSettingMgr")
require("SdkLuaMgr")
require("LuaCollect")
require("SceneCtrl")
require("LuaXmlParser")

-- for CCLuaEngine traceback
local function __G__TRACKBACK__(msg)
    Notifier.dispatchCmd(CmdName.ADD_LOG_INFO, "E:"..tostring(msg).."\n"..debug.traceback())
    print("----------------------------------------")
    print("LUA ERROR: " .. tostring(msg) .. "\n")
    print(debug.traceback())
    print("----------------------------------------")
end

function gameStar()
    Timer.init()
    TimerManager.start()
    DisplayUtil.init()
    SysSettingMgr:getInstance():initAllSetting()
    --发送第一个流失率统计节点,必须在SysSettingMgr执行完initAllSetting后
    SysSettingMgr:getInstance():sendWasteageCount(1)


    UpdateScene:addNewLuaPath()
    --临时处理
    CCFileUtils:sharedFileUtils():addSearchPath("data/skywar")

    
    -- CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA4444)

    local function sdkInfiSucc()
        Notifier.remove("sdk_init_success",sdkInfiSucc)

        local scene
        if Global:getTargetPlatform() == Helper.TargetPlatForms.WIN32 then

            SceneCtrl:getInstance():goToScene(CmdName.ChannelScene)

        else
            require("SceneCtrl")

            SceneCtrl:getInstance():goToScene(CmdName.ChannelScene,function()
                local update_scene 
                if Global:isNeedUpdate() and Global:getNetWorkState() == Helper.NetWorkState.disconnect then 
                    -- 如果没网络，则直接跳到更新界面，等待检测，避免黑屏等待太久
                    update_scene = SceneCtrl:getInstance():goToScene(CmdName.UpdateScene)
                    TimerManager.addTimer(120, function() update_scene:checkUpdate() end)
                elseif Global:isNeedUpdate() and UpdateScene:staticCheckIsUpdate() then 
                    --如果有网络，则先检测是否需要更新，需要才进入更新界面，否则直接进入登陆界面
                    update_scene = SceneCtrl:getInstance():goToScene(CmdName.UpdateScene)
                    update_scene:checkUpdate()
                else
                    SceneCtrl:getInstance():goToScene(CmdName.LOGIN_SCENE)
                end

            end)
        end

        --跳转到版本检验场景，如果不需要更新，则跳转到普通登陆界面

        Global:RegisterCmdWithParas("ERR_SOCKET","handleSocketErr(string)")
        Global:RegisterCmdWithParas("ShowLoadingStatus","handleLoadingStatus(string)")

    end

    sdkInfiSucc()

    -- require "test/TestMain";scene = CCScene:create();CCDirector:sharedDirector():runWithScene(scene);scene:addChild(TestMain:create());
    
    
end

local function main()
	-- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)

	math.randomseed(tostring(os.time()):reverse():sub(1, 6))
	
    if Global:isDevelop() == false then
        CCDirector:sharedDirector():setDisplayStats(false)
    end    
    -- CCEGLView:sharedOpenGLView():setFrameSize(1024, 768)
    CCEGLView:sharedOpenGLView():setDesignResolutionSize(960, 640, kResolutionExactFit)
    
    gameStar()

end
-- Entry
xpcall(main, __G__TRACKBACK__)
