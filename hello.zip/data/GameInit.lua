--
-- Author: lvgansheng
-- Date: 2014-10-14 15:37:28
-- 监听相关的数据是否初始化完毕

GameInit = class("GameInit")

local _instance = nil
local _allowInstance = false

local is_bag_init = false
local is_hero_init = false
local is_team_init = false
local is_battle_eqm_init = false

function GameInit:ctor()
    if not _allowInstance then
		error("GameInit is a singleton class")
	end
	self:addListens()
end

function GameInit:getInstance()
	if not _instance then
		_allowInstance = true
		_instance = GameInit.new()
		_allowInstance = false
	end
	return _instance
end

local function onBagInit()
	Notifier.remove(CmdName.BACKPACK_INIT,onBagInit)
	is_bag_init = true
	_instance:isGameStar()
end

local function onHeroInit()
	Notifier.remove(CmdName.HeroInfoInit,onHeroInit)
	is_hero_init = true
	_instance:isGameStar()
end

local function onTeamInit()
	Notifier.remove(CmdName.TEAM_INIT_HERO,onTeamInit)
	is_team_init = true
	_instance:isGameStar()
end

local function onBattleEqmInit()
	Notifier.remove(CmdName.InitBattleHeroEqm,onBattleEqmInit)
	is_battle_eqm_init = true
	_instance:isGameStar()
end

function GameInit:addListens()
	Notifier.regist(CmdName.BACKPACK_INIT,onBagInit)
	Notifier.regist(CmdName.HeroInfoInit,onHeroInit)
	Notifier.regist(CmdName.TEAM_INIT_HERO,onTeamInit)
	Notifier.regist(CmdName.InitBattleHeroEqm,onBattleEqmInit)
end

function GameInit:isGameStar()
	if is_bag_init and is_hero_init and
	 is_team_init and is_battle_eqm_init then
		Notifier.dispatchCmd(CmdName.GameStar)  
	end
end