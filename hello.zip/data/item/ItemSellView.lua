--
-- Author: lvgansheng
-- Date: 2014-07-08 15:23:01
-- 出售界面

ItemSellView = class("ItemSellView",WindowBase)

ItemSellView.uiLayer = nil
ItemSellView.widget = nil
ItemSellView.item_data = nil --当前点击的物品ID

function ItemSellView:init()
    self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
        
    self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/backpack/item_sell/item_sell.ExportJson")
    self.uiLayer:addWidget(self.widget)

    self.sell_money_type_img = tolua.cast( self.uiLayer:getWidgetByName("unit_price_img") , "ImageView")
    self.get_money_type_img = tolua.cast( self.uiLayer:getWidgetByName("total_price_img") , "ImageView")

    local bg_img = tolua.cast( self.uiLayer:getWidgetByName("sell_bg") , "ImageView")

    self.item_icon = ItemIcon:create()
    self.item_icon:setPosition(ccp(-120,196))
    bg_img:addChild(self.item_icon)

    --设置减号按钮
    local subBtn= self.uiLayer:getWidgetByName("sub_btn") 
    local function subBtnFun(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then 
            
            if(self.sellNum == 1) then -- 已经只有一件，无法再减少
                return
            end

            self.sellNum=self.sellNum-1
            local str = string.format('%d/%d',self.sellNum,self.item_data.quantity)
            local numTxt = self.uiLayer:getWidgetByName("sell_num_label")
            tolua.cast(numTxt,"Label")
            numTxt:setText(str)
            self:changeMoney()
        end
    end
    subBtn:addTouchEventListener(subBtnFun)
    
    --设置加号按钮
    local addbtn= self.uiLayer:getWidgetByName("add_btn")  
    local function addbtnfun(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then 
            
            if(self.sellNum == self.item_data.quantity) then -- 已经是最大数量
                return
            end

            self.sellNum=self.sellNum+1
            local str = string.format('%d/%d',self.sellNum,self.item_data.quantity)
            local numTxt = self.uiLayer:getWidgetByName("sell_num_label")
            tolua.cast(numTxt,"Label")
            numTxt:setText(str)
            self:changeMoney()
        end
    end
    addbtn:addTouchEventListener(addbtnfun)
        
    local maxBtn= self.uiLayer:getWidgetByName("max_btn")  --设置出售界面的最大数量按钮
    maxBtn:setTouchEnabled(true)    
    local function maxBtnFun(sender,eventType)
        
        if(self.sellNum == self.item_data.quantity) then -- 已经是最大数量
            return
        end 
        
        self.sellNum = self.item_data.quantity
        local str = string.format('%d/%d',self.sellNum,self.item_data.quantity)
        local numTxt = self.uiLayer:getWidgetByName("sell_num_label")
        tolua.cast(numTxt,"Label")
        numTxt:setText(str)
        self:changeMoney()
    end
    maxBtn:addTouchEventListener(maxBtnFun)

    --取消按钮
    local cancelBtn = self.uiLayer:getWidgetByName("cancel_btn")    --确认出售按钮
    local function onClickCancelBtn(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end 
    cancelBtn:addTouchEventListener(onClickCancelBtn)
                
    --出售按钮
    local selBtn = self.uiLayer:getWidgetByName("sell_btn") 
    local function confrimSelBtnFun(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            -- local bag_sell_req = bag_pb.bag_sell_req();
            -- local bag_sell_item = bag_sell_req.items:add();
            -- bag_sell_item.id = self.item_data.id
            -- bag_sell_item.quantity = self.sellNum    
   --          ComSender:getInstance():send(proto_cmd_pb.msg_cmd.bag_sell_req,bag_sell_req)
            ItemManager:getInstance():sendSellItemReq(self.item_data.id, self.sellNum)      
            -- Global:sendPkg(proto_cmd_pb.msg_cmd.bag_sell_req, bag_sell_req:SerializeToString() , bag_sell_req:ByteSize())
        end
    end 
    selBtn:addTouchEventListener(confrimSelBtnFun)
    
    self.open = function() 
        if self.params ~= nil then
            self:setitem_data(self.params)
        end
    end

end

function ItemSellView:create()
    local item_sell_view = ItemSellView.new()
    -- item_sell_view:init()
    return item_sell_view
end

function ItemSellView:setitem_data(item)
    self.item_data = item 
    self.sellNum = 1
    self:changeContent()
    self:changeMoney()
end

function ItemSellView:changeMoney()
     local moneyLabel = self.uiLayer:getWidgetByName("total_price_label")
     tolua.cast(moneyLabel,"Label")
     moneyLabel:setText(self.item_data.mode.sell_price * self.sellNum )
end

function ItemSellView:changeContent()
    -- local itemIcon =  self.uiLayer:getWidgetByName("ImageView_78")
    -- tolua.cast(itemIcon,"ImageView")
    -- itemIcon:loadTexture("ui/backpack/10401.png")
    self.item_icon:setBaseId(self.item_data.mode.base_id)

    local namelabel = self.uiLayer:getWidgetByName("name_label")
    tolua.cast(namelabel,"Label")
    namelabel:setColor(ItemHelper:getColorByQuality(self.item_data.mode.quality))
    namelabel:setText(self.item_data.mode.name)
    
    local numlabel = self.uiLayer:getWidgetByName("quantity_label")
    tolua.cast(numlabel,"Label")
    numlabel:setText(self.item_data.quantity)       
        
    local str = string.format('%d/%d',self.sellNum,self.item_data.quantity)
    local numTxt = self.uiLayer:getWidgetByName("sell_num_label")
    tolua.cast(numTxt,"Label")
    numTxt:setText(string.format('1/%d',self.item_data.quantity))
    
    local priceTxt = self.uiLayer:getWidgetByName("unit_price_label")
    tolua.cast(priceTxt,"Label")
    priceTxt:setText(self.item_data.mode.sell_price)

    if self.item_data.mode.money_type == ItemHelper.moneyType.glodCoin then
        self.sell_money_type_img:loadTexture("gold.png", UI_TEX_TYPE_PLIST)
        self.get_money_type_img:loadTexture("gold.png", UI_TEX_TYPE_PLIST)
    else
        self.sell_money_type_img:loadTexture("diamond.png", UI_TEX_TYPE_PLIST)
        self.get_money_type_img:loadTexture("diamond.png", UI_TEX_TYPE_PLIST)
    end
end