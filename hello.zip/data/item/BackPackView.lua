


BackPackView = class("BackPackView",WindowBase)

BackPackView.uiLayer = nil
BackPackView.widget = nil
BackPackView.itemIconDic = nil --保存背包中的物品图标
BackPackView.clickItemData = nil --当前点击的物品ID
BackPackView.sellNum = nil --当前要出售的物品数量
BackPackView.enterFun = nil --窗体被显示时需要执行的方法
BackPackView.exitFun = nil --被移除时需要执行的方法
BackPackView.item_info_view = nil
BackPackView.select_img = nil

BackPackView.item_bg_batch_node = nil
BackPackView.item_icon_batch_node = nil
BackPackView.item_border_batch_node = nil
BackPackView.label_batch_node = nil
BackPackView.num_label_arr = nil

local BackPackConstTab = {}
BackPackConstTab.DefaultScrollHeight = 430 --背包滚动层的默认高度
BackPackConstTab.DefaultIconWidth = 105 --物品图标的默认宽度
BackPackConstTab.DefaultIconHeight = 115 --物品图标的默认高度
BackPackConstTab.DefaultIconNum = 4 -- 背包一行显示的图标个数

local itemManager = nil

local cur_select_icon = nil

local cur_menu_tag = 1

--初始化背包界面
function BackPackView:init()
	require 'BackpackIcon'
	require 'ItemInfoView'
	require 'ItemManager'
	require 'proto_cmd_pb'
	require 'error_code_pb'
	require 'bag_pb'
	require 'common_pb'
	require "common_2_pb"
	require 'ItemHelper'
	require("CustomMenu")
	require("Utils")

	local visibleSize = CCDirector:sharedDirector():getVisibleSize()
    local origin = CCDirector:sharedDirector():getVisibleOrigin()    
	
	itemManager = ItemManager:getInstance()

	self.itemIconDic = {} -- 保存背包中的物品图标
	
	self.num_label_arr = CCArray:create()
	self.num_label_arr:retain()

	self.gift_label_arr = CCArray:create()
	self.gift_label_arr:retain()

	self.eqm_lv_label_arr = CCArray:create()
	self.eqm_lv_label_arr:retain()

	self.icon_pos_dic = {}

    self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/backpack/backpack_base/backpack_base.ExportJson")
    self.uiLayer:addWidget(self.widget)

    --物品选中状态
    self.select_img = ImageView:create()
    self.select_img:loadTexture("item_select.png",UI_TEX_TYPE_PLIST)
    self.select_img:retain()
				
	--背包滚动层
	self.scrollView = self.uiLayer:getWidgetByName("item_scroll_view")	
	tolua.cast(self.scrollView,"ScrollView")
	self.scrollView:setBounceEnabled(false)
	local innerLayer = Layout:create()
	innerLayer:setPosition(ccp(50,-57))
	self.scrollView:addChild(innerLayer)
	--没有物品提示
	self.imgNothingTips = tolua.cast(self.uiLayer:getWidgetByName("img_nothing"),"ImageView")

	local temp_af = self.scrollView:nodeToWorldTransform()
	-- local tmp_af_x = temp_af.tx - (BackPackConstTab.DefaultIconWidth/2)
	-- local tmp_af_y = temp_af.ty -  (BackPackConstTab.DefaultIconHeight/2)
		local tmp_af_x = temp_af.tx 
	local tmp_af_y = temp_af.ty 
    -- self.tips_view:setPosition(ccp(temp_af.tx+400,temp_af.ty+50))

	self.item_bg_batch_node = CCSpriteBatchNode:create("ui/common/common.pvr.ccz",100)
	self.item_icon_batch_node = CCSpriteBatchNode:create("ui/common/item_icon.pvr.ccz",100)
	self.item_border_batch_node = CCSpriteBatchNode:create("ui/common/common.pvr.ccz",100)
	self.ext_img_batch_node = CCSpriteBatchNode:create("ui/common/common.pvr.ccz",100) --显示一些额外的信息
	self.label_batch_node = Layout:create()

	innerLayer:addNode(self.item_bg_batch_node)
	innerLayer:addNode(self.item_icon_batch_node)
	innerLayer:addNode(self.item_border_batch_node)
	innerLayer:addChild(self.label_batch_node)
	innerLayer:addNode(self.ext_img_batch_node)
			
	local function setScrollHeight(itemNum) --设置背包滚动层高度
		local innerWidth = self.scrollView:getSize().width
		local innerHeight = math.ceil(itemNum/BackPackConstTab.DefaultIconNum)*BackPackConstTab.DefaultIconHeight --滚动框高度由物品个数决定
			
		if 	innerHeight<BackPackConstTab.DefaultScrollHeight then
			innerHeight = BackPackConstTab.DefaultScrollHeight
		end	
		
		self.scrollView:setInnerContainerSize(CCSize(innerWidth, innerHeight))

	end	

	-- scrollView:addEventListenerScrollView(function(sender, eventType) end)

	local old_pos_y = 0
	self.scrollView:addTouchEventListener(function(sender, eventType) 
		if eventType == ComConstTab.TouchEventType.ended then
			local tmp_y = self.scrollView:getInnerContainer():getPositionY()
			local touch_pos = self.scrollView:getTouchEndPos()
			local innerHeight = self.scrollView:getInnerContainerSize().height

			local tmp_row_value = (innerHeight-touch_pos.y+tmp_af_y+tmp_y)/BackPackConstTab.DefaultIconHeight
			local tmp_col_value = (touch_pos.x-tmp_af_x)/BackPackConstTab.DefaultIconWidth

			tempBtn = self.icon_pos_dic[self:getIconPosKey(tmp_row_value, tmp_col_value)]  

			if tempBtn==nil then
				cclog("這個位置沒東西~~~%f~~~~%f",tmp_row_value,tmp_col_value)
				return
			end
			cclog("innerHeight=%d~~~~touch_pos.y=%d~~~~~tmp_af_y=%d",innerHeight, touch_pos.y, tmp_af_y)
			if self.item_info_view == nil then
				self.item_info_view = ItemInfoView:create()
				self.item_info_view:retain()
			end

			if self.item_info_view:getParent() == nil then
				self.uiLayer:addWidget(self.item_info_view)
			end

			self.item_info_view:setItemData(tempBtn.itemData)

			if self.select_img:getParent() then
				self.select_img:removeFromParentAndCleanup(true)
			end

			self.select_img:setPosition(tempBtn:getRealPos())

			innerLayer:addChild(self.select_img)

			--新手引导事件
			if tempBtn.itemData.mode.base_id == 40001 then
				if GuideDataProxy:getInstance().nowMainTutroialEventId == 10304 then
	            	Notifier.dispatchCmd(GuideEvent.StepFinish,"click_itemgrid")
	        	end
			end

		elseif eventType == ComConstTab.TouchEventType.moved  then
			if -self.scrollView:getInnerContainer():getPositionY()-old_pos_y>-300 and 
				-self.scrollView:getInnerContainer():getPositionY()-old_pos_y<300 and old_pos_y~=0 then
				return
			end

			self:showNumLabel()
		end
	end)
			
	--点击背包物品的响应函数
    local function onItemIconClick(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
			
			if self.select_img:getParent() then
				self.select_img:removeFromParentAndCleanup(true)
			end

			local item_icon =  sender:getParent()
			local itemData = item_icon.itemData
			item_icon:addChild(self.select_img)

			if self.item_info_view == nil then
				self.item_info_view = ItemInfoView:create()
				self.item_info_view:retain()
			end

			if self.item_info_view:getParent() == nil then
				self.uiLayer:addWidget(self.item_info_view)
			end

			self.item_info_view:setItemData(itemData)

			
        end
    end		
	
	--显示所有背包中的物品
	local function showALLBackPackItem() 
		self.item_bg_batch_node:removeAllChildrenWithCleanup(true)       
		self.item_icon_batch_node:removeAllChildrenWithCleanup(true)
		self.item_border_batch_node:removeAllChildrenWithCleanup(true)       
		self.ext_img_batch_node:removeAllChildrenWithCleanup(true)       

		local backpackItemTab = itemManager.backpackItemTab
		local itemIdArr = itemManager.backpackItemIdArr
		local count =  #itemIdArr

		self.imgNothingTips:setVisible(count == 0)
		
		setScrollHeight(count)	
			
		local itemId = 0
		local tempBtn = nil
		local innerHeight = self.scrollView:getInnerContainerSize().height
		local tmp_row_value = 0
		local tmp_col_value = 0

		for i = 1,count do
			itemId = itemIdArr[i]
			tempBtn = self.itemIconDic[itemId]
			if( tempBtn == nil) then
				tempBtn = BackpackIcon:create()
				-- tempBtn:setTouchEnabled(true)			
				-- tempBtn:setTouchEvent(onItemIconClick)
				self.itemIconDic[itemId] = tempBtn
			end
			tmp_row_value = math.modf((i-1)/BackPackConstTab.DefaultIconNum)
			tmp_col_value = (i-1)%BackPackConstTab.DefaultIconNum

			tempBtn:changeItemData(backpackItemTab[itemId])	
			self.item_bg_batch_node:addChild(tempBtn:getIconBg())
			self.item_icon_batch_node:addChild(tempBtn:getItemIcon())
			self.item_border_batch_node:addChild(tempBtn:getIconBorder())

			if tempBtn:isShowEqmFrag() then
				self.ext_img_batch_node:addChild(tempBtn:getEqmFragImg())
			end

			tempBtn:setRealPos(CCPoint(BackPackConstTab.DefaultIconWidth*tmp_col_value, 
				innerHeight -(BackPackConstTab.DefaultIconHeight*tmp_row_value)))

			self.icon_pos_dic[self:getIconPosKey(tmp_row_value, tmp_col_value)] = tempBtn
		end
		
		--新手引导事件
		if GuideDataProxy:getInstance().nowMainTutroialEventId == 10303 then
    		Notifier.dispatchCmd(GuideEvent.StepFinish,"click_bagpanel")
    	end
	end		
			
	local function changeBackPackItemByItemType(itemType)
	   	self.item_bg_batch_node:removeAllChildrenWithCleanup(true)       
		self.item_icon_batch_node:removeAllChildrenWithCleanup(true)       
		self.item_border_batch_node:removeAllChildrenWithCleanup(true) 
		self.ext_img_batch_node:removeAllChildrenWithCleanup(true)
		self.icon_pos_dic = {}

		if self.select_img:getParent() then
			self.select_img:removeFromParentAndCleanup(true)
		end

		if itemType ==1000 then --1000表示显示所有物品
			showALLBackPackItem()
			self:showNumLabel()
			return
		end	

		local itemArr = itemManager:getItemArrByIdInterval(itemType)
		local num = #itemArr

		self.imgNothingTips:setVisible( num == 0 )

		setScrollHeight(num)
		local innerHeight = self.scrollView:getInnerContainerSize().height 
		local tmp_row_value = 0
		local tmp_col_value = 0
		for i=1,num do   
			local tempBtn = self.itemIconDic[itemArr[i]]
			tmp_row_value = math.modf((i-1)/BackPackConstTab.DefaultIconNum)
			tmp_col_value = (i-1)%BackPackConstTab.DefaultIconNum	
			tempBtn:setRealPos(CCPoint(BackPackConstTab.DefaultIconWidth*tmp_col_value, 
						innerHeight-(BackPackConstTab.DefaultIconHeight*tmp_row_value)))
			self.item_bg_batch_node:addChild(tempBtn:getIconBg())
			self.item_icon_batch_node:addChild(tempBtn:getItemIcon())
			self.item_border_batch_node:addChild(tempBtn:getIconBorder())

			if tempBtn:isShowEqmFrag() then
				self.ext_img_batch_node:addChild(tempBtn:getEqmFragImg())
			end

			self.icon_pos_dic[self:getIconPosKey(tmp_row_value, tmp_col_value)] = tempBtn
			-- self.label_batch_node:addNode(tempBtn:getNumLabel())
		end

		self.scrollView:jumpToTop()
		self:showNumLabel()
	end	
	
	--测试新menu控件
    local function menuCallback(tag)
        local item_type = nil
        if tag == 1 then 
            item_type = 1000
        elseif tag == 2 then
            item_type = 2
        elseif tag == 3 then
            item_type = 3
        elseif tag == 4 then   
            item_type = 4
        elseif tag == 5 then
        	item_type = 5
        else 
            item_type = 1000
        end
        cur_menu_tag = tag
        changeBackPackItemByItemType(item_type)
    end

    local menu_arr = {}
    table.insert(menu_arr,{txt="全部"})
    table.insert(menu_arr,{txt="裝備"})
    table.insert(menu_arr,{txt="消耗品"})
    table.insert(menu_arr,{txt="靈魂石"})
    table.insert(menu_arr,{txt="碎片"})

    self.cus_menu = CustomMenu:create()
    self.cus_menu:setBtnScalex(0.7)
    self.cus_menu:setBtnScaley(0.7)
    self.cus_menu:setData(menu_arr,menuCallback)
    self.cus_menu:alignItemsVerticallyWithPadding(15)
    self.cus_menu:setPosition(CCPoint(884,280))
    self.widget:addNode(self.cus_menu) 
										
	--初始化背包的物品数据
	local function onBackPackDataInit()
		showALLBackPackItem()
	end	

	--添加新物品,新加的物品默认添加到最后面
   local function onBackpackAddNewItem(itemArr)
        local itemArr = itemArr
		local tempBtn = nil
		local j =innerLayer:getChildrenCount()--当前的物品个数		 
		local isRefresh = false -- 是否需要重置之前的按钮位置 
		local oldInnerHeight = self.scrollView:getInnerContainerSize().height
		setScrollHeight(j)		
		local innerHeight = self.scrollView:getInnerContainerSize().height 
		if innerHeight > oldInnerHeight then
			isRefresh = true
		end	
		
		for i, v in pairs(itemArr) do						    
			j = j +1
			tempBtn = self.itemIconDic[i]
			if( tempBtn == nil) then
				tempBtn = BackpackIcon:create()
				self.itemIconDic[i] = tempBtn
				tempBtn:changeItemData(v)	
				self.item_bg_batch_node:addChild(tempBtn:getIconBg())
				self.item_icon_batch_node:addChild(tempBtn:getItemIcon())
				self.item_border_batch_node:addChild(tempBtn:getIconBorder())
			
				if tempBtn:isShowEqmFrag() then
					self.ext_img_batch_node:addChild(tempBtn:getEqmFragImg())
				end

				tempBtn:setRealPos(CCPoint(BackPackConstTab.DefaultIconWidth*((j-1)%BackPackConstTab.DefaultIconNum),innerHeight-(BackPackConstTab.DefaultIconHeight*math.modf((j-1)/BackPackConstTab.DefaultIconNum))))
				-- innerLayer:addChild(tempBtn)
				-- tempBtn:setTouchEvent(onItemIconClick)
			end
			-- tempBtn:setItemNum(v.quantity)				
			-- tempBtn:changeItemNum(itemManager.backpackItemTab[v].quantity )				
		end
		
		-- if isRefresh  then
			-- refreshPosition()
			menuCallback(cur_menu_tag)
		-- end
			
    end
	
	--更新背包物品数量
	local function onBackpackUpdateItem(itemArr)
		local itemArr = itemArr
		local tempBtn = nil
	
		-- for i, v in pairs(itemArr) do
		-- 	tempBtn = self.itemIconDic:objectForKey(v)			
		-- 	tempBtn:setItemNum(itemManager.backpackItemTab[v].quantity )
			
		-- end	
		self:showNumLabel()
	end
	
    --删除背包物品
	local function onBackpacDelItem(itemArr)
		local itemArr = itemArr 
		local tempBtn = nil

		for i, v in pairs(itemArr) do
			tempBtn =self.itemIconDic[v]	
			if tempBtn then
				-- tempBtn:removeFromParentAndCleanup(true)
				self.itemIconDic[v] = nil

				if self.item_info_view and 
					self.item_info_view:getParent() and
					self.item_info_view:getItemId()== v then
					self.item_info_view:removeFromParentAndCleanup(true)
				end

			end	
		end			
		-- refreshPosition()
		menuCallback(cur_menu_tag)
	end
	
	--新手引导动画
	Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)	
				
	self.open = function () --监听背包相关事件
		 Notifier.regist(CmdName.BACKPACK_INIT, onBackPackDataInit)
	Notifier.regist(CmdName.BACKPACK_ADD,onBackpackAddNewItem)
	Notifier.regist(CmdName.BACKPACK_UPDATE,onBackpackUpdateItem)
	Notifier.regist(CmdName.BACKPACK_DEL,onBackpacDelItem) 
		 -- refreshPosition()
		 self.cus_menu:setSelectedItem(1)
		 menuCallback()
	end

	self.close = function () --移除背包相关事件的监听
		Notifier.remove(CmdName.BACKPACK_INIT, onBackPackDataInit)
		Notifier.remove(CmdName.BACKPACK_ADD, onBackpackAddNewItem)
		Notifier.remove(CmdName.BACKPACK_UPDATE, onBackpackUpdateItem )
		Notifier.remove(CmdName.BACKPACK_DEL,onBackpacDelItem)

		if self.item_info_view and 
			self.item_info_view:getParent()then
			self.item_info_view:removeFromParentAndCleanup(true)
		end
	end
	
end

--创建背包界面
function BackPackView:create()
    local layer = BackPackView.new()
    -- layer:init()
    return layer   
end

function BackPackView:extTouch(enable)
    self.cus_menu:setTouchEnabled(enable)
end

function BackPackView:extTouchPriority(value)
    self.cus_menu:setTouchPriority(value)
end

--新手引导动画
function BackPackView:showStepAnim(param)
	if param.target == "item_item" then
		local itemIdArr = itemManager.backpackItemIdArr
		local backpackItemTab = itemManager.backpackItemTab
		for i = 1,#itemIdArr do
			local itemId = itemIdArr[i]
			if backpackItemTab[itemId].mode.base_id == 40001 then
				local icon = self.itemIconDic[itemId]
				local x = icon:getRealPos().x
				local y = icon:getRealPos().y
				GuideRenderMgr:getInstance():renderMainFlag(self.scrollView,param.id,param.target,ccp(x,y))
				break
			end
		end
	elseif param.target == "bag_itemgrid" then
		local itemIdArr = itemManager.backpackItemIdArr
		local backpackItemTab = itemManager.backpackItemTab
		for i = 1,#itemIdArr do
			local itemId = itemIdArr[i]
			if backpackItemTab[itemId].mode.base_id == 40001 then
				local icon = self.itemIconDic[itemId]
				local x = icon:getRealPos().x
				local y = icon:getRealPos().y
				GuideRenderMgr:getInstance():renderMainFlag(self.scrollView,param.id,param.target,ccp(x,y))
				break
			end
		end
	elseif param.target == "backpack_view" then
		GuideRenderMgr:getInstance():renderMainFlag(self.widget,param.id,param.target)

	elseif param.target == "backpack_item" then
    	if GuideDataProxy:getInstance().nowMainTutroialEventId == 10305 then
        	GuideRenderMgr:getInstance():renderMainFlag(self.item_info_view.apply_btn,param.id,param.target)
        end
	end
end


function BackPackView:showNumLabel()
	self.label_batch_node:removeAllNodes()
	local old_pos_y = -self.scrollView:getInnerContainer():getPositionY()
	local idx = 0
	local tmp_label = nil
	local tmp_count = self.num_label_arr:count()

	local idx_gift = 0
	local gift_count = self.gift_label_arr:count()

	local eqm_lv_idx = 0
	local eqm_lv_count = self.eqm_lv_label_arr:count() 

	for i,tmp_icon in pairs(self.itemIconDic) do
		if tmp_icon:getRealPos().y>old_pos_y-700 and tmp_icon:getRealPos().y<old_pos_y+1200 
			and tmp_icon:getIconBg():getParent() then
			if idx>=tmp_count then
				tmp_label = CCLabelTTF:create()
				tmp_label:setAnchorPoint(ccp(1,0))
				tmp_label:setFontSize(22)
				tmp_label:setColor(ItemHelper.colors.yellow)
				self.num_label_arr:addObject(tmp_label)
			else
				tmp_label = self.num_label_arr:objectAtIndex(idx)
			end
			tmp_label:setString(tmp_icon:getNumDesc())
			-- Utils.createStroke(tmp_label,11,ccc3(255,255,0),255)
			-- tmp_label:enableStroke(ccc3(0,0,0),1,true)

			tmp_label:setPosition(tmp_icon:getRealPos().x+42,tmp_icon:getRealPos().y-45)
			self.label_batch_node:addNode(tmp_label)
			idx = idx+1
------------------------------------------------------------------------------
			--礼包状态
			if tmp_icon:getItemData().mode.func_type == ItemHelper.func_type.gift_card then
				if idx_gift>=gift_count then
					tmp_label = CCLabelTTF:create()
					tmp_label:setAnchorPoint(ccp(1,0))
					tmp_label:setFontSize(22)
					self.gift_label_arr:addObject(tmp_label)
				else
					tmp_label = self.gift_label_arr:objectAtIndex(idx_gift)
				end			
				local str,color = tmp_icon:getItemData():getGiftStateStr()
				tmp_label:setString(str)
				tmp_label:setColor(color)
				tmp_label:setPosition(tmp_icon:getRealPos().x+42,tmp_icon:getRealPos().y+20)
				self.label_batch_node:addNode(tmp_label)
				idx_gift = idx_gift+1
			end
------------------------------------------------------------------------------
			--装备等级
			if itemManager:isEqm(tmp_icon:getItemData().mode.item_type) or 
				tmp_icon:getItemData().mode.item_type == ItemHelper.itemType.equip_fragment then

				if eqm_lv_idx>=eqm_lv_count then
					tmp_label = CCLabelTTF:create()
					tmp_label:setAnchorPoint(ccp(1,0))
					tmp_label:setFontSize(22)
					-- tmp_label:setString("12")
					tmp_label:setColor(ItemHelper.colors.yellow)
					-- tmp_label = Utils.createStrokeLabel(tmp_label,1,ccc3(0,0,0))
					self.eqm_lv_label_arr:addObject(tmp_label)
				else
					tmp_label = self.eqm_lv_label_arr:objectAtIndex(eqm_lv_idx)
				end
				tmp_label:setString(tmp_icon:getEqmLvDesc())

				tmp_label:setPosition(tmp_icon:getRealPos().x+42,tmp_icon:getRealPos().y+20)
				self.label_batch_node:addNode(tmp_label)
				eqm_lv_idx = eqm_lv_idx+1

			end
		end
	end
end

function BackPackView:getIconPosKey(row_value, col_value)
	local row_value = math.floor(row_value)
	local col_value = math.floor(col_value)
	cclog("row_value=%f~~~~~col_value=%f",row_value ,col_value)
	return row_value.."_"..col_value
end