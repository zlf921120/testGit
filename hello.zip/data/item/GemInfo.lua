--
-- Author: lvgansheng
-- Date: 2014-07-30 19:42:52
-- 宝石信息

GemInfo = class("GemInfo")
GemInfo.base_id = 0
GemInfo.gem_lev = 0
GemInfo.attr_type = 0
GemInfo.val = 0
GemInfo.enegry = 0
