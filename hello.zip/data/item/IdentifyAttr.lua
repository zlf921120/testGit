--
-- Author: lvgansheng
-- Date: 2014-06-16 19:55:48
-- 物品属性vo

IdentifyAttr = class("IdentifyAttr")
IdentifyAttr.flag = 0 --属性类型
IdentifyAttr.value = 0 -- 属性值
IdentifyAttr.stars = 0 -- 星级


