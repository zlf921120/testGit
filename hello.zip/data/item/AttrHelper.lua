--
-- Author: lvgansheng
-- Date: 2014-06-16 15:15:36
-- 属性的常量定义及相关转换

AttrHelper = {}

--属性种类
AttrHelper.attr_flag = {}
AttrHelper.attr_flag.hp = 1 --气血上限
AttrHelper.attr_flag.atk_speed = 2 --攻击速度
AttrHelper.attr_flag.atk = 3 --攻击
AttrHelper.attr_flag.pdef = 4 --防御
AttrHelper.attr_flag.crit = 5 --暴击
AttrHelper.attr_flag.block = 6 --格挡
AttrHelper.attr_flag.def_break = 7 --忽视防御
AttrHelper.attr_flag.evasion = 8 --闪避
AttrHelper.attr_flag.fight_back = 9 --反击
AttrHelper.attr_flag.reduce_harm = 10 --伤害豁免/减伤
AttrHelper.attr_flag.real_harm = 11 --真实伤害/法伤
AttrHelper.attr_flag.anti_stun = 12 --眩晕抵抗
AttrHelper.attr_flag.anti_silent = 13 --沉默抵抗
AttrHelper.attr_flag.anti_chaos = 14 --混乱抵抗
AttrHelper.attr_flag.anti_stone = 15 --石化抵抗
AttrHelper.attr_flag.anti_polymorph = 16 --变形抵抗
AttrHelper.attr_flag.anti_taunt = 17 --嘲讽抵抗
AttrHelper.attr_flag.anti_sleep = 18 --睡眠抵抗
AttrHelper.attr_flag.tought = 19 --坚韧
AttrHelper.attr_flag.break_atk = 20 --破击
AttrHelper.attr_flag.suck_blood = 21 --吸血
AttrHelper.attr_flag.stare = 22 --命中
AttrHelper.attr_flag.hp_cur = 23 --当前血值
--配置表用千分比, 代码计算用万分比
AttrHelper.attr_flag.anti_breakarmour = 24 --破甲抵抗
AttrHelper.attr_flag.anti_poisoning = 25 --中毒抵抗
AttrHelper.attr_flag.anti_burn = 26 --灼烧抵抗
AttrHelper.attr_flag.anti_bleed = 27 --流血抵抗
AttrHelper.attr_flag.anti_sacred_burn = 28 --神圣流血抵抗

--属性来源分类
AttrHelper.attr_source = {}
AttrHelper.attr_source.normal = 0 --普通属性
AttrHelper.attr_source.strength = 1 --强化属性
AttrHelper.attr_source.enhance = 2 --附魔属性
AttrHelper.attr_source.inlay = 3 --镶嵌属性
AttrHelper.attr_source.identify = 4 --鉴定属性

--特殊属性
AttrHelper.special_attr = {}
AttrHelper.special_attr[AttrHelper.attr_flag.anti_silent] = true
AttrHelper.special_attr[AttrHelper.attr_flag.anti_chaos] = true
AttrHelper.special_attr[AttrHelper.attr_flag.anti_stone] = true
AttrHelper.special_attr[AttrHelper.attr_flag.anti_polymorph] = true
AttrHelper.special_attr[AttrHelper.attr_flag.anti_taunt] = true
AttrHelper.special_attr[AttrHelper.attr_flag.anti_sleep] = true
AttrHelper.special_attr[AttrHelper.attr_flag.atk_speed] = true
AttrHelper.special_attr[AttrHelper.attr_flag.stare] = true
AttrHelper.special_attr[AttrHelper.attr_flag.anti_breakarmour] = true
AttrHelper.special_attr[AttrHelper.attr_flag.anti_poisoning] = true
AttrHelper.special_attr[AttrHelper.attr_flag.anti_burn] = true
AttrHelper.special_attr[AttrHelper.attr_flag.anti_bleed] = true
AttrHelper.special_attr[AttrHelper.attr_flag.anti_sacred_burn] = true


function AttrHelper:getAttrNameByFlag(flag)
	local flag_name = "未知屬性"

	if flag == AttrHelper.attr_flag.hp then
		flag_name = "生命"
	elseif flag == AttrHelper.attr_flag.atk then
		flag_name = "攻擊"
	elseif flag == AttrHelper.attr_flag.pdef then
		flag_name = "防禦"
	elseif flag == AttrHelper.attr_flag.crit then
		flag_name = "暴擊"
	elseif flag == AttrHelper.attr_flag.block then
		flag_name = "格擋"
	elseif flag == AttrHelper.attr_flag.def_break then
		flag_name = "忽視防禦"
	elseif flag == AttrHelper.attr_flag.evasion then
		flag_name = "閃避"
	elseif flag == AttrHelper.attr_flag.atk_speed then
		flag_name = "攻擊速度"
	elseif flag == AttrHelper.attr_flag.fight_back then
		flag_name = "反震"
	elseif flag == AttrHelper.attr_flag.reduce_harm then
		flag_name = "傷害豁免"
	elseif flag == AttrHelper.attr_flag.real_harm then
		flag_name = "真實傷害"
	elseif flag == AttrHelper.attr_flag.anti_stun then
		flag_name = "眩暈抵抗"
	elseif flag == AttrHelper.attr_flag.anti_silent then
		flag_name = "沉默抵抗"
	elseif flag == AttrHelper.attr_flag.anti_chaos then
		flag_name = "混亂抵抗"
	elseif flag == AttrHelper.attr_flag.anti_stone then
		flag_name = "石化抵抗"
	elseif flag == AttrHelper.attr_flag.anti_polymorph then
		flag_name = "變形抵抗"
	elseif flag == AttrHelper.attr_flag.anti_taunt then
		flag_name = "嘲諷抵抗"
	elseif flag == AttrHelper.attr_flag.anti_sleep then
		flag_name = "睡眠抵抗"
	elseif flag == AttrHelper.attr_flag.tought then
		flag_name = "堅韌"
	elseif flag == AttrHelper.attr_flag.break_atk then
		flag_name = "破擊"
	elseif flag == AttrHelper.attr_flag.suck_blood then
		flag_name = "吸血"
	elseif flag == AttrHelper.attr_flag.stare then
		flag_name = "命中"
	elseif flag == AttrHelper.attr_flag.anti_breakarmour then
		flag_name = "破甲抵抗"
	elseif flag == AttrHelper.attr_flag.anti_poisoning then
		flag_name = "中毒抵抗"
	elseif flag == AttrHelper.attr_flag.anti_burn then
		flag_name = "灼燒抵抗"
	elseif flag == AttrHelper.attr_flag.anti_bleed then
		flag_name = "流血抵抗"
	elseif flag == AttrHelper.attr_flag.anti_sacred_burn then
		flag_name = "神聖流血抵抗"
	end

	return flag_name
end

function AttrHelper:getAttrImgName(flag)
	local ret = "atk_attr_img"
	if flag == AttrHelper.attr_flag.hp then
		ret = "hp_attr_img"
	elseif flag == AttrHelper.attr_flag.atk then
		ret = "atk_attr_img"
	elseif flag == AttrHelper.attr_flag.pdef then
		ret = "pdef_attr_img"
	elseif flag == AttrHelper.attr_flag.crit then
		ret = "attr_crit"
	elseif flag == AttrHelper.attr_flag.block then
		ret = "attr_block"
	elseif flag == AttrHelper.attr_flag.def_break then
		ret = "attr_def_break"
	elseif flag == AttrHelper.attr_flag.evasion then
		ret = "attr_evasion"
	elseif flag == AttrHelper.attr_flag.atk_speed then
		ret = "atk_speed_attr_img"
	elseif flag == AttrHelper.attr_flag.reduce_harm then
		ret = "attr_real_harm"
	elseif flag == AttrHelper.attr_flag.break_atk then
		ret = "attr_break_atk"
	elseif flag == AttrHelper.attr_flag.suck_blood then
		ret = "attr_suck_blood"
	elseif flag == AttrHelper.attr_flag.tought then
		ret = "attr_tought"
	end
	return ret
end

--返回属性的字符串标识
function AttrHelper:getAttrStrFlag(flag)

	local str_flag = nil

	for k, v in pairs(AttrHelper.attr_flag) do
		if v == flag then
			return tostring(k)
		end
	end

	return nil
end

--根据属性的字符串标识返回名称描述
function AttrHelper:getAttrNameByStrFlag(str_flag)

	local flag_name = "未知屬性"

	if str_flag == "hp" then
		flag_name = "生命"
	elseif str_flag == "atk" then
		flag_name = "攻擊"
	elseif str_flag == "pdef" then
		flag_name = "防禦"
	elseif str_flag == "crit" then
		flag_name = "暴擊"
	elseif str_flag == "block" then
		flag_name = "格擋"
	elseif str_flag == "def_break" then
		flag_name = "忽視防禦"
	elseif str_flag == "evasion" then
		flag_name = "閃避"
	elseif str_flag == "atk_speed" then
		flag_name = "攻擊速度"					
	end

	return flag_name 
end

function AttrHelper:getAtkSpeedDesc(value)
	if value<10 then
		return "極慢"
	elseif value<20 then
		return "慢"
	elseif value<30 then
		return "較慢"
	elseif value<40 then
		return "較快"
	elseif value<50 then
		return "快"
	elseif value<60 then	
		return "極快"
	else
		return "最快"
	end
end

function AttrHelper:isSpecialAttr(flag)
	if AttrHelper.special_attr[flag] then
		return true
	end
	return false
end

