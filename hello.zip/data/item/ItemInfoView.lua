--
-- Author: lvgansheng
-- Date: 2014-07-08 15:23:36
-- 物品详细信息界面


ItemInfoView = class("ItemInfoView",WidgetBase)

ItemInfoView.uiLayer = nil
ItemInfoView.widget = nil
ItemInfoView.itemData = nil --当前点击的物品ID
ItemInfoView.item_icon = nil

--属性文本
ItemInfoView.team_lv_label = nil
ItemInfoView.item_type_label = nil
ItemInfoView.base_attr_label = nil
ItemInfoView.powered_lv_label = nil
ItemInfoView.enchant_label = nil
ItemInfoView.identify_dec_label = nil --鉴定描述
ItemInfoView.attr_label_dic = nil --鉴定属性记录
ItemInfoView.item_desc = nil --物品文字描述

ItemInfoView.win_type = 0 -- 0表示背包的物品信息界面，1表示英雄界面的装备信息界面, 2表示替换装备时的确认界面 

function ItemInfoView:init(win_type)
	--self.uiLayer = TouchGroup:create() 
    --self:addChild(self.uiLayer)
    require("AttrLabel")
    require("ItemIcon")
    
    self.win_type = win_type or 0

	self.attr_label_dic = CCDictionary:create()
	self.attr_label_dic:retain()	

	self.attr_label_dic2 = CCDictionary:create()	
	self.attr_label_dic2:retain()
	
	self.attr_label_dic3 = CCDictionary:create()	
	self.attr_label_dic3:retain()

	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/backpack/item_info/item_info.ExportJson")
    self:addChild(self.widget)

     if self.win_type ==1 then 
    	local bg = tolua.cast(self.widget:getChildByName("ImageView_52_Copy0"), "ImageView")
    	bg:setSize(CCSize(372,553))
    	self:setPositionX(37)
    	self:setPositionY(-2)
    end

    self.item_icon = ItemIcon:create()
    self.item_icon:setPosition(ccp(75,455))
    self:addChild(self.item_icon)

    self.attr_list_view = tolua.cast(self.widget:getChildByName("attr_listview"), "ListView") 

    self.team_lv_label = AttrLabel:create()
    self.team_lv_label:retain()
    self.team_lv_label:setData("戰隊等級:",10)
    --self.attr_list_view:pushBackCustomItem(self.team_lv_label)

    self.item_type_label = AttrLabel:create()
    self.item_type_label:setData("裝備類型:","武器")
    self.item_type_label:retain()
   -- self.attr_list_view:pushBackCustomItem(self.item_type_label)

    self.base_attr_label = AttrLabel:create()
    self.base_attr_label:setData("基礎屬性","100")
     self.base_attr_label:retain()
   -- self.attr_list_view:pushBackCustomItem(self.item_type_label)

    self.powered_lv_label = AttrLabel:create()
    self.powered_lv_label:setData("強化等級：","1")
    self.powered_lv_label:setEachLabelColor(1, ItemHelper.colors.deep_orange)
    self.powered_lv_label:retain()

    self.powered_attr_label = AttrLabel:create()
    self.powered_attr_label:setData("強化屬性：","1")
    self.powered_attr_label:retain()
   -- self.attr_list_view:pushBackCustomItem(self.item_type_label)

    self.enchant_label = AttrLabel:create()
    self.enchant_label:setData("附魔等級:1級")
    self.enchant_label:setEachLabelColor(1, ItemHelper.colors.deep_orange)
    -- self.enchant_label:setEachLabelColor(ItemHelper.colors.deep_yellow, 
    --  					ItemHelper.colors.green, ItemHelper.colors.green)
    self.enchant_label:retain()
   -- self.attr_list_view:pushBackCustomItem(self.item_type_label)



    self.identify_dec_label = AttrLabel:create()
    self.identify_dec_label:setData("鑒定屬性:")
    self.identify_dec_label:retain()
    self.identify_dec_label:setEachLabelColor(1, ItemHelper.colors.deep_orange)
   -- self.attr_list_view:pushBackCustomItem(self.identify_dec_label)

    -- self.gem_dec_label = AttrLabel:create()
    -- self.gem_dec_label:setData("鑲嵌寶石:")
    -- self.gem_dec_label:setSize(CCSize(300,38))
    -- self.gem_dec_label:retain()
    -- self.gem_dec_label:setEachLabelColor(1, ItemHelper.colors.deep_orange)

    self.gem_one_label =  AttrLabel:create()
    self.gem_one_label:setData("11級防禦石:","+800氣血")
    self.gem_one_label:setSize(CCSize(300,38))
    self.gem_one_label:retain()

    self.gem_two_label =  AttrLabel:create()
    self.gem_two_label:setData("11級防禦石:","+800氣血")
    self.gem_two_label:setSize(CCSize(300,38))
    self.gem_two_label:retain()

    self.gem_three_label =  AttrLabel:create()
    self.gem_three_label:setData("11級防禦石:","+800氣血")
    self.gem_three_label:setSize(CCSize(300,38))
    self.gem_three_label:retain()

    self.gem_suit_desc_label = AttrLabel:create()
    self.gem_suit_desc_label:setData("當前寶石套效果:")
    self.gem_suit_desc_label:setSize(CCSize(300,38))
    self.gem_suit_desc_label:retain()
    self.gem_suit_desc_label:setEachLabelColor(1, ItemHelper.colors.deep_orange)

    self.gem_suit_add_label = AttrLabel:create()
    self.gem_suit_add_label:setData("所有寶石屬性:","+25%")
    self.gem_suit_add_label:setSize(CCSize(300,38))
    self.gem_suit_add_label:retain()

    self.gem_suit_attr_title = AttrLabel:create()
    self.gem_suit_attr_title:setData("當前寶石套的珍稀屬性：")
    self.gem_suit_attr_title:setSize(CCSize(300,38))
    self.gem_suit_attr_title:retain()
    self.gem_suit_attr_title:setEachLabelColor(1, ItemHelper.colors.deep_orange)

    self.enchant_suit_attr_title = AttrLabel:create()
    self.enchant_suit_attr_title:setData("當前附魔套的屬性：")
    self.enchant_suit_attr_title:setSize(CCSize(300,38))
    self.enchant_suit_attr_title:retain()
    self.enchant_suit_attr_title:setEachLabelColor(1, ItemHelper.colors.deep_orange)

    self.lab_couttime = tolua.cast(self.widget:getChildByName("lab_couttime"), "Label") 
    -- self.gem_one_label:setEachLabelColor(1, ItemHelper.colors.deep_orange)

   	self.desc_layout = DisplayUtil.newLayout()
   	self.desc_layout:retain()
   	self.desc_layout:setSize(CCSize(300,105))

   	self.item_desc = Label:create()
   	self.item_desc:setColor(ItemHelper.colors.yellow)
   	self.item_desc:ignoreContentAdaptWithSize(false)
	self.item_desc:setAnchorPoint(ccp(0,1))
	self.item_desc:setPosition(ccp(10,105))
	self.item_desc:setSize(CCSize(282,205))
   	self.item_desc:setFontSize(24)
  	-- self.desc_layout:retain()
   	self.desc_layout:addChild(self.item_desc)

    self.selBtn = tolua.cast(self.widget:getChildByName("sell_btn"), "Button")  	--出售按钮
    if self.win_type == 1 then
    	self.selBtn:setTitleText("鍛造")
    end

    local function selBtnfun(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
			if self.win_type == 0 then
				WindowCtrl:getInstance():open(CmdName.BACKPACK_SELL_VIEW, self.itemData)
			elseif self.win_type ==1 then
				WindowCtrl:getInstance():open(CmdName.Eqm_Forge_View,{self.itemData,self.itemData.mode.item_type})
			end
        end
    end
    self.selBtn:addTouchEventListener(selBtnfun)

    self.apply_btn = tolua.cast(self.widget:getChildByName("apply_btn"), "Button")  	--出售按钮
    if self.win_type == 1 then
    	 self.apply_btn:setTitleText("替換")
    end

    local function applyBtnFun(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
			if self.win_type == 0 then
				--WindowCtrl:getInstance():open(CmdName.BACKPACK_SELL_VIEW, self.itemData)
				if self.itemData.mode.func_type == ItemHelper.func_type.exp_medicine then
					local params = {}
					params.func_type = 1
					params.use_item_id = self.itemData.id
					WindowCtrl:getInstance():open(CmdName.Hero_List_View,params,false)
				elseif self.itemData.mode.func_type == ItemHelper.func_type.get_skill_point then
					WindowCtrl:getInstance():open(CmdName.GetSkillPointView)
				elseif self.itemData.mode.func_type == ItemHelper.func_type.enchant_energy then
					--打开附魔面板
					local enchat_item = ItemManager:getInstance():getFitEqmToEnchant()
					if enchat_item then
						WindowCtrl:getInstance():open(CmdName.Eqm_Forge_View,
									{enchat_item,enchat_item.mode.item_type,HeroHelper.forgePanelType.enchant})
					else
						Alert:show("您沒有穿戴裝備，裝備穿戴後可附魔")
					end
				elseif self.itemData.mode.func_type == ItemHelper.func_type.gem_inlay then
					local gem_item = ItemManager:getInstance():getFitEqmToGem(self.itemData.mode.base_id)
					if gem_item then
						WindowCtrl:getInstance():open(CmdName.Eqm_Forge_View,
									{gem_item,gem_item.mode.item_type,HeroHelper.forgePanelType.gem})
					else
						Alert:show("您沒有穿戴裝備，裝備穿戴後鑲嵌寶石")
					end
				elseif self.itemData.mode.func_type == ItemHelper.func_type.hero_upgrade then
					local hero_base_id = HeroManager:getInstance():findHeroByGemId(self.itemData.mode.base_id)
					local hero_info = HeroManager:getInstance():getHeroInfoByBaseId(hero_base_id)
					if hero_info.id>0 then
						WindowCtrl:getInstance():open(CmdName.Hero_View,hero_base_id)
				        local param = {}
				        table.insert(param,HeroHelper.leftPanelType.heroUpgradeView)
				        Notifier.dispatchCmd(CmdName.CtrlRoleLeftPanel,param)
				    else
				    	WindowCtrl:getInstance():open(CmdName.Hero_List_View)
				    end
				elseif self.itemData.mode.func_type == ItemHelper.func_type.eqm_on then

					if self.itemData.mode.limit_lev>CharacterManager:getInstance():getTeamData():getLev() then
						 Alert:show(string.format("您的戰隊等級未滿%d級，努力升級哦。",self.itemData.mode.limit_lev))
						 return
					end

					local hero_id = HeroManager:getInstance():findFitHeroToEqmOn(self.itemData)
					if hero_id>0 then
						WindowCtrl:getInstance():open(CmdName.Hero_View,hero_id)
						local params = {}
						params.hero_id = hero_id
						params.item = self.itemData
						params.location = self.itemData.mode.item_type
						WindowCtrl:getInstance():open(CmdName.EqmOnConfirmView, params) 
					else
						Alert:show(string.format("您的戰隊%s沒有上陣英雄，不能穿戴裝備哦",
							ItemHelper:getLimitStandName(self.itemData.mode.limit_stand)))
					end
				elseif self.itemData.mode.func_type == ItemHelper.func_type.money_card then
					--资产卡，如果数量大于1，则弹出批量使用界面，否则直接发使用协议
					if self.itemData.quantity>1 then
						WindowCtrl:getInstance():open(CmdName.BatchUseItemView, self.itemData)
					else
						ItemManager:getInstance():sendSellItemReq(self.itemData.id, 1)   
					end

				elseif self.itemData.mode.func_type == ItemHelper.func_type.eqm_upgrade then --装备升级
					
					WindowCtrl:getInstance():open(CmdName.ItemUpgradeView,{item = self.itemData})
				elseif self.itemData.mode.func_type == ItemHelper.func_type.pet_levup then
					if ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Elf,nil,false) then
						WindowCtrl:getInstance():open(CmdName.Pet_View)
						WindowCtrl:getInstance():open(CmdName.Pet_View_Levup)
					else
						Alert:show("你還沒有召喚出侍寵精靈")
					end
				elseif self.itemData.mode.func_type == ItemHelper.func_type.pet_upgrade then
					if ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Elf,nil,false) then
						WindowCtrl:getInstance():open(CmdName.Pet_View)
						WindowCtrl:getInstance():open(CmdName.Pet_View_Upgrade)
					else
						Alert:show("你還沒有召喚出侍寵精靈")
					end
				elseif self.itemData.mode.func_type == ItemHelper.func_type.gift_card then
					if self.itemData.mode.limit_vip>CharacterDataProxy:getInstance():getVipLev() then
						Alert:show(string.format("您的VIP等級不足%d級，無法打開禮包哦",self.itemData.mode.limit_vip))
						return
					end
					--礼包卡
					if self.itemData.mode.limit_lev>CharacterManager:getInstance():getTeamData():getLev() then
						 Alert:show(string.format("您的戰隊等級不足%d級，快提升等級吧。",self.itemData.mode.limit_lev))
						 return
					end

					if self.itemData.mode.expire_type == ItemHelper.expire_type.forever then
						if self.itemData.quantity>1 then
							WindowCtrl:getInstance():open(CmdName.BatchUseItemView, self.itemData)
						else
							ItemManager:getInstance():sendItemUseReq(1,self.itemData.id,1,0)  
						end
					else
						local left,type = self.itemData:getLeftTime()
						if type == -1 then
							Alert:show("禮包未生效")
						elseif type == 1 then
							Alert:show("禮包已過期")
						else
							--礼包卡 限时
							WindowCtrl:getInstance():open(CmdName.Reward_MultGiftPanel,{itemData = self.itemData})
						end
					end
				elseif self.itemData.mode.func_type == ItemHelper.func_type.mystery_refresh then
					--神秘商店刷新卡
					if ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Mystery,nil,false) then
		                require "ShopCfg"
		                WindowCtrl:getInstance():open(CmdName.Shop_View,{area = BuyArea.Mystery})
		           	else
						Alert:show("你還沒有開啟神秘商人")
		            end
				end
			elseif self.win_type == 1 then
			 	local param = {}
	            table.insert(param,HeroHelper.leftPanelType.equipListView)
	            table.insert(param,self.itemData.mode.item_type)
	            Notifier.dispatchCmd(CmdName.CtrlRoleLeftPanel,param)
			end
        end
    end

     self.apply_btn:addTouchEventListener(applyBtnFun)

     --获得更强装备
     self.btn_getbetter = tolua.cast(self.widget:getChildByName("btn_getbetter"),"Button")
     self.btn_getbetter:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then

        	local hero_id = HeroManager:getInstance():findFitHeroToEqmOn(self.itemData)
        	local heroInfo = HeroManager:getInstance():getHeroInfoByBaseId(hero_id)
      		local param = {}
        	param.hero_pos = heroInfo.pos
        	param.eqm_type = self.itemData.mode.item_type
        	param.find_type = ItemHelper.find_type.better_eqm
       		WindowCtrl:getInstance():open(CmdName.FindEqmView,param)
       	end
     end)

     --升级装备
     self.btn_upgrade = tolua.cast(self.widget:getChildByName("btn_upgrade"),"Button")
     self.btn_upgrade:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then

       		WindowCtrl:getInstance():open(CmdName.ItemUpgradeView,{ item = self.itemData })
       	end
     end)
    self.btn_upgrade:setEnabled(false)
	self.btn_getbetter:setEnabled(false)

    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function ItemInfoView:create(win_type)
	local item_info_view = ItemInfoView.new()
	item_info_view:init(win_type)
	return item_info_view
end

--新手引导动画
function ItemInfoView:showStepAnim(param)
    if param.target == "backpack_eqm" then
        GuideRenderMgr:getInstance():renderMainFlag(self.apply_btn,param.id,param.target)
    elseif param.target == "backpack_ex" then
    	GuideRenderMgr:getInstance():renderMainFlag(self.apply_btn,param.id,param.target)
    end
end

function ItemInfoView:setItemData(item)
	self.itemData = item 
	self.attr_flag = ItemHelper:getAttrFlagByLocation(item.mode.item_type)
	
	self:changeContent()
	self:checkGetBetterStatus()
end

function ItemInfoView:changeContent()
	self.item_icon:setBaseId(self.itemData.mode.base_id)
	if self.itemData.powered_lev>0 then
		self.item_icon:setPowerNum(self.itemData.powered_lev)
	elseif self.win_type == 0 then
		self.item_icon:setItemNum(1)
	else
		self.item_icon:setPowerNum(0)
	end
	
	local namelabel = self.widget:getChildByName("name_label")
	tolua.cast(namelabel,"Label")
	namelabel:setText(self.itemData.mode.name)
	namelabel:setColor(ItemHelper:getColorByQuality(self.itemData.mode.quality))

	self.attr_list_view:removeAllItems()

	if self.itemData.mode.limit_lev>0 then
		self.team_lv_label:setData("戰隊等級:",self.itemData.mode.limit_lev)
		self.attr_list_view:pushBackCustomItem(self.team_lv_label)
	end

	local fc_txt_img = self.widget:getChildByName("ImageView_55")
	local fc_txt_label = tolua.cast(self.widget:getChildByName("fight_capacity_label"), "Label") 

	local enchant_ratio = ItemManager:getInstance():getEnchantRation(self.itemData.enchant_lev) -- 附魔系数

	self.lab_couttime:setText("")
	self.desc_layout:removeChildByTag(1521,true)
	self.desc_layout:removeChildByTag(1522,true)	
	self.desc_layout:setSize(CCSize(300,105))

	if ItemManager:getInstance():isEqm(self.itemData.mode.item_type) == false then

		self.item_desc:setColor(ItemHelper.colors.yellow)
		self.item_desc:setText(self.itemData.mode.desc)

		if self.itemData.mode.func_type == ItemHelper.func_type.gift_card then

			-- local extStr = "" --礼包倒计时
			-- local extStrEnd = ""
			-- local extLn = ""

			-- self.item_desc:setText("")

			-- if self.itemData.mode.expire_type == ItemHelper.expire_type.couttime then
			-- 	-- extStr = os.date("　　　　%Y年%m月%d日",self.itemData.gift.create_time) .. 
			-- 	-- 		"-" .. os.date("%Y年%m月%d日",self.itemData:getEndTime()) .. "\n"
			-- 	self.lab_couttime:setText(Helper.getChCoutStringTime(self.itemData:getLeftTime()))
			-- 	extStr = "　　　　"..self.itemData.mode.expire_time .. "小時\n"
			-- elseif self.itemData.mode.expire_type == ItemHelper.expire_type.interval then
			-- 	extLn = "\n"
			-- 	extStr = os.date("　　　　%Y年%m月%d日",Helper.getNewTime(self.itemData.mode.expire_beg)) .. 
			-- 			"-" .. os.date("%Y年%m月%d日",self.itemData:getEndTime()) .. "\n"
			-- 	self.lab_couttime:setText(Helper.getChCoutStringTime(self.itemData:getLeftTime()))
			-- end

			-- extStrEnd = ItemManager:getInstance():giftRelationListStr(self.itemData.mode.base_id)
		
			-- self.lab_gift_desc = Label:create()
			-- self.lab_gift_desc:setFontSize(24)
			-- self.lab_gift_desc:setColor(ItemHelper.colors.yellow)
		 --   	self.lab_gift_desc:ignoreContentAdaptWithSize(false)
			-- self.lab_gift_desc:setAnchorPoint(ccp(0,1))

			-- self.desc_layout:setSize(CCSize(300,350))
			-- local cellSize = self.desc_layout:getSize()

			-- self.lab_gift_desc:setPosition(ccp(10,cellSize.height))
			-- self.lab_gift_desc:setSize(CCSize(305,cellSize.height))
			
			-- local vipLimit = ""
			-- local vipLimitLev = ""
			-- if self.itemData.mode.limit_vip > 0 then
			-- 	vipLimit = "VIP等級：\n"
			-- 	vipLimitLev = "　　　 　"..self.itemData.mode.limit_vip.."\n"
			-- end

			-- local costTips = ""
			-- local costNum = ""
			-- require "ShopCfg"
			-- if self.itemData.mode.gain_cost > 0 then
			-- 	costTips = "打開消耗：\n"
			-- 	costNum = "　　　 　 "..self.itemData.mode.gain_cost .. CurrencyName[self.itemData.mode.gain_currency].."\n"
			-- end

			-- local itemModeDesc = Helper.insertnl(self.itemData.mode.desc,12)
			-- local numLn = Helper.nlCount(itemModeDesc)
			-- local extLn2 = "\n"
			-- for i=1,numLn do
			-- 	extLn2 = extLn2 .. "\n"
			-- end

			-- self.lab_gift_desc:setTag(1521)
			-- self.lab_gift_desc:setText(extStr .. vipLimitLev..costNum.. extLn2..extStrEnd)
			-- self.desc_layout:addChild(self.lab_gift_desc)

			-- self.lab_item_desc_title = Label:create()
			-- self.lab_item_desc_title:setFontSize(24)
			-- self.lab_item_desc_title:setColor(ItemHelper.colors.deep_yellow)
		 --   	self.lab_item_desc_title:ignoreContentAdaptWithSize(false)
			-- self.lab_item_desc_title:setAnchorPoint(ccp(0,1))
			-- self.lab_item_desc_title:setPosition(ccp(10,cellSize.height))
			-- self.lab_item_desc_title:setSize(CCSize(305,cellSize.height))

			-- if extStr ~= "" then
			-- 	self.lab_item_desc_title:setText("有效期：\n"..extLn..vipLimit..costTips.. self.itemData.mode.desc)
			-- else
			-- 	self.lab_item_desc_title:setText(itemModeDesc)
			-- end

			-- self.lab_item_desc_title:setTag(1522)
			-- self.desc_layout:addChild(self.lab_item_desc_title)

			--倒计时
			local extStr = ""
			if self.itemData.mode.expire_type == ItemHelper.expire_type.couttime then
				self.lab_couttime:setText(Helper.getChCoutStringTime(self.itemData:getLeftTime()))
				extStr = self.itemData.mode.expire_time .. "小時"
			elseif self.itemData.mode.expire_type == ItemHelper.expire_type.interval then
				extStr = os.date("%Y年%m月%d日",Helper.getNewTime(self.itemData.mode.expire_beg)) .. 
						"-" .. os.date("%Y年%m月%d日",self.itemData:getEndTime()) 
				self.lab_couttime:setText(Helper.getChCoutStringTime(self.itemData:getLeftTime()))
			end

			if extStr ~= "" then
				local size = Helper.makeStrSize("有效期："..extStr,300)
				local rtfLeftTime = ChatHelper.createRtf({{txt="有效期：",color=ItemHelper.colors.deep_yellow},{txt=extStr}},
					size.width,size.height,ccp(0,0))
				rtfLeftTime:setPositionX(10)
				local tmpLayout = Layout:create()
				tmpLayout:setSize(size)
				tmpLayout:addChild(rtfLeftTime)
				self.attr_list_view:pushBackCustomItem(tmpLayout)
			end

			--vip 等级 
			if self.itemData.mode.limit_vip > 0 then
				self.base_attr_label:setData("VIP等級：",self.itemData.mode.limit_vip) 
				self.attr_list_view:pushBackCustomItem(self.base_attr_label)
			end
			--打开消耗
			if self.itemData.mode.gain_cost > 0 then
				require "ShopCfg"
				self.item_type_label:setData("打開消耗：",self.itemData.mode.gain_cost .. CurrencyName[self.itemData.mode.gain_currency])
				self.attr_list_view:pushBackCustomItem(self.item_type_label)
			end
			--礼包描述
			self.team_lv_label:setData(self.itemData.mode.desc)
			self.attr_list_view:pushBackCustomItem(self.team_lv_label)
			--礼包预览
			local labGiftPreview = Label:create()
			labGiftPreview:setAnchorPoint(ccp(0,0))
			labGiftPreview:setFontSize(22)
			labGiftPreview:setColor(ItemHelper.colors.yellow)
			labGiftPreview:setPositionX(10)
			labGiftPreview:setText(ItemManager:getInstance():giftRelationListStr(self.itemData.mode.base_id))
			local tmpLayout = Layout:create()
			tmpLayout:setSize(labGiftPreview:getSize())
			tmpLayout:addChild(labGiftPreview)
			self.attr_list_view:pushBackCustomItem(tmpLayout)
		else
			self.attr_list_view:pushBackCustomItem(self.desc_layout)
		end
		return 
	end

	self.item_type_label:setData("裝備類型:",ItemHelper:getTypeName(self.itemData.mode.item_type))
	
	local attr_name = AttrHelper:getAttrNameByFlag(self.attr_flag)
 	local attrs = ItemManager:getInstance():getEqmBaseAttrAddQuality(self.itemData.mode.base_id)
 	if enchant_ratio>0 then
		self.base_attr_label:setData(attr_name..":",attrs[self.attr_flag],
			math.ceil(attrs[self.attr_flag]*enchant_ratio))
	else
		self.base_attr_label:setData(attr_name..":",attrs[self.attr_flag])
	end

	self.attr_list_view:pushBackCustomItem(self.item_type_label)
	self.attr_list_view:pushBackCustomItem(self.base_attr_label)

	--强化等级处理
	if self.itemData.powered_lev>0 then
		 local powered_attrs =  ItemManager:getInstance():getEqmPoweredAttr(self.itemData.mode.base_id,
		 						self.itemData.powered_lev)
		 self.powered_lv_label:setData("強化等級:",self.itemData.powered_lev)
		 self.attr_list_view:pushBackCustomItem(self.powered_lv_label)
		 if enchant_ratio>0 then
		 	self.powered_attr_label:setData(attr_name..":",math.ceil(powered_attrs[self.attr_flag]),
		 										math.ceil(powered_attrs[self.attr_flag]*enchant_ratio))
		 else
		 	self.powered_attr_label:setData(attr_name..":",math.ceil(powered_attrs[self.attr_flag]))
		 end
		 self.attr_list_view:pushBackCustomItem(self.powered_attr_label)
	end 

	--附魔等级处理
	if self.itemData.enchant_lev>0 then
		self.enchant_label:setEachLabelColor(2,ItemHelper:getEnchantColor(self.itemData.enchant_lev))
		self.powered_attr_label:setEachLabelColor(3,ItemHelper:getEnchantColor(self.itemData.enchant_lev))
		self.base_attr_label:setEachLabelColor(3,ItemHelper:getEnchantColor(self.itemData.enchant_lev))

		self.enchant_label:setData("附魔等級:",string.format("%d級",self.itemData.enchant_lev))
		self.attr_list_view:pushBackCustomItem(self.enchant_label)
		-- self.enchant_label:set
		--显示附魔特效
		self.item_icon:setEnchanteffect(self.itemData.enchant_lev)
	else
		self.item_icon:setEnchanteffect(0)
	end

	--鉴定属性处理
	local identify_attrs = self.itemData.identify_attrs
	local count = #identify_attrs
	local attr_vo = nil
	local attr_label = nil
	if count>0 then
		self.identify_dec_label:setData("鑒定屬性:")
		self.attr_list_view:pushBackCustomItem(self.identify_dec_label)

		for key=1,count do
			attr_vo = identify_attrs[key]
			attr_label = self.attr_label_dic:objectForKey(key)
			if attr_label == nil then
				attr_label = AttrLabel:create()
				self.attr_label_dic:setObject(attr_label, key)
			end
			attr_label:setData(AttrHelper:getAttrNameByFlag(attr_vo.flag)..":",string.format("%d   (%d星)",
								attr_vo.value,attr_vo.stars))
			attr_label:setEachLabelColor(2,ItemHelper.colors.blue)
			--attr_label:setData(AttrHelper:getAttrNameByFlag(attr_vo.flag)..":",
									-- attr_vo.value,string.format("(%d星)",attr_vo.stars))
			self.attr_list_view:pushBackCustomItem(attr_label)
		end
	elseif self.itemData.mode.quality>ItemHelper.itemQuality.Blue then
		self.identify_dec_label:setData("鑒定屬性：","尚未鑒定")
		self.attr_list_view:pushBackCustomItem(self.identify_dec_label)
	end

	-- local gem_item_icon = nil
	-- local gems = self.itemData.gems
	-- local gem_dis = 0
	-- local temp_gem_data = nil
	-- for gem_idx =1,3 do
	-- 	gem_item_icon = self.gem_icon_dic:objectForKey(gem_idx)
	-- 	if gem_item_icon == nil then
	-- 		gem_item_icon = ImageView:create()
	-- 		gem_item_icon:setScale(0.7)
	-- 		gem_item_icon:setAnchorPoint(ccp(0,0))
	-- 		self.gem_icon_dic:setObject(gem_item_icon, gem_idx)
	-- 		self.gem_layer:addChild(gem_item_icon)
	-- 	end

	-- 	if gems[gem_idx] then
	-- 		temp_gem_data = ItemManager:getInstance():getItemModelByBaseId(gems[gem_idx])
	-- 		gem_item_icon:loadTexture(string.format("item_%d.png",temp_gem_data.icon_id), UI_TEX_TYPE_PLIST)
	-- 		gem_item_icon:setVisible(true)
	-- 		gem_item_icon:setPositionX(gem_dis+5)
	-- 		gem_dis = gem_dis+70
	-- 	else
	-- 		gem_item_icon:setVisible(false)
	-- 	end
	-- end

	-- if gem_dis>0 then
	-- 	self.attr_list_view:pushBackCustomItem(self.gem_dec_label)
	-- 	self.attr_list_view:pushBackCustomItem(self.gem_layer)

	-- end

	local gems = self.itemData.gems
	local gem_label_status ={}
	local temp_item_mode = nil
	local temp_gem_data = nil
	local gem_attr_name = nil
	local gem_value_str = nil
	for gem_idx =1,3 do
		if gems[gem_idx] then
			temp_item_mode = ItemManager:getInstance():getItemModelByBaseId(gems[gem_idx])
			temp_gem_data =  ItemManager:getInstance():getGemInfo(gems[gem_idx])

			if self.gem_one_label:getParent()==nil then
				self.gem_one_label:setData(temp_item_mode.name..":",string.format(" +%d",
						temp_gem_data.val,AttrHelper:getAttrNameByFlag(temp_gem_data.attr_type)))
				self.attr_list_view:pushBackCustomItem(self.gem_one_label)
			elseif self.gem_two_label:getParent()==nil then
				self.gem_two_label:setData(temp_item_mode.name..":",string.format(" +%d",
						temp_gem_data.val,AttrHelper:getAttrNameByFlag(temp_gem_data.attr_type)))
				self.attr_list_view:pushBackCustomItem(self.gem_two_label)
			elseif self.gem_three_label:getParent()==nil then	
				self.gem_three_label:setData(temp_item_mode.name..":",string.format(" +%d",
						temp_gem_data.val,AttrHelper:getAttrNameByFlag(temp_gem_data.attr_type)))
				self.attr_list_view:pushBackCustomItem(self.gem_three_label)
			end

		end
	end

	local eqms = HeroManager:getInstance():getBattleHeroEqmList(self.itemData.hero_id)
	if eqms then
		local min_gem_lv,gem_count =  eqms:getGemSuitLv()
		if min_gem_lv>=HeroManager.MIN_GEM_LV_FOR_SUIT then
			local gem_suit_ratio = ItemManager:getInstance():getGemSuitRationByLv(min_gem_lv)*100
			self.gem_suit_add_label:setData("所有寶石屬性:",string.format("+%s%%",gem_suit_ratio))
			self.gem_suit_add_label:setEachLabelColor(2, ItemHelper:getGemSuitAttrLabelColor(min_gem_lv))

			self.attr_list_view:pushBackCustomItem(self.gem_suit_desc_label)
			self.attr_list_view:pushBackCustomItem(self.gem_suit_add_label)

			-- 当前宝石套的珍稀属性：
			local attr = ItemManager:getInstance():getGemSuitAttr(min_gem_lv)
			if attr then
				self.attr_list_view:pushBackCustomItem(self.gem_suit_attr_title)

				local i = 0
				local attr_label = nil
				for k,v in pairs(attr) do
					i = i + 1
					attr_label = self.attr_label_dic2:objectForKey("gem_suit_attr"..i)
					if attr_label == nil then
						attr_label = AttrLabel:create()
						self.attr_label_dic2:setObject(attr_label, "gem_suit_attr"..i)
					end
					attr_label:setData(AttrHelper:getAttrNameByFlag(k)..":"," +"..v)
					self.attr_list_view:pushBackCustomItem(attr_label)
				end
			end
		end

		local lv,progress = eqms:getEnchantSuitLv()
		if lv>=HeroManager.MIN_ENCHANT_LV_FOR_SUIT then
			-- 当前附魔套的珍稀属性：
			local attr = ItemManager:getInstance():getEnchantSuitAttr(lv)
			if attr then
				self.attr_list_view:pushBackCustomItem(self.enchant_suit_attr_title)

				local i = 0
				local attr_label = nil
				for k,v in pairs(attr) do
					i = i + 1
					attr_label = self.attr_label_dic3:objectForKey("enchant_suit_attr"..i)
					if attr_label == nil then
						attr_label = AttrLabel:create()
						self.attr_label_dic3:setObject(attr_label, "enchant_suit_attr"..i)
					end
					attr_label:setData(AttrHelper:getAttrNameByFlag(k)..":"," +"..v)
					self.attr_list_view:pushBackCustomItem(attr_label)
				end
			end
		end
	end
    

	self.item_desc:setText(self.itemData.mode.desc)
	self.attr_list_view:pushBackCustomItem(self.desc_layout)
end

--检测该装备是否需要 升级/获得更强
function ItemInfoView:checkGetBetterStatus()
	local isShowArm = false --展示特效
	local infos = HeroManager:getInstance():getBetterEqmGuideInfos(self.itemData.mode.limit_stand,self.itemData.mode.item_type)
	if infos == nil or self.itemData.hero_id == 0 then
		self.btn_upgrade:setEnabled(false)
		self.btn_getbetter:setEnabled(false)

	elseif self.itemData.mode.base_id ~= infos[1].target_base_id then  --
		if self.itemData.mode.limit_lev >= 40 and self.itemData.mode.quality >= ItemHelper.itemQuality.Purple then
			self.btn_upgrade:setEnabled(true)   --有紫装 40级后 但未到90级紫装
			self.btn_getbetter:setEnabled(false)
			isShowArm = true
		else
			self.btn_upgrade:setEnabled(false)  --没穿上 40级前 对应最高的装备时候
			self.btn_getbetter:setEnabled(true)
		end

		if self.itemData.mode.limit_lev >= 90 and self.itemData.mode.quality >= ItemHelper.itemQuality.Purple then
			self.btn_upgrade:setEnabled(false) --有紫装 90级 
			self.btn_getbetter:setEnabled(false)
		end
	elseif self.itemData.mode.base_id == infos[1].target_base_id and self.itemData.mode.limit_lev == 40 then
		self.btn_upgrade:setEnabled(true)
		self.btn_getbetter:setEnabled(false)
		isShowArm = true
	elseif self.itemData.mode.base_id == infos[1].target_base_id then --已经穿上当前等级阶段最强 紫装
		self.btn_upgrade:setEnabled(false)
		self.btn_getbetter:setEnabled(false)
	end
-------------------------------------------------------------------
	local child = self.widget:getNodeByTag(1441)
	if child ~= nil then
		self.widget:removeNode(child)
	end
	if isShowArm and ItemManager:getInstance():isCanEqmUpgrade(self.itemData)  then
		CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo("ui/effects_ui/zhuangbeishengji/zhuangbeishengji.ExportJson")
		local arm = CCArmature:create("zhuangbeishengji")
		arm:setPosition(ccp(self.btn_upgrade:getPosition()))
		arm:getAnimation():play("Animation1",0,-1,1)
		arm:setTag(1441)
		self.widget:addNode(arm)
	end
-------------------------------------------------------------------
end

function ItemInfoView:getItemId()
	if self.itemData then
		return self.itemData.id
	else
		return 0
	end
end