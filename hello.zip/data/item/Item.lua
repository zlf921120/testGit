--物品数据类
require("IdentifyAttr")

Item = class("Item")

local max_count = 5

Item.id = 0 -- 物品的唯一ID
Item.quantity = 0 --物品数量
Item.mode = nil -- 物品的基础信息,类型是ItemMode
Item.attrs = nil -- 物品属性
Item.powered_lev = 0 -- 强化等级
Item.enchant_lev = 0 -- 附魔等级
Item.enchant_energy = 0 -- 附魔当前附带能量
Item.hero_id = 0 -- 当前装备所属的英雄ID
Item.identify_attrs = nil -- 鉴定所带来的属性
Item.identify_left_num = max_count -- 剩余鉴定次数
Item.identify_lucky = 0 --装备当前 鉴定幸运值
Item.gems = nil --装备上所镶嵌的宝石信息
Item.is_eqm_on = false --是否装备在上阵英雄身上
Item.total_identify_stars = 0 --鉴定总星数
Item.gift = nil --礼包信息
Item.isViewFashionInfo = true --是否显示时装信息

function Item:setItemInfo(id, base_id, quantity)
	self.id = id
    self.mode = ItemManager:getInstance():getItemModelByBaseId(base_id)
    self.quantity = quantity

    self.gems = self.gems or {}
    self.identify_attrs = self.identify_attrs or {}
end

--设置强化等级
function Item:setPoweredLev(lev)
	self.powered_lev = lev
end

--设置附魔等级
function Item:setEnchantLev(lev)
	self.enchant_lev = lev
end

--设置附魔当前附带能量
function Item:setEnchantEnergy(energy)
	self.enchant_energy = energy
end

--设置所属英雄ID
function Item:setHeroId(hero_id)
	self.hero_id = hero_id
	if hero_id>0 then
		is_eqm_on = true
	else
		is_eqm_on = false
	end
end

--设置时装信息
function Item:setViewFashionInfo(b)
	self.isViewFashionInfo = b
end

--设置鉴定剩余次数
function Item:setIdentifyInfo(identify_left_num,identify_lucky)
	self.identify_left_num = identify_left_num
	self.identify_lucky = identify_lucky
end

--设置鉴定属性
function Item:setIdentifyAttrs(attrs)

	self.identify_attrs = {}
	self.total_identify_stars =0
	local attr_infos = attrs
	if attr_infos then 
		local one_attr_info = nil
		local one_attr_vo = nil
		local count = #attr_infos
		for i=1,count do
		  one_attr_info = attr_infos[i] 
		  one_attr_vo = IdentifyAttr.new()
		  one_attr_vo.flag = one_attr_info.name
		  one_attr_vo.value = one_attr_info.val
		  one_attr_vo.stars = one_attr_info.stars
		  one_attr_vo.attr_id = one_attr_info.attr_id
		  one_attr_vo.is_locked = one_attr_info.is_locked
		  self.identify_attrs[i] = one_attr_vo
		  self.total_identify_stars = self.total_identify_stars + one_attr_info.stars
		end
     end	
end

--设置单个镶嵌宝石信息
function Item:setGems(gems)
	self.gems = gems or {}
end

--设置礼包信息
function Item:setGiftInfo(info)
	self.gift = self.gift or {}
	self.gift.create_time = info.create_time
end

--获取礼包倒计时
function Item:getLeftTime()
	local ret = 0
	local type = 0 --正常
	if self.mode.expire_type == ItemHelper.expire_type.couttime then

		local nowTime = ServerTimerManager:getInstance():getCurTime()
		ret = math.max(0,self.gift.create_time + tonumber(self.mode.expire_time) * 60 * 60 - nowTime)
		
		if ret < 0 then
			type = 1
		end

	elseif self.mode.expire_type == ItemHelper.expire_type.interval then
		local begTime = Helper.getNewTime(self.mode.expire_beg)
		local endTime = Helper.getNewTime(self.mode.expire_end)

		local nowTime = ServerTimerManager:getInstance():getCurTime()
		if nowTime >= begTime and nowTime < endTime then
			ret = math.max(0,endTime - nowTime)
		elseif nowTime < begTime then --未到期
			type = -1
		elseif nowTime >= endTime then --过期
			type = 1
		end
	end
	return ret,type
end

--获取礼包 过期时间
function Item:getEndTime()
	local ret = 0
	if self.mode.expire_type == ItemHelper.expire_type.couttime then
		ret = self.gift.create_time + self.mode.expire_time * 60 * 60
	elseif self.mode.expire_type == ItemHelper.expire_type.interval then
		ret = Helper.getNewTime(self.mode.expire_end)
	end
	return ret
end

--获取礼包 状态描述
function Item:getGiftStateStr()
	local time,type = self:getLeftTime()
	local ret = ""
	local color = ccc3(0xff,0xb1,0x09)
	if type == -1 then
		ret = "未生效"
		color = ccc3(0xff,0xb1,0x09)
	elseif type == 1 then
		ret = "過期"
		color = ccc3(0xff,0x09,0x09)
	elseif type == 0 and self.mode.expire_type ~= ItemHelper.expire_type.forever then
		ret = "限時"
		color = ccc3(0xff,0xb1,0x09)
	end
	return ret,color
end