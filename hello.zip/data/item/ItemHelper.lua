--物品相关的常量定义及名称转换

ItemHelper = {}

--物品类型定义
ItemHelper.itemType = {}
ItemHelper.itemType.Normal = 0 -- 常规消耗类道具
ItemHelper.itemType.EquipUpgrade = 1 --装备提升类道具
ItemHelper.itemType.Inlay = 2 -- 镶嵌类道具
ItemHelper.itemType.GemEnergy = 3 --宝石能量
ItemHelper.itemType.Weapon = 4 --武器
ItemHelper.itemType.Clothes = 5 --上装
ItemHelper.itemType.Trousers = 6 --下装/裤子
ItemHelper.itemType.Jewelry =  7 --饰品
ItemHelper.itemType.Shoes = 8 --鞋子
ItemHelper.itemType.Amulet = 9 --护符
ItemHelper.itemType.Necklace = 10 --项链
ItemHelper.itemType.Ring = 11 -- 戒指
ItemHelper.itemType.team_exp = 12 -- 战队经验
ItemHelper.itemType.hero_exp = 13 -- 英雄经验
ItemHelper.itemType.gold = 14 -- 金币
ItemHelper.itemType.diamond = 15 -- 钻石
ItemHelper.itemType.phy = 16 -- 体力
ItemHelper.itemType.point = 17 -- 积分
ItemHelper.itemType.skill_point = 18 -- 技能点
ItemHelper.itemType.hero_card = 19 --英雄整卡
ItemHelper.itemType.equip_fragment = 20 --装备碎片
ItemHelper.itemType.gift = 21 --礼包卡
ItemHelper.itemType.guard_card = 22 --怪物守卫卡
ItemHelper.itemType.fashion_skin = 100 	--时装:皮肤
ItemHelper.itemType.miracle = 101 		--时装:神器

--装备类型
ItemHelper.equipType = {}
ItemHelper.equipType.equip = 1 --普通装备
ItemHelper.equipType.fashion = 2 --时装
--物品品质定义,白绿蓝紫橙
ItemHelper.itemQuality = {}
ItemHelper.itemQuality.White = 0 
ItemHelper.itemQuality.Green = 1 
ItemHelper.itemQuality.Blue = 2 
ItemHelper.itemQuality.Purple = 3
ItemHelper.itemQuality.Orange = 4 

--使用方式定义
ItemHelper.useway = {}
ItemHelper.useway.UnableUsedDirect = 0 
ItemHelper.useway.Consume = 1 
ItemHelper.useway.Unconsume = 2 
ItemHelper.useway.Wear = 3 

--物品站位定义
ItemHelper.limitStand = {}
ItemHelper.limitStand.Unlimit = 0 -- 不限制
ItemHelper.limitStand.Front = 1 --前排
ItemHelper.limitStand.Midle = 2 -- 中排
ItemHelper.limitStand.Back = 3 --后排

--客户端改变背包数据的类型
ItemHelper.change_type = {}
ItemHelper.change_type.add = 1 --增加物品数量，有可能是从0个到1个，此时表示新增。否则只是单纯改变数量
ItemHelper.change_type.sub = 2 --减少物品数量，当数量变为0时，表示从背包中删除此物品，否则只是单纯改变数量

--镶嵌宝石位置定义
ItemHelper.gem_location = {} --界面从左往右的三个宝石槽
ItemHelper.gem_location.one = 1
ItemHelper.gem_location.two = 2
ItemHelper.gem_location.three = 3

--宝石的子类型定义
ItemHelper.gem_type = {} --界面从左往右的三个宝石槽
ItemHelper.gem_type.hp = 0
ItemHelper.gem_type.atk = 1
ItemHelper.gem_type.pdef = 2

--物品功能类型定义
ItemHelper.func_type = {}
ItemHelper.func_type.normal = 0 --无特殊功能
ItemHelper.func_type.exp_medicine = 1 --经验药
ItemHelper.func_type.get_skill_point = 2 --技能符文石
ItemHelper.func_type.enchant_energy = 3 --附魔能量
ItemHelper.func_type.gem_inlay = 4 --宝石镶嵌
ItemHelper.func_type.hero_upgrade = 5 --英雄进阶
ItemHelper.func_type.eqm_on = 6 --点击装备
ItemHelper.func_type.money_card = 7 --金币卡，打开出售界面
ItemHelper.func_type.eqm_upgrade = 8 --装备升级
ItemHelper.func_type.pet_levup = 9 --侍宠升级
ItemHelper.func_type.pet_upgrade = 10 --侍宠升阶  
ItemHelper.func_type.gift_card = 11 --礼包卡
ItemHelper.func_type.mystery_refresh = 12 --神秘商人刷新卡
--礼包有效类型
ItemHelper.expire_type = {}
ItemHelper.expire_type.forever = 0 --永不过期
ItemHelper.expire_type.couttime = 1 --进入倒计时
ItemHelper.expire_type.interval = 2 --时间段

--更换装备的状态
ItemHelper.exc_eqm_status = {}
ItemHelper.exc_eqm_status.normal = 0
ItemHelper.exc_eqm_status.add = 1 
ItemHelper.exc_eqm_status.up = 2 

ItemHelper.colors = {} --色码定义

--通用提示/警告/无法操作
ItemHelper.colors.yellow = ccc3(251, 241, 160) --通用提示色
ItemHelper.colors.deep_yellow = ccc3(255, 177, 9) --通用提示色2
ItemHelper.colors.deep_orange = ccc3(238, 98, 30) --通用提示色3
ItemHelper.colors.red = ccc3(215, 6, 1) --通用警告色
ItemHelper.colors.brown = ccc3(118, 88, 80) --关闭/无法操作


ItemHelper.colors.light_blue = ccc3(49, 226, 174) --浅蓝

--物品品质色
ItemHelper.colors.white = ccc3(215, 211, 203)
ItemHelper.colors.green = ccc3(59, 250, 0)
ItemHelper.colors.blue = ccc3(0, 194, 243)
ItemHelper.colors.purple = ccc3(194, 21, 200)
ItemHelper.colors.orange = ccc3(255, 153, 7)

--引导物品查找 类型
ItemHelper.find_type = {}
ItemHelper.find_type.none_eqm = 0 --没装备的时候
ItemHelper.find_type.better_eqm = 1 -- 更好装备
ItemHelper.find_type.upgrade_res = 2 --装备升级材料
ItemHelper.find_type.pet_res = 3 --侍宠喂养材料
ItemHelper.find_type.defguard = 4 --驻守妖怪
ItemHelper.find_type.fashion = 5 --时装

--通过物品类型值获取相应的类型名 
function ItemHelper:getTypeName(item_type)
	local item_type = item_type
	if item_type == ItemHelper.itemType.Normal then
		return "常規道具"
	elseif item_type == ItemHelper.itemType.EquipUpgrade then
		return "提升類道具"
	elseif item_type == ItemHelper.itemType.InlayGem then
		return "鑲嵌類道具"
	elseif item_type == ItemHelper.itemType.GemEnergy then
		return "寶石能量"
	elseif item_type == ItemHelper.itemType.Weapon then
		return "武器"
	elseif item_type == ItemHelper.itemType.Clothes then
		return "上裝"
	elseif item_type == ItemHelper.itemType.Trousers then
		return "下裝"
	elseif item_type == ItemHelper.itemType.Jewelry then
		return "飾品"
	elseif item_type == ItemHelper.itemType.Shoes then
		return "鞋子"
	elseif item_type == ItemHelper.itemType.Amulet then
		return "護符"
	elseif item_type == ItemHelper.itemType.Necklace then
		return "項鍊"
	elseif item_type == ItemHelper.itemType.Ring then
		return "戒指"
	elseif item_type == ItemHelper.itemType.exp then
		return "經驗"
	elseif item_type == ItemHelper.itemType.gold then
		return "金幣"
	elseif item_type == ItemHelper.itemType.diamond then
		return "鑽石"
	elseif item_type == ItemHelper.itemType.equip_fragment then
		return "裝備碎片"
	elseif item_type == ItemHelper.itemType.fashion_skin then
		return "時裝"
	elseif item_type == ItemHelper.itemType.miracle then
		return "神器"
	else 
		return "未定義"
	end
end

--获取物品品质的中文名称 
function ItemHelper:getQualityName(quality)
	local quality = quality
	if quality == ItemHelper.itemQuality.White then
		return "白"
	elseif quality == 	ItemHelper.itemQuality.Green then
		return "綠"
	elseif quality == 	ItemHelper.itemQuality.Blue then
		return "藍"
	elseif quality == ItemHelper.itemQuality.Purple then
		return "紫"
	elseif quality == 	ItemHelper.itemQuality.Orange then
		return "橙"
	end																
end

--获取物品使用方式的中文名称 
function ItemHelper:getQualityName(useway)
	local useway = useway
	if useway == ItemHelper.useway.UnableUsedDirect then
		return "不能直接使用"
	elseif useway == ItemHelper.useway.Consume then
		return "消耗"
	elseif useway == ItemHelper.useway.Unconsume then
		return "不消耗"
	elseif useway == ItemHelper.useway.Wear then
		return "穿戴"
	end														
end

--通过附魔等级获取对应颜色
function ItemHelper:getEnchantColor(enchant_lev)
	-- if enchant_lev <3 then
	-- 	return ItemHelper.colors.yellow
	-- elseif enchant_lev<6 then
	-- 	return ItemHelper.colors.green
	-- elseif enchant_lev<9 then
	-- 	return ItemHelper.colors.blue
	-- elseif enchant_lev<12 then
	-- 	return ItemHelper.colors.purple
	-- else
	-- 	return ItemHelper.colors.orange
	-- end
	return ItemHelper.colors.purple
end

ItemHelper.limitStand.Unlimit = 0 -- 不限制
ItemHelper.limitStand.Front = 1 --前排
ItemHelper.limitStand.Middle = 2 -- 中排
ItemHelper.limitStand.Back = 3 --后排

--获取站位名称 
function ItemHelper:getLimitStandName(limitStand)
	local limitStand = limitStand
	if limitStand == ItemHelper.limitStand.Unlimit then
		return "不限制"
	elseif limitStand == ItemHelper.limitStand.Front then
		return "前排"
	elseif limitStand == ItemHelper.limitStand.Middle then
		return "中排"
	elseif limitStand == ItemHelper.limitStand.Back then
		return "後排"
	else 
		return "不限制"	
	end														
end

--根据装备部位返回相对应的属性
function ItemHelper:getAttrFlagByLocation(location)
	if location == ItemHelper.itemType.Weapon then
		return AttrHelper.attr_flag.atk
	elseif location == ItemHelper.itemType.Clothes then
		return AttrHelper.attr_flag.pdef	
	elseif location == ItemHelper.itemType.Trousers then
		return AttrHelper.attr_flag.pdef
	elseif location == ItemHelper.itemType.Jewelry then
		return AttrHelper.attr_flag.hp
	elseif location == ItemHelper.itemType.Shoes then
		return AttrHelper.attr_flag.hp
	elseif location == ItemHelper.itemType.Amulet then	
		return AttrHelper.attr_flag.crit
	elseif location == ItemHelper.itemType.Necklace then	
		return AttrHelper.attr_flag.hp
	elseif location == ItemHelper.itemType.Ring then	
		return AttrHelper.attr_flag.atk
	elseif location == ItemHelper.itemType.fashion_skin then
		return AttrHelper.attr_flag.hp
	end
end

function ItemHelper:getColorByQuality(quality)
	if quality == ItemHelper.itemQuality.White then
		return ItemHelper.colors.white
	elseif quality == ItemHelper.itemQuality.Green then
		return ItemHelper.colors.green
	elseif quality == ItemHelper.itemQuality.Blue then
		return ItemHelper.colors.blue
	elseif quality == ItemHelper.itemQuality.Purple then
		return ItemHelper.colors.purple
	elseif quality == ItemHelper.itemQuality.Orange then
		return ItemHelper.colors.orange
	end	
end

--获取站位名称缩写 
function ItemHelper:getHeroPosShortName(limitStand)
	local limitStand = limitStand
	if limitStand == ItemHelper.limitStand.Unlimit then
		return ""
	elseif limitStand == ItemHelper.limitStand.Front then
		return "前"
	elseif limitStand == ItemHelper.limitStand.Middle then
		return "中"
	elseif limitStand == ItemHelper.limitStand.Back then
		return "後"
	else 
		return ""	
	end														
end

function ItemHelper:getEquipTypeWithItemType(itemType)
	local ret = 0
	if itemType == ItemHelper.itemType.Weapon or
		itemType == ItemHelper.itemType.Clothes or 
		itemType == ItemHelper.itemType.Trousers or
		itemType == ItemHelper.itemType.Jewelry or
		itemType == ItemHelper.itemType.Shoes or
		itemType == ItemHelper.itemType.Amulet or
		itemType == ItemHelper.itemType.Necklace or
		itemType == ItemHelper.itemType.Ring then

		ret = ItemHelper.equipType.equip
	elseif itemType == ItemHelper.itemType.fashion_skin then
		ret = ItemHelper.equipType.fashion
	end
	return ret
end

function ItemHelper:getAttrFlagById(base_id)
	local mode = ItemManager:getInstance():getItemModelByBaseId(base_id)
	local equipType = ItemHelper:getEquipTypeWithItemType(mode.item_type)
	if equipType == ItemHelper.equipType.equip then
		return ItemHelper:getAttrFlagByLocation(mode.item_type)
	elseif equipType == ItemHelper.equipType.fashion then

		local fashionData = HeroManager:getInstance():getCfgFashionDataByBaseId(base_id)
		local attrs = ItemManager:getInstance():getFashionEnchantAttr(fashionData.heroId,fashionData.pos)

		for key,value in pairs(attrs) do
			if value > 0 then
				return key
			end
		end
	end
end

--获取站位资源名称
function ItemHelper:getHeroPosImgName(limitStand)
	local limitStand = limitStand
	if limitStand == ItemHelper.limitStand.Unlimit then
		return ""
	elseif limitStand == ItemHelper.limitStand.Front then
		return "i18n_hero_front_txt.png"
	elseif limitStand == ItemHelper.limitStand.Middle then
		return "i18n_hero_mid_txt.png"
	elseif limitStand == ItemHelper.limitStand.Back then
		return "i18n_hero_back_txt.png"
	else 
		return ""	
	end														
end

--获取附魔特效资源名称
function ItemHelper:getEnchentEffectName(enchant_lev)
	local limitStand = limitStand
	if enchant_lev>2 and enchant_lev<6	 then --3 4 5 
		return "lu"
	elseif enchant_lev>5 and enchant_lev<9 then --6 7 8
		return "lan"
	elseif enchant_lev>8 and enchant_lev<12 then -- 9 10 11
		return "zi"
	elseif enchant_lev>11 then
		return "cheng"	
	end														
end

--判断一个物品是否灵魂石
function ItemHelper:isSoulStone(base_id)
	if base_id>=44000 and base_id<=44017 then
		return true
 	end

 	return false
end


ItemHelper.moneyType = {}
ItemHelper.moneyType.glodCoin = 1
ItemHelper.moneyType.diamon = 2


function ItemHelper:getGemSuitAttrLabelColor(gem_suit_lv)
  if gem_suit_lv<HeroManager.MIN_GEM_LV_FOR_SUIT then
    return ItemHelper.colors.yellow
  elseif gem_suit_lv<7 then
    return ItemHelper.colors.green
  elseif gem_suit_lv<10 then
    return ItemHelper.colors.blue
  elseif gem_suit_lv<16 then
    return ItemHelper.colors.purple
  else
    return ItemHelper.colors.orange 
  end
end

function ItemHelper:getEnchantSuitAttrLabelColor(lv)
  if lv<HeroManager.MIN_ENCHANT_LV_FOR_SUIT then
    return ItemHelper.colors.yellow
  elseif lv<6 then
    return ItemHelper.colors.green
  elseif lv<9 then
    return ItemHelper.colors.blue
  elseif lv<12 then
    return ItemHelper.colors.purple
  else
    return ItemHelper.colors.orange 
  end
end