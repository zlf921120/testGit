--
-- Author: lvgansheng
-- Date: 2015-01-21 19:52:26
-- 批量使用物品

BatchUseItemView = class("BatchUseItemView", WindowBase)


function BatchUseItemView:init()
	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
        
    self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/backpack/batch_use_item/batch_use_item.ExportJson")
    self.uiLayer:addWidget(self.widget)

    self.money_type_img = tolua.cast( self.uiLayer:getWidgetByName("money_type_img") , "ImageView")

    self.view_bg = tolua.cast( self.uiLayer:getWidgetByName("view_bg") , "ImageView")

    self.item_icon = ItemIcon:create()
    self.item_icon:setPosition(ccp(382,378))
    self.widget:addChild(self.item_icon,2)

    self.numTxt = tolua.cast(self.uiLayer:getWidgetByName("sell_num_label"),"Label")
    self.moneyLabel = tolua.cast(self.uiLayer:getWidgetByName("total_price_label"),"Label")

    self.panelMoney = tolua.cast(self.uiLayer:getWidgetByName("panel_money"),"Layout")
    self.panelBtn = tolua.cast(self.uiLayer:getWidgetByName("panel_btn"),"Layout")
    self.imgBg2 = tolua.cast(self.uiLayer:getWidgetByName("img_bg2"),"Layout")

    --设置减号按钮
    local subBtn= self.uiLayer:getWidgetByName("sub_btn") 
    local function subBtnFun(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then 
            
            if(self.sellNum == 1) then -- 已经只有一件，无法再减少
                return
            end

            self.sellNum=self.sellNum-1
            local str = string.format('%d/%d',self.sellNum,self.item_data.quantity)
            self.numTxt:setText(str)
            self:changeMoney()
        end
    end
    subBtn:addTouchEventListener(subBtnFun)
    
    --设置加号按钮
    local addbtn= self.uiLayer:getWidgetByName("add_btn")  
    local function addbtnfun(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then 
            
            if(self.sellNum == self.item_data.quantity) then -- 已经是最大数量
                return
            end

            self.sellNum=self.sellNum+1
            local str = string.format('%d/%d',self.sellNum,self.item_data.quantity)
            self.numTxt:setText(str)
            self:changeMoney()
        end
    end
    addbtn:addTouchEventListener(addbtnfun)
        
    local maxBtn= self.uiLayer:getWidgetByName("max_btn")  --设置出售界面的最大数量按钮
    maxBtn:setTouchEnabled(true)    
    local function maxBtnFun(sender,eventType)
        
        if(self.sellNum == self.item_data.quantity) then -- 已经是最大数量
            return
        end 
        
        self.sellNum = self.item_data.quantity
        local str = string.format('%d/%d',self.sellNum,self.item_data.quantity)
        self.numTxt:setText(str)
        self:changeMoney()
    end
    maxBtn:addTouchEventListener(maxBtnFun)

    --取消按钮
    local cancelBtn = self.uiLayer:getWidgetByName("cancel_btn")    --确认出售按钮
    local function onClickCancelBtn(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end 
    cancelBtn:addTouchEventListener(onClickCancelBtn)
                
    --确认按钮
    local cfm_btn = self.uiLayer:getWidgetByName("cfm_btn") 
    local function confrimSelBtnFun(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            if self.item_data.mode.func_type == ItemHelper.func_type.gift_card then--礼包
                ItemManager:getInstance():sendItemUseReq(1,self.item_data.id,self.sellNum,0)
            else
                ItemManager:getInstance():sendSellItemReq(self.item_data.id, self.sellNum)
            end      
        end
    end 
    
    cfm_btn:addTouchEventListener(confrimSelBtnFun)
end

function BatchUseItemView:open()
	if self.params ~= nil then
        self:setitem_data(self.params)
    end
end

function BatchUseItemView:setitem_data(item)
    self.item_data = item 
    self.sellNum = 1
    self:changeContent()
    self:changeMoney()
    self:adjustScale(self.item_data.mode.func_type)
end

function BatchUseItemView:adjustScale(func_type)
    if func_type == ItemHelper.func_type.gift_card then--礼包
        self.panelMoney:setVisible(false)
        self.panelBtn:setPositionY(147)
        self.imgBg2:setSize(CCSize(400,200))
        self.view_bg:setSize(CCSize(466,350))
    else --普通物品
        self.panelMoney:setVisible(true)
        self.panelBtn:setPositionY(45)
        self.imgBg2:setSize(CCSize(400,288))
        self.view_bg:setSize(CCSize(466,455))
    end
end

function BatchUseItemView:close()

end

function BatchUseItemView:create()
	local batch_use_view = BatchUseItemView.new()
	return batch_use_view
end

function BatchUseItemView:changeMoney()
      self.moneyLabel:setText(self.item_data.mode.sell_price * self.sellNum )
end

function BatchUseItemView:changeContent()

    self.item_icon:setBaseId(self.item_data.mode.base_id)

    local namelabel = self.uiLayer:getWidgetByName("item_name_label")
    tolua.cast(namelabel,"Label")
    namelabel:setColor(ItemHelper:getColorByQuality(self.item_data.mode.quality))
    namelabel:setText(self.item_data.mode.name)
          
    local str = string.format('%d/%d',self.sellNum,self.item_data.quantity)
    local numTxt = self.uiLayer:getWidgetByName("sell_num_label")
    tolua.cast(numTxt,"Label")
    numTxt:setText(string.format('1/%d',self.item_data.quantity))
    
    if self.item_data.mode.money_type == ItemHelper.moneyType.glodCoin then
        self.money_type_img:loadTexture("gold.png", UI_TEX_TYPE_PLIST)
    else
        self.money_type_img:loadTexture("diamond.png", UI_TEX_TYPE_PLIST)
    end
end