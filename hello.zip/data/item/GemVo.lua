--
-- Author: lvgansheng
-- Date: 2014-07-28 19:48:11
-- 装备所携带的镶嵌信息

GemVo = class("GemVo")
GemVo.item = nil
GemVo.location = 0 --宝石位置