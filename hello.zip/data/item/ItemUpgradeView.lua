-- 装备 升级
ItemUpgradeView = class("ItemUpgradeView", WindowBase)
ItemUpgradeView.widget = nil
ItemUpgradeView.uiLayer = nil
ItemUpgradeView.base_id = nil
ItemUpgradeView.item = nil
ItemUpgradeView.upgrade_info = nil

function ItemUpgradeView:init()

	  self.uiLayer = TouchGroup:create() 
  	self:addChild(self.uiLayer)
	  self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/backpack/item_upgrade/item_upgrade.ExportJson")
  	self.uiLayer:addWidget(self.widget)

  	self.before_equip = ItemIcon:create()
  	self.before_equip:setPosition(ccp(self.widget:getChildByName("p_1"):getPosition()))
  	self.widget:addChild(self.before_equip)
    self.before_equip:setTouchEvent(function(sender,event_type)
      if event_type == ComConstTab.TouchEventType.ended then
            local param = {}
            local curEqmInfo = HeroManager:getInstance():getBetterEqmGuideInfoById( self.upgrade_info.base_id )
            if curEqmInfo ~= nil then
              param.hero_pos = curEqmInfo.hero_pos
              param.eqm_type = curEqmInfo.eqm_type
              param.find_type = ItemHelper.find_type.better_eqm
              WindowCtrl:getInstance():open(CmdName.FindEqmView,param)
            else
                --寻找超过 40级的紫装失败
            end
        end
    end)

  	self.res_icon = ItemIcon:create()
  	self.res_icon:setPosition(ccp(self.widget:getChildByName("p_2"):getPosition()))
  	self.widget:addChild(self.res_icon)
    self.res_icon:setTouchEvent(function(sender,event_type)
      if event_type == ComConstTab.TouchEventType.ended then
            local param = {}
            param.res_baseid = self.upgrade_info.cost_base_id
            param.eqm_type = ItemHelper.itemType.equip_fragment
            param.find_type = ItemHelper.find_type.upgrade_res
            WindowCtrl:getInstance():open(CmdName.FindEqmView,param)
        end
    end)

    require "ItemInfoPanel"
  	self.after_equip = ItemIcon:create()
  	self.after_equip:setPosition(ccp(self.widget:getChildByName("p_3"):getPosition()))
    self.widget:addChild(self.after_equip)
    self.after_equip:setTouchEvent(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.began then

                ItemInfoPanel:show(pSender:getTag())

        elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then

            ItemInfoPanel:hide()
        end
    end)

    self.labHeroWearFix = tolua.cast(self.widget:getChildByName("lab_fix"),"Label")
  	self.labBeforeName = tolua.cast(self.widget:getChildByName("lab_name"),"Label")
  	self.labResNum = tolua.cast(self.widget:getChildByName("lab_num"),"Label")
  	self.labCost = tolua.cast(self.widget:getChildByName("lab_cost"),"Label")
    self.labName = tolua.cast(self.widget:getChildByName("lab_name"),"Label")
    self.labHeroName = tolua.cast(self.widget:getChildByName("lab_hero"),"Label")
    self.labResName = tolua.cast(self.widget:getChildByName("lab_costname"),"Label")
    self.panelTip = tolua.cast(self.widget:getChildByName("panel_tip"),"Label")
    self.labTips = tolua.cast(self.panelTip:getChildByName("lab_tiplev"),"Label")

  	self.btnOk = tolua.cast(self.widget:getChildByName("btn_ok"),"Button")
  	self.btnOk:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
          local param = {}
          if self.item then
            param.hero_id = self.item.hero_id
            param.item_id = self.item.id
            param.eqm_pos = self.item.mode.item_type
            ItemManager:getInstance():sendEquipUpgradeReq(param)
          end
        end
  	end)

  	local return_btn = self.uiLayer:getWidgetByName("btn_close")
	  return_btn:addTouchEventListener(function(sender,event_type)
	  	if event_type == ComConstTab.TouchEventType.ended then
	        WindowCtrl:getInstance():close(self.name)
	    end
	end)

end

function ItemUpgradeView:create()
    local ret = ItemUpgradeView.new()
    return ret
end

function ItemUpgradeView:open()

  self.item = self.params.item

  local im = ItemManager:getInstance()
  if self.item.mode.item_type == ItemHelper.itemType.equip_fragment then --碎片

      local tbl = im:getEqmUpgradeInfoByResId(self.item.mode.base_id)
      local isCanUpgradeBaseId = tbl[1].base_id
      table.sort( tbl, function(a,b) return a.team_lev > b.team_lev end )
      for k,v in pairs(tbl) do
          if im:isCanEqmUpgradeByBaseId( v.base_id ) then
             isCanUpgradeBaseId = v.base_id
             break
          end
      end
      self.base_id = isCanUpgradeBaseId
      -- print(" self.item.mode.base_id ",self.item.mode.base_id,self.base_id )
      self.upgrade_info = im:getEqmUpgradeInfo(self.base_id)
  else
      self.base_id = self.item.mode.base_id
      self.upgrade_info = im:getEqmUpgradeInfo(self.base_id)
  end
	self:update()
end

function ItemUpgradeView:update()

	self.after_equip:setBaseId(self.upgrade_info.target_base_id)
  self.after_equip:getClickImg():setTag(self.upgrade_info.target_base_id)
	self.before_equip:setBaseId(self.upgrade_info.base_id)
	self.res_icon:setBaseId(self.upgrade_info.cost_base_id)
  self.labCost:setText(self.upgrade_info.coin)

  local im = ItemManager:getInstance()
  local eqmMode = im:getItemModelByBaseId(self.upgrade_info.base_id)
  local resMode = im:getItemModelByBaseId(self.upgrade_info.cost_base_id)

  self.labResName:setText(resMode.name)
  self.labResName:setColor(ItemHelper:getColorByQuality(resMode.quality))

  if self.item.mode.item_type == ItemHelper.itemType.equip_fragment then --碎片
      self.item = im:getOneEquipInfoByBaseId(self.base_id) --查找英雄身上的物品
      if self.item == nil then
          self.labHeroName:setText("")
          self.labHeroWearFix:setText("")
      else
          local heroId = self.item.hero_id
          local heroInfo = HeroManager:getInstance():getHeroInfoById(heroId)
          self.labHeroName:setText(heroInfo.name)
          self.labHeroWearFix:setText("穿戴者:")
      end
  else
      self.labHeroWearFix:setText("")
      self.labHeroName:setText("")
  end
  self.labName:setText(eqmMode.name)
  self.labName:setColor(ItemHelper:getColorByQuality(eqmMode.quality))

  local num = im:getQuantityByBaseId(self.upgrade_info.cost_base_id)
	self.labResNum:setText(string.format("%d/%d",num,self.upgrade_info.cost_num))
  if num < self.upgrade_info.cost_num then
      self.labResNum:setColor(ItemHelper.colors.red)
  else
      self.labResNum:setColor(ItemHelper.colors.yellow)
  end

  local isCanUpgrade,err = im:isCanEqmUpgradeByBaseId(self.base_id)

  self.btnOk:setBright(isCanUpgrade)
  self.btnOk:setTouchEnabled(isCanUpgrade)

  self.panelTip:setVisible( not err.teamLev )
  self.labTips:setText(self.upgrade_info.team_lev)

  self.before_equip:getClickImg():setTouchEnabled(err.teamLev) --等级不足

  if CharacterManager:getInstance():getAssetData():getGold() < self.upgrade_info.coin then
      self.labCost:setColor(ItemHelper.colors.red)
  else
      self.labCost:setColor(ItemHelper.colors.yellow)
  end

end
