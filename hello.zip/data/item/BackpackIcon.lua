--背包中的单个物品图片


BackpackIcon = class("BackpackIcon")
BackpackIcon.itemData=nil 

function BackpackIcon:init()
	self.icon_bg = CCSprite:createWithSpriteFrameName("quality_bg_1.png")
	self.icon_bg:retain()
	self.item_icon = CCSprite:createWithSpriteFrameName("item_10000.png")
	self.item_icon:retain()
	self.icon_border = CCSprite:createWithSpriteFrameName("quality_border_1.png")
	self.icon_border:retain()
end

function BackpackIcon:changeItemData(itemData)
    self.itemData = itemData
  
    if self.icon_bg  then
    	self.icon_bg:initWithSpriteFrameName(string.format("quality_bg_%d.png",self.itemData.mode.quality))
    end

     if self.item_icon  then
     	local icon_res = ""
     	local sex = CharacterManager:getInstance():getBaseData():getSex()
        if (self.itemData.mode.icon_id == 60016 or self.itemData.mode.icon_id == 44000) and
             sex == Helper.sex.female then --女
            icon_res = string.format("item_%d_f.png",self.itemData.mode.icon_id)
        else
            icon_res = string.format("item_%d.png",self.itemData.mode.icon_id)
        end
    	self.item_icon:initWithSpriteFrameName(icon_res)
    end

     if self.icon_border  then
    	self.icon_border:initWithSpriteFrameName(string.format("quality_border_%d.png",self.itemData.mode.quality))
    end
    --碎片
    -- self:makeImgFragment( self.item_mode.item_type == ItemHelper.itemType.equip_fragment )
end

function BackpackIcon:makeImgFragment(vis)
	if vis then
        if self.imgFragment == nil then
            self.imgFragment = CCSprite:createWithSpriteFrameName("equip_fragment.png")
            self.imgFragment:retain()
        end
    else
        if self.imgFragment ~= nil then
            self.imgFragment:removeFromParentAndCleanup(true)
            self.imgFragment:release()
            self.imgFragment = nil
        end
    end
end

function BackpackIcon:create()
    local icon = BackpackIcon.new()
    icon:init()
    return icon   
end

function BackpackIcon:getIconBg()
	if self.icon_bg  then
		return self.icon_bg
	else
		self.icon_bg = CCSprite:createWithSpriteFrameName("quality_bg_1.png")
		self.icon_bg:retain()
		return self.icon_bg
	end
end

function BackpackIcon:getItemIcon()
	if self.item_icon  then
		return self.item_icon
	else
		self.item_icon = CCSprite:createWithSpriteFrameName("item_10000.png")
		self.item_icon:retain()
		return self.item_icon
	end
end

function BackpackIcon:getIconBorder()
	if self.icon_border  then
		return self.icon_border
	else
		self.icon_border = CCSprite:createWithSpriteFrameName("quality_border_1.png")
		self.icon_border:retain()
		return self.icon_border
	end
end

function BackpackIcon:setRealPos(real_pos)
	self.real_pos = real_pos
	self.icon_bg:setPosition(real_pos)
	self.item_icon:setPosition(real_pos)
	self.icon_border:setPosition(real_pos)

	if self.eqmFragImg then
		self.eqmFragImg:setPosition(ccp(real_pos.x-27,real_pos.y+27))
	end


	-- if self.item_mode.item_type == ItemHelper.itemType.equip_fragment then --碎片
	-- 	-- self.imgFragment
	-- end
	-- self.num_label:setPosition(real_pos)
end

function BackpackIcon:getRealPos()
	return self.real_pos 
end

function BackpackIcon:setNumLabel(tmp_num_label)
	self.tmp_num_label = tmp_num_label
end

function BackpackIcon:getNumLabel()
	return self.tmp_num_label
end

function BackpackIcon:getNumDesc()
	if self.itemData==nil then
		return ""
	end
    if self.itemData.quantity > 1 then
    	return self.itemData.quantity
    elseif self.itemData and ItemManager:getInstance():isEqm(self.itemData.mode.item_type)
    or self.itemData.mode.item_type==ItemHelper.itemType.equip_fragment then
       	return ItemHelper:getHeroPosShortName(self.itemData.mode.limit_stand)
    end

    return ""
end

-- 是否需要显示装备碎片图标
function BackpackIcon:isShowEqmFrag()
	return self.itemData.mode.item_type == ItemHelper.itemType.equip_fragment
end

function BackpackIcon:getEqmFragImg()
	if self.eqmFragImg  then
		return self.eqmFragImg
	else
		self.eqmFragImg = CCSprite:createWithSpriteFrameName("equip_fragment.png")
		self.eqmFragImg:retain()
		return self.eqmFragImg
	end
end

function BackpackIcon:getItemData()
	return self.itemData
end

function BackpackIcon:getEqmLvDesc()
	if self.itemData.mode.limit_lev>0 then
		return "lv."..self.itemData.mode.limit_lev
	end

	return ""
end