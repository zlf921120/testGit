--
-- Author: lvgansheng
-- Date: 2014-06-14 16:36:39
-- 物品管理器


ItemManager = class("ItemManager")
ItemManager.isRead = false -- 是否已经读取过了
ItemManager.isEqmRead = false -- 是否已经读取过装备列表了
ItemManager.isGemDataRead = false -- 是否已经读取过宝石表了
ItemManager.isBackPackInit = false --是否已经接收过过背包初始化协议
ItemManager.allItemDataTab = nil --存放所有物品信息
ItemManager.backpackItemTab = nil --存放背包中的物品
ItemManager.backpackItemIdArr = nil -- 存放背包中物品唯一ID的数组
ItemManager.equipItemTab = nil -- 存放装备物品信息列表
ItemManager.fashionItemTab = nil -- 存放时装物品信息列表(一般情况下 用equipItemTab )
ItemManager.eqm_base_attrs = nil -- 存放装备基础属性
ItemManager.eqm_powered_attrs = nil -- 存放装备强化属性
ItemManager.fashion_powered_attrs = nil -- 存放时装强化属性
ItemManager.eqm_powered_cost = nil -- 存放装备强化消耗
ItemManager.eqm_enchant_attr = nil -- 存放装备附魔成长比例
ItemManager.eqm_enchant_cost = nil -- 存放装备附魔消耗
ItemManager.eqm_identify_cost = nil -- 存放装备鉴定消耗
ItemManager.eqm_identify_lock_cost = nil -- 存放装备属性锁定消耗
ItemManager.eqm_identify_lucky_list = nil -- 存放装备幸运值消耗
ItemManager.fashion_identify_lucky_list = nil --存放时装幸运值消耗
ItemManager.eqm_upgrade_cost = nil -- 存放装备升级消耗
ItemManager.eqm_upgrade_cost_res = nil -- 存放装备升级消耗(材料id做主键)
ItemManager.eqm_identify_reset_cost = nil -- 存放装备鉴定重置消耗
ItemManager.fashion_identify_reset_cost = nil -- 存放时装鉴定重置消耗
ItemManager.gem_info_tab = nil -- 存放宝石相关信息
ItemManager.gem_upgrade_tab = nil -- 存放宝石升级能量
ItemManager.eqm_final_attrs = nil -- 存储装备的最终属性，避免频繁计算
ItemManager.eqm_attr_ischange = nil -- 是否需要重新计算某装备的属性
ItemManager.soul_stone_nums = nil --灵魂石数量
ItemManager._canUpgradeHeroList = nil --可升级装备的 英雄id列表

ItemManager.identify_attrs = nil  --暂存装备的锁定属性
ItemManager._gemSuitDataDict = nil --宝石套数据表数据吗，key为宝石套等级

local is_load_item_plist = false -- 是否已经加载过物品图标资源

local _instance = nil
local _allowInstance = false

ItemManager.gem_special_slot_pos = 0 --记录当前操作的是宝石界面的哪个孔

function ItemManager:ctor()

    if not _allowInstance then
        error("ItemManager is a singleton class,please call getInstance method")
    end


    require 'fnt_item_data_pb'
    require 'fnt_eqm_data_pb'
    require 'fnt_gem_data_pb'
    require 'bag_pb'
    require 'CmdName'
    require 'helper'
    require 'ItemMode'
    require 'Item'
    require "CharacterEvent"
    require 'GemInfo'
    require("HeroHelper")

    self.allItemDataTab = {} 
    self.backpackItemTab = {} 
    self.backpackItemIdArr = {} 
    self.equipItemTab = {}
    self.fashionItemTab = {}
    self.eqm_base_attrs = {}
    self.eqm_powered_attrs = {}
    self.fashion_powered_attrs = {}
    self.eqm_powered_cost ={}
    self.eqm_enchant_attr ={}
    self.eqm_enchant_cost ={}
    self.eqm_identify_cost ={}
    self.eqm_identify_lock_cost ={}
    self.gem_info_tab = {}
    self.gem_upgrade_tab ={}
    self.eqm_final_attrs ={}
    self.eqm_attr_ischange ={}
    self.quality_ratios ={}
    self.soul_stone_nums ={}
    self.eqm_upgrade_cost = {}
    self.eqm_upgrade_cost_res = {}
    self.eqm_identify_reset_cost = {}
    self.fashion_identify_reset_cost = {}
    self.eqm_identify_lucky_list = {}
    self.fashion_identify_lucky_list = {}
    self.fashion_enchant_attrs ={}
    self.gift_relation_list = {} --礼包预览
    self.eqm_suit_attr_list = {} --宝石套 属性加成
    self.enchant_suit_attr = {} --附魔套

    -- 部分函数调用
    self._onBagItemsSort = function(item_id_one, item_id_two)
        return self:bagItemsSort(item_id_one, item_id_two)
    end

    self._onInitBackpage = function()
        Notifier.remove(CmdName.GameStar,self._onInitBackpage)
        self:onInitBackpage()
    end

    self._onTeamUpdate = function()
        self:onTeamUpdate()
    end

    self:addListens()
end

function ItemManager:addListens()
    -- Notifier.regist(CmdName.Main_UI_Init_Success,sendBagInfoReq)
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.bag_add_rsp, "onBagAddRsp()") --侦听背包数据的增加，测试用 
   
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_enchant_req+1, "onGetEnchantRsp()") --装备附魔的结果   
   
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_embed_on_rsp, "onGetEmbedOnRsp()") --装备镶嵌宝石的结果   
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_embed_off_rsp, "onGetEmbedOffRsp()") --装备摘除宝石的结果   
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_embed_upgrade_rsp, "onGetEmbedUpgradeRsp()") --宝石升级的结果  
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.bag_use_item_rsp, "onGetItemUseRsp()") --物品使用的结果

    Notifier.regist(CmdName.GameStar,self._onInitBackpage)
    Notifier.regist(CmdName.CHARACTER_RSP_UPDATE_TEAM,self._onTeamUpdate)
end

function ItemManager:loadItemIconPlist()
  if is_load_item_plist then
    return
  end

  CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/common/item_icon.plist", "ui/common/item_icon.pvr.ccz")
  is_load_item_plist = true
end

function onBagAddRsp(pbPkgData)
   local  bag_add_rsp = bag_pb.bag_add_rsp()
   bag_add_rsp:ParseFromString(pbPkgData)

   ItemManager:getInstance():addMultiItem(bag_add_rsp.items)

   ComSender:getInstance():dealExtInfo(bag_add_rsp.ext)
end 

function ItemManager:onInitBackpage()
    self:checkHasCanUpgradeEqm() --检测是否有可升级的装备
end

function ItemManager:onTeamUpdate()
    self:checkHasCanUpgradeEqm() --检测是否有可升级的装备
end

--检测是否有可升级的装备
function ItemManager:checkHasCanUpgradeEqm()
    self._canUpgradeHeroList = {}
    for k,v in pairs(self.equipItemTab) do
        if self:isCanEqmUpgrade(v) then
            table.insert( self._canUpgradeHeroList ,v.hero_id )
        end
    end
    --是否显示绿点
    Notifier.dispatchCmd(CmdName.UpdateGreenTipsPoint)
end

function ItemManager:sendSellItemReq(item_id, sell_num)
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.bag_sell_req+1, "onBagSellRsp()") --背包物品出售的结果   
    local bag_sell_req = bag_pb.bag_sell_req();
    local bag_sell_item = bag_sell_req.items:add();
    bag_sell_item.id = item_id
    bag_sell_item.quantity = sell_num  
    ComSender:getInstance():send(proto_cmd_pb.msg_cmd.bag_sell_req,bag_sell_req)
end

--服务端返回出售结果
function onBagSellRsp(pbPkgData) 
    Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.bag_sell_req+1, "onBagSellRsp()") --背包物品出售的结果   
    Notifier.dispatchCmd(CmdName.Eqm_UnLocked)
    
    local bag_sell_rsp =bag_pb.bag_sell_rsp()
    bag_sell_rsp:ParseFromString(pbPkgData)

    if bag_sell_rsp.ret ~= error_code_pb.msg_ret.success then
        -- local params = {}
        -- params["txt"] = Helper.getErrStr(bag_sell_rsp.ret)
        -- WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
        -- cclog("sell item fail,i don't know why---%d",bag_sell_rsp.ret)
        Alert:show(Helper.getErrStr(bag_sell_rsp.ret))
        return 
    end             
        
    local count = #(bag_sell_rsp.items)
    local updateItemTab = {} -- 需要更新数量的物品
    local delItemTab = {}-- 数量为0需要删除的物品
    local backpackItemTab = ItemManager:getInstance().backpackItemTab   
    local oneitem_data = nil
    for i =1 ,count do
        oneitem_data = bag_sell_rsp.items[i]

        if(oneitem_data.quantity == backpackItemTab[oneitem_data.id].quantity) then 
            table.insert(delItemTab,oneitem_data.id)
        else
            table.insert(updateItemTab,oneitem_data)
        end
    end 
    
    --更新背包物品数量          
    ItemManager:getInstance():updateMultiItem(updateItemTab)
    
    --删除背包物品
    ItemManager:getInstance():delMultiItem(delItemTab)

    local old_gold_value = CharacterManager:getInstance():getAssetData():getGold() 
    local old_diamond_value = CharacterManager:getInstance():getAssetData():getDiamond()

    --更新资产
    CharacterManager:getInstance():updateRoleAssets(bag_sell_rsp.assets)

    local new_gold_value = CharacterManager:getInstance():getAssetData():getGold() 
    local new_diamond_value = CharacterManager:getInstance():getAssetData():getDiamond() 
                    
    --售出成功后，移除界面
    WindowCtrl:getInstance():close(CmdName.BACKPACK_SELL_VIEW)
    WindowCtrl:getInstance():close(CmdName.BatchUseItemView)

    if new_gold_value>old_gold_value then
        Alert:show(string.format("出售成功，您獲得%d金幣",new_gold_value-old_gold_value))
    elseif new_diamond_value>old_diamond_value then
        Alert:show(string.format("使用成功，您獲得%d鑽石,%dvip經驗",
            new_diamond_value-old_diamond_value, new_diamond_value-old_diamond_value))
    end

    --新手引导保底操作
    local groupId = GuideDataProxy:getInstance():getNowGroupId()
    if groupId == 1 or groupId == 2 then
        GuideRenderMgr:getInstance():forceFinishEvent()
    end

    ComSender:getInstance():dealExtInfo(bag_sell_rsp.ext)
end

function ItemManager:sendPoweredReq(hero_id, eqm_pos, item_id)
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_powered_req+1, "onGetPoweredRsp()") --装备强化的结果   

    local powered_req = hero_pb.hero_eqm_powered_req() 
    powered_req.hero_id = hero_id
    powered_req.eqm_pos = eqm_pos
    powered_req.item_id = item_id
    ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_eqm_powered_req, powered_req)
end

--装备强化的结果
function onGetPoweredRsp(pbPkgData)

    Notifier.dispatchCmd(CmdName.Eqm_UnLocked)

    Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_powered_req+1, "onGetPoweredRsp()") --装备强化的结果   
    local  powered_rsp = hero_pb.hero_eqm_powered_rsp()
    powered_rsp:ParseFromString(pbPkgData)
    
    if powered_rsp.ret ~= error_code_pb.msg_ret.success then
        local params = {}
        -- params["txt"] = Helper.getErrStr(powered_rsp.ret)
        -- WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
        cclog("eqm powered fail,i don't know why----%d",powered_rsp.ret)
        if powered_rsp.ret == error_code_pb.msg_ret.err_not_enough_team_lev then
             Alert:show("戰隊等級不足，提升戰隊等級可提升裝備強化等級上限")
        else
            Alert:show(Helper.getErrStr(powered_rsp.ret))    
        end
        return 
    end 

    Alert:show("裝備強化成功")

    local item = ItemManager:getInstance():getEquipInfoById(powered_rsp.item.id,powered_rsp.item.base_id)
    item:setPoweredLev(powered_rsp.item.eqm_info.powered_lev)

    --更改角色资产
    CharacterManager:getInstance():updateRoleAssets(powered_rsp.assets)

    _instance:setEqmAttrIsChange(item.id,true)
    --通知锻造界面刷新
    Notifier.dispatchCmd(CmdName.EqmPoweredSuccess,item.id)

   --通知英雄界面更新
   local param = {}
   param.hero_id = item.hero_id
   param.location = item.mode.item_type

   Notifier.dispatchCmd(CmdName.EqmInfoUpdate,param) 

   ComSender:getInstance():dealExtInfo(powered_rsp.ext)
end 

--装备附魔的结果
function onGetEnchantRsp(pbPkgData)
    Notifier.dispatchCmd(CmdName.Eqm_UnLocked)
    local  enchant_rsp = hero_pb.hero_eqm_enchant_rsp()
    enchant_rsp:ParseFromString(pbPkgData)
    
    if enchant_rsp.ret ~= error_code_pb.msg_ret.success then
        local params = {}
       -- params["txt"] = Helper.getErrStr(enchant_rsp.ret)
        --WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
       -- cclog("eqm enchant fail,i don't know why----%d",enchant_rsp.ret)
        Alert:show(Helper.getErrStr(enchant_rsp.ret))
        return 
    end 

    -- cclog ("eqm enchant success")

    Alert:show("裝備附魔成功")



    local item = ItemManager:getInstance():getEquipInfoById(enchant_rsp.item.id)
    local old_enchant_lev = item.enchant_lev
    item:setEnchantLev(enchant_rsp.item.eqm_info.enchant_lev)
    item:setEnchantEnergy(enchant_rsp.item.eqm_info.enchant_energy)

    --更改角色资产
    CharacterManager:getInstance():updateRoleAssets(enchant_rsp.assets)

    --删除背包中消耗的物品
    local cost_items = enchant_rsp.items
    local count = #cost_items
    local cost_one = nil
    local item_mgr = ItemManager:getInstance()
    for i = 1,count do
        cost_one = cost_items[i]
        if cost_one~=nil then
           item_mgr:changeDataByClient(cost_one.id,0,cost_one.quantity,ItemHelper.change_type.sub)
        end
    end

    _instance:setEqmAttrIsChange(item.id,true)

    --通知界面刷新
    Notifier.dispatchCmd(CmdName.EnchantSuccess,item.id)

    --通知英雄界面更新
    if old_enchant_lev ~= item.enchant_lev then
        local param = {}
        param.hero_id = item.hero_id
        param.location = item.mode.item_type

        Notifier.dispatchCmd(CmdName.EqmInfoUpdate,param) 
    end

    ComSender:getInstance():dealExtInfo(enchant_rsp.ext)
end 

--发送装备属性锁
local islocked = nil
function ItemManager:sendIdentifyAttrLockReq(hero_id, eqm_pos, item_id, attr_id, is_locked, identify_attrs)
print(" hero_id, eqm_pos, item_id ",hero_id, eqm_pos, item_id)
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_lock_eqm_identify_rsp, "onGetIdentifyAttrLockRsp()") --装备属性锁的结果 
    local identifyAttrLock_req = hero_pb.hero_lock_eqm_identify_req() 

    islocked = is_locked
    self.identify_attrs = identify_attrs
    identifyAttrLock_req.hero_id = hero_id
    identifyAttrLock_req.eqm_pos = eqm_pos
    identifyAttrLock_req.item_id = item_id
    identifyAttrLock_req.attr_id = attr_id
    ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_lock_eqm_identify_req,identifyAttrLock_req)
end

--锁的结果
function onGetIdentifyAttrLockRsp(pbPkgData)
    Notifier.dispatchCmd(CmdName.Eqm_UnLocked)
    Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_lock_eqm_identify_rsp, "onGetIdentifyAttrLockRsp()") --装备属性锁的结果 
    local  identifyAttrLock_rsp = hero_pb.hero_lock_eqm_identify_rsp()
    identifyAttrLock_rsp:ParseFromString(pbPkgData)
    
    if identifyAttrLock_rsp.ret ~= error_code_pb.msg_ret.success then
        cclog("eqm identifyAttrLock fail,i don't know why----%d",identifyAttrLock_rsp.ret)
        Alert:show(Helper.getErrStr(identifyAttrLock_rsp.ret))
        return 
    end 
    -- cclog ("eqm identify success")
    if islocked == 1 then
            Alert:show("屬性鎖已解開")
        else
            Alert:show("屬性鎖定成功")
    end


    local item = ItemManager:getInstance():getEquipInfoById(identifyAttrLock_rsp.item.id)
    if identifyAttrLock_rsp.item_id ~= identifyAttrLock_rsp.item.id then 
        ItemManager:getInstance():delEquipItem(item) --删除旧的
        item.id = identifyAttrLock_rsp.item.id
        ItemManager:getInstance():setEquipItem(item) --增加新的id
    end 

    local item_eqm_info = identifyAttrLock_rsp.item.eqm_info

    local itemMgr = ItemManager:getInstance()
    local attrLocked_vo = nil
    local attr_vo = nil

    for i=1,5 do
        attr_vo = itemMgr.identify_attrs[i]
        if attr_vo then
            for j=1,5 do
                attrLocked_vo = item_eqm_info.identify_attrs[j]
                if attrLocked_vo then
                    if attr_vo.attr_id == attrLocked_vo.attr_id then
                        itemMgr.identify_attrs[i] = attrLocked_vo
                        break
                    end
                end
            end
        end
    end

    --更新鉴定属性
    item:setIdentifyAttrs(itemMgr.identify_attrs)

    _instance:setEqmAttrIsChange(item.id,true)

    --通知界面更新
    Notifier.dispatchCmd(CmdName.IdentifyAttrLockSuc,item.id)

    ComSender:getInstance():dealExtInfo(identifyAttrLock_rsp.ext)
    itemMgr.identify_attrs = nil
    islocked = nil
  
end


function ItemManager:sendIdentifyReq(hero_id, eqm_pos, item_id )
print(" hero_id, eqm_pos, item_id ",hero_id, eqm_pos, item_id)
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_identify_rsp, "onGetIdentifyRsp()") --装备鉴定的结果 
    local identify_req = hero_pb.hero_eqm_identify_req() 
    identify_req.hero_id = hero_id
    identify_req.eqm_pos = eqm_pos
    identify_req.item_id = item_id
    ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_eqm_identify_req,identify_req)
end

--鉴定结果
function onGetIdentifyRsp(pbPkgData)
    Notifier.dispatchCmd(CmdName.Eqm_UnLocked)
    Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_identify_rsp, "onGetIdentifyRsp()") --装备鉴定的结果 
    local  identify_rsp = hero_pb.hero_eqm_identify_rsp()
    identify_rsp:ParseFromString(pbPkgData)
    
    if identify_rsp.ret ~= error_code_pb.msg_ret.success then
      --  SingleBox:getInstance():setTxt(string.format("附魔失敗，失敗ID：%d",enchant_rsp.ret))
       -- WinCtrl:getInstance():getMainScene():addChild(SingleBox:getInstance())
        -- local params = {}
        -- params["txt"] = Helper.getErrStr(identify_rsp.ret)
        -- WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
        cclog("eqm identify fail,i don't know why----%d",identify_rsp.ret)
        Alert:show(Helper.getErrStr(identify_rsp.ret))
        return 
    end 

    -- cclog ("eqm identify success")
    Alert:show("裝備鑒定成功")

    local item = ItemManager:getInstance():getEquipInfoById(identify_rsp.item_id)
    if identify_rsp.item_id ~= identify_rsp.item.id then 
        ItemManager:getInstance():delEquipItem(item) --删除旧的
        item.id = identify_rsp.item.id
        ItemManager:getInstance():setEquipItem(item) --增加新的id
    end 

    local item_eqm_info = identify_rsp.item.eqm_info
     --更新鉴定剩余次数
    -- item.identify_left_num = item_eqm_info.identify_left_num
    item:setIdentifyInfo(item_eqm_info.identify_left_num,item_eqm_info.identify_lucky)
    --更新鉴定属性
    item:setIdentifyAttrs(item_eqm_info.identify_attrs)
   
    --更改角色资产
    CharacterManager:getInstance():updateRoleAssets(identify_rsp.assets)

    _instance:setEqmAttrIsChange(item.id,true)

    --通知界面更新
    Notifier.dispatchCmd(CmdName.IdentifySuccess,item.id)

    --通知英雄界面更新
    local param = {}
    param.hero_id = item.hero_id
    param.location = item.mode.item_type

    Notifier.dispatchCmd(CmdName.EqmInfoUpdate,param) 

    ComSender:getInstance():dealExtInfo(identify_rsp.ext)
  
end

--宝石镶嵌结果
function onGetEmbedOnRsp(pbPkgData)
    Notifier.dispatchCmd(CmdName.Eqm_UnLocked)
    local embed_on_rsp = hero_pb.hero_eqm_embed_on_rsp()
    embed_on_rsp:ParseFromString(pbPkgData)
    
    if embed_on_rsp.ret ~= error_code_pb.msg_ret.success then
        -- local params = {}
        -- params["txt"] = Helper.getErrStr(embed_on_rsp.ret)
        -- WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
        -- cclog("eqm embed_on fail,i don't know why----%d",embed_on_rsp.ret)
        Alert:show(Helper.getErrStr(embed_on_rsp.ret))
        return 
    end 

    -- Alert:show("寶石鑲嵌成功")
    Notifier.dispatchCmd(CmdName.GemSuccessMsgShow)

    local item = ItemManager:getInstance():getEquipInfoById(embed_on_rsp.item.id)
    
    --更新装备的镶嵌信息
    local server_gems = embed_on_rsp.item.eqm_info.gems
    local client_gems = {}
    local num = #server_gems
    
    for i=1,num do
         client_gems[server_gems[i].pos] = server_gems[i].item_base_id
    end
    item:setGems(client_gems)

    --更新背包物品，删除镶嵌消耗物品
    for _,cost_item in pairs(embed_on_rsp.cost_items) do
        if cost_item.id ~= nil then
            ItemManager:getInstance():changeDataByClient(cost_item.id,0,cost_item.quantity,ItemHelper.change_type.sub)
        end
    end  

    --背包增加的物品
    _instance:addMultiItem(embed_on_rsp.add_items)

    -- for _,add_item_info in pairs(embed_on_rsp.add_items) do
    --     if add_item_info.id ~=nil then
    --         ItemManager:getInstance():addBagItem(add_item_info)

    --     end
    -- end  

    _instance:setEqmAttrIsChange(item.id,true)

    --通知界面更新
    Notifier.dispatchCmd(CmdName.GemSuccess,item.id)

    --通知英雄界面
    local param = {}
    param.hero_id = item.hero_id
    param.location = item.mode.item_type
    Notifier.dispatchCmd(CmdName.EqmInfoUpdate,param) 

    ComSender:getInstance():dealExtInfo(embed_on_rsp.ext)
end


--宝石摘除结果
function onGetEmbedOffRsp(pbPkgData)
    
    local embed_off_rsp = hero_pb.hero_eqm_embed_off_rsp()
    embed_off_rsp:ParseFromString(pbPkgData)
    
    if embed_off_rsp.ret ~= error_code_pb.msg_ret.success then
        -- local params = {}
        -- params["txt"] = Helper.getErrStr(embed_off_rsp.ret)
        -- WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
        Alert:show(Helper.getErrStr(embed_off_rsp.ret))
        return 
    end 

    Alert:show("寶石摘除成功")

    local item = ItemManager:getInstance():getEquipInfoById(embed_off_rsp.item.id)
    
    --更新装备的镶嵌信息
    local server_gems = embed_off_rsp.item.eqm_info.gems
    local client_gems = {}
    local num = #server_gems
    
    for i=1,num do
         client_gems[server_gems[i].pos] = server_gems[i].item_base_id
    end
    item:setGems(client_gems)

    --更新背包物品，摘除的宝石返回背包
    ItemManager:getInstance():addMultiItem(embed_off_rsp.add_items)

    _instance:setEqmAttrIsChange(item.id,true)

    --通知界面更新
    Notifier.dispatchCmd(CmdName.GemSuccess,item.id)

    --通知英雄界面
    local param = {}
    param.hero_id = item.hero_id
    param.location = item.mode.item_type
    Notifier.dispatchCmd(CmdName.EqmInfoUpdate,param) 

    ComSender:getInstance():dealExtInfo(embed_off_rsp.ext)
end

--宝石升级结果
function onGetEmbedUpgradeRsp(pbPkgData)
    Notifier.dispatchCmd(CmdName.Eqm_UnLocked)
    local gem_upgrade_rsp = hero_pb.hero_eqm_embed_upgrade_rsp()
    gem_upgrade_rsp:ParseFromString(pbPkgData)
    
    if gem_upgrade_rsp.ret ~= error_code_pb.msg_ret.success then
      --  SingleBox:getInstance():setTxt(string.format("附魔失敗，失敗ID：%d",enchant_rsp.ret))
       -- WinCtrl:getInstance():getMainScene():addChild(SingleBox:getInstance())
        -- local params = {}
        -- params["txt"] = Helper.getErrStr(gem_upgrade_rsp.ret)
        -- WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
        -- cclog("eqm embed_upgrade fail,i don't know why----%d",gem_upgrade_rsp.ret)
        Alert:show(Helper.getErrStr(gem_upgrade_rsp.ret))
        return 
    end 

    Alert:show("寶石升級成功")

    local item = ItemManager:getInstance():getEquipInfoById(gem_upgrade_rsp.item.id)
    
    --更新装备的镶嵌信息
    local server_gems = gem_upgrade_rsp.item.eqm_info.gems
    local client_gems = {}
    local num = #server_gems
    
    for i=1,num do
         client_gems[server_gems[i].pos] = server_gems[i].item_base_id
    end
    item:setGems(client_gems)

    --更新背包物品，删除镶嵌消耗物品
    for _,cost_item in pairs(gem_upgrade_rsp.cost_items) do
        ItemManager:getInstance():changeDataByClient(cost_item.id,0,cost_item.quantity,ItemHelper.change_type.sub)
    end   

    _instance:setEqmAttrIsChange(item.id,true) 

    --通知界面更新
    Notifier.dispatchCmd(CmdName.GemSuccess,item.id)

    --通知英雄界面
    local param = {}
    param.hero_id = item.hero_id
    param.location = item.mode.item_type
    Notifier.dispatchCmd(CmdName.EqmInfoUpdate,param) 

    ComSender:getInstance():dealExtInfo(gem_upgrade_rsp.ext)
end

function sendBagInfoReq()
    Notifier.remove(CmdName.LOGIN_FINISH)
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.bag_info_req+1, "onBagInfoRsp()")

    --登陆成功后,初始化数据
    ItemManager:getInstance():readItemData()
    ItemManager:getInstance():readEqmData()
    ItemManager:getInstance():readGemData()

    --请求背包数据
    local  bag_info_req = bag_pb.bag_info_req();
    bag_info_req.rid.uin = CharacterManager:getInstance():getLoginData():getAcctId()
    bag_info_req.rid.channel_id =CharacterManager:getInstance():getLoginData():getChannelId()
    bag_info_req.rid.zone_id = CharacterManager:getInstance():getLoginData():getZoneId()
   -- local bag_content = bag_info_req:SerializeToString()
    --Global:sendPkg(proto_cmd_pb.msg_cmd.bag_info_req, bag_content , string.len(bag_content))
    ComSender:getInstance():send(proto_cmd_pb.msg_cmd.bag_info_req, bag_info_req)     
end


function onBagInfoRsp(pbPkgData)
    Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.bag_info_req+1, "onBagInfoRsp()")
    -- local  bag_msg_rsp = bag_pb.bag_info_rsp()
    -- bag_msg_rsp:ParseFromString(pbPkgData)
    -- local count = #bag_msg_rsp.items
    ItemManager:getInstance():initBackPackData(bag_msg_rsp.items)

    --收到背包数据后，请求英雄数据+槽位装备数据+战队数据
    -- HeroManager:getInstance():sendHeroInfoReq(HeroHelper.hero_info_req_type.all) --请求英雄信息
    -- TeamManager:getInstance():reqTeamAllInfo(TeamType.Normal) --请求战队信息
    -- HeroManager:getInstance():sendHeroAllEqmReq() --请求上阵英雄的装备信息

end

--请求装备升级
function ItemManager:sendEquipUpgradeReq(param)

    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_upgrade_req+1, "onEquipUpgradeRsp()")

    print("---------------- sendEquipUpgradeReq --------------------- ",param.hero_id,param.eqm_pos,param.item_id)
    local hero_eqm_upgrade_req = hero_pb.hero_eqm_upgrade_req()
    hero_eqm_upgrade_req.hero_id = param.hero_id
    hero_eqm_upgrade_req.eqm_pos = param.eqm_pos
    hero_eqm_upgrade_req.item_id = param.item_id

    ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_eqm_upgrade_req, hero_eqm_upgrade_req)
end

--响应装备升级
function onEquipUpgradeRsp(pbPkgData)
    Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_eqm_upgrade_req+1, "onEquipUpgradeRsp()")

    local hero_eqm_upgrade_rsp = hero_pb.hero_eqm_upgrade_rsp()
    hero_eqm_upgrade_rsp:ParseFromString(pbPkgData)

    if hero_eqm_upgrade_rsp.ret ~= error_code_pb.msg_ret.success then
         Alert:show(Helper.getErrStr(hero_eqm_upgrade_rsp.ret))
        cclog("hero upgrade eqm fail,i don't know why.error_code_id:%d",hero_eqm_upgrade_rsp.ret)
        return 
    end     

    ComSender:getInstance():dealExtInfo(hero_eqm_upgrade_rsp.ext)
    local eqms = HeroManager:getInstance():getBattleHeroEqmList(hero_eqm_upgrade_rsp.hero_id)
    if eqms == nil then
        cclog ("eqms is nil，該英雄未上陣%d",hero_eqm_upgrade_rsp.hero_id)
        return
    end

    ItemManager:getInstance():updateOrDelMultiItems(hero_eqm_upgrade_rsp.cost_items)--更新背包物品

    local equipVo = eqms:getSingleEquip(hero_eqm_upgrade_rsp.eqm_pos)
    if equipVo == nil then
        equipVo = EquipVo.new()
    elseif equipVo.item ~= nil then
        _instance:delEquipItem(equipVo.item)
    end

    local onItem = _instance:addEqmItem(hero_eqm_upgrade_rsp.hero_id, hero_eqm_upgrade_rsp.item) --穿上新升级好的装备
    equipVo:setInfo(hero_eqm_upgrade_rsp.eqm_pos,onItem)
    eqms:setSingleEquip(equipVo) 

    WindowCtrl:getInstance():close(CmdName.ItemUpgradeView)

    CharacterManager:getInstance():updateRoleAssets(hero_eqm_upgrade_rsp.assets) --更新资产

    --通知相应界面更新
   local param = {}
   param.hero_id = hero_eqm_upgrade_rsp.hero_id
   param.location = hero_eqm_upgrade_rsp.eqm_pos
   Notifier.dispatchCmd(CmdName.EqmInfoUpdate,param) 

   local param2 = {}
   param2.item = onItem
   param2.location = hero_eqm_upgrade_rsp.eqm_pos
   Notifier.dispatchCmd(CmdName.EqmUpgradeSuc,param2)
   --检测绿点
    _instance:checkHasCanUpgradeEqm()

    Alert:show("裝備升級成功")
end

--请求装备重置
function ItemManager:sendEquipIdentifyReset(param)
    
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_reset_eqm_identify_req+1, "onEquipIdentifyReset()")

    print("---------------- sendEquipIdentifyReset --------------------- ",param.hero_id,param.eqm_pos,param.item_id)
    local hero_reset_eqm_identify_req = hero_pb.hero_reset_eqm_identify_req()
    hero_reset_eqm_identify_req.hero_id = param.hero_id
    hero_reset_eqm_identify_req.eqm_pos = param.eqm_pos
    hero_reset_eqm_identify_req.item_id = param.item_id

    for item_id,num in pairs(param.cost_arr) do
        if num > 0 then
            local item_del = common_2_pb.item_del()
            print(" item_id ",item_id,"num",num)
            item_del.id = item_id
            item_del.quantity = num
            table.insert(hero_reset_eqm_identify_req.items,item_del)
        end
    end

    ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_reset_eqm_identify_req, hero_reset_eqm_identify_req)
end

--响应装备重置
function onEquipIdentifyReset(pbPkgData)

    Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_reset_eqm_identify_req+1, "onEquipIdentifyReset()")

    local hero_reset_eqm_identify_rsp = hero_pb.hero_reset_eqm_identify_rsp()
    hero_reset_eqm_identify_rsp:ParseFromString(pbPkgData)

    if hero_reset_eqm_identify_rsp.ret ~= error_code_pb.msg_ret.success then
         Alert:show(Helper.getErrStr(hero_reset_eqm_identify_rsp.ret))
        cclog("hero upgrade eqm fail,i don't know why.error_code_id:%d",hero_reset_eqm_identify_rsp.ret)
        return 
    end     

    ComSender:getInstance():dealExtInfo(hero_reset_eqm_identify_rsp.ext)
    local eqms = HeroManager:getInstance():getBattleHeroEqmList(hero_reset_eqm_identify_rsp.hero_id)
    if eqms == nil then
        cclog ("eqms is nil，該英雄未上陣%d",hero_reset_eqm_identify_rsp.hero_id)
        return
    end

    local equipType = ItemHelper:getEquipTypeWithItemType(hero_reset_eqm_identify_rsp.eqm_pos)  
    if equipType == ItemHelper.equipType.equip then

        local equipVo = eqms:getSingleEquip(hero_reset_eqm_identify_rsp.eqm_pos)
        if equipVo.item ~= nil then --清空重置
           -- equipVo.item:setIdentifyAttrs({})
           equipVo.item.identify_left_num = 5 --最大5次
        end

        CharacterManager:getInstance():updateRoleAssets(hero_reset_eqm_identify_rsp.assets) --更新资产

        ItemManager:getInstance():updateOrDelMultiItems(hero_reset_eqm_identify_rsp.cost_items)--更新背包物品
        WindowCtrl:getInstance():close(CmdName.EqmIdentifyResetPanel)
        --通知相应界面更新
       local param = {}
       param.hero_id = hero_reset_eqm_identify_rsp.hero_id
       param.location = hero_reset_eqm_identify_rsp.eqm_pos
       Notifier.dispatchCmd(CmdName.EqmInfoUpdate,param) 
       
       Notifier.dispatchCmd(CmdName.IdentifyResesSuc,equipVo.item.id)
          Alert:show("鑒定重置成功")
    elseif equipType == ItemHelper.equipType.fashion then

        local itemVo = HeroManager:getInstance():getFashionItemTab(hero_reset_eqm_identify_rsp.eqm_pos,hero_reset_eqm_identify_rsp.hero_id)
        if itemVo then
            itemVo.identify_left_num = 5
        end

        CharacterManager:getInstance():updateRoleAssets(hero_reset_eqm_identify_rsp.assets) --更新资产

        ItemManager:getInstance():updateOrDelMultiItems(hero_reset_eqm_identify_rsp.cost_items)--更新背包物品
        WindowCtrl:getInstance():close(CmdName.EqmIdentifyResetPanel)

            --通知相应界面更新
           local param = {}
           param.hero_id = hero_reset_eqm_identify_rsp.hero_id
           param.location = hero_reset_eqm_identify_rsp.eqm_pos
           Notifier.dispatchCmd(CmdName.EqmInfoUpdate,param) 
           
           Notifier.dispatchCmd(CmdName.IdentifyResesSuc,itemVo.id)
         Alert:show("鑒定重置成功")
    end

end

function ItemManager:getInstance()

    if _instance == nil then
        _allowInstance = true
        _instance = ItemManager.new()
        _allowInstance = false
    end

    return _instance

end

--读取物品表
function ItemManager:readItemData()

    if self.isRead then
        cclog ("itemdata had already read,don't call this method again")
        return
    end

   --[[ local dataFile = CCFileUtils:sharedFileUtils():fullPathForFilename("fnt_item_data.dat")
    local datafile_handle = io.open(dataFile, "rb")
    local pbdata = datafile_handle:read("*a")
    datafile_handle:close()--]]
    local pbdata = Global:getAssetFileData("fnt_item_data.dat", "rb")
    print("===============讀取物品表=============================",#pbdata)
    local msg = fnt_item_data_pb.fnt_item_data()
    msg:ParseFromString(pbdata)

    -- 尝试读取第一个标签页的数据
    local normal_item_table = msg.normal_item_rows
    local item_one_data = nil

    for i, v in pairs(normal_item_table) do
        if v.base_id~=nil then 
            item_one_data = ItemModel.new()
            item_one_data.base_id = v.base_id
            item_one_data.name = v.name
            item_one_data.icon_id = v.icon_id
            item_one_data.item_type = v.item_type
            item_one_data.quality = v.quality
            item_one_data.useway = v.useway
            -- item_one_data.attr_desc = v.attr_desc
            item_one_data.desc = v.desc
            item_one_data.limit_lev = v.limit_lev
            item_one_data.limit_stand = v.limit_stand
            item_one_data.money_type = v.money_type
            item_one_data.sell_price = v.sell_price
            item_one_data.enchant_energy = v.enchant_energy
            item_one_data.func_type = v.func_type
            item_one_data.script_args = tonumber(v.script_args)
            self.allItemDataTab[item_one_data.base_id] = item_one_data
        end
    end

    -- 尝试读取第二个标签页的数据
    local equip_item_table = msg.equip_item_rows

    for i, v in pairs(equip_item_table) do
        if v.base_id~=nil then
            item_one_data = ItemModel.new()
            item_one_data.base_id = v.base_id
            item_one_data.name = v.name
            item_one_data.icon_id = v.icon_id
            item_one_data.item_type = v.item_type
            item_one_data.quality = v.quality
            item_one_data.eqm_quality = v.eqm_quality or 0
            item_one_data.useway = v.useway
            -- item_one_data.attr_desc = v.attr_desc
            item_one_data.desc = v.desc
            item_one_data.limit_lev = v.limit_lev
            item_one_data.limit_stand = v.limit_stand
            item_one_data.money_type = v.money_type
            item_one_data.sell_price = v.sell_price
            item_one_data.enchant_energy = v.enchant_energy
            item_one_data.func_type = v.func_type
            self.allItemDataTab[item_one_data.base_id] = item_one_data
        end
    end
        
    -- 尝试读取第三个标签页的数据
    local gift_item_table = msg.gift_data_rows
    for i, v in pairs(gift_item_table) do
        if v.base_id~=nil then 
            item_one_data = ItemModel.new()
            item_one_data.base_id = v.base_id
            item_one_data.name = v.name
            item_one_data.icon_id = v.icon_id
            item_one_data.item_type = v.item_type
            item_one_data.quality = v.quality
            item_one_data.useway = v.useway
            -- item_one_data.attr_desc = v.attr_desc
            item_one_data.desc = v.desc
            item_one_data.limit_lev = v.limit_lev
            item_one_data.limit_vip = v.limit_vip
            item_one_data.limit_stand = v.limit_stand
            item_one_data.money_type = v.money_type
            item_one_data.sell_price = v.sell_price
            item_one_data.enchant_energy = v.enchant_energy
            item_one_data.func_type = v.func_type
            item_one_data.expire_type = v.expire_type
            item_one_data.expire_time = v.expire_time
            item_one_data.expire_beg = v.expire_beg
            item_one_data.expire_end = v.expire_end
            item_one_data.gain_cost = v.gain_cost
            item_one_data.gain_currency = v.gain_currency
            self.allItemDataTab[item_one_data.base_id] = item_one_data
        end
    end

    --由物品获取 对应英雄
    require "LotteryDataProxy"
    local goods_relation_table = msg.goods_relation_rows
    local dp = LotteryDataProxy:getInstance()
    for i, v in pairs(goods_relation_table) do
        if v.base_id ~= nil then
            local item = dp:createLotteryHeroItemVo()
            item.itemId = v.base_id
            item.heroId = v.hero_id
            item.heroStar = v.hero_star
            dp:setLotteryHeroItemVo(item)
        end
    end

    local goods_res_monster_table = msg.goods_res_monster_rows
    require "ResContendManager"
    require "ResContendData"
    local dp = ResContendManager:getInstance()
    local list = dp:getGuardGoodsDict()
    for k,v in pairs(goods_res_monster_table) do
        if v.base_id ~= nil then
            local vo = ResGuardGoods:create()
            vo.baseId = v.base_id
            vo.guardId = v.guard_base_id
            vo.stars = v.stars
            list[vo.guardId] = list[vo.guardId] or {}
            list[vo.guardId][vo.stars] = vo
        end
    end

    --礼包
    local gift_relation_rows = msg.gift_relation_rows
    for k,v in pairs(gift_relation_rows) do
        if v.gift_id ~= nil then
            self.gift_relation_list[v.gift_id] = self.gift_relation_list[v.gift_id] or {}
            table.insert(self.gift_relation_list[v.gift_id],{base_id = v.base_id,quantity = v.quantity})
        end
    end
   self.isRead = true
end

--根据物品的唯一ID返回相应的物品基础信息
function ItemManager:getItemModleById(itemId)
    local tempdata = self.backpackItemTab[itemId]
    return tempdata.mode 
end

--通过物品基础ID查找基础信息
function ItemManager:getItemModelByBaseId(itemBaseId)
    return self.allItemDataTab[itemBaseId]
end

--获取礼包预览项
function ItemManager:giftRelationList(base_id)
    return self.gift_relation_list[base_id]
end

--获取礼包预览项 文字描述
function ItemManager:giftRelationListStr(base_id)
    local tbl = self.gift_relation_list[base_id]
    local str = ""
    for i=1 ,#tbl do
        local mode = self:getItemModelByBaseId(tbl[i].base_id)
        str = str .. mode.name .. "x" ..  tbl[i].quantity .. "\n"
    end
    return str
end

--通过唯一ID，从背包中取出相应物品数据
function ItemManager:getItemById(itemId)
    return self.backpackItemTab[itemId]
end

--初始化背包数据
function ItemManager:initBackPackData(srv_all_items)
    
   self.isBackPackInit = true 
   -- local  bag_msg_rsp = bag_pb.bag_info_rsp()
   -- bag_msg_rsp:ParseFromString(pbPkgData)

   local count = #srv_all_items
   local oneItemData = nil
   for i =1 ,count do
         oneItemData = srv_all_items[i]
         self:addBagItem(oneItemData, false)
   end

   table.sort(self.backpackItemIdArr,self._onBagItemsSort)

   --通知背包界面更新
    Notifier.dispatchCmd(CmdName.BACKPACK_INIT)

    -- ComSender:getInstance():dealExtInfo(bag_msg_rsp.ext)
end

--添加背包物品
function ItemManager:addBagItem(item_info, is_need_disptch)
    local tempBackItem = self.backpackItemTab[item_info.id]
    local is_new_eqm_item = false
    if tempBackItem == nil then
        tempBackItem = Item:new()
        tempBackItem:setItemInfo(item_info.id,item_info.base_id,item_info.quantity)
        table.insert(self.backpackItemIdArr,item_info.id)
        is_new_eqm_item = true
    else
        tempBackItem.quantity =tempBackItem.quantity + item_info.quantity
    end
    
    --鉴定属性可以在背包中存在
    --设置鉴定属性
    item_eqm_info = item_info.eqm_info
    if item_eqm_info then
        tempBackItem:setIdentifyInfo(item_eqm_info.identify_left_num,item_eqm_info.identify_lucky)
        tempBackItem:setIdentifyAttrs(item_eqm_info.identify_attrs)
    end
    self.backpackItemTab[item_info.id] = tempBackItem

    --新的物品,而且是装备
    if is_need_disptch~=false and is_new_eqm_item and
        self:isEqm(tempBackItem.mode.item_type) then
        Notifier.dispatchCmd(CmdName.BagAddNewEqmItem, tempBackItem)
    end

    --新物品，而且是灵魂石
    if ItemHelper:isSoulStone(item_info.base_id) then
       if self.soul_stone_nums[item_info.base_id]==nil then
            self.soul_stone_nums[item_info.base_id] = 0
       end
       --item_info.quantity为增加的数量
       self.soul_stone_nums[item_info.base_id]= self.soul_stone_nums[item_info.base_id]+item_info.quantity
       cclog("增加的靈魂石名稱~~~%s，增加的數量%d，增加後的總數量~~%d",
            tempBackItem.mode.name, item_info.quantity, self.soul_stone_nums[item_info.base_id])
       Notifier.dispatchCmd(CmdName.UpdateGreenTipsPoint, 
                        {HeroManager:getInstance():findHeroByGemId(item_info.base_id)})
    end

    if tempBackItem.mode.item_type == ItemHelper.itemType.equip_fragment then --新物品 碎片
        self:checkHasCanUpgradeEqm()
    elseif tempBackItem.mode.func_type == ItemHelper.func_type.gift_card then --礼包
        tempBackItem:setGiftInfo(item_info)
    elseif tempBackItem.mode.func_type == ItemHelper.func_type.pet_levup or   --侍宠物品
            tempBackItem.mode.func_type == ItemHelper.func_type.pet_upgrade then
        require "PetEvent"
        Notifier.dispatchCmd(PetEvent.Update_items)
    end
    return tempBackItem
end

--判断当前物品是否虚拟物品
function ItemManager:isVirtualItem(base_id)
    local item_mode = self:getItemModelByBaseId(base_id)
    if (item_mode.item_type > ItemHelper.itemType.Ring and
        item_mode.item_type <= ItemHelper.itemType.hero_card) or
        item_mode.item_type == ItemHelper.itemType.guard_card then
        return true
    end
    return false
end

--背包中添加多个物品
function ItemManager:addMultiItem(itemArr)
    
    local count = #(itemArr)
    local oneItemData = nil
    local tempBackItem = nil
    --self.addItemDataTab = {}
    local tempTab = {}  
    
    for i =1 ,count do
        oneItemData = itemArr[i]
        if  self:isVirtualItem(oneItemData.base_id)==false  then --过滤金币 
            tempBackItem = self:addBagItem(oneItemData)
            tempTab[oneItemData.id] = tempBackItem
        end
    end
    table.sort(self.backpackItemIdArr,self._onBagItemsSort)
    Notifier.dispatchCmd(CmdName.BACKPACK_ADD,tempTab)
end 

--客户端控制背包中添加单个物品，
--例如抽奖后拿到若干物品，由对应功能调用增加
function ItemManager:addSingleItem(id,base_id,quantity)
    
    local tempTab = {}  
    local cliten_item_info = {}
    cliten_item_info.id = id
    cliten_item_info.base_id = base_id
    cliten_item_info.quantity = quantity
    tempTab[id] = self:addBagItem(cliten_item_info)
    table.sort(self.backpackItemIdArr,self._onBagItemsSort)
    Notifier.dispatchCmd(CmdName.BACKPACK_ADD,tempTab)

    -- local tempTab = {}  
    -- local tempBackItem = self.backpackItemTab[id]
    -- if tempBackItem == nil then
    --     tempBackItem = Item:new()
    --     tempBackItem:setItemInfo(id,base_id,quantity)
    --     table.insert(self.backpackItemIdArr,id) 
    -- else 
    --     tempBackItem.quantity = tempBackItem.quantity + quantity
    -- end
  
    -- self.backpackItemTab[id] = tempBackItem
    -- tempTab[id] = tempBackItem
      
    -- Notifier.dispatchCmd(CmdName.BACKPACK_ADD,tempTab)
end 

--更新物品数量
function ItemManager:updateMultiItem(itemArr)
    local count = #(itemArr)    
    local tempItem = nil
    local backpackItemTab = self.backpackItemTab
    local updateItemDataTab = {}    
    
    for i =1 ,count do
       tempItem = itemArr[i]
      -- backpackItemTab[tempItem.id].quantity = backpackItemTab[tempItem.id].quantity - tempItem.quantity -- 更新数量
       self:updateItem(tempItem.id, tempItem.quantity)
       table.insert(updateItemDataTab,tempItem.id)
    end
    
    Notifier.dispatchCmd(CmdName.BACKPACK_UPDATE,updateItemDataTab)
end

--背包物品更新数量必须调用的方法(此方法只管更新数量，不负责数量由1→0的情况，
--如果是删除的则由del处理)
function ItemManager:updateItem(id,quantity)
    --self.backpackItemTab[id].quantity = self.backpackItemTab[id].quantity - quantity -- 更新数量

    local temp_item = self.backpackItemTab[id]
    temp_item.quantity = temp_item.quantity - quantity

     if ItemHelper:isSoulStone(temp_item.mode.base_id) then
       if self.soul_stone_nums[temp_item.mode.base_id]==nil then
            self.soul_stone_nums[temp_item.mode.base_id] = 0
       end
       self.soul_stone_nums[temp_item.mode.base_id]= self.soul_stone_nums[temp_item.mode.base_id]- quantity
       cclog("減少的靈魂石名稱~~%s，減少的數量%d~~~剩餘的總數量~~~%d",
                temp_item.mode.name, quantity, self.soul_stone_nums[temp_item.mode.base_id])
        Notifier.dispatchCmd(CmdName.UpdateGreenTipsPoint, 
                        {HeroManager:getInstance():findHeroByGemId(temp_item.mode.base_id)})
    end

    if temp_item.mode.item_type == ItemHelper.itemType.equip_fragment then --碎片
        self:checkHasCanUpgradeEqm()
    end
end

function ItemManager:updateSingleItem(id,quantity) 
    local updateItemDataTab = {}
   -- print(self.backpackItemTab[id].quantity , quantity)
   -- self.backpackItemTab[id].quantity = self.backpackItemTab[id].quantity - quantity -- 更新数量
    self:updateItem(id, quantity)
    table.insert(updateItemDataTab,id)
    Notifier.dispatchCmd(CmdName.BACKPACK_UPDATE,updateItemDataTab)
end

--批量删除背包中的物品
function ItemManager:delMultiItem(itemIdArr) --itemArr为存储物品ID的数组
    local count = #(itemIdArr)  
    local id = 0
    local backpackItemTab = self.backpackItemTab
    local delItemDataTab = {}   
    
    for i =1 ,count do
        id = itemIdArr[i]
       --backpackItemTab[id] = nil
        self:delItem(id)
        table.insert(delItemDataTab,id)
       --table.remove(self.backpackItemIdArr, Helper.findArrIndexByValue(self.backpackItemIdArr,id))
    end
    
    if count>0 then
         Notifier.dispatchCmd(CmdName.BACKPACK_DEL,delItemDataTab)
    end
end

--删除单个物品
function ItemManager:delSingleItem(item_id)
    local delItemDataTab = {}
    --self.backpackItemTab[item_id] = nil   
    self:delItem(item_id)
    table.insert(delItemDataTab,item_id)
    --table.remove(self.backpackItemIdArr, Helper.findArrIndexByValue(self.backpackItemIdArr,item_id))
    
    Notifier.dispatchCmd(CmdName.BACKPACK_DEL,delItemDataTab)   
    cclog("刪掉一個物品")
end

--物品被删除时必须调用的方法
function ItemManager:delItem(item_id)
    local del_item = self.backpackItemTab[item_id]
    local delItemItem_type = del_item.mode.item_type

    if del_item and  ItemHelper:isSoulStone(del_item.mode.base_id) then
       if self.soul_stone_nums[del_item.mode.base_id]==nil then
            self.soul_stone_nums[del_item.mode.base_id] = 0
       end
       self.soul_stone_nums[del_item.mode.base_id]= self.soul_stone_nums[del_item.mode.base_id]- del_item.quantity
       cclog("刪除的靈魂石名稱~~%s，刪除的數量%d~~~剩餘的總數量~~~%d",
                del_item.mode.name, del_item.quantity, self.soul_stone_nums[del_item.mode.base_id])
       Notifier.dispatchCmd(CmdName.UpdateGreenTipsPoint, 
                        {HeroManager:getInstance():findHeroByGemId(del_item.mode.base_id)})
    end

    del_item = nil
    self.backpackItemTab[item_id] = nil 
    table.remove(self.backpackItemIdArr, Helper.findArrIndexByValue(self.backpackItemIdArr,item_id))

    if delItemItem_type == ItemHelper.itemType.equip_fragment then --碎片
        self:checkHasCanUpgradeEqm()
    end
end

function ItemManager:updateOrDelMultiItems( item_list )
    local count = #(item_list)
    local updateItemTab = {} -- 需要更新数量的物品
    local delItemTab = {}-- 数量为0需要删除的物品
    local backpackItemTab = ItemManager:getInstance().backpackItemTab   
    local del_item = nil
    for i =1 ,count do
        del_item = item_list[i]
        if(del_item.quantity == backpackItemTab[del_item.id].quantity) then 
            table.insert(delItemTab,del_item.id)
        else
            table.insert(updateItemTab,del_item)
        end
    end 
    
    --更新背包物品数量          
    ItemManager:getInstance():updateMultiItem(updateItemTab)
    
    --删除背包物品
    ItemManager:getInstance():delMultiItem(delItemTab)
end

--根据物品类型返回相应物品数据
function ItemManager:getItemArrByItemType(itemType)
    local tempArr = {}
    local backpackItemTab = self.backpackItemTab
    local allItemDataTab = self.allItemDataTab  
    local itemType = itemType 
    
    for i,v in pairs(backpackItemTab) do
        if(v.mode.item_type == itemType) then 
            table.insert(tempArr,v)
        end
    end
    
    return tempArr
end

--根据ID区间返回相应物品数据
--10000至39999的是装备
-- 44000至44999的是灵魂石
-- 其他是消耗品
function ItemManager:getItemArrByIdInterval(id_type)
    local tempArr = {}
    local backpackItemTab = self.backpackItemTab
    local allItemDataTab = self.allItemDataTab  
    local itemType = itemType 
    
    for i,v in pairs(backpackItemTab) do
  --       if id_type == 2 then
  --           if v.mode.base_id>=10000 and v.mode.base_id<=39999 then
  --               table.insert(tempArr,i)
  --           end
  --       elseif id_type == 4 then
  --           if  v.mode.base_id>=44000 and v.mode.base_id<=44999 then
        --   table.insert(tempArr,i)
  --           end
  --       else
  --            table.insert(tempArr,i)
        -- end

        if v.mode.base_id>=10000 and v.mode.base_id<=39999 then
            if id_type == 2 then
                table.insert(tempArr,i)
            end
        elseif v.mode.base_id>=44000 and v.mode.base_id<=44999 then
            if id_type == 4 then
                table.insert(tempArr,i)
            end
        elseif v.mode.base_id >= 46000 and v.mode.base_id <= 46999 then
            if id_type == 5 then
                table.insert(tempArr,i)
            end
        elseif id_type==3 then
            table.insert(tempArr,i)
        end

    end
    
    return tempArr
end

--对可装备的物品进行排序
local eqm_exc_attr_flag = 0 -- 当前装备的属性
local team_lv_for_eqm_sort = 0
local function eqmListSort(item_one, item_two)
    -- local item_one = _instance:getItemById(id_one) or _instance:getEquipInfoById(id_one)
    -- local item_two = _instance:getItemById(id_two) or _instance:getEquipInfoById(id_two)
    local attrs_one = ItemManager:getInstance():getEqmBaseAttrAddQuality(item_one.mode.base_id)
    local attrs_two = ItemManager:getInstance():getEqmBaseAttrAddQuality(item_two.mode.base_id)

    if item_one == nil or item_two == nil then
        return false
    end

    -- if item_one.hero_id>0 and item_two.hero_id>0 then
    --     return attrs_one[eqm_exc_attr_flag] > attrs_two[eqm_exc_attr_flag]
    -- elseif item_one.hero_id>0 and item_two.hero_id==0 then
    --     return false
    -- elseif item_one.hero_id==0 and item_two.hero_id>0 then
    --     return true
    -- end

    --按照属性从高到低排序
    --如果两件装备属性一样，其中一件已经被某英雄装备，则被装备的排后

    if (team_lv_for_eqm_sort>=item_one.mode.limit_lev and
        team_lv_for_eqm_sort>=item_two.mode.limit_lev) or 
        (team_lv_for_eqm_sort<item_one.mode.limit_lev and 
        team_lv_for_eqm_sort<item_two.mode.limit_lev )then -- 如果两件装备都满足/不满足等级，则比较属性
        

        --两件装备都已经被穿戴了，或者两件都未被穿戴，按品质，同品质的按属性
        if (item_one.hero_id>0 and item_two.hero_id>0) or 
            (item_one.hero_id==0 and item_two.hero_id==0) then
               
                if item_one.mode.quality~=item_two.mode.quality then
                    if _instance:canIdentify(item_one)==true and 
                        _instance:canIdentify(item_two)==false then
                        return true
                    elseif _instance:canIdentify(item_one)==false and 
                         _instance:canIdentify(item_two)==true then
                         return false
                    elseif _instance:canIdentify(item_one)==true and 
                         _instance:canIdentify(item_two)==true then    
                         return item_one.mode.quality>item_two.mode.quality
                    end
                end

           -- if attrs_one[eqm_exc_attr_flag]~=attrs_two[eqm_exc_attr_flag] then
                return attrs_one[eqm_exc_attr_flag] > attrs_two[eqm_exc_attr_flag]
          --  else
            --    return compareHeroId(item_one, item_two)
         --   end

        else
            return item_one.hero_id<item_two.hero_id
        end

        --品质不一样的情况下，比较品质，橙装->紫装->蓝装=绿装=白装，蓝绿白认为是一个品质
        -- if item_one.mode.quality~=item_two.mode.quality then
        --     if _instance:canIdentify(item_one)==true and 
        --     _instance:canIdentify(item_two)==false then
        --         return true
        --     elseif _instance:canIdentify(item_one)==false and 
        --          _instance:canIdentify(item_two)==true then
        --          return false
        --     elseif _instance:canIdentify(item_one)==true and 
        --          _instance:canIdentify(item_two)==true then    
        --          return item_one.mode.quality>item_two.mode.quality
        --     end
        -- end

        -- if attrs_one[eqm_exc_attr_flag]~=attrs_two[eqm_exc_attr_flag] then
        --     return attrs_one[eqm_exc_attr_flag] > attrs_two[eqm_exc_attr_flag]
        -- else
        --     return compareHeroId(item_one, item_two)
        -- end

    else
        -- 其中一件装备满足等级，另外一件不满足，则选装备等级最低那件排在前面
        return item_one.mode.limit_lev<item_two.mode.limit_lev
    end
end

--通过英雄类型(前中后)+装备部位类型，从背包中筛选出合适的物品数组
function ItemManager:findFitEquipFromBackPack(heroType,location,isAllowExc)
    
    local tempEquipArr = {}
    local backpackItemTab = self.backpackItemTab
    local allItemDataTab = self.allItemDataTab
    local tempItemMode = nil
    for i,v in pairs(backpackItemTab) do
        if(v.mode.limit_stand == heroType and v.mode.item_type == location) then 
            table.insert(tempEquipArr,v)
        end 
    end

    --是否允许跟其它英雄交换，不允许的话则只显示背包中的装备
    if isAllowExc then
        for _,eqm_item in pairs(self.equipItemTab) do
            if eqm_item.mode.limit_stand == heroType 
                and eqm_item.mode.item_type == location
                and eqm_item.hero_id>0 then 
                table.insert(tempEquipArr,eqm_item)
            end 
        end
    end

    eqm_exc_attr_flag =  ItemHelper:getAttrFlagByLocation(location)
    team_lv_for_eqm_sort = CharacterManager:getInstance():getTeamData():getLev()
    table.sort(tempEquipArr,eqmListSort)

    return tempEquipArr
        
end     

--寻找背包中是否有比当前装备优秀的装备
function ItemManager:findCanExcEqm(heroType,location,cur_eqm_item)

    local tempEquipArr = {}
    local backpackItemTab = self.backpackItemTab
    local allItemDataTab = self.allItemDataTab
    local tempItemMode = nil
    -- local cur_lev = cur_eqm_item.mode.limit_lev
    -- local cur_quality = cur_eqm_item.mode.quality
    local team_lv = CharacterManager:getInstance():getTeamData():getLev()

    for i,v in pairs(backpackItemTab) do
        if(v.mode.limit_stand == heroType and v.mode.item_type == location) then 
            
            --战队等级大于等于穿戴所需等级时的物品才需要校验
            if v.mode.limit_lev <= team_lv then

                if cur_eqm_item == nil then --当前未装备任何物品
                    return ItemHelper.exc_eqm_status.add 
                end

                if v.mode.limit_lev>cur_eqm_item.mode.limit_lev and v.mode.quality>cur_eqm_item.mode.quality then
                    return ItemHelper.exc_eqm_status.up 
                elseif  v.mode.limit_lev>cur_eqm_item.mode.limit_lev and v.mode.quality==cur_eqm_item.mode.quality then
                    return ItemHelper.exc_eqm_status.up 
                elseif  v.mode.limit_lev==cur_eqm_item.mode.limit_lev and v.mode.quality>cur_eqm_item.mode.quality then
                    return ItemHelper.exc_eqm_status.up 
                end
            end
        end 
    end

    return ItemHelper.exc_eqm_status.normal 
end

--检测该装备是否能升级
function ItemManager:isCanEqmUpgrade(cur_eqm_item)
    local ret = false
    if cur_eqm_item and cur_eqm_item.mode then
        ret = self:isCanEqmUpgradeByBaseId(cur_eqm_item.mode.base_id)
    end
    return ret
end

--检测该装备是否能升级(物品id)
function ItemManager:isCanEqmUpgradeByBaseId(base_id)
    local ret = false
    local err = {}
    local upgradeCostInfo = self:getEqmUpgradeInfo(base_id)
    if upgradeCostInfo ~= nil then
        local teamLev = CharacterDataProxy:getInstance():getTeamLev()
        local resNum = self:getQuantityByBaseId(upgradeCostInfo.cost_base_id)
        -- local coin = CharacterManager:getInstance():getAssetData():getGold()

        err.teamLev = teamLev >= upgradeCostInfo.team_lev
        err.resNum = resNum >= upgradeCostInfo.cost_num

        if teamLev >= upgradeCostInfo.team_lev and
            resNum >= upgradeCostInfo.cost_num 
            -- and coin >= upgradeCostInfo.coin 
            then
            ret = true
        end
    end
    return ret,err
end

--[[
两个装备比较
返回值：ItemHelper.exc_eqm_status.add
        ItemHelper.exc_eqm_status.up
        ItemHelper.exc_eqm_status.normal
--]]
function ItemManager:eqmComp(heroType, location, new_eqm_item, cur_eqm_item)

    if new_eqm_item.mode.limit_stand == heroType 
        and new_eqm_item.mode.item_type == location then 
        
        local team_lv = CharacterManager:getInstance():getTeamData():getLev()
        --战队等级大于等于穿戴所需等级时的物品才需要校验
        if new_eqm_item.mode.limit_lev <= team_lv then

            if cur_eqm_item == nil then --当前未装备任何物品
                return ItemHelper.exc_eqm_status.add 
            end

            if new_eqm_item.mode.limit_lev>cur_eqm_item.mode.limit_lev 
                and new_eqm_item.mode.quality>cur_eqm_item.mode.quality then
                return ItemHelper.exc_eqm_status.up 
            elseif  new_eqm_item.mode.limit_lev>cur_eqm_item.mode.limit_lev 
                and new_eqm_item.mode.quality==cur_eqm_item.mode.quality then
                return ItemHelper.exc_eqm_status.up 
            elseif  new_eqm_item.mode.limit_lev==cur_eqm_item.mode.limit_lev 
                and new_eqm_item.mode.quality>cur_eqm_item.mode.quality then
                return ItemHelper.exc_eqm_status.up 
            end
        end
    end 

    return ItemHelper.exc_eqm_status.normal 

end


--判断一件物品是否装备
 function ItemManager:isEqm(item_type)
    if item_type > 3 and
        item_type < 12 then
        return true
    end
    return false
end

local function sortEnchantItem(item_one, item_two)
    --按品质跟能提供的附魔能量值，从低到高
    if item_one.mode.quality~=item_two.mode.quality then
        return item_one.mode.quality<item_two.mode.quality 
    end

    return item_one.mode.enchant_energy<item_two.mode.enchant_energy 
end

--筛选出可以附魔的物品
function ItemManager:findEnchantItem()
    local tempEnchantArr = {}
    local backpackItemTab = self.backpackItemTab
    local allItemDataTab = self.allItemDataTab
    local tempItemMode = nil
    for i,v in pairs(backpackItemTab) do
        if self:isEqm(v.mode.item_type) or v.mode.enchant_energy>0 then 
            table.insert(tempEnchantArr,v)
        end 
    end

    table.sort(tempEnchantArr, sortEnchantItem)
    cclog ("可以附魔的物品個數為--------%d",#tempEnchantArr)
    return tempEnchantArr
end

--增加装备信息
function ItemManager:addEqmItem(hero_id,item_info)
    if self.equipItemTab[item_info.id] ~= nil then
        cclog("已存在該裝備資訊")
        return
    end

    local tempItem = Item:new()
    tempItem:setItemInfo(item_info.id,item_info.base_id,item_info.quantity)

    local item_eqm_info = item_info.eqm_info
    tempItem:setPoweredLev(item_eqm_info.powered_lev)
    tempItem:setEnchantLev(item_eqm_info.enchant_lev)
    tempItem:setEnchantEnergy(item_eqm_info.enchant_energy)
    --设置鉴定属性
    tempItem:setIdentifyInfo(item_eqm_info.identify_left_num,item_eqm_info.identify_lucky)
    tempItem:setIdentifyAttrs(item_eqm_info.identify_attrs)

    --更新装备的镶嵌信息
    local server_gems = item_eqm_info.gems
    local client_gems = {}
    local num = #server_gems
    
    for i=1,num do
         client_gems[server_gems[i].pos] = server_gems[i].item_base_id
    end

    tempItem:setGems(client_gems)

    tempItem:setHeroId(hero_id)
    self.equipItemTab[tempItem.id] = tempItem

    self:setEqmAttrIsChange(tempItem.id,true)

    return tempItem
end

function ItemManager:convertItemInfoToEqm(item_info)
    local tempItem = Item:new()
    tempItem:setItemInfo(item_info.id,item_info.base_id,item_info.quantity)

    local item_eqm_info = item_info.eqm_info
    tempItem:setPoweredLev(item_eqm_info.powered_lev)
    tempItem:setEnchantLev(item_eqm_info.enchant_lev)
    tempItem:setEnchantEnergy(item_eqm_info.enchant_energy)
    --设置鉴定属性
    tempItem:setIdentifyInfo(item_eqm_info.identify_left_num,item_eqm_info.identify_lucky)
    tempItem:setIdentifyAttrs(item_eqm_info.identify_attrs)

    --更新装备的镶嵌信息
    local server_gems = item_eqm_info.gems
    local client_gems = {}
    local num = #server_gems
    
    for i=1,num do
         client_gems[server_gems[i].pos] = server_gems[i].item_base_id
    end

    tempItem:setGems(client_gems)

    return tempItem
end

--增加背包中的物品
function ItemManager:setBagItem(item)
    if self.backpackItemTab[item.id] == nil then
        self.backpackItemTab[item.id] = item
        local tempTab = {}  
        tempTab[item.id] = item
        table.insert(self.backpackItemIdArr,item.id) 
        Notifier.dispatchCmd(CmdName.BACKPACK_ADD,tempTab)
    end
    
end  

--增加装备信息
function ItemManager:setEquipItem(item)
    _instance:setEqmAttrIsChange(item.id,true)
    self.equipItemTab[item.id] = item
end  

--删除装备信息
function ItemManager:delEquipItem(item)
    self.equipItemTab[item.id] = nil
end    

--通过物品ID，从装备列表中获取相应信息
function ItemManager:getEquipInfoById( itemId )
    local tempItem = self.equipItemTab[itemId]
    return tempItem
end

--通过物品ID，从装备列表中获取相应信息
function ItemManager:getOneEquipInfoByBaseId( base_id )
    local ret = nil
    for k,v in pairs(self.equipItemTab) do
        if v.mode.base_id == base_id and v.hero_id ~= 0 then
            ret = v
            break
        end
    end
    return ret
end

function ItemManager:changeDataByClient(id, base_id, quantity, change_type)

    local item = self.backpackItemTab[id]
    if change_type == ItemHelper.change_type.add then
        self:addSingleItem(id, base_id, quantity)
        cclog("增加的物品base_id~~%d~~~數量%d",base_id, quantity)
    elseif change_type == ItemHelper.change_type.sub then
        if item == nil then   
            cclog ("no item for this id")
        elseif item.quantity - quantity >0 then
            self:updateSingleItem(id, quantity)
        else 
            self:delSingleItem(id)
        end
    end
end

--读取装备表
function ItemManager:readEqmData()

    if self.isEqmRead then
        cclog ("eqmdata had already read,don't call this method again")
        return
    end

    --[[local dataFile = CCFileUtils:sharedFileUtils():fullPathForFilename("fnt_eqm_data.dat")
    local datafile_handle = io.open(dataFile, "rb")
    local pbdata = datafile_handle:read("*a")
    datafile_handle:close()--]]
    local pbdata = FileUtils.readConfigFile("fnt_eqm_data.dat")
    
    local msg = fnt_eqm_data_pb.fnt_eqm_data()
    msg:ParseFromString(pbdata)

    --读取装备品质系数
    local quality_ratio_rows = msg.quality_ratio_rows
    for i, v in pairs(quality_ratio_rows) do
        if v.quality ~= nil then
            self.quality_ratios[v.quality] = v.ratio/10000
        end 
    end

    --读取基础属性标签页的数据
    local base_attr_rows = msg.base_attr_rows
    local one_base_attr = nil
    local key = nil
    local num = 0
    for i, v in pairs(base_attr_rows) do
        one_base_attr = {}
        if v.stand ~= nil then
            key = self:getEqmAttrKey(v.stand,v.pos,v.lev,v.eqm_quality or 0)
            one_base_attr[AttrHelper.attr_flag.hp] = v.hp_max
            one_base_attr[AttrHelper.attr_flag.atk] = v.atk
            one_base_attr[AttrHelper.attr_flag.pdef] = v.pdef
            one_base_attr[AttrHelper.attr_flag.crit] = v.crit
            one_base_attr[AttrHelper.attr_flag.block] = v.block
            one_base_attr[AttrHelper.attr_flag.def_break] = v.def_break
            one_base_attr[AttrHelper.attr_flag.evasion] = v.evasion
            one_base_attr[AttrHelper.attr_flag.atk_speed] = v.atk_speed
            self.eqm_base_attrs[key] = one_base_attr
        end 
    end

    cclog ("開始強化屬性的讀取")
    --读取强化属性标签页的数据  
    local powered_attr_rows = msg.powered_attr_rows
    local one_powered_attr = nil
    for i, v in pairs(powered_attr_rows) do

        one_powered_attr = {}
        if v.stand ~= nil then
            key = self:getPoweredAttrKey(v.stand,v.pos)
            one_powered_attr[AttrHelper.attr_flag.hp] = tonumber(v.hp_max)
            one_powered_attr[AttrHelper.attr_flag.atk] = tonumber(v.atk)
            one_powered_attr[AttrHelper.attr_flag.pdef] = tonumber(v.pdef)
            one_powered_attr[AttrHelper.attr_flag.crit] = tonumber(v.crit)
            one_powered_attr[AttrHelper.attr_flag.block] =tonumber(v.block)
            one_powered_attr[AttrHelper.attr_flag.def_break] = tonumber(v.def_break)
            one_powered_attr[AttrHelper.attr_flag.evasion] = tonumber(v.evasion)
            one_powered_attr[AttrHelper.attr_flag.atk_speed] = tonumber(v.atk_speed)
            self.eqm_powered_attrs[key] = one_powered_attr   
        end
    end

    --时装 强化
    local f_powered_attr_rows = msg.f_powered_attr_rows
    for k,v in pairs(f_powered_attr_rows) do
        if v.pos ~= nil then
            one_powered_attr = {}
            key = self:getPoweredAttrKey(v.pos,v.hero_id)
            one_powered_attr[AttrHelper.attr_flag.hp] = tonumber(v.hp_max)
            one_powered_attr[AttrHelper.attr_flag.atk] = tonumber(v.atk)
            one_powered_attr[AttrHelper.attr_flag.pdef] = tonumber(v.pdef)
            one_powered_attr[AttrHelper.attr_flag.crit] = tonumber(v.crit)
            one_powered_attr[AttrHelper.attr_flag.block] =tonumber(v.block)
            one_powered_attr[AttrHelper.attr_flag.def_break] = tonumber(v.def_break)
            one_powered_attr[AttrHelper.attr_flag.evasion] = tonumber(v.evasion)
            one_powered_attr[AttrHelper.attr_flag.atk_speed] = tonumber(v.atk_speed)
            self.fashion_powered_attrs[key] = one_powered_attr 
        end
    end

    --时装附魔属性
    local f_enchant_base_attr_rows = msg.f_enchant_base_attr_rows
    for k,v in pairs(f_enchant_base_attr_rows) do
        if v.base_id ~= nil then
            local one_enchant_attr = {}
            one_enchant_attr[AttrHelper.attr_flag.hp] = tonumber(v.hp_max)
            one_enchant_attr[AttrHelper.attr_flag.atk] = tonumber(v.atk)
            one_enchant_attr[AttrHelper.attr_flag.pdef] = tonumber(v.pdef)
            one_enchant_attr[AttrHelper.attr_flag.crit] = tonumber(v.crit)
            one_enchant_attr[AttrHelper.attr_flag.block] =tonumber(v.block)
            one_enchant_attr[AttrHelper.attr_flag.def_break] = tonumber(v.def_break)
            one_enchant_attr[AttrHelper.attr_flag.evasion] = tonumber(v.evasion)
            one_enchant_attr[AttrHelper.attr_flag.atk_speed] = tonumber(v.atk_speed)
            self.fashion_enchant_attrs[ v.base_id.."_"..v.pos ] = one_enchant_attr
        end
    end

    --读取强化消耗表
    local powered_cost_rows = msg.powered_cost_rows
    local one_powered_cost = nil
    for i, v in pairs(powered_cost_rows) do
        one_powered_cost = {}
        if v.lev ~= nil then
            one_powered_cost[1] = v.team_lev
            one_powered_cost[2] = v.cost_coin
            self.eqm_powered_cost[v.lev] = one_powered_cost 
        end
    end

    --附魔成长系数
    local enchant_attr_rows = msg.enchant_attr_rows
    for i, v in pairs(enchant_attr_rows) do
        if v.lev ~= nil then
            self.eqm_enchant_attr[v.lev] = v.ratio/10000
        end
    end

    --附魔消耗
    local enchant_cost_rows = msg.enchant_cost_rows
    local one_enchant_cost = nil
    for i, v in pairs(enchant_cost_rows) do
        if v.lev ~= nil then
            one_enchant_cost = {}
            one_enchant_cost.team_lev = v.team_lev
            one_enchant_cost.cost_energy = v.cost_energy
            self.eqm_enchant_cost[v.lev] = one_enchant_cost 
            -- cclog ("附魔等級為%d,所需戰隊等級為:%d，所需能量為：%d",v.lev,v.team_lev, v.cost_energy) 
        end
    end

    --读取鉴定消耗表
    local identify_cost_rows = msg.identify_cost_rows
    local one_identify_cost 
       for i, v in pairs(identify_cost_rows) do
        if v.time ~= nil then
            one_identify_cost = {}
            one_identify_cost.time = v.time
            one_identify_cost.cost_diamond = v.cost_diamond
            one_identify_cost.cost_coin = v.cost_coin
            self.eqm_identify_cost[v.time] = one_identify_cost 
        end
    end

    --读取装备属性锁定消耗表
    local identify_lock_cost_rows = msg.identify_lock_cost_rows
    local one_identify_lock_cost
        for i, v in pairs(identify_lock_cost_rows) do
            if v.lock_num ~= nil then
                one_identify_lock_cost = {}
                one_identify_lock_cost.lock_num = v.lock_num
                one_identify_lock_cost.addt_diamond = v.addt_diamond
                self.eqm_identify_lock_cost[v.lock_num] = one_identify_lock_cost 
        end
    end




    --读取装备升级消耗表
    local upgrade_cost_rows = msg.upgrade_cost_rows
    for k,v in pairs(upgrade_cost_rows) do
       if v.base_id ~= nil then
            local one_upgrade_cost = {}
            one_upgrade_cost.base_id = v.base_id
            one_upgrade_cost.team_lev = v.team_lev
            one_upgrade_cost.target_base_id = v.target_base_id
            one_upgrade_cost.cost_base_id = v.cost_base_id
            one_upgrade_cost.cost_num = v.cost_num
            one_upgrade_cost.coin = v.coin
            self.eqm_upgrade_cost[ v.base_id ] = one_upgrade_cost
            self.eqm_upgrade_cost_res[ v.cost_base_id ] = self.eqm_upgrade_cost_res[ v.cost_base_id ] or {}
            table.insert( self.eqm_upgrade_cost_res[ v.cost_base_id ] , one_upgrade_cost )
       end
    end

    --读取重置鉴定消耗表
    local identify_reset_cost_rows = msg.identify_reset_cost_rows
    for k,v in pairs(identify_reset_cost_rows) do
        if v.base_id ~= nil then
            local one_identify_reset_cost = {}
            one_identify_reset_cost.base_id = v.base_id
            one_identify_reset_cost.piece_num = v.piece_num
            self.eqm_identify_reset_cost[ v.base_id ] = one_identify_reset_cost
        end
    end
    --时装 重置鉴定消耗
    local f_identify_reset_cost_rows = msg.f_identify_reset_cost_rows
    for k,v in pairs(f_identify_reset_cost_rows) do
        if v.hero_id ~= nil then
            local one_identify_reset_cost = {}
            one_identify_reset_cost.pos = v.pos
            one_identify_reset_cost.hero_id = v.hero_id
            one_identify_reset_cost.piece_num = v.piece_num
            self.fashion_identify_reset_cost[ v.hero_id.."_"..v.pos ] = one_identify_reset_cost
        end
    end

    --读取鉴定幸运值
    local identify_lucky_rows = msg.identify_lucky_rows
    for k,v in pairs(identify_lucky_rows) do
        if v.lucky ~= nil then
            local one_identify_lucky = {}
            one_identify_lucky.lucky = v.lucky
            one_identify_lucky.item_lev = v.item_lev
            one_identify_lucky.min_stars = v.min_stars
            self.eqm_identify_lucky_list[ v.lucky ] = self.eqm_identify_lucky_list[ v.lucky ] or {} 
            self.eqm_identify_lucky_list[ v.lucky ][ v.item_lev ] = one_identify_lucky
        end
    end

    --时装 鉴定幸运值
    local f_identify_lucky_rows = msg.f_identify_lucky_rows
    for k,v in pairs(f_identify_lucky_rows) do
        if v.lucky ~= nil then
            local one_identify_lucky = {}
            one_identify_lucky.lucky = v.lucky
            one_identify_lucky.max_stars = v.max_stars
            one_identify_lucky.min_stars = v.min_stars
            self.fashion_identify_lucky_list[ v.lucky ] = one_identify_lucky
        end
    end

    --附魔套 附加属性
    for _,v in pairs(msg.enchant_suit_attr_rows) do
        if v.enchant_suit_lv then
            self.enchant_suit_attr[v.enchant_suit_lv] = self.enchant_suit_attr[v.enchant_suit_lv] or {}
            self.enchant_suit_attr[v.enchant_suit_lv][v.attr_id] = v.attr_value
        end
    end

   self.isEqmRead =true
end

--[[
@param stand 英雄站位
@param pos 装备部位
@param lev 装备等级
--]]
function ItemManager:getEqmAttrKey(stand,pos,lev,eqm_quality)
    local key = string.format("%d_%d_%d_%d",stand,pos,lev,eqm_quality)
    return key
end

--[[
@param stand 英雄站位
@param pos 装备部位
--]]
function ItemManager:getPoweredAttrKey(stand,pos)
    local key = string.format("%d_%d",stand,pos)
    return key
end

--获取装备基础属性
function ItemManager:getEqmBaseAttr(base_id)
    local item_mode = self:getItemModelByBaseId(base_id)
    local key = self:getEqmAttrKey(item_mode.limit_stand,item_mode.item_type,item_mode.limit_lev,item_mode.eqm_quality) 
    
    return self.eqm_base_attrs[key] 
end

--获取装备强化成长系数
function ItemManager:getEqmPoweredRatio(base_id)
    local item_mode = ItemManager:getInstance():getItemModelByBaseId(base_id)
    local key = ItemManager:getInstance():getPoweredAttrKey(item_mode.limit_stand,item_mode.item_type) 
    return ItemManager:getInstance().eqm_powered_attrs[key] 
end

function ItemManager:getFashionPoweredRatio(hero_id,pos)
    local key = ItemManager:getInstance():getPoweredAttrKey(pos,hero_id) 
    return ItemManager:getInstance().fashion_powered_attrs[key]
end

function ItemManager:getFashionEnchantAttr(hero_id,pos)
    local ret = {}
    for k,v in pairs(self.fashion_enchant_attrs[ hero_id.."_"..pos ]) do
        if v > 0 then
            ret[k] = v
        end
     end 
    return ret
end
    
--获取某id装备的在某强化等级下的具体数值
function ItemManager:getEqmPoweredAttr(base_id,powered_lv)
    local temp_attrs = {}  
    local attrs = self:getEqmPoweredRatio(base_id)

    for flag,value in pairs(attrs) do
        temp_attrs[flag] = value * powered_lv
    end
    return temp_attrs
end

function ItemManager:getFashionPoweredAttr(heroId,pos,powered_lv)
    local temp_attrs = {}  
    local attrs = self:getFashionPoweredRatio(heroId,pos)

    for flag,value in pairs(attrs) do
        temp_attrs[flag] = value * powered_lv
    end
    return temp_attrs
end

--获取装备升级 配置数据
function ItemManager:getEqmUpgradeInfo(base_id)
    return self.eqm_upgrade_cost[ base_id ]
end

--获取装备鉴定重置消耗 配置数据
function ItemManager:getEqmIdentifyResetInfo(base_id)
    return self.eqm_identify_reset_cost[ base_id ]
end

--获取时装鉴定重置消耗 配置数据
function ItemManager:getFashionIdentifyResetInfo(hero_id,location)
    return self.fashion_identify_reset_cost[ hero_id.."_"..location ]
end

--获取装备鉴定幸运配置
function ItemManager:getEqmIdentifyLuckyInfo(lucky,item_lev,item_type)
    local equipType = ItemHelper:getEquipTypeWithItemType(item_type)
    local ret = nil
    if equipType == ItemHelper.equipType.equip then
        ret = self.eqm_identify_lucky_list[lucky][item_lev]
    elseif equipType == ItemHelper.equipType.fashion then
        ret = self.fashion_identify_lucky_list[lucky]
    end
    return ret
end

--获取装备升级 配置数据(根据材料id) 返回匹配列表
function ItemManager:getEqmUpgradeInfoByResId(res_id)
    return self.eqm_upgrade_cost_res[ res_id ]
end

function ItemManager:getEqmBaseAttrAddQuality(base_id , is_ceil_value )
    local is_ceil = true

    if is_ceil_value==false then
        is_ceil = is_ceil_value
    end

    local attrs = {}
    local item_mode = self:getItemModelByBaseId(base_id)
    local key = self:getEqmAttrKey(item_mode.limit_stand,item_mode.item_type,item_mode.limit_lev,item_mode.eqm_quality) 
    local base_attrs = self.eqm_base_attrs[key] 
    local quality_ratio = self:getQualityRatio(item_mode.quality)  --品质系数 
    for flag,value in pairs(base_attrs) do
        attrs[flag] = value*quality_ratio
    end

    --向上取整
    if is_ceil then
        for flag,value in pairs(attrs) do
            attrs[flag] = math.ceil(value)
        end
    end
    return attrs
end

--通过装备ID获取该装备的总属性(基础属性+强化+附魔+鉴定+镶嵌)
function ItemManager:getEqmFinalAttrById(id, gem_suit_lv)
    --装备属性计算公式：(基础属性*品质系数+强化属性)*(1+附魔万分比/10000)+鉴定属性+宝石属性

    --cclog("獲取裝備總屬性11111111111111")

    -- if self.eqm_attr_ischange[id] == false then
    --     --cclog("獲取裝備總屬性222222222222")
    --     return self.eqm_final_attrs[id]
    -- end

    --宝石套的存在，其它宝石改变了，会导致其它装备宝石也改变
    -- if self.eqm_attr_ischange[id] == false then
    -- 	return self.eqm_final_attrs[id]
    -- end
    local gem_suit_lv = gem_suit_lv or 0
    local gem_suit_add_ratio = self:getGemSuitRationByLv(gem_suit_lv)
    -- local gem_suit_add_ratio = 0
    local attrs = {}
    local item = self:getEquipInfoById(id)
    --计算品质系数后
    attrs = self:getEqmBaseAttrAddQuality(item.mode.base_id, false)

    -- local base_attrs = self:getEqmBaseAttr(item.mode.base_id)
    -- local quality_ratio = self:getQualityRatio(item.mode.quality)  --品质系数 
    -- for flag,value in pairs(base_attrs) do
    --     attrs[flag] = value*quality_ratio
    --     cclog ("原始值%f---計算品質係數後%f",value,attrs[flag])
    -- end

    --强化属性
    local powered_atrrs = self:getEqmPoweredAttr(item.mode.base_id,item.powered_lev)
    for flag,value in pairs(powered_atrrs) do
        if attrs[flag] > 0 and value >0 then
            attrs[flag] =  attrs[flag] + value
           -- cclog ("原始值%f---計算計算強化後%f",value,attrs[flag])
        end
    end

    --附魔
    local enchant_ratio = self:getEnchantRation(item.enchant_lev) -- 附魔系数
     for flag,value in pairs(attrs) do
        if value>0 then
            attrs[flag] = value*(1+enchant_ratio)
         --   cclog ("原始值%f---附魔後%f",value,attrs[flag])
        end
    end


    --鉴定属性
    local identify_attrs = item.identify_attrs
     for _,attrvo in pairs(identify_attrs) do
        if attrs[attrvo.flag]~=nil then
            attrs[attrvo.flag] =  attrs[attrvo.flag] + attrvo.value
        else
            attrs[attrvo.flag] = attrvo.value
        end
       -- cclog ("鑒定值的類型%d---具體%f",attrvo.flag,attrvo.value)
    end

    --宝石附加属性
    local gems = item.gems
    local gem_item_mode = nil
    local gem_info 
    for _,base_id in pairs(gems) do
        gem_info = self:getGemInfo(base_id)
        if attrs[gem_info.attr_type]~=nil then
            attrs[gem_info.attr_type] =  attrs[gem_info.attr_type] + (gem_info.val*(1+gem_suit_add_ratio))
        else
            attrs[gem_info.attr_type] = gem_info.val*(1+gem_suit_add_ratio)
        end
    end

    --对物品属性做向上取整处理
    -- for flag,value in pairs(attrs) do
    --     attrs[flag] = math.ceil(value)
    -- end
    self:setEqmAttrIsChange(id,false)
    self.eqm_final_attrs[id] = attrs
    return attrs
end

--通过装备数据获取属性
-- function ItemManager:getEqmFinalAttr(eqm_item)
--     --装备属性计算公式：(基础属性*品质系数+强化属性)*(1+附魔万分比/10000)+鉴定属性+宝石属性
--     local attrs = {}
--     local item = eqm_item
--     local base_attrs = self:getEqmBaseAttr(item.mode.base_id)
--     local quality_ratio = self:getQualityRatio(item.mode.quality)  --品质系数 
--     for flag,value in pairs(base_attrs) do
--         if value >0 then
--             attrs[flag] = value*quality_ratio
--             cclog ("原始值%f---計算品質係數後%f",value,attrs[flag])
--         end
--     end

--     --强化属性
--     local powered_atrrs = self:getEqmPoweredAttr(item.mode.base_id,item.powered_lev)
--     for flag,value in pairs(powered_atrrs) do
--         if attrs[flag] > 0 and value >0 then
--             attrs[flag] =  attrs[flag] + value
--             cclog ("原始值%f---計算計算強化後%f",value,attrs[flag])
--         end
--     end

--     --附魔
--     local enchant_ratio = self:getEnchantRation(item.enchant_lev) -- 附魔系数
--      for flag,value in pairs(attrs) do
--         if value>0 then
--             attrs[flag] = value*(1+enchant_ratio)
--             cclog ("原始值%f---附魔後%f",value,attrs[flag])
--         end
--     end

--     --鉴定属性
--     local identify_attrs = item.identify_attrs
--      for _,attrvo in pairs(identify_attrs) do
--         if attrs[attrvo.flag]~=nil then
--             attrs[attrvo.flag] =  attrs[attrvo.flag] + attrvo.value
--         else
--             attrs[attrvo.flag] = attrvo.value
--         end
--         cclog ("鑒定值的類型%d---具體%f",attrvo.flag,attrvo.value)
--     end

--     --宝石附加属性
--     local gems = item.gems
--     local gem_item_mode = nil
--     local gem_info 
--     for _,base_id in pairs(gems) do
--         gem_info = self:getGemInfo(base_id)
--         if attrs[gem_info.attr_type]~=nil then
--             attrs[gem_info.attr_type] =  attrs[gem_info.attr_type] + gem_info.val
--         else
--             attrs[gem_info.attr_type] = gem_info.val
--         end
--         cclog ("寶石類型%d---具體%f",gem_info.attr_type,gem_info.val)
--     end

--     return attrs
-- end

--通过装备强化等级获取所消耗金币
function ItemManager:getPoweredCostCoin(lev)
    local cost = self.eqm_powered_cost[lev]

    if cost == nil then 
        return 0
    end

    return cost[2]
end

--通过装备强化等级获取所需要的战队等级
function ItemManager:getPoweredTeamLv(lev)
    return self.eqm_powered_cost[lev][1]
end

--锻造界面的物品排序
local hero_2_pos = nil
local function sortEqmForExcView(eqm_item_one, eqm_item_two)
    --前中后，数值越小越前
    if eqm_item_one.mode.limit_stand<eqm_item_two.mode.limit_stand then
        return true
    elseif eqm_item_one.mode.limit_stand>eqm_item_two.mode.limit_stand then
        return false
    end

    if hero_2_pos[eqm_item_one.hero_id]>hero_2_pos[eqm_item_two.hero_id] then
        return true
    elseif hero_2_pos[eqm_item_one.hero_id]<hero_2_pos[eqm_item_two.hero_id] then
        return false
    end

    --装备所属英雄类型同样时，按物品类型先后排
    if eqm_item_one.mode.item_type<eqm_item_two.mode.item_type then
        return true
    else
        return false
    end

end

--通过站位，从装备列表中筛选合适物品
function ItemManager:getEqmByPos(pos)
    local eqm_arr = {}

    for id,item in pairs(self.equipItemTab) do
        if (item.mode.limit_stand == pos or 
            ItemHelper.limitStand.Unlimit == pos) 
            and item.hero_id>0 then --该部位没有上阵英雄则不显示该装备
            table.insert(eqm_arr,item)
        end
    end

    hero_2_pos = TeamManager:getInstance():transHero2posList(TeamType.Normal)

    table.sort(eqm_arr, sortEqmForExcView)

    return eqm_arr
end

--通过附魔等级获取相应成长系数
function ItemManager:getEnchantRation(lev)
    local ration = self.eqm_enchant_attr[lev]
    if ration == nil then 
        return 0
    else
        return self.eqm_enchant_attr[lev]
    end
end

--通过附魔等级获取所需能量值
function ItemManager:getEnchantEnergyCost(lev)
    local one_enchant_cost = self.eqm_enchant_cost[lev]
    if one_enchant_cost ~=nil then
        return one_enchant_cost.cost_energy
    end   
    return 0
end

--通过附魔等级获取所要求的战队等级
function ItemManager:getEnchantTeamLv(lev)
    local one_enchant_cost = self.eqm_enchant_cost[lev]
    if one_enchant_cost ~=nil then
        return one_enchant_cost.team_lev
    end   
    return nil
end

--根据鉴定次数返回能量
local function getExtEnchantEnergy(num)
    if num == 1 then
        return 0
    elseif num == 2 then
        return 50 / 2
    elseif num == 3 then
        return 150 / 2
    elseif num == 4 then
        return 300 / 2
    elseif num == 5 then
        return 500 / 2
    end
    return 0
end

--当前物品是否可以鉴定
function ItemManager:canIdentify(item)
    if item.mode.quality<ItemHelper.itemQuality.Purple then
        return false
    else
        return true
    end
end

--获取物品所能提供的附魔能量值
function ItemManager:getEnchantEnergy(id)
    local item = self:getItemById(id)
    if self:isEqm(item.mode.item_type) then
        identify_left_num = item.identify_left_num
        if self:canIdentify(item) == false then --判断是否可以鉴定的装备，
            identify_left_num = 5
        end
        return item.mode.enchant_energy + getExtEnchantEnergy(5-identify_left_num)  --所有装备暂时默认提供一点
    else
        return item.mode.enchant_energy -- 附魔能量
    end
end

--根据装备品质获取相应成长系数
function ItemManager:getQualityRatio(quality)
    return self.quality_ratios[quality]
    -- if quality == ItemHelper.itemQuality.White then
    --     return 1
    -- elseif quality == ItemHelper.itemQuality.Green then
    --     return 1.3
    -- elseif quality == ItemHelper.itemQuality.Blue then
    --     return 1.7
    -- elseif quality == ItemHelper.itemQuality.Purple then
    --     return 2.2
    -- elseif quality == ItemHelper.itemQuality.Orange then
    --     return 2.7
    -- else 
    --     cclog ("找不到相應品質")
    --     return 1
    -- end             
end

--根据鉴定次数返回相应消耗
function ItemManager:getIdentifyCostByTime(time)
    return self.eqm_identify_cost[time]
end

--根据锁定的属性数量返回相应的消耗
function ItemManager:getIdentifyLockCostByNum(num)
    if num > 0 then
        return self.eqm_identify_lock_cost[num]
        else
            return nil
    end
end

local function gemListSort(item_one, item_two)
    -- local item_one = _instance:getItemById(id_one) or _instance:getEquipInfoById(id_one)
    -- local item_two = _instance:getItemById(id_two) or _instance:getEquipInfoById(id_two)
    local gem_info_one = ItemManager:getInstance():getGemInfo(item_one.mode.base_id)
    local gem_info_two = ItemManager:getInstance():getGemInfo(item_two.mode.base_id)

    if item_one == nil or item_two == nil then
        return false
    end

    return gem_info_one.gem_lev > gem_info_two.gem_lev

end

--[[
查找可以镶嵌的宝石
@param gem_types 可以镶嵌的宝石类型
--]]
function ItemManager:findGemItems(gem_types)
    local gem_type_one = gem_types[1] or -1
    local gem_type_two = gem_types[2] or -1
    local gem_type_three = gem_types[3] or -1

    local backpack_items = self.backpackItemTab
    local gem_items = {}
    local gem_info = nil
    for i,item in pairs(backpack_items) do
        if item.mode.item_type == ItemHelper.itemType.Inlay then
            gem_info = self:getGemInfo( item.mode.base_id)

            if  gem_info.gem_type == gem_type_one or
                gem_info.gem_type == gem_type_two or
                gem_info.gem_type == gem_type_three then 
                table.insert(gem_items, item)
            end
        end 
    end    

    table.sort(gem_items,gemListSort)

    return gem_items
end

--读取宝石相关数据
function ItemManager:readGemData()
    if self.isGemDataRead then
        --cclog ("gemdata had already read,don't call this method again")
        return
    end

    --[[local dataFile = CCFileUtils:sharedFileUtils():fullPathForFilename("fnt_gem_data.dat")
    local datafile_handle = io.open(dataFile, "rb")
    local pbdata = datafile_handle:read("*a")
    datafile_handle:close()--]]
    
    local pbdata = Global:getAssetFileData("fnt_gem_data.dat", "rb")
    
    local msg = fnt_gem_data_pb.fnt_gem_data()
    msg:ParseFromString(pbdata)

    --宝石基础信息
    local gem_info_rows = msg.gem_info_rows
    local gem_one_data = nil

    for i, v in pairs(gem_info_rows) do
        if v.base_id~=nil then 
            gem_one_data = GemInfo.new()
            gem_one_data.base_id = v.base_id
            gem_one_data.gem_lev = v.gem_lev
            gem_one_data.gem_type = v.gem_type
            gem_one_data.attr_type = v.attr_type
            gem_one_data.val = v.val
            gem_one_data.enegry = v.enegry
            self.gem_info_tab[gem_one_data.base_id] = gem_one_data
        end
    end

    --宝石升级所需能量
    local gem_upgrade_rows = msg.gem_upgrade_rows
    for i, v in pairs(gem_upgrade_rows) do
        if v.gem_lev~=nil then 
            self.gem_upgrade_tab[v.gem_lev] = v.energy
        end
    end

     self.isGemDataRead = true


    --宝石套相应数据
    self._gemSuitDataDict = {}
    local gem_suit_add_rows = msg.gem_suit_add_rows
    local gem_suit_info_one 
    for i,v in pairs(gem_suit_add_rows) do
        if v.gem_lev then
            self._gemSuitDataDict[v.gem_lev] = v.add_ratio/10000
        end
    end
    --宝石套 附加属性
    for _,v in pairs(msg.gem_suit_rare_attr_rows) do
        if v.gem_suit then
            self.eqm_suit_attr_list[v.gem_suit] = self.eqm_suit_attr_list[v.gem_suit] or {}
            self.eqm_suit_attr_list[v.gem_suit][v.attr_id] = v.attr_value
        end
    end
end

--通过宝石套等级获取万分比加成
function ItemManager:getGemSuitRationByLv(gem_suit_lv)
    local add_ration = self._gemSuitDataDict[gem_suit_lv]
    if add_ration==nil then
        return 0
    end
    return add_ration
end

--判断是否有足够的宝石能量升级
function ItemManager:isEnoughGemEnergy(gem_base_id)
    local gem_info = self:getGemInfo(gem_base_id)

    --如果已经是最高级的宝石
    if gem_info.gem_lev == 20 then
        return false
    end

    local item_mode = self:getItemModelByBaseId(gem_base_id)
    local temp_gem_info = nil
    local backpack_items = self.backpackItemTab
    local need_energy =  self.gem_upgrade_tab[gem_info.gem_lev+1] - gem_info.enegry  -- 升级需要的能量
    local temp_energy = 0

    --从背包中筛选
    for id,temp_item in pairs(backpack_items) do
        if temp_item.mode.item_type == ItemHelper.itemType.Inlay then
            temp_gem_info = self:getGemInfo(temp_item.mode.base_id)
            if temp_gem_info.gem_lev <= gem_info.gem_lev and 
               temp_gem_info.gem_type == gem_info.gem_type then
                temp_energy = temp_energy + temp_gem_info.enegry*temp_item.quantity
            end
        end
    end

    if temp_energy < need_energy then
        return false
    else
        return true
    end
end

--返回宝石数据
function ItemManager:getGemInfo(gem_base_id)
    return  self.gem_info_tab[gem_base_id]
end

function ItemManager:setEqmAttrIsChange(item_id, is_change)
    --cclog("物品ID~~~%d",item_id)
    self.eqm_attr_ischange[item_id] = is_change
end

function ItemManager:resetAllEqmAttrIsChange()
    for item_id, is_change in pairs(self.eqm_attr_ischange) do
        self.eqm_attr_ischange[item_id] = true
    end
end

function ItemManager:getEqmAttrIsChange(item_id)
    return self.eqm_attr_ischange[item_id] or false
end

--[[
发送物品使用请求
@param use_type 发送类型，1表示ID，2表示基础ID
@param item_id 物品ID
@param quantity 物品数量 
@param target_id 目标ID（>0:英雄ID, =0:战队）
--]]
local use_item_base_id = 0
local is_send_batch = false
function ItemManager:sendItemUseReq(use_type, item_id, quantity, target_id)
    
    if use_type ==1 then
        if self.backpackItemTab[item_id] then
            use_item_base_id = self:getItemModleById(item_id).base_id
        else
            Alert:show("物品不足")
            return false
        end
    else
        use_item_base_id = item_id
    end

    if quantity>1 then
        is_send_batch = true
    else
        is_send_batch = false
    end

    local bag_use_item_req = bag_pb.bag_use_item_req()
    bag_use_item_req.use_type = use_type
    bag_use_item_req.item_id = item_id
    bag_use_item_req.quantity = quantity
    bag_use_item_req.target_id = target_id
    ComSender:getInstance():send(proto_cmd_pb.msg_cmd.bag_use_item_req,bag_use_item_req)
end

function onGetItemUseRsp(pbPkgData)
    local  bag_use_item_rsp = bag_pb.bag_use_item_rsp()
    bag_use_item_rsp:ParseFromString(pbPkgData)

    if bag_use_item_rsp.ret ~= error_code_pb.msg_ret.success then
         -- Alert:show(string.format("使用物品失敗%d",bag_use_item_rsp.ret))
        if bag_use_item_rsp.ret == error_code_pb.msg_ret.err_not_enough_team_lev then
             Alert:show("英雄等級不能超過戰隊等級，請努力提升戰隊等級哦。")
        else
             Alert:show(Helper.getErrStr(bag_use_item_rsp.ret))
        end
        
        return
    end

    --更新/删除背包物品
    ItemManager:getInstance():updateOrDelMultiItems(bag_use_item_rsp.items)

    --如果是对英雄使用的，更新相应英雄信息
    local temp_hero = bag_use_item_rsp.hero
    if temp_hero and temp_hero.id>0 then
        cclog("英雄~~id~~%d",temp_hero.id)
        local old_lev = HeroManager:getInstance():getHeroInfoByBaseId(temp_hero.id).cur_lev

        if is_send_batch==false then  --如果是单个喂养的，才需要播放特效
            local exp_params = {}
            exp_params.hero_id = temp_hero.id
            if temp_hero.lev>old_lev then -- 升级
                exp_params.play_type =1 
                Notifier.dispatchCmd(CmdName.HeroAddExpSuc,exp_params)
            else --没升级，只是增加经验
                exp_params.play_type =2 
                Notifier.dispatchCmd(CmdName.HeroAddExpSuc,exp_params)
            end
        end

        HeroManager:getInstance():updateHeroInfoByClient(temp_hero.id, temp_hero.lev, 
                                                        temp_hero.exp, temp_hero.stars, temp_hero.pos_models, temp_hero.models)
    end

    --更新资产
    if bag_use_item_rsp.assets then
        CharacterManager:getInstance():updateRoleAssets(bag_use_item_rsp.assets)
    end

    if use_item_base_id == 40011 then
         Alert:show("增加技能點成功")
    else
        -- Alert:show("使用經驗藥成功")
    end

    Notifier.dispatchCmd(CmdName.UseItemSuccess,use_item_base_id)

    --礼包使用
    if bag_use_item_rsp.gain_items and #bag_use_item_rsp.gain_items > 0 then

        local mode = ItemManager:getInstance():getItemModelByBaseId(use_item_base_id)
        WindowCtrl:getInstance():open(CmdName.Reward_MuilItemPanel,
            {reward_list = bag_use_item_rsp.gain_items,
             reward_title = mode.name})

        ItemManager:getInstance():addMultiItem(bag_use_item_rsp.gain_items)  --更新背包 
    end

    WindowCtrl:getInstance():close(CmdName.BatchUseItemView)
    WindowCtrl:getInstance():close(CmdName.Reward_MultGiftPanel)
    WindowCtrl:getInstance():close(CmdName.GetSkillPointView)
    ComSender:getInstance():dealExtInfo(bag_use_item_rsp.ext)
end

--通过物品base_id从背包中统计出总数量
function ItemManager:getQuantityByBaseId(base_id)
    local backpack_items = self.backpackItemTab
    local total_quantity = 0
    for id,item in pairs(backpack_items) do
        if item.mode.base_id == base_id then
          total_quantity = total_quantity+item.quantity
        end
    end

    return total_quantity
end

--选择某件装备可以附魔
--附魔等级越低的优先级越高
function ItemManager:getFitEqmToEnchant()
    local item_id = 0
    local min_enchant_lv = 100
    local all_eqms = self.equipItemTab
    for id,eqm_item in pairs(all_eqms) do
        if eqm_item.enchant_lev<min_enchant_lv and 
            TeamManager:getInstance():isHeroInBattle(eqm_item.hero_id)>0  then
            min_enchant_lv = eqm_item.enchant_lev
            item_id = id
        end
    end

    return all_eqms[item_id]
end

--选择某件装备可以镶嵌
--宝石孔空的装备优先
function ItemManager:getFitEqmToGem(base_id)
    local item_id = 0
    local gem_info = self:getGemInfo(base_id)
    local temp_gem_info = nil
    local all_eqms = self.equipItemTab
    local temp_gems = nil
    local has_same_gem = false
    local min_gem_lev = 100
    for id,eqm_item in pairs(all_eqms) do
        temp_gems = eqm_item.gems
        has_same_gem = false

        if TeamManager:getInstance():isHeroInBattle(eqm_item.hero_id)>0 then
            for gem_pos,gem_base_id in pairs(temp_gems) do
                temp_gem_info = self:getGemInfo(gem_base_id)
                if temp_gem_info.gem_type == gem_info.gem_type then
                    has_same_gem = true

                    if min_gem_lev>temp_gem_info.gem_lev then
                        min_gem_lev = temp_gem_info.gem_lev
                        item_id = id
                    end
                end
            end

            --还没有该类型的宝石
            if has_same_gem == false then
                item_id = id
                break
            end
        end
    end

    return all_eqms[item_id]
end

--选择某件装备可以强化
--强化等级越低的优先级越高
function ItemManager:getFitEqmToPowered()
    local item_id = 0
    local min_powered_lv = 100
    local all_eqms = self.equipItemTab
    for id,eqm_item in pairs(all_eqms) do
        if eqm_item.hero_id>0 and
         eqm_item.powered_lev<min_powered_lv and 
        TeamManager:getInstance():isHeroInBattle(eqm_item.hero_id)>0 then
            min_powered_lv = eqm_item.powered_lev
            item_id = id
        end
    end

    return all_eqms[item_id]
end

--选择某件装备可以鉴定
--鉴定剩余次数越多的优先级越高
function ItemManager:getFitEqmToIdentity()
    local item_id = 0
    local max_left_num = -1
    local all_eqms = self.equipItemTab
    for id,eqm_item in pairs(all_eqms) do
        if self:canIdentify(eqm_item) and 
            eqm_item.identify_left_num>max_left_num and 
            TeamManager:getInstance():isHeroInBattle(eqm_item.hero_id)>0 then
            max_left_num = eqm_item.identify_left_num
            item_id = id
        end
    end

    return all_eqms[item_id]
end


function ItemManager:getAllBagItems()
    return self.backpackItemTab
end

--获取灵魂石数量
function ItemManager:getSoulStoneNum(base_id)
    if self.soul_stone_nums[base_id]==nil then
        self.soul_stone_nums[base_id] = 0
    end

    return self.soul_stone_nums[base_id]
end

--判断是否有装备
function ItemManager:hasEqm()
    return Utils.get_length_from_any_table(self.equipItemTab)>0
end

--[[
判断角色身上所有装备是否进行过某些操作
@params event_type 操作类型
--]]
function ItemManager:eqmHasDoSth(event_type)
    local eqm_arr = self.equipItemTab
    for i,v in pairs(eqm_arr) do
        if event_type==HeroHelper.forgePanelType.powered then -- 强化
            if v.powered_lev>0 then
                return true
            end
        elseif event_type==HeroHelper.forgePanelType.enchant then --附魔
            if v.enchant_lev>0 then
                return true
            end
        elseif event_type==HeroHelper.forgePanelType.identify then --鉴定
            if #v.identify_attrs>0 then --有鉴定属性，则说明鉴定过
                return true
            end
        elseif event_type==HeroHelper.forgePanelType.gem then --镶嵌
            if #v.gems>0 then --有镶嵌过
                return true
            end
        end    
    end
    return false
end

--按baseid区分物品段落，数值越大越靠前
local function itemBaseIdPart(base_id)
    if base_id>=100000 and base_id<=109999 then
        return 500
    elseif base_id>=40000 and base_id<=40999 then
        return 400
    elseif base_id>=44000 and base_id<=44999 then
        return 300
    elseif base_id>=10000 and base_id<=39999 then
        return 200
    else
         return 100
    end
end

function ItemManager:bagItemsSort(item_id_one, item_id_two)
    local item_one = self:getItemById(item_id_one)
    local item_two = self:getItemById(item_id_two)
    local lev_one = itemBaseIdPart(item_one.mode.base_id )
    local lev_two = itemBaseIdPart(item_two.mode.base_id )

    if lev_one~=lev_two then
        return lev_one>lev_two
    end

    --相同baseid段落的，按照baseid从小到大排序
    return item_one.mode.base_id<item_two.mode.base_id

end

-- 发送批量强化请求
function ItemManager:sendBatchPoweredReq(dest_lev, hero_id, eqm_pos)
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.hero_all_eqm_powered_req+1, "onGetBatchPoweredRsp()")

    local powered_req = hero_pb.hero_all_eqm_powered_req() 
    powered_req.dest_lev = dest_lev
    powered_req.hero_id = hero_id or 0
    powered_req.eqm_pos = eqm_pos or 0
    if eqm_pos~=nil and eqm_pos~=0  then
        self.is_batch_powered = false
    else
        self.is_batch_powered = true
    end
    ComSender:getInstance():send(proto_cmd_pb.msg_cmd.hero_all_eqm_powered_req, powered_req)
end

function onGetBatchPoweredRsp(pbPkgData)
   local  batch_powered_rsp = hero_pb.hero_all_eqm_powered_rsp()
   batch_powered_rsp:ParseFromString(pbPkgData)

    if batch_powered_rsp.ret ~= error_code_pb.msg_ret.success then
        Alert:show(Helper.getErrStr(batch_powered_rsp.ret))
        return 
    end          

    local srv_eqms = batch_powered_rsp.eqms
    local client_item = nil

    for i,v in pairs(srv_eqms) do
        if v.eqms then
            for j,srv_item_info in pairs(v.eqms) do
                if srv_item_info.item then
                    client_item = _instance:getEquipInfoById(srv_item_info.item.id)
                    client_item:setPoweredLev(srv_item_info.item.eqm_info.powered_lev)
                    -- cclog("物品強化等級=%s~~%d",client_item.mode.name,srv_item_info.item.eqm_info.powered_lev)
                end
            end
        end
    end

    HeroManager:getInstance():refreshAllHero(batch_powered_rsp.heroes)

    _instance:resetAllEqmAttrIsChange()
    CharacterManager:getInstance():updateRoleAssets(batch_powered_rsp.assets)
    Notifier.dispatchCmd(CmdName.EqmBatchPoweredSucc,{is_batch_powered=_instance.is_batch_powered})
    WindowCtrl:getInstance():close(CmdName.EqmBatchPoweredView)
    ComSender:getInstance():dealExtInfo(batch_powered_rsp.ext)
end

--计算所有上阵英雄装备在当前金币数下所能强化的最高等级
function ItemManager:getFitMoneyPowered(target_lv)
    local all_eqms = self.equipItemTab
    local all_cost = 0
    local target_lv = target_lv
    local cur_lv = 0
    local real_lv = 0 
    local min_lv = self:getMinPowerLv()

    --一级一级的判断，找出可以满足条件的强化级别
    local is_end = false
    local cur_total_gold = CharacterManager:getInstance():getAssetData():getGold()
    for i=min_lv+1,target_lv do
        real_lv = i
        for _,eqm_item in pairs(all_eqms) do
            if eqm_item.hero_id>0 and eqm_item.powered_lev<i then
                all_cost = all_cost+self:getPoweredCostCoin(i)
                if all_cost>cur_total_gold then
                    all_cost = all_cost-self:getPoweredCostCoin(i)
                    real_lv = real_lv-1
                    is_end = true
                    break
                end
            end
        end

        if is_end then
            break
        end
    end

    return real_lv,all_cost
end


--计算所有上阵英雄装备强化到某一等级所需消
function ItemManager:getAllEqmPoweredCost(target_lv)
    local all_eqms = self.equipItemTab
    local all_cost = 0
    local target_lv = target_lv
    local cur_lv = 0
    for i,eqm_item in pairs(all_eqms) do
        if eqm_item.hero_id>0 and  
            eqm_item.powered_lev<target_lv then
            cur_lv = eqm_item.powered_lev
            for j = cur_lv+1,target_lv do
                all_cost = all_cost+self:getPoweredCostCoin(j)
            end     
        end
    end

    return all_cost
end

function ItemManager:getSingleFullPoweredCost(cur_powered_lv, target_powered_lv)
    local cost = 0
    for i = cur_powered_lv+1,target_powered_lv do
        cost = cost+self:getPoweredCostCoin(i)
    end
    return cost
end

--获取所有装备中最低的强化等级
function ItemManager:getMinPowerLv()
    local all_eqms = self.equipItemTab
    local min_lv = 99999
    for i,eqm_item in pairs(all_eqms) do
        if eqm_item.hero_id>0 then
            if min_lv>eqm_item.powered_lev then
                min_lv = eqm_item.powered_lev
            end
        end
    end

    return min_lv
end

--可升级装备的 英雄列表
function ItemManager:getCanUpgradeHeroList()
    return self._canUpgradeHeroList or {}
end

--该英雄是否有 可升级的装备
function ItemManager:isCanUpgradeByHeroId(hero_id)
    local ret = false
    for i=1,#self._canUpgradeHeroList do
        if self._canUpgradeHeroList[i] == hero_id then
            ret = true
            break
        end
    end
    return ret
end

--是否可以重置鉴定(不判断是否满足材料要求)
function ItemManager:isCanResetIdentify(item)
    local cost_data = self:getEqmIdentifyResetInfo( item.mode.base_id )
    return item.identify_left_num <= 5 - 1 and cost_data --最大鉴定次数5次 并配置表有
end

function ItemManager:isCanFashionResetIdentify(item)
    local fashion_data = self:getFashionIdentifyResetInfo( item.hero_id,item.mode.item_type )
    return item.identify_left_num <= 5 - 1 and fashion_data --最大鉴定次数5次 并配置表有
end

function ItemManager:clearAllEqm()
    self.equipItemTab = {}
end

--判断背包是否存在该ID的物品
function ItemManager:isItemInBag(item_id)
    if self.backpackItemTab[item_id] then
        return true
    end

    return false
end

--获取宝石套 属性配置列表
function ItemManager:getGemSuitAttrList()
    return self.eqm_suit_attr_list
end

--获取宝石套 属性
function ItemManager:getGemSuitAttr(lv)
    return self.eqm_suit_attr_list[lv]
end

--获取附魔套 属性配置
function ItemManager:getEnchantSuitAttrList()
    return self.enchant_suit_attr
end

--获取附魔套 属性
function ItemManager:getEnchantSuitAttr(lv)
    return self.enchant_suit_attr[lv]
end

--获取锻造屋快捷操作的数据列表
function ItemManager:getQuickForgeList(forge_type)
    local eqm_list = {}
    local identify_list = {}
    local upgrade_list = {}
    local hero_id_list = TeamManager:getInstance():getHeroIdByLimitStand(ItemHelper.limitStand.Unlimit, nil, 2)
    local count = #hero_id_list
    local hero_id_data_one = nil
    local eqms = nil
    local tmp_hero_info = nil
    local tab_idx = {}
    local tmp_item = nil
    for i=1,count do
        hero_id_data_one = hero_id_list[i]
        tmp_hero_info = HeroManager:getInstance():getHeroInfoByBaseId(hero_id_data_one.hero_id)
        eqms = HeroManager:getInstance():getBattleHeroEqmList(hero_id_data_one.hero_id) 
        --填充装备数据
        for location,eqm_vo in pairs(eqms:getEquipList()) do
            if eqm_vo and eqm_vo.item then
                table.insert(eqm_list,eqm_vo.item)
                tab_idx[hero_id_data_one.hero_id.."_"..eqm_vo.item.mode.base_id] = #eqm_list

                --鉴定
                if self:canIdentify(eqm_vo.item) then
                    table.insert(identify_list,eqm_vo.item)
                end

                --装备升级
                local ret,err = self:isCanEqmUpgradeByBaseId(eqm_vo.item.mode.base_id)
                if err.teamLev~=nil then
                    table.insert(upgrade_list,eqm_vo.item)
                end
            end
        end
        --填充时装数据
        local fashion_list = tmp_hero_info:getFashionCurWearList()
        for location,fashion_vo in pairs(fashion_list) do
            if fashion_vo then
                tmp_item = tmp_hero_info:getFashionCurWearItem(location)
                table.insert(eqm_list,tmp_item)
                tab_idx[hero_id_data_one.hero_id.."_"..tmp_item.mode.base_id] = #eqm_list

                --鉴定
                if self:canIdentify(tmp_item) then
                    table.insert(identify_list,tmp_item)
                end

                --装备升级
                local ret,err = self:isCanEqmUpgradeByBaseId(tmp_item.mode.base_id)
                if err.teamLev~=nil then
                    table.insert(upgrade_list,tmp_item)
                end
            end
        end
    end

    return eqm_list,tab_idx,identify_list,upgrade_list
end