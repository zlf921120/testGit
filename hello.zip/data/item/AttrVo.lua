--
-- Author: lvgansheng
-- Date: 2014-06-16 19:55:48
-- 物品属性vo

AttrVo = class("AttrVo")


