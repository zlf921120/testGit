
--物品表中的物品模型数据
ItemModel =class("ItemModel")

ItemModel.base_id = 0 --基础ID
ItemModel.name = nil --名称
ItemModel.icon_id = 0 --图标ID
ItemModel.item_type = 0 --类型
ItemModel.quality = 0 --品质
ItemModel.useway = 0 --使用方式
ItemModel.attr_desc = nil -- 属性描述
ItemModel.desc = nil -- 文案描述
ItemModel.limit_lev = 0 --限制等级
ItemModel.limit_stand = 0 --限制站位
ItemModel.sell_price = 0 --卖出单价
ItemModel.money_type = 0 --售价的货币类型,1表示金币，2表示钻石,ItemHelper.moneyType中有相关定义
ItemModel.enchant_energy = 0 --附魔时可以提供的能量
ItemModel.func_type = 0 --功能类型
ItemModel.eqm_quality = 0 --装备品质(精良等)