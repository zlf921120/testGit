
--互赠 条目
GiveItem = class("GiveItem",function()
    return Layout:create()
end)

GiveItem.__index = GiveItem
GiveItem._widget 	= nil
GiveItem.uiLayer = nil
GiveItem.playerVo = nil

function GiveItem:create(playerVo)
    local ret = GiveItem.new()
    ret:init(playerVo)
    return ret
end

--------------------------响应事件---------------------------------------------
local function event_btn_physical(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
        local id = tolua.cast(pSender,"Button"):getTag()
		GuildNetTask:getInstance():requestSendPhysical(id)
	end
end

-- local function event_btn_icon(pSender,eventType)
--     if eventType == ComConstTab.TouchEventType.ended then
--         local playerVo = GuildDataProxy:getInstance():getPlayerVoById(pSender:getTag())
--         WindowCtrl:getInstance():open(CmdName.Comm_PlayerInfo,{vo = playerVo})
--     end
-- end
--------------------------初始化----------------------------------------------
function GiveItem:init(playerVo)

	self._widget = GuildDataProxy:getInstance():getWidgetGivePhysicalItem():clone()
    self:addChild(self._widget)
    self:setSize(CCSize(541,116))

    local btnPhysical = tolua.cast(self._widget:getChildByName("btn_physical"),"Button")
    btnPhysical:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            GuildNetTask:getInstance():requestSendPhysical(self.playerVo.role_id:getKeyIdx())
        end
    end)

    local p_icon = self._widget:getChildByName("p_icon")
    local icon = HeadIcon:create()
    icon:setScale(0.9)
    icon:setFaceId(playerVo.faceId,playerVo.sex)
    icon:setPosition(ccp(p_icon:getPosition()))
    icon:setClickEvent(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Comm_PlayerInfo,{vo = self.playerVo})
        end
    end)
    self._widget:addChild(icon)

    self.playerVo = playerVo
    self:update(self.playerVo)

    -- Notifier.regist(OrganizEvent.CB_SEND_PHYSICAL,function() self:update(self.playerVo) end)
end

function GiveItem:update(playerVo)

	local labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    labName:setText(playerVo.name)

    local labLevel = tolua.cast(self._widget:getChildByName("lab_level"),"Label")
    labLevel:setText(playerVo.level)

    local labClazz = tolua.cast(self._widget:getChildByName("lab_clazz"),"Label")
    labClazz:setText(ClazzTypeName[playerVo.clazz + 1])

    local btnPhysical = tolua.cast(self._widget:getChildByName("btn_physical"),"Button")

    if playerVo.physicalStatus == PhysicalStatus.UN_SEND then
        btnPhysical:setTitleText(PhysicalStatusName.UN_SEND)
		btnPhysical:setBright(true)
        btnPhysical:setTouchEnabled(true)
    elseif playerVo.physicalStatus == PhysicalStatus.HAD_SEND then
        btnPhysical:setTitleText(PhysicalStatusName.HAD_SEND)
        btnPhysical:setBright(false)
        btnPhysical:setTouchEnabled(false)
    end

end