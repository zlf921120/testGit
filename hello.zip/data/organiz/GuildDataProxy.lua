--公会 数据代理
GuildDataProxy = class("GuildDataProxy")
GuildDataProxy.organizVoList = {} --公会列表
GuildDataProxy.guildLogVoList = {} --公会日志
GuildDataProxy.guildViewVoList = {} --内部公会 查看 公会列表
GuildDataProxy.playerVoList = {}  --内部成员列表
GuildDataProxy.findGuildVoList = {} --查找公会结果列表
GuildDataProxy.givePhysicalVo = nil --互赠体力页面 值对象
GuildDataProxy.applyVoList = {}  --申请者列表
GuildDataProxy.worshipDescVo = nil --领取 膜拜页面  值对象
GuildDataProxy.worshipChoiceVo = nil --选择 膜拜页面 值对象
GuildDataProxy.guildMemberSceneVo = nil --公会 内部 场景
GuildDataProxy.guildDonatePanelVo = nil --捐献面板 
GuildDataProxy.auctionVoList = {} --公会竞拍列表
GuildDataProxy.myAuctionVoList = {} --我的竞拍列表
GuildDataProxy.auctionDataVoList = {} --公会竞拍 [配置]列表
GuildDataProxy.bossVoList = {} --公会boss列表 [Map结构]
GuildDataProxy.bossVoTblList = {}  --公会boss列表 [Vector结构]
GuildDataProxy.guildRecordVoList = {} --公会竞拍 纪录
GuildDataProxy.myRecordVoList = {} --个人竞拍 纪录
GuildDataProxy.skillDescVoList = {} --技能描述列表[配置]列表
GuildDataProxy.skillMeVoList = {} --个人技能列表
GuildDataProxy.skillGuildVoList = {} --公会技能列表
GuildDataProxy.iconVoList = {} --公会图标 配置列表
GuildDataProxy.levupCostVoList = {} --公会升级消耗 配置列表
GuildDataProxy.mailCostVoList = {} --公会群发消耗 配置列表
GuildDataProxy.levLimitVoList = {} --等级 --> 成员 -- > 资金上限 配置列表
GuildDataProxy.donoteCostVoList = {} --捐赠消耗 (金币) 配置列表
GuildDataProxy.donateDiamonCostVoList = {} --捐献消耗(钻石) 配置列表
GuildDataProxy.quickJoinVoList = {} --免申请等级 配置列表
	
GuildDataProxy.fightCheerVoList = {} --公会战 助威进阶
GuildDataProxy.fightGlorySceneVo = nil --公会战 战利分配
GuildDataProxy.guildFightSceneVo = nil --公会战 场景
GuildDataProxy.fightSignupVoList = {} --公会战 申请列表
GuildDataProxy.fightScheVoList = {} --公会战 赛程列表
GuildDataProxy.fightScoreVoList = {} --公会战 本届 [某公会] 战绩列表 
GuildDataProxy.fightLastScoreVoList = {} --公会战 上届 [某公会] 战绩列表 
GuildDataProxy.fightMyAreaVoList = {} --公会战 我方 区域 标题列表
GuildDataProxy.fightEnemyAreaVoList = {} --公会战 敌方 区域 标题列表
GuildDataProxy.fightEnemyVoList = {} --公会战 对手镜像列表
GuildDataProxy.fightMyTeamVoList = {} --公会战 我方镜像列表
GuildDataProxy.fightMyHeroVoList = {} --公会战 我方英雄血量 情况
GuildDataProxy.fightAllCombatRecord = {} --公会战 全服 战况列表
GuildDataProxy.fightAllCombatRecordTitle = {} --公会战 全服 战况列表 日期标题
GuildDataProxy.fightMyCombatRecord = {} --公会战 本公会 所有 对战结果[动态增长]
GuildDataProxy.fightAllCombatRank = {} --公会战 本届 全服公会 总排名
GuildDataProxy.guildFightTeamVoList = {} --公会战 战斗队伍状况 （我方/敌方）

GuildDataProxy.fightGloryRankList = {} --公会战 成员 排名
GuildDataProxy.fightGloryLogList = {} --公会战 战利 日志
GuildDataProxy.fightGloryLogTitleList = {} --公会战 战利 日志 标题
GuildDataProxy.fightGloryGiftList = {} --公会战 战利 物品列表
GuildDataProxy.fightPowerRankList = {} --公会战 战力排名
GuildDataProxy.fightCurRankList = {} --公会战 当前排名
GuildDataProxy.fightRankRewardList = {} --公会战 排名奖励列表

GuildDataProxy._passiveSkillDataDict = {} --技能列表
GuildDataProxy._skillTypeDict = {}
---------------------------------------------------------
GuildDataProxy.guildCombatColdList = {}
GuildDataProxy.svrHpLen = 0
------------------------------------------------
GuildDataProxy.short_fight_news_enter = 0
GuildDataProxy.myauction_news = 0
GuildDataProxy.fight_reward_news = 0

local __instance = nil
local _allowInstance = false

function GuildDataProxy:ctor()
    if not _allowInstance then
		error("GuildDataProxy is a singleton class")
	end
	self:init()
end

function GuildDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = GuildDataProxy.new()
		_allowInstance = false
	end

	return __instance
end

function GuildDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function GuildDataProxy:init()
	require "SkillEnum"
	require "SkillVO"
	require "GuildVo"
end
---------------------------------------------------------------
function GuildDataProxy:getGuildSceneVo()
	if self.guildMemberSceneVo == nil then
		self.guildMemberSceneVo = GuildVo.new()
	end
	return self.guildMemberSceneVo
end

function GuildDataProxy:getDonatePanelVo()
	if self.guildDonatePanelVo == nil then
		self.guildDonatePanelVo = GuildDonatePanelVo.new()
	end
	return self.guildDonatePanelVo
end
---------------加入公会 面板 值对象---------------------------------
function GuildDataProxy:getGuildVoList()
	return self.organizVoList
end

function GuildDataProxy:createGuildVo()
	return GuildVo.new()
end

function GuildDataProxy:setGuildVo(vo)
	self.organizVoList[ vo.id ] = vo
end

function GuildDataProxy:getGuildVoById(id)
	return self.organizVoList[id]
end
-------------------公会内部 查看公会--------------------------------
function GuildDataProxy:getGuildViewVoList()
	return self.guildViewVoList
end

function GuildDataProxy:setGuildViewVo(vo)
	self.guildViewVoList[ vo.id ] = vo
end

function GuildDataProxy:getGuildViewVoById(id)
	return self.guildViewVoList[id]
end
---------------查找公会 面板 值对象---------------------------------
function GuildDataProxy:getFindGuildVoList()
	return self.findGuildVoList
end

function GuildDataProxy:setFindGuildVo(vo)
	self.findGuildVoList[ vo.id ] = vo
end

function GuildDataProxy:getFindGuildVoById(id)
	return self.findGuildVoList[id]
end
-----------------成员 公会面板 值对象------------------------------------
function GuildDataProxy:createPlayerVo()
	return GuildPlayerVo.new()
end

function GuildDataProxy:getPlayerVoList()
	return self.playerVoList
end

function GuildDataProxy:setPlayerVo(vo)
	self.playerVoList[ vo.id ] = vo
end

function GuildDataProxy:getPlayerVoById(id)
	return self.playerVoList[id]
end

function GuildDataProxy:removePlayerVoById(id)
	self.playerVoList[id] = nil 
end
-------------------选择 赠送体力 页面 值对象---------------------------------
function GuildDataProxy:getWorshipChoiceVo()
	if self.worshipChoiceVo == nil then
		self.worshipChoiceVo = WorshipChoiceVo.new()
	end
	return self.worshipChoiceVo
end

-------------------互赠体力 页面 值对象--------------------------------------
function GuildDataProxy:getGivePhysicalVo()
	if self.givePhysicalVo == nil then
		self.givePhysicalVo = GivePhysicalVo.new()
	end
	return self.givePhysicalVo
end

--------------------领取 受拜奖励 页面 值对象---------------------------------------
function GuildDataProxy:getWorshipDescVo()
	if self.worshipDescVo == nil then
		self.worshipDescVo = WorshopDescVo.new()

	    local guildData = CharacterManager:getInstance():getGuildData()
	    self.worshipDescVo.rewardNum = guildData:getWorshipReward()
	end
	return self.worshipDescVo
end
---------------------公会战 战利 面板-----------------------------------------
function GuildDataProxy:getFightGlorySceneVo()
	if self.fightGlorySceneVo == nil then
		self.fightGlorySceneVo = GuildFightGlorySceneVo.new()
	end
	return self.fightGlorySceneVo
end
----------------------会长权限 页面 值对象--------------------------------------
function GuildDataProxy:createApplyVo()
	return GuildApplyVo:new()
end

function GuildDataProxy:getApplyVoList()
	return self.applyVoList
end

function GuildDataProxy:setApplyVo(vo)
	self.applyVoList[ vo.id ] = vo
end

function GuildDataProxy:getApplyVoById(id)
	return self.applyVoList[ id ]
end

function GuildDataProxy:removeApplyVoById(id)
	self.applyVoList[id] = nil 
end
-------------------公会图标-----------------------------------------
function GuildDataProxy:createIconVo()
	return OrganizIconVo.new()
end

function GuildDataProxy:getIconVoById(id)
	return self.iconVoList[ id ]
end

function GuildDataProxy:setIconVo(vo)
	self.iconVoList[ vo.id ] = vo
end

function GuildDataProxy:getIconVoList()
	return self.iconVoList
end
----------------------公会boss---------------------------------------
function GuildDataProxy:createBossVo()
	return GuildBossVo.new()
end

function GuildDataProxy:getBossVoById(id)
	return self.bossVoList[ id ]
end

function GuildDataProxy:setBossVo(vo)
	self.bossVoList[ vo.id ] = vo
end

function GuildDataProxy:getBossVoList()
	return self.bossVoList
end
----------------------公会战----------------------------------------
function GuildDataProxy:getGuildFightSceneVo()
	if self.guildFightSceneVo == nil then
		self.guildFightSceneVo = GuildFightSceneVo.new()
	end
	return self.guildFightSceneVo
end

function GuildDataProxy:getGuildFightPerpareVo()
	if self.guildFightPerpareVo == nil then
		self.guildFightPerpareVo = GuildFightPerpareVo.new()
	end
	return self.guildFightPerpareVo
end
----------------------公会竞拍---------------------------------------
function GuildDataProxy:createAuctionVo()
	return GuildAuctionVo.new()
end

function GuildDataProxy:getAuctionVoById(id)
	return self.auctionVoList[ id ]
end

function GuildDataProxy:setAuctionVo(vo)
	self.auctionVoList[ vo.id ] = vo
end

function GuildDataProxy:getAuctionVoList()
	return self.auctionVoList
end
-----------------------我的竞拍--------------------------------------
function GuildDataProxy:getMyAuctionVoById(id)
	return self.myAuctionVoList[ id ]
end

function GuildDataProxy:setMyAuctionVo(vo)
	self.myAuctionVoList[ vo.id ] = vo
end

function GuildDataProxy:getMyAuctionVoList()
	return self.myAuctionVoList
end
----------------------公会竞拍 [配置数据]----------------------------------
function GuildDataProxy:createAuctionDataVo()
	return GuildAuctionDataVo.new()
end

function GuildDataProxy:getAuctionDataVoById(baseId)
	return self.auctionDataVoList[ baseId ]
end

function GuildDataProxy:setAuctionDataVo(vo)
	self.auctionDataVoList[ vo.base_id ] = vo
end

function GuildDataProxy:getAuctionDataVoList()
	return self.auctionDataVoList
end
----------------------公会升级 消耗----------------------------
function GuildDataProxy:createLevupCostVo()
	return GuildLevupCostVo.new()
end

function GuildDataProxy:getLevupCostVoById(lev)
	return self.levupCostVoList[ lev ]
end

function GuildDataProxy:setLevupCostVo(vo)
	self.levupCostVoList[ vo.lev ] = vo
end

function GuildDataProxy:getLevupCostVoList()
	return self.levupCostVoList
end
----------------------公会群发邮件 消耗----------------------------
function GuildDataProxy:createMailCostVo()
	return GuildMailCostVo.new()
end

function GuildDataProxy:getMailCostVoById(cout)
	return self.mailCostVoList[ cout ]
end

function GuildDataProxy:setMailCostVo(vo)
	self.mailCostVoList[ vo.cout ] = vo
end

function GuildDataProxy:getMailCostVoList()
	return self.mailCostVoList
end
----------------------公会人员 上限 ----------------------------
function GuildDataProxy:createLevLimitVo()
	return GuildLevLimitVo.new()
end

function GuildDataProxy:getLevLimitVoById(lev)
	return self.levLimitVoList[ lev ]
end

function GuildDataProxy:setLevLimitVo(vo)
	self.levLimitVoList[ vo.lev ] = vo
end

function GuildDataProxy:getLevLimitVoList()
	return self.levLimitVoList
end
----------------------公会捐献 消耗 ----------------------------
function GuildDataProxy:createDonateCostVo()
	return GuildDonateCostVo.new()
end

-- function GuildDataProxy:getDonateCostVoById(cout)
-- 	return self.donoteCostVoList[ cout ]
-- end

-- function GuildDataProxy:setDonateCostVo(vo)
-- 	self.donoteCostVoList[ vo.cout ] = vo
-- end

-- function GuildDataProxy:getDonateCostVoList()
-- 	return self.donoteCostVoList
-- end

function GuildDataProxy:setDiamonDonateCostVo(vo)
	self.donateDiamonCostVoList[ vo.cout ] = vo
end

function GuildDataProxy:getDiamonDonateCostVoById(cout)
	return self.donateDiamonCostVoList[ cout ]  
end

function GuildDataProxy:getDiamonDonateCostVoList()
	return self.donateDiamonCostVoList
end
----------------------公会免申请设置 ----------------------------
function GuildDataProxy:createQuickJoinVo()
	return GuildQuickJoinVo.new()
end

function GuildDataProxy:getQuickJoinVoById(id)
	return self.quickJoinVoList[ id ]
end

function GuildDataProxy:setQuickJoinVo(vo)
	self.quickJoinVoList[ vo.id ] = vo
end

function GuildDataProxy:getQuickJoinVoByLev(lev)
	local ret = nil
	for k,v in pairs(self.quickJoinVoList) do
		if v.lev == lev then
			ret = v
			break
		end
	end
	return ret
end

function GuildDataProxy:getQuickJoinVoList()
	return self.quickJoinVoList
end
----------------------------------------------------
function GuildDataProxy:createFightTeamVo()
	return GuildFightTeamVo.new()
end

function GuildDataProxy:setGuildFightTeamVo(vo)
	self.guildFightTeamVoList[ vo.type ] = vo
end

function GuildDataProxy:getGuildFightTeamVoById(id)
	return self.guildFightTeamVoList[id]
end
----------------------公会技能 -----------------------------
function GuildDataProxy:getSkillPassiveVoList()
	return self._passiveSkillDataDict
end

function GuildDataProxy:getSkillPassiveVoByLev(skill_id, skill_lv)
	return self._passiveSkillDataDict[skill_id][skill_lv]
end

----------------------公会技能 描述----------------------------
function GuildDataProxy:createSkillVo()
	return GuildSkillVo.new()
end

function GuildDataProxy:getSkillDescVoById(id,lev)
	return self.skillDescVoList[ id ][ lev ]
end

function GuildDataProxy:setSkillDescVo(vo)
	self.skillDescVoList[ vo.id ] = self.skillDescVoList[ vo.id ] or {}
	self.skillDescVoList[ vo.id ][ vo.lev ] = vo
end

function GuildDataProxy:getSkillDescVoList()
	return self.skillDescVoList
end
--我 技能列表
function GuildDataProxy:setMeSkillVo(vo)
	self.skillMeVoList[ vo.id ] = vo
end

function GuildDataProxy:getMeSkillVoById(id)
	return self.skillMeVoList[ id ]
end

function GuildDataProxy:getMeSkillVoList()
	return self.skillMeVoList
end

--公会 技能列表
function GuildDataProxy:setGuildSkillVo(vo)
	self.skillGuildVoList[ vo.id ] = vo
end

function GuildDataProxy:getGuildSkillVoById(id)
	return self.skillGuildVoList[ id ]
end

function GuildDataProxy:getGuildSkillVoList()
	return self.skillGuildVoList
end
-----------------------------------------------------
--公会 竞拍纪录
function GuildDataProxy:createRecordVo()
	return GuildRecordVo.new()
end

function GuildDataProxy:getGuildRecordVoById(id)
	return self.guildRecordVoList[ id ]
end

function GuildDataProxy:setGuildRecordVo(vo)
	self.guildRecordVoList[ vo.id ] = vo
end

function GuildDataProxy:getGuildRecordVoList()
	return self.guildRecordVoList
end
--个人 竞拍纪录
function GuildDataProxy:getMyRecordVoById(id)
	return self.myRecordVoList[ id ]
end

function GuildDataProxy:setMyRecordVo(vo)
	self.myRecordVoList[ vo.id ] = vo
end

function GuildDataProxy:getMyRecordVoList()
	return self.myRecordVoList
end
-----------------------公会 日志-----------------------------
function GuildDataProxy:createGuildLogVo()
	return GuildLogVo.new()
end

function GuildDataProxy:getGuildLogVoList()
	return self.guildLogVoList
end

function GuildDataProxy:setGuildLogVo(vo)
	self.guildLogVoList[ vo.id ] = vo
end
----------------------公会战 冷却-------------------------
function GuildDataProxy:createCombatColdVo()
	return GuildFightColdVo.new()
end

function GuildDataProxy:setCombatColdVo(vo)
	self.guildCombatColdList[ vo.combat_num ] = vo
end

function GuildDataProxy:getCombatColdVoById(num)
	return self.guildCombatColdList[num]
end
---------------------公会战 申请列表--------------------------
function GuildDataProxy:setFightSignupVo(vo)
	vo.height = 144 --控件高度
	self.fightSignupVoList[ vo.id ] = vo
end

function GuildDataProxy:getFightSignupVoById(id)
	return self.fightSignupVoList[id]
end

function GuildDataProxy:getFightSignupVoList()
	return self.fightSignupVoList
end

function GuildDataProxy:cleanFightSignupVoList()
	self.fightSignupVoList = {}
end
------------------公会战 赛季 总排名 结果--------------------
function GuildDataProxy:createFightCombatRankVo()
	return GuildFightCombatRankVo.new()
end

function GuildDataProxy:setAllCombatRankVo(vo)
	self.fightAllCombatRank[ vo.id ] = vo
end

function GuildDataProxy:getAllCombatRankVoById(id)
	return self.fightAllCombatRank[ id ]
end

function GuildDataProxy:getAllCombatRankVoList()
	return self.fightAllCombatRank
end

function GuildDataProxy:cleanAllCombatRankVoList()
	for k,v in pairs(self.fightAllCombatRank) do
		self.fightAllCombatRank[k] = nil
	end
	self.fightAllCombatRank = {}
end
-----------------公会战 战利 日志 ---------------------------
function GuildDataProxy:createFightGloryLogTitleVo()
	return GuildFightLogTitleItemVo.new()
end

function GuildDataProxy:setFightGloryLogTitleVo(vo)
	self.fightGloryLogTitleList[vo.id] = vo
end

function GuildDataProxy:getFightGloryLogTitleVoById(id)
	return self.fightGloryLogTitleList[ id ]
end

function GuildDataProxy:getFightGloryLogTitleVoList()
	return self.fightGloryLogTitleList
end

function GuildDataProxy:createFightGloryLogVo()
	return GuildFightLogItemVo.new()
end

function GuildDataProxy:setFightGloryLogVo(vo)
	table.insert(self.fightGloryLogList,vo)
	vo.id = #self.fightGloryLogList
end

function GuildDataProxy:getFightGloryLogVoById(id)
	return self.fightGloryLogList[ id ]
end

function GuildDataProxy:getFightGloryLogVoList()
	return self.fightGloryLogList
end

function GuildDataProxy:cleanFightGloryLogVoList()
	for k,v in pairs(self.fightGloryLogList) do
		self.fightGloryLogList[k] = nil
	end
	self.fightGloryLogList = {}
end
-----------------公会战 战利 物品 ---------------------------
function GuildDataProxy:createFightGloryGiftVo()
	return GuildFightGloryGiftVo.new()
end

function GuildDataProxy:setFightGloryGiftVo(vo)
	self.fightGloryGiftList[ vo.id ] = vo
end

function GuildDataProxy:getFightGloryGiftVoById(id)
	return self.fightGloryGiftList[ id ]
end

function GuildDataProxy:getFightGloryGiftVoList()
	return self.fightGloryGiftList
end

function GuildDataProxy:cleanFightGloryGiftVoList()
	for k,v in pairs(self.fightGloryGiftList) do
		self.fightGloryGiftList[k] = nil
	end
	self.fightGloryGiftList = {}
end
---------------------公会战 我方 本赛季 对战记录----------------------
function GuildDataProxy:createFightCombatRecordVo()
	return GuildFightCombatRecordVo.new()
end

function GuildDataProxy:setMyCombatRecordVo(vo)
	self.fightMyCombatRecord[ vo.id ] = vo
end

function GuildDataProxy:getMyCombatRecordVoById(id)
	return self.fightMyCombatRecord[ id ]
end

function GuildDataProxy:getMyCombatRecordVoList()
	return self.fightMyCombatRecord
end

function GuildDataProxy:getMyCombatRecordLastVo()
	local tmp = {}
	for k,v in pairs(self.fightMyCombatRecord) do
		table.insert(tmp,v)
	end
	table.sort( tmp, function(a,b) return a.id < b.id end ) --返回最后一场记录
	return tmp[#tmp]
end

function GuildDataProxy:cleanMyCombatRecordVoList()
	for k,v in pairs(self.fightMyCombatRecord) do
		self.fightMyCombatRecord[k] = nil
	end
	self.fightMyCombatRecord = {}
end
---------------------公会战 对手列表-----------------------------
function GuildDataProxy:setFightEnemyVo(vo)
	vo.flag = GuildFightTeamStatus.EnemyTeam
	-- vo.height = 90 --控件高度
	-- vo.widget = "fightplayer_" --具体控件
	self.fightEnemyVoList[ vo.role_id:getKeyIdx() ] = vo
end

function GuildDataProxy:getFightEnemyVoById(id)
	return self.fightEnemyVoList[id]
end

function GuildDataProxy:getFightEnemyVoByRoleId(role_id)
	return self.fightEnemyVoList[ OrganizHelper.exchageRoleIdKey(role_id) ]
end

function GuildDataProxy:getFightEnemyVoList()
	return self.fightEnemyVoList
end

function GuildDataProxy:cleanFightEnemyVoList()
	self.fightEnemyVoList = {}
end
---------------------公会战 我方列表-----------------------------
function GuildDataProxy:setFightMyTeamVo(vo)
	vo.flag = GuildFightTeamStatus.MyTeam
	self.fightMyTeamVoList[ vo.role_id:getKeyIdx() ] = vo
end

function GuildDataProxy:getFightMyTeamVoById(key)
	return self.fightMyTeamVoList[key]
end

function GuildDataProxy:getFightMyTeamVoList()
	return self.fightMyTeamVoList
end

function GuildDataProxy:cleanFightMyTeamVoList()
	for k,v in pairs(self.fightMyTeamVoList) do
		self.fightMyTeamVoList[k] = nil
	end
	self.fightMyTeamVoList = {}
end

function GuildDataProxy:getCurCheerVo()
	return self:getFightCheerVoById(self:getCheerStep())
end

------------------公会战 战力排名--------------------
function GuildDataProxy:createFightPowerRankVo()
	return GuildFightPowerRankVo.new()
end

function GuildDataProxy:setPowerRankVo(vo)
	self.fightPowerRankList[ vo.id ] = vo
end

function GuildDataProxy:getPowerRankVoById(id)
	return self.fightPowerRankList[ id ]
end

function GuildDataProxy:getPowerRankVoList()
	return self.fightPowerRankList
end

function GuildDataProxy:cleanPowerRankVoList()
	for k,v in pairs(self.fightPowerRankList) do
		self.fightPowerRankList[k] = nil
	end
	self.fightPowerRankList = {}
end
------------------公会战 实时排名--------------------
function GuildDataProxy:createFightCurRankVo()
	return GuildFightCurRankVo.new()
end

function GuildDataProxy:setCurRankVo(vo)
	self.fightCurRankList[ vo.id ] = vo
end

function GuildDataProxy:getCurRankVoById(id)
	return self.fightCurRankList[ id ]
end

function GuildDataProxy:getCurRankVoList()
	return self.fightCurRankList
end

function GuildDataProxy:cleanCurRankVoList()
	for k,v in pairs(self.fightCurRankList) do
		self.fightCurRankList[k] = nil
	end
	self.fightCurRankList = {}
end
-------------------------------------------------
--获取各区的总高度
function GuildDataProxy:getFightTeamAreaHeight(area,t)
	local count = 0
	local voList = nil
	if t == GuildFightTeamStatus.MyTeam then
		voList = self.fightMyTeamVoList 
	elseif t == GuildFightTeamStatus.EnemyTeam then
		voList = self.fightEnemyVoList 
	end
		
	for k,v in pairs(voList) do
		if v.guild_fight_area == area then
			count = count + v.height
		end
	end
	count = count + 80
	return count
end

--检查是否需要 填充占位 元素
function GuildDataProxy:checkMakeHolderVo()
	local power_num = 0
	local protect_num = 0
	local defense_num = 0
	local common_num = 0
	--初始化占位人
	for i=0,20 do
		self.fightMyTeamVoList[ string.format("%d_%d_%d",10000,i,0) ] = nil
		self.fightMyTeamVoList[ string.format("%d_%d_%d",20000,i,0) ] = nil
		self.fightMyTeamVoList[ string.format("%d_%d_%d",30000,i,0) ] = nil
	end

	local cheerVo = self:getCurCheerVo()

	--统计各区人数
	for k,v in pairs(self.fightMyTeamVoList) do
		if v.guild_fight_area == GuildFightArea.Protect then

			protect_num = protect_num + 1
		elseif v.guild_fight_area == GuildFightArea.Power then

			power_num = power_num + 1
		elseif v.guild_fight_area == GuildFightArea.Defense then

			defense_num = defense_num + 1
		elseif v.guild_fight_area == GuildFightArea.Common then

			common_num = common_num + 1
		end
	end

	local disProtect = cheerVo.protection_limit - protect_num
	if disProtect > 0 then
		for i=1,disProtect do
			local empty_role_info = GuildFightRoleInfo:create()
			empty_role_info:setBaseInfo({uin=10000,channel_id=i,zone_id=0})
			empty_role_info:setGuildFight(GuildFightArea.Protect)
			self:setFightMyTeamVo(empty_role_info)
		end
	end
	local disPower = cheerVo.power_limit - power_num
	if disPower > 0 then
		for i=1,disPower do
			local empty_role_info = GuildFightRoleInfo:create()
			empty_role_info:setBaseInfo({uin=20000,channel_id=i,zone_id=0})
			empty_role_info:setGuildFight(GuildFightArea.Power)
			self:setFightMyTeamVo(empty_role_info)
		end
	end
	local disDefense = cheerVo.defence_limit - defense_num
	if disDefense > 0 then
		for i=1,disDefense do
			local empty_role_info = GuildFightRoleInfo:create()
			empty_role_info:setBaseInfo({uin=30000,channel_id=i,zone_id=0})
			empty_role_info:setGuildFight(GuildFightArea.Defense)
			self:setFightMyTeamVo(empty_role_info)
		end
	end
	self:makeAreaVoList( CharacterManager:getInstance():getGuildData():getCheerNum() ,self.fightMyAreaVoList)
end

--统计各个区 助威数值加成 
function GuildDataProxy:makeAreaVoList(cheerNum,target)

	local dp = GuildDataProxy:getInstance()
	local idx = dp:getCheerStep(cheerNum)
	local cheerVo = dp:getFightCheerVoById(idx)

	local areaVo = self:createFightAreaVo()
	areaVo.t = GuildFightArea.Protect
	target[ GuildFightArea.Protect ] = areaVo
	local areaVo = self:createFightAreaVo()
	areaVo.t = GuildFightArea.Power
	areaVo.addition = cheerVo.act_addition
	target[ GuildFightArea.Power ] = areaVo
	local areaVo = self:createFightAreaVo()
	areaVo.t = GuildFightArea.Defense
	areaVo.addition = cheerVo.hp_addition
	target[ GuildFightArea.Defense ] = areaVo
	local areaVo = self:createFightAreaVo()
	areaVo.t = GuildFightArea.Common
	target[ GuildFightArea.Common ] = areaVo
end

--获取当前助威阶段
function GuildDataProxy:getCheerStep(cheerNum)

	local num = cheerNum
	if num == nil then
		local guildData = CharacterManager:getInstance():getGuildData()
		num = guildData:getCheerNum()
	end
	
    local voList = GuildDataProxy:getInstance():getFightCheerVoList()

    local idx = 1
    for k,v in pairs(voList) do
        if num >= v.cheer_num then
            idx = v.id
        else
            break
        end
    end
    return idx
end

--是否已经 修改好 公会战 出战阵型
function GuildDataProxy:isConfirmFightPos()
	return OrganizHelper.getCurFightRoleInfo().guild_fight_isConfirmTeam == 1
end

function GuildDataProxy:setConfirmFightPos(value)
	OrganizHelper.getCurFightRoleInfo().guild_fight_isConfirmTeam = value
end

function GuildDataProxy:isCanChangeTeam()
	if self:getGuildFightSceneVo().curMoment == GuildFightMoment.BattleIng and 
		self:isConfirmFightPos() then
		return false
	end
	return true
end

----------------------公会战 我方战区 标题列表----------------------------
function GuildDataProxy:createFightAreaVo()
	return GuildFightAreaTitleVo.new()
end

function GuildDataProxy:setFightMyAreaVo(vo)
	self.fightMyAreaVoList[ vo.t ] = vo
end

function GuildDataProxy:getFightMyAreaVoById(t)
	return self.fightMyAreaVoList[ t ]
end

function GuildDataProxy:getFightMyAreaVoList()
	return self.fightMyAreaVoList
end
----------------------公会战 敌方战区 标题列表----------------------------
function GuildDataProxy:setFightEnemyAreaVo(vo)
	self.fightEnemyAreaVoList[ vo.id ] = vo
end

function GuildDataProxy:getFightEnemyAreaVoById(id)
	return self.fightEnemyAreaVoList[ id ]
end

function GuildDataProxy:getFightEnemyAreaVoList()
	return self.fightEnemyAreaVoList
end
------------------公会战 我 英雄血量--------------------------
function GuildDataProxy:createHeroVo()
	return GuildFightHeroVo.new()
end

function GuildDataProxy:getMyHeroVoList()
	return self.fightMyHeroVoList
end

function GuildDataProxy:setMyHeroVo(vo)
	self.fightMyHeroVoList[ vo.id ] = vo
end

--英雄血量长度
function GuildDataProxy:getSvrHpLen()
	return self.svrHpLen
end

function GuildDataProxy:getMyHeroVoById(id)
	local v = self.fightMyHeroVoList[ id ]
	if v then
		if v.molecular == 0 then
			v.perc = 0
		else
			v.perc = v.molecular / v.denominator
		end
		local attrVo = HeroManager:getInstance():getHeroFinalAttr(id, TeamType.Guild_atk)

		v.hp = attrVo[ AttrHelper.attr_flag.hp ] * v.perc
		v.maxHp = attrVo[ AttrHelper.attr_flag.hp ]
	end
	return v
end

--------------------公会战 本届对战赛程---------------------------------
function GuildDataProxy:createFightScheItemVo()
	return GuildFightScheItemVo.new()
end

function GuildDataProxy:setFightScheItemVo(vo)
	table.insert(self.fightScheVoList,vo)
	vo.id = #self.fightScheVoList
end

function GuildDataProxy:getFightScheItemVoById(id)
	return self.fightScheVoList[ id ]
end

function GuildDataProxy:getFightScheItemVoList()
	return self.fightScheVoList
end

function GuildDataProxy:cleanFightScheVoList()
	for k,v in pairs(self.fightScheVoList) do
		self.fightScheVoList[k] = nil
	end
	self.fightScheVoList = {}
end
---------------------公会战 某公会 战绩 [注意 这是临时数据 缓存列表 会不断被刷新]------------------------
function GuildDataProxy:setFightScoreItemVo(vo)
	self.fightScoreVoList[vo.id] = vo
end

function GuildDataProxy:getFightScoreItemVoById(id)
	return self.fightScoreVoList[ id ]
end

function GuildDataProxy:getFightScoreList()
	return self.fightScoreVoList
end

function GuildDataProxy:clearFightScoreList()
	for i,v in pairs(self.fightScoreVoList) do
		self.fightScoreVoList[i] = nil
	end
	self.fightScoreVoList = {}
end
----------公会战 战绩面板--------------------------------------------------
function GuildDataProxy:getFightScoreViewVo()
	if self.guildFightScoreViewVo == nil then
		self.guildFightScoreViewVo = GuildFightScoreViewVo.new()
	end
	return self.guildFightScoreViewVo
end

------------------------公会战 成员积分 排名------------
function GuildDataProxy:createFightGloryMember() 
	return GuildFightGloryMemberVo.new()
end

function GuildDataProxy:setFightGloryMember(vo)
	self.fightGloryRankList[vo.id] = vo
end

function GuildDataProxy:getFightGloryMemberById(id)
	return self.fightGloryRankList[id]
end

function GuildDataProxy:getFightGloryMemberList()
	return self.fightGloryRankList
end

function GuildDataProxy:cleanGloryMemberList()
	for k,v in pairs(self.fightGloryRankList) do
		self.fightGloryRankList[k] = nil
	end
	self.fightGloryRankList = {}
end
----------------------------------------------------
function GuildDataProxy:createFightCheerVo()
	return GuildFightCheerVo.new()
end

function GuildDataProxy:setFightCheerVo(vo)
	self.fightCheerVoList[ vo.id ] = vo
end

function GuildDataProxy:getFightCheerVoById(id)
	return self.fightCheerVoList[id]
end

function GuildDataProxy:getFightCheerVoList()
	return self.fightCheerVoList
end
-------------------公会战 全服战况 排名---------------
function GuildDataProxy:createAllCombatRecordTitle()
	return GuildFightSituationTitleItemVo.new()
end

function GuildDataProxy:setAllCombatRecordTitle(vo)
	self.fightAllCombatRecordTitle[ vo.id ] = vo
end

function GuildDataProxy:getAllCombatRecordTitleById(id)
	return self.fightAllCombatRecordTitle[id]
end

function GuildDataProxy:getAllCombatRecordTitleVoList()
	return self.fightAllCombatRecordTitle
end

function GuildDataProxy:setAllCombatRecordVo(vo)
	vo.height = 138
	vo.widget = "fightAllCombat_"
	table.insert(self.fightAllCombatRecord,vo)
end

function GuildDataProxy:getAllCombatRecordById(id)
	return self.fightAllCombatRecord[ id ]
end

function GuildDataProxy:getAllCombatRecordVoList()
	return self.fightAllCombatRecord
end

function GuildDataProxy:cleanAllCombatRecordVoList()
	for k,v in pairs(self.fightAllCombatRecord) do
		self.fightAllCombatRecord[k] = nil
	end
	self.fightAllCombatRecord = {}

	for k,v in pairs(self.fightAllCombatRecordTitle) do
		self.fightAllCombatRecordTitle[k] = nil
	end
	self.fightAllCombatRecordTitle = {}
end
------------------------------------------------------
function GuildDataProxy:getRankRewardList()
	return self.fightRankRewardList
end

function GuildDataProxy:getRankRewardByRank(rank)
	local type = 0
	if rank == 1 then
		type = 1
	elseif rank == 2 then
		type = 2
	elseif rank == 3 then
		type = 3
	elseif rank == 4 or rank == 5 then
		type = 4
	elseif rank >= 6 then
		type = 5
	end
	return self.fightRankRewardList[type]
end
------------------------------------------------
-- function GuildDataProxy:getFightTimerRenderFuncList()
-- 	return self.fightTimerRenderFuncTbl
-- end

-- function GuildDataProxy:appendFightTimerRenderFunc(func)
-- 	table.insert(self.fightTimerRenderFuncTbl,func)
-- end
---------检测 公会战 镜像数据 剩余的人数---------------------------------
function GuildDataProxy:getFightTeamLeftNum(arr)
	local cout = 0
	local total = 0
	for k,v in pairs(arr) do
		if (v.role_id.uin == 10000 or 
			v.role_id.uin == 20000 or 
			v.role_id.uin == 30000) then
			--排除 占位的 镜像条目
		else
			total = total + 1
			if v:isDealAllHero() == false then
				cout = cout + 1
			end
		end
	end
	return cout,total
end

function GuildDataProxy:getFightTeamLeftNum()

end
------------------------------------------------------------------
function GuildDataProxy:makeMeGuildSkillBySvr()

	local guildData = CharacterManager:getInstance():getGuildData()
	for i=1,#guildData._skills do
		local v = guildData._skills[i]
		local skillVo = self:createSkillVo()
		skillVo.id = v.skill_id
		skillVo.lev = v.lev
		self:setMeSkillVo(skillVo)
	end
end

function GuildDataProxy:makeGuildBossHpBySvr(info)
	-- print(" ##info.hp ",#info.hp)
	-- print(" ##info.open ",#info.open)
	-- print(" ##info.att ",#info.att)
	if #info.hp <= 0 then return print("該玩家的公會還沒初始化") end

	for i=1,#info.hp do
	 	local bossVo = self:getBossVoById( info.hp[i].id )
	 	bossVo.isActive = 1
	 	bossVo.hp = info.hp[i].hp
	 	-- print("-> bossVo.hp ",bossVo.hp)
	end

	local curBossVo = self.bossVoTblList[ GuildRenderMgr:getInstance().showBossIdx ]
	curBossVo.hurtList = {}
	for i=1,#info.att do
		local v = info.att[i]
		table.insert( curBossVo.hurtList , { name = v.name , role_id = v.id,att = v.att })
	end
	Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_BOSS_SCENE_ITEM,curBossVo.id)
	Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_BOSS_HURT_LIST)
	Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_BOSS_INFO,curBossVo)
end

function GuildDataProxy:makeAllCombatTitleVoList(info)
	for i=1,#info do
		local v = info[i]
		local voTitle = self:createAllCombatRecordTitle()
		voTitle.id = v.session
		self:setAllCombatRecordTitle(voTitle)
	end
end

function GuildDataProxy:makeLogTitleVoList(info)
	for i=1,#info do
		local v = info[i]
		local voTitle = self:createFightGloryLogTitleVo()
	    local nowMonth = tonumber(os.date("%m",v.create_time))
	    local nowYear = tonumber(os.date("%Y",v.create_time))
	    local nowDay = tonumber(os.date("%d",v.create_time))
	    local createDay = os.time{year=nowYear, month=nowMonth, day=nowDay, hour=0, sec=0}
	    voTitle.id = createDay
		self:setFightGloryLogTitleVo(voTitle)
	end
end

--关闭所有跟公会有关的面板
function GuildDataProxy:closeAllGuildView()
	local wc = WindowCtrl:getInstance()
	wc:close(CmdName.Guild_View_Public)
	wc:close(CmdName.Guild_View_Member)
	wc:close(CmdName.Guild_View_Permission)
	wc:close(CmdName.Guild_View_Boss)
	wc:close(CmdName.Guild_View_BossOpen)
	wc:close(CmdName.Guild_View_BossPerpare)
	wc:close(CmdName.Guild_View_Skill)
	wc:close(CmdName.Guild_View_Skill_Guild)
	wc:close(CmdName.Guild_View_AuctionPanel)
	wc:close(CmdName.Guild_View_GuildInfoPanel)
	wc:close(CmdName.Guild_View_DonatePanel)
	wc:close(CmdName.Guild_View_DescWorship)
	wc:close(CmdName.Guild_View_ChoiceWorship)
	wc:close(CmdName.Guild_View_GivePhysical)
	wc:close(CmdName.Guild_View_LogoPanel_create)
	wc:close(CmdName.Guild_View_LogoPanel_edit)
	wc:close(CmdName.Guild_View_EditMember)
	wc:close(CmdName.Guild_View_MEMBMER_ALL_GUILD)
	wc:close(CmdName.Guild_View_FightScene)
	wc:close(CmdName.Guild_View_SignupView)
	wc:close(CmdName.Guild_View_FightPerpare)
	wc:close(CmdName.Guild_View_FightBattle)
	wc:close(CmdName.Guild_View_FightEdit)
	wc:close(CmdName.Guild_View_CheerView)
	wc:close(CmdName.Guild_View_FightScorePanel)
	wc:close(CmdName.Guild_View_FightSchePanel)
	wc:close(CmdName.Guild_View_PerpareFinish)
	wc:close(CmdName.Guild_View_SignupList)
	wc:close(CmdName.Guild_View_GloryPanel)
	wc:close(CmdName.Guild_View_GloryAllotPanel)

	CharacterManager:getInstance():getGuildData()._name = ""
	Alert:show("您已被踢出公會")
end

function GuildDataProxy:cleanBossData()
	for k,v in pairs(self.bossVoList) do
		local monstorAttr = MonsterManager:getInstance():getBaseAttr(v.id)
        local hpMax = monstorAttr[ AttrHelper.attr_flag.hp ]
		v.isActive = 0
		v.hp = hpMax
		v.active_num = 0
		v.leftDay = ""
	end
end

--是否可以学习新技能
function GuildDataProxy:isCanLearnSkill()
	local ret = false
	local tmpList = {}
	for skill_id,v in pairs( self:getSkillDescVoList()) do
		table.insert(tmpList,skill_id)
	end
	for i=1,#tmpList do
		local guildSkillVo = self:getGuildSkillVoById( tmpList[i] )
		local meSkillVo = self:getMeSkillVoById( tmpList[i] )
		if guildSkillVo ~= nil and meSkillVo == nil then --有公会技能 没自己技能
			ret = true
			break
		elseif guildSkillVo ~= nil and meSkillVo ~= nil and guildSkillVo.lev > meSkillVo.lev then --都有技能 但公会比我高
			ret = true
			break
		end
	end
	return ret
end

--获取可以学习新技能具体id
function GuildDataProxy:getCanLearnSkillTbl()
	local ret = {}
	local tmpList = {}
	for skill_id,v in pairs( self:getSkillDescVoList()) do
		table.insert(tmpList,skill_id)
	end
	for i=1,#tmpList do
		local guildSkillVo = self:getGuildSkillVoById( tmpList[i] )
		local meSkillVo = self:getMeSkillVoById( tmpList[i] )
		if guildSkillVo ~= nil and meSkillVo == nil then --有公会技能 没自己技能
			ret[ tmpList[ i ] ] = "done"
		elseif guildSkillVo ~= nil and meSkillVo ~= nil and guildSkillVo.lev > meSkillVo.lev then --都有技能 但公会比我高
			ret[ tmpList[ i ] ] = "done"
		end
	end
	return ret
end

--根据当前时间 获取当前 公会战处于 的阶段
function GuildDataProxy:getCurMoment(info)
	local ret = GuildFightMoment.SignupBefore
	local scheduleList = info.scheduleList

	local sceneVo = self:getGuildFightSceneVo()
	sceneVo.isMissCurFight = 0
	
	local curTime = ServerTimerManager:getInstance():getCurTime()
	if curTime < info.signup_start then   
		ret = GuildFightMoment.SignupBefore 

		if curTime > info.signup_start - 60 * 10 and 
			Utils.get_length_from_any_table(self:getMyCombatRecordVoList()) > 0 then

			ret = GuildFightMoment.BattleFinishPerpare
		end
	elseif curTime >= info.signup_start and curTime < info.signup_end then
		ret = GuildFightMoment.SignupIng

		if curTime < info.signup_start + 60 * ( 60 - 10) and 
			Utils.get_length_from_any_table(self:getAllCombatRankVoList()) > 0 then

			ret = GuildFightMoment.BattleFinish
		end
	elseif curTime >= info.signup_end then
		ret = GuildFightMoment.SignupAfter
	end

	local scheId = 0
	for i=1,#scheduleList do
		local v = scheduleList[i]
		if curTime >= v.ready_start and curTime < v.ready_end then
			ret = GuildFightMoment.SignupAfter 
			scheId = v.matches

			if sceneVo.isSignup == 1 then --是否报名
				if curTime < v.ready_start + 60 * 60 and scheId > 1 then
					ret = GuildFightMoment.BattleAfter
				end
			else
				ret = GuildFightMoment.SignupBefore 
				sceneVo.isMissCurFight = 1
			end

		elseif curTime >= v.ready_end and curTime < v.combat_start then
			if sceneVo.isSignup == 1 then --是否报名
				ret = GuildFightMoment.BattleBefore
			else
				ret = GuildFightMoment.SignupBefore 
				sceneVo.isMissCurFight = 1
			end
			scheId = v.matches

		elseif curTime >= v.combat_start and curTime < v.combat_end then --是否报名
			if sceneVo.isSignup == 1 then
				ret = GuildFightMoment.BattleIng
			else
				ret = GuildFightMoment.SignupBefore 
				sceneVo.isMissCurFight = 1
			end
			scheId = v.matches
		end
	end
	return ret,scheId
end

--检测 是否有效的时间阶段
function GuildDataProxy:checkValidScheInfo(container)
	local sceneVo = self:getGuildFightSceneVo()
	local isVis = sceneVo:getCurScheInfo() ~= nil
	if isVis then  --没找到匹配时间
		container:setVisible(true) 
		container:setPositionY(0)
	else
		container:setVisible(false) 
		container:setPositionY(-1000)
	end
	return isVis
end

--强制 隐藏/显示 面板
function GuildDataProxy:foreceVisibleView(container,isVis)

	if isVis then 
		container:setVisible(true) 
		container:setPositionY(0)
	else
		container:setVisible(false) 
		container:setPositionY(-1000)
	end
	return isVis
end
------------------清理缓存------------------------------------------
function GuildDataProxy:clearFindGuildVoList()
	for i,v in pairs(self.findGuildVoList) do
		self.findGuildVoList[i] = nil
	end
	self.findGuildVoList = {}
end

function GuildDataProxy:clearPlayerVoList()
	for i,v in pairs(self.playerVoList) do
		self.playerVoList[i] = nil
	end
	self.playerVoList = {}
end

function GuildDataProxy:clearGuildVoList()
	for i,v in pairs(self.organizVoList) do
		self.organizVoList[i] = nil
	end
	self.organizVoList = {}
end

function GuildDataProxy:clearApplyVoList()
	for k,v in pairs(self.applyVoList) do
		self.applyVoList[k] = nil
	end
	self.applyVoList = {}
end

function GuildDataProxy:clearAuctionRecordVoList()
	for i,v in pairs(self.myRecordVoList) do
		self.myRecordVoList[i] = nil
	end
	self.myRecordVoList = {}
	for i,v in pairs(self.guildRecordVoList) do
		self.guildRecordVoList[i] = nil
	end
	self.guildRecordVoList = {}
end

function GuildDataProxy:clearAuctionVoList()
	for k,v in pairs(self.auctionVoList) do
		self.auctionVoList[k] = nil
	end
	self.auctionVoList = {}
end

function GuildDataProxy:clearMyAuctionVoList()
	for k,v in pairs(self.myAuctionVoList) do
		self.myAuctionVoList[k] = nil
	end
	self.myAuctionVoList = {}
end

function GuildDataProxy:clear()
	self:clearFindGuildVoList()
	self:clearPlayerVoList()
	self:clearGuildVoList()
end
-------------------------------------------------
function GuildDataProxy:getWidgetOriganItem()
	if self.widgetOrganizItem == nil then
		self.widgetOrganizItem = GUIReader:shareReader():widgetFromJsonFile("organiz/public/OrganizItem.ExportJson")
		self.widgetOrganizItem:retain()
	end
	return self.widgetOrganizItem
end

function GuildDataProxy:getWidgetMemeberItem()
	if self.widgetMemberItem == nil then
		self.widgetMemberItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/PlayerItem.ExportJson")
		self.widgetMemberItem:retain()
	end
	return self.widgetMemberItem
end

function GuildDataProxy:getWidgetApplyItem()
	if self.widgetApplyItem == nil then
		self.widgetApplyItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/ApplyItem.ExportJson")
		self.widgetApplyItem:retain()
	end
	return self.widgetApplyItem
end

function GuildDataProxy:getWidgetGivePhysicalItem()
	if self.widgetGivePhysicalItem == nil then
		self.widgetGivePhysicalItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GiveItem.ExportJson")
		self.widgetGivePhysicalItem:retain()
	end
	return self.widgetGivePhysicalItem
end

function GuildDataProxy:getWidgetEditItem()
	if self.widgetEidtItem == nil then
		self.widgetEidtItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/EditMemberItem.ExportJson")
		self.widgetEidtItem:retain()
	end
	return self.widgetEidtItem
end

function GuildDataProxy:getWidgetRecordItem()
	if self.widgetRecordItem == nil then
		self.widgetRecordItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildRecordItem.ExportJson")
		self.widgetRecordItem:retain()
	end
	return self.widgetRecordItem
end

function GuildDataProxy:getWidgetAuctionItem()
	if self.widgetAuctionItem == nil then
		self.widgetAuctionItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildAuctionItem.ExportJson")
		self.widgetAuctionItem:retain()
	end
	return self.widgetAuctionItem
end

function GuildDataProxy:getWidgetMyAuctionItem()
	if self.widgetMyAuctionItem == nil then
		self.widgetMyAuctionItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildMyAuctionItem.ExportJson")
		self.widgetMyAuctionItem:retain()
	end
	return self.widgetMyAuctionItem
end

function GuildDataProxy:getWidgetRecordTitleItem()
	if self.widgetRecordTitleItem == nil then
		self.widgetRecordTitleItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildRecordTitleItem.ExportJson")
		self.widgetRecordTitleItem:retain()
	end
	return self.widgetRecordTitleItem
end

function GuildDataProxy:getWidgetBossItem()
	if self.widgetBossItem == nil then
		self.widgetBossItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildBossItem.ExportJson")
		self.widgetBossItem:retain()
	end
	return self.widgetBossItem
end

function GuildDataProxy:getWidgetBigBossItem()
	if self.widgetBigBossItem == nil then
		self.widgetBigBossItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildBossBigItem.ExportJson")
		self.widgetBigBossItem:retain()
	end
	return self.widgetBigBossItem
end

function GuildDataProxy:getWidgetHurtItem()
	if self.widgetHurtItem == nil then
		self.widgetHurtItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildHurtItem.ExportJson")
		self.widgetHurtItem:retain()
	end
	return self.widgetHurtItem
end

function GuildDataProxy:getWidgetFightSignupItem()
	if self.widgetFightSignupItem == nil then
		self.widgetFightSignupItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightSignupItem.ExportJson")
		self.widgetFightSignupItem:retain()
	end
	return self.widgetFightSignupItem
end

function GuildDataProxy:getWidgetLogItem()
	if self.widgetGuildLogItem == nil then
		self.widgetGuildLogItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildLogItem.ExportJson")
		self.widgetGuildLogItem:retain()
	end
	return self.widgetGuildLogItem
end

function GuildDataProxy:getWidgetFightEnemyItem()
	if self.widgetFightPlayerItem == nil then
		self.widgetFightPlayerItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightPlayerItem.ExportJson")
		self.widgetFightPlayerItem:retain()
	end
	return self.widgetFightPlayerItem
end

function GuildDataProxy:getWidgetFightAreaItem()
	if self.widgetFightAreaItem == nil then
		self.widgetFightAreaItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightAreaItem.ExportJson")
		self.widgetFightAreaItem:retain()
	end
	return self.widgetFightAreaItem
end

function GuildDataProxy:getWidgetSignupListItem()
	if self.widgetSignupListItem == nil then
		self.widgetSignupListItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightSignupListItem.ExportJson")
		self.widgetSignupListItem:retain()
	end
	return self.widgetSignupListItem
end

function GuildDataProxy:getWidgetFightScheItem()
	if self.widgetFightScheItem == nil then
		self.widgetFightScheItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightScheItem.ExportJson")
		self.widgetFightScheItem:retain()
	end
	return self.widgetFightScheItem
end

function GuildDataProxy:getWidgetFightScoreItem()
	if self.widgetFightScoreItem == nil then
		self.widgetFightScoreItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightScoreItem.ExportJson")
		self.widgetFightScoreItem:retain()
	end
	return self.widgetFightScoreItem
end

function GuildDataProxy:getWidgetGloryGiftItem()
	if self.widgetGloryGiftItem == nil then
		self.widgetGloryGiftItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightGloryGiftItem.ExportJson")
		self.widgetGloryGiftItem:retain()
	end
	return self.widgetGloryGiftItem
end

function GuildDataProxy:getWidgetGloryLogItem()
	if self.widgetGloryLogItem == nil then
		self.widgetGloryLogItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightGloryLogItem.ExportJson")
		self.widgetGloryLogItem:retain()
	end
	return self.widgetGloryLogItem
end

function GuildDataProxy:getWidgetGloryLogTitleItem()
	if self.widgetGloryLogTitleItem == nil then
		self.widgetGloryLogTitleItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightGloryLogTitle.ExportJson")
		self.widgetGloryLogTitleItem:retain()
	end
	return self.widgetGloryLogTitleItem
end

function GuildDataProxy:getWidgetGloryRankItem()
	if self.widgetGloryRankItem == nil then
		self.widgetGloryRankItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightGloryRankItem.ExportJson")
		self.widgetGloryRankItem:retain()
	end
	return self.widgetGloryRankItem
end

function GuildDataProxy:getWidgetMemberRankItem()
	if self.widgetMemberRankItem == nil then
		self.widgetMemberRankItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightMemberRankItem.ExportJson")
		self.widgetMemberRankItem:retain()
	end
	return self.widgetMemberRankItem
end

function GuildDataProxy:getWidgetFightSituationItem()
	if self.widgetFightSituationItem == nil then
		self.widgetFightSituationItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightHistoryItem.ExportJson")
		self.widgetFightSituationItem:retain()
	end
	return self.widgetFightSituationItem
end

function GuildDataProxy:getWidgetFightSituationTitleItem()
	if self.widgetFightSituationTitleItem == nil then
		self.widgetFightSituationTitleItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightHistoryTitleItem.ExportJson")
		self.widgetFightSituationTitleItem:retain()
	end
	return self.widgetFightSituationTitleItem
end

function GuildDataProxy:getWidgetRankPowerItem()
	if self.widgetFightRankPowerItem == nil then
		self.widgetFightRankPowerItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightRankPowerItem.ExportJson")
		self.widgetFightRankPowerItem:retain()
	end
	return self.widgetFightRankPowerItem
end

function GuildDataProxy:getWidgetRankGiftItem()
	if self.widgetFightRankGiftItem == nil then
		self.widgetFightRankGiftItem = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightRankGiftItem.ExportJson")
		self.widgetFightRankGiftItem:retain()
	end
	return self.widgetFightRankGiftItem
end

--预加载 控件
function GuildDataProxy:reloadWidget(t)
	
	local rm = GuildRenderMgr:getInstance()

	if t == GuildFightWidget.FightPlayer then
		for i=1,4 do
			local key = string.format("fightplayer_%d",i)
			if rm.dic:objectForKey(key) == nil then
				rm.dic:setObject(GuildFightPlayerItem:create(),key)
			end
		end
	elseif t == GuildFightWidget.FightArea then
		for i=1,4 do
			local key = string.format("fightarea_%d",i)
			if rm.dic:objectForKey(key) == nil then
				rm.dic:setObject(GuildFightAreaTitle:create(),key)
			end
		end
	end
end
-------------------------主界面快捷方式 处理--------------------------------------
--缓存
function GuildDataProxy:saveGuildFightRule(info)
	-- print("saveGuildFightRule !!!!!!!!!!",info.guild_id , info.is_signup , info.other_name )
	self.short_fight_news_enter = info.entrance_green
	self.short_fight_issignup = info.is_signup
	-- print(" self.short_fight_news_enter ",self.short_fight_news_enter,self.short_fight_issignup)
	--debug
	-- self.short_fight_news_enter = 1
	-- self.short_fight_issignup = 0

	if info.guild_id > 0 and info.is_signup > 0 and info.other_name ~= "" then
		self.short_fightRule = info.rule
		self.short_fight_news = info.is_green

		-- print(" info.is_green", info.is_green)
		
		self:makeGuildFightRule()
	end
end

function GuildDataProxy:checkGuildNewsTips()
	if self.short_fight_issignup == 0 and self.short_fight_news_enter > 0 or 
	 	self.myauction_news > 0 or
	 	self.fight_reward_news > 0 then
		Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.guild)
	else
		Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.guild)
	end
end

--赋值
function GuildDataProxy:makeGuildFightRule()
	
	self.guildFightScheduleList = {}

	for i=1,#self.short_fightRule.matches do
		local v = self.short_fightRule.matches[i]
		local sche = {}
		sche.matches = v.matches
		sche.ready_start = v.ready_start 
		if sche.matches == 1 then --第一场匹配结果延时1分钟（因为服务器生成对手要时间...）
			sche.ready_start = sche.ready_start + 60
		end
		sche.ready_end = v.ready_end
		sche.combat_start = v.combat_start
		sche.combat_end = v.combat_end

		print(" 場次 ",sche.matches)
		print(" 開始備戰 ",os.date("%Y/%m/%d %X",sche.ready_start))
		print(" 結束備戰 ",os.date("%Y/%m/%d %X",sche.ready_end))
		print(" 開始戰鬥 ",os.date("%Y/%m/%d %X",sche.combat_start))
		print(" 結束戰鬥 ",os.date("%Y/%m/%d %X",sche.combat_end))

		table.insert(self.guildFightScheduleList,sche)
	end

end

function GuildDataProxy:getCurGuildFightViewRes()
	return self.curGuildFightViewRes
end

--处理主界面 定时器
function GuildDataProxy.progressSchedule()

	local dp = GuildDataProxy:getInstance()
	local isVis = false
	local scheduleList = dp.guildFightScheduleList
	if scheduleList and #scheduleList > 0 then
		local curTime = ServerTimerManager:getInstance():getCurTime()
		--debug
		-- local curTime = os.time({year=2015,month=4,day=20, hour=20, min=30, sec=0})
		-- dp.short_isSignup = 1

		print("當前伺服器時間：",os.date("%Y/%m/%d %X",curTime))
		local scheId = 0
		for i=1,#scheduleList do
			local v = scheduleList[i]
			if curTime >= v.ready_start and curTime < v.ready_end then
				-- ret = GuildFightMoment.SignupAfter
				dp.curGuildFightViewRes = "i18n_guild_fight_perpareing" 
				scheId = v.matches
				isVis = true

				if curTime < v.ready_start + 60 * 60 and scheId > 1 then
					-- ret = GuildFightMoment.BattleAfter
					dp.curGuildFightViewRes = "i18n_guild_fight_perpareing" 
					isVis = true
				end
			elseif curTime >= v.combat_start and curTime < v.combat_end then --是否报名
				-- ret = GuildFightMoment.BattleIng
				dp.curGuildFightViewRes = "i18n_guild_battle"
				isVis = true
				scheId = v.matches
			end
		end

		if isVis then
			if dp.short_fight_news == 1 then --是否显示绿点
				dp.short_fight_news = 0
				Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.mainui_guild_fight)
			end
			Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_ICON,NewTipsEnum.mainui_guild_fight)
		else
			dp.short_fight_news = 0
			Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.mainui_guild_fight)
			Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_ICON,NewTipsEnum.mainui_guild_fight)
		end
	end

	dp:checkGuildNewsTips()
end
-------------------------------------------------------------
-- 获取当前 焦点日程
function GuildDataProxy:getFightCurFocusScheId()
	local ret = -1
	local dp = GuildDataProxy:getInstance()
    local sceneVo = dp:getGuildFightSceneVo()
    local checkMonet = GuildFightMoment.SignupBefore
    if sceneVo.curMoment == GuildFightMoment.SignupBefore or 
        sceneVo.curMoment == GuildFightMoment.SignupIng then

        checkMonet = GuildFightMoment.SignupIng
    elseif sceneVo.curMoment == GuildFightMoment.SignupAfter or
            sceneVo.curMoment == GuildFightMoment.BattleAfter then

        checkMonet = GuildFightMoment.SignupAfter
    elseif sceneVo.curMoment == GuildFightMoment.BattleBefore then

        checkMonet = GuildFightMoment.BattleBefore
    elseif sceneVo.curMoment == GuildFightMoment.BattleIng then

        checkMonet = GuildFightMoment.BattleIng
    elseif checkMonet == GuildFightMoment.BattleFinish or
            checkMonet == GuildFightMoment.BattleFinishPerpare then

        checkMonet = GuildFightMoment.BattleFinish
    end
-------------------------------------------------------------------
	for k,v in pairs(self.fightScheVoList) do
		if checkMonet == v.monent and 
	        sceneVo.curScheId == v.session and 
	        checkMonet ~= GuildFightMoment.SignupIng then

	        ret = v.id 
	    end
	end
	return ret
end