--会长权限 面板

PermissionScene = class("PermissionScene",WindowBase)
PermissionScene.__index = PermissionScene
PermissionScene._widget     = nil
PermissionScene.uiLayer    = nil
PermissionScene.settingIdx = 1 -- 选择公会类型 下标

local __instance = nil

function PermissionScene:create()
    local ret = PermissionScene.new()
    __instance = ret
    return ret   
end
--------------------响应事件-----------------------------------
local btnLast = nil
local panelLast = nil

local panelApply = nil

local panelMember = nil
local panelEditMember = nil

local panelOrganiz = nil
local panelLogo = nil
local inputDesc = nil
local labFreeLevel = nil
local imgLogo = nil
local btnActive = nil
local btnPushLevel = nil
local btnAdd = nil
local btnMin = nil

local panelMail = nil

local listApply = nil
local listEditMember = nil

local _freeLevel = 0
local _iconId = 1

local function event_btn_close(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
         WinCtrl:getInstance():closeWinByName(CmdName.Guild_View_Permission) 
    end
end

local function event_btn_organiz(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        
        panelOrganiz:setVisible(true)
        panelOrganiz:setZOrder(4)

       local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if btnLast ~= btn then
            btnLast:setFocused(false)
            btnLast:setTitleColor(ccc3(245,204,85))
            btnLast = btn
            
            --刷新全数据
            GuildNetTask:getInstance():requestMemberItems()

            panelLast:setVisible(false)
            panelLast:setZOrder(3)
            panelLast = panelOrganiz

        end
    end
end

local function event_btn_apply(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        
        local voList = CharacterManager:getInstance():getBaseData():getNewsTipList()
        if voList[ NewTipsEnum.guild_apply ] == 0 then  --0 显示  1 不显示
            GuildNetTask:getInstance():requestCheckApplyTips()
        end

        panelApply:setVisible(true)
        panelApply:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if btnLast ~= btn then
            btnLast:setFocused(false)
            btnLast:setTitleColor(ccc3(245,204,85))
            btnLast = btn
        
            GuildNetTask:getInstance():requestMemberItems()

            panelLast:setVisible(false)
            panelLast:setZOrder(3)
            panelLast = panelApply
            --渲染申请列表
            GuildRenderMgr.renderApplyList(listApply)
        end
    end
end

local function event_btn_member(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
     
        panelMember:setVisible(true)
        panelMember:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if btnLast ~= btn then
            btnLast:setFocused(false)
            btnLast:setTitleColor(ccc3(245,204,85))
            btnLast = btn
            
            -- --刷新全数据
            GuildNetTask:getInstance():requestMemberItems()
            panelLast:setVisible(false)
            panelLast:setZOrder(3)
            panelLast = panelMember
            --请求 成员管理 面板
            Notifier.dispatchCmd(OrganizEvent.MSG_EDIT_MEMBER_ITEM)
        end
    end
end

local function event_btn_mail(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 

        panelMail:setVisible(true)
        panelMail:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if btnLast ~= btn then
            btnLast:setFocused(false)
            btnLast:setTitleColor(ccc3(245,204,85))
            btnLast = btn
        
            panelLast:setVisible(false)
            panelLast:setZOrder(3)
            panelLast = panelMail

        end
    end
end

----------------------公会管理----------------------------------------------------------------
local function event_btn_editicon(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 

        WindowCtrl:getInstance():open(CmdName.Guild_View_LogoPanel_edit,
        {okCallFunc = 
            function(iconId)
                imgLogo:setId(iconId) 
                _iconId = iconId
            end
        })
    end
end

local function event_btn_pushedit(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 

        GuildNetTask:getInstance():requestEditGuildSetting(
            _freeLevel,_iconId,inputDesc:getStringValue())
    end
end

local function event_btn_levup(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        local dp = GuildDataProxy:getInstance()
        local sceneVo = dp:getGuildSceneVo()
        if  sceneVo.donateTotal <  __instance.levupCost then
            Alert:show("公會資金不足")
        else
            WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,
                {okFunc = function()
                    GuildNetTask:getInstance():requestGuildLevup()
                end, txt = string.format("是否消耗%d公會資金提升公會等級至%d級?",
                    __instance.levupCost,sceneVo.lev + 1)})
        end
    end
end


local function event_btn_add(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        local dp = GuildDataProxy:getInstance()
        __instance.settingIdx = math.min( __instance.settingIdx + 1 ,#dp:getQuickJoinVoList())
        _freeLevel = dp:getQuickJoinVoById(__instance.settingIdx).lev
        __instance:updateGuildType()
    end
end

local function event_btn_min(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        local dp = GuildDataProxy:getInstance()
        __instance.settingIdx = math.max( __instance.settingIdx - 1 ,1)
        _freeLevel = dp:getQuickJoinVoById(__instance.settingIdx).lev
        __instance:updateGuildType()
    end
end
-----------------------群发邮件---------------------------------------------------------------
local function event_send_mail(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        local txt = __instance.inputMail:getStringValue()
        if string.len(txt) <= 0 then
            Alert:show("請輸入內容")
        else
            if __instance.costMail == 0 then
                GuildNetTask:getInstance():requestGuildMail( txt )
            else
                WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,
                {okFunc = function()
                    GuildNetTask:getInstance():requestGuildMail( txt )
                end, txt = string.format("是否花費%d鑽石群發郵件?",
                    __instance.costMail)})
            end
        end

    end
end
----------------------初始化-----------------------------------------------------------
function PermissionScene:init()
    require "LogoPanel"
    require "EditMember"
    require "GuildIcon"

    ItemManager:getInstance():loadItemIconPlist()
    HeroManager:getInstance():loadSkillIconPlist()
    
    --加载纹理
    ComResMgr:getInstance():loadOtherRes()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/Permission.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    local btnOrganiz = tolua.cast(self.uiLayer:getWidgetByName("btn_organiz"),"Button")
    btnLast = btnOrganiz  
    btnOrganiz:setFocused(true)
    btnOrganiz:setTitleColor(ccc3(210,253,238))
    btnOrganiz:addTouchEventListener(event_btn_organiz)

    local btnApply = tolua.cast(self.uiLayer:getWidgetByName("btn_apply"),"Button")
    btnApply:addTouchEventListener(event_btn_apply)

    local btnMember = tolua.cast(self.uiLayer:getWidgetByName("btn_member"),"Button")
    btnMember:addTouchEventListener(event_btn_member)

    self.btnMail = tolua.cast(self.uiLayer:getWidgetByName("btn_mail"),"Button")
    self.btnMail:addTouchEventListener(event_btn_mail)

    panelOrganiz = tolua.cast(self.uiLayer:getWidgetByName("panel_organiz"),"Layout")
    panelApply = tolua.cast(self.uiLayer:getWidgetByName("panel_apply"),"Layout")
    panelMember = tolua.cast(self.uiLayer:getWidgetByName("panel_member"),"Layout")
    panelMail = tolua.cast(self.uiLayer:getWidgetByName("panel_mail"),"Layout")
    panelLast = panelOrganiz

    ----------------------公会管理----------------------------------------------------------------
    local btnEditIcon = tolua.cast(self.uiLayer:getWidgetByName("btn_editicon"),"Button")
    btnEditIcon:addTouchEventListener(event_btn_editicon)

    local btnPushEdit = tolua.cast(self.uiLayer:getWidgetByName("btn_pushedit"),"Button")
    btnPushEdit:addTouchEventListener(event_btn_pushedit)

    self.btnLevup = tolua.cast(self.uiLayer:getWidgetByName("btn_levup"),"Button")
    self.btnLevup:addTouchEventListener(event_btn_levup)

    self.panelCost = tolua.cast(self.uiLayer:getWidgetByName("panel_cost"),"Layout")
    self.panelTotal = tolua.cast(self.uiLayer:getWidgetByName("panel_total"),"Layout")
    self.labTipLev = tolua.cast(self.uiLayer:getWidgetByName("lab_tiplev"),"Label")
    self.labLev = tolua.cast(self.uiLayer:getWidgetByName("lab_lev"),"Label")
    self.labContributeCost = tolua.cast(self.uiLayer:getWidgetByName("lab_contributeCost"),"Label")
    self.labContributeTotal = tolua.cast(self.uiLayer:getWidgetByName("lab_contributeTotal"),"Label")
    labFreeLevel = tolua.cast(self.uiLayer:getWidgetByName("lab_freelevel"),"Label")
    inputDesc = tolua.cast(self.uiLayer:getWidgetByName("input_desc"),"TextField")

    btnAdd = tolua.cast(self.uiLayer:getWidgetByName("btn_add"),"Button")
    btnAdd:addTouchEventListener(event_btn_add)

    btnMin = tolua.cast(self.uiLayer:getWidgetByName("btn_min"),"Button")
    btnMin:addTouchEventListener(event_btn_min)

    imgLogo = GuildIcon:create()
    imgLogo:setPosition(ccp(230,275))
    panelOrganiz:getChildByName("scrol_view"):addChild(imgLogo)

    ----------------------申请管理----------------------------------------------------------------
    listApply = tolua.cast(panelApply:getChildByName("list_apply"),"ListView")
    ----------------------成员管理----------------------------------------------------------------
    self.scrolEdit = DisplayUtil.createAdaptScrollView(880,360,140,0,1)

    panelMember:addChild(self.scrolEdit,10)
    ----------------------邮件发送---------------------------------------------------------------------
    self.inputMail = tolua.cast(panelMail:getChildByName("input_mail"),"TextField")
    self.labMailCost = tolua.cast(self.uiLayer:getWidgetByName("lab_cost"),"Label")
    self.btnSendMail = tolua.cast(panelMail:getChildByName("btn_send"),"Button")
    self.btnSendMail:addTouchEventListener(event_send_mail)
    self.paneViewMail = tolua.cast(panelMail:getChildByName("panel_view"),"Layout")
    self.labTipMail = tolua.cast(self.uiLayer:getWidgetByName("lab_tipmail"),"Label")

    --注册事件
    Notifier.regist(OrganizEvent.CB_AGREE_IGNORE_ORGANIZ,function() GuildRenderMgr.renderApplyList(listApply) end)
    Notifier.regist(OrganizEvent.MSG_EDIT_MEMBER_ITEM,function()

        GuildRenderMgr:getInstance():renderEditMemberListAdapt(self.scrolEdit)

        self.scrolEdit:stopAllActions()
        self.scrolEdit:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolEdit:getInnerContainer():getPositionY()
                local viewRect = CCRectMake(0,math.abs(viewY),880,360)
                GuildRenderMgr:getInstance():refreshViewEditVoList(viewRect,self.scrolEdit)
            end),
            CCDelayTime:create(0.1))))

    end)
    Notifier.regist(OrganizEvent.MSG_UPDATE_PREMISSION,function() self:update() end)
    Notifier.regist(OrganizEvent.MSG_UPDATE_NEW_TIPS_HIDE,function(key) self:hideNewsTip(key) end) 
end

function PermissionScene._refreshScrolEdit(scrol)

    local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),880,360)

    -- GuildRenderMgr:getInstance():refreshViewEditVoList(viewRect,scrol)
end

function PermissionScene:update()
	
    local guildVo = CharacterManager:getInstance():getGuildData()
    inputDesc:setText(guildVo:getDesc())

    local dp = GuildDataProxy:getInstance()
    local settingVo = dp:getQuickJoinVoByLev( guildVo:getFree() )
    if settingVo then
       self.settingIdx = settingVo.id
    else
        self.settingIdx = 2
    end

    _iconId = guildVo:getLogoId() or 1
    imgLogo:setId(guildVo:getLogoId()) 

    local isMaster = OrganizHelper.isMaster( OrganizHelper.getCurPlayerVo() ) 

    self.btnMail:setTouchEnabled(isMaster) --只有会长 能群发邮件
    self.btnMail:setVisible(isMaster)

    local sceneVo = dp:getGuildSceneVo()
    local levMax = Utils.get_length_from_any_table(dp:getLevupCostVoList())
    self.labContributeTotal:setText(sceneVo.donateTotal)
    self.labLev:setText(sceneVo.lev)
    if sceneVo.lev >= levMax then
        self.btnLevup:setTouchEnabled(false)
        self.btnLevup:setVisible(false)
        self.panelCost:setVisible(false)
        self.panelTotal:setPositionY(425)
    else
        self.btnLevup:setTouchEnabled(true and isMaster)--只有会长 能升级公会
        self.btnLevup:setVisible(true and isMaster)
        self.panelCost:setVisible(true)
        self.panelTotal:setPositionY(400)
        local costVo = dp:getLevupCostVoById(math.min(sceneVo.lev + 1,12))
        self.levupCost = costVo.coin
        self.labContributeCost:setText(costVo.coin)
    end

    local mailMax = Utils.get_length_from_any_table(dp:getMailCostVoList())
    if sceneVo.mailNum >= mailMax then
        self.labTipMail:setVisible(true)
        self.paneViewMail:setVisible(false)
    else
        local costMailVo = dp:getMailCostVoById( math.min(sceneVo.mailNum + 1,10)) 
        self.costMail = costMailVo.cost
        if costMailVo.cost == 0 then
            self.labMailCost:setText("免費")
        else
            self.labMailCost:setText(costMailVo.cost)
        end
        self.labTipMail:setVisible(false)
        self.paneViewMail:setVisible(true)
    end

    self.inputMail:setText("")

    self:updateGuildType()
end

function PermissionScene:open()
    if self.params then
        local isShow = self.params["isShowTip"]
        if isShow == 0 then
            self:showNewsTip(NewTipsEnum.guild_apply)
        end
    end
    self:update()
end

function PermissionScene:getInstance()
    return __instance
end

function PermissionScene:updateGuildType()
    local dp = GuildDataProxy:getInstance()
    if self.settingIdx == 1 then
        labFreeLevel:setText("需驗證加入")
    else
        labFreeLevel:setText(string.format("%d級直接進入",dp:getQuickJoinVoById( self.settingIdx ).lev))
    end
end

function PermissionScene:removeAllTimer()
    TimerManager.removeTimer(PermissionScene:getInstance()._refreshScrolEdit)
end

function PermissionScene:close()

    local btnOrganiz = tolua.cast(self.uiLayer:getWidgetByName("btn_organiz"),"Button")
    event_btn_organiz(btnOrganiz,ComConstTab.TouchEventType.ended)

    TimerManager.removeTimer(PermissionScene:getInstance()._refreshScrolEdit)
    WindowCtrl:getInstance():open(CmdName.Guild_View_Member)
end


function PermissionScene:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

-- 隐藏 新消息 提示
function PermissionScene:hideNewsTip(key)
    local target = nil
    if key == NewTipsEnum.guild_apply then
        target = self.uiLayer:getWidgetByName("btn_apply")
    end
    if target and target:getChildByTag(2866) ~= nil then
        target:removeChildByTag(2866,true)
    end
end

-- 展示 新消息 提示
function PermissionScene:showNewsTip(key)
    local target = nil
    local pos = nil
    if key == NewTipsEnum.guild_apply then
        target = self.uiLayer:getWidgetByName("btn_apply")
        pos = ccp(55,20)
    end
    if target and target:getChildByTag(2866) == nil then
        local tips_img = ImageView:create()
        tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
        tips_img:setTag(2866)
        tips_img:setPosition(pos)
        target:addChild(tips_img)
        self:tipsPointPlayAct(tips_img)
    elseif target and target:getChildByTag(2866) ~= nil then
        local tips_img = target:getChildByTag(2866)
        self:tipsPointPlayAct(tips_img)
    end
end
