-- 公会Boss 开启 面板
GuildBossOpen = class("GuildBossOpen",WindowBase)
GuildBossOpen.__index = GuildBossOpen
GuildBossOpen._widget     = nil
GuildBossOpen.uiLayer    = nil
GuildBossOpen.is_dispose = true

local __instance = nil

function GuildBossOpen:create()
    local ret = GuildBossOpen.new()
    __instance = ret
    return ret   
end

function GuildBossOpen:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end

function GuildBossOpen:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildBossOpen.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            if GuildDataProxy:getInstance():getGuildSceneVo().donateTotal < self.bossVo.cost_donate then
                Alert:show("公會資金不足")
                return
            end

            if self.bossVo.hp > 0 and self.bossVo.isActive == 1 then
                WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()

                    GuildNetTask:getInstance():requestActivateBoss(self.boss_id)
                    
                end, txt = "重置BOSS後會刷新BOSS的挑戰進度以及清空BOSS的傷害排行，確定要重置BOSS進度嗎？"})
            else
                GuildNetTask:getInstance():requestActivateBoss(self.boss_id)
            end
        end
    end)

    require "MonsterIcon"
    require "MonsterInfoPanel"
    self.monsterIcon = MonsterIcon:create()
    self.monsterIcon:setPosition(ccp(450,384))
    self.monsterIcon:setClickEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                MonsterInfoPanel:show(pSender:getTag())

            elseif eventType == ComConstTab.TouchEventType.ended or
                    eventType == ComConstTab.TouchEventType.canceled then
                MonsterInfoPanel:hide()
            end
        end)
    self._widget:addChild(self.monsterIcon)

    self.labDonate = tolua.cast(self._widget:getChildByName("lab_donate"),"Label")
    self.labCost = tolua.cast(self._widget:getChildByName("lab_cost"),"Label")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labTips = tolua.cast(self._widget:getChildByName("lab_tips"),"Label")
end

function GuildBossOpen:open()

	self.boss_id = self.params["boss_id"]
    local monstorMode = MonsterManager:getInstance():getBaseInfo(self.boss_id)
    
    self.monsterIcon:setMonsterId(self.boss_id)
    self.monsterIcon.icon_img:setTag(self.boss_id)

    local dp = GuildDataProxy:getInstance()
    local bossVo = dp:getBossVoById(self.boss_id)
    self.bossVo = bossVo

    self.labName:setText(monstorMode.name)
    self.labDonate:setText(dp:getGuildSceneVo().donateTotal)
    self.labCost:setText(bossVo.cost_donate)

    local guildData = CharacterManager:getInstance():getGuildData()

    self.btnOk:setTouchEnabled(true)
    self.btnOk:setBright(true)
    self.labTips:setVisible(false)

    if bossVo.isActive == 1 then
        self.btnOk:setTitleText("重置")
    else
        self.btnOk:setTitleText("開啟")
    end

    local bossLastVo = dp.bossVoTblList[ bossVo.idx - 1 ]

    if bossVo.isActive == 1 then
        --已激活不用管
    elseif GuildDataProxy:getInstance():getGuildSceneVo().lev < bossVo.guild_lev then --是否满足等级
        self.labTips:setVisible(true)
        self.labTips:setText(string.format("公會%d級可開啟挑戰",bossVo.guild_lev))
        self.btnOk:setVisible(false)
        self.btnOk:setTouchEnabled(false)
    elseif bossLastVo and bossLastVo.hp ~= 0 and bossLastVo.hadBeenFight == 0 then
        self.labTips:setVisible(true)
        self.labTips:setText("擊殺上一個BOSS後可開啟")
        self.btnOk:setVisible(false)
        self.btnOk:setTouchEnabled(false)   
    elseif bossVo.active_num >= 1 then
        self.labTips:setVisible(true)
        self.labTips:setText("該BOSS今日重置次數已滿")
        self.btnOk:setVisible(false)
        self.btnOk:setTouchEnabled(false)   
    end
end

function GuildBossOpen:close()

end