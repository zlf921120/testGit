--公会Boss 说明 面板
GuildBossDesc = class("GuildBossDesc",WindowBase)
GuildBossDesc.__index = GuildBossDesc
GuildBossDesc._widget     = nil
GuildBossDesc.uiLayer    = nil
GuildBossDesc.is_dispose = true

local __instance = nil

function GuildBossDesc:create()
    local ret = GuildBossDesc.new()
    __instance = ret
    return ret   
end

function GuildBossDesc:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end

local function event_btn_close(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		__instance:addCloseAnim()
	end
end

function GuildBossDesc:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("tower/dialog/TowerDesc.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

	local labDesc = tolua.cast(self._widget:getChildByName("lab_desc"),"Label")
	labDesc:setText(OrganizCfg.BossInfo)

	local btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
	btnClose:addTouchEventListener(event_btn_close)

	local labTitle = tolua.cast(self._widget:getChildByName("lab_title"),"Label")
	labTitle:setText("公會Boss")
end

function GuildBossDesc:open()
	self:isShowBg(false)
	self:isShowReturnBtn(false)

	self:addOpenAnim()
end

