------------------------------------------------------------------
--公会战 预览分配物品 面板
GuildFightPerviewGiftView = class("GuildFightPerviewGiftView",WindowBase)
GuildFightPerviewGiftView.__index = GuildFightPerviewGiftView
GuildFightPerviewGiftView._widget     = nil
GuildFightPerviewGiftView.uiLayer = nil
GuildFightPerviewGiftView.is_dispose = true

function GuildFightPerviewGiftView:create()
    local ret = GuildFightPerviewGiftView.new()
    return ret   
end

function GuildFightPerviewGiftView:dispose()
	if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
end

function GuildFightPerviewGiftView:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightPerviewGiftView.ExportJson")
     self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    require "ItemInfoPanel"
    require "ItemIcon"

    self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():close(self.name)
	    end
	end)

	self.scrollView = DisplayUtil.createAdaptScrollView(664,310,105,0,4)
	self.scrollView:setPosition(ccp(154,132))
	self._widget:addChild(self.scrollView,3)
end

function GuildFightPerviewGiftView:open()

	local reward_list = self.params["reward_list"]

	self.scrollView:setScrollHeight(math.max(2,#reward_list))

	local function progress()

		local function createPosArr( len )
			local col = 4
			local row = math.max(2, math.ceil(len / 4))
			local ret = {}

			local baseX = 70
			local baseY = 60

			local idx = 0
			for i=0,row - 1 do

				for j=0,col - 1 do
					idx = idx + 1

					local height = 100
					local width = 130

					table.insert(ret, { x = baseX + j * width , y = baseY + (row - i - 1) * height })
				end
			end
			return ret
		end

		local pos = createPosArr( #reward_list )

		local idx = 0
		local function step_create()
			idx = idx + 1
			local itemVo = reward_list[idx]
			if itemVo ~= nil then
				local item = ItemIcon:create()
				item:setBaseId(itemVo.base_id)
				item:setScale(0.9)
				item:setItemNum(itemVo.quantity)
				item:setPosition(ccp(pos[idx].x,pos[idx].y))
				item:getClickImg():setTag( itemVo.base_id )
		        item:setTouchEvent(function(pSender,eventType)
		            if eventType == ComConstTab.TouchEventType.began then
		                
		                ItemInfoPanel:show(pSender:getTag())
		            elseif eventType == ComConstTab.TouchEventType.ended or
		                eventType == ComConstTab.TouchEventType.canceled then
		                ItemInfoPanel:hide()
		            end
		        end)
				self.scrollView:getInnerContainer():addChild(item)
			else
				self.scrollView:stopAllActions()
			end
		end

		self.scrollView:stopAllActions()
		self.scrollView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
			CCCallFunc:create(step_create),
			CCDelayTime:create(0.05))))
	end

	progress()
end

function GuildFightPerviewGiftView:close()

	self.scrollView:removeAllChildren()
end
