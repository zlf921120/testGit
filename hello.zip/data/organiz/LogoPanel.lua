
-- 公会 创建图标 面板
OrganizLogoCreate = class("OrganizLogoCreate",WindowBase)
OrganizLogoCreate.__index = OrganizLogoCreate
OrganizLogoCreate._widget 	= nil
OrganizLogoCreate.uiLayer = nil
OrganizLogoCreate.is_dispose = true

local __instanceCreate = nil
local _logoIdCreate = 1

function OrganizLogoCreate:create()
    local ret = OrganizLogoCreate.new()
    __instanceCreate = ret
    return ret
end

function OrganizLogoCreate:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end
------------------响应事件-------------------------------------------------

local selectImgCreate = nil

local function event_btn_ok_create(sender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        Notifier.dispatchCmd(OrganizEvent.MSG_CHOICE_LOGO,_logoIdCreate)
         __instanceCreate:addCloseAnim()
    end
end

local function event_btn_close_create(sender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        __instanceCreate:addCloseAnim()
    end
end

local function event_btn_logo_create(sender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        -- local btn = tolua.cast(sender,"Button")
        _logoIdCreate = sender:getTag()
        Notifier.dispatchCmd(OrganizEvent.MSG_CHOICE_LOGO,_logoIdCreate)
        -- selectImgCreate:setPosition(ccp(sender:getPositionX()+30,sender:getPositionY()-30))
        selectImgCreate:setPosition(ccp(sender:getParent():getPositionX()+30,
                                        sender:getParent():getPositionY()-30))
    end
end

-----------------初始化----------------------------------------------------
function OrganizLogoCreate:init()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/public/dialog/LogoPanel.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    local btnOk = tolua.cast(self.uiLayer:getWidgetByName("btn_ok"),"Button")
    btnOk:addTouchEventListener(event_btn_ok_create)

    local btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    btnClose:addTouchEventListener(event_btn_close_create)
    
    local scrolLogo = tolua.cast(self.uiLayer:getWidgetByName("scrol_logo"),"ScrollView")

    selectImgCreate = scrolLogo:getChildByName("img_select")

    local function createPosArr(len)
        local col = 6
        local row = math.ceil(len / col)
        local ret = {}

        local baseX = 50
        local baseY = 50

        local idx = 0
        for i=0,row - 1 do

            for j=0,col - 1 do
                idx = idx + 1

                local height = 107
                local width = 107

                table.insert(ret, { x = baseX + j * width , y = baseY + (row - i - 1) * height })
            end
        end
        return ret
    end

    local posArr = createPosArr(30)

    local arr = CCArray:create()
    for i=1,30 do
        arr:addObject(CCDelayTime:create(0.1))
        arr:addObject(CCCallFunc:create(function()
            local icon = GuildIcon:create()
            icon:setId(i)
            icon:getClickImg():setTag(i)
            icon:setPosition(ccp(posArr[i].x,posArr[i].y))
            icon:setClickEvent(event_btn_logo_create)
            scrolLogo:addChild(icon)
        end))
    end

    for i=1,30 do
        if scrolLogo:getChildByTag(i) ~= nil then
            scrolLogo:removeChildByTag(i,true)
        end
    end
    scrolLogo:stopAllActions()
    scrolLogo:runAction(CCSequence:create(arr))
end

function OrganizLogoCreate:open()
    self:addOpenAnim()
end

---------------------------------------------------------------------------------------
-- 公会 修改图标 面板
OrganizLogoEdit = class("OrganizLogoEdit",WindowBase)
OrganizLogoEdit.__index = OrganizLogoEdit
OrganizLogoEdit._widget   = nil
OrganizLogoEdit.uiLayer = nil
OrganizLogoEdit.is_dispose = true

local __instanceEdit = nil
local _logoIdEdit = 1

function OrganizLogoEdit:create()
    local ret = OrganizLogoEdit.new()
    __instanceEdit = ret
    return ret
end

function OrganizLogoEdit:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end
------------------响应事件-------------------------------------------------

local selectImgEdit = nil

local function event_btn_ok_edit(sender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        __instanceEdit:addCloseAnim()

        if __instanceEdit._okCallFnc ~= nil then
            __instanceEdit._okCallFnc(_logoIdEdit)
        end
    end
end

local function event_btn_close_edit(sender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
       __instanceEdit:addCloseAnim()

        -- if __instanceEdit._okCallFnc ~= nil then
        --     __instanceEdit._okCallFnc(_logoIdEdit)
        -- end
    end
end

local function event_btn_logo_edit(sender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        _logoIdEdit = sender:getTag()

        selectImgEdit:setPosition(ccp(sender:getParent():getPositionX()+30,
                                        sender:getParent():getPositionY()-30))
    end
end

function OrganizLogoEdit:open()
    -- local logoId = CharacterManager:getInstance():getGuildData():getLogoId()
    local scrolLogo = tolua.cast(self.uiLayer:getWidgetByName("scrol_logo"),"ScrollView")
    -- local btn = tolua.cast(scrolLogo:getChildByName(string.format("btn_logo%d",logoId)),"Button")
    -- selectImgEdit:setPosition(ccp(btn:getPositionX()+30,btn:getPositionY()-30))

    self._okCallFnc = self.params["okCallFunc"]

    self:addOpenAnim()
end

-----------------初始化----------------------------------------------------
function OrganizLogoEdit:init()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/public/dialog/LogoPanel.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    local btnOk = tolua.cast(self.uiLayer:getWidgetByName("btn_ok"),"Button")
    btnOk:addTouchEventListener(event_btn_ok_edit)

    local btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    btnClose:addTouchEventListener(event_btn_close_edit)
    
    local scrolLogo = tolua.cast(self.uiLayer:getWidgetByName("scrol_logo"),"ScrollView")

    selectImgEdit = scrolLogo:getChildByName("img_select")

    local function createPosArr(len)
        local col = 6
        local row = math.ceil(len / col)
        local ret = {}

        local baseX = 50
        local baseY = 50

        local idx = 0
        for i=0,row - 1 do

            for j=0,col - 1 do
                idx = idx + 1

                local height = 107
                local width = 107

                table.insert(ret, { x = baseX + j * width , y = baseY + (row - i - 1) * height })
            end
        end
        return ret
    end

    local posArr = createPosArr(30)

    local logoId = CharacterManager:getInstance():getGuildData():getLogoId()

    local arr = CCArray:create()
    for i=1,30 do
        arr:addObject(CCDelayTime:create(0.1))
        arr:addObject(CCCallFunc:create(function()
            local icon = GuildIcon:create()
            icon:setId(i)
            icon:getClickImg():setTag(i)
            icon:setPosition(ccp(posArr[i].x,posArr[i].y))
            icon:setClickEvent(event_btn_logo_edit)
            icon:setTag(i)
            if logoId == i then
                selectImgEdit:setPosition(ccp(posArr[i].x+30,posArr[i].y-30))
            end
            scrolLogo:addChild(icon)
        end))
    end

    for i=1,30 do
        if scrolLogo:getChildByTag(i) ~= nil then
            scrolLogo:removeChildByTag(i,true)
        end
    end
    scrolLogo:stopAllActions()
    scrolLogo:runAction(CCSequence:create(arr))

end
