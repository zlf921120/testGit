--选择 膜拜 面板 (膜拜大神)

DescWorship = class("DescWorship",WindowBase)
DescWorship.__index = DescWorship
DescWorship._widget     = nil
DescWorship.uiLayer    = nil
DescWorship.is_dispose = true

local __instance = nil

function DescWorship:create()
    local ret = DescWorship.new()
    __instance = ret
    return ret   
end

function DescWorship:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
    Notifier.removeByName(OrganizEvent.CB_UPDATE_DESC)
end
--------------------响应事件-----------------------------------
local labRewardnum = nil

local function event_btn_close(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
       __instance:addCloseAnim()
    end
end

local function event_btn_get(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then 

        if tonumber(labRewardnum:getStringValue()) > 0 then
            GuildNetTask:getInstance():requestGetReward()
        else
            Alert:show("當前沒有可以領取的獎勵")
        end
    end
end
----------------------初始化--------------------------------------
function DescWorship:init()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/DescWorship.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    local btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    btnClose:addTouchEventListener(event_btn_close)

    local btnGet = tolua.cast(self.uiLayer:getWidgetByName("btn_get"),"Button")
    btnGet:addTouchEventListener(event_btn_get)

    labRewardnum = tolua.cast(self.uiLayer:getWidgetByName("lab_rewardnum"),"Label")

    Notifier.regist(OrganizEvent.CB_UPDATE_DESC,function() self:update() end)
end

function DescWorship:open()

    self:update()

    self:addOpenAnim()
end

function DescWorship:update()

    local descVo = GuildDataProxy:getInstance():getWorshipDescVo()
    local labLeft = tolua.cast(self.uiLayer:getWidgetByName("lab_left"),"Label")

    local limit = VipDataProxy:getInstance():getPrivilegeValue( VipPrivilegeType.GuildWorshipMax )
    labLeft:setText(string.format("%d/%d",descVo.surplusWorship,limit) )

    local labCout = tolua.cast(self.uiLayer:getWidgetByName("lab_cout"),"Label")
    labCout:setText(descVo.coutWorship)

    local labRewardnum = tolua.cast(self.uiLayer:getWidgetByName("lab_rewardnum"),"Label")
    labRewardnum:setText(descVo.rewardNum)
end

function DescWorship:close()

end