-- (自身)公会信息 面板
GuildInfoPanel = class("GuildInfoPanel",WindowBase)
GuildInfoPanel.__index = GuildInfoPanel
GuildInfoPanel._widget     = nil
GuildInfoPanel.uiLayer    = nil
GuildInfoPanel.is_dispose = true

local __instance = nil

function GuildInfoPanel:create()
    local ret = GuildInfoPanel.new()
    __instance = ret
    return ret   
end

function GuildInfoPanel:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end

function GuildInfoPanel:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildInfoPanel.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
    	if eventType == ComConstTab.TouchEventType.ended then 
    		WindowCtrl:getInstance():close(self.name)
    	end
    end)

    self.labPeople = tolua.cast(self.uiLayer:getWidgetByName("lab_people"),"Label")
    self.labLev = tolua.cast(self.uiLayer:getWidgetByName("lab_lev"),"Label")
    self.labDonateTotal = tolua.cast(self.uiLayer:getWidgetByName("lab_contribute"),"Label")
    self.labDonateToday = tolua.cast(self.uiLayer:getWidgetByName("lab_todayctb"),"Label")
    self.labDesc = tolua.cast(self.uiLayer:getWidgetByName("lab_desc"),"Label")

    self.scrollDesc = tolua.cast(self.uiLayer:getWidgetByName("scrol_desc"),"ScrollView") 
end

function GuildInfoPanel:open()

    local dp = GuildDataProxy:getInstance()
	local sceneVo = dp:getGuildSceneVo()

    local guildData = CharacterManager:getInstance():getGuildData()
    self.labPeople:setText(string.format("%d/%d", guildData:getCurrNum(), guildData:getMaxnum()))
    self.labLev:setText(sceneVo.lev)
    self.labDonateTotal:setText(sceneVo.donateTotal)

    self.labDonateToday:setText(sceneVo.donateTodayAdd)
    local limitVo = dp:getLevLimitVoById(math.min(sceneVo.lev,Utils.get_length_from_any_table(dp:getLevupCostVoList())))
    local desc = string.format(OrganizCfg.GuildInfo,limitVo.todayLimitDonate)
    self.labDesc:setText(desc)

    local descSize = CCSize(self.scrollDesc:getSize().width,730)
    self.labDesc:setSize(descSize)
    self.scrollDesc:setInnerContainerSize(descSize)

    if limitVo.todayLimitDonate == sceneVo.donateTodayAdd then
        self.labDonateToday:setText(sceneVo.donateTodayAdd.. "（今日只能通過捐獻增加資金）")
    else
        self.labDonateToday:setText(sceneVo.donateTodayAdd)
    end
end

function GuildInfoPanel:close()

end