OrganizHelper = {}

--获取当前玩家 值对象
OrganizHelper.getCurPlayerVo = function()
	local role_id = CharacterManager:getInstance():getLoginData():getRoleId()
	return GuildDataProxy:getInstance():getPlayerVoById(role_id:getKeyIdx())
end

--获取当前玩家公会战 的角色数据
OrganizHelper.getCurFightRoleInfo = function()
	local role_id = CharacterManager:getInstance():getLoginData():getRoleId()
	return GuildDataProxy:getInstance():getFightMyTeamVoById(role_id:getKeyIdx())
end

--是否公会会长
OrganizHelper.isMaster = function(playerVo)
	return playerVo.clazz == ClazzType.Master 
end

--公会成员
OrganizHelper.getMemberNum = function()
	
	return Utils.get_length_from_any_table(GuildDataProxy:getInstance():getPlayerVoList())
end

--获取 目标公会的状态 (满员,普通申请,已申请)
OrganizHelper.getOrganizStatus = function(organizVo,defineStatus)
	
	organizVo.status = defineStatus
	local status = organizVo.status
	if organizVo.population < organizVo.populationMax then 
		if organizVo.status ~= JoinStatus.HAD_APPLY then --已申请
			if CharacterManager:getInstance():getTeamData():getLev() < organizVo.freeLevel then
				status = JoinStatus.APPLY_JOIN --普通申请
			else
				status = JoinStatus.QUICI_JOIN  --快速申请
			end
		end
	else
		status = JoinStatus.HAD_FULLY --已经满员
	end
	return status
end

--刷新自己 公会信息
OrganizHelper.refreshGuildInfo = function(lists)

	local cm = CharacterManager:getInstance()
	local dp = GuildDataProxy:getInstance()
	local guildData = cm:getGuildData()
	if lists.id == 0 then
		print(" 警告!!! 該工會id為零!!!!! ")
	else
		guildData._id = lists.id
		guildData._desc = lists.board
		guildData._name = lists.name
		guildData._logoId = lists.icon
		guildData._free = lists.free
		guildData._lev = lists.lev
		guildData._maxnum = lists.members_max
		guildData._isActive = lists.flag

		local guild_combat = lists.guild_combat
		guildData._declaration = guild_combat.declaration
		guildData._cheerNum = guild_combat.cheer_num

		local sceneVo = dp:getGuildSceneVo()
		sceneVo.lev = lists.lev
		sceneVo.donateTotal = lists.coin
		sceneVo.donateTodayAdd = lists.today_add_coin
		sceneVo.mailNum = lists.send_mails_num

		--公会战 区域
		local sceneFight = dp:getGuildFightSceneVo()
		sceneFight.areaNumList = {}
		sceneFight.areaNumList[ GuildFightArea.Protect ] = guild_combat.protection_num
		sceneFight.areaNumList[ GuildFightArea.Power ] = guild_combat.fire_num
		sceneFight.areaNumList[ GuildFightArea.Defense ] = guild_combat.defence_num
		-- sceneFight.areaNumList[ GuildFightArea.Common ] = guild_combat
	end
end

--刷新 目标公会 信息
OrganizHelper.makeGuildInfo = function(target,lists)

	target.id = lists.id
	target.name = lists.name
	target.logoId = lists.icon
	target.desc = lists.board
	target.freeLevel = lists.free
	target.population = lists.members_size
	target.populationMax = lists.members_max
	target.status = lists.status
	target.isActive = lists.flag
	target.lev = lists.lev
	target.declaration = lists.guild_combat.declaration
	target.donateTodayAdd = lists.today_add_coin
end

--工厂方法 加工公会会员
OrganizHelper.makeMemberInfo = function(target,members)
	
	if target then
		target.role_id = RoleId:create()
		target.role_id:setData(members.id.uin, members.id.channel_id, members.id.zone_id)
		target.id = target.role_id:getKeyIdx()
		target.name = members.name
		target.clazz = members.post
		target.fightValue = members.fc
		target.level = members.lev
		target.worship = members.worship
		target.faceId = members.face_id
		target.sex = members.sex
		target.pet_star = members.sprite_stars
		target.historyLoginTime = members.last_login_time

		if target.historyLoginTime == 0 then
			target.historyLoginTime = ServerTimerManager:getInstance():getCurTime()
		end

		target.donateCur = members.assets.guild_contribute   --当前帮贡
		target.donateTotal = members.assets.guild_total_contribute  --全部帮贡
	end
	if Helper.mathCurRoId( members.id ) then
		local cm = CharacterManager:getInstance()
		local guildData = cm:getGuildData()
		guildData._post = members.post
		local guildData = CharacterManager:getInstance():getGuildData()
	end

	OrganizHelper.makeMyFightMember(members)
end

--工厂方法 加工公会战 成员
OrganizHelper.makeMyFightMember = function(members)
	local dp = GuildDataProxy:getInstance()
	local server_role_info = members.mrole
	local client_role_info = GuildFightRoleInfo:create()
    client_role_info:setBaseInfo(server_role_info.id, server_role_info.name, 
                            server_role_info.team_lev,server_role_info.fc, 
                            server_role_info.face_id, server_role_info.rank, 
                            server_role_info.win_num,server_role_info.guild_name,
                            server_role_info.sex)

	client_role_info:setHeros(server_role_info.heroes)
-- print("members.is_change_team!!!!!!!!!  ",members.is_change_team)
    local status = GuildFightCombatStatus.Normal
    if TeamManager:getInstance():isDeadAllWithTeamType(TeamType.Guild_def) then
    	status = GuildFightCombatStatus.Dead
    -- elseif members.being_combat_time == 0 then
    -- 	status = GuildFightCombatStatus.Normal 
    -- elseif members.being_combat_time > 0 then
    -- 	status = GuildFightCombatStatus.Fighting
    elseif members.start_combat_time > 0 then
    	status = GuildFightCombatStatus.Cold
    end
	client_role_info:setGuildFight(members.guild_regional,
									members.guild_is_check,
									status,
									members.start_combat_time,
									members.is_change_team,
									members.regional_time,
									members.combat_num)

	dp:setFightMyTeamVo(client_role_info)
end

--工厂方法 加工公会战 对手
OrganizHelper.makeEnemyFightMember = function(members)
	local dp = GuildDataProxy:getInstance()
	local server_role_info = members.mrole
	local client_role_info = GuildFightRoleInfo:create()
    client_role_info:setBaseInfo(server_role_info.id, server_role_info.name, 
                            server_role_info.team_lev,server_role_info.fc, 
                            server_role_info.face_id, server_role_info.rank, 
                            server_role_info.win_num,server_role_info.guild_name,
                            server_role_info.sex)

    client_role_info:setHeros(server_role_info.heroes)
    -- print(" members.being_combat_time !!!!!!!! ",members.being_combat_time )
    local status = GuildFightCombatStatus.Dead
    if OrganizHelper.checkIsDeadAll(client_role_info.heros) then
    	status = GuildFightCombatStatus.Dead
    elseif members.being_combat_time > 0 then
    	status = GuildFightCombatStatus.Fighting
    -- elseif members.start_combat_time > 0 then
    -- 	status = GuildFightCombatStatus.Cold
    elseif members.being_combat_time == 0 then
    	status = GuildFightCombatStatus.Normal 
    end
	client_role_info:setGuildFight(members.guild_regional,
									members.guild_is_check,
									status,
									members.being_combat_time,
									members.is_change_team,
									0,
									members.combat_num)

	dp:setFightEnemyVo(client_role_info)
end

--工厂方法 加工 对战 数据
OrganizHelper.makeFightCombat = function(target,info)
	target.id = info.session
	target.isWin = info.is_combat_rest
	target.num1 = info.now_members
	target.name1 = info.name
	target.lev1 = info.lev
	target.guildId1 = info.id
	target.logoId1 = info.icon

	target.num2 = info.other_members
	target.name2 = info.other_name
	target.lev2 = info.other_lev
	target.guildId2 = info.other_id
	target.logoId2 = info.other_icon

end

--工厂方法 加工 战利物品 条目
OrganizHelper.makeFightGloryGift = function(target,info)
	target.id = info.id
	target.base_id = info.base_id
	target.num = info.quantity
	target.create_time = info.create_time
end

--工厂方法 加工 成员公会战 积分排名
OrganizHelper.makeGloryMemberRank = function(target,info)
	
	target.role_id = RoleId:create()
	target.role_id:setData(info.id.uin, info.id.channel_id, info.id.zone_id)
	target.id = target.role_id:getKeyIdx()
	target.rank = info.rank
	target.score = info.integral
	target.scoreTotal = info.integraltotal
	target.name = info.name
	target.is_spoils = info.is_spoils
end

--工厂方法 加工 排行记录 数据
OrganizHelper.makeAllCombatRank = function(target,info,maxSession)
	target.rank = info.rank
	target.name = info.name
	target.lev = info.lev
	target.session_max = maxSession
	target.win_num = info.win_num
	target.id = info.id
end

--工厂方法 加工角色数据
OrganizHelper.makeRoleId = function(target,role_info)
	target.uin = role_info.uin
	target.channel_id = role_info.channel_id
	target.zone_id = role_info.zone_id
end

OrganizHelper.makeGloryLog = function(target,info)
	target.base_name = info.base_name
	target.role_name = info.role_name
	target.gain_way = info.gain_way
	target.create_time = info.create_time
	
	local nowMonth = tonumber(os.date("%m",target.create_time))
    local nowYear = tonumber(os.date("%Y",target.create_time))
    local nowDay = tonumber(os.date("%d",target.create_time))
    local createDay = os.time{year=nowYear, month=nowMonth, day=nowDay, hour=0, sec=0}
    target.time = createDay
end

OrganizHelper.makePowerCurRank = function(target,info)
	target.rank = info.now_rank
	target.id = info.id
	target.num = info.members_len
	target.lev = info.lev
	target.logoId = info.icon
	target.win_num = info.combat_win_total
	target.topRank = info.quarter_top_rank
	target.session_max = info.combat_join_num
	target.name = info.name
end

OrganizHelper.exchageRoleIdKey = function(v)
	local role_id = RoleId:create()
	role_id:setData( v.uin,v.channel_id,v.zone_id )
	return role_id:getKeyIdx()
end

OrganizHelper.checkIsDeadAll = function(heros)
	local hpTotoal = 0
	for k,heroInfo in pairs(heros) do
		hpTotoal = hpTotoal + heroInfo:getAttr(AttrHelper.attr_flag.hp_cur)
	end
	return hpTotoal == 0
end