require "OtherRoleInfo"
--公会战  角色数据
GuildFightRoleInfo = class("GuildFightRoleInfo",function()
	return OtherRoleInfo:create()
end)
GuildFightRoleInfo.guild_fight_area = 0
GuildFightRoleInfo.guild_fight_islock = 0  --是否锁定
GuildFightRoleInfo.guild_fight_combat_status = 0
GuildFightRoleInfo.guild_fight_coldtime = 0
GuildFightRoleInfo.guild_fight_isConfirmTeam = 0
GuildFightRoleInfo.guild_fight_regional_time = 9999999999
GuildFightRoleInfo.combat_num = 0

function GuildFightRoleInfo:create()
	local role = GuildFightRoleInfo.new()
	role:init()
	return role
end

function GuildFightRoleInfo:init()
	self.height = 90 --控件高度
	self.widget = "fightplayer_" --具体控件
end

--设置数据
function GuildFightRoleInfo:setGuildFight(regional,is_check,combat_status,coldtime,is_confirm_team,regional_time,combat_num)
	self.guild_fight_area = regional
	self.guild_fight_islock = is_check
	self.guild_fight_combat_status = combat_status
	self.guild_fight_coldtime = coldtime
	self.guild_fight_isConfirmTeam = is_confirm_team
	self.guild_fight_regional_time = regional_time or 9999999999
	self.combat_num = combat_num
end