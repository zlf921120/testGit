--公会日志 条目
GuildLogItem = class("GuildLogItem",function()
    return Layout:create()
end)

GuildLogItem.__index = GuildLogItem
GuildLogItem._widget = nil
GuildLogItem.logVo = nil

function GuildLogItem:create()
    local ret = GuildLogItem.new()
    ret:init()
    return ret
end

function GuildLogItem:init()
	self._widget = GuildDataProxy:getInstance():getWidgetLogItem():clone()
    self:setSize(CCSize(820,140))
    self:addChild(self._widget)

    self.labTitle = tolua.cast(self._widget:getChildByName("lab_title"),"Label")
    self.labContent = tolua.cast(self._widget:getChildByName("lab_content"),"Label")
end

function GuildLogItem:setData(vo)
	self.logVo = vo
	self:update()
end

function GuildLogItem:update()
	self.labTitle:setText(self.logVo.title)
	self.labContent:setText(self.logVo.content)
end
