-------------------------------------------------------------------------------
--成员 排行 条目
GuildGloryRankItem = class("GuildGloryRankItem",function()
    return Layout:create()
end)
GuildGloryRankItem.__index = GuildGloryRankItem
GuildGloryRankItem._widget     = nil
GuildGloryRankItem.playerVo = nil

function GuildGloryRankItem:create()
    local ret = GuildGloryRankItem.new()
    ret:init()
    return ret
end

function GuildGloryRankItem:init()

	self._widget = GuildDataProxy:getInstance():getWidgetMemberRankItem():clone()
    self:setSize(CCSize(840,82))
    self:addChild(self._widget)

    self.btnCheck = tolua.cast(self._widget:getChildByName("btn_check"),"Button")
    self.btnCheck:setVisible(false)
    self.btnCheck:setTouchEnabled(false)

    self.labRank = tolua.cast(self._widget:getChildByName("lab_rank"),"Label")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labScore = tolua.cast(self._widget:getChildByName("lab_score"),"Label")
    self.labScoreTotal = tolua.cast(self._widget:getChildByName("lab_score_total"),"Label")
    self.imgBg = tolua.cast(self._widget:getChildByName("img_bg"),"ImageView")
end

function GuildGloryRankItem:setData(vo)
    self.rankVo = vo
    self:update()
end

function GuildGloryRankItem:update()

    self.labName:setText(self.rankVo.name)
    self.labScore:setText(self.rankVo.score)
    self.labScoreTotal:setText(self.rankVo.scoreTotal)
    if self.rankVo.rank == 1 then
        self.labRank:setText("榮耀冠軍")
        self.labRank:setColor(ItemHelper.colors.orange)
    else
        self.labRank:setText(string.format("第%d名",self.rankVo.rank))
        self.labRank:setColor(ItemHelper.colors.blue)
    end
    
    local isVis = self.rankVo.rank % 2 == 1 
    self.imgBg:setVisible(isVis)
end
-------------------------------------------------------------------------------
--战利 条目
GuildGloryGiftItem = class("GuildGloryGiftItem",function()
    return Layout:create()
end)
GuildGloryGiftItem.__index = GuildGloryGiftItem
GuildGloryGiftItem._widget     = nil

function GuildGloryGiftItem:create()
    local ret = GuildGloryGiftItem.new()
    ret:init()
    return ret
end

function GuildGloryGiftItem:init()

	self._widget = GuildDataProxy:getInstance():getWidgetGloryGiftItem():clone()
    self:setSize(CCSize(844,132))
    self:addChild(self._widget)

    require "ItemInfoPanel"
    require "ItemIcon"
    self.itemIcon = ItemIcon:create()
    self.itemIcon:setPosition(ccp(63,68))
    self:addChild(self.itemIcon)
    self.itemIcon:setTouchEvent(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.began then
                ItemInfoPanel:show(pSender:getTag())

        elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then

            ItemInfoPanel:hide()
        end
    end)

    self.labTips = tolua.cast(self._widget:getChildByName("lab_tips"),"Label")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")

    self.btnSend = tolua.cast(self._widget:getChildByName("btn_send"),"Button")
    self.btnSend:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            WindowCtrl:getInstance():open(CmdName.Guild_View_GloryAllotPanel,
                {id = self.itemVo.id})
        end
    end)
end

function GuildGloryGiftItem:setData(vo)
    self.itemVo = vo
    self:update()
end

function GuildGloryGiftItem:update()
    self.itemIcon:setBaseId(self.itemVo.base_id)
    self.itemIcon:setItemNum(self.itemVo.num)
    self.itemIcon:getClickImg():setTag(self.itemVo.base_id)
    local mode = ItemManager:getInstance():getItemModelByBaseId(self.itemVo.base_id)
    self.labName:setText(string.format("%s X %d",mode.name,self.itemVo.num))
    self.labTips:setText(string.format("系統分配倒計時 %s",Helper.sec2TimeStr(math.max(0, 24 * 60 * 60 - (ServerTimerManager:getInstance():getCurTime() - self.itemVo.create_time) ))))

    local isVis = GuildDataProxy:getInstance():getFightGlorySceneVo().allotType ~= 3 --自动分配
    self.btnSend:setVisible(isVis)
    self.btnSend:setTouchEnabled(isVis)
end
-------------------------------------------------------------------------------
--战利 日志 条目
GuildGloryLogItem = class("GuildGloryLogItem",function()
    return Layout:create()
end)
GuildGloryLogItem.__index = GuildGloryLogItem
GuildGloryLogItem._widget     = nil

function GuildGloryLogItem:create()
    local ret = GuildGloryLogItem.new()
    ret:init()
    return ret
end

function GuildGloryLogItem:init()

    self._widget = GuildDataProxy:getInstance():getWidgetGloryLogItem():clone()
    self:setSize(CCSize(840,47))
    self:addChild(self._widget)

    self.labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labContent = tolua.cast(self._widget:getChildByName("lab_conten"),"Label")
end

function GuildGloryLogItem:setData(vo)
    self.logVo = vo
    self:update()
end

function GuildGloryLogItem:update()
    
    self.labTime:setText(os.date("%H:%M",self.logVo.create_time))
    self.labName:setText("【"..self.logVo.role_name.."】")
    self.labContent:setText("通過"..self.logVo.gain_way .."獲得了"..self.logVo.base_name )
end


-------------------------------------------------------------------------------
--战利 日志 标题 条目
GuildGloryLogTitleItem = class("GuildGloryLogTitleItem",function()
    return Layout:create()
end)
GuildGloryLogTitleItem.__index = GuildGloryLogTitleItem
GuildGloryLogTitleItem._widget     = nil

function GuildGloryLogTitleItem:create()
    local ret = GuildGloryLogTitleItem.new()
    ret:init()
    return ret
end

function GuildGloryLogTitleItem:init()

	self._widget = GuildDataProxy:getInstance():getWidgetGloryLogTitleItem():clone()
    self:setSize(CCSize(840,47))
    self:addChild(self._widget)

    self.labTitle = tolua.cast(self._widget:getChildByName("lab_day"),"Label")
end

function GuildGloryLogTitleItem:setData(vo)
    self.voTitle = vo
    self:update()
end

function GuildGloryLogTitleItem:update()
    self.labTitle:setText(os.date("%m月%d日",self.voTitle.id))
end
--------------------------------------------------------------------------------
--公会战 (我的公会) 战利 面板
GuildFightGloryPanel = class("GuildFightGloryPanel",WindowBase)
GuildFightGloryPanel.__index = GuildFightGloryPanel
GuildFightGloryPanel._widget = nil
GuildFightGloryPanel.uiLayer = nil
GuildFightGloryPanel.btnLast = nil
GuildFightGloryPanel.panelLast = nil
GuildFightGloryPanel.selectAllotIdx = 0
GuildFightGloryPanel.is_dispose = true

local __instance = nil

function GuildFightGloryPanel:create()
    local ret = GuildFightGloryPanel.new()
    __instance = ret
    return ret
end

function GuildFightGloryPanel:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_RANK_LIST)
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_GIFT_LIST)
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_LOG_LIST)
end

function GuildFightGloryPanel:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightGloryPanel.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
 	self.btnClose:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
        	WindowCtrl:getInstance():close(self.name)
       	end
    end)

    self.btnRank = tolua.cast(self.uiLayer:getWidgetByName("btn_rank"),"Button")
    self.btnRank:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then

        	self.panelRank:setVisible(true)
	        self.panelRank:setZOrder(4)

	        self.btnRank:setFocused(true)
	        self.btnRank:setTitleColor(ccc3(210,253,238))
	        if self.btnLast ~= self.btnRank then
	            self.btnLast:setFocused(false)
	            self.btnLast:setTitleColor(ccc3(245,204,85))
	            self.btnLast = self.btnRank
	            
                self:cleanAllRefresh()
                GuildNetTask:getInstance():requestMemberFightRank()

	            self.panelLast:setVisible(false)
                self.panelLast:setZOrder(1)
                self.panelLast = self.panelRank
	        end
        end
    end)

    self.btnGift = tolua.cast(self.uiLayer:getWidgetByName("btn_gift"),"Button")
    self.btnGift:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then

        	self.panelGift:setVisible(true)
	        self.panelGift:setZOrder(4)

	        self.btnGift:setFocused(true)
	        self.btnGift:setTitleColor(ccc3(210,253,238))
	        if self.btnLast ~= self.btnGift then
	            self.btnLast:setFocused(false)
	            self.btnLast:setTitleColor(ccc3(245,204,85))
	            self.btnLast = self.btnGift
	            
                self:cleanAllRefresh()
                GuildNetTask:getInstance():requestGuildGloryGift()

	            self.panelLast:setVisible(false)
	            self.panelLast:setZOrder(1)
	            self.panelLast = self.panelGift
	        end
        end
    end)

    self.btnLog = tolua.cast(self.uiLayer:getWidgetByName("btn_log"),"Button")
    self.btnLog:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then

        	self.panelLog:setVisible(true)
	        self.panelLog:setZOrder(4)

	        self.btnLog:setFocused(true)
	        self.btnLog:setTitleColor(ccc3(210,253,238))
	        if self.btnLast ~= self.btnLog then
	            self.btnLast:setFocused(false)
	            self.btnLast:setTitleColor(ccc3(245,204,85))
	            self.btnLast = self.btnLog
	            
                self:cleanAllRefresh()
                GuildNetTask:getInstance():requestGuildGloryLog()

	            self.panelLast:setVisible(false)
	            self.panelLast:setZOrder(1)
	            self.panelLast = self.panelLog

	        end
        end
    end)

    self.btnLast = self.btnRank  
    self.btnRank:setFocused(true)
    self.btnRank:setTitleColor(ccc3(210,253,238))

    self.panelRank = tolua.cast(self.uiLayer:getWidgetByName("panel_rank"),"Layout")
    self.panelGift = tolua.cast(self.uiLayer:getWidgetByName("panel_gift"),"Layout")
    self.panelLog = tolua.cast(self.uiLayer:getWidgetByName("panel_log"),"Layout")
    self.panelLast = self.panelRank

    self.panelMenu = tolua.cast(self.uiLayer:getWidgetByName("panel_menu"),"Layout")
    -------------分配 战利品---------------------------------------------
    self.btnLeft = tolua.cast(self.uiLayer:getWidgetByName("btn_left"),"Button")
    self.btnLeft:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            self.selectAllotIdx = math.max(1,self.selectAllotIdx - 1) 
            self.labWay:setText( GuildGloryAllotName[ self.selectAllotIdx ] )
    	end
    end)
    self.btnRight = tolua.cast(self.uiLayer:getWidgetByName("btn_right"),"Button")
    self.btnRight:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            self.selectAllotIdx = math.min(3,self.selectAllotIdx + 1) 
            self.labWay:setText( GuildGloryAllotName[ self.selectAllotIdx ] )
    	end
    end)
    self.btnConfirm = tolua.cast(self.uiLayer:getWidgetByName("btn_ok"),"Button")
    self.btnConfirm:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            GuildNetTask:getInstance():requestEditGloryGiftWay(self.selectAllotIdx)
    	end
    end)

    self.labTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips"),"Label")
    self.labWay = tolua.cast(self.uiLayer:getWidgetByName("lab_content"),"Label")
---------------------------------------------------------------------------------------
    self.scrolRank = DisplayUtil.createAdaptScrollView(840,400,0,0,1)
    self.scrolRank:setPosition(ccp(0,0))
    self.panelRank:addChild(self.scrolRank)

    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_RANK_LIST,function() 
        local voList = GuildDataProxy:getInstance():getFightGloryMemberList()
        self.labTips:setVisible(Utils.get_length_from_any_table(voList) <= 0)

        GuildRenderMgr:getInstance():renderGloryRankAdapt(self.scrolRank)

        self.lastRankY1 = -1

        self.scrolRank:stopAllActions()
        self.scrolRank:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolRank:getInnerContainer():getPositionY()
                if self.lastRankY1 ~= viewY then
                    self.lastRankY1 = viewY
                    local viewRect = CCRectMake(0,math.abs(viewY),840,400)
                    GuildRenderMgr:getInstance():refreshGloryRankList(viewRect,self.scrolRank)
                end
            end),
            CCDelayTime:create(0.1))))
    end)
---------------------------------------------------------------------------------------
    self.scrolGift = DisplayUtil.createAdaptScrollView(840,380,0,0,1)
    self.scrolGift:setPosition(ccp(0,0))
    self.panelGift:addChild(self.scrolGift)

    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_GIFT_LIST,function() 
        GuildRenderMgr:getInstance():renderGloryGiftAdapt(self.scrolGift)

        self:hideNewsTip(NewTipsEnum.guild_fight_reward)
        self.lastRankY2 = -1

        self.scrolGift:stopAllActions()
        self.scrolGift:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolGift:getInnerContainer():getPositionY()
                if self.lastRankY2 ~= viewY then
                    self.lastRankY2 = viewY
                    local viewRect = CCRectMake(0,math.abs(viewY),840,380)
                    GuildRenderMgr:getInstance():refreshGloryGiftList(viewRect,self.scrolGift)
                end
            end),
            CCDelayTime:create(0.1))))

        self:update()
    end)
---------------------------------------------------------------------------------------
    self.scrolLog = DisplayUtil.createAdaptScrollView(840,450,0,0,1)
    self.scrolLog:setPosition(ccp(0,0))
    self.panelLog:addChild(self.scrolLog)

    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_LOG_LIST,function() 
        GuildRenderMgr:getInstance():renderGloryLogAdapt(self.scrolLog)

        self.lastRankY3 = -1

        self.scrolLog:stopAllActions()
        self.scrolLog:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolLog:getInnerContainer():getPositionY()
                if self.lastRankY3 ~= viewY then
                    self.lastRankY3 = viewY
                    local viewRect = CCRectMake(0,math.abs(viewY),840,450)
                    GuildRenderMgr:getInstance():refreshGloryLogList(viewRect,self.scrolLog)
                end
            end),
            CCDelayTime:create(0.1))))
    end)
end

function GuildFightGloryPanel:cleanAllRefresh()
    self.scrolRank:stopAllActions()
    self.scrolGift:stopAllActions()
    self.scrolLog:stopAllActions()
end

function GuildFightGloryPanel:resetView()
    self.panelRank:setVisible(true)
    self.panelRank:setZOrder(4)

    self.btnRank:setFocused(true)
    self.btnRank:setTitleColor(ccc3(210,253,238))
    if self.btnLast ~= self.btnRank then
        self.btnLast:setFocused(false)
        self.btnLast:setTitleColor(ccc3(245,204,85))
        self.btnLast = self.btnRank
        
        self:cleanAllRefresh()

        self.panelLast:setVisible(false)
        self.panelLast:setZOrder(1)
        self.panelLast = self.panelRank
    end
end

function GuildFightGloryPanel:update()
    local dp = GuildDataProxy:getInstance()
    self.selectAllotIdx = dp:getFightGlorySceneVo().allotType
    self.labWay:setText(GuildGloryAllotName[ self.selectAllotIdx ])
end

function GuildFightGloryPanel:open()

    GuildNetTask:getInstance():requestMemberFightRank()

    if GuildDataProxy:getInstance().fight_reward_news > 0 then
        self:showNewsTip(NewTipsEnum.guild_fight_reward)
    end
end

function GuildFightGloryPanel:close()
    self:resetView()
end

function GuildFightGloryPanel:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

-- 隐藏 新消息 提示
function GuildFightGloryPanel:hideNewsTip(key)
    local target = nil
    if key == NewTipsEnum.guild_fight_reward then
        target = self.btnGift
    end
    if target and target:getChildByTag(2866) ~= nil then
        CharacterManager:getInstance():getBaseData():setNewsTipStatus(key,1) --0 显示  1 不显示
        target:removeChildByTag(2866,true)

        GuildDataProxy:getInstance().fight_reward_news = 0
        Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.guild)
        Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_NEW_TIPS_HIDE,NewTipsEnum.guild_fight)
        Notifier.dispatchCmd(OrganizEvent.GUILD_FIGHT_NEW_TIPS_HIDE,NewTipsEnum.guild_fight_reward)
    end
end

-- 展示 新消息 提示
function GuildFightGloryPanel:showNewsTip(key)
    local target = nil
    local pos = nil
    if key == NewTipsEnum.guild_fight_reward then
        target = self.btnGift
        pos = ccp(55,20)
    end
    if target and target:getChildByTag(2866) == nil then
        local tips_img = ImageView:create()
        tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
        tips_img:setTag(2866)
        tips_img:setPosition(pos)
        target:addChild(tips_img)
        self:tipsPointPlayAct(tips_img)
    elseif target and target:getChildByTag(2866) ~= nil then
        local tips_img = target:getChildByTag(2866)
        self:tipsPointPlayAct(tips_img)
    end
end
