------------------------------------------------------------------
--公会战 战绩 条目
GuildFightScoreItem = class("GuildFightScoreItem",function()
    return Layout:create()
end)
GuildFightScoreItem.__index = GuildFightScoreItem
GuildFightScoreItem._widget     = nil
GuildFightScoreItem.scoreVo = nil

function GuildFightScoreItem:create()
    local ret = GuildFightScoreItem.new()
    ret:init()
    return ret
end

function GuildFightScoreItem:init()

	self._widget = GuildDataProxy:getInstance():getWidgetFightScoreItem():clone()
	self:setSize(CCSize(620,168))
	self:addChild(self._widget)

	self.panelEnemy = tolua.cast(self._widget:getChildByName("panel_enemy"),"Layout")
	self.labSession = tolua.cast(self._widget:getChildByName("lab_session"),"Label")

	self.guildIcon1 = GuildIcon:create()
	self.guildIcon1:setPosition(ccp(84,59))
	self._widget:addChild(self.guildIcon1)

	self.guildIcon2 = GuildIcon:create()
	self.guildIcon2:setPosition(ccp(262,58))
	self.panelEnemy:addChild(self.guildIcon2,2)

	self.labNum1 = tolua.cast(self._widget:getChildByName("lab_num1"),"Label")
	self.labNum2 = tolua.cast(self.panelEnemy:getChildByName("lab_num2"),"Label")
	self.labName1 = tolua.cast(self._widget:getChildByName("lab_name1"),"Label")
	self.labName2 = tolua.cast(self.panelEnemy:getChildByName("lab_name2"),"Label")
	self.imgWin = tolua.cast(self._widget:getChildByName("img_win"),"ImageView")
end

function GuildFightScoreItem:setData(vo)
	self.scoreVo = vo
	self:update()
end

function GuildFightScoreItem:update()
	
	self.labSession:setText(string.format("第%s場",Helper.converNumToChinese(self.scoreVo.id)))

	if self.scoreVo.name1 == "" then
        self.guildIcon1:setVisible(false)
        self.labName1:setText("輪空")
        self.labNum1:setVisible(false)
    else
        self.guildIcon1:setVisible(true)
        self.labNum1:setVisible(true)
        self.guildIcon1:setId(self.scoreVo.logoId1)
        self.guildIcon1:setLev(self.scoreVo.lev1)
        self.labName1:setText(self.scoreVo.name1)
        self.labNum1:setText(string.format("(%d人)",self.scoreVo.num1))
    end

    if self.scoreVo.name2 == "" then
        self.guildIcon2:setVisible(false)
        self.labName2:setText("輪空")
        self.labNum2:setVisible(false)
    else
        self.guildIcon2:setVisible(true)
        self.labNum2:setVisible(true)
        self.guildIcon2:setId(self.scoreVo.logoId2)
        self.guildIcon2:setLev(self.scoreVo.lev2)
        self.labName2:setText(self.scoreVo.name2)
        self.labNum2:setText(string.format("(%d人)",self.scoreVo.num2))
    end
	if self.scoreVo.isWin == 1 then
		self.imgWin:setPositionX(118)
	else
		self.imgWin:setPositionX(496)
	end
end

------------------------------------------------------------------
-- 公会战 战绩 面板
GuildFightScorePanel = class("GuildFightScorePanel",WindowBase)
GuildFightScorePanel.__index = GuildFightScorePanel
GuildFightScorePanel._widget = nil
GuildFightScorePanel.uiLayer = nil
GuildFightScorePanel.is_dispose = true

local __instance = nil

function GuildFightScorePanel:create()
    local ret = GuildFightScorePanel.new()
    __instance = ret
    return ret
end

function GuildFightScorePanel:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
end

function GuildFightScorePanel:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightScorePanel.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)
    
    self.listView = tolua.cast(self.uiLayer:getWidgetByName("list_score"),"ListView")
   	self.labTitle = tolua.cast(self.uiLayer:getWidgetByName("lab_title"),"Label")
   	self.labFixWinPerc = tolua.cast(self.uiLayer:getWidgetByName("lab_win_perc_fix"),"Label")
   	self.labFixScore = tolua.cast(self.uiLayer:getWidgetByName("lab_score_fix"),"Label")
   	self.labWinPerc = tolua.cast(self.uiLayer:getWidgetByName("lab_win_perc"),"Label")
   	self.labWinNum = tolua.cast(self.uiLayer:getWidgetByName("lab_win_num"),"Label")
   	self.labScore = tolua.cast(self.uiLayer:getWidgetByName("lab_score"),"Label")
    self.labTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips"),"Label")
    self.labLastRankFix = tolua.cast(self.uiLayer:getWidgetByName("lab_last_rank_fix"),"Label")
    self.labLastRank = tolua.cast(self.uiLayer:getWidgetByName("lab_last_rank"),"Label")
    
    self._update = function()
    	self:update()
   	end
end

function GuildFightScorePanel:update()

	GuildRenderMgr:getInstance():renderGuildScoreList(self.listView)

	self.labTitle:setText(string.format("%s戰績",self.guildName))
	if self.type == GuildFightScoreType.Current then
		self.labFixWinPerc:setText("本屆勝率：")
		self.labFixScore:setText("本屆公會總積分：")
	elseif self.type == GuildFightScoreType.Last then
		self.labFixWinPerc:setText("上屆勝率：")
		self.labFixScore:setText("上屆公會總積分：")
	end
    local viewVo = GuildDataProxy:getInstance():getFightScoreViewVo()
	self.labWinPerc:setText( string.format("%.2f%%",viewVo.win_num/math.max(1,viewVo.session_max) * 100) )
	self.labScore:setText(viewVo.scoreTotal)
	self.labWinNum:setText(viewVo.win_num)

    if self.type == GuildFightScoreType.Current then
        self.labTips:setText("該公會未參加本屆公會戰")
    elseif self.type == GuildFightScoreType.Last then
        self.labTips:setText("該公會未參加上屆公會戰")
    end
    self.labTips:setVisible(Utils.get_length_from_any_table(GuildDataProxy:getInstance():getFightScoreList()) == 0 )

    local vis = self.type == GuildFightScoreType.Current and viewVo.lastRank > 0
    self.labLastRank:setText(viewVo.lastRank)
    self.labLastRank:setVisible(vis)
    self.labLastRankFix:setVisible(vis)
end

function GuildFightScorePanel:open()

	self.guildId = self.params["id"]
	self.type = self.params["type"]
	self.guildName = self.params["name"]

	Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_SCORE_LIST,self._update)
	GuildNetTask:getInstance():requestGuildFightResult(self.guildId,self.type)
end

function GuildFightScorePanel:close()

	Notifier.remove(OrganizEvent.MSG_UPDATE_FIGHT_SCORE_LIST,self._update)
end
