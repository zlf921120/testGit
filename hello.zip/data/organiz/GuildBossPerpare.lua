-- 公会Boss 预备战斗 面板
GuildBossPerpare = class("GuildBossPerpare",WindowBase)
GuildBossPerpare.__index = GuildBossPerpare
GuildBossPerpare._widget     = nil
GuildBossPerpare.uiLayer    = nil
GuildBossPerpare.is_dispose = true

local __instance = nil

function GuildBossPerpare:create()
    local ret = GuildBossPerpare.new()
    __instance = ret
    return ret   
end

function GuildBossPerpare:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_BOSS_INFO)
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_BOSS_HURT_LIST)
end

function GuildBossPerpare:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildBossPerpare.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    self.btnOpen = tolua.cast(self._widget:getChildByName("btn_open"),"Button")
    self.btnOpen:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Guild_View_BossOpen,{boss_id = self.bossVo.id})
        end
    end)

    self.btnFight = tolua.cast(self.uiLayer:getWidgetByName("btn_fight"),"Button")
    self.btnFight:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            if self.bossVo.isActive ~= 1 then
                Alert:show("該BOSS需要會長或副會長開啟才可挑戰")
            else
                if table.maxn(TeamManager:getInstance():getBattleHeroList()) == 0 then
                    WindowCtrl:getInstance():open(CmdName.Team_View,{
                        team_type = TeamType.Dungeon,
                        id = self.bossVo.battle_id,
                        subId = 1,
                        bossId =self.bossVo.id,
                        bossHp = self.bossVo.hp,
                        btnOkTitle = "挑戰"
                    })
                else
                    BattleManager:getInstance():reqBattleStart(self.bossVo.battle_id, 1, TeamType.Dungeon,
                        {bossId = self.bossVo.id,bossHp = self.bossVo.hp})
                end
            end

        end
    end)

    self.btnSetting = tolua.cast(self.uiLayer:getWidgetByName("btn_team"),"Button")
    self.btnSetting:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

           WindowCtrl:getInstance():open(CmdName.Team_View,{
                team_type = TeamType.Dungeon,
                id = self.bossVo.battle_id,
                subId = 1,
                bossId =self.bossVo.id,
                bossHp = self.bossVo.hp,
                btnOkTitle = "挑戰"
            })
        end
    end)

    self.btnLeft = tolua.cast(self.uiLayer:getWidgetByName("btn_left"),"Button")
    self.btnLeft:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            local rm = GuildRenderMgr:getInstance()
            local idx = rm.showBossIdx - 1
            local tbl = GuildDataProxy:getInstance().bossVoTblList
            self.bossVo = tbl[ math.max(1,idx) ]

            -- print(" btn_left ",self.bossVo.idx)
            GuildNetTask:getInstance():requestGuildBossInfo(self.bossVo.id)
        end
    end)

    self.btnRight = tolua.cast(self._widget:getChildByName("btn_right"),"Button")
    self.btnRight:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            local rm = GuildRenderMgr:getInstance()
            local idx = rm.showBossIdx + 1
            local tbl = GuildDataProxy:getInstance().bossVoTblList
            self.bossVo = tbl[ math.min(#tbl,idx) ]

            -- print(" btn_right ",self.bossVo.idx)
            GuildNetTask:getInstance():requestGuildBossInfo(self.bossVo.id)
        end
    end)

    self.btnDesc = tolua.cast(self._widget:getChildByName("btn_desc"),"Button")
    self.btnDesc:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
                WindowCtrl:getInstance():open(CmdName.Comm_DescPanel,
                {title="公會Boss",content=OrganizCfg.BossInfo,
                rewardArr = {{img="reward_equip.png",lab="裝備"},
                            {img="reward_fragment.png",lab="碎片"},
                            {img="gold.png",lab="金幣"},
                            {img="reward_hero_exp.png",lab="經驗藥"}}})
        end
    end)

    self.listRecord = tolua.cast(self._widget:getChildByName("list_record"),"ListView")

    self.bossItem = GuildBossItem:create()
    self.bossItem:setPosition(ccp(72,115))
    self.bossItem:setType(2)
    self._widget:addChild(self.bossItem)

    require "ItemIcon"
    require "ItemInfoPanel"
    self.itemIconList = {}
    for i=1,5 do
        local itemIcon = ItemIcon:create()
        itemIcon:setScale(0.80)
        itemIcon:setPosition(ccp(503 + (i-1)*90, 209))
        itemIcon:setTouchEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                if pSender:getTag() ~= 0 then
                    
                    ItemInfoPanel:show(pSender:getTag())
                end
            elseif eventType == ComConstTab.TouchEventType.ended or
                    eventType == ComConstTab.TouchEventType.canceled then

                ItemInfoPanel:hide()
            end
        end)
        self._widget:addChild(itemIcon)
        self.itemIconList[ i ] = itemIcon
    end

    self.labLeft = tolua.cast(self.uiLayer:getWidgetByName("lab_left"),"Label")
    self.labTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips"),"Label")
    self.panelView = tolua.cast(self.uiLayer:getWidgetByName("panel_view"),"Label")

    Notifier.regist(OrganizEvent.MSG_UPDATE_BOSS_INFO,function(bossVo) 
        if bossVo then
            self.bossVo = bossVo 
            self:update() 
        end
    end)
    Notifier.regist(OrganizEvent.MSG_UPDATE_BOSS_HURT_LIST,function() self:updateBossHurtList() end)
end

function GuildBossPerpare:open()
	local bossId = self.params["boss_id"]

    GuildNetTask:getInstance():requestGuildBossInfo(bossId)

    --仅会长 和 副会长 可用
    local playerVo = OrganizHelper.getCurPlayerVo()
    local isVis = playerVo.clazz == ClazzType.Master or playerVo.clazz == ClazzType.Deputy
    self.btnOpen:setVisible( isVis ) 
    self.btnOpen:setTouchEnabled( isVis )
end

function GuildBossPerpare:update()
    
    self.bossItem:setData(self.bossVo)

    self.panelView:setVisible(true)
    self.btnFight:setTouchEnabled(true)
    self.btnSetting:setTouchEnabled(true)
    self.labTips:setVisible(false)

    for i=1,5 do
        local base_id = self.bossVo.rewardList[i]
        if base_id ~= nil then
            self.itemIconList[ i ]:setBaseId( tonumber(base_id) )
            self.itemIconList[ i ]:setItemNum(1)
            self.itemIconList[ i ]:getClickImg():setTag(tonumber(base_id))
        else
            self.itemIconList[ i ]:setVisible(false)
            self.itemIconList[ i ]:getClickImg():setTag(0)
        end
    end

    -- print(" self.bossVo.hasBeenFightNum ",OrganizCfg.GuildBossFightLimit,self.bossVo.hasBeenFightNum)
    local guildData = CharacterManager:getInstance():getGuildData()

    if OrganizCfg.GuildBossFightLimit - guildData:getHasBeenFightNum() <= 0 then --次数不足
        self.labLeft:setText("今天挑戰次數已用完")
        self.btnFight:setBright(false)
        self.btnFight:setTouchEnabled(false)
    elseif self.bossVo.hp <= 0 then  --血量不足
        self.btnFight:setBright(false)
        self.btnFight:setTouchEnabled(false)
    else
        self.labLeft:setText(string.format("今天剩餘挑戰次數：%d/%d", 
            OrganizCfg.GuildBossFightLimit - guildData:getHasBeenFightNum() ,
            OrganizCfg.GuildBossFightLimit))
        self.btnFight:setBright(true)
        self.btnFight:setTouchEnabled(true)
    end

    self:updateBossHurtList()
    local rm = GuildRenderMgr:getInstance()
    if rm.showBossIdx == 1 then
        self.btnLeft:setTouchEnabled(false)
        self.btnLeft:setVisible(false)
        self.btnRight:setTouchEnabled(true)
        self.btnRight:setVisible(true)
    elseif rm.showBossIdx == #GuildDataProxy:getInstance().bossVoTblList then
        self.btnLeft:setTouchEnabled(true)
        self.btnLeft:setVisible(true)
        self.btnRight:setTouchEnabled(false)
        self.btnRight:setVisible(false)
    else
        self.btnLeft:setTouchEnabled(true)
        self.btnLeft:setVisible(true)
        self.btnRight:setTouchEnabled(true)
        self.btnRight:setVisible(true)
    end

    local dp = GuildDataProxy:getInstance()
    local bossLastVo = dp.bossVoTblList[ self.bossVo.idx - 1 ]
    
    if self.bossVo.isActive == 1 then
        --已激活不用管
    elseif dp:getGuildSceneVo().lev < self.bossVo.guild_lev then --是否满足等级

        self.labTips:setVisible(true)
        self.labTips:setText(string.format("公會%d級可開啟挑戰",self.bossVo.guild_lev))
        self.panelView:setVisible(false)
        self.btnFight:setTouchEnabled(false)
        self.btnSetting:setTouchEnabled(false)
    elseif bossLastVo and bossLastVo.hp ~= 0 and bossLastVo.hadBeenFight == 0 then

        self.labTips:setVisible(true)
        self.labTips:setText("擊殺上一個BOSS後可開啟")
        self.panelView:setVisible(false)
        self.btnFight:setTouchEnabled(false)
        self.btnSetting:setTouchEnabled(false)
    end
end

function GuildBossPerpare:updateBossHurtList()
    local rm = GuildRenderMgr:getInstance()
    rm:renderBossHurtList(self.listRecord,self.bossVo.id)
    rm.showBossIdx = self.bossVo.idx
end

function GuildBossPerpare:close()

end