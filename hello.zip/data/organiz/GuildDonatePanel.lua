-- 公会捐献 面板
GuildDonatePanel = class("GuildDonatePanel",WindowBase)
GuildDonatePanel.__index = GuildDonatePanel
GuildDonatePanel._widget     = nil
GuildDonatePanel.uiLayer    = nil
GuildDonatePanel.is_dispose = true
GuildDonatePanel.coin_cout = 0

local _lastChoicePanel = nil
local _curSelect = 0
local _tipsType = nil
local _cost_value = 99999

local __instance = nil

function GuildDonatePanel:create()
    local ret = GuildDonatePanel.new()
    __instance = ret
    return ret   
end

function GuildDonatePanel:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_DONATE_INFO)
    _curSelect = 0
    _tipsType = nil
    __instance = nil
    _cost_value = 99999
end

local function event_btn_push(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        if _tipsType == 0 then --0金币 
            Alert:show("金幣不足")
        elseif _tipsType == 1 then --钻石
            Alert:show("鑽石不足")
        else
            if _curSelect == 1 then
                WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()

                    __instance.btnPush:setBright(false)
                    __instance.btnPush:setTouchEnabled(false)

                    GuildNetTask:getInstance():requestPushDonate(_curSelect,0)

                end, txt = string.format("您確定要花費%d鑽石捐贈公會嗎？",_cost_value)})
            elseif _curSelect == 0 then
                __instance.btnPush:setBright(false)
                __instance.btnPush:setTouchEnabled(false)

                GuildNetTask:getInstance():requestPushDonate(_curSelect,__instance.coin_cout)
            end
        end
   	end
end

local function event_opt_type(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        if _lastChoicePanel == pSender then return end
        if pSender:getTag() == 1 and CharacterDataProxy:getInstance():getVipLev() <= 0 then
            Alert:show("需要開啟Vip等級")
            return  
        end

    	_lastChoicePanel:getChildByName("img_select"):setVisible(false)
            
        _curSelect = pSender:getTag()
        pSender:getChildByName("img_select"):setVisible(true)
        _lastChoicePanel = pSender

        if _curSelect == 0 then

            __instance.panelView:setVisible(true)
            __instance.panelView:setZOrder(2)
            __instance.panelView2:setVisible(false)
            __instance.panelView2:setZOrder(1)
            __instance.labDiamonTips:setVisible(false)

            __instance:update()
        elseif _curSelect == 1 then

            __instance.panelView2:setVisible(true)
            __instance.panelView2:setZOrder(2)
            __instance.panelView:setVisible(false)
            __instance.panelView:setZOrder(1)
            __instance.labDiamonTips:setVisible(true)

            __instance:update2()
        end

        
   	end
end

function GuildDonatePanel:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildDonatePanel.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    -- self.imgCurrency = tolua.cast(self.uiLayer:getWidgetByName("img_currency"),"ImageView")

    self.panelCoin = tolua.cast(self._widget:getChildByName("panel_coin"),"Layout")
    self.panelCoin:setTag(0) --0金币 
    self.panelCoin:addTouchEventListener(event_opt_type)
    self.panelDiamon = tolua.cast(self._widget:getChildByName("panel_diamon"),"Layout")
    self.panelDiamon:setTag(1)  --1钻石 
    self.panelDiamon:addTouchEventListener(event_opt_type)
    _lastChoicePanel = self.panelCoin

    self.panelView = tolua.cast(self._widget:getChildByName("panel_view"),"Layout")
    self.panelView2 = tolua.cast(self._widget:getChildByName("panel_view2"),"Layout")
    self.labCoinDonateMe = tolua.cast(self.panelView:getChildByName("lab_donteMe"),"Label")
    self.labCoinDonateGuild = tolua.cast(self.panelView:getChildByName("lab_donteGuild"),"Label")
    self.labCoinTips = tolua.cast(self.panelView:getChildByName("lab_coin"),"Label")
    self.labCoinCost = tolua.cast(self.panelView:getChildByName("lab_cost"),"Label")

    self.panelGuildView = tolua.cast(self.panelView2:getChildByName("panel_guildview"),"Layout")
    self.panelMeView = tolua.cast(self.panelView2:getChildByName("panel_meview"),"Layout")
    self.labCost = tolua.cast(self.panelView2:getChildByName("lab_cost"),"Label")
    self.labDonateMe = tolua.cast(self.panelMeView:getChildByName("lab_donteMe"),"Label")
    self.labDonateGuild = tolua.cast(self.panelGuildView:getChildByName("lab_donteGuild"),"Label")
    self.labDiamonTips = tolua.cast(self._widget:getChildByName("lab_diamon"),"Label")

    self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then 
	    	WindowCtrl:getInstance():close(self.name)
	   	end
    end)

    self.btnPush = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
    self.btnPush:addTouchEventListener(event_btn_push)

    self.btnMin = tolua.cast(self.uiLayer:getWidgetByName("btn_min"),"Button")
    self.btnMin:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then 
            
            self.coin_cout = math.max(0,self.coin_cout - 1)
            self:update()
        end
    end)    

    self.btnAdd = tolua.cast(self.uiLayer:getWidgetByName("btn_add"),"Button")
    self.btnAdd:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then 
            local panelVo = GuildDataProxy:getInstance():getDonatePanelVo()
            local cost = panelVo.initCoin + self.coin_cout * panelVo.coinAdd
            if cost < VipDataProxy:getInstance():getPrivilegeValue(VipPrivilegeType.GuildDonateCoin) - panelVo.coutCoin then
                self.coin_cout = self.coin_cout + 1
                self:update()
            end
        end
    end)

    self.btnMax = tolua.cast(self.uiLayer:getWidgetByName("btn_max"),"Button")
    self.btnMax:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then 
            local panelVo = GuildDataProxy:getInstance():getDonatePanelVo()
            local costVipMax = VipDataProxy:getInstance():getPrivilegeValue(VipPrivilegeType.GuildDonateCoin) - panelVo.initCoin
            
            local panelVo = GuildDataProxy:getInstance():getDonatePanelVo()
            local costMax = costVipMax - panelVo.coutCoin
            if costMax >= panelVo.initCoin then
                self.coin_cout = costMax / panelVo.coinAdd
                self:update()
            else
                Alert:show("捐獻金幣已達到上限")
            end
        end
    end)

    Notifier.regist(OrganizEvent.MSG_UPDATE_DONATE_INFO,function() self:update() end)
end

function GuildDonatePanel:update()

    local panelVo = GuildDataProxy:getInstance():getDonatePanelVo()

    local cost = panelVo.initCoin + self.coin_cout * panelVo.coinAdd
    self.labCoinCost:setText( cost )
    self.labCoinDonateMe:setText( cost  / panelVo.coinAdd * panelVo.donateMeAdd )
    self.labCoinDonateGuild:setText( cost / panelVo.coinAdd * panelVo.donateGuildAdd )

    self.labCoinTips:setText( string.format("（今日可捐贈金幣%d）",
        VipDataProxy:getInstance():getPrivilegeValue(VipPrivilegeType.GuildDonateCoin)-panelVo.coutCoin) )

    self.btnPush:setBright(true)
    self.btnPush:setTouchEnabled(true)
    self.btnPush:setTitleText("捐獻金幣")
end

function GuildDonatePanel:update2()

    local dp = GuildDataProxy:getInstance()
    local cm = CharacterManager:getInstance()
    -- local panelVo = dp:getDonatePanelVo()
    local lenMax = 0
    local cout = 0
    local costVo = nil
    local path = ""
    local myMoney = 0
    -- local btnTitle = ""
    local type = ""
    _tipsType = nil

    self.btnPush:setBright(true)
    self.btnPush:setTouchEnabled(true)
    self.btnPush:setTitleText("捐獻鑽石")

    if _curSelect == 0 then --0金币 
        -- lenMax = Utils.get_length_from_any_table( dp:getDonateCostVoList() )
        -- cout = panelVo.coutCoin
        -- costVo = dp:getDonateCostVoById(cout + 1)
        -- -- path = "gold.png"
        -- myMoney = cm:getAssetData():getGold()
        -- -- btnTitle = "捐獻金幣"
        -- type = "金幣"
    elseif _curSelect == 1 then --1钻石 
        lenMax = 99999999 --无穷大
        cout = 1
        costVo = dp:getDiamonDonateCostVoById(cout)
        print(" costVo.donate ",costVo.donate)
        -- path = "diamond.png"
        myMoney = cm:getAssetData():getDiamond()
        -- btnTitle = "捐獻鑽石"
        type = "鑽石"
    end

    if cout >= lenMax then
        self.labDiamonTips:setVisible(true)
        self.labDiamonTips:setText(string.format("今天%s捐獻次數已滿%d次",type,lenMax))
        self.labDiamonTips:setPositionY(191)
        self.panelView2:setVisible(false)
        self.btnPush:setBright(false)
        self.btnPush:setTouchEnabled(false)
    else

        self.btnPush:setBright(true)
        self.btnPush:setTouchEnabled(true)
        
        self.labCost:setText(costVo.cost)
        self.labDonateMe:setText(costVo.donate)
        self.labDonateGuild:setText(costVo.donate)

        -- self.imgCurrency:loadTexture(path,UI_TEX_TYPE_PLIST)

        -- self.labDiamonTips:setText( string.format("（今日第%d次捐贈，還可捐贈%d次）",cout + 1,lenMax - cout) )
        self.panelView2:setVisible(true)
        -- self.labDiamonTips:setPositionY(97)

        _cost_value = costVo.cost
        if costVo.cost > myMoney then
            self.labCost:setColor(ItemHelper.colors.red)
            _tipsType = _curSelect
        else
            self.labCost:setColor(ItemHelper.colors.yellow)
        end

        self.labDiamonTips:setVisible(false)
    end

--------------------------------------------------------
    -- local sceneVo = dp:getGuildSceneVo()
    -- if sceneVo.donateTodayAdd >= 50000 then --每日公会资金 增量上限
    --     self.panelGuildView:setVisible(false)
    --     self.panelMeView:setPositionY(87)
    -- else
        -- self.panelGuildView:setVisible(true)
        -- self.panelMeView:setPositionY(106)
    -- end
end

function GuildDonatePanel:open()

    if CharacterDataProxy:getInstance():getVipLev() <= 0 then -- 非Vip玩家
        self.panelCoin:setPositionX(393)
        self.panelDiamon:setTouchEnabled(false)
        self.panelDiamon:setVisible(false)
    else
        self.panelCoin:setPositionX(282)
        self.panelDiamon:setPositionX(502)
        self.panelDiamon:setTouchEnabled(true)
        self.panelDiamon:setVisible(true)
    end

    self:update()
end

function GuildDonatePanel:close()
    _tipsType = nil
end