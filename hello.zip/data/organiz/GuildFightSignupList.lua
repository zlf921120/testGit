--------------------------------------------------------------------
--公会战 报名列表 条目
GuildFightSignupItem = class("GuildFightSignupItem",function()
    return Layout:create()
end)

GuildFightSignupItem.__index = GuildFightSignupItem
GuildFightSignupItem._widget = nil
GuildFightSignupItem.signupVo = nil

function GuildFightSignupItem:create()
    local ret = GuildFightSignupItem.new()
    ret:init()
    return ret
end

function GuildFightSignupItem:init()
    self._widget = GuildDataProxy:getInstance():getWidgetSignupListItem():clone()
    self:setSize(CCSize(844,144))
    self:addChild(self._widget)

    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labPopulation = tolua.cast(self._widget:getChildByName("lab_population"),"Label")
    self.labDesc = tolua.cast(self._widget:getChildByName("lab_desc"),"Label")

    self.guildIcon = GuildIcon:create()
    self.guildIcon:setPosition(ccp(76,70))
    self._widget:addChild(self.guildIcon,2)

    self.btnInfo = tolua.cast(self._widget:getChildByName("btn_info"),"Button")
    self.btnInfo:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Guild_View_FightScorePanel,
                {id=self.signupVo.id,
                type=GuildFightScoreType.Last,
                name=self.signupVo.name})
        end
    end)
end

function GuildFightSignupItem:setData(vo)
    self.signupVo = vo
    self:update()
end

function GuildFightSignupItem:update()
    self.labName:setText(self.signupVo.name)
    self.labDesc:setText(self.signupVo.declaration)
    self.labPopulation:setText(string.format("(%d人)",self.signupVo.population))

    self.guildIcon:setId(self.signupVo.logoId)
    self.guildIcon:setLev(self.signupVo.lev)
end

--------------------------------------------------------------------
-- 公会战 报名列表 场景
GuildFightSignupList = class("GuildFightSignupList",WindowBase)
GuildFightSignupList.__index = GuildFightSignupList
GuildFightSignupList._widget = nil
GuildFightSignupList.uiLayer = nil
GuildFightSignupList.is_dispose = true

local __instance = nil

function GuildFightSignupList:create()
    local ret = GuildFightSignupList.new()
    __instance = ret
    return ret
end

function GuildFightSignupList:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_FIGHT_SIGNUPLIST)
end

function GuildFightSignupList:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightSignupList.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.scrolSignup = DisplayUtil.createAdaptScrollView(844,405,144,0,1)
 	self.scrolSignup:setPosition(ccp(66,48))
    self._widget:addChild(self.scrolSignup,2)

    self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_SIGNUPLIST,function() 
        GuildRenderMgr:getInstance():renderFightSignupListAdapt(self.scrolSignup)

        self.scrolSignup:stopAllActions()
        self.scrolSignup:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolSignup:getInnerContainer():getPositionY()
                local viewRect = CCRectMake(0,math.abs(viewY),844,405)
                GuildRenderMgr:getInstance():refreshFightSignupVoList(viewRect,self.scrolSignup)
            end),
            CCDelayTime:create(0.1))))
        
        self:update()
    end)

    self.labSignNum = tolua.cast(self.uiLayer:getWidgetByName("lab_signup_num"),"Label")
end

function GuildFightSignupList:update()

    local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo() 
    self.labSignNum:setText(string.format("已報名公會數：%d個 ",sceneVo.signupNum))
end

function GuildFightSignupList:open()

    GuildNetTask:getInstance():requestGuildSignupList()
end