--公会聊天弹出层
GuildPopChatView = class("GuildPopChatView",function()
    return DisplayUtil.newFitLayer()
end)
GuildPopChatView.__index = GuildPopChatView
GuildPopChatView.chatArea = nil
local __instance = nil

function GuildPopChatView:getInstance()
    if not __instance then
        local ret = GuildPopChatView.new()
        __instance = ret
        ret:init()
        ret:retain()
    end
    return __instance
end

function GuildPopChatView:init()
    require "ChatCfg"
    self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/GuildPopChatView.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self.uiLayer:setTouchPriority(-2550)
    self:addChild(self.uiLayer)

    self.panelView = tolua.cast(self._widget:getChildByName("panel_view"),"Layout")
    self.labLev = tolua.cast(self.panelView:getChildByName("lab_level"),"Label")
    self.labName = tolua.cast(self.panelView:getChildByName("lab_name"),"Label")
    self.listView = tolua.cast(self._widget:getChildByName("list_view"),"ListView")

    self.btnOk = tolua.cast(self.panelView:getChildByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Chat_View,{dialog = 1})
        end
    end) 

    Notifier.regist(CmdName.BATTLE_RSP_START,function()
        GuildPopChatView:getInstance().progressTimer()
    end)
end

function GuildPopChatView:show()

    if WindowCtrl:getInstance():hasOpeningWinByName(CmdName.Chat_View) == false
        and (#CharacterDataProxy:getInstance():getGuildChatCacheList() > 0 or 
            #CharacterDataProxy:getInstance():getWorldChatCacheList() > 0 ) then

        CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/chat/face.plist")
        local layer = GameLayerMgr:getInstance():getMsgLayer()
        if layer then
            local child = layer:getChildByTag(3509)
            if child ~= nil then
                layer:removeChildByTag(3509,false)
            end
            local view = GuildPopChatView:getInstance()
            view:removeFromParentAndCleanup(false)
            view:setTag(3509)
            view:setPosition(ccp(0,0))
            layer:addChild(view)
        end
    else
        GuildPopChatView:hide()
    end 
end

function GuildPopChatView:setChatArea(chatArea)
    self.chatArea = chatArea
end

function GuildPopChatView:hide()
    local layer = GameLayerMgr:getInstance():getMsgLayer()
    if layer then
        local child = layer:getChildByTag(3509)
        if child ~= nil then
            layer:removeChildByTag(3509,false)
        end
    end
    GuildPopChatView:getInstance().listView:removeAllItems()
    TimerManager.removeTimer(GuildPopChatView:getInstance().progressTimer)
end

function GuildPopChatView.progressTimer()
    GuildPopChatView:show()
    __instance:checkShow() --检测队列
end

function GuildPopChatView:checkShow()

    local dp = CharacterDataProxy:getInstance()
    local voList = nil                  --local voList = dp:getGuildChatCacheList()
    voList = dp:getGuildChatCacheList()
    if #voList <= 0 then
        voList = dp:getWorldChatCacheList()
    end

    local isVis = BattleManager:getInstance():isBattle()
    self.btnOk:setTouchEnabled(not isVis)
    self.btnOk:setVisible(not isVis)

    if #voList > 0 then
        GuildPopChatView:getInstance().isPrepareRemoveSelf = 1

        if self.listView:getItems():count() > 1 then
            self.listView:removeItem(0)
        end

        local v = voList[1]
        self.labName:setText(v.name)
        self.labLev:setText(string.format("Lv.%d",v.level))

        -- local rtf = ChatHelper.createNodeRtf(v.txt,700,40,ccp(0,0))
        local rtf = ChatHelper.createTextRtf(v.txt,0,40,ccp(0,0))
        local layout = Layout:create()
        layout:setSize(CCSize(700,40))
        layout:addChild(rtf)
        self.listView:pushBackCustomItem(layout)
        self.listView:refreshView()
        self.listView:scrollToBottom(0.5,false)
        self.listView:stopAllActions()
        self.listView:runAction(CCSequence:createWithTwoActions(
            CCDelayTime:create(0.5),
            CCCallFunc:create(function()
            local scrollTime = 5 * 1000
            if rtf:getSize().width >= 550 then
                scrollTime = 7 * 1000

                local abs = rtf:getSize().width - 550
                rtf:stopAllActions()
                rtf:runAction(CCSequence:createWithTwoActions(
                    CCDelayTime:create(7),
                    CCMoveBy:create(1,ccp(-abs,0))))
            end
            table.remove(voList,1) --清理队列 

            TimerManager.addTimer(scrollTime,GuildPopChatView:getInstance().progressTimer)
        end)))
    else
         GuildPopChatView:hide()
         GuildPopChatView:getInstance().isPrepareRemoveSelf = nil
    end
    self.chatArea = nil   --重新赋值为nil
end