--内部成员条目
MemberItem = class("MemberItem",function()
    return Layout:create()
end)
MemberItem.__index = MemberItem
MemberItem._widget 	= nil
MemberItem.uiLayer = nil
MemberItem.id = 0
MemberItem.playerVo = nil

--成员 条目
function MemberItem:create(playerVo)
    local ret = MemberItem.new()
    ret:init(playerVo)
    return ret
end

--------------------------初始化----------------------------------------------
function MemberItem:init(playerVo)
    
	self._widget = GuildDataProxy:getInstance():getWidgetMemeberItem():clone()
    self:addChild(self._widget)
    self:setSize(CCSize(540,116))

    self.labDonate = tolua.cast(self._widget:getChildByName("lab_donate"),"Label")

    local p_icon = self._widget:getChildByName("p_icon")
    self.icon = HeadIcon:create()
    self.icon:setScale(0.9)
   
    self.imgBg = tolua.cast(self._widget:getChildByName("img_bg"),"ImageView")

    self.icon:setPosition(ccp(p_icon:getPosition()))
    self.icon:setClickEvent(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Comm_PlayerInfo,{vo = self.playerVo})
        end
    end)
    self._widget:addChild(self.icon)

    self.btnWorship = tolua.cast(self._widget:getChildByName("btn_worship"),"Button")
    self.btnWorship:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
        
            local limit = VipDataProxy:getInstance():getPrivilegeValue( VipPrivilegeType.GuildWorshipMax )
            local guildData = CharacterManager:getInstance():getGuildData()
            if guildData:getWorshipToday() >= limit then
                WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()

                    WindowCtrl:getInstance():open(CmdName.Vip_View)

                end, txt = string.format(OrganizCfg.GuildWorshipTips),
                okBtnName = "查看"})
            else
                WindowCtrl:getInstance():open(CmdName.Guild_View_ChoiceWorship,
                    {id = self.playerVo.id})
            end
        end
    end)

end

function MemberItem:setData(vo)
    self.playerVo = vo
    self:update()
end

function MemberItem:update()

    local playerVo = self.playerVo

    self.icon:setFaceId(playerVo.faceId,playerVo.sex)

	local labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    labName:setText(playerVo.name)

    local labLevel = tolua.cast(self._widget:getChildByName("lab_level"),"Label")
    labLevel:setText(playerVo.level)

    local labClazz = tolua.cast(self._widget:getChildByName("lab_clazz"),"Label")
    labClazz:setText(ClazzTypeName[playerVo.clazz + 1])

    if playerVo.role_id:match( CharacterManager:getInstance():getLoginData():getRoleId()) then--排除自己账号
        self.btnWorship:setTouchEnabled(false)
        self.btnWorship:setVisible(false)

        local assetData = CharacterManager:getInstance():getAssetData()

        self.labDonate:setText(string.format("貢獻：%s/%s",
        Helper.getChNumStr(assetData:getDonate()), 
        Helper.getChNumStr(assetData:getDonateTotal())))
    else
        if CharacterManager:getInstance():getTeamData():getLev() < playerVo.level then
            self.btnWorship:setTouchEnabled(true)
            self.btnWorship:setVisible(true)
        else
            self.btnWorship:setTouchEnabled(false)
            self.btnWorship:setVisible(false)
        end

        self.labDonate:setText(string.format("貢獻：%s/%s",
        Helper.getChNumStr(playerVo.donateCur), 
        Helper.getChNumStr(playerVo.donateTotal)))
    end

    if OrganizHelper.getCurPlayerVo() == playerVo then
        self.imgBg:loadTexture("btn_down_7.png",UI_TEX_TYPE_PLIST)
    else
        self.imgBg:loadTexture("btn_up_7.png",UI_TEX_TYPE_PLIST)
    end

    
end