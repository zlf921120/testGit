-- 公会 本地xls数据读取类
GuildLocalReader = class("GuildLocalReader")

local __instance = nil
local _allowInstance = false
local _hasLoadGuildLocalReader = false

function GuildLocalReader:ctor()
    if not _allowInstance then
		error("GuildLocalReader is a singleton class")
	end
	self:init()
end

function GuildLocalReader:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = GuildLocalReader.new()
		_allowInstance = false
	end

	return __instance
end

function GuildLocalReader:init()
    require "fnt_guild_data_pb"
    
    require("GuildDataProxy")
end

function GuildLocalReader:loadInProxy()

    if _hasLoadGuildLocalReader then return end--只加载一次
    _hasLoadGuildLocalReader = true

    require "OrganizCfg"
    local dp = GuildDataProxy:getInstance()
	
    local pbdata = FileUtils.readConfigFile("fnt_guild_data.dat")
    
    local msg = fnt_guild_data_pb.fnt_guild_data()
    msg:ParseFromString(pbdata)

    local configArr = msg.config_data_rows
    local itemVo = dp:getWorshipChoiceVo()
---------------公会配置-------------------------
    for k,v in pairs(configArr) do
    	if v.type == WorshipType.Free then
    		itemVo.free_physical = v.physical
    		itemVo.free_cost = v.cost
    	elseif v.type == WorshipType.Coin then
    		itemVo.coin_physical = v.physical
    		itemVo.coin_cost = v.cost
    	elseif v.type == WorshipType.Diamon then
    		itemVo.diamon_physical = v.physical
    		itemVo.diamon_cost = v.cost
    	end
    end
---------------公会图标-------------------------
    local iconArr = msg.guild_icon_rows

    for k,v in pairs(iconArr) do
        if v.id ~= nil then
            local iconVo = dp:createIconVo()
            iconVo.id = v.id
            iconVo.resId = v.res_id
            iconVo.bgId = v.bg_id
            dp:setIconVo(iconVo)
        end
    end
-----------------公会升级消耗------------------------------
    local levupUnit = msg.lev_add_loss_rows
    for k,v in pairs(levupUnit) do
        if v.lev ~= nil then
            local costVo = dp:createLevupCostVo()
            costVo.lev = v.lev
            costVo.coin = v.coin
            dp:setLevupCostVo(costVo)
        end
    end
-----------------群发邮件消耗------------------------------
    local mailUnit = msg.mail_loss_rows
    for k,v in pairs(mailUnit) do
        if v.cout ~= nil then
            local costVo = dp:createMailCostVo()
            costVo.cout = v.cout
            costVo.cost = v.cost
            dp:setMailCostVo(costVo)
        end
    end
-----------------公会人员上限 ------------------------------
    local limitUnit = msg.guild_lev_update_rows
    for k,v in pairs(limitUnit) do
        if v.lev ~= nil then
            local limitVo = dp:createLevLimitVo()
            limitVo.lev = v.lev
            limitVo.people = v.people
            limitVo.todayLimitDonate = v.today_limit_donate
            dp:setLevLimitVo(limitVo)
        end
    end
-----------------捐赠消耗  金币------------------------------
    local donateUnit = msg.contribute_loss_rows
    for k,v in pairs(donateUnit) do
        if v.init_donate ~= nil then
            local viewVo = dp:getDonatePanelVo()
            viewVo.initCoin = v.init_donate
            viewVo.coinAdd = v.coin_add
            viewVo.donateMeAdd = v.donate_me_add
            viewVo.donateGuildAdd = v.donate_guild_add
        end
    end
-----------------捐赠消耗  钻石------------------------------
    local goldCostUnit = msg.contribute_gold_loss_rows
    for k,v in pairs(goldCostUnit) do
        if v.cout ~= nil then
            local costVo = dp:createDonateCostVo()
            costVo.cout = v.cout
            costVo.cost = v.cost
            costVo.donate = v.donate
            dp:setDiamonDonateCostVo(costVo)
        end
    end 
-----------------免申请设置 ------------------------------
    local quickUnit = msg.quick_join_rows
    for k,v in pairs(quickUnit) do
        if v.guild_type ~= nil then
            local quickVo = dp:createQuickJoinVo()
            quickVo.id = v.guild_type
            quickVo.lev = v.lev
            dp:setQuickJoinVo(quickVo)
        end
    end
-------------------公会技能 ---------------------------------------
    local skillData = nil
    local skillId = 0
    local scriptArgsList = nil
    local skillUnit = msg.guild_pas_skill_rows
    for k, v in pairs(skillUnit) do

        if v.id then

            skillId = tonumber(v.id)

            if not dp._passiveSkillDataDict[skillId] then
                dp._passiveSkillDataDict[skillId] = {}

                dp._skillTypeDict[skillId] = SkillType.PASS
            end

            skillData = SkillPassiveVO:create()
            skillData.id = tonumber(v.id)
            skillData.name = v.name
            skillData.lev = tonumber(v.lev)
            skillData.heroLevel = tonumber(v.hero_lev)
            skillData.upgradeCostGold = tonumber(v.cost_gold)

            skillData.hp = tonumber(v.hp)
            skillData.atk = tonumber(v.atk)
            skillData.pdef = tonumber(v.pdef)
            skillData.crit = tonumber(v.crit)
            skillData.block = tonumber(v.block)
            skillData.break_atk = tonumber(v.break_atk)
            skillData.evasion = tonumber(v.evasion)
            skillData.fight_back = tonumber(v.fight_back)
            skillData.def_break = tonumber(v.def_break)
            skillData.real_harm = tonumber(v.real_harm)
            skillData.anti_stun = tonumber(v.anti_stun)
            skillData.anti_silent = tonumber(v.anti_silent)
            skillData.anti_chaos = tonumber(v.anti_chaos)
            skillData.anti_stone = tonumber(v.anti_stone)
            skillData.anti_polymorph = tonumber(v.anti_polymorph)
            skillData.anti_taunt = tonumber(v.anti_taunt)
            skillData.anti_sleep = tonumber(v.anti_sleep)
            skillData.suck_blood = tonumber(v.suck_blood)
            skillData.tought = tonumber(v.tought)
            
            skillData.scriptId = tonumber(v.script_id)      
            
            if skillData.scriptId ~= 0 then
                
                scriptArgsList = loadstring(string.format("return %s", v.script_args))()

                for i, v in ipairs(scriptArgsList) do
                    skillData:addScriptArg(v)
                end
            end

            skillData.desc = v.desc

            dp._passiveSkillDataDict[skillId][skillData.lev] = skillData
            -- cclog("工會技能ID=%d，技能等級=%d",skillId, skillData.lev)
            -- table.insert(dp._passiveSkillDataDict[skillId], skillData)
------------------------------------------------------------------------------------------
            local skillDescVo = dp:createSkillVo()
            skillDescVo.lev = tonumber(v.lev)
            skillDescVo.id = tonumber(v.id)
            skillDescVo.name = v.name
            skillDescVo.guild_lev = tonumber(v.guild_lev)
            skillDescVo.guild_donate_cost = tonumber(v.levup_donate_cost)
            skillDescVo.me_donate_cost = tonumber(v.learn_donate_cost)
            skillDescVo.cost_gold = tonumber(v.cost_gold)
            skillDescVo.desc = v.desc
            dp:setSkillDescVo(skillDescVo)

        end
    end
-------------------公会Boss ---------------------------------------
    require "MonsterManager"
    local bossUnit = msg.guild_drop_boss_rows
    for k,v in pairs(bossUnit) do
        if v.base_id ~= nil then
            local monstorAttr = MonsterManager:getInstance():getBaseAttr(v.base_id)
            local hpMax = monstorAttr[ AttrHelper.attr_flag.hp ]

            local bossVo = dp:createBossVo()
            bossVo.id = v.base_id
            bossVo.rewardList = Utils.Split(v.reward_list,",")
            bossVo.cost_donate = v.cost_donate
            bossVo.guild_lev = v.lev
            bossVo.hp = hpMax
            bossVo.scale = v.boss_scale
            bossVo.pos = Utils.split(v.boss_pos,",")
            bossVo.battle_id = v.battle_id
            bossVo.boss_img = v.boss_img
            dp:setBossVo(bossVo)
            table.insert( dp.bossVoTblList ,bossVo )
            bossVo.idx = #dp.bossVoTblList
        end
    end
    table.sort( dp.bossVoTblList, function(a,b) return a.id < b.id end )
--------------------公会竞拍----------------------------------------
    local auctionUnit = msg.guild_auction_rows
    for k,v in pairs(auctionUnit) do
        if v.base_id ~= nil then
            local auctionDataVo = dp:createAuctionDataVo()
            auctionDataVo.base_id = v.base_id
            auctionDataVo.low_bid = v.low_bid
            auctionDataVo.pass_left = v.pass_left
            dp:setAuctionDataVo(auctionDataVo)
        end
    end
------------------报名消耗 ---------------------------------------
    local signupUnit = msg.guild_signup_loss_rows
    for k,v in pairs(signupUnit) do
        if v.cost_type == GuildCostType.GuildDonate then
            dp:getGuildFightSceneVo().signupCost = v.cost
        elseif v.cost_type == GuildCostType.GuildLev then
            dp:getGuildFightSceneVo().signupLev = v.cost
        end
    end
------------------公会战 助威-------------------------
    local cheerUnit = msg.guild_cheer_rows
    for k,v in pairs(cheerUnit) do
        if v.step_num ~= nil then
            local cheerVo = dp:createFightCheerVo()
            cheerVo.id = v.step_num
            cheerVo.cheer_num = v.cheer_num --需要助威人数
            cheerVo.protection_limit = v.protection_limit
            cheerVo.defence_limit = v.defence_limit
            cheerVo.hp_addition = v.hp_addition
            cheerVo.power_limit = v.power_limit
            cheerVo.act_addition = v.act_addition
            dp:setFightCheerVo( cheerVo )
        end
    end
-----------------公会战 战斗冷却------------------------
    local combatColdUnit = msg.guild_battle_cold_rows
    for k,v in pairs(combatColdUnit) do
        if v.combat_num ~= nil then
            local coldVo = dp:createCombatColdVo()
            coldVo.combat_num = v.combat_num
            coldVo.cd_time = v.cd_time
            dp:setCombatColdVo(coldVo)
        end
    end
------------------------------------------------------
    local function makeRewardTbl(str)
        local ret = {}
        local tblArr = Utils.split(str,",")
        for i,v in ipairs(tblArr) do
            local t = Utils.split(v,";")
            table.insert(ret,{base_id = tonumber(t[1]), quantity = tonumber(t[2])}) 
        end
        return ret
    end
    local fightRewardUnit = msg.guild_combat_reward_rows
    for k,v in pairs(fightRewardUnit) do
        if v.reward_flag ~= nil then
            local list = dp:getRankRewardList()
            list[1] = makeRewardTbl(v.members_rank_reward_1)
            list[2] = makeRewardTbl(v.members_rank_reward_2)
            list[3] = makeRewardTbl(v.members_rank_reward_3)
            list[4] = makeRewardTbl(v.members_rank_reward_4_5)
            list[5] = makeRewardTbl(v.members_rank_reward_6_10)
        end
    end
end