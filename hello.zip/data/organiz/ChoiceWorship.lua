--选择 膜拜 面板

ChoiceWorship = class("ChoiceWorship",WindowBase)
ChoiceWorship.__index = ChoiceWorship
ChoiceWorship._widget     = nil
ChoiceWorship.uiLayer    = nil
ChoiceWorship.is_dispose = true

local __instance = nil
local _id = 0

function ChoiceWorship:create()
    local ret = ChoiceWorship.new()
    __instance = ret
    return ret   
end

function ChoiceWorship:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
    Notifier.removeByName(OrganizEvent.CB_CLOSE_CHOICE_WORSHIP)
end

--------------------响应事件-----------------------------------
local lastSelect = nil
local worshipType = 0
local _number = 15

local function event_btn_cancel(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
         __instance:addCloseAnim()
    end
end

local function event_cb_close()
    __instance:addCloseAnim()
end

local function event_btn_ok(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then 
    
        if worshipType == WorshipType.Diamon then
            VipDataProxy:getInstance():isCanOpen(VipPrivilegeType.GuildWorship3,function()
                GuildNetTask:getInstance():requestWorship(worshipType,_id,_number)
            end)
        else
            GuildNetTask:getInstance():requestWorship(worshipType,_id,_number)
        end
        
    end
end

local function event_btn_free(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        local btn = tolua.cast(pSender,"Button")
        local selectImg = btn:getChildByName("img_select")
        if selectImg ~= lastSelect then
            selectImg:setVisible(true)
            lastSelect:setVisible(false)
            lastSelect = selectImg

            worshipType = WorshipType.Free
            _number = GuildDataProxy:getInstance():getWorshipChoiceVo().free_cost
        end
    end
end

local function event_btn_coin(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        local btn = tolua.cast(pSender,"Button")
        local selectImg = btn:getChildByName("img_select")
        if selectImg ~= lastSelect then
            selectImg:setVisible(true)
            lastSelect:setVisible(false)
            lastSelect = selectImg

            worshipType = WorshipType.Coin
            _number = GuildDataProxy:getInstance():getWorshipChoiceVo().coin_cost
        end
    end
end

local function event_btn_diamon(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        local btn = tolua.cast(pSender,"Button")
        local selectImg = btn:getChildByName("img_select")
        if selectImg ~= lastSelect then
            selectImg:setVisible(true)
            lastSelect:setVisible(false)
            lastSelect = selectImg

            worshipType = WorshipType.Diamon
            _number = GuildDataProxy:getInstance():getWorshipChoiceVo().diamon_cost
        end
    end
end

----------------------初始化--------------------------------------

function ChoiceWorship:init()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/ChoiceWorship.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.panelWorshop1 = self._widget:getChildByName("panel_worship1")
    self.panelWorshop2 = self._widget:getChildByName("panel_worship2")
    self.panelWorshop3 = self._widget:getChildByName("panel_worship3")

    local btnFree = tolua.cast(self.panelWorshop1:getChildByName("btn_free"),"Button")
    btnFree:addTouchEventListener(event_btn_free)
    lastSelect = btnFree:getChildByName("img_select")

    local btnCoin = tolua.cast(self.panelWorshop2:getChildByName("btn_coin"),"Button")
    btnCoin:addTouchEventListener(event_btn_coin)

    local btnDiamon = tolua.cast(self.panelWorshop3:getChildByName("btn_diamon"),"Button")
    btnDiamon:addTouchEventListener(event_btn_diamon)

    local btnCancel = tolua.cast(self.uiLayer:getWidgetByName("btn_cancel"),"Button")
    btnCancel:addTouchEventListener(event_btn_cancel)
    
    local btnOk = tolua.cast(self.uiLayer:getWidgetByName("btn_ok"),"Button")
    btnOk:addTouchEventListener(event_btn_ok)

    Notifier.regist(OrganizEvent.CB_CLOSE_CHOICE_WORSHIP,event_cb_close)
end

function ChoiceWorship:open()
	
    _id = self.params["id"]
	
    local choiceVo = GuildDataProxy:getInstance():getWorshipChoiceVo()

    local labPhysicalFree = tolua.cast(self.panelWorshop1:getChildByName("lab_physical_free"),"Label")
    labPhysicalFree:setText(choiceVo.free_physical)

    local labPhysicalCoin = tolua.cast(self.panelWorshop2:getChildByName("lab_physical_coin"),"Label")
    labPhysicalCoin:setText(choiceVo.coin_physical)

    local labPhysicalDiamon = tolua.cast(self.panelWorshop3:getChildByName("lab_physical_diamon"),"Label")
    labPhysicalDiamon:setText(choiceVo.diamon_physical)

    local labCostCoin = tolua.cast(self.panelWorshop2:getChildByName("lab_reward_coin"),"Label")
    labCostCoin:setText(choiceVo.coin_cost)

    local labCostDiamon = tolua.cast(self.panelWorshop3:getChildByName("lab_reward_diamon"),"Label")
    labCostDiamon:setText(choiceVo.diamon_cost)

    self.panelWorshop3:setVisible(false)
    self.panelWorshop3:setPosition(ccp(0,10000)) --飞出屏幕  不让玩家点...
    self.panelWorshop1:setPosition(ccp(251,188))
    self.panelWorshop2:setPosition(ccp(500,188))

    local assetData = CharacterManager:getInstance():getAssetData()
    if assetData:getDiamond() < choiceVo.diamon_cost then
        labCostDiamon:setColor(ItemHelper.colors.red)
    else
        labCostDiamon:setColor(ItemHelper.colors.yellow)
    end

    if assetData:getGold() < choiceVo.coin_cost then
        labCostCoin:setColor(ItemHelper.colors.red)
    else
        labCostCoin:setColor(ItemHelper.colors.yellow)
    end

    self:addOpenAnim()

    --检测是否 解锁vip特权
    VipDataProxy:getInstance():isCanOpen(VipPrivilegeType.GuildWorship3,function()
        self.panelWorshop3:setVisible(true)
        self.panelWorshop3:setPosition(ccp(572,188))
        self.panelWorshop1:setPosition(ccp(211,188))
        self.panelWorshop2:setPosition(ccp(394,188))
    end,false)
end

function ChoiceWorship:close()

end