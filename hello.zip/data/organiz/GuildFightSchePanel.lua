-----------------------------------------------------------------
--公会战 全服 战况条目
GuildFightSituationItem = class("GuildFightSituationItem",function()
    return Layout:create()
end)
GuildFightSituationItem.__index = GuildFightSituationItem
GuildFightSituationItem._widget     = nil
GuildFightSituationItem.combatVo = nil

function GuildFightSituationItem:create()
    local ret = GuildFightSituationItem.new()
    ret:init()
    return ret
end

function GuildFightSituationItem:init()

	self._widget = GuildDataProxy:getInstance():getWidgetFightSituationItem():clone()
    self:setSize(CCSize(840,138))
    self:addChild(self._widget)

    self.btnCheck1 = tolua.cast(self._widget:getChildByName("btn_check1"),"Button")
    self.btnCheck1:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            if GuildDataProxy:getInstance():getGuildFightSceneVo().curMoment == GuildFightMoment.BattleFinishPerpare then
                WindowCtrl:getInstance():open(CmdName.Guild_View_FightScorePanel,
                {id=self.combatVo.guildId1,
                type=GuildFightScoreType.Last,
                name=self.combatVo.name1})
            else
                WindowCtrl:getInstance():open(CmdName.Guild_View_FightScorePanel,
                {id=self.combatVo.guildId1,
                type=GuildFightScoreType.Current,
                name=self.combatVo.name1})
            end
        end
    end)

    self.btnCheck2 = tolua.cast(self._widget:getChildByName("btn_check2"),"Button")
    self.btnCheck2:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            if GuildDataProxy:getInstance():getGuildFightSceneVo().curMoment == GuildFightMoment.BattleFinishPerpare then
                WindowCtrl:getInstance():open(CmdName.Guild_View_FightScorePanel,
                {id=self.combatVo.guildId2,
                type=GuildFightScoreType.Last,
                name=self.combatVo.name2})
            else
                WindowCtrl:getInstance():open(CmdName.Guild_View_FightScorePanel,
                {id=self.combatVo.guildId2,
                type=GuildFightScoreType.Current,
                name=self.combatVo.name2})
            end
        end
    end)

    self.guildIcon1 = GuildIcon:create()
    self.guildIcon1:setPosition(ccp(208,73))
    self._widget:addChild(self.guildIcon1,2)

    self.guildIcon2 = GuildIcon:create()
    self.guildIcon2:setPosition(ccp(636,68))
    self._widget:addChild(self.guildIcon2,2)

    self.imgWin = tolua.cast(self._widget:getChildByName("img_win"),"ImageView")
    self.labName1 = tolua.cast(self._widget:getChildByName("lab_name1"),"Label")
    self.labName2 = tolua.cast(self._widget:getChildByName("lab_name2"),"Label")
    self.labNum1 = tolua.cast(self._widget:getChildByName("lab_num1"),"Label")
    self.labNum2 = tolua.cast(self._widget:getChildByName("lab_num2"),"Label")
end

function GuildFightSituationItem:setData(vo)
    self.combatVo = vo
    self:update()
end

function GuildFightSituationItem:update()

    if self.combatVo.name1 == "" then
        self.guildIcon1:setVisible(false)
        self.labName1:setText("輪空")
        self.labNum1:setVisible(false)
    else
        self.guildIcon1:setVisible(true)
        self.labNum1:setVisible(true)
        self.guildIcon1:setId(self.combatVo.logoId1)
        self.guildIcon1:setLev(self.combatVo.lev1)
        self.labName1:setText(self.combatVo.name1)
        self.labNum1:setText(string.format("(%d人)",self.combatVo.num1))
    end

    if self.combatVo.name2 == "" then
        self.guildIcon2:setVisible(false)
        self.labName2:setText("輪空")
        self.labNum2:setVisible(false)
    else
        self.guildIcon2:setVisible(true)
        self.labNum2:setVisible(true)
        self.guildIcon2:setId(self.combatVo.logoId2)
        self.guildIcon2:setLev(self.combatVo.lev2)
        self.labName2:setText(self.combatVo.name2)
        self.labNum2:setText(string.format("(%d人)",self.combatVo.num2))
    end

    if self.combatVo.isWin == 1 then
        self.imgWin:setPositionX(241)
    else
        self.imgWin:setPositionX(638)
    end
end
-----------------------------------------------------------------
--公会战 全服 战况条目 标题
GuildFightSituationTitleItem = class("GuildFightSituationTitleItem",function()
    return Layout:create()
end)
GuildFightSituationTitleItem.__index = GuildFightSituationTitleItem
GuildFightSituationTitleItem._widget     = nil
GuildFightSituationTitleItem.titleVo = nil

function GuildFightSituationTitleItem:create()
    local ret = GuildFightSituationTitleItem.new()
    ret:init()
    return ret
end

function GuildFightSituationTitleItem:init()

	self._widget = GuildDataProxy:getInstance():getWidgetFightSituationTitleItem():clone()
    self:setSize(CCSize(830,55))
    self:addChild(self._widget)

    self.labTitle = tolua.cast(self._widget:getChildByName("lab_session"),"Label")

end

function GuildFightSituationTitleItem:setData(vo)
    self.titleVo = vo
    self:update()
end

function GuildFightSituationTitleItem:update()

    self.labTitle:setText(string.format("第%s場",Helper.converNumToChinese(self.titleVo.id)))
end

------------------------------------------------------------------
--公会战 日程 条目
GuildFightScheItem = class("GuildFightScheItem",function()
    return Layout:create()
end)
GuildFightScheItem.__index = GuildFightScheItem
GuildFightScheItem._widget     = nil
GuildFightScheItem.scoreVo = nil
GuildFightScheItem.idx = 0

function GuildFightScheItem:create()
    local ret = GuildFightScheItem.new()
    ret:init()
    return ret
end

function GuildFightScheItem:init()

	self._widget = GuildDataProxy:getInstance():getWidgetFightScheItem():clone()
	self:setSize(CCSize(840,116))
	self:addChild(self._widget)

    self.labDay1 = tolua.cast(self._widget:getChildByName("lab_day_1"),"Label")
    self.labTime1 = tolua.cast(self._widget:getChildByName("lab_time1"),"Label")
    self.lab = tolua.cast(self._widget:getChildByName("lab_session"),"Label")

    self.labTxt1 = tolua.cast(self._widget:getChildByName("lab_txt1"),"Label")
    self.labTxt2 = tolua.cast(self._widget:getChildByName("lab_txt2"),"Label")
    self.labTxt3 = tolua.cast(self._widget:getChildByName("lab_txt3"),"Label")
    self.imgBg = tolua.cast(self._widget:getChildByName("img_bg"),"ImageView")
    self.btnClick = tolua.cast(self._widget:getChildByName("btn_click"),"Button")

    self.imgLine = tolua.cast(self._widget:getChildByName("img_line"),"ImageView")
	self.imgWin = tolua.cast(self._widget:getChildByName("img_win"),"ImageView")
    self.imgArrow = tolua.cast(self._widget:getChildByName("img_arrow"),"ImageView")

    self.btnClick:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            local tag = sender:getTag()
            if tag == 1 then -- 备战

                WindowCtrl:getInstance():close(CmdName.Guild_View_FightSchePanel)
                WindowCtrl:getInstance():close(CmdName.Guild_View_FightScene)
                WindowCtrl:getInstance():open(CmdName.Guild_View_FightPerpare)
            elseif tag == 2 then --对手情报

                WindowCtrl:getInstance():close(CmdName.Guild_View_FightSchePanel)
                WindowCtrl:getInstance():close(CmdName.Guild_View_FightScene)
                WindowCtrl:getInstance():open(CmdName.Guild_View_FightPerpare,{enemy=1})
            elseif tag == 3 then --挑战

                WindowCtrl:getInstance():close(CmdName.Guild_View_FightSchePanel)
                WindowCtrl:getInstance():close(CmdName.Guild_View_FightScene)
                WindowCtrl:getInstance():open(CmdName.Guild_View_FightBattle)
            elseif tag == 4 then --查看
                
                local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()
                WindowCtrl:getInstance():open(CmdName.Guild_View_FightScorePanel,
                {id=CharacterManager:getInstance():getGuildData():getId(),
                type=GuildFightScoreType.Current,
                name=CharacterManager:getInstance():getGuildData():getName()})
            end
        end
    end)
end

function GuildFightScheItem:setData(vo)
	self.scoreVo = vo
	self:update()
end

function GuildFightScheItem:update()
    self.labTxt1:setText("")
    self.labTxt2:setText("")
    self.labTxt3:setText("")
    self.imgBg:setVisible(false)
    self.btnClick:setVisible(false)
    self.btnClick:setTouchEnabled(false)
    self.imgArrow:setVisible(false)
    self.imgWin:setVisible(false)
    self.imgLine:loadTexture("guild_sche_line1.png",UI_TEX_TYPE_PLIST)

    local monentTxt = ""
    if self.scoreVo.monent == GuildFightMoment.SignupIng then
        monentTxt = "報名階段"
        self.labTxt1:setText(monentTxt)
    elseif self.scoreVo.monent == GuildFightMoment.SignupAfter then
        self.labTxt1:setText(string.format("第%s場",Helper.converNumToChinese(self.scoreVo.session)))
        monentTxt = "備戰階段"
        self.labTxt2:setText(monentTxt)
        self.btnClick:setTitleText("備戰")
        self.btnClick:setTag(1)
    elseif self.scoreVo.monent == GuildFightMoment.BattleBefore then
        self.labTxt1:setText(string.format("第%s場",Helper.converNumToChinese(self.scoreVo.session)))
        monentTxt = "公會戰即將開始"
        self.labTxt2:setText(monentTxt)
        self.btnClick:setTitleText("對手情報")
        self.btnClick:setTag(2)
    elseif self.scoreVo.monent == GuildFightMoment.BattleIng then
        self.labTxt1:setText(string.format("第%s場",Helper.converNumToChinese(self.scoreVo.session)))
        monentTxt = "會戰階段"
        self.labTxt2:setText(monentTxt)
        self.btnClick:setTitleText("挑戰")
        self.btnClick:setTag(3)
    elseif self.scoreVo.monent == GuildFightMoment.BattleFinish then
        self.labTxt1:setText("即將揭曉")
        self.labTxt2:setText("公會戰排名名次")

        self.imgArrow:setVisible(true)
    end
------------------------------------------------------------------
    local dp = GuildDataProxy:getInstance()
    local sceneVo = dp:getGuildFightSceneVo()
    local checkMonet = GuildFightMoment.SignupBefore
    if sceneVo.curMoment == GuildFightMoment.SignupBefore or 
        sceneVo.curMoment == GuildFightMoment.SignupIng then

        checkMonet = GuildFightMoment.SignupIng
    elseif sceneVo.curMoment == GuildFightMoment.SignupAfter or
            sceneVo.curMoment == GuildFightMoment.BattleAfter then

        checkMonet = GuildFightMoment.SignupAfter
    elseif sceneVo.curMoment == GuildFightMoment.BattleBefore then

        checkMonet = GuildFightMoment.BattleBefore
    elseif sceneVo.curMoment == GuildFightMoment.BattleIng then

        checkMonet = GuildFightMoment.BattleIng
    elseif checkMonet == GuildFightMoment.BattleFinish or
            checkMonet == GuildFightMoment.BattleFinishPerpare then

        checkMonet = GuildFightMoment.BattleFinish
    end
-------------------------------------------------------------------
    if checkMonet == self.scoreVo.monent and 
        sceneVo.curScheId == self.scoreVo.session and 
        checkMonet ~= GuildFightMoment.SignupIng then

        self.imgBg:setVisible(true)
        self.imgLine:loadTexture("guild_sche_line2.png",UI_TEX_TYPE_PLIST)

        if checkMonet == GuildFightMoment.BattleFinish then
            --不用做什么
        else
            self.btnClick:setVisible(true)
            self.btnClick:setTouchEnabled(true)

            self.labTxt1:setText(string.format("第%s場 %s",Helper.converNumToChinese(self.scoreVo.session),monentTxt))
            self.labTxt2:setText("匹配對手公會：")
            if sceneVo.enemyInfo.name == "" then
                self.labTxt3:setText("輪空")
                self.btnClick:setVisible(false)
                self.btnClick:setTouchEnabled(false)
            else
                self.labTxt3:setText(sceneVo.enemyInfo.name)
            end
        end

    elseif self.scoreVo.monent == GuildFightMoment.BattleIng and --已经打过了
            sceneVo.curScheId > self.scoreVo.session then 

        self.imgWin:setVisible(true)
        self.btnClick:setVisible(true)
        self.btnClick:setTouchEnabled(true)
        self.btnClick:setTitleText("查看")
        local recordVo = dp:getMyCombatRecordVoById(self.scoreVo.session)
        if recordVo then
            self.btnClick:setTag(4)
            if recordVo.isWin == 1 then
                self.imgWin:loadTexture("i18n_guild_win.png",UI_TEX_TYPE_PLIST)
            else
                self.imgWin:loadTexture("i18n_guild_loss.png",UI_TEX_TYPE_PLIST)
            end

            self.labTxt1:setText(string.format("第%s場 %s",Helper.converNumToChinese(self.scoreVo.session),"會戰階段"))
            self.labTxt2:setText("匹配對手公會：")
            if recordVo.name2 == "" then
                self.labTxt3:setText("輪空")
                self.btnClick:setVisible(false)
                self.btnClick:setTouchEnabled(false)
            else
                self.labTxt3:setText(recordVo.name2)
            end
        else
            self.imgWin:setVisible(false)
            self.btnClick:setVisible(false)
            self.btnClick:setTouchEnabled(false)
        end
    elseif GuildFightMoment.SignupAfter == self.scoreVo.monent and --已经备战过了
            sceneVo.curScheId > self.scoreVo.session then 
        local recordVo = dp:getMyCombatRecordVoById(self.scoreVo.session)
        if recordVo and recordVo.name == "" then
            self.btnClick:setVisible(false)
            self.btnClick:setTouchEnabled(false)
        end
    end

	self.labDay1:setText(os.date("%m月%d日",self.scoreVo.time))
    self.labTime1:setText(os.date("%H:%M",self.scoreVo.time))
end

------------------------------------------------------------------
-- 公会战 日程 面板
GuildFightSchePanel = class("GuildFightSchePanel",WindowBase)
GuildFightSchePanel.__index = GuildFightSchePanel
GuildFightSchePanel._widget = nil
GuildFightSchePanel.uiLayer = nil
GuildFightSchePanel.btnLast = nil
GuildFightSchePanel.panelLast = nil

local __instance = nil

function GuildFightSchePanel:create()
    local ret = GuildFightSchePanel.new()
    __instance = ret
    return ret
end

function GuildFightSchePanel:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightSchePanel.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    self.btnSche = tolua.cast(self.uiLayer:getWidgetByName("btn_sche"),"Button")
    self.btnSche:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then

        	self.panelSche:setVisible(true)
	        self.panelSche:setZOrder(4)

	        self.btnSche:setFocused(true)
	        self.btnSche:setTitleColor(ccc3(210,253,238))
	        if self.btnLast ~= self.btnSche then
	            self.btnLast:setFocused(false)
	            self.btnLast:setTitleColor(ccc3(245,204,85))
	            self.btnLast = self.btnSche
	            
	            self:cleanAllRefresh()
                Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_SCHE_LIST)

	            self.panelLast:setVisible(false)
	            self.panelLast:setZOrder(1)
	            self.panelLast = self.panelSche

	        end
        end
    end)

    self.btnAll = tolua.cast(self.uiLayer:getWidgetByName("btn_all"),"Button")
    self.btnAll:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then

        	self.panelAll:setVisible(true)
	        self.panelAll:setZOrder(4)

	        self.btnAll:setFocused(true)
	        self.btnAll:setTitleColor(ccc3(210,253,238))
	        if self.btnLast ~= self.btnAll then
	            self.btnLast:setFocused(false)
	            self.btnLast:setTitleColor(ccc3(245,204,85))
	            self.btnLast = self.btnAll
	            
	            self:cleanAllRefresh()

                if GuildDataProxy:getInstance():getGuildFightSceneVo().curMoment == GuildFightMoment.BattleFinishPerpare then
                    GuildNetTask:getInstance():requestGuildFightAllScheList(GuildFightScoreType.Last)
                else
                    GuildNetTask:getInstance():requestGuildFightAllScheList(GuildFightScoreType.Current)
                end

	            self.panelLast:setVisible(false)
	            self.panelLast:setZOrder(1)
	            self.panelLast = self.panelAll
	        end
        end
    end)

    self.btnLast = self.btnSche  
    self.btnSche:setFocused(true)
    self.btnSche:setTitleColor(ccc3(210,253,238))

    self.panelSche = tolua.cast(self.uiLayer:getWidgetByName("panel_sche"),"Layout")
    self.panelAll = tolua.cast(self.uiLayer:getWidgetByName("panel_all"),"Layout")
    self.panelLast = self.panelSche
    self.listView = tolua.cast(self.uiLayer:getWidgetByName("list_view"),"ListView")

    self.scrolFight = DisplayUtil.createAdaptScrollView(840,450,0,0,1)
   	self.scrolFight:setPosition(ccp(0,0))
    self.panelAll:addChild(self.scrolFight)

    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_ALL_COMBAT_LIST,function() 
        GuildRenderMgr:getInstance():renderFightScheAllListAdapt(self.scrolFight)

        self.lastScheAllViewY = -1

        self.scrolFight:stopAllActions()
        self.scrolFight:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolFight:getInnerContainer():getPositionY()
                if self.lastScheAllViewY ~= viewY then 
                    self.lastScheAllViewY = viewY
                    local viewRect = CCRectMake(0,math.abs(viewY),840,450)
                    GuildRenderMgr:getInstance():refreshFightScheAllList(viewRect,self.scrolFight)
                end
            end),
            CCDelayTime:create(0.1))))
    end)

    self.scrolSche = DisplayUtil.createAdaptScrollView(840,450,0,0,1)
    self.scrolSche:setPosition(ccp(0,0))
    self.panelSche:addChild(self.scrolSche)

    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_SCHE_LIST,function() 
        GuildRenderMgr:getInstance():renderFightScheListAdapt(self.scrolSche)

        self.lastScheViewY = -1

        self.panelSche:stopAllActions()
        self.panelSche:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()

                local viewY = self.scrolSche:getInnerContainer():getPositionY()
                if self.lastScheViewY ~= viewY then 
                    self.lastScheViewY = viewY
                    local viewRect = CCRectMake(0,math.abs(viewY),840,450)
                    GuildRenderMgr:getInstance():refreshFightScheList(viewRect,self.scrolSche)
                end
            end),
            CCDelayTime:create(0.1))))
    end)

end

function GuildFightSchePanel:resetView()
    self.panelSche:setVisible(true)
    self.panelSche:setZOrder(4)

    self.btnSche:setFocused(true)
    self.btnSche:setTitleColor(ccc3(210,253,238))
    if self.btnLast ~= self.btnSche then
        self.btnLast:setFocused(false)
        self.btnLast:setTitleColor(ccc3(245,204,85))
        self.btnLast = self.btnSche
        
        self:cleanAllRefresh()

        self.panelLast:setVisible(false)
        self.panelLast:setZOrder(1)
        self.panelLast = self.panelSche
    end
end

function GuildFightSchePanel:cleanAllRefresh()
	self.scrolFight:stopAllActions()
    self.scrolSche:stopAllActions()
end

function GuildFightSchePanel:update()

end

function GuildFightSchePanel:open()

    Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_SCHE_LIST)
end

function GuildFightSchePanel:close()

    self:resetView()
end
