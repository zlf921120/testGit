--公会 内部场景
MemberScene = class("MemberScene",WindowBase)
MemberScene.__index = MemberScene
MemberScene._widget = nil
MemberScene.uiLayer = nil

local __instance = nil

function MemberScene:create()
    local ret = MemberScene.new()
    __instance = ret
    return ret
end

---------------响应事件--------------------------------------------------
local listMember = nil

local function event_btn_show_permission(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        local playerVo = OrganizHelper.getCurPlayerVo()
        if playerVo.clazz == ClazzType.Master or playerVo.clazz == ClazzType.Deputy then --正/副 会长
            local voList = CharacterManager:getInstance():getBaseData():getNewsTipList()
            local params = {isShowTip = voList[ NewTipsEnum.guild_apply ] }  --0 显示  1 不显示

            WindowCtrl:getInstance():close(__instance.name)
            WindowCtrl:getInstance():open(CmdName.Guild_View_Permission,params)
        end
    end
end

-------------------响应事件-------------------------------------------
local function event_btn_physical(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        GuildNetTask:getInstance():requestSendPhysicalStatus()
    end
end

local function event_btn_worship(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        GuildNetTask:getInstance():requestDescWorship()
    end
end

local function event_btn_skill(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        WindowCtrl:getInstance():close(__instance.name)
        WindowCtrl:getInstance():open(CmdName.Guild_View_Skill)
    end
end

local function event_btn_contribute(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
    
        GuildNetTask:getInstance():requestDonatePanelInfo()
    end
end

local function event_btn_boss(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        WindowCtrl:getInstance():close(__instance.name)
        WindowCtrl:getInstance():open(CmdName.Guild_View_Boss)
    end
end

local function event_btn_info(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        WindowCtrl:getInstance():open(CmdName.Guild_View_GuildInfoPanel)
    end
end

---------------初始化-----------------------------------------------------
local labName = nil
local labId = nil
local labPeople = nil
local imgIcon = nil

function MemberScene:init()
    require "GuildDataProxy"
    require "ChoiceWorship"
    require "DescWorship"
    require "GivePhysical"
    require "PermissionScene"
    require "OrganizHelper"
    require "GuildLocalReader"
    require "GuildRenderMgr"
    require "GuildIcon"
    require "OrganizEvent"
    require "GuildNetTask"
    require "PlayerInfoPanel"
    require "MsgBox"

    GuildRenderMgr:getInstance()
    GuildLocalReader:getInstance():loadInProxy()

    ItemManager:getInstance():loadItemIconPlist()
    HeroManager:getInstance():loadSkillIconPlist()
    --加载纹理
    ComResMgr:getInstance():loadOtherRes()
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/organiz/member/guild.plist")

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/MemberScene.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

    self.btnPermission = tolua.cast(self.uiLayer:getWidgetByName("btn_permission"),"Button")
    self.btnPermission:addTouchEventListener(event_btn_show_permission)

    self.btnWorship = tolua.cast(self.uiLayer:getWidgetByName("btn_worship"),"Button")
    self.btnWorship:addTouchEventListener(event_btn_worship)

    self.btnPhysical = tolua.cast(self.uiLayer:getWidgetByName("btn_physical"),"Button")
    self.btnPhysical:addTouchEventListener(event_btn_physical)

    self.btnSkill = tolua.cast(self.uiLayer:getWidgetByName("btn_skill"),"Button")
    self.btnSkill:addTouchEventListener(event_btn_skill)

    self.btnContribute = tolua.cast(self.uiLayer:getWidgetByName("btn_contribute"),"Button")
    self.btnContribute:addTouchEventListener(event_btn_contribute)

    self.btnBoss = tolua.cast(self.uiLayer:getWidgetByName("btn_boss"),"Button")
    self.btnBoss:addTouchEventListener(event_btn_boss)

    self.btnInfo = tolua.cast(self._widget:getChildByName("btn_info"),"Button")
    self.btnInfo:addTouchEventListener(event_btn_info)

    self.btnList = tolua.cast(self.uiLayer:getWidgetByName("btn_guildlist"),"Button")
    self.btnList:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then 
            WindowCtrl:getInstance():open(CmdName.Guild_View_MEMBMER_ALL_GUILD)
        end
    end)

    self.btnFight = tolua.cast(self.uiLayer:getWidgetByName("btn_guild_fight"),"Button")
    self.btnFight:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then 
            WindowCtrl:getInstance():close(self.name)
            WindowCtrl:getInstance():open(CmdName.Guild_View_FightScene)
        end
    end)

    self.btnChat = tolua.cast(self.uiLayer:getWidgetByName("btn_chat"),"Button")
    self.btnChat:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then 
            WindowCtrl:getInstance():close(self.name)
            WindowCtrl:getInstance():open(CmdName.Chat_View,{area = 2})
        end
    end)

    self.scrolMember = DisplayUtil.createAdaptScrollView(540,310,116,0,1)

    self.scrolMember:setPosition(ccp(36,28))
    self._widget:addChild(self.scrolMember,10)

    listMember = tolua.cast(self.uiLayer:getWidgetByName("list_member"),"ListView")

    labName = tolua.cast(self.uiLayer:getWidgetByName("lab_name"),"Label")
    labId = tolua.cast(self.uiLayer:getWidgetByName("lab_organizid"),"Label")
    labPeople = tolua.cast(self.uiLayer:getWidgetByName("lab_member"),"Label")
    labDesc = tolua.cast(self.uiLayer:getWidgetByName("lab_desc"),"Label")
    self.labDonateTotal = tolua.cast(self.uiLayer:getWidgetByName("lab_contribute"),"Label") 

    imgIcon = GuildIcon:create()
    imgIcon:setPosition(ccp(90,384))
    self._widget:addChild(imgIcon)

    --锁层
    self.panelLock = tolua.cast(self.uiLayer:getWidgetByName("panel_lock"),"Layout")
    self.panelLock:setTouchEnabled(true)

    --注册事件
    Notifier.regist(OrganizEvent.GET_MEMBER_ITEM_SUCCESS,function()
        GuildRenderMgr:getInstance():renderMemberListAdapt(self.scrolMember) 

        self.scrolMember:stopAllActions()
        self.scrolMember:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolMember:getInnerContainer():getPositionY()
                local viewRect = CCRectMake(0,math.abs(viewY),540,310)
                GuildRenderMgr:getInstance():refreshViewMemberVoList(viewRect,self.scrolMember)
            end),
            CCDelayTime:create(0.1))))
    end) 
    Notifier.regist(OrganizEvent.GET_MEMBER_ORGANIZ_INFO,function() self:update() end)
    Notifier.regist(OrganizEvent.MSG_UPDATE_GUILD_LEVUP,function() self:update() end)
    Notifier.regist(OrganizEvent.MSG_UPDATE_NEW_TIPS_SHOW,function(key) self:showNewsTip(key) end)
    Notifier.regist(OrganizEvent.MSG_UPDATE_NEW_TIPS_HIDE,function(key) self:hideNewsTip(key) end) 
    --初始化数据
    GuildLocalReader:getInstance():loadInProxy()
end

function MemberScene:update()

    self.panelLock:setTouchEnabled(false)

    local dp = GuildDataProxy:getInstance()
    local guildVo = CharacterManager:getInstance():getGuildData()
    local playerVoList = dp:getPlayerVoList()
    guildVo._curnum = Utils.get_length_from_any_table(playerVoList)

    labName:setText(guildVo:getName())
    labId:setText(guildVo:getId())
    labPeople:setText(string.format("%d/%d",guildVo._curnum,guildVo:getMaxnum()))
    labDesc:setText(guildVo:getDesc())
    imgIcon:setId(guildVo:getLogoId())
    imgIcon:setLev(guildVo:getLev())
    self.labDonateTotal:setText( dp:getGuildSceneVo().donateTotal )

    local playerVo = OrganizHelper.getCurPlayerVo()
    local btnPermission = tolua.cast(self.uiLayer:getWidgetByName("btn_permission"),"Button")

    local isVisible = playerVo.clazz == ClazzType.Master or playerVo.clazz == ClazzType.Deputy
    btnPermission:setVisible(isVisible)
    if isVisible then --展示绿点

        local voList = CharacterManager:getInstance():getBaseData():getNewsTipList()
        if voList[ NewTipsEnum.guild_apply ] == 0 then
            self:showNewsTip(NewTipsEnum.guild_apply)
        else
            self:hideNewsTip(NewTipsEnum.guild_apply)
        end
    end

    if GuildDataProxy:getInstance():isCanLearnSkill() then
        self:showNewsTip(NewTipsEnum.guild_skill)
    else
        self:hideNewsTip(NewTipsEnum.guild_skill)
    end
end

function MemberScene:open()

    self.panelLock:setTouchEnabled(true)

    GuildNetTask:getInstance():requestMemberItems()

    local guildData = CharacterManager:getInstance():getGuildData()
    if guildData:getWorshipReward() > 0 then
        self:showNewsTip(NewTipsEnum.guild_worship)
    end
    if GuildDataProxy:getInstance().short_fight_news_enter > 0 or 
        GuildDataProxy:getInstance().fight_reward_news > 0 then
        self:showNewsTip(NewTipsEnum.guild_fight)
    end
    if GuildDataProxy:getInstance().myauction_news > 0 then
        self:showNewsTip(NewTipsEnum.guild_boss)
    end
end

function MemberScene:getInstance()
    return __instance
end

function MemberScene:close()

    -- listMember:removeAllItems() --清理
    -- local dp = GuildDataProxy:getInstance()
    -- local rm = GuildRenderMgr:getInstance()
    -- local voList = dp:getGuildVoList()
    -- for id,v in pairs(table_name) do
    --     rm.dic:removeObjectForKey(string.format("guilditem_%d",id))
    -- end
    -- dp:clearPlayerVoList()

end

function MemberScene:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

-- 隐藏 新消息 提示
function MemberScene:hideNewsTip(key)
    local target = nil
    if key == NewTipsEnum.guild_apply then
        target = self.uiLayer:getWidgetByName("btn_permission")
    elseif key == NewTipsEnum.guild_worship then
        target = self.uiLayer:getWidgetByName("btn_worship")
    elseif key == NewTipsEnum.guild_skill then
        target = self.uiLayer:getWidgetByName("btn_skill")
    elseif key == NewTipsEnum.guild_fight then
        target = self.uiLayer:getWidgetByName("btn_guild_fight")
    elseif key == NewTipsEnum.guild_boss then
        target = self.btnBoss
    end
    if target and target:getChildByTag(2866) ~= nil then
        CharacterManager:getInstance():getBaseData():setNewsTipStatus(key,1) --0 显示  1 不显示
        target:removeChildByTag(2866,true)
    end
end

-- 展示 新消息 提示
function MemberScene:showNewsTip(key)
    local target = nil
    local pos = nil
    if key == NewTipsEnum.guild_apply then
        target = self.uiLayer:getWidgetByName("btn_permission")
        pos = ccp(55,20)
    elseif key == NewTipsEnum.guild_worship then
        target = self.uiLayer:getWidgetByName("btn_worship")
        pos = ccp(25,25)
    elseif key == NewTipsEnum.guild_skill then
        target = self.uiLayer:getWidgetByName("btn_skill")
        pos = ccp(25,25)
    elseif key == NewTipsEnum.guild_fight then
        target = self.uiLayer:getWidgetByName("btn_guild_fight")
        pos = ccp(25,25)
    elseif key == NewTipsEnum.guild_boss then
        target = self.btnBoss
        pos = ccp(25,25)
    end
    if target and target:getChildByTag(2866) == nil then
        local tips_img = ImageView:create()
        tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
        tips_img:setTag(2866)
        tips_img:setPosition(pos)
        target:addChild(tips_img)
        self:tipsPointPlayAct(tips_img)
    elseif target and target:getChildByTag(2866) ~= nil then
        local tips_img = target:getChildByTag(2866)
        self:tipsPointPlayAct(tips_img)
    end
end
