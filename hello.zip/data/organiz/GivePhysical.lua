--互赠体力 面板

GivePhysical = class("GivePhysical",WindowBase)
GivePhysical.__index = GivePhysical
GivePhysical._widget     = nil
GivePhysical.uiLayer    = nil
GivePhysical.is_dispose = true

local __instance = nil

function GivePhysical:create()
    local ret = GivePhysical.new()
    __instance = ret
    return ret   
end

function GivePhysical:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_GIVE_PHYSICAL)
end

--------------------响应事件-----------------------------------
local listMember = nil

local function event_btn_close(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        __instance:addCloseAnim()
    end
end

local function event_cb_close()
end

----------------------初始化--------------------------------------
function GivePhysical:init()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GivePhysical.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    local btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    btnClose:addTouchEventListener(event_btn_close)

    listMember = tolua.cast(self.uiLayer:getWidgetByName("list_member"),"ListView")

    Notifier.regist(OrganizEvent.MSG_UPDATE_GIVE_PHYSICAL,function() self:update() end)
end

function GivePhysical:update()

    local givePhyicalVo = GuildDataProxy:getInstance():getGivePhysicalVo()

    local labGetReward = tolua.cast(self.uiLayer:getWidgetByName("lab_getreward"),"Label")
    labGetReward:setText(givePhyicalVo.getRewardNum)
    
    local labSendReward = tolua.cast(self.uiLayer:getWidgetByName("lab_sendreward"),"Label")
    labSendReward:setText(givePhyicalVo.sendRewardNum)
end

function GivePhysical:open()

    self:addOpenAnim(function()
        self:update()
        GuildRenderMgr.renderGivePhysicalList(listMember)
    end)
end

function GivePhysical:close()

    listMember:removeAllItems() 
    local dp = GuildDataProxy:getInstance()
    local rm = GuildRenderMgr:getInstance()
    local voList = dp:getPlayerVoList()
    for k,v in pairs(voList) do
        if v.role_id:match( CharacterManager:getInstance():getLoginData():getRoleId() ) == false then
            rm.dic:removeObjectForKey(string.format("giveitem_%s",v.id))
        end
    end
end