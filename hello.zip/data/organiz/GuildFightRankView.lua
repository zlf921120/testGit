-------------------------------------------------------------------------------
--公会实力 排行 条目
GuildRankPowerItem = class("GuildRankPowerItem",function()
    return Layout:create()
end)
GuildRankPowerItem.__index = GuildRankPowerItem
GuildRankPowerItem._widget     = nil
GuildRankPowerItem.rankVo = nil

function GuildRankPowerItem:create()
    local ret = GuildRankPowerItem.new()
    ret:init()
    return ret
end

function GuildRankPowerItem:init()

	self._widget = GuildDataProxy:getInstance():getWidgetRankPowerItem():clone()
    self:setSize(CCSize(840,95))
    self:addChild(self._widget)

    self.guildIcon = GuildIcon:create()
    self.guildIcon:setScale(0.8)
    self.guildIcon:setPosition(ccp(146,48))
    self._widget:addChild(self.guildIcon,5)

    self.imgBg = tolua.cast(self._widget:getChildByName("img_bg"),"ImageView")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labNum = tolua.cast(self._widget:getChildByName("lab_num"),"Label")
    self.labWin = tolua.cast(self._widget:getChildByName("lab_win"),"Label")
    self.labRankMax = tolua.cast(self._widget:getChildByName("lab_rank_max"),"Label")
    self.labRank = tolua.cast(self._widget:getChildByName("lab_rank"),"Label")
end

function GuildRankPowerItem:setData(vo)
    self.rankVo = vo
    self:update()
end

function GuildRankPowerItem:update()
    self.imgBg:setVisible(self.rankVo.rank % 2 == 0)
    self.labRank:setText(self.rankVo.rank)
    self.labName:setText(self.rankVo.name)
    self.guildIcon:setId(self.rankVo.logoId)
    self.guildIcon:setLev(self.rankVo.lev)
    self.labRankMax:setText(self.rankVo.topRank)
    self.labNum:setText(string.format("(%d人）",self.rankVo.num))
    self.labWin:setText(string.format("勝%d場（%.2f%%）",self.rankVo.win_num,self.rankVo.win_num/self.rankVo.session_max*100) )
end
-------------------------------------------------------------------------------
--公会战实时 排行 条目
GuildRankCurItem = class("GuildRankCurItem",function()
    return Layout:create()
end)
GuildRankCurItem.__index = GuildRankCurItem
GuildRankCurItem._widget     = nil
GuildRankCurItem.rankVo = nil

function GuildRankCurItem:create()
    local ret = GuildRankCurItem.new()
    ret:init()
    return ret
end

function GuildRankCurItem:init()

	self._widget = GuildDataProxy:getInstance():getWidgetRankGiftItem():clone()
    self:setSize(CCSize(840,62))
    self:addChild(self._widget)

    self.btnGift = tolua.cast(self._widget:getChildByName("btn_gift"),"Button")
    self.btnGift:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Reward_GuildGiftPanel,
                {reward_title="獎勵",rank = self.rankVo.rank,
                 reward_list=GuildDataProxy:getInstance():getRankRewardByRank(self.rankVo.rank)})
		end
	end)

	self.btnInfo = tolua.cast(self._widget:getChildByName("btn_info"),"Button")
    self.btnInfo:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Guild_View_FightScorePanel,
                {id=self.rankVo.id,
                type=GuildFightScoreType.Current,
                name=self.rankVo.name})
		end
	end)
    self.imgBg = tolua.cast(self._widget:getChildByName("ImageView_235_Copy3"),"ImageView")
    self.labRank = tolua.cast(self._widget:getChildByName("lab_rank"),"Label")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labWinPerc = tolua.cast(self._widget:getChildByName("lab_win"),"Label")
    self.labWin = tolua.cast(self._widget:getChildByName("lab_win_num"),"Label")
    self.labLev = tolua.cast(self._widget:getChildByName("lab_lev"),"Label")
end

function GuildRankCurItem:setData(vo)
    self.rankVo = vo
    self:update()
end

function GuildRankCurItem:update()
    self.imgBg:setVisible(self.rankVo.rank % 2 == 0)
    self.labRank:setText(self.rankVo.rank)
    if self.rankVo.win_num == 0 then
        self.labWin:setText("無")
    else
        self.labWin:setText(self.rankVo.win_num)
    end
    
    self.labName:setText(self.rankVo.name)
    self.labLev:setText("Lv."..self.rankVo.lev)
    self.labWinPerc:setText(string.format("%.2f%%",self.rankVo.win_num/self.rankVo.session_max*100))
end

-------------------------------------------------------------------------
--公会战 排名 面板
GuildFightRankView = class("GuildFightRankView",WindowBase)
GuildFightRankView.__index = GuildFightRankView
GuildFightRankView._widget = nil
GuildFightRankView.uiLayer = nil
GuildFightRankView.btnLast = nil
GuildFightRankView.panelLast = nil
GuildFightRankView.is_dispose = true

local __instance = nil

function GuildFightRankView:create()
    local ret = GuildFightRankView.new()
    __instance = ret
    return ret
end


function GuildFightRankView:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_FIGHT_POWER_RANK_LIST)
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_FIGHT_CUR_RANK_LIST)
end

function GuildFightRankView:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightRankView.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    self.btnOptAll = tolua.cast(self._widget:getChildByName("btn_rank_all"),"Button")
    self.btnOptAll:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	self.panelAll:setVisible(true)
	        self.panelAll:setZOrder(4)

	        local btn = tolua.cast(pSender,"Button")
	        btn:setFocused(true)
	        btn:setTitleColor(ccc3(210,253,238))
	        if self.btnLast ~= btn then
	            self.btnLast:setFocused(false)
	            self.btnLast:setTitleColor(ccc3(245,204,85))
	            self.btnLast = btn
	            
	            self.panelLast:setVisible(false)
	            self.panelLast:setZOrder(2)
	            self.panelLast = self.panelAll

                self:cleanAllRefresh()
                GuildNetTask:getInstance():requestGuildPowerRankList()
	        end
	    end
	end)
    self.btnOptCur = tolua.cast(self._widget:getChildByName("btn_rank_cur"),"Button")
    self.btnOptCur:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	self.panelCur:setVisible(true)
	        self.panelCur:setZOrder(4)

	        local btn = tolua.cast(pSender,"Button")
	        btn:setFocused(true)
	        btn:setTitleColor(ccc3(210,253,238))
	        if self.btnLast ~= btn then
	            self.btnLast:setFocused(false)
	            self.btnLast:setTitleColor(ccc3(245,204,85))
	            self.btnLast = btn
	            
	            self.panelLast:setVisible(false)
	            self.panelLast:setZOrder(2)
	            self.panelLast = self.panelCur
	            
                self:cleanAllRefresh()
                GuildNetTask:getInstance():requestGuildCurRankList()
	        end
	    end
	end)
	self.btnOptAll:setFocused(true)
    self.btnOptAll:setTitleColor(ccc3(210,253,238))
    self.btnLast = self.btnOptAll 

	self.panelAll = tolua.cast(self._widget:getChildByName("panel_rank_all"),"Layout")
    self.panelCur = tolua.cast(self._widget:getChildByName("panel_rank_cur"),"Layout")
    self.panelLast = self.panelAll
---------------------------------------------------------------------------------------
    self.scrolAllRank = DisplayUtil.createAdaptScrollView(840,370,0,0,1)
    self.scrolAllRank:setPosition(ccp(0,0))
    self.panelAll:addChild(self.scrolAllRank)

    self.labAllTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips_all"),"Label")
    self.labCurTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips_cur"),"Label")

    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_POWER_RANK_LIST,function() 
        local voList = GuildDataProxy:getInstance():getPowerRankVoList()
        self.labAllTips:setVisible(Utils.get_length_from_any_table(voList) <= 0)

        GuildRenderMgr:getInstance():renderPowerRankAdapt(self.scrolAllRank)

        self.lastAllRankY = -1

        self.scrolAllRank:stopAllActions()
        self.scrolAllRank:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolAllRank:getInnerContainer():getPositionY()
                if self.lastAllRankY ~= viewY then
                    self.lastAllRankY = viewY

                    local viewRect = CCRectMake(0,math.abs(viewY),840,370)
                    GuildRenderMgr:getInstance():refreshPowerRankList(viewRect,self.scrolAllRank)
                end
            end),
            CCDelayTime:create(0.1))))
    end)
---------------------------------------------------------------------------------------
    self.scrolCurRank = DisplayUtil.createAdaptScrollView(840,370,0,0,1)
    self.scrolCurRank:setPosition(ccp(0,0))
    self.panelCur:addChild(self.scrolCurRank)

    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_CUR_RANK_LIST,function() 
        local voList = GuildDataProxy:getInstance():getCurRankVoList()
        self.labCurTips:setVisible(Utils.get_length_from_any_table(voList) <= 0)

        self.lastCurRankY = -1

        GuildRenderMgr:getInstance():renderCurRankAdapt(self.scrolCurRank)

        self.scrolCurRank:stopAllActions()
        self.scrolCurRank:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolCurRank:getInnerContainer():getPositionY()
                if self.lastCurRankY ~= viewY then
                    self.lastCurRankY = viewY

                    local viewRect = CCRectMake(0,math.abs(viewY),840,370)
                    GuildRenderMgr:getInstance():refreshCurRankList(viewRect,self.scrolCurRank)
                end
            end),
            CCDelayTime:create(0.1))))
    end)
---------------------------------------------------------------------------------------

end

function GuildFightRankView:cleanAllRefresh()
    self.scrolCurRank:stopAllActions()
    self.scrolAllRank:stopAllActions()
end

function GuildFightRankView:open()
    GuildNetTask:getInstance():requestGuildPowerRankList()
end