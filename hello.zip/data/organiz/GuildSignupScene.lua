-- 公会战 报名场景
GuildSignupScene = class("GuildSignupScene",WindowBase)
GuildSignupScene.__index = GuildSignupScene
GuildSignupScene._widget = nil
GuildSignupScene.uiLayer = nil

local __instance = nil

function GuildSignupScene:create()
    local ret = GuildSignupScene.new()
    __instance = ret
    return ret
end

function GuildSignupScene:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/GuildSignupScene.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.scrolSignup = DisplayUtil.createAdaptScrollView(820,432,140,0,1)

    self.scrolSignup:setPosition(ccp(68,32))
    self._widget:addChild(self.scrolSignup,10)

    Notifier.regist(OrganizEvent.MSG_UPDATE_MEMBER_SHOW_GUILD,function() 
        GuildRenderMgr:getInstance():renderFightSignupListAdapt(self.scrolSignup) 

        self.scrolSignup:stopAllActions()
        self.scrolSignup:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolSignup:getInnerContainer():getPositionY()
                local viewRect = CCRectMake(0,math.abs(viewY),820,432)
                GuildRenderMgr:getInstance():refreshViewFightSignupVoList(viewRect,self.scrolSignup)
            end),
            CCDelayTime:create(0.1))))
    end) 

end

function GuildSignupScene:open()

end

function GuildSignupScene:close()

end