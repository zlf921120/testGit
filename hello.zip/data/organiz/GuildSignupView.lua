-- 公会战 报名面板
GuildSignupView = class("GuildSignupView",WindowBase)
GuildSignupView.__index = GuildSignupView
GuildSignupView._widget = nil
GuildSignupView.uiLayer = nil
GuildSignupView.is_dispose = true

local __instance = nil

function GuildSignupView:create()
    local ret = GuildSignupView.new()
    __instance = ret
    return ret
end

function GuildSignupView:dispose()
	if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
end

function GuildSignupView:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightSignupView.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.inputDesc = tolua.cast(self.uiLayer:getWidgetByName("input_desc"),"TextField")

 	self.btnOk = tolua.cast(self.uiLayer:getWidgetByName("btn_signup"),"Button")
    self.btnOk:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
            local guildLev = CharacterManager:getInstance():getGuildData():getLev() 
            local costLev = GuildDataProxy:getInstance():getGuildFightSceneVo().signupLev
            if guildLev >= costLev then

    	    	-- WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()

                    GuildNetTask:getInstance():requestGuildFightSignup(self.inputDesc:getStringValue())

                -- end, txt = string.format("報名參加公會戰將花費%d公會資金，是否確定？",
                -- 	GuildDataProxy:getInstance():getGuildFightSceneVo().signupCost) })
            else
                Alert:show(string.format("%d級以上公會可報名公會戰",costLev))
            end
	    end
	end)

    self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():close(self.name)
	   	end
	end)

    self.labNum = tolua.cast(self.uiLayer:getWidgetByName("lab_num"),"Label")
    self.labName = tolua.cast(self.uiLayer:getWidgetByName("lab_name"),"Label")

    self.guildIcon1 = GuildIcon:create()
    self.guildIcon1:setPosition(ccp(295,421))
    self._widget:addChild(self.guildIcon1,2)
end

function GuildSignupView:open()

  	local guildData = CharacterManager:getInstance():getGuildData()
	self.guildIcon1:setId(guildData:getLogoId())
	self.guildIcon1:setLev(guildData:getLev())
	self.labName:setText(guildData:getName())
	self.labNum:setText(string.format("(%d人)",guildData:getCurrNum()))

end

function GuildSignupView:close()

end