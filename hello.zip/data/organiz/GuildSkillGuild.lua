-- 公会技能 升级 面板
GuildSkillGuild = class("GuildSkillGuild",WindowBase)
GuildSkillGuild.__index = GuildSkillGuild
GuildSkillGuild._widget     = nil
GuildSkillGuild.uiLayer    = nil
GuildSkillGuild.is_dispose = true

local __instance = nil

function GuildSkillGuild:create()
    local ret = GuildSkillGuild.new()
    __instance = ret
    return ret   
end

function GuildSkillGuild:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end

local function event_btn_levup(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        local sceneVo = GuildDataProxy:getInstance():getGuildSceneVo()
        if __instance.guild_donate_cost > sceneVo.donateTotal then
            Alert:show("公會資金不足")
        else
            GuildNetTask:getInstance():requestLevupGuildSkill(__instance.skillId)
        end
   	end
end

function GuildSkillGuild:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildSkillGuild.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnOk = tolua.cast(self._widget:getChildByName("btn_learn"),"Button")
    self.btnOk:addTouchEventListener(event_btn_levup)

    self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then 
	    	WindowCtrl:getInstance():close(self.name)
	   	end
    end)

    self.labTip = tolua.cast(self._widget:getChildByName("lab_tip"),"Label")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labNowDesc = tolua.cast(self._widget:getChildByName("lab_now"),"Label")
    self.labNextDesc = tolua.cast(self._widget:getChildByName("lab_next"),"Label")
    self.labGuildDonate = tolua.cast(self._widget:getChildByName("lab_guild_donate"),"Label")
    self.labDonateCost = tolua.cast(self._widget:getChildByName("lab_donatecost"),"Label")
    self.p_1 = self._widget:getChildByName("p_1")
    self.p_2 = self._widget:getChildByName("p_2")

    self.iconNow = GuildSkillIcon:create()
    self.iconNow:setPosition(ccp(360,417))
    self._widget:addChild( self.iconNow ,5)

    self.iconNext = GuildSkillIcon:create()
    self.iconNext:setPosition(ccp(606,417))
    self._widget:addChild( self.iconNext,5 )

end

function GuildSkillGuild:open()

    local dp = GuildDataProxy:getInstance()
    local guilDdata = CharacterManager:getInstance():getGuildData()

    self.p_2:setVisible(false)
    self.iconNext:setVisible(true)
    self.btnOk:setVisible(true)
    self.btnOk:setTouchEnabled(true)
    self.labTip:setVisible(false)

	self.skillId = self.params["skill_id"]
    local skillGuildVo = dp:getGuildSkillVoById(self.skillId)
    if skillGuildVo == nil then --未学习
        local skillDescVo = dp:getSkillDescVoById(self.skillId,1)
        self.labNowDesc:setText("未學習")
        self.labName:setText( skillDescVo.name )
        self.labNextDesc:setText( skillDescVo.desc )
        self.labDonateCost:setText( skillDescVo.guild_donate_cost )
        self.guild_donate_cost = skillDescVo.guild_donate_cost 

        self.iconNow:setId(self.skillId)
        self.iconNow:setLev(0)
        self.iconNext:setId(self.skillId)
        self.iconNext:setLev(1)

        if skillDescVo.guild_lev > guilDdata:getLev() then --等级不足
            self.btnOk:setVisible(false)
            self.btnOk:setTouchEnabled(false)
            self.labTip:setVisible(true)
            self.labTip:setText(string.format("公會等級%d級可升級",skillDescVo.guild_lev))
        end
    else
        local skillDescVo = dp:getSkillDescVoById(self.skillId,skillGuildVo.lev)
        local skillNextVo = dp:getSkillDescVoById(self.skillId,skillGuildVo.lev + 1)

        if skillNextVo ~= nil then
            self.labNowDesc:setText( skillDescVo.desc )
            self.labName:setText( skillDescVo.name )
            self.labNextDesc:setText( skillNextVo.desc )
            self.labDonateCost:setText( skillNextVo.guild_donate_cost )
            self.guild_donate_cost = skillNextVo.guild_donate_cost

            self.iconNow:setId(self.skillId)
            self.iconNow:setLev(skillGuildVo.lev)
            self.iconNext:setId(self.skillId)
            self.iconNext:setLev(skillGuildVo.lev + 1)

            if skillNextVo.guild_lev > guilDdata:getLev() then --等级不足
                self.btnOk:setVisible(false)
                self.btnOk:setTouchEnabled(false)
                self.labTip:setVisible(true)
                self.labTip:setText(string.format("公會等級%d級可升級",skillNextVo.guild_lev))
            end
        else --最高了
            self.p_2:setVisible(true)
            self.iconNow:setId(self.skillId)
            self.iconNow:setLev(skillGuildVo.lev)
            self.iconNext:setVisible(false)
            self.labNowDesc:setText(skillDescVo.desc)
            self.labNextDesc:setText("當前已是最高等級")
            self.btnOk:setTouchEnabled(false)
            self.btnOk:setVisible(false)
        end
    end

    local sceneVo = dp:getGuildSceneVo()
    self.labGuildDonate:setText(sceneVo.donateTotal)
end

function GuildSkillGuild:close()

end