-- 公会战 助威 场景
GuildCheerView = class("GuildCheerView",WindowBase)
GuildCheerView.__index = GuildCheerView
GuildCheerView._widget = nil
GuildCheerView.uiLayer = nil
GuildCheerView.is_dispose = true

local __instance = nil

function GuildCheerView:create()
    local ret = GuildCheerView.new()
    __instance = ret
    return ret
end

function GuildCheerView:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
end

function GuildCheerView:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildCheerView.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
 	self.btnClose:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then 
        	WindowCtrl:getInstance():close(self.name)
 		end
 	end)

 	self.btnCheer = tolua.cast(self.uiLayer:getWidgetByName("btn_cheer"),"Button")
 	self.btnCheer:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then 
            local dp = GuildDataProxy:getInstance()
            local sceneVo = dp:getGuildFightSceneVo()

            if sceneVo.isCheer == 1 then
                Alert:show("本場公會戰你已經助威過了")
            else
                GuildNetTask:getInstance():requestGuildCheer()
            end
 		end
 	end)

    self.labNowPower = tolua.cast(self.uiLayer:getWidgetByName("lab_now_power"),"Label")
    self.labNowDefense = tolua.cast(self.uiLayer:getWidgetByName("lab_now_defense"),"Label")
    self.labNowHp = tolua.cast(self.uiLayer:getWidgetByName("lab_now_hp"),"Label")
    self.labNowAct = tolua.cast(self.uiLayer:getWidgetByName("lab_now_act"),"Label")
    self.labNowStatus = tolua.cast(self.uiLayer:getWidgetByName("lab_now_status"),"Label")

    self.labNextPower = tolua.cast(self.uiLayer:getWidgetByName("lab_next_power"),"Label")
    self.labNextDefense = tolua.cast(self.uiLayer:getWidgetByName("lab_next_defense"),"Label")
    self.labNextHp = tolua.cast(self.uiLayer:getWidgetByName("lab_next_hp"),"Label")
    self.labNextAct = tolua.cast(self.uiLayer:getWidgetByName("lab_next_act"),"Label")
    self.labNextStatus = tolua.cast(self.uiLayer:getWidgetByName("lab_next_status"),"Label")
    
    self.panelNext = tolua.cast(self.uiLayer:getWidgetByName("panel_next"),"Layout")
end

function GuildCheerView:update()
    
    local dp = GuildDataProxy:getInstance()
    local guildData = CharacterManager:getInstance():getGuildData()
    local voList = GuildDataProxy:getInstance():getFightCheerVoList()

    local idx = dp:getCheerStep()
    local cheerVo = dp:getFightCheerVoById(idx)
    self.labNowStatus:setText(string.format("當前已有%d人助威，開啟備戰加成：",guildData:getCheerNum()))
    self.labNowPower:setText(string.format("%d個",cheerVo.power_limit))
    self.labNowDefense:setText(string.format("%d個",cheerVo.defence_limit))
    self.labNowHp:setText(string.format("生命+%d%%",cheerVo.hp_addition))
    self.labNowAct:setText(string.format("攻擊+%d%%",cheerVo.act_addition))

    local nextCheerVo = dp:getFightCheerVoById(idx + 1)
    if nextCheerVo then
    
        self.labNextStatus:setText(string.format("下一階段需要%d人助威，開啟備戰加成：",nextCheerVo.cheer_num))
        self.labNextPower:setText(string.format("%d個",nextCheerVo.power_limit))
        self.labNextDefense:setText(string.format("%d個",nextCheerVo.defence_limit))
        self.labNextHp:setText(string.format("生命+%d%%",nextCheerVo.hp_addition))
        self.labNextAct:setText(string.format("攻擊+%d%%",nextCheerVo.act_addition))
    else
        self.panelNext:setVisible(false)
    end
end

function GuildCheerView:open()
    self:update()
end

function GuildCheerView:close()

end
