-- 公会 内部 查看 公会列表 面板
GuildShowGuildScene = class("GuildShowGuildScene",WindowBase)
GuildShowGuildScene.__index = GuildShowGuildScene
GuildShowGuildScene._widget     = nil
GuildShowGuildScene.uiLayer    = nil
GuildShowGuildScene.is_dispose = true
GuildShowGuildScene.lastScorlGuildY = 0

local __instance = nil

function GuildShowGuildScene:create()
    local ret = GuildShowGuildScene.new()
    __instance = ret
    return ret   
end

function GuildShowGuildScene:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_MEMBER_SHOW_GUILD)
end

function GuildShowGuildScene:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildShowGuild.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    self.btnRefresh = tolua.cast(self._widget:getChildByName("btn_refresh"),"Button")
    self.btnRefresh:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            GuildNetTask:getInstance():requestLookupAllGuild()
        end
    end)

    self.scrolGuild = DisplayUtil.createAdaptScrollView(820,432,140,0,1)

    self.scrolGuild:setPosition(ccp(68,32))
    self._widget:addChild(self.scrolGuild,10)

    Notifier.regist(OrganizEvent.MSG_UPDATE_MEMBER_SHOW_GUILD,function() 
        GuildRenderMgr:getInstance():renderMemberGuildListAdapt(self.scrolGuild) 

        self.lastScorlGuildY = -1
        self.scrolGuild:stopAllActions()
        self.scrolGuild:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolGuild:getInnerContainer():getPositionY()
                if self.lastScorlGuildY ~= viewY then
                    self.lastScorlGuildY = viewY
                    local viewRect = CCRectMake(0,math.abs(viewY),820,432)
                    GuildRenderMgr:getInstance():refreshViewGuildViewVoList(viewRect,self.scrolGuild)
                end
            end),
            CCDelayTime:create(0.1))))
    end) 
end

-- function GuildShowGuildScene._refreshScrolGuild(scrol)

--     local viewY = scrol:getInnerContainer():getPositionY()
--     local viewRect = CCRectMake(0,math.abs(viewY),820,432)

--     GuildRenderMgr:getInstance():refreshViewGuildViewVoList(viewRect,scrol)
-- end

function GuildShowGuildScene:open()
    GuildNetTask:getInstance():requestLookupAllGuild()

    -- TimerManager.addTimer(100,self._refreshScrolGuild,true,self.scrolGuild)
end

function GuildShowGuildScene:close()

    -- TimerManager.removeTimer(self._refreshScrolGuild)
end