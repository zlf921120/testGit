--公会事件
OrganizEvent = 
{
	GET_ORGANIZ_ITEM_SUCCESS = "public_get_organiz_item_success", -- 获取 公会条目 成功
	GET_MEMBER_ITEM_SUCCESS = "member_get_member_item_success", -- 获取 成员条目 成功
	GET_APPLY_ITEM_SUCCESS = "member_get_apply_item_success", -- 获取 申请人条目 成功
	GET_MEMBER_ORGANIZ_INFO = "member_get_organiz_info", -- 获取公会 信息

	CB_JOIN_ORGANIZ = "public_join_organiz",	--申请加入公会 回调
	CB_SEND_PHYSICAL = "member_send_physical", --发送体力 回调
	CB_AGREE_IGNORE_ORGANIZ = "permiss_agree_ignore_organiz", --处理 同意/忽略 申请公会
	CB_CANCEL_APPLY = "public_cancel_apply", --取消申请 回调
	CB_ACTIVE_OK = "permission_active_ok", --激活成功 回调
	CB_UPDATE_DESC = "member_update_desc", --更新 膜拜大神面板

	CB_CLOSE_EDIT_LOGO = "public_close_edit_logo", --关闭图标logo
	CB_CLOSE_CHOICE_WORSHIP = "member_close_choice_worship", --关闭选择膜拜面板
	CB_CLOSE_EDIT_MEMBER = "member_close_edit_member", --关闭修改玩家 面板

	MSG_FIND_ORGANIZ = "public_find_organiz", 	--查找 公会 条目
	MSG_EDIT_MEMBER_ITEM = "member_edit_member_item", --渲染 成员管理 条目
	MSG_MEMBERCTL_PANEL = "member_memberctl_panel", --修改成员 面板
	MSG_CHOICE_LOGO = "public_choice_logo", --选择公会 标志
	MSG_EDIT_LOGO = "member_edit_logo", --修改公会 标志
	MSG_UPDATE_AUCTION_INFO = "member_MSG_UPDATE_AUCTION_INFO", --更新竞拍信息
	MSG_UPDATE_PREMISSION = "member_update_permission", --更新公会信息
	MSG_UPDATE_GIVE_PHYSICAL = "member_MSG_UPDATE_GIVE_PHYSICAL", --更新互赠体力面板
	MSG_UPDATE_GUILD_LEVUP = "member_MSG_UPDATE_GUILD_LEVUP", --更新公会等级
	MSG_UPDATE_BOSS_SCENE_ITEM = "member_MSG_UPDATE_BOSS_SCENE_ITEM", --更新公会Boss 条目
	MSG_UPDATE_BOSS_LIST = "member_MSG_UPDATE_BOSS_LIST", --更新公会Boss列表
	MSG_UPDATE_SKILL_SCENE = "member_MSG_UPDATE_SKILL_SCENE", --更新公会 技能场景
	MSG_UPDATE_BOSS_INFO = "member_MSG_UPDATE_BOSS_INFO",--更新boss 信息
	MSG_UPDATE_MEMBER_SHOW_GUILD = "member_MSG_UPDATE_MEMBER_SHOW_GUILD", --内部公会 查看公会 刷新
	MSG_UPDATE_AUCTION_LIST = "member_MSG_UPDATE_AUCTION_LIST", -- 更新公会竞拍 列表 
	MSG_UPDATE_MYAUCTION_LIST = "member_MSG_UPDATE_MYAUCTION_LIST", --更新 我的竞拍 列表
	MSG_UPDATE_RECORD_LIST = "member_MSG_UPDATE_RECORD_LIST" , --更新公会 竞拍 记录列表
	MSG_UPDATE_DONATE_INFO = "member_MSG_UPDATE_DONATE_INFO",--更新捐献信息
	MSG_UPDATE_BOSS_HURT_LIST = "member_MSG_UPDATE_BOSS_HURT_LIST", --更新boss伤害列表
	MSG_UPDATE_NEW_TIPS_HIDE = "member_MSG_UPDATE_NEW_TIPS_HIDE",--内部场景 取消绿点提示
	MSG_UPDATE_NEW_TIPS_SHOW = "member_MSG_UPDATE_NEW_TIPS_SHOW", --内部场景 展示绿点
	GUILD_FIGHT_NEW_TIPS_HIDE = "member_GUILD_FIGHT_NEW_TIPS_HIDE",--公会战场景 取消绿点提示
	GUILD_FIGHT_NEW_TIPS_SHOW = "member_GUILD_FIGHT_NEW_TIPS_SHOW", --公会战场景 展示绿点
	MSG_UPDATE_NEW_TIPS_SKILL_SHOW = "member_MSG_UPDATE_NEW_TIPS_SKILL_SHOW", --技能场景 展示绿点
	MSG_UPDATE_NEW_TIPS_SKILL_HIDE = "member_MSG_UPDATE_NEW_TIPS_SKILL_HIDE", --技能场景 隐藏绿点
	MSG_UPDATE_GUILD_LOG = "member_MSG_UPDATE_GUILD_LOG", --公会日志 更新
	MSG_UPDATE_FIGHT_SIGNUPING = "fight_MSG_UPDATE_FIGHT_SIGNUPING", --更新报名中 
	MSG_UPDATE_FIGHT_CHEER = "fight_MSG_UPDATE_FIGHT_CHEER", --更新公会战 助威
	MSG_UPDATE_FIGHT_SIGNUPLIST = "fight_MSG_UPDATE_FIGHT_SIGNUPLIST", --更新 公会战 报名列表
	MSG_UPDATE_FIGHT_HISTORY_LIST = "fight_MSG_UPDATE_FIGHT_HISTORY_LIST", --更新 公会战 上届战况
	MSG_UPDATE_FIGHT_GLORY_RANK_LIST = "fight_MSG_UPDATE_FIGHT_GLORY_RANK_LIST", --更新 我的公会 排名
	MSG_UPDATE_FIGHT_GLORY_GIFT_LIST = "fight_MSG_UPDATE_FIGHT_GLORY_GIFT_LIST", --更新 我的公会 战利
	MSG_UPDATE_FIGHT_GLORY_LOG_LIST = "fight_MSG_UPDATE_FIGHT_GLORY_LOG_LIST", --更新 我的公会 日志
	MSG_UPDATE_FIGHT_GLORY_ALLOT_LIST = "fight_MSG_UPDATE_FIGHT_GLORY_ALLOT_LIST", --更新 公会战 分配战利人员
	MSG_UPDATE_FIGHT_GLORY_ALLOT_CONFIRM = "fight_MSG_UPDATE_FIGHT_GLORY_ALLOT_CONFIRM", --战利确认 分配
	MSG_UPDATE_FIGHT_ALL_COMBAT_LIST = "fight_MSG_UPDATE_FIGHT_ALL_COMBAT_LIST", --更新 公会战 全部战况
	MSG_UPDATE_FIGHT_SCHE_LIST = "fight_MSG_UPDATE_FIGHT_SCHE_LIST", --更新公会战 日程表
	MSG_UPDATE_FINISH_RANK = "fight_MSG_UPDATE_FINISH_RANK",--更新 总赛季排行
	MSG_UPDATE_FIGHT_SCORE_LIST = "fight_MSG_UPDATE_FIGHT_SCORE_LIST", --更新某公会 战绩
	MSG_UPDATE_FINISH_RANK_SIGNLIST = "fight_MSG_UPDATE_FINISH_RANK_SIGNLIST",--更新公会 总赛季 排名 报名
	MSG_UPDATE_FIGHT_POWER_RANK_LIST = "fight_MSG_UPDATE_FIGHT_POWER_RANK_LIST", --更新公会 战斗力 排名
	MSG_UPDATE_FIGHT_CUR_RANK_LIST = "fight_MSG_UPDATE_FIGHT_CUR_RANK_LIST", --更新当前公会 排名

	MSG_UPDATE_FIGHT_SCENE = "fight_MSG_UPDATE_FIGHT_SCENE",--更新 公会战场景
	MSG_UPDATE_FIGHT_MYTEAM_LIST = "fight_MSG_UPDATE_FIGHT_MYTEAM_LIST", --更新 公会战 我方队列
	MSG_UPDATE_FIGHT_ENEMY_PERPARE_LIST = "fight_MSG_UPDATE_FIGHT_ENEMY_PERPARE_LIST", --更新 公会战 地方 镜像队列
	MSG_UPDATE_FIGHT_ENEMY_LIST = "fight_MSG_UPDATE_FIGHT_ENEMY_LIST", --更新 公会战 对手 战斗队列 

	PUBLIC_SHOW_ALERT = "public_show_alert", --公开场景 展示提示
	MEMBER_SHOW_ALERT = "member_show_alert", --内部场景 展示提示
	PERMISSION_SHOW_ALERT = "permission_show_alert", --权限场景 展示提示
}