--公会条目 值对象
GuildVo = class("GuildVo")
GuildVo.id = 0
GuildVo.name = ""
GuildVo.population = 0 --人数
GuildVo.populationMax = 0 --总人数
GuildVo.desc = ""		 --宣言
GuildVo.freeLevel = 99 --快速加入公会等级
GuildVo.logoId = 0
GuildVo.status = 0  --状态(默认申请加入)
GuildVo.isActive = 0 -- 是否已经激活
GuildVo.donateTotal = 0 --公会资金
GuildVo.donateTodayAdd = 0 --公会今日资金增加
GuildVo.fightScore = 0 --公会战 积分
GuildVo.lev = 0 --公会等级
GuildVo.mailNum = 0 --已发邮件次数
GuildVo.declaration = "" --宣言

--公会日志
GuildLogVo = class("GuildLogVo")
GuildLogVo.id = 0
GuildLogVo.title = ""
GuildLogVo.content = ""

--选择膜拜 面板 值对象 
WorshipChoiceVo = class("WorshipChoiceVo")
WorshipChoiceVo.free_physical = 15 			-- 免费 (获赠体力)
WorshipChoiceVo.free_cost = 0	   			-- 免费 (消耗量)
WorshipChoiceVo.coin_physical = 30 			-- 金币 (获赠体力)
WorshipChoiceVo.coin_cost = 30000  			-- 金币  (消耗量)
WorshipChoiceVo.diamon_physical = 100 		-- 钻石 (获赠体力)
WorshipChoiceVo.diamon_cost = 150 			-- 钻石  (消耗量)
--公会头像 值对象
OrganizIconVo = class("OrganizIconVo")
OrganizIconVo.id = 0
OrganizIconVo.resId = ""  --资源id
OrganizIconVo.bgId = ""   --背景id

--膜拜描述 值对象 
WorshopDescVo = class("WorshopDescVo")
WorshopDescVo.coutWorship = 0 --累计被膜拜次数
WorshopDescVo.rewardNum = 0 --领取数
WorshopDescVo.surplusWorship = 0 --剩余膜拜次数

--申请人 值对象
GuildApplyVo = class("GuildApplyVo")
GuildApplyVo.id = 0
GuildApplyVo.channelId = 0
GuildApplyVo.zoneId = 0
GuildApplyVo.faceId = 0
GuildApplyVo.name = ""
GuildApplyVo.level = 0
GuildApplyVo.attack = 0

--公会人物 值对象 
GuildPlayerVo = class("GuildPlayerVo")
GuildPlayerVo.id = ""
GuildPlayerVo.faceId = 0
GuildPlayerVo.name = ""
GuildPlayerVo.level = 0
GuildPlayerVo.fightValue = 0 --总战力
GuildPlayerVo.clazz = 0 --阶级类型
GuildPlayerVo.worship = 0 --膜拜类型
GuildPlayerVo.physicalStatus = 0 --体力赠送状态
GuildPlayerVo.role_id = nil
GuildPlayerVo.guild = "" --公会名称
GuildPlayerVo.sex = 0 --性别
GuildPlayerVo.heroList = nil
GuildPlayerVo.donateCur = 0    --当前帮贡
GuildPlayerVo.donateTotal = 0  --全部帮贡
GuildPlayerVo.historyLoginTime = 0 --上一次登录时间
GuildPlayerVo.winPerc = 0 --公会战 胜率
GuildPlayerVo.winNum = 0 --公会战 胜出场数
GuildPlayerVo.fightRank = 0 --公会战 排名

--会长权限 页面 值对象
PermissionVo = class("PermissionVo")
PermissionVo.iconId = 0
PermissionVo.desc = ""
PermissionVo.freeLevel = 99

--互赠体力 值对象 
GivePhysicalVo = class("GivePhysicalVo")
GivePhysicalVo.getRewardNum = 0    --获增次数
GivePhysicalVo.getRewardLimit = 3
GivePhysicalVo.sendRewardNum = 0   --赠送次数
GivePhysicalVo.sendRewardLimit = 3

--公会捐献面板
GuildDonatePanelVo = class("DonatePanelVo")
GuildDonatePanelVo.coutCoin = 0 --已捐献金币
-- GuildDonatePanelVo.coutDiamon = 0 --已捐献次数(钻石)
GuildDonatePanelVo.initCoin = 0 --初始化金币量
GuildDonatePanelVo.coinAdd = 0 --金币步进
GuildDonatePanelVo.donateMeAdd = 0 --个人贡献步进
GuildDonatePanelVo.donateGuildAdd = 0 --公会资金步进

--公会升级消耗 对象值
GuildLevupCostVo = class("GuildLevupCostVo")
GuildLevupCostVo.lev = 0
GuildLevupCostVo.coin = 0

--公会群发邮件消耗 对象值
GuildMailCostVo = class("GuildMailCostVo")
GuildMailCostVo.cout = 0  --次数
GuildMailCostVo.cost = 0  --消耗值(钻石)

--公会成员上限 对象值
GuildLevLimitVo = class("GuildLevLimitVo")
GuildLevLimitVo.lev = 0
GuildLevLimitVo.people = 0
GuildLevLimitVo.todayLimitDonate = 0 --每日贡献上限

--公会捐赠消耗 
GuildDonateCostVo = class("GuildDonateCostVo")
GuildDonateCostVo.cout = 0
GuildDonateCostVo.cost = 0
GuildDonateCostVo.donate = 0

--公会免申请 配置
GuildQuickJoinVo = class("GuildQuickJoinVo") 
GuildQuickJoinVo.lev = 0
GuildQuickJoinVo.id = 0

--公会Boss 值对象
GuildBossVo = class("GuildBossVo")
GuildBossVo.id = 0 
GuildBossVo.rewardList = nil --可能掉落的物品
GuildBossVo.hurtList = nil --伤害记录
GuildBossVo.hp = 0 --当前hp
GuildBossVo.isActive = 0 --是否激活
GuildBossVo.cost_donate = 0 --开启消耗 贡献
GuildBossVo.guild_lev = 0 --公会等级要求
GuildBossVo.battle_id = 0
GuildBossVo.active_num = 0 --激活次数
GuildBossVo.scale = nil
GuildBossVo.pos = nil
GuildBossVo.hadBeenFight = 0 --是否曾经打过
GuildBossVo.leftDay = "" --该boss的剩余时间

--竞拍项 值对象
GuildAuctionVo = class("GuildAuctionVo")
GuildAuctionVo.id = 0     --竞拍id
GuildAuctionVo.base_id = 0 --物品id
GuildAuctionVo.num = 0	  --竞拍数量
GuildAuctionVo.status = 0 --状态
GuildAuctionVo.boss_id = 0  --来源boss
GuildAuctionVo.time = 0  --竞拍倒计时
GuildAuctionVo.people = 0
GuildAuctionVo.cost = 0 --我的出价
GuildAuctionVo.top_price = 0 --最高出价
GuildAuctionVo.height = 142

--竞拍项 [配置 数据]
GuildAuctionDataVo = class("GuildAuctionDataVo")
GuildAuctionDataVo.base_id = 0
GuildAuctionDataVo.pass_left = 0 --流拍补偿
GuildAuctionDataVo.low_bid = 0 --最低竞拍价

--竞拍记录 值对象
GuildRecordVo = class("GuildRecordVo")
GuildRecordVo.id = 0 
GuildRecordVo.base_id = 0
GuildRecordVo.num = 0	  --竞拍数量
GuildRecordVo.time = 0 --竞拍时间
GuildRecordVo.cost = 0 --竞价
GuildRecordVo.playerName = "" --玩家名称

--公会技能 描述类 值对象
GuildSkillVo = class("GuildSkillVo")
GuildSkillVo.id = 0
GuildSkillVo.name = ""
GuildSkillVo.desc = ""
GuildSkillVo.lev = 0 
GuildSkillVo.guild_lev = 0 --公会等级要求
GuildSkillVo.guild_donate_cost = 0 -- 公会 贡献要求
GuildSkillVo.me_donate_cost = 0 --  个人 贡献要求
GuildSkillVo.cost_gold = 0 --金币消耗

--公会战场景 值对象
GuildFightSceneVo = class("GuildFightSceneVo")
GuildFightSceneVo.signupCost = 0 --公会战报名 消耗
GuildFightSceneVo.signupLev = 0 --公会等级
GuildFightSceneVo.curMoment = 0 --当前阶段 [报名/备战...]
GuildFightSceneVo.curScheId = 0 --当前场次
GuildFightSceneVo.signup_start = 0 --开始报名时间
GuildFightSceneVo.signup_end = 0 --结束报名时间
GuildFightSceneVo.scheduleList = nil --本赛季 日程列表
GuildFightSceneVo.signupNum = 0 --已报名公会数
GuildFightSceneVo.isSignup = 0 --本公会是否已报名
GuildFightSceneVo.isCheer = 0 --本公会是否已助威
GuildFightSceneVo.isMissCurFight = 0 --是否错过本次 公会战
GuildFightSceneVo.enemyInfo = nil --对手 信息 
GuildFightSceneVo.areaNumList = nil --各区域人数
GuildFightSceneVo.mySessionScore = 0  --我方公会 本场 积分
GuildFightSceneVo.enemySessionScore = 0 --敌方公会 本场 积分
GuildFightSceneVo.showMorrorArea = 0 --展示镜像区域 
function GuildFightSceneVo:getCurScheInfo()
	return self.scheduleList[ self.curScheId ]
end
function GuildFightSceneVo:getMaxScheInfo()
	return self.scheduleList[#self.scheduleList]
end
function GuildFightSceneVo:getAreaNumById(id)
	return self.areaNumList[ id ]
end

--公会战 报名消耗
GuildFightSignupCostVo = class("GuildFightSignupCostVo")
GuildFightSignupCostVo.cost = 0 --公会资金

--公会战 预备阶段
GuildFightPerpareVo = class("GuildFightPerpareVo")
GuildFightPerpareVo.curFightEnemy = nil --当前 对战匹配 对手
--公会战 战绩
GuildFightHistorySceneVo = class("GuildFightHistorySceneVo")
GuildFightHistorySceneVo.winPerc = 0 --本届胜率
GuildFightHistorySceneVo.totalScore = 0 --本届总积分
GuildFightHistorySceneVo.winRound = 0 --胜利场数
--公会战 区域标题
GuildFightAreaTitleVo = class("GuildFightAreaTitleVo")
GuildFightAreaTitleVo.t = 0 --区域类型 [火力,保护..]
GuildFightAreaTitleVo.addition = 0 --加成
GuildFightAreaTitleVo.height = 80 --控件高度
GuildFightAreaTitleVo.widget = "fightarea_" --具体控件

--公会战 [我方] 战斗英雄   仅用来 记录血量情况
GuildFightHeroVo = class("GuildFightHeroVo")
GuildFightHeroVo.id = 0 
GuildFightHeroVo.hp = 0 --血量
GuildFightHeroVo.maxHp = 0 --血量上限
GuildFightHeroVo.pos = 0 --上阵位置
GuildFightHeroVo.perc = 1 --血量百分比
GuildFightHeroVo.molecular = 0 --分子
GuildFightHeroVo.denominator = 0 --分母
--公会战 助威 条目
GuildFightCheerVo = class("GuildFightCheerVo")
GuildFightCheerVo.id = 0 --阶数
GuildFightCheerVo.cheer_num = 0 --需要助威人数
GuildFightCheerVo.protection_limit = 0
GuildFightCheerVo.defence_limit = 0
GuildFightCheerVo.power_limit = 0
GuildFightCheerVo.act_addition = 0
GuildFightCheerVo.hp_addition = 0

--公会战 本届赛程 条目
GuildFightScheItemVo = class("GuildFightScheItemVo")
GuildFightScheItemVo.id = 0
GuildFightScheItemVo.monent = 0 --处于的阶段
GuildFightScheItemVo.session = 0
GuildFightScheItemVo.time = 0
GuildFightScheItemVo.isWin = 0
GuildFightScheItemVo.height = 116
GuildFightScheItemVo.widget = "glorySche_"

--公会战 全服 战况 条目标题
GuildFightSituationTitleItemVo = class("GuildFightSituationTitleItemVo")
GuildFightSituationTitleItemVo.id = 0
GuildFightSituationTitleItemVo.day = 0
GuildFightSituationTitleItemVo.height = 55
GuildFightSituationTitleItemVo.widget = "fightAllCombatTitle_"

--公会战 对战结果 记录
GuildFightCombatRecordVo = class("GuildFightCombatRecordVo")
GuildFightCombatRecordVo.id = 0 --场次
GuildFightCombatRecordVo.isWin = 0
GuildFightCombatRecordVo.integral = 0 --本届积分
GuildFightCombatRecordVo.num1 = 0
GuildFightCombatRecordVo.name1 = ""
GuildFightCombatRecordVo.lev1 = 0
GuildFightCombatRecordVo.guildId1 = 0
GuildFightCombatRecordVo.num2 = 0
GuildFightCombatRecordVo.name2 = ""
GuildFightCombatRecordVo.lev2 = 0
GuildFightCombatRecordVo.guildId2 = 0
--公会战 赛季总排名
GuildFightCombatRankVo = class("GuildFightCombatRankVo")
GuildFightCombatRankVo.rank = 0 --排名
GuildFightCombatRankVo.id = 0 --公会Id
GuildFightCombatRankVo.name = ""
GuildFightCombatRankVo.lev = 0
GuildFightCombatRankVo.win_num = 0
GuildFightCombatRankVo.session_max = 0
GuildFightCombatRankVo.height = 82
--公会战 战绩 面板
GuildFightScoreViewVo = class("GuildFightScoreViewVo")
GuildFightScoreViewVo.scoreTotal = 0
GuildFightScoreViewVo.win_num = 0
GuildFightScoreViewVo.session_max = 0
GuildFightScoreViewVo.lastRank = 0 --本公会上届排名

--公会战 战利场景
GuildFightGlorySceneVo = class("GuildFightGlorySceneVo")
GuildFightGlorySceneVo.allotType = 1 --分配方式
GuildFightGlorySceneVo.focusRoleId = nil  --焦点角色

--公会战 成员 积分排名
GuildFightGloryMemberVo = class("GuildFightGloryMemberVo")
GuildFightGloryMemberVo.rank = 0
GuildFightGloryMemberVo.role_id = nil
GuildFightGloryMemberVo.score = 0
GuildFightGloryMemberVo.id = ""
GuildFightGloryMemberVo.height = 82
GuildFightGloryMemberVo.is_spoils = 0

--公会战 战利 物品
GuildFightGloryGiftVo = class("GuildFightGloryGiftVo")
GuildFightGloryGiftVo.id = 0
GuildFightGloryGiftVo.base_id = 0
GuildFightGloryGiftVo.num = 0
GuildFightGloryGiftVo.create_time = 0
GuildFightGloryGiftVo.height = 132

--公会战 战利 日志 条目标题
GuildFightLogTitleItemVo = class("GuildFightLogTitleItemVo")
GuildFightLogTitleItemVo.id = 0 --以日子时间 为id
GuildFightLogTitleItemVo.height = 47
GuildFightLogTitleItemVo.widget = "gloryLogTitle_"
--公会战 战利 日志 条目
GuildFightLogItemVo = class("GuildFightLogItemVo")
GuildFightLogItemVo.id = 0
GuildFightLogItemVo.time = 0
GuildFightLogItemVo.height = 47
GuildFightLogItemVo.widget = "gloryLog_"
--公会战 战斗冷却
GuildFightColdVo = class("GuildFightColdVo")
GuildFightColdVo.combat_num = 0
GuildFightColdVo.cd_time = 0
--公会战 队伍战斗状况
GuildFightTeamVo = class("GuildFightTeamVo")
GuildFightTeamVo.curNum = 0
GuildFightTeamVo.maxNum = 0
--公会战 战力排名
GuildFightPowerRankVo = class("GuildFightPowerRankVo")
GuildFightPowerRankVo.rank = 0 --排名
GuildFightPowerRankVo.id = 0 --公会Id
GuildFightPowerRankVo.num = 0
GuildFightPowerRankVo.logoId = 0
GuildFightPowerRankVo.name = ""
GuildFightPowerRankVo.lev = 0
GuildFightPowerRankVo.win_num = 0
GuildFightPowerRankVo.session_max = 1
GuildFightPowerRankVo.height = 95
GuildFightPowerRankVo.topRank = 0
--公会战 实时排名
GuildFightCurRankVo = class("GuildFightCurRankVo")
GuildFightCurRankVo.rank = 0 --排名
GuildFightCurRankVo.id = 0 --公会Id
GuildFightCurRankVo.num = 0
GuildFightCurRankVo.logoId = 0
GuildFightCurRankVo.name = ""
GuildFightCurRankVo.lev = 0
GuildFightCurRankVo.win_num = 0
GuildFightCurRankVo.session_max = 1
GuildFightCurRankVo.height = 62
GuildFightCurRankVo.topRank = 0