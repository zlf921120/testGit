-- 公会竞拍记录 条目

GuildRecordItem = class("GuildRecordItem",function()
    return Layout:create()
end)
GuildRecordItem.__index = GuildRecordItem
GuildRecordItem._widget 	= nil
GuildRecordItem.uiLayer 	= nil
GuildRecordItem.recordVo = nil

function GuildRecordItem:create(recordVo)
    local ret = GuildRecordItem.new()
    ret:init(recordVo)
    return ret
end

function GuildRecordItem:init(recordVo)
	self.recordVo = recordVo

	self._widget = GuildDataProxy:getInstance():getWidgetRecordItem():clone()
    self:setSize(CCSize(850,140))
    self:addChild(self._widget)

    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labNum = tolua.cast(self._widget:getChildByName("lab_num"),"Label")
    self.labProd = tolua.cast(self._widget:getChildByName("lab_production"),"Label")
    self.labCost = tolua.cast(self._widget:getChildByName("lab_cost"),"Label")
    self.labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")
    self.labAccout = tolua.cast(self._widget:getChildByName("lab_accout"),"Label")

    require "ItemIcon"
    require "ItemInfoPanel"
    self.itemIcon = ItemIcon:create()
    self.itemIcon:setPosition(ccp(75,70))
    self.itemIcon:setTouchEvent(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.began then

                ItemInfoPanel:show(pSender:getTag())

        elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then

            ItemInfoPanel:hide()
        end
    end)
    self._widget:addChild( self.itemIcon,5 )

    self:update()
end

function GuildRecordItem:update()

	self.itemIcon:setBaseId(self.recordVo.base_id)
    self.itemIcon:getClickImg():setTag(self.recordVo.base_id)
	self.itemIcon:setItemNum(1)

    local now = ServerTimerManager:getInstance():getCurTime()
    local itemMode = ItemManager:getInstance():getItemModelByBaseId(self.recordVo.base_id)
    local monstorMode = MonsterManager:getInstance():getBaseInfo(self.recordVo.boss_id)

	self.labName:setText(itemMode.name)
	self.labNum:setText("x"..self.recordVo.num)
	self.labProd:setText(monstorMode.name)
    if self.recordVo.isCurPlayer then
        self.labCost:setText(self.recordVo.cost)
    else
        self.labCost:setText(string.format("以%d貢獻拍得",self.recordVo.cost))
    end
    self.labAccout:setText(self.recordVo.playerName)

    self.labTime:setText( Helper.getChCoutStrTime( now - self.recordVo.time, 60 * 60 ) )

end
---------------------------------------------------------------
-- 公会竞拍 纪录 标题Item
GuildRecordTitleItem = class("GuildRecordTitleItem",function()
    return Layout:create()
end)

function GuildRecordTitleItem:create(txt)
    local ret = GuildRecordTitleItem.new()
    ret:init(txt)
    return ret
end

function GuildRecordTitleItem:init(txt)
    self._widget = GuildDataProxy:getInstance():getWidgetRecordTitleItem():clone()
    self:setSize(CCSize(850,52))
    self:addChild(self._widget)

    self.labTitle = tolua.cast(self._widget:getChildByName("lab_title"),"Label")
    self.labTitle:setText(txt)
end
