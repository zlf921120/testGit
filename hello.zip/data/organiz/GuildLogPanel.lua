--公会日志 面板

GuildLogPanel = class("GuildLogPanel",WindowBase)
GuildLogPanel.__index = GuildLogPanel
GuildLogPanel._widget     = nil
GuildLogPanel.uiLayer    = nil
GuildLogPanel.is_dispose = true

local __instance = nil

function GuildLogPanel:create()
    local ret = GuildLogPanel.new()
    __instance = ret
    return ret   
end

function GuildLogPanel:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
end

function GuildLogPanel:init()
	
	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildLogPanel.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then
		    WindowCtrl:getInstance():close(self.name)
		end
   	end)

   	self.scrolLog = DisplayUtil.createAdaptScrollView(820,432,140,0,1)

    self.scrolLog:setPosition(ccp(68,32))
    self._widget:addChild(self.scrolLog,10)

    Notifier.regist(OrganizEvent.MSG_UPDATE_GUILD_LOG,function() 
        GuildRenderMgr:getInstance():renderGuildLogVoListAdapt(self.scrolLog) 

        self.scrolLog:stopAllActions()
        self.scrolLog:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolLog:getInnerContainer():getPositionY()
                local viewRect = CCRectMake(0,math.abs(viewY),820,432)
                GuildRenderMgr:getInstance():refreshGuildLogVoList(viewRect,self.scrolLog)
            end),
            CCDelayTime:create(0.1))))
    end) 
end