-- 公会 Boss 条目(小)
GuildBossItem = class("GuildBossItem",function()
    return Layout:create()
end)
GuildBossItem.__index = GuildBossItem
GuildBossItem._widget 	= nil
GuildBossItem.uiLayer 	= nil
GuildBossItem.bossVo = nil

function GuildBossItem:create()
    local ret = GuildBossItem.new()
    ret:init()
    return ret
end

function GuildBossItem:init()

	self._widget = GuildDataProxy:getInstance():getWidgetBossItem():clone()
    self:setSize(CCSize(286,438))
    self:addChild(self._widget)

    self.btnShow = tolua.cast(self._widget:getChildByName("btn_show"),"Button")
    self.btnShow:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            WindowCtrl:getInstance():open(CmdName.Guild_View_BossPerpare,{boss_id = self.bossVo.id})
        end
    end)

    self.panelView = tolua.cast(self._widget:getChildByName("panel_view"),"Layout")
    self.labDesc = tolua.cast(self._widget:getChildByName("lab_desc"),"Label")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.loadHp = tolua.cast(self.panelView:getChildByName("load_hp"),"LoadingBar")
    self.labPerc = tolua.cast(self.panelView:getChildByName("lab_perc"),"Label")
    self.labTips = tolua.cast(self._widget:getChildByName("lab_tips"),"Label")
    self.imgTips = tolua.cast(self._widget:getChildByName("img_tips"),"Label")
    self.imgBoss = tolua.cast(self._widget:getChildByName("img_boss"),"ImageView")

    Notifier.regist(OrganizEvent.MSG_UPDATE_BOSS_SCENE_ITEM,function(id) 
        if self.bossVo and id == self.bossVo.id then
             -- print(" id == self.bossVo.id ",id ,self.bossVo.id)
            self:update() 
        end
    end)
end

function GuildBossItem:setData(bossVo)

    -- if self.bossVo and self.bossVo.id == bossVo.id then
    --     --相同的骨骼 不刷新
    -- else
    --     if self._widget:getNodeByTag(5241) ~= nil then
    --         self._widget:removeNodeByTag(5241)
    --         AnimateManager:getInstance():clear(self.arm_boss_path)
    --     end

    --     local monstorMode = MonsterManager:getInstance():getBaseInfo(bossVo.id)
    --     local animateCfg = EffectManager:getInstance():getActionData(monstorMode.animat_res_id)
    --     local armBoss = AnimateManager:getInstance():getArmature(animateCfg._fileFullPathName, animateCfg._fileName)
    --     armBoss:setPosition(ccp( 142 + tonumber(bossVo.pos[1]), 234 + tonumber(bossVo.pos[2]) ))
    --     armBoss:setScale(bossVo.scale)
    --     armBoss:setTag(5241)
    --     armBoss:getAnimation():play("stand")
    --     self._widget:addNode(armBoss)
    --     self.arm_boss_path = animateCfg._fileFullPathName
    -- end

    self.bossVo = bossVo
    self:update()
end

function GuildBossItem:setType(type)
    if type == 1 then --有查看按钮
        self.btnShow:setVisible(true)
        self.btnShow:setTouchEnabled(true)
        self.labDesc:setVisible(false)
    elseif type == 2 then --没有查看按钮
        self.btnShow:setVisible(false)
        self.btnShow:setTouchEnabled(false)
        self.labDesc:setVisible(true)
    end
end

function GuildBossItem:update()

	local monstorMode = MonsterManager:getInstance():getBaseInfo(self.bossVo.id)
    local monstorAttr = MonsterManager:getInstance():getBaseAttr(self.bossVo.id)

    local hpMax = monstorAttr[ AttrHelper.attr_flag.hp ]
    self.labName:setText(monstorMode.name)
    self.labDesc:setText(monstorMode.desc)

    self.imgBoss:loadTexture(string.format("guild_boss_%s.png",self.bossVo.boss_img),UI_TEX_TYPE_PLIST)

    self.panelView:setVisible(true)
    self.labTips:setVisible(false)
    self.loadHp:setPercent(self.bossVo.hp / hpMax * 100)
    self.labPerc:setText(string.format("%.2f%%",self.bossVo.hp / hpMax * 100) )

    local guildLev = CharacterManager:getInstance():getGuildData():getLev()
    if guildLev < self.bossVo.guild_lev then --未满足条件开启
        self.panelView:setVisible(false)
        self.labTips:setText(string.format("公會%d級開啟",self.bossVo.guild_lev))
        self.labTips:setVisible(true)
    elseif self.bossVo.isActive == 0 or self.bossVo.hp <= 0 then --未开启/已死亡
        self.panelView:setVisible(false)
    end

    self.imgTips:setVisible(self.bossVo.hp <= 0)
end
--------------------------------------------------------------------------------------------
-- 公会 Boss 条目 (大)
GuildBossBigItem = class("GuildBossBigItem",function()
    return Layout:create()
end)
GuildBossBigItem.__index = GuildBossBigItem
GuildBossBigItem._widget   = nil
GuildBossBigItem.uiLayer   = nil
GuildBossBigItem.bossVo = nil

function GuildBossBigItem:create()
    local ret = GuildBossBigItem.new()
    ret:init()
    return ret
end

function GuildBossBigItem:init()
    self._widget = GuildDataProxy:getInstance():getWidgetBigBossItem():clone()
    self:setSize(CCSize(400,438))
    self:addChild(self._widget)

    self.btnShow = tolua.cast(self._widget:getChildByName("btn_show"),"Button")
    self.btnShow:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            WindowCtrl:getInstance():open(CmdName.Guild_View_BossPerpare,{boss_id = self.bossVo.id})
        end
    end)

    self.panelView = tolua.cast(self._widget:getChildByName("panel_view"),"Layout")
    self.labDesc = tolua.cast(self._widget:getChildByName("lab_desc"),"Label")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.loadHp = tolua.cast(self.panelView:getChildByName("load_hp"),"LoadingBar")
    self.labPerc = tolua.cast(self.panelView:getChildByName("lab_perc"),"Label")
    self.labTips = tolua.cast(self._widget:getChildByName("lab_tips"),"Label")
    self.imgTips = tolua.cast(self._widget:getChildByName("img_tips"),"Label")
    self.imgBoss = tolua.cast(self._widget:getChildByName("img_boss"),"ImageView")

    self.panelTips = tolua.cast(self._widget:getChildByName("panel_tips"),"Layout")
    self.labContent = tolua.cast(self.panelTips:getChildByName("lab_content"),"Label")

    Notifier.regist(OrganizEvent.MSG_UPDATE_BOSS_SCENE_ITEM,function(id) 
        if self.bossVo and id == self.bossVo.id then
             -- print(" id == self.bossVo.id ",id ,self.bossVo.id)
            self:update() 
        end
    end)
end

function GuildBossBigItem:setData(bossVo)

    self.bossVo = bossVo
    self:update()
end

function GuildBossBigItem:setType(type)
    if type == 1 then --有查看按钮
        self.btnShow:setVisible(true)
        self.btnShow:setTouchEnabled(true)
        self.labDesc:setVisible(false)
    elseif type == 2 then --没有查看按钮
        self.btnShow:setVisible(false)
        self.btnShow:setTouchEnabled(false)
        self.labDesc:setVisible(true)
    end
end

function GuildBossBigItem:update()

    local monstorMode = MonsterManager:getInstance():getBaseInfo(self.bossVo.id)
    local monstorAttr = MonsterManager:getInstance():getBaseAttr(self.bossVo.id)

    self.imgBoss:loadTexture(string.format("guild_boss_%s.png",self.bossVo.boss_img),UI_TEX_TYPE_PLIST)

    local hpMax = monstorAttr[ AttrHelper.attr_flag.hp ]
    self.labName:setText(monstorMode.name)
    self.labDesc:setText(monstorMode.desc)

    self.panelView:setVisible(true)
    self.labTips:setVisible(false)
    self.loadHp:setPercent(self.bossVo.hp / hpMax * 100)
    self.labPerc:setText(string.format("%.2f%%",self.bossVo.hp / hpMax * 100) )

    local guildLev = CharacterManager:getInstance():getGuildData():getLev()
    if guildLev < self.bossVo.guild_lev then --未满足条件开启
        self.panelView:setVisible(false)
        self.labTips:setText(string.format("公會%d級開啟",self.bossVo.guild_lev))
        self.labTips:setVisible(true)
    elseif self.bossVo.isActive == 0 or self.bossVo.hp <= 0 then --未开启/已死亡
        self.panelView:setVisible(false)
    end

    self.imgTips:setVisible(self.bossVo.hp <= 0)

    self.panelTips:setVisible(string.len(self.bossVo.leftDay) > 0)
    if string.len(self.bossVo.leftDay) > 0 then
        self.labContent:setText(string.format("%s內成功擊殺，全部成員將獲得額外獎勵",self.bossVo.leftDay)) 
    end
end

-------------------------------------------------------------------------------------------
--Boss 伤害记录 条目
GuildBossHurtItem = class("GuildBossHurtItem",function()
    return Layout:create()
end)

GuildBossHurtItem.__index = GuildBossHurtItem
GuildBossHurtItem._widget = nil
GuildBossHurtItem.hurtVo = nil

function GuildBossHurtItem:create(hurtVo)
    local ret = GuildBossHurtItem.new()
    ret:init(hurtVo)
    return ret
end

function GuildBossHurtItem:init(hurtVo)

    self._widget = GuildDataProxy:getInstance():getWidgetHurtItem():clone()
    self:setSize(CCSize(534,50))
    self:addChild(self._widget)
    self.hurtVo = hurtVo

    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labHurt = tolua.cast(self._widget:getChildByName("lab_hurt"),"Label")
    self.labIdx = tolua.cast(self._widget:getChildByName("lab_idx"),"Label")

    self:update()
end

function GuildBossHurtItem:update()

    self.labName:setText( self.hurtVo.name )
    self.labHurt:setText( "單次輸出：" .. self.hurtVo.att )
    self.labIdx:setText( self.hurtVo.id )
end