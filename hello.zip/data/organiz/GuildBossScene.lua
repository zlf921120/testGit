--公会boss 面板
GuildBossScene = class("GuildBossScene",WindowBase)
GuildBossScene.__index = GuildBossScene
GuildBossScene._widget = nil
GuildBossScene.uiLayer = nil
GuildBossScene.btnLast = nil
GuildBossScene.panelLast = nil
GuildBossScene.is_dispose = true

local __instance = nil

function GuildBossScene:create()
    local ret = GuildBossScene.new()
    __instance = ret
    return ret
end

function GuildBossScene:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
    local volist = GuildDataProxy:getInstance():getBossVoList()
    for id,v in pairs(volist) do
        local monstorMode = MonsterManager:getInstance():getBaseInfo(id)
        local animateCfg = EffectManager:getInstance():getActionData(monstorMode.animat_res_id)
        AnimateManager:getInstance():clear(animateCfg._fileFullPathName)
        GuildRenderMgr:getInstance().dic:removeObjectForKey(string.format("bossitem_%d",id))
    end

    Notifier.removeByName(OrganizEvent.MSG_UPDATE_MYAUCTION_LIST)
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_AUCTION_LIST)
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_RECORD_LIST)
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_BOSS_LIST)
end

local function event_opt_boss(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
    	__instance.panelBoss:setVisible(true)
        __instance.panelBoss:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if __instance.btnLast ~= btn then
            __instance.btnLast:setFocused(false)
            __instance.btnLast:setTitleColor(ccc3(245,204,85))
            __instance.btnLast = btn
            
            __instance.panelLast:setVisible(false)
            __instance.panelLast:setZOrder(3)
            __instance.panelLast = __instance.panelBoss

            __instance:cleanAllRefresh()
            GuildRenderMgr:getInstance():renderBossList(__instance.listBoss)
        end
	end
end

local function event_opt_auction(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        __instance.panelAuction:setVisible(true)
        __instance.panelAuction:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if __instance.btnLast ~= btn then
            __instance.btnLast:setFocused(false)
            __instance.btnLast:setTitleColor(ccc3(245,204,85))
            __instance.btnLast = btn
            
            __instance.panelLast:setVisible(false)
            __instance.panelLast:setZOrder(3)
            __instance.panelLast = __instance.panelAuction

            __instance:cleanAllRefresh()
            GuildNetTask:getInstance():requestGuildAuctionList()

            -- __instance:startScheduleAuction()
        end
	end
end

local function event_opt_record(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        __instance.panelRecord:setVisible(true)
        __instance.panelRecord:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if __instance.btnLast ~= btn then
            __instance.btnLast:setFocused(false)
            __instance.btnLast:setTitleColor(ccc3(245,204,85))
            __instance.btnLast = btn
            
            __instance.panelLast:setVisible(false)
            __instance.panelLast:setZOrder(3)
            __instance.panelLast = __instance.panelRecord

            __instance:cleanAllRefresh()
            GuildNetTask:getInstance():requestAuctionRecord()
        end
	end
end

local function event_opt_desc(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        __instance.panelDesc:setVisible(true)
        __instance.panelDesc:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if __instance.btnLast ~= btn then
            __instance.btnLast:setFocused(false)
            __instance.btnLast:setTitleColor(ccc3(245,204,85))
            __instance.btnLast = btn
            
            __instance.panelLast:setVisible(false)
            __instance.panelLast:setZOrder(3)
            __instance.panelLast = __instance.panelDesc

            __instance:cleanAllRefresh()

        end
	end
end

local function event_opt_myauction(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        __instance.panelMyAuction:setVisible(true)
        __instance.panelMyAuction:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if __instance.btnLast ~= btn then
            __instance.btnLast:setFocused(false)
            __instance.btnLast:setTitleColor(ccc3(245,204,85))
            __instance.btnLast = btn
            
            __instance.panelLast:setVisible(false)
            __instance.panelLast:setZOrder(3)
            __instance.panelLast = __instance.panelMyAuction

            __instance:cleanAllRefresh()
            GuildNetTask:getInstance():requestMyAuctionList()
        end
    end
end

function GuildBossScene:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildBoss.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnOptBoss = tolua.cast(self._widget:getChildByName("btn_boss"),"Button")
    self.btnOptBoss:addTouchEventListener(event_opt_boss)
    self.btnOptAuction = tolua.cast(self._widget:getChildByName("btn_auction"),"Button")
    self.btnOptAuction:addTouchEventListener(event_opt_auction)
    self.btnOptRecord = tolua.cast(self._widget:getChildByName("btn_record"),"Button")
    self.btnOptRecord:addTouchEventListener(event_opt_record)
    self.btnOptDesc = tolua.cast(self._widget:getChildByName("btn_desc"),"Button")
    self.btnOptDesc:addTouchEventListener(event_opt_desc)
    self.btnOptMine = tolua.cast(self._widget:getChildByName("btn_mine"),"Button")
    self.btnOptMine:addTouchEventListener(event_opt_myauction)
    self.btnOptBoss:setFocused(true)
    self.btnOptBoss:setTitleColor(ccc3(210,253,238))
    self.btnLast = self.btnOptBoss 

    self.panelBoss = tolua.cast(self._widget:getChildByName("panel_boss"),"Layout")
    self.panelAuction = tolua.cast(self._widget:getChildByName("panel_auction"),"Layout")
    self.panelRecord = tolua.cast(self._widget:getChildByName("panel_record"),"Layout")
    self.panelDesc = tolua.cast(self._widget:getChildByName("panel_desc"),"Layout")
    self.panelMyAuction = tolua.cast(self._widget:getChildByName("panel_myauction"),"Layout")
    self.panelLast = self.panelBoss
   	
    self.btnLeft = tolua.cast(self.panelBoss:getChildByName("btn_left"),"Button")
    self.btnLeft:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            local scrol = tolua.cast(self.listBoss,"ScrollView")
            local perc = DisplayUtil.getScrollViewPercent(scrol)
            local offset = 900 / scrol:getInnerContainer():getContentSize().width * 100
            scrol:scrollToPercentHorizontal( perc - offset ,0.2,true)
        end
    end)
    self.btnRight = tolua.cast(self.panelBoss:getChildByName("btn_right"),"Button")
    self.btnRight:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            local scrol = tolua.cast(self.listBoss,"ScrollView")
            local perc = DisplayUtil.getScrollViewPercent(scrol)
            local offset = 900 / scrol:getInnerContainer():getContentSize().width * 100
            scrol:scrollToPercentHorizontal(perc + offset,0.2,true)
        end
    end)

    self.listBoss = tolua.cast(self.panelBoss:getChildByName("list_view"),"ListView")
    self.listRecord = tolua.cast(self.panelRecord:getChildByName("list_view"),"ListView")

    self.scrolAuction = DisplayUtil.createAdaptScrollView(850,420,142,0,1)
    self.panelAuction:addChild(self.scrolAuction)

    self.scrolMyAuction = DisplayUtil.createAdaptScrollView(850,420,142,0,1)
    self.panelMyAuction:addChild(self.scrolMyAuction)

    self.labAuctionDesc = tolua.cast(self.panelDesc:getChildByName("lab_desc"),"Label")
    self.labAuctionDesc:setText(OrganizCfg.AuctionInfo)
----------------------------------------------------------------------------------------------------
    Notifier.regist(OrganizEvent.MSG_UPDATE_AUCTION_LIST,function() 
        GuildRenderMgr:getInstance():renderAuctionListAdapt(self.scrolAuction)

        self.lastAuctionViewY = -1

        self.scrolAuction:stopAllActions()
        self.scrolAuction:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()

                local viewY = self.scrolAuction:getInnerContainer():getPositionY()
                if self.lastAuctionViewY ~= viewY then
                    self.lastAuctionViewY = viewY
                    local viewRect = CCRectMake(0,math.abs(viewY),850,420)
                    GuildRenderMgr:getInstance():refreshViewAuctionVoList(viewRect,self.scrolAuction)
                end
            end),
            CCDelayTime:create(0.1))))
    end)
----------------------------------------------------------------------------------------------------
    Notifier.regist(OrganizEvent.MSG_UPDATE_MYAUCTION_LIST,function() 
        GuildRenderMgr:getInstance():renderMyAuctionListAdapt(self.scrolMyAuction)
        self:hideNewsTip(NewTipsEnum.guild_myauction)

        self.lastMyAuctionY = -1

        self.scrolMyAuction:stopAllActions()
        self.scrolMyAuction:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()

                local viewY = self.scrolMyAuction:getInnerContainer():getPositionY()
                if self.lastMyAuctionY ~= viewY then
                    self.lastMyAuctionY = viewY
                    local viewRect = CCRectMake(0,math.abs(viewY),850,420)
                    GuildRenderMgr:getInstance():refreshViewMyAuctionVoList(viewRect,self.scrolMyAuction)
                end
            end),
            CCDelayTime:create(0.1))))
    end)
----------------------------------------------------------------------------------------------------

    Notifier.regist(OrganizEvent.MSG_UPDATE_RECORD_LIST,function() 
        GuildRenderMgr:getInstance():renderRecordList(self.listRecord) 
    end)
    Notifier.regist(OrganizEvent.MSG_UPDATE_BOSS_LIST,function()
        GuildRenderMgr:getInstance():renderBossList(self.listBoss)
    end)
end

function GuildBossScene:cleanAllRefresh()
    self.scrolAuction:stopAllActions()
    self.scrolMyAuction:stopAllActions()
end

function GuildBossScene:open()

    GuildNetTask:getInstance():requestBossList()
    --默认点击第一个
    event_opt_boss(self.btnOptBoss, ComConstTab.TouchEventType.ended)

    if GuildDataProxy:getInstance().myauction_news > 0 then
        self:showNewsTip(NewTipsEnum.guild_myauction)
    end
end

function GuildBossScene:close()

    self.listRecord:removeAllItems()

    WindowCtrl:getInstance():open(CmdName.Guild_View_Member)
end

function GuildBossScene:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

function GuildBossScene:showNewsTip(key)
    local target = nil
    local pos = nil
    if key == NewTipsEnum.guild_myauction then
        target = self.btnOptMine
        pos = ccp(55,20)
    end
    if target and target:getChildByTag(2866) == nil then
        local tips_img = ImageView:create()
        tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
        tips_img:setTag(2866)
        tips_img:setPosition(pos)
        target:addChild(tips_img)
        self:tipsPointPlayAct(tips_img)
    elseif target and target:getChildByTag(2866) ~= nil then
        local tips_img = target:getChildByTag(2866)
        self:tipsPointPlayAct(tips_img)
    end
end

-- 隐藏 新消息 提示
function GuildBossScene:hideNewsTip(key)
    local target = nil
    if key == NewTipsEnum.guild_myauction then
        target = self.btnOptMine
    end
    if target and target:getChildByTag(2866) ~= nil then
        CharacterManager:getInstance():getBaseData():setNewsTipStatus(key,1) --0 显示  1 不显示
        target:removeChildByTag(2866,true)
        GuildDataProxy:getInstance().myauction_news = 0
        Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.guild)
        Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_NEW_TIPS_HIDE,NewTipsEnum.guild_boss)
    end
end