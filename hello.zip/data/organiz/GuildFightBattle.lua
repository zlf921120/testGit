-- 公会战 战斗 对手英雄 场景
GuildFightBattle = class("GuildFightBattle",WindowBase)
GuildFightBattle.__index = GuildFightBattle
GuildFightBattle._widget = nil
GuildFightBattle.uiLayer = nil

local __instance = nil

function GuildFightBattle:create()
    local ret = GuildFightBattle.new()
    __instance = ret
    return ret
end

function GuildFightBattle:init()
    
	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightBattle.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.scrolEnemy = DisplayUtil.createAdaptScrollView(880,420,0,0,1)
    self.scrolEnemy:setPosition(ccp(37,78))
    self._widget:addChild(self.scrolEnemy,5)
 	GuildRenderMgr:getInstance():initFightEnemyScrol(self.scrolEnemy)

    self.imgBg = ImageView:create()
    self.imgBg:setPosition(ccp(480,320))
    self._widget:addChild(self.imgBg)

    self.labTime = tolua.cast(self.uiLayer:getWidgetByName("lab_left_time"),"Label")

    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_ENEMY_LIST,function() 
        GuildRenderMgr:getInstance():renderFightEnemyListAdapt(self.scrolEnemy)

        self.lastEnemyViewY = -1

        self.scrolEnemy:stopAllActions()
        self.scrolEnemy:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolEnemy:getInnerContainer():getPositionY()
                if self.lastEnemyViewY ~= viewY then
                    self.lastEnemyViewY = viewY
                    
                    local viewRect = CCRectMake(0,math.abs(viewY),880,420)
                    GuildRenderMgr:getInstance():refreshFightEnemyList(viewRect,self.scrolEnemy)
                end
            end),
            CCDelayTime:create(0.1))))

        self:update()
    end)

    self.btnDesc = tolua.cast(self.uiLayer:getWidgetByName("btn_desc"),"Button")
    self.btnDesc:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Comm_DescPanel,
                {title="公會戰",content=OrganizCfg.GuildFightInfo,
                rewardArr = {{img="gold.png",lab="金幣"},
                            {img="reward_enchan.png",lab="附魔書"},
                            {img="reward_hero_exp.png",lab="經驗藥"},
                            {img="reward_pet.png",lab="侍寵進階精華"}}})
        end
    end)

    self._runTimer = function()
        local dp = GuildDataProxy:getInstance()
        local nowTime = ServerTimerManager:getInstance():getCurTime()
        local sceneVo = dp:getGuildFightSceneVo()
        local sec = sceneVo:getCurScheInfo().combat_end - nowTime
        self.labTime:setText( Helper.getChCoutStringTime(math.max(0,sec)))
        --检测是否冷却中
        local role_info = OrganizHelper.getCurFightRoleInfo()
        if role_info.guild_fight_combat_status == GuildFightCombatStatus.Cold then
            self.panelCold:setVisible(true)
            self.labTips:setVisible(false)

            local sec = dp:getCombatColdVoById(math.max(role_info.combat_num,1)).cd_time - (nowTime - role_info.guild_fight_coldtime)
            self.labColdTime:setText(Helper.sec2TimeStr(math.max(0,sec)))

            if sec <= 0 then --倒计时<=0后要主动刷新一次
                GuildNetTask:getInstance():requestGuildFightEnemyList() 
            end
        else
            self.panelCold:setVisible(false)
            self.labTips:setVisible(true)
        end
    end

    self.panelCold = tolua.cast(self.uiLayer:getWidgetByName("panel_cold"),"Label")
    self.labTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips"),"Label")
    self.labColdTime = tolua.cast(self.uiLayer:getWidgetByName("lab_cold_time"),"Label")
end

function GuildFightBattle:update()
    --取消绿点
    GuildDataProxy:getInstance().short_fight_news = 0
    Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.mainui_guild_fight)
    
    GuildRenderMgr:getInstance():renderFightEnemyListAdapt(self.scrolEnemy)

    self:startSchedule()
end

function GuildFightBattle:enter()
    GuildNetTask:getInstance():requestGuildFightEnemyList() 
end

function GuildFightBattle:returnFun()
    WindowCtrl:getInstance():close(self.name)
    WindowCtrl:getInstance():open(CmdName.Guild_View_FightScene,{norefresh = 1})
end

function GuildFightBattle:startSchedule()
    TimerManager.addTimer(1000,self._runTimer,true)
end

function GuildFightBattle:clearSchedule()
    TimerManager.removeTimer(self._runTimer)
end

function GuildFightBattle:open()
    GuildDataProxy:getInstance():reloadWidget(GuildFightWidget.FightPlayer)
    GuildNetTask:getInstance():requestGuildFightEnemyList()

    self.imgBg:loadTexture("ui/organiz/member/fight/guild_fight_bg.jpg")
    self.imgBg:setScaleX(1/DisplayUtil.min_scale*DisplayUtil.max_scale)
    self.imgBg:setScaleY(1/DisplayUtil.min_scale*DisplayUtil.max_scale)
----------------------------------------------------------------------
    local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()
    sceneVo.showMorrorArea = GuildFightMorror.Combat
end

function GuildFightBattle:close()
    self:clearSchedule()
    CCTextureCache:sharedTextureCache():removeTextureForKey("ui/organiz/member/fight/guild_fight_bg.jpg")
end