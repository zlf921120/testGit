-- 公会战 备战 修改占位 场景
GuildFightEditView = class("GuildFightEditView",WindowBase)
GuildFightEditView.__index = GuildFightEditView
GuildFightEditView._widget = nil
GuildFightEditView.uiLayer = nil
GuildFightEditView.is_dispose = true

local __instance = nil

function GuildFightEditView:create()
    local ret = GuildFightEditView.new()
    __instance = ret
    return ret
end

function GuildFightEditView:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
end

function GuildFightEditView:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightEditView.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.btnProtect = tolua.cast(self.uiLayer:getWidgetByName("btn_protect"),"Button")
    self.btnDefense = tolua.cast(self.uiLayer:getWidgetByName("btn_defense"),"Button")
    self.btnPower = tolua.cast(self.uiLayer:getWidgetByName("btn_power"),"Button")
    self.btnComm = tolua.cast(self.uiLayer:getWidgetByName("btn_comm"),"Button")
    self.btnLock = tolua.cast(self.uiLayer:getWidgetByName("btn_lock"),"Button")
    self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    self.labFc = tolua.cast(self.uiLayer:getWidgetByName("lab_fc"),"Label")
    self.labName = tolua.cast(self.uiLayer:getWidgetByName("lab_name"),"Label")

    self.btnTbl = {}
    self.btnTbl[ GuildFightArea.Protect ] = self.btnProtect
    self.btnTbl[ GuildFightArea.Power ] = self.btnPower
    self.btnTbl[ GuildFightArea.Defense ] = self.btnDefense
    self.btnTbl[ GuildFightArea.Common ] = self.btnComm

 	self.btnProtect:addTouchEventListener(function(sender, eventType)
    	if eventType == ComConstTab.TouchEventType.ended then

            GuildNetTask:getInstance():requestGuildFightEditArea(self.id,GuildFightArea.Protect)
		end
 	end)
 	
 	self.btnDefense:addTouchEventListener(function(sender, eventType)
    	if eventType == ComConstTab.TouchEventType.ended then

            GuildNetTask:getInstance():requestGuildFightEditArea(self.id,GuildFightArea.Defense)
		end
 	end)
 	
 	self.btnPower:addTouchEventListener(function(sender, eventType)
    	if eventType == ComConstTab.TouchEventType.ended then

            GuildNetTask:getInstance():requestGuildFightEditArea(self.id,GuildFightArea.Power)
		end
 	end)
 	
 	self.btnComm:addTouchEventListener(function(sender, eventType)
    	if eventType == ComConstTab.TouchEventType.ended then

            GuildNetTask:getInstance():requestGuildFightEditArea(self.id,GuildFightArea.Common)
		end
 	end)
 	
 	self.btnLock:addTouchEventListener(function(sender, eventType)
    	if eventType == ComConstTab.TouchEventType.ended then
    		
            GuildNetTask:getInstance():requestGuildFightLockArea(self.id)
		end
 	end)
    
    self.btnClose:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    self.hero_icons = {}
    for i=1,6 do
        local icon = HeroIcon:create()
        icon:setScale(0.5)
        icon:setPosition(ccp(222 + (i-1) * 75,386))
        self._widget:addChild(icon,2)
        table.insert(self.hero_icons,icon)
    end
end

function GuildFightEditView:update()

    for i=1,#self.hero_icons do
        local icon = self.hero_icons[i]
        local hero_info = self.playerVo.heros[i]

        if hero_info ~= nil then
            icon:setVisible(true)
            icon:setOtherHeroInfo(hero_info)
        else
            icon:setOtherHeroInfo(nil)
        end
    end

    self.labFc:setText(self.playerVo.fight_capacity)
    self.labName:setText(self.playerVo.role_name .." Lv."..self.playerVo.team_lev )
end

function GuildFightEditView:open()

    self.id = self.params["id"]
    self.playerVo = GuildDataProxy:getInstance():getFightMyTeamVoById(self.id)

    if self.playerVo.guild_fight_islock == 1 then
        for k,btn in pairs(self.btnTbl) do
            btn:setBright(false)
            btn:setVisible(true)
            btn:setTouchEnabled(false)
        end
    else
        for k,btn in pairs(self.btnTbl) do
            btn:setBright(true)
            btn:setTouchEnabled(true)
            btn:setVisible(true)
        end
        local btn = self.btnTbl[self.playerVo.guild_fight_area]
        btn:setTouchEnabled(false)
        btn:setVisible(false)
    end

    local clazz = CharacterManager:getInstance():getGuildData():getPost()
    if clazz == ClazzType.Master then
        self.btnLock:setBright(true)
        self.btnLock:setTouchEnabled(true)
    else
        self.btnLock:setBright(false)
        self.btnLock:setTouchEnabled(false)
    end

    if self.playerVo.guild_fight_islock == 1 then
        self.btnLock:setTitleText("解鎖在當前區域")
    else
        self.btnLock:setTitleText("鎖定在當前區域")
    end

    self:update()
end

function GuildFightEditView:close()

end