--公会战 镜像 条目
GuildFightPlayerItem = class("GuildFightPlayerItem",function()
    return Layout:create()
end)
GuildFightPlayerItem.__index = GuildFightPlayerItem
GuildFightPlayerItem._widget     = nil
GuildFightPlayerItem.playerVo = nil

function GuildFightPlayerItem:create()
    local ret = GuildFightPlayerItem.new()
    ret:init()
    return ret
end

function GuildFightPlayerItem:init()
    require "GloryHeroIcon"

	self._widget = GuildDataProxy:getInstance():getWidgetFightEnemyItem():clone()
    self:setSize(CCSize(860,90))
    self:addChild(self._widget)

    self.panelEmpty = tolua.cast(self._widget:getChildByName("panel_empty"),"Layout")
    self.panelView = tolua.cast(self._widget:getChildByName("panel_view"),"Layout")

    self.panelEdit = tolua.cast(self.panelView:getChildByName("panel_edit"),"Layout")
    self.panelFight = tolua.cast(self.panelView:getChildByName("panel_fight"),"Layout")

    self.labName = tolua.cast(self.panelView:getChildByName("lab_name"),"Label")
    self.labLev = tolua.cast(self.panelView:getChildByName("lab_lev"),"Label")
    self.labFc = tolua.cast(self.panelView:getChildByName("lab_fc"),"Label")
    self.labStatus = tolua.cast(self.panelFight:getChildByName("lab_status"),"Label")
    self.imgLock = tolua.cast(self.panelEdit:getChildByName("img_lock"),"ImageView")
    self.labArea = tolua.cast(self.panelEmpty:getChildByName("lab_area"),"Label")

    self.btnSetting = tolua.cast(self.panelEdit:getChildByName("btn_setting"),"Button")
    self.btnSetting:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended and self.panelEdit:isVisible() == true then 

            local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()
            local isVis = sceneVo.showMorrorArea == GuildFightMorror.Perpare --处于备战界面
            if isVis then
                WindowCtrl:getInstance():open(CmdName.Guild_View_FightEdit,{ id = self.key })
            end
        end
    end)

    self.btnFight = tolua.cast(self.panelFight:getChildByName("btn_fight"),"Button")
    self.btnFight:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended and self.panelFight:isVisible() == true then 

            if TeamManager:getInstance():isDeadAllWithTeamType(TeamType.Guild_atk) == true then
                return Alert:show("您的戰隊已經全部陣亡，不能繼續挑戰")
            else
                local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()
                local isVis = sceneVo.showMorrorArea == GuildFightMorror.Combat --处于战斗界面
                if isVis then
                    local perc = 0
                    local curCheerVo = GuildDataProxy:getInstance():getCurCheerVo()
                    if self.playerVo.guild_fight_area == GuildFightArea.Defense then
                        perc = curCheerVo.hp_addition
                    elseif self.playerVo.guild_fight_area == GuildFightArea.Power then
                        perc = curCheerVo.act_addition 
                    end

                    WindowCtrl:getInstance():open(CmdName.Team_View,{
                        team_type = TeamType.Guild_atk,
                        notips = 1,
                        subId = 1,
                        id = BattleIDType.GUILD_FIGHT,
                        roleId = self.playerVo.role_id,
                        fightArea = self.playerVo.guild_fight_area,
                        cheerPerc = perc
                    })
                end
            end
        end
    end)
    
    self.hero_icons = {}
    for i=1,6 do
        local icon = GloryHeroIcon:create()
        icon:setScale(0.5)
        icon:setPosition(ccp(240 + (i-1) * 75,41))
        self.panelView:addChild(icon,1)
        table.insert(self.hero_icons,icon)
    end

    self.head_icon = HeadIcon:create()
    self.head_icon:setScale(0.75)
    self.head_icon:setPosition(ccp(64,43))
    self.panelView:addChild(self.head_icon,2)
end

function GuildFightPlayerItem:setData(vo)
    self.playerVo = vo
    self:update()
end

function GuildFightPlayerItem:update()
    --检测自身是否冷却中
    local function checkforceCold()

        if OrganizHelper.getCurFightRoleInfo() and OrganizHelper.getCurFightRoleInfo().guild_fight_combat_status == GuildFightCombatStatus.Cold then
            -- OrganizHelper.getCurFightRoleInfo().guild_fight_combat_status == GuildFightCombatStatus.Dead then
            self.btnFight:setVisible(false)
            self.btnFight:setTouchEnabled(false)
            self.labStatus:setVisible(true)
            self.labStatus:setText("冷卻中")
        end
    end

    local key = self.playerVo.role_id:getKeyIdx()
    self.key = key
    local role_uin = self.playerVo.role_id.uin
    if role_uin == 10000 or role_uin == 20000 or role_uin == 30000 then --占位空额
        self.panelEmpty:setVisible(true)
        self.panelEmpty:setZOrder(3)

        self.panelView:setVisible(false)
        self.panelView:setZOrder(0)

        self.labArea:setText(GuildFightAreaHolder[self.playerVo.guild_fight_area])
    else --正常玩家
        self.panelEmpty:setVisible(false)
        self.panelEmpty:setZOrder(0)

        self.panelView:setVisible(true)
        self.panelView:setZOrder(3)

        self.labName:setText(self.playerVo.role_name)
        self.labLev:setText("Lv."..self.playerVo.team_lev)
        self.labFc:setText(self.playerVo.fight_capacity)
        self.head_icon:setFaceId(self.playerVo.face_id, self.playerVo.sex)

        if self.playerVo.flag == GuildFightTeamStatus.MyTeam then
            --战斗中
            if GuildDataProxy:getInstance():getGuildFightSceneVo().curMoment == GuildFightMoment.BattleIng then
                self.panelEdit:setVisible(false)
                self.panelFight:setVisible(false)
                
            else --备战期间
                local clazz = CharacterManager:getInstance():getGuildData():getPost()
                if clazz == ClazzType.Master or 
                    clazz == ClazzType.Deputy then

                    if GuildDataProxy:getInstance():getGuildFightSceneVo().curMoment == GuildFightMoment.BattleBefore then
                        self.panelEdit:setVisible(false)
                        self.panelFight:setVisible(false)
                    else
                        self.panelEdit:setVisible(true)
                        self.panelEdit:setZOrder(3)
                        self.panelFight:setVisible(false)
                        self.panelFight:setZOrder(0)
                    end
                else
                    self.panelEdit:setVisible(false)
                    self.panelFight:setVisible(false)
                end

                self.imgLock:setVisible(self.playerVo.guild_fight_islock == 1)
            end


        elseif self.playerVo.flag == GuildFightTeamStatus.EnemyTeam then
            local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()
            local isVisCombat = sceneVo.showMorrorArea == GuildFightMorror.Combat --处于战斗界面

            self.panelEdit:setVisible(false)
            self.panelEdit:setZOrder(0)
            -- self.panelEdit:setPositionY(10)
            self.panelFight:setVisible(true and isVisCombat)
            self.panelFight:setZOrder(3)
            -- self.panelFight:setPositionY(10)

            self.btnFight:setVisible(false)
            self.btnFight:setTouchEnabled(false)
            self.labStatus:setVisible(true)

            if self.playerVo.guild_fight_combat_status == GuildFightCombatStatus.Normal then

                self.btnFight:setVisible(true)
                self.btnFight:setTouchEnabled(true)
                self.labStatus:setVisible(false)
                checkforceCold()

            elseif self.playerVo.guild_fight_combat_status == GuildFightCombatStatus.Fighting then

                self.labStatus:setText("戰鬥中")
                checkforceCold()
            elseif self.playerVo.guild_fight_combat_status == GuildFightCombatStatus.Dead then

                self.labStatus:setText("已剿滅")
            elseif self.playerVo.guild_fight_combat_status == GuildFightCombatStatus.Cold then

                self.labStatus:setText("冷卻中")
            end

            --隐藏  敌人 保护区
            if self.playerVo.guild_fight_area == GuildFightArea.Protect then
                self.head_icon:setDefaultFace()
                self.labFc:setText("????????")
                self.labName:setText("????????")
                self.labLev:setText("????????")
            end
        end
--------------------------------------------------------------------------------------------
        for i=1,#self.hero_icons do
            local icon = self.hero_icons[i]
            local hero_info = self.playerVo.heros[i]

            if hero_info ~= nil then
                icon:setVisible(true)
                icon:setOtherHeroInfo(hero_info,  self.playerVo.sex)

                if self.playerVo.flag == GuildFightTeamStatus.EnemyTeam then
                    icon:setHp( hero_info:getAttr(AttrHelper.attr_flag.hp_cur), 
                                hero_info:getAttr(AttrHelper.attr_flag.hp) )
                    icon:setHpVisible(true)
                    --隐藏  敌人 保护区
                    icon:setMystery( self.playerVo.guild_fight_area == GuildFightArea.Protect )

                elseif self.playerVo.flag == GuildFightTeamStatus.MyTeam then
                    --战斗中
                    if GuildDataProxy:getInstance():getGuildFightSceneVo().curMoment == GuildFightMoment.BattleIng then
                        icon:setHp( hero_info:getAttr(AttrHelper.attr_flag.hp_cur), 
                                hero_info:getAttr(AttrHelper.attr_flag.hp) )
                        icon:setHpVisible(true)
                    else
                        icon:setHp(1,1) --重置血量
                        icon:setHpVisible(false)
                    end
                end
            else
                icon:setHp(1,1) --重置血量
                icon:setHpVisible(false)
                icon:setOtherHeroInfo(nil)
            end
        end

    end
end

--------------------------------------------------------------------------
--公会战 敌人列表 区域标题
GuildFightAreaTitle = class("GuildFightAreaTitle",function()
	return Layout:create()
end)
GuildFightAreaTitle.__index = GuildFightAreaTitle
GuildFightAreaTitle._widget = nil
GuildFightAreaTitle.titleVo = nil

function GuildFightAreaTitle:create()
    local ret = GuildFightAreaTitle.new()
    ret:init()
    return ret
end

function GuildFightAreaTitle:init()
	self._widget = GuildDataProxy:getInstance():getWidgetFightAreaItem():clone()
    self:addChild(self._widget)
    self:setSize(CCSize(863,80))

    self.labAddition = LabelAtlas:create()
    self.labAddition:setPosition(ccp(751,28))
    self._widget:addChild(self.labAddition)

    self.imgTitle = tolua.cast(self._widget:getChildByName("img_title"),"ImageView")
    self.imgBg = tolua.cast(self._widget:getChildByName("img_bg"),"ImageView")
    self.imgAddBg = tolua.cast(self._widget:getChildByName("img_add_bg"),"ImageView")

end

function GuildFightAreaTitle:setData(vo)
    self.titleVo = vo
    self:update()
end

function GuildFightAreaTitle:update()
    self.imgAddBg:setVisible(true)
    self.labAddition:setVisible(true)

   if GuildFightArea.Protect == self.titleVo.t then
        self.imgBg:loadTexture("bg_light_5.png",UI_TEX_TYPE_PLIST)
        self.imgAddBg:setVisible(false)
        self.labAddition:setVisible(false)
    elseif GuildFightArea.Power == self.titleVo.t then
        self.imgBg:loadTexture("bg_light_4.png",UI_TEX_TYPE_PLIST)
        self.labAddition:setProperty(self.titleVo.addition,"ui/digit/guild_fight_atk_num.png",24,31,"0")
        -- self.labAddition:setText(string.format("攻擊+%d%%",self.titleVo.addition))
        self.imgAddBg:setVisible(true)
        self.imgAddBg:loadTexture("i18n_guild_fight_area_atk.png",UI_TEX_TYPE_PLIST)
    elseif GuildFightArea.Defense == self.titleVo.t then
        self.imgBg:loadTexture("bg_light_3.png",UI_TEX_TYPE_PLIST)
        -- self.labAddition:setText(string.format("生命+%d%%",self.titleVo.addition))
        self.labAddition:setProperty(self.titleVo.addition,"ui/digit/guild_fight_def_num.png",24,31,"0")
        self.imgAddBg:setVisible(true)
        self.imgAddBg:loadTexture("i18n_guild_fight_area_def.png",UI_TEX_TYPE_PLIST)
    elseif GuildFightArea.Common == self.titleVo.t then
        self.imgBg:loadTexture("bg_light_1.png",UI_TEX_TYPE_PLIST)
        self.imgAddBg:setVisible(false)
        self.labAddition:setVisible(false)
    end
    self.imgTitle:loadTexture(string.format("i18n_guild_fight_area%d.png",self.titleVo.t),UI_TEX_TYPE_PLIST)

end