-- 公会竞拍 面板
GuildAuctionPanel = class("GuildAuctionPanel",WindowBase)
GuildAuctionPanel.__index = GuildAuctionPanel
GuildAuctionPanel._widget     = nil
GuildAuctionPanel.uiLayer    = nil
GuildAuctionPanel.is_dispose = true

local __instance = nil

function GuildAuctionPanel:create()
    local ret = GuildAuctionPanel.new()
    __instance = ret
    return ret   
end

function GuildAuctionPanel:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_AUCTION_INFO)
end

function GuildAuctionPanel:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildAuctionPanel.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnCancel = tolua.cast(self._widget:getChildByName("btn_cancel"),"Button")
    self.btnCancel:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            local assetData = CharacterManager:getInstance():getAssetData()

            if string.len(self.inputCost:getText()) <= 0 then
                Alert:show("請輸入競價")
            elseif assetData:getDonate() < self.low_push then
                Alert:show("貢獻不足")
            elseif tonumber(self.inputCost:getText()) < self.low_push then
                Alert:show(string.format("競拍價不低於%d",self.low_push))
            else
                if self.type == 1 then
                    GuildNetTask:getInstance():requestPushAuction(self.auctionVo.id,tonumber(self.inputCost:getText()))
                else
                    GuildNetTask:getInstance():requestAppendAuction(self.auctionVo.id,tonumber(self.inputCost:getText()))
                end
            end
        end
    end)

    self.inputCost = CCEditBox:create(CCSize(170,30),CCScale9Sprite:create("ui/login/resource/img/img_empty.png"))
    self.inputCost:setPosition(ccp(538 ,213))
    self.inputCost:setMaxLength(12)
    self.inputCost:setPlaceHolder("請輸入數位")
    self.inputCost:setInputMode(kEditBoxInputModeNumeric)
    self.inputCost:setInputMode(kEditBoxInputModeSingleLine)
    self.inputCost:setFontSize(28) 
    self._widget:addNode(self.inputCost,5)

    self.labCostTitle = tolua.cast(self._widget:getChildByName("lab_cost_title"),"Label")
    self.labNum = tolua.cast(self._widget:getChildByName("lab_num"),"Label")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labPeople = tolua.cast(self._widget:getChildByName("lab_people"),"Label")
    self.labTime = tolua.cast(self._widget:getChildByName("lab_left"),"Label")
    self.labTips = tolua.cast(self._widget:getChildByName("lab_tips"),"Label")
    self.labDonate = tolua.cast(self._widget:getChildByName("lab_donate"),"Label")

    self.panelMyAuction = tolua.cast(self.uiLayer:getWidgetByName("panel_myauction"),"Layout")
    self.labMeAuction = tolua.cast(self.uiLayer:getWidgetByName("lab_me_auction"),"Label")

    require "ItemIcon"
    self.itemIcon = ItemIcon:create()
    self.itemIcon:setPosition(ccp(335,475))
    self._widget:addChild( self.itemIcon,5 )

    Notifier.regist(OrganizEvent.MSG_UPDATE_AUCTION_INFO,function() self:update() end)
end

function GuildAuctionPanel:extTouchPriority(value)
    self.inputCost:setTouchPriority(value)
end

function GuildAuctionPanel:open()

    self.auctionVo = self.params["auctionVo"]
    self.type = self.params["type"] or 1

    -- local dp = GuildDataProxy:getInstance()
    -- self.auctionData = dp:getAuctionDataVoById( self.auctionVo.base_id )
    -- self.low_bid = 250
    -- if self.auctionData ~= nil then
    --     self.low_bid = self.auctionData.low_bid
    -- end

    local assetData = CharacterManager:getInstance():getAssetData()
    self.labDonate:setText(assetData:getDonate())

    
    local itemMode = ItemManager:getInstance():getItemModelByBaseId(self.auctionVo.base_id)
    self.labName:setText(itemMode.name)
    self.labNum:setText("x"..self.auctionVo.num)

    self.itemIcon:setBaseId(self.auctionVo.base_id)
    self.itemIcon:setItemNum(1)

    if self.auctionVo.people < 3 then
        self.labPeople:setText("少於3人")
    else
        self.labPeople:setText(self.auctionVo.people .."人")
    end

    self:update()
end

function GuildAuctionPanel:update()
    local now = ServerTimerManager:getInstance():getCurTime()
    self.labTime:setText(Helper.sec2TimeStr(12 * 60 * 60 - (now - self.auctionVo.time)))

    if self.type == 1 then --出价
        self.labCostTitle:setText("出　　價：")
        self.panelMyAuction:setVisible(false)
        self.low_push = self.auctionVo.top_price + 1
        self.inputCost:setText(self.low_push)
        self.labTips:setText(string.format("該裝備目前的最低出價為：%d",self.auctionVo.top_price ))
    elseif self.type == 2 then --加价
        self.labMeAuction:setText(self.auctionVo.cost)
        self.labCostTitle:setText("加　　價：")
        self.panelMyAuction:setVisible(true)
        self.low_push = self.auctionVo.top_price - self.auctionVo.cost + 1
        self.inputCost:setText(self.low_push)
        self.labTips:setText(string.format("該裝備目前的最低加價為：%d",self.low_push))
    end
end

function GuildAuctionPanel:close()

end