-------------------------------------------------------------------------------
--被分配 人员 条目
GuildGloryAllotItem = class("GuildGloryAllotItem",function()
    return Layout:create()
end)
GuildGloryAllotItem.__index = GuildGloryAllotItem
GuildGloryAllotItem._widget     = nil
GuildGloryAllotItem.rankVo = nil

function GuildGloryAllotItem:create()
    local ret = GuildGloryAllotItem.new()
    ret:init()
    return ret
end

function GuildGloryAllotItem:init()

    self._widget = GuildDataProxy:getInstance():getWidgetMemberRankItem():clone()
    self:setSize(CCSize(840,82))
    self:addChild(self._widget)

    self.labRank = tolua.cast(self._widget:getChildByName("lab_rank"),"Label")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labScore = tolua.cast(self._widget:getChildByName("lab_score"),"Label")
    self.labScoreTotal = tolua.cast(self._widget:getChildByName("lab_score_total"),"Label")
    self.imgBg = tolua.cast(self._widget:getChildByName("img_bg"),"ImageView")

    self.btnCheck = tolua.cast(self._widget:getChildByName("btn_check"),"Button")
    self.btnCheck:setTitleText("分　配")
    self.btnCheck:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_ALLOT_CONFIRM,
                self.rankVo.role_id)
        end
    end)
end

function GuildGloryAllotItem:setData(vo)
    self.rankVo = vo
    self:update()
end

function GuildGloryAllotItem:update()
    self.labName:setText(self.rankVo.name)
    self.labScore:setText(self.rankVo.score)
    self.labScoreTotal:setText(self.rankVo.scoreTotal)
    if self.rankVo.rank == 1 then
        self.labRank:setText("榮耀冠軍")
    else
        self.labRank:setText(string.format("第%d名",self.rankVo.rank))
    end

    local isVis = self.rankVo.is_spoils == 0
    self.btnCheck:setBright(isVis)
    self.btnCheck:setTouchEnabled(isVis)

    local isVis = self.rankVo.rank % 2 == 1 
    self.imgBg:setVisible(isVis)
end
--------------------------------------------------------------------------------
--公会战 战利 分配给人员 面板
GuildFightGloryAllotPanel = class("GuildFightGloryAllotPanel",WindowBase)
GuildFightGloryAllotPanel.__index = GuildFightGloryAllotPanel
GuildFightGloryAllotPanel._widget = nil
GuildFightGloryAllotPanel.uiLayer = nil
GuildFightGloryAllotPanel.is_dispose = true

local __instance = nil

function GuildFightGloryAllotPanel:create()
    local ret = GuildFightGloryAllotPanel.new()
    __instance = ret
    return ret
end

function GuildFightGloryAllotPanel:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
    Notifier.removeByName(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_ALLOT_LIST)
end

function GuildFightGloryAllotPanel:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightGloryAllotPanel.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
 	self.btnClose:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
        	WindowCtrl:getInstance():close(self.name)
       	end
    end)

    self.scrolRank = DisplayUtil.createAdaptScrollView(840,400,0,0,1)
    self.scrolRank:setPosition(ccp(62,81))
    self._widget:addChild(self.scrolRank,2)

    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_ALLOT_LIST,function() 
        GuildRenderMgr:getInstance():renderGloryAllotRankAdapt(self.scrolRank)

        self.scrolRank:stopAllActions()
        self.scrolRank:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolRank:getInnerContainer():getPositionY()
                local viewRect = CCRectMake(0,math.abs(viewY),840,400)
                GuildRenderMgr:getInstance():refreshGloryAllotRankList(viewRect,self.scrolRank)
            end),
            CCDelayTime:create(0.1))))
    end)

    self._confirm_allot = function(role_id)
        GuildNetTask:getInstance():requestSendGloryGift(role_id,self.id)
    end
end

function GuildFightGloryAllotPanel:open()
    self.id = self.params["id"]

    Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_ALLOT_LIST)
    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_ALLOT_CONFIRM,self._confirm_allot)
end

function GuildFightGloryAllotPanel:close()

    Notifier.remove(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_ALLOT_CONFIRM,self._confirm_allot)
end