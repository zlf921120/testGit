
--修改成员 面板

EditMember = class("EditMember",WindowBase)
EditMember.__index = EditMember
EditMember._widget     = nil
EditMember.uiLayer    = nil

local __instance = nil
local _id = ""
local _clazz = 0

function EditMember:create()
    local ret = EditMember.new()
    __instance = ret
    return ret   
end

------------------响应事件--------------------------------------------------
local function event_btn_close(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
       __instance:addCloseAnim()
    end
end
--响应
local function event_cb_close()
    -- WindowCtrl:getInstance():close(CmdName.Guild_View_EditMember)
    __instance:addCloseAnim()
end

--让位
local function event_btn_left(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        -- if _clazz == ClazzType.Master then return end

        local txt = ""
        local curPlayerVo = OrganizHelper.getCurPlayerVo()
        if curPlayerVo.clazz == ClazzType.Master then
            txt = OrganizTips.LeftConfirm
        elseif curPlayerVo.clazz == ClazzType.Deputy then
            txt = OrganizTips.LeftConfirmDeputy
        end
        local params = {}
        params["txt"] = txt
        params["okFunc"] = function()
            GuildNetTask:getInstance():requestSetJob(_id)
        end
        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
    end
end
--剔除
local function event_btn_kick(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        if _clazz == ClazzType.Master then return end

        local params = {}
        params["txt"] = OrganizTips.KickConfirm
        params["okFunc"] = function()
            GuildNetTask:getInstance():requestKickMember(_id)
        end
        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
    end
end
--任命
local function event_btn_appoint(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        if _clazz == ClazzType.Master then return end

        local curPlayerVo = OrganizHelper.getCurPlayerVo()
        if curPlayerVo.clazz == ClazzType.Deputy then return end --副会长不能任命

        local txt = ""
        if _clazz == ClazzType.Common then
            txt = OrganizTips.AppointDeputyConfirm 
        elseif _clazz == ClazzType.Deputy then
            txt = OrganizTips.AppointCommonConfirm 
        end

        local params = {}
        params["txt"] = txt
        params["okFunc"] = function()
            GuildNetTask:getInstance():requestAppoint(_id)
        end
        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
    end
end
------------------初始化----------------------------------------------------
function EditMember:init()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/dialog/EditMember.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    local btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    btnClose:addTouchEventListener(event_btn_close)

    local btnLeft = tolua.cast(self.uiLayer:getWidgetByName("btn_left"),"Button")
    btnLeft:addTouchEventListener(event_btn_left)

    local btnOut = tolua.cast(self.uiLayer:getWidgetByName("btn_out"),"Button")
    btnOut:addTouchEventListener(event_btn_kick)

    local btnAppoint = tolua.cast(self.uiLayer:getWidgetByName("btn_appoint"),"Button")
    btnAppoint:addTouchEventListener(event_btn_appoint)
    
    self.labLev = tolua.cast(self.uiLayer:getWidgetByName("lab_level"),"Label")

    local p_icon = self._widget:getChildByName("p_icon")
    self.icon = HeadIcon:create()
    self.icon:setScale(0.9)
    self.icon:setPosition(ccp(p_icon:getPosition()))
    self.icon:setClickEvent(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            local playerVo = GuildDataProxy:getInstance():getPlayerVoById(_id)
            WindowCtrl:getInstance():open(CmdName.Comm_PlayerInfo,{vo = playerVo})
        end
    end)
    self._widget:addChild(self.icon)

    Notifier.regist(OrganizEvent.CB_CLOSE_EDIT_MEMBER,event_cb_close)
end

function EditMember:close()
    local btnAppoint = tolua.cast(self.uiLayer:getWidgetByName("btn_appoint"),"Button")
    btnAppoint:setVisible(true)
    btnAppoint:setTouchEnabled(true)
    local btnOut = tolua.cast(self.uiLayer:getWidgetByName("btn_out"),"Button")
    btnOut:setVisible(true)
    btnOut:setTouchEnabled(true)
    local btnLeft = tolua.cast(self.uiLayer:getWidgetByName("btn_left"),"Button")
    btnLeft:setVisible(true)
    btnLeft:setTouchEnabled(true)
end

function EditMember:open()

    local id = self.params["id"]
    local playerVo = GuildDataProxy:getInstance():getPlayerVoById(id)
    _id = id
    _clazz = playerVo.clazz
	
	self.icon:setFaceId(playerVo.faceId,playerVo.sex)

    local labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    labName:setText(playerVo.name)
    local labClazz = tolua.cast(self._widget:getChildByName("lab_clazz"),"Label")
    labClazz:setText(ClazzTypeName[playerVo.clazz + 1])

    local btnAppoint = tolua.cast(self.uiLayer:getWidgetByName("btn_appoint"),"Button")
    if playerVo.clazz ==  ClazzType.Deputy then
        btnAppoint:setTitleText("撤職")
    else
        btnAppoint:setTitleText("任命")
    end

    local curPlayerVo = OrganizHelper.getCurPlayerVo()
    if curPlayerVo.clazz == ClazzType.Deputy then
        btnAppoint:setVisible(false)  --副会长不能任命
        btnAppoint:setTouchEnabled(false)
    end

    if _clazz == ClazzType.Master or _clazz == ClazzType.Deputy then
         local btnOut = tolua.cast(self.uiLayer:getWidgetByName("btn_out"),"Button")
         btnOut:setVisible(false) --会长不能踢
         btnOut:setTouchEnabled(false)
         local btnLeft = tolua.cast(self.uiLayer:getWidgetByName("btn_left"),"Button")
         btnLeft:setVisible(false) --会长不能踢
         btnLeft:setTouchEnabled(false)
    end

    self.labLev:setText(playerVo.level)

    self:addOpenAnim()
end