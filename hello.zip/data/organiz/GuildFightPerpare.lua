-----------------------------------------------------------------------
-- 公会战 备战 场景
GuildFightPerpare = class("GuildFightPerpare",WindowBase)
GuildFightPerpare.__index = GuildFightPerpare
GuildFightPerpare._widget = nil
GuildFightPerpare.uiLayer = nil
GuildFightPerpare.viewType = 1

local __instance = nil

function GuildFightPerpare:create()
    local ret = GuildFightPerpare.new()
    __instance = ret
    return ret
end

function GuildFightPerpare:init()
    ComResMgr:getInstance():loadOtherRes()
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/organiz/member/guild.plist")
    require "GloryHeroIcon"

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/fight/GuildFightSettingPlayer.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.scrolPlayer = DisplayUtil.createAdaptScrollView(880,430,0,0,1)
 	self.scrolPlayer:setPosition(ccp(42,133))
    self._widget:addChild(self.scrolPlayer,5)
    GuildRenderMgr:getInstance():initFightEnemyScrol(self.scrolPlayer)

    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_MYTEAM_LIST,function() 

        GuildRenderMgr:getInstance():renderFightPlayerListAdapt(self.scrolPlayer)
        self.lastPlayerY1 = -1
        self.scrolPlayer:stopAllActions()
        self.scrolPlayer:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolPlayer:getInnerContainer():getPositionY()
                if self.lastPlayerY1 ~= viewY then
                    self.lastPlayerY1 = viewY
                    local viewRect = CCRectMake(0,math.abs(viewY),880,430)

                    GuildRenderMgr:getInstance():refreshFightPlayerVoList(viewRect,self.scrolPlayer)
                end
            end),
            CCDelayTime:create(0.1))))

        self:update() 
    end)

    Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_ENEMY_PERPARE_LIST,function() 
        GuildRenderMgr:getInstance():renderFightEnemyListAdapt(self.scrolPlayer)
        self.lastPlayerY2 = -1
        self.scrolPlayer:stopAllActions()
        self.scrolPlayer:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolPlayer:getInnerContainer():getPositionY()
                if self.lastPlayerY2 ~= viewY then
                    self.lastPlayerY2 = viewY
                    local viewRect = CCRectMake(0,math.abs(viewY),880,430)
                    GuildRenderMgr:getInstance():refreshFightEnemyList(viewRect,self.scrolPlayer)
                end
            end),
            CCDelayTime:create(0.1))))

        self:update() 
    end)

    self.labFc = tolua.cast(self.uiLayer:getWidgetByName("lab_my_fc"),"Label")

    self.btnTeam = tolua.cast(self.uiLayer:getWidgetByName("btn_team"),"Button")
    self.btnTeam:addTouchEventListener(function(sender, eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            self.scrolPlayer:stopAllActions()
            WindowCtrl:getInstance():open(CmdName.Team_View,
                {team_type = TeamType.Guild_def,showGuildFightTips = 1})
        end
    end)

    self.btnDesc = tolua.cast(self.uiLayer:getWidgetByName("btn_desc"),"Button")
    self.btnDesc:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Comm_DescPanel,
                {title="公會戰",content=OrganizCfg.GuildFightInfo,
                rewardArr = {{img="gold.png",lab="金幣"},
                            {img="reward_enchan.png",lab="附魔書"},
                            {img="reward_hero_exp.png",lab="經驗藥"},
                            {img="reward_pet.png",lab="侍寵進階精華"}}})
        end
    end)

    self.imgBg = ImageView:create()
    self.imgBg:setPosition(ccp(480,320))
    self._widget:addChild(self.imgBg)

    self.imgTitle = tolua.cast(self.uiLayer:getWidgetByName("img_title"),"ImageView")
    self.panelTeam = tolua.cast(self.uiLayer:getWidgetByName("panel_team"),"Layout")
    self.panelTeam:setVisible(false)

    self.hero_icons = {}
    for i=1,6 do
        local icon = GloryHeroIcon:create()
        icon:setScale(0.65)
        icon:setPosition(ccp(165 + (i-1) * 94,68))
        self.panelTeam:addChild(icon,5)
        table.insert(self.hero_icons,icon)
    end

    self._update = function()
         GuildNetTask:getInstance():requestGuildFightMyTeamList() 
    end
end

function GuildFightPerpare:update()

    if self.viewType == GuildFightTeamStatus.MyTeam then

        GuildRenderMgr:getInstance():renderFightPlayerListAdapt(self.scrolPlayer)
        local playerVo = OrganizHelper.getCurFightRoleInfo()
        for i=1,#self.hero_icons do
            local icon = self.hero_icons[i]
            local hero_info = playerVo.heros[i]

            if hero_info ~= nil then
                icon:setVisible(true)
                icon:setOtherHeroInfo(hero_info)
            else
                icon:setOtherHeroInfo(nil)
            end
        end

        self.labFc:setText(playerVo.fight_capacity)
        self.imgTitle:loadTexture("i18n_guild_fight_perpare.png",UI_TEX_TYPE_PLIST)

        --取消绿点
        GuildDataProxy:getInstance().short_fight_news = 0
        Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.mainui_guild_fight)

    elseif self.viewType == GuildFightTeamStatus.MyTeam_Fight then

        GuildRenderMgr:getInstance():renderFightPlayerListAdapt(self.scrolPlayer)

        self.imgTitle:loadTexture("i18n_guild_fight_my_team.png",UI_TEX_TYPE_PLIST)

    elseif self.viewType == GuildFightTeamStatus.EnemyTeam then

        GuildRenderMgr:getInstance():renderFightEnemyListAdapt(self.scrolPlayer)

        self.imgTitle:loadTexture("i18n_guild_fight_enemy_perpare.png",UI_TEX_TYPE_PLIST)
    end
end

function GuildFightPerpare:open()

    GuildDataProxy:getInstance():reloadWidget(GuildFightWidget.FightPlayer)
    self.imgBg:loadTexture("ui/organiz/member/fight/guild_fight_bg.jpg")
    self.imgBg:setScaleX(1/DisplayUtil.min_scale*DisplayUtil.max_scale)
    self.imgBg:setScaleY(1/DisplayUtil.min_scale*DisplayUtil.max_scale)

    if self.params == nil then --我方备战设置

        self.viewType = GuildFightTeamStatus.MyTeam

        GuildNetTask:getInstance():requestGuildFightMyTeamList()
        Notifier.regist(CmdName.Team_View_Close,self._update)

        self.panelTeam:setPositionY(0)
        self.panelTeam:setVisible(true)

    elseif self.params and self.params["myteam"] == 1 then

        self.viewType = GuildFightTeamStatus.MyTeam 
        GuildNetTask:getInstance():requestGuildFightMyTeamList()

        self.panelTeam:setPositionY(-1000)
        self.panelTeam:setVisible(false)

    elseif self.params and self.params["myteam_fight"] == 1 then

        self.viewType = GuildFightTeamStatus.MyTeam_Fight 
        GuildNetTask:getInstance():requestGuildFightMyTeamList()

        self.panelTeam:setPositionY(-1000)
        self.panelTeam:setVisible(false)

    elseif self.params and self.params["enemy"] == 1 then

        self.viewType = GuildFightTeamStatus.EnemyTeam 
        GuildNetTask:getInstance():requestGuildFightEnemyPerpare()

        self.panelTeam:setPositionY(-1000)
        self.panelTeam:setVisible(false)
    end
----------------------------------------------------------------------
    local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()
    sceneVo.showMorrorArea = GuildFightMorror.Perpare
end

function GuildFightPerpare:returnFun()
    WindowCtrl:getInstance():close(self.name)
    WindowCtrl:getInstance():open(CmdName.Guild_View_FightScene,{norefresh = 1})
end

function GuildFightPerpare:close()
    Notifier.remove(CmdName.Team_View_Close,self._update)
    CCTextureCache:sharedTextureCache():removeTextureForKey("ui/organiz/member/fight/guild_fight_bg.jpg")
end