--备战成功 提示
GuildPerpareFinish = class("GuildPerpareFinish",WindowBase)
GuildPerpareFinish.__index = GuildPerpareFinish
GuildPerpareFinish._widget     = nil
GuildPerpareFinish.uiLayer    = nil
GuildPerpareFinish.is_dispose = true

function GuildPerpareFinish:create()
    local ret = GuildPerpareFinish.new()
    ret:init()
    return ret
end

function GuildPerpareFinish:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
end

function GuildPerpareFinish:init()
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildPerpareFinish.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then 
	       WindowCtrl:getInstance():close(self.name)
	    end
	end)

	self.btnOk = tolua.cast(self.uiLayer:getWidgetByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then 
	       WindowCtrl:getInstance():close(self.name)
	    end
	end)
end

function GuildPerpareFinish:open()

end

function GuildPerpareFinish:close()

end