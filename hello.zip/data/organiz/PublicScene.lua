
--公会 公开场景

PublicScene = class("PublicScene",WindowBase)
PublicScene.__index = PublicScene
PublicScene._widget = nil
PublicScene.uiLayer = nil

local __instance = nil

local _logoId = 1

function PublicScene:create()
    local ret = PublicScene.new()
    __instance = ret
    return ret
end

---------------响应事件--------------------------------------------------
local btnLast = nil
local panelLast = nil

local panelJoin = nil
local listOrganziShow = nil

local panelFind = nil
local listOrganizFind = nil
local inputFind = nil   --查找 输入框

local panelCreate = nil
local panelLogo = nil 
local inputCreate = nil --创建 输入框
local imgLogo = nil --公会图标

local function event_btnoption_join(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then

        panelJoin:setVisible(true)
        panelJoin:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if btnLast ~= btn then
            btnLast:setFocused(false)
            btnLast:setTitleColor(ccc3(245,204,85))
            btnLast = btn
            
            panelLast:setVisible(false)
            panelLast:setZOrder(3)
            panelLast = panelJoin


        end
    end
end

local function event_btnoption_create(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then

        panelCreate:setVisible(true)
        panelCreate:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if btnLast ~= btn then
            btnLast:setFocused(false)
            btnLast:setTitleColor(ccc3(245,204,85))
            btnLast = btn
            

            panelLast:setVisible(false)
            panelLast:setZOrder(3)
            panelLast = panelCreate

        end
    end
end


local function event_btnoption_find(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then

        panelFind:setVisible(true)
        panelFind:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if btnLast ~= btn then
            btnLast:setFocused(false)
            btnLast:setTitleColor(ccc3(245,204,85))
            btnLast = btn

            panelLast:setVisible(false)
            panelLast:setZOrder(3)
            panelLast = panelFind
        end
    end
end
---------------------加入公会---面板----------------------------------
-- local function event_render_organiz_item(pSender,eventType)
--     --开始渲染
--     GuildRenderMgr:getInstance():renderOrganizList(listOrganziShow)
-- end

---------------------创建公会---面板---------------------------------
local function event_btn_editlogo(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        WindowCtrl:getInstance():open(CmdName.Guild_View_LogoPanel_create)
    end
end

local function event_btn_create(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        local logoData = CharacterManager:getInstance():getLoginData()

        local name = inputCreate:getStringValue() --限制公会名字
        if Helper.lenEnCn(name) > 12 then
            return  Alert:show("公會名稱超過了限制")
        elseif string.len(name) == 0 then
            return  Alert:show("公會名稱不能為空")
        elseif Helper.hasSensitiveWord(name) then
            return Alert:show("名字含有非法字元")
        end

        local desc = GuildDefalutDesc[ math.random(1,#GuildDefalutDesc) ]
        local acc_id = logoData:getAcctId()
        local channel_id = logoData:getChannelId()
        local zone_id = logoData:getZoneId()
        local logoId = _logoId

        GuildNetTask:getInstance():requestCreateOrganiz(name,desc,acc_id,channel_id,zone_id,logoId)
    end
end

local function event_render_logo(id)
    imgLogo:setId(id)
    _logoId = id
end
---------------------查找公会---面板---------------------------------
local function event_btn_find(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        GuildNetTask:getInstance():requestFindOrganiz(inputFind:getStringValue())
    end
end

local function event_render_findorganiz()
    GuildRenderMgr.renderFindList(listOrganizFind)
end
---------------初始化-----------------------------------------------------
function PublicScene:init()
    require "GuildDataProxy"
    require "OrganizEvent"
    require "GuildNetTask"
    require "GuildRenderMgr"
    require "LogoPanel"
    require "CharacterManager"
    require "GuildIcon"

    GuildLocalReader:getInstance():loadInProxy()
    GuildRenderMgr:getInstance()

    ItemManager:getInstance():loadItemIconPlist()
    HeroManager:getInstance():loadSkillIconPlist()
    --加载纹理
    ComResMgr:getInstance():loadOtherRes()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/public/PublicScene.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

    local btnJoinOption = tolua.cast(self.uiLayer:getWidgetByName("btn_join"),"Button")
    btnLast = btnJoinOption
    btnJoinOption:setFocused(true)
    btnJoinOption:setTitleColor(ccc3(210,253,238))
    btnJoinOption:addTouchEventListener(event_btnoption_join)

    local btnCreateOption = tolua.cast(self.uiLayer:getWidgetByName("btn_create"),"Button")
    btnCreateOption:addTouchEventListener(event_btnoption_create)

    local btnFindOption = tolua.cast(self.uiLayer:getWidgetByName("btn_find"),"Button")
    btnFindOption:addTouchEventListener(event_btnoption_find)

    panelJoin = tolua.cast(self.uiLayer:getWidgetByName("panel_join"),"Layout")
    panelLast = panelJoin
    panelCreate = tolua.cast(self.uiLayer:getWidgetByName("panel_create"),"Layout")
    panelFind = tolua.cast(self.uiLayer:getWidgetByName("panel_find"),"Layout")

    self.labTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips"),"Label")
    ---------------加入公会面板 控件---------------------------------------------------
    -- listOrganziShow = tolua.cast(panelJoin:getChildByName("list_item"),"ListView")
    self.scrollGuild = DisplayUtil.createAdaptScrollView(820,410,140,0,1)
    panelJoin:addChild(self.scrollGuild,10)

    ---------------创建公会面板 控件---------------------------------------------------
    local p_icon = panelCreate:getChildByName("p_icon")
    imgLogo = GuildIcon:create()
    imgLogo:setId(1) --默认图标
    imgLogo:setPosition(ccp(p_icon:getPosition()))
    panelCreate:addChild(imgLogo)

    inputCreate = tolua.cast(panelCreate:getChildByName("input_name"),"TextField")

    local btnEdit = tolua.cast(panelCreate:getChildByName("btn_edit"),"Button")
    btnEdit:addTouchEventListener(event_btn_editlogo)

    self.btnCreate = tolua.cast(panelCreate:getChildByName("btn_create"),"Button")
    self.btnCreate:addTouchEventListener(event_btn_create)
    self.labCost = tolua.cast(panelCreate:getChildByName("lab_cost"),"Label")
    self.labForbid = tolua.cast(panelCreate:getChildByName("lab_forbid"),"Label")

    ---------------查找公会面板 控件---------------------------------------------------
    listOrganizFind = tolua.cast(panelFind:getChildByName("list_item"),"ListView")

    inputFind = tolua.cast(panelFind:getChildByName("input_name"),"TextField")

    local btnFind = tolua.cast(panelFind:getChildByName("btn_find"),"Button")
    btnFind:addTouchEventListener(event_btn_find)

    -- 注册事件
    -------------加入公会面板 事件---------
    Notifier.regist(OrganizEvent.GET_ORGANIZ_ITEM_SUCCESS,function()
        GuildRenderMgr:getInstance():renderOrganizListAdapt(self.scrollGuild)

        self.lastScorlGuildY = -1
        self.scrollGuild:stopAllActions()
        self.scrollGuild:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrollGuild:getInnerContainer():getPositionY()
                if self.lastScorlGuildY ~= viewY then
                    self.lastScorlGuildY = viewY
                    local viewRect = CCRectMake(0,math.abs(viewY),820,410)
                    GuildRenderMgr:getInstance():refresGuildVoList(viewRect,self.scrollGuild)
                end
            end),
            CCDelayTime:create(0.1))))

        self.labTips:setVisible( Utils.get_length_from_any_table(GuildDataProxy:getInstance():getGuildVoList()) <= 0 )
    end)  --渲染公会列表
    -------------创建公会面板 事件---------
    Notifier.regist(OrganizEvent.MSG_CHOICE_LOGO,event_render_logo) --更新图标
    -------------查找公会面板 事件---------
    Notifier.regist(OrganizEvent.MSG_FIND_ORGANIZ,event_render_findorganiz) --查找公会

    Notifier.regist(CmdName.CHARACTER_RSP_UPDATE_TEAM,function() self:update() end) 

    self:update()
end

function PublicScene:update()

    local isVisibleCreateBtn = CharacterManager:getInstance():getTeamData():getLev() >= 20
    self.btnCreate:setTouchEnabled(isVisibleCreateBtn)
    self.btnCreate:setVisible(isVisibleCreateBtn)
    self.labForbid:setVisible(not isVisibleCreateBtn)

    if CharacterManager:getInstance():getAssetData():getDiamond() < 100 then --钻石
        self.labCost:setColor(ItemHelper.colors.red)
    else
        self.labCost:setColor(ItemHelper.colors.yellow)
    end
end

function PublicScene:open()    
     --请求 帮会数据 
    GuildNetTask:getInstance():requestOrganizItems()
end

function PublicScene:close()

    local btnJoinOption = tolua.cast(self.uiLayer:getWidgetByName("btn_join"),"Button")
    event_btnoption_join(btnJoinOption,ComConstTab.TouchEventType.ended)
---------------------------------------------
--清理-------
    listOrganizFind:removeAllItems() 
    local dp = GuildDataProxy:getInstance()
    local rm = GuildRenderMgr:getInstance()
    local voList = dp:getGuildVoList()
    for id,v in pairs(voList) do
        rm.dic:removeObjectForKey(string.format("guilditem_%d",id))
    end
    dp:clearGuildVoList()

    local voList = dp:getFindGuildVoList()
    for id,v in pairs(voList) do
        rm.dic:removeObjectForKey(string.format("finditem_%d",id))
    end
    dp:clearFindGuildVoList()
end
