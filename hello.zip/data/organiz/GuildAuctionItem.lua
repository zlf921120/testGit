--------------------------------------------------------------
-- 公会 竞拍 条目
GuildAuctionItem = class("GuildAuctionItem",function()
    return Layout:create()
end)
GuildAuctionItem.__index = GuildAuctionItem
GuildAuctionItem._widget 	= nil
GuildAuctionItem.auctionVo = nil

function GuildAuctionItem:create()
    local ret = GuildAuctionItem.new()
    ret:init()
    return ret
end

function GuildAuctionItem:setData(vo)
    self.auctionVo = vo
    self:update()
end

function GuildAuctionItem:init()

	self._widget = GuildDataProxy:getInstance():getWidgetAuctionItem():clone()
    self:setSize(CCSize(850,140))
    self:addChild(self._widget)

    self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            if self.auctionVo.status == AuctionStatus.HadBeen then
                Alert:show("你已出價過了")
            else
                WindowCtrl:getInstance():open(CmdName.Guild_View_AuctionPanel,
                    {auctionVo = self.auctionVo,type = 1})
            end
        end
    end)

    self.panelStatus = tolua.cast(self._widget:getChildByName("panel_status"),"Layout")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labNum = tolua.cast(self._widget:getChildByName("lab_num"),"Label")
    self.labProd = tolua.cast(self._widget:getChildByName("lab_production"),"Label")
    self.labTime = tolua.cast(self.panelStatus:getChildByName("lab_time"),"Label")
    self.labPeople = tolua.cast(self.panelStatus:getChildByName("lab_people"),"Label")
    self.labTips = tolua.cast(self._widget:getChildByName("lab_tips"),"Label")
    self.imgBg = tolua.cast(self._widget:getChildByName("img_bg"),"ImageView")

    require "ItemIcon"
    require "ItemInfoPanel"
    self.itemIcon = ItemIcon:create()
    self.itemIcon:setPosition(ccp(75,70))
    self.itemIcon:setTouchEvent(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.began then

                ItemInfoPanel:show(pSender:getTag())

        elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then

            ItemInfoPanel:hide()
        end
    end)
    self._widget:addChild( self.itemIcon,5 )
end

function GuildAuctionItem:update()
    self.itemIcon:setBaseId(self.auctionVo.base_id)
    self.itemIcon:getClickImg():setTag(self.auctionVo.base_id)
    self.itemIcon:setItemNum(1)

    local now = ServerTimerManager:getInstance():getCurTime()
	self.labTime:setText(Helper.sec2TimeStr(12 * 60 * 60 - (now - self.auctionVo.time)))

    local monstorMode = MonsterManager:getInstance():getBaseInfo(self.auctionVo.boss_id)
    if monstorMode == nil then return end
    local itemMode = ItemManager:getInstance():getItemModelByBaseId(self.auctionVo.base_id)
    self.labName:setText(itemMode.name)
    self.labProd:setText(monstorMode.name) 
    self.labNum:setText("x".. self.auctionVo.num)

    if self.auctionVo.people < 3 then
        self.labPeople:setText("少於3人")
    else
        self.labPeople:setText(self.auctionVo.people .."人")
    end

    if self.auctionVo.status == AuctionStatus.Normal then
        self.panelStatus:setVisible(true)
        self.labTips:setVisible(false)
        self.btnOk:setVisible(true)
        self.btnOk:setTouchEnabled(true)
        self.imgBg:loadTexture("btn_down_7.png",UI_TEX_TYPE_PLIST)
        self.btnOk:setTitleText("競拍")

    elseif self.auctionVo.status == AuctionStatus.HadBeen then

        self.panelStatus:setVisible(true)
        self.labTips:setVisible(false)
        self.btnOk:setTitleText("已競拍")
        self.imgBg:loadTexture("btn_up_7.png",UI_TEX_TYPE_PLIST)
    elseif self.auctionVo.status == AuctionStatus.Forbid then

        self.panelStatus:setVisible(false)
        self.labTips:setVisible(true)
        self.btnOk:setVisible(false)
        self.btnOk:setTouchEnabled(false)
        self.imgBg:loadTexture("btn_up_7.png",UI_TEX_TYPE_PLIST)
    end 
end
---------------------------------------------------------------
-- 公会 我的竞拍 条目
GuildMyAuctionItem = class("GuildMyAuctionItem",function()
    return Layout:create()
end)
GuildMyAuctionItem.__index = GuildMyAuctionItem
GuildMyAuctionItem._widget    = nil
GuildMyAuctionItem.auctionVo = nil

function GuildMyAuctionItem:create()
    local ret = GuildMyAuctionItem.new()
    ret:init()
    return ret
end

function GuildMyAuctionItem:setData(vo)
    self.auctionVo = vo
    self:update()
end

function GuildMyAuctionItem:init()

    self._widget = GuildDataProxy:getInstance():getWidgetMyAuctionItem():clone()
    self:setSize(CCSize(850,140))
    self:addChild(self._widget)

    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labNum = tolua.cast(self._widget:getChildByName("lab_num"),"Label")
    self.labProd = tolua.cast(self._widget:getChildByName("lab_production"),"Label")
    self.labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")
    self.labPeople = tolua.cast(self._widget:getChildByName("lab_people"),"Label")
    self.panelView = tolua.cast(self._widget:getChildByName("panel_view"),"Layout")
    self.labMine = tolua.cast(self._widget:getChildByName("lab_mine"),"Label")
    self.labMax = tolua.cast(self.panelView:getChildByName("lab_max"),"Label")

    self.btnOk = tolua.cast(self.panelView:getChildByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended and self.panelView:isVisible() then

            WindowCtrl:getInstance():open(CmdName.Guild_View_AuctionPanel,
                {auctionVo = self.auctionVo,type = 2})
        end
    end)

    require "ItemIcon"
    require "ItemInfoPanel"
    self.itemIcon = ItemIcon:create()
    self.itemIcon:setPosition(ccp(75,70))
    self.itemIcon:setTouchEvent(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.began then

                ItemInfoPanel:show(pSender:getTag())

        elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then

            ItemInfoPanel:hide()
        end
    end)
    self._widget:addChild( self.itemIcon,5 )
end

function GuildMyAuctionItem:update()

    self.itemIcon:setBaseId(self.auctionVo.base_id)
    self.itemIcon:getClickImg():setTag(self.auctionVo.base_id)
    self.itemIcon:setItemNum(1)

    local now = ServerTimerManager:getInstance():getCurTime()
    self.labTime:setText(Helper.sec2TimeStr(12 * 60 * 60 - (now - self.auctionVo.time)))

    local monstorMode = MonsterManager:getInstance():getBaseInfo(self.auctionVo.boss_id)
    if monstorMode == nil then return end
    local itemMode = ItemManager:getInstance():getItemModelByBaseId(self.auctionVo.base_id)
    self.labName:setText(itemMode.name)
    self.labProd:setText(monstorMode.name) 
    self.labNum:setText("x".. self.auctionVo.num)

    if self.auctionVo.people < 3 then
        self.labPeople:setText("少於3人")
    else
        self.labPeople:setText(self.auctionVo.people .."人")
    end

    self.labMine:setText(self.auctionVo.cost)
    local isVis = self.auctionVo.cost < self.auctionVo.top_price
    self.panelView:setVisible(isVis)
    if isVis then
        self.labMine:setColor(ItemHelper.colors.red)
        self.labMax:setText(self.auctionVo.top_price)
    else
        self.labMine:setColor(ItemHelper.colors.yellow)
    end
end