-- 公会技能 面板
GuildSkillScene = class("GuildSkillScene",WindowBase)
GuildSkillScene.__index = GuildSkillScene
GuildSkillScene._widget     = nil
GuildSkillScene.uiLayer    = nil
-- GuildSkillScene.is_dispose = true

local __instance = nil
local _choiceId = 50000 --写死第一个

-- function GuildSkillScene:dispose()
--     if self._widget then
--         self._widget:removeFromParentAndCleanup(true)
--     end
--     Notifier.removeByName(OrganizEvent.MSG_UPDATE_SKILL_SCENE)
-- end

function GuildSkillScene:create()
    local ret = GuildSkillScene.new()
    __instance = ret
    return ret   
end

local function event_btn_levup_me(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        if __instance.me_donate_cost > CharacterManager:getInstance():getAssetData():getDonate() then
            Alert:show("個人貢獻不足")
        else
            GuildNetTask:getInstance():requestLevupMeSkill(_choiceId)
        end
   	end
end

local function event_btn_levup_guild(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        WindowCtrl:getInstance():open(CmdName.Guild_View_Skill_Guild,{skill_id = _choiceId})
    end
end

local function event_choice_skill(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        if _choiceId == pSender:getTag() then return end
        -- print(" 選中技能id ",pSender:getTag())
        _choiceId = pSender:getTag()
        
        __instance:update()
    end
end

function GuildSkillScene:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("organiz/member/dialog/GuildSkillScene.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.scrollView = tolua.cast(self.uiLayer:getWidgetByName("scrol_view"),"ScrollView")
    self.btnLearn = tolua.cast(self.uiLayer:getWidgetByName("btn_learn"),"Button")
    self.btnLearn:addTouchEventListener(event_btn_levup_me)

    self.btnGuild = tolua.cast(self.uiLayer:getWidgetByName("btn_setting"),"Button")
    self.btnGuild:addTouchEventListener(event_btn_levup_guild)

    self.panelLearn = tolua.cast(self.uiLayer:getWidgetByName("panel_learn"),"Layout")
    self.panelSkill = tolua.cast(self.uiLayer:getWidgetByName("panel_skill"),"Layout")
    self.labName = tolua.cast(self.uiLayer:getWidgetByName("lab_name"),"Label")
    self.labLev = tolua.cast(self.uiLayer:getWidgetByName("lab_skill_lev"),"Label")
    self.labTiplev = tolua.cast(self.uiLayer:getWidgetByName("lab_levtip"),"Label")
    self.labNowDesc = tolua.cast(self.uiLayer:getWidgetByName("lab_nowskill"),"Label")
    self.labNextDesc = tolua.cast(self.uiLayer:getWidgetByName("lab_nextskill"),"Label")
    self.labDonate = tolua.cast(self.uiLayer:getWidgetByName("lab_donate"),"Label")
    self.labCost = tolua.cast(self.uiLayer:getWidgetByName("lab_cost"),"Label")
    self.p_1 = self._widget:getChildByName("p_1")
    self.p_2 = self._widget:getChildByName("p_2")
    self.labForbid = tolua.cast(self.uiLayer:getWidgetByName("lab_forbid"),"Label")

    self.iconNow = GuildSkillIcon:create()
    self.iconNow:setPosition(ccp(self.p_1:getPosition()))
    self._widget:addChild( self.iconNow,5 )

    self.iconNext = GuildSkillIcon:create()
    self.iconNext:setPosition(ccp(self.p_2:getPosition()))
    self._widget:addChild( self.iconNext,5)

    Notifier.regist(OrganizEvent.MSG_UPDATE_SKILL_SCENE,function() 
        self:update() 
        --刷新技能条目
        GuildRenderMgr:getInstance():renderSkillList(self.scrollView,event_choice_skill)
    end)

    Notifier.regist(OrganizEvent.MSG_UPDATE_NEW_TIPS_SKILL_SHOW,function(id) self:showNewsTip(id) end)
    Notifier.regist(OrganizEvent.MSG_UPDATE_NEW_TIPS_SKILL_HIDE,function(id) self:hideNewsTip(id) end)
end

function GuildSkillScene:open()

    local playerVo = OrganizHelper.getCurPlayerVo()
    self.btnGuild:setVisible( OrganizHelper.isMaster(playerVo) ) 
    self.btnGuild:setTouchEnabled( OrganizHelper.isMaster(playerVo) )

    self:update()

    --刷新技能条目
    GuildRenderMgr:getInstance():renderSkillList(self.scrollView,event_choice_skill)
end

function GuildSkillScene:update()
    local dp = GuildDataProxy:getInstance()
    local skillMeVo = dp:getMeSkillVoById(_choiceId)
    local skillGuildVo = dp:getGuildSkillVoById(_choiceId)

    self.p_2:setVisible(false)
    self.labForbid:setVisible(false)
    self.iconNext:setVisible(true)
    self.panelSkill:setVisible(true)
    self.panelLearn:setVisible(true)
    self.labTiplev:setVisible(false)
    self.btnLearn:setTouchEnabled(true)
    self.iconNext:setVisible(true)

    self.me_donate_cost = 0

    if skillMeVo ~= nil then --学过

        local skillDescVo = dp:getSkillDescVoById(skillMeVo.id,skillMeVo.lev)
        local skillNextVo = dp:getSkillDescVoById(skillMeVo.id,skillMeVo.lev + 1)

        --print("  skillMeVo.id,skillMeVo.lev ",skillMeVo.id,skillMeVo.lev,skillDescVo)
        self.labName:setText(skillDescVo.name)
        self.labNowDesc:setText(skillDescVo.desc)

        if skillGuildVo ~= nil then
            self.labLev:setText(skillGuildVo.lev)

            if skillNextVo ~= nil then
	            self.labLev:setText(skillGuildVo.lev)
	            
	            self.labNextDesc:setText(skillNextVo.desc)
	            self.labCost:setText( string.format("消耗%d貢獻點",skillNextVo.me_donate_cost) )
	            self.me_donate_cost = skillNextVo.me_donate_cost

	            self.iconNow:setId(_choiceId)
	            self.iconNow:setLev(skillMeVo.lev)

	            if skillGuildVo.lev > skillMeVo.lev then --公会技能比我高 
	                self.iconNext:setId(_choiceId)
	                self.iconNext:setLev(skillMeVo.lev + 1)
	                self.labLev:setColor(ItemHelper.colors.yellow)
	            else
	                self.labLev:setColor(ItemHelper.colors.red)
	                self.p_2:setVisible(true)
	                self.iconNext:setVisible(false)
	                self.labNextDesc:setText("當前已是最高等級")
	                self.panelLearn:setVisible(false)
	                self.btnLearn:setTouchEnabled(false)
	            end
	        else --最高了
	            self.p_2:setVisible(true)
	            self.iconNext:setVisible(false)
	            self.labNextDesc:setText("當前已是最高等級")
	        end

	   	else  --公会技能还没开启
            if skillNextVo ~= nil then

	            self.labName:setText(skillDescVo.name)
	            self.labNowDesc:setText(skillDescVo.desc)
	            self.labNextDesc:setText(skillNextVo.desc)
	            self.labCost:setText( string.format("消耗%d貢獻點",skillNextVo.me_donate_cost) )
	            self.me_donate_cost = skillNextVo.me_donate_cost

	            self.iconNow:setId(_choiceId)
	            self.iconNow:setLev(skillMeVo.lev)
	        else --最高了
	            self.p_2:setVisible(true)
	            self.iconNext:setVisible(false)
	            self.labNextDesc:setText("當前已是最高等級")
	        end

            self.labTiplev:setText(string.format("公會%d級可開啟",skillDescVo.guild_lev))
            self.labTiplev:setVisible(true)
            self.panelSkill:setVisible(false)
            self.panelLearn:setVisible(false)
            self.btnLearn:setTouchEnabled(false)
            self.labForbid:setVisible(true)
            self.iconNext:setVisible(false)

            local guildData = CharacterManager:getInstance():getGuildData()
            if guildData:getLev() >= skillDescVo.guild_lev then
                self.labTiplev:setColor(ItemHelper.colors.yellow)
            else
                self.labTiplev:setColor(ItemHelper.colors.red)
            end
	    end
        
    else --未学过
        local skillDescVo = dp:getSkillDescVoById(_choiceId,1)

        if skillGuildVo ~= nil then
            self.labLev:setText(skillGuildVo.lev)
        else  --公会技能还没开启
            self.labTiplev:setText(string.format("公會%d級可開啟",skillDescVo.guild_lev))
            self.labTiplev:setVisible(true)
            self.panelSkill:setVisible(false)
            self.panelLearn:setVisible(false)
            self.btnLearn:setTouchEnabled(false)
            self.labForbid:setVisible(true)
            self.iconNext:setVisible(false)

            local guildData = CharacterManager:getInstance():getGuildData()
            if guildData:getLev() >= skillDescVo.guild_lev then
                self.labTiplev:setColor(ItemHelper.colors.yellow)
            else
                self.labTiplev:setColor(ItemHelper.colors.red)
            end
        end
        self.labName:setText(skillDescVo.name)
        self.labNowDesc:setText("未學習")
        self.labNextDesc:setText(skillDescVo.desc)

        self.iconNow:setId(_choiceId)
        self.iconNow:setLev(0)
        self.iconNext:setId(_choiceId)
        self.iconNext:setLev(1)

        self.labCost:setText( string.format("消耗%d貢獻點",skillDescVo.me_donate_cost) )
        self.me_donate_cost = skillDescVo.me_donate_cost
    end

    local assetData = CharacterManager:getInstance():getAssetData()
    self.labDonate:setText(assetData:getDonate())
end

function GuildSkillScene:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

-- 隐藏 新消息 提示
function GuildSkillScene:hideNewsTip(id)
    local rm = GuildRenderMgr:getInstance()
    local target = rm.dic:objectForKey( string.format("skillitem_%d",id) )
    if target and target:getChildByTag(2866) ~= nil then
        target:removeChildByTag(2866,true)
    end
end

-- 展示 新消息 提示
function GuildSkillScene:showNewsTip(id)
    local target = nil
    local pos = ccp(30,30)
    local rm = GuildRenderMgr:getInstance()
    local target = rm.dic:objectForKey( string.format("skillitem_%d",id) )
    if target and target:getChildByTag(2866) == nil then
        local tips_img = ImageView:create()
        tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
        tips_img:setTag(2866)
        tips_img:setPosition(pos)
        target:addChild(tips_img)
        self:tipsPointPlayAct(tips_img)
    elseif target and target:getChildByTag(2866) ~= nil then
        local tips_img = target:getChildByTag(2866)
        self:tipsPointPlayAct(tips_img)
    end
end


function GuildSkillScene:close()
    --更新内部公会
    Notifier.dispatchCmd(OrganizEvent.GET_MEMBER_ORGANIZ_INFO)

    WindowCtrl:getInstance():open(CmdName.Guild_View_Member)
end