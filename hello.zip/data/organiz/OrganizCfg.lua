--公会配置

OrganizCfg = 
{
	LeastFreeLevel = 20 , --最少免申请入会等级
	OrganizDesc	= "會長很懶，什麼也沒有留下~",
	GuildInfo = "　　1.公會成員每天消耗1點體力，公會增加1點資金，該成員同時增加1點貢\n\n獻，每天上限為600點；成員還可通過公會捐獻同時增加公會資金和個人貢獻，\n\n該途徑無上限。\n\n"..
				"　　2.公會每日通過成員消耗體力來增長的資金有上限，本公會等級增長的上限\n\n為：%d。\n\n"..
				"　　3.公會資金可用于會長升級公會等級、公會技能，會長和副會長開啟公會\n\nBOSS等。\n\n"..
				"　　4.成員的個人貢獻退出公會後再進入其他公會依然保留，可用於學習技能、\n\n競拍公會BOSS的掉落物品等；成員的公會技能在退出公會後也依然會保留。\n\n"..
				"　　5.公會會長連續3天不登陸遊戲將被系統自動彈劾，會長職位將被轉移。\n\n"..
				"　　6.每天資金和貢獻的上限重新刷新時間為05:00。",

	AuctionInfo = "　　1.挑戰公會副本中的BOSS會掉落競拍裝備，只有參與挑戰該副本的成員才可以競拍。\n\n"..
					"　　2.裝備競拍時間為裝備掉落起24小時內，24小時後出價貢獻最高者獲得該裝備，通過郵\n\n件的形式發送到玩家郵件，24小時後無人競拍則系統自動收回，收回的裝備化為公會的活躍\n\n值。\n\n"..
					"　　3.競拍裝備消耗個人貢獻，每個裝備都有最低的競拍價格。\n\n"..
					"　　4.當出價相同時，則按競拍的時間順序，先競拍者獲得。\n\n"..
					"　　5.競拍失敗的玩家，將返還競拍時的個人貢獻。\n\n"..
					"　　6.競拍裝備後退出公會的玩家，將視作競拍失敗，直接退回貢獻。",

	BossInfo = "　　1.每個公會成員每天有2次挑戰BOSS的機會，每日淩晨5點重置。\n\n"..
				"　　2.每個公會BOSS的開啟有一定的條件，需要同時滿足公會等級要求以及成功擊殺\n\n上一個BOSS才可以開啟。\n\n"..
				"　　3.每個公會BOSS都有單次挑戰的傷害排行，排名前10的成員在BOSS被擊殺的同時\n\n可以獲得豐厚的排名獎勵。\n\n"..
				"　　4.每個公會BOSS每天都有1次開啟/重置進度的機會，公會會長或者副會長消耗一\n\n定的公會資金可開啟/重置進度。\n\n"..
				"　　5.重置公會BOSS的進度會同時清空傷害排行榜和BOSS的剩餘血量。\n\n"..
				"　　6.挑戰BOSS後可相應競拍該BOSS掉落的珍惜裝備或者裝備碎片。",

	GuildFightInfo = "　　1.開服第一天22:10開啟第一場公會戰報名，2級及以上公會可報名參加。\n\n"..
						"　　2.公會戰以一周為一屆，每天進行一場對戰，報名成功的公會均會參與到每天的\n\n對戰中；每週周日為最後一場，結束後會在周日晚22:10根據公會勝率公佈各個公會的\n\n排名和獎勵。\n\n"..
						"　　3.備戰階段開始時，系統會自動將公會中的所有成員的戰隊資料上傳到備戰戰隊\n\n中，成員可以自由改變自己的備戰戰隊英雄，會長和副會長可以將成員設置到保護區\n\n（開戰時敵方無法看到此區域的所有資訊）、火力區（將獲得攻擊加成）和防衛區（\n\n將獲得生命力加成）。\n\n"..
						"　　4.在備戰階段，公會成員還可以通過“助戰”來提升公會的火力區、防衛區數量\n\n以及加成強度。\n\n"..
						"　　5.公會戰正式開戰階段，交戰的雙方可以使用自己的一隻攻擊隊伍來攻打對方的\n\n備戰隊伍，每次進攻後都有冷卻時間才能開啟下一次進攻，每次進攻都會獲得一定的\n\n公會戰積分。\n\n"..
						"　　6.在一場公會戰中，先將對方備戰隊伍剿滅則獲得勝利，如果雙方都沒有剿滅對\n\n方，則根據當場積分高則勝利。每場公會戰結束後會根據該公會的積分來發放戰利\n\n品，公會管理人員有許可權在“我的公會”處分配戰利品。",
	WorshipLimit = 2, --膜拜上限
	GuildBossFightLimit = 2, 
	GuildWorshipTips = "公會膜拜次數不足\n提升VIP等級能獲得更多的特權",
}

GuildDefalutDesc = {
	"本公會男女比例失衡，誠招大量男性單身玩家",
	"會長剛新進了一批屠龍寶刀，入會人手一把",
	"團滅理論與實踐，專注貪刀三十年",
	"我叫你聲逗比你敢進來嗎？",
	"我們的大招早已饑渴難耐",
	"今天會長沒吃藥！感覺自己萌！萌！噠！",
}


--区域
OrganizArea = 
{
	SHOW_ORGANIZ = 0,   --展示公会
	FIND_ORGANIZ = 1,	--查找公会
}

--阶级类型 
ClazzType = 
{
	Master = 2,
	Deputy = 1,
	Common = 0,
}

--阶级类型 名字
ClazzTypeName = 
{
	"",
	"副會長",
	"會長",
}

--膜拜状态
WorshipStatus = 
{
	Allow = 1, --允许
	Forbid = 0, --阻止
}

--加入 状态
JoinStatus =
{
	APPLY_JOIN = 0, --普通 申请加入
	QUICI_JOIN = 1, --免申请 立即加入
	CANCEL_APPLY = 2,  --取消申请(已申请)
	HAD_FULLY = 3 ,  --已满员
}

--加入状态名字
JoinStatusName =
{
	"申請加入",
	"立即加入",
	"取消申請",
	"已滿員",
}

--体力状态
PhysicalStatus = 
{
	UN_SEND = 0,
	HAD_SEND = 1,
}

--体力状态名字
PhysicalStatusName = 
{
	UN_SEND = "送體力",
	HAD_SEND = "已贈送",
}

--提示信息
OrganizTips =
{
	ExitOrganiz = "退出公會後1小時內無法加入任何公會,48小時內無法回到原公會,是否退出?",
	ExitOrganizMaster = "公會僅剩1人，現在退出公會，公會將會被解散，是否退出並解散公會？",
	ExitForbidMaster = "此時會長無法退出公會，請先讓位後再試",
	KickConfirm = "確定要剔除該成員?",
	AppointDeputyConfirm = "確定任命該成員為副會長?",
	AppointCommonConfirm = "確定撤職該成員?",
	LeftConfirm = "確定要讓位該成員為會長?",
	LeftConfirmDeputy = "確定要讓位該成員為副會長?",
	ACTIVE_DESC = "請先啟動公會",
}

--膜拜类型
WorshipType =
{
	Free = 0,	--免费膜拜
	Coin = 1, 	--金币膜拜
	Diamon = 2,	--钻石膜拜
}

--竞拍状态
AuctionStatus = 
{
	Normal = 0, --可竞拍
	HadBeen = 1, --已竞拍
	Forbid = 2, --不可竞拍
}

--公会战 区域
GuildFightArea = 
{
	Protect = 1, --保护区
	Power = 3,   --火力区
	Defense = 2, --防御区
	Common = 0,	 --普通区
}

--公会战 区域 占位
GuildFightAreaHolder = {}
GuildFightAreaHolder[1] = "當前可設置保護區隊伍"
GuildFightAreaHolder[2] = "當前可設置防衛區隊伍"
GuildFightAreaHolder[3] = "當前可設置火力區隊伍"

--公会战 阶段
GuildFightMoment = 
{
	SignupBefore = 1,
	SignupIng = 2,
	SignupAfter = 3,--(备战开始和结束报名)
	BattleIng = 4,
	BattleAfter = 5,
	BattleBefore = 6, --战斗前
	BattleFinishPerpare = 8,
	BattleFinish = 7,--公布结果
}

--公会战 阵型
GuildFightTeamStatus = 
{
	MyTeam = 1,  --我方镜像
	EnemyTeam = 2,  --敌方镜像
	MyTeam_Fight = 3,--我方镜像(表现区域不一样而已)
}

--公会消耗类型
GuildCostType = 
{
	GuildDonate = 1, --公会资金
	PersonDonate = 3, --个人资金
	GuildLev = 2, --公会等级
}

--公会战  战绩类型
GuildFightScoreType = 
{
	Current = 1, --本届
	Last = 2,	 --上届
}

--公会战 战斗状态
GuildFightCombatStatus = 
{
	Normal = 0,   --正常
	Fighting = 1, --战斗中
	Dead = 2,     --死亡
	Cold = 3,	  --冷却中
}

--公会战 控件类型
GuildFightWidget = 
{
	FightPlayer = 1,
	FightArea = 2,
}

--公会战 镜像
GuildFightMorror =
{
	Combat = 1,
	Perpare = 2
}

--公会战 战利 分配方式
GuildGloryAllotType =
{
	Master = 1,
	MasterAndDeputy = 2,
	Auto = 0,
}

--公会战 战利 分配方式 名字
GuildGloryAllotName = {}
GuildGloryAllotName[1] = "僅會長分配"
GuildGloryAllotName[2] = "會長副會長"
GuildGloryAllotName[3] = "自動分配"

------------------------网络回调信息码--------------------------------------------------
OrganizMsgMap = 
{
	success_create_organiz = "創建公會成功",
	success_destory_organiz = "解散公會成功",
	success_exit_organiz = "退出公會成功",
	success_edit_organiz = "修改成功",
	success_apply_normal = "申請成功",
	success_quick_join = "加入公會成功",
	success_cancel_organiz = "取消申請成功",
	success_let_clazz = "讓位成功",
	success_set_clazz = "操作成功",
	success_kick_member = "剔除成功",
	success_worship_member = "膜拜成功",
	success_send_phyiscal = "贈送體力成功",
	success_give_phyiscal = "獲取體力成功",
	success_get_reward = "領取成功",
	success_active_ok = "操作成功",
} 

-- 公会通用操作类型	
OrganizCommHandle = 
{
	guild_options = 1,
	-- guild_lev = 1,
	-- guild_board = 2,
	-- guild_icon = 3,
	guild_flag = 4,
	guild_lose_apply = 5,
	guild_agree_apply = 6,
	guild_eliminate = 7,
	guild_appointment = 8,
	guild_abdicate = 9,
	guild_give_physical = 10,
	guild_dissolution = 11,
	guild_sign_out = 12,
	guild_worship_reward = 13,
	guild_add_lev = 14,
	guild_add_contribute = 15,
	guild_send_group_mails = 16,
	guild_study_skill = 17,
	guild_add_skill = 18,
	guild_open_boss = 19,
}