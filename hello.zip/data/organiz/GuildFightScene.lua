-----------------------------------------------------------------------------
--公会战 报名前
GuildFightSignupBefore = class("GuildFightSignupBefore",function()
	return Layout:create()
end)

function GuildFightSignupBefore:create()
	local ret = GuildFightSignupBefore.new()
	ret:init()
    return ret
end

function GuildFightSignupBefore:init()
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightSignupBefore.ExportJson")
	self:addChild(self._widget)
	self:setSize(CCSize(960,640))

	self.btnInfo = tolua.cast(self._widget:getChildByName("btn_info"),"Button")
	self.btnInfo:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightSchePanel)
	    end
	end)
	self.labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")

	self._timerFunc = function()

		local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()
		local nowTime = ServerTimerManager:getInstance():getCurTime()
		local sec = 0

		if sceneVo.isMissCurFight == 1 then
			sec = sceneVo:getMaxScheInfo().combat_end - nowTime
		else
	 		sec = sceneVo.signup_start - nowTime
		end
		self.labTime:setText( Helper.getChCoutStringTime(math.max(0,sec)) )
	end

	-- GuildDataProxy:getInstance():appendFightTimerRenderFunc(self._timerFunc)
end

function GuildFightSignupBefore:update()

	local dp = GuildDataProxy:getInstance()
	local sceneVo = dp:getGuildFightSceneVo()

	local isVis = sceneVo.isSignup == 0
	self.btnInfo:setVisible(isVis)
	self.btnInfo:setTouchEnabled(isVis)

	self._timerFunc()
end

function GuildFightSignupBefore:enter()

end
-----------------------------------------------------------------------------
--公会战 报名中
GuildFightSignupIng = class("GuildFightSignupIng",function()
	return Layout:create()
end)

function GuildFightSignupIng:create()
	local ret = GuildFightSignupIng.new()
	ret:init()
    return ret
end

function GuildFightSignupIng:init()
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightSignupIng.ExportJson")
	self:addChild(self._widget)
	self:setSize(CCSize(960,640))

	self.btnSignup = tolua.cast(self._widget:getChildByName("btn_signup"),"Button")
	self.btnSignup:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_SignupView)
	    end
	end)
	self.btnSignList = tolua.cast(self._widget:getChildByName("btn_signup_list"),"Button")
	self.btnSignList:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_SignupList)
	    end
	end)
	self.labSignNum = tolua.cast(self._widget:getChildByName("lab_signup_num"),"Label")
	self.labTime = tolua.cast(self._widget:getChildByName("lab_left_time"),"Label")
	self.labStatus = tolua.cast(self._widget:getChildByName("lab_guild_status"),"Label")

	self._timerFunc = function()
		local nowTime = ServerTimerManager:getInstance():getCurTime()
		local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()
		local sec = sceneVo.signup_end - nowTime
		self.labTime:setText( Helper.getChCoutStringTime(math.max(0,sec)) )
	end
	-- GuildDataProxy:getInstance():appendFightTimerRenderFunc(self._timerFunc)

	Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_SIGNUPING,function() self:update() end)
end

function GuildFightSignupIng:update()

	local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()

	local curPlayerVo = OrganizHelper.getCurPlayerVo()
	local isVis = curPlayerVo.clazz == ClazzType.Master or
					curPlayerVo.clazz == ClazzType.Deputy

	if sceneVo.isSignup == 1 then
		self.labStatus:setText("（本公會已報名）")
		self.btnSignup:setTouchEnabled(false)
		self.btnSignup:setVisible(false)

		self.btnSignList:setPositionX(480)
	else
		self.labStatus:setText("（本公會暫未報名）")
		self.btnSignup:setTouchEnabled(true and isVis)
		self.btnSignup:setVisible(true and isVis)

		self.btnSignList:setPositionX(376)
	end

	self.labSignNum:setText(string.format("（已有%d個公會報名）",sceneVo.signupNum))
	self._timerFunc()
end

function GuildFightSignupIng:enter()

end
-----------------------------------------------------------------------------
--公会战 报名后
GuildFightSignupAfter = class("GuildFightSignupAfter",function()
	return Layout:create()
end)

function GuildFightSignupAfter:create()
	local ret = GuildFightSignupAfter.new()
	ret:init()
    return ret
end

function GuildFightSignupAfter:init()
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightSignupAfter.ExportJson")
	self:addChild(self._widget)
	self:setSize(CCSize(960,640))

	self.btnPerpare = tolua.cast(self._widget:getChildByName("btn_perpare"),"Button")
	self.btnPerpare:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():close(CmdName.Guild_View_FightScene)
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightPerpare)
		end
	end)

	self.btnInfo = tolua.cast(self._widget:getChildByName("btn_fight_info"),"Button")
	self.btnInfo:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightSchePanel)
	    end
	end)

	self.btnCheer = tolua.cast(self._widget:getChildByName("btn_cheer"),"Button")
	self.btnCheer:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_CheerView)
	    end
	end)

	self.labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")
	self.labSession = tolua.cast(self._widget:getChildByName("lab_fight_session"),"Label")
	self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
	self.labCheerNum = tolua.cast(self._widget:getChildByName("lab_cheer_num"),"Label")
	self.labTips1 = tolua.cast(self._widget:getChildByName("lab_empty1"),"Label")
	self.labTips2 = tolua.cast(self._widget:getChildByName("lab_empty2"),"Label")

	self.guildIcon = GuildIcon:create()
	self.guildIcon:setPosition(ccp(515,363))
	self._widget:addChild(self.guildIcon,2)

	self._timerFunc = function()
		local nowTime = ServerTimerManager:getInstance():getCurTime()
		local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()
		if sceneVo:getCurScheInfo() then
			local sec = sceneVo:getCurScheInfo().combat_start - nowTime
			self.labTime:setText( Helper.getChCoutStringTime(math.max(0,sec)) )
		end
	end
	-- GuildDataProxy:getInstance():appendFightTimerRenderFunc(self._timerFunc)
end

function GuildFightSignupAfter:update()

	if GuildDataProxy:getInstance():checkValidScheInfo(self) == false then return end
	
	local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()
	local enemyInfo = sceneVo.enemyInfo
	local isEmpty = false
	if enemyInfo.name == "" then
		isEmpty = true
		self.labName:setText("")
	else
		self.labName:setText(enemyInfo.name)
	end

	self.labSession:setText("第".. Helper.converNumToChinese(sceneVo.curScheId) .. "場")

	if isEmpty then
		self.guildIcon:setVisible(false)
		self.btnCheer:setVisible(false)
		self.btnCheer:setTouchEnabled(false)
		self.btnPerpare:setVisible(false)
		self.btnPerpare:setTouchEnabled(false)

		self.labTips1:setVisible(true)
		self.labTips2:setVisible(true)
		self.labCheerNum:setVisible(false)
	else
		self.labCheerNum:setVisible(true)
		self.guildIcon:setVisible(true)
		self.guildIcon:setId(enemyInfo.logoId)
		self.guildIcon:setLev(enemyInfo.lev)

		self.btnCheer:setVisible(true)
		self.btnCheer:setTouchEnabled(true)
		self.btnPerpare:setVisible(true)
		self.btnPerpare:setTouchEnabled(true)

		local guildData = CharacterManager:getInstance():getGuildData()
		self.labCheerNum:setText(string.format("已有%d人助威",guildData:getCheerNum()))
		self.labTips1:setVisible(false)
		self.labTips2:setVisible(false)
	end

	if self.armCheer then
		self.btnCheer:removeNode(self.armCheer)
        self.armCheer = nil 
	end
    if sceneVo.isCheer == 0 then
        self.armCheer_path = "ui/effects_ui/zhuwei/zhuwei.ExportJson"
	    self.armCheer = AnimateManager:getInstance():getArmature(self.armCheer_path,"zhuwei")
    	self.armCheer:getAnimation():play("Animation1",-1,-1,1)
    	self.btnCheer:addNode(self.armCheer)
    end
	self._timerFunc()
end

function GuildFightSignupAfter:enter()

end
-----------------------------------------------------------------------------
--公会战 战斗前
GuildFightBattleBefore = class("GuildFightBattleBefore",function()
	return Layout:create()
end)

function GuildFightBattleBefore:create()
	local ret = GuildFightBattleBefore.new()
	ret:init()
    return ret
end

function GuildFightBattleBefore:init()
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightBattleBefore.ExportJson")
	self:addChild(self._widget)
	self:setSize(CCSize(960,640))

	self.labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")
	self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
	self.labSession = tolua.cast(self._widget:getChildByName("lab_fight_session"),"Label")

	self.btnPerpare = tolua.cast(self._widget:getChildByName("btn_perpare"),"Button")
	self.btnPerpare:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():close(CmdName.Guild_View_FightScene)
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightPerpare,{myteam = 1})
	    end
	end)
	self.btnInfo = tolua.cast(self._widget:getChildByName("btn_fight_info"),"Button")
	self.btnInfo:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightSchePanel)
	    end
	end)
	self.btnEnemy = tolua.cast(self._widget:getChildByName("btn_enemy_info"),"Button")
	self.btnEnemy:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():close(CmdName.Guild_View_FightScene)
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightPerpare,{enemy = 1})
	    end
	end)

	self.guildIcon = GuildIcon:create()
	self.guildIcon:setPosition(ccp(515,363))
	self._widget:addChild(self.guildIcon,2)

	self._timerFunc = function()
		local nowTime = ServerTimerManager:getInstance():getCurTime()
		local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()
		if sceneVo:getCurScheInfo() then
			local sec = sceneVo:getCurScheInfo().combat_start - nowTime
			self.labTime:setText( Helper.getChCoutStringTime(math.max(0,sec)) )
		end
	end
	-- GuildDataProxy:getInstance():appendFightTimerRenderFunc(self._timerFunc)
end

function GuildFightBattleBefore:update()
	
	if GuildDataProxy:getInstance():checkValidScheInfo(self) == false then return end

	local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()

	local enemyInfo = sceneVo.enemyInfo
	local isEmpty = false
	if enemyInfo.name == "" then
		isEmpty = true
		self.labName:setText("輪空")

		self.btnPerpare:setVisible(false)
		self.btnPerpare:setTouchEnabled(false)
		self.btnEnemy:setVisible(false)
		self.btnEnemy:setTouchEnabled(false)
	else
		self.labName:setText(enemyInfo.name)

		self.btnPerpare:setVisible(true)
		self.btnPerpare:setTouchEnabled(true)
		self.btnEnemy:setVisible(true)
		self.btnEnemy:setTouchEnabled(true)
	end

	self.labSession:setText("第".. Helper.converNumToChinese(sceneVo.curScheId) .. "場")

	if isEmpty then
		self.guildIcon:setVisible(false)
	else
		self.guildIcon:setVisible(true)
		self.guildIcon:setId(enemyInfo.logoId)
		self.guildIcon:setLev(enemyInfo.lev)
	end
	self._timerFunc()
end

function GuildFightBattleBefore:enter()
	
end
-----------------------------------------------------------------------------
--公会战 战斗中
GuildFightBattleIng = class("GuildFightBattleIng",function()
	return Layout:create()
end)

function GuildFightBattleIng:create()
	local ret = GuildFightBattleIng.new()
	ret:init()
    return ret
end

function GuildFightBattleIng:init()
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightBattleIng.ExportJson")
	self:addChild(self._widget)
	self:setSize(CCSize(960,640))

	self.labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")
	self.labNum1 = tolua.cast(self._widget:getChildByName("lab_num1"),"Label")
	self.labNum2 = tolua.cast(self._widget:getChildByName("lab_num2"),"Label")
	self.labName1 = tolua.cast(self._widget:getChildByName("lab_name1"),"Label")
	self.labName2 = tolua.cast(self._widget:getChildByName("lab_name2"),"Label")
	self.labTeamNum1 = tolua.cast(self._widget:getChildByName("lab_team_num1"),"Label")
	self.labTeamNum2 = tolua.cast(self._widget:getChildByName("lab_team_num2"),"Label")
	self.labScore1 = tolua.cast(self._widget:getChildByName("lab_score1"),"Label")
	self.labScore2 = tolua.cast(self._widget:getChildByName("lab_team_score2"),"Label")
	self.labSession = tolua.cast(self._widget:getChildByName("lab_session"),"Label")

	self.guildIcon1 = GuildIcon:create()
	self.guildIcon1:setPosition(ccp(320,368))
	self._widget:addChild(self.guildIcon1,2)

	self.guildIcon2 = GuildIcon:create()
	self.guildIcon2:setPosition(ccp(666,368))
	self._widget:addChild(self.guildIcon2,2)

	self.btnInfo = tolua.cast(self._widget:getChildByName("btn_fight_info"),"Button")
	self.btnInfo:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightSchePanel)
	    end
	end)

	self.btnFight = tolua.cast(self._widget:getChildByName("btn_fight"),"Button")
	self.btnFight:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():close(CmdName.Guild_View_FightScene)
	   		WindowCtrl:getInstance():open(CmdName.Guild_View_FightBattle)
	    end
	end)

	self.btnMyTeam = tolua.cast(self._widget:getChildByName("btn_myteam"),"Button")
	self.btnMyTeam:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightPerpare,{myteam_fight = 1})
		end
	end)

	self._timerFunc = function()
		local nowTime = ServerTimerManager:getInstance():getCurTime()
		local dp = GuildDataProxy:getInstance()
		local sceneVo = dp:getGuildFightSceneVo()
		if sceneVo:getCurScheInfo() then
			local sec = sceneVo:getCurScheInfo().combat_end - nowTime
			self.labTime:setText( Helper.getChCoutStringTime(math.max(0,sec)) )
		end
	end
	-- GuildDataProxy:getInstance():appendFightTimerRenderFunc(self._timerFunc)
end

function GuildFightBattleIng:update()
	
	if GuildDataProxy:getInstance():checkValidScheInfo(self) == false then return end

	local dp = GuildDataProxy:getInstance()
	local sceneVo = dp:getGuildFightSceneVo()
	self.labSession:setText("第".. Helper.converNumToChinese(sceneVo.curScheId) .. "場")

	local guildData = CharacterManager:getInstance():getGuildData()
	self.guildIcon1:setId(guildData:getLogoId())
	self.guildIcon1:setLev(guildData:getLev())
	self.labName1:setText(guildData:getName())
	self.labNum1:setText(string.format("(%d人)",guildData:getCurrNum()))

	local enemyInfo = sceneVo.enemyInfo
	
	local isEmpty = false
	if enemyInfo.name == "" then
		isEmpty = true
		self.labName2:setText("輪空")
		self.labNum2:setVisible(false)
		self.guildIcon2:setVisible(false)

		self.btnFight:setVisible(false)
		self.btnFight:setTouchEnabled(false)
		self.labScore2:setVisible(false)
		self.labTeamNum2:setVisible(false)
	else
		self.labNum2:setVisible(true)
		self.guildIcon2:setVisible(true)
		self.guildIcon2:setId(enemyInfo.logoId)
		self.guildIcon2:setLev(enemyInfo.lev)
		self.labName2:setText(enemyInfo.name)
		self.labNum2:setText(string.format("(%d人)",enemyInfo.population))

		self.btnFight:setVisible(true)
		self.btnFight:setTouchEnabled(true)
		self.labScore2:setVisible(true)
		self.labTeamNum2:setVisible(true)
	end

	local teamVo1 = dp:getGuildFightTeamVoById(GuildFightTeamStatus.MyTeam)
	local teamVo2 = dp:getGuildFightTeamVoById(GuildFightTeamStatus.EnemyTeam)

	self.labTeamNum1:setText(string.format("%d/%d",teamVo1.curNum,teamVo1.maxNum))
	if teamVo1.curNum > 0 and teamVo2.curNum == 0 then
		self.labTeamNum2:setText("【全殲對手！】")
	else
		self.labTeamNum2:setText(string.format("%d/%d",teamVo2.curNum,teamVo2.maxNum))
	end
	self.labScore1:setText(sceneVo.mySessionScore)
	self.labScore2:setText(sceneVo.enemySessionScore)

	self._timerFunc()
end

function GuildFightBattleIng:enter()
	--预先获取战队阵型
	TeamManager:getInstance():reqTeamAllInfo(TeamType.Guild_atk,true)
end
-----------------------------------------------------------------------------
--公会战 战斗后
GuildFightBattleAfter = class("GuildFightBattleAfter",function()
	return Layout:create()
end)

function GuildFightBattleAfter:create()
	local ret = GuildFightBattleAfter.new()
	ret:init()
    return ret
end

function GuildFightBattleAfter:init()
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightBattleAfter.ExportJson")
	self:addChild(self._widget)
	self:setSize(CCSize(960,640))

	self.labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")
	self.labCheerNum = tolua.cast(self._widget:getChildByName("lab_cheer_num"),"Label")
	self.panelLastBattle = tolua.cast(self._widget:getChildByName("panel_last_battle"),"Label")
	
	self.guildIcon1 = GuildIcon:create()
	self.guildIcon1:setPosition(ccp(324,389))
	self._widget:addChild(self.guildIcon1,2)

	self.guildIcon2 = GuildIcon:create()
	self.guildIcon2:setPosition(ccp(644,389))
	self._widget:addChild(self.guildIcon2,2)

	self.guildIcon3 = GuildIcon:create()
	self.guildIcon3:setScale(0.8)
	self.guildIcon3:setPosition(ccp(410,229))
	self._widget:addChild(self.guildIcon3,2)

	self.btnPerpare = tolua.cast(self._widget:getChildByName("btn_perpare"),"Button")
	self.btnPerpare:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():close(CmdName.Guild_View_FightScene)
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightPerpare)
		end
	end)

	self.btnInfo = tolua.cast(self._widget:getChildByName("btn_info"),"Button")
	self.btnInfo:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightSchePanel)
	    end
	end)

	self.btnCheer = tolua.cast(self._widget:getChildByName("btn_cheer"),"Button")
	self.btnCheer:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_CheerView)
	    end
	end)

	self.imgWin = tolua.cast(self._widget:getChildByName("img_win"),"ImageView")
	self.labNum1 = tolua.cast(self.panelLastBattle:getChildByName("lab_num1"),"Label")
	self.labNum2 = tolua.cast(self.panelLastBattle:getChildByName("lab_num2"),"Label")
	self.labName1 = tolua.cast(self.panelLastBattle:getChildByName("lab_name1"),"Label")
	self.labName2 = tolua.cast(self.panelLastBattle:getChildByName("lab_name2"),"Label")
	self.labLastSession = tolua.cast(self.panelLastBattle:getChildByName("lab_last_session"),"Label")
	self.labNextSession = tolua.cast(self.panelLastBattle:getChildByName("lab_next_session"),"Label")
	self.labName3 = tolua.cast(self.panelLastBattle:getChildByName("lab_next_name"),"Label")
	self.labCheerNum = tolua.cast(self._widget:getChildByName("lab_cheer_num"),"Label")

	self._timerFunc = function()
		local nowTime = ServerTimerManager:getInstance():getCurTime()
		local dp = GuildDataProxy:getInstance()
		local sceneVo = dp:getGuildFightSceneVo()
		if sceneVo:getCurScheInfo() then
			local sec = sceneVo:getCurScheInfo().combat_start - nowTime
			self.labTime:setText( Helper.getChCoutStringTime(math.max(0,sec)) )
		end

		local guildData = CharacterManager:getInstance():getGuildData()
		self.labCheerNum:setText(string.format("已有%d人助威",guildData:getCheerNum()))
	end
	-- GuildDataProxy:getInstance():appendFightTimerRenderFunc(self._timerFunc)
end

function GuildFightBattleAfter:update()

	if GuildDataProxy:getInstance():checkValidScheInfo(self) == false then return end

	local dp = GuildDataProxy:getInstance()
	local sceneVo = dp:getGuildFightSceneVo()

	local guildData = CharacterManager:getInstance():getGuildData()
	self.guildIcon1:setId(guildData:getLogoId())
	self.guildIcon1:setLev(guildData:getLev())
	self.labName1:setText(guildData:getName())
	self.labNum1:setText(string.format("(%d人)",guildData:getCurrNum()))

	local recordVo = dp:getMyCombatRecordVoById( sceneVo.curScheId - 1 )
	if GuildDataProxy:getInstance():foreceVisibleView(self,recordVo ~= nil) == false then return end

	local isEmpty = false
	if recordVo.name2 == "" then
		isEmpty = true
		self.labName2:setText("輪空")
		self.guildIcon2:setVisible(false)
		self.labNum2:setVisible(false)
	else
		self.guildIcon2:setVisible(true)
		self.guildIcon2:setId(recordVo.logoId2)
		self.guildIcon2:setLev(recordVo.lev2)
		self.labName2:setText(recordVo.name2)
		self.labNum2:setText(string.format("(%d人)",recordVo.num2))
		self.labNum2:setVisible(true)
	end
	if recordVo.isWin == 1 then
		self.imgWin:setPositionX(359)
	else
		self.imgWin:setPositionX(699)
	end
	
	self.labLastSession:setText("第".. Helper.converNumToChinese(sceneVo.curScheId - 1) .. "場")

	local enemyInfo = sceneVo.enemyInfo
	local isEmpty = false
	if enemyInfo.name == "" then
		isEmpty = true
		self.labName3:setText("輪空")
		self.guildIcon3:setVisible(false)
		self.btnPerpare:setVisible(false)
		self.btnPerpare:setTouchEnabled(false)
	else
		self.btnPerpare:setVisible(true)
		self.btnPerpare:setTouchEnabled(true)
		self.guildIcon3:setVisible(true)
		self.guildIcon3:setId(enemyInfo.logoId)
		self.guildIcon3:setLev(enemyInfo.lev)
		self.labName3:setText(enemyInfo.name)
	end

	if self.armCheer then
		self.btnCheer:removeNode(self.armCheer)
        self.armCheer = nil 
	end
    if sceneVo.isCheer == 0 then
        self.armCheer_path = "ui/effects_ui/zhuwei/zhuwei.ExportJson"
	    self.armCheer = AnimateManager:getInstance():getArmature(self.armCheer_path,"zhuwei")
    	self.armCheer:getAnimation():play("Animation1",-1,-1,1)
    	self.btnCheer:addNode(self.armCheer)
    end
	self._timerFunc()
end

function GuildFightBattleAfter:enter()

end
-----------------------------------------------------------------------------
--公会战 即将公布赛果
GuildFightBattleFinishPerpare = class("GuildFightBattleFinishPerpare",function()
	return Layout:create()
end)

function GuildFightBattleFinishPerpare:create()
	local ret = GuildFightBattleFinishPerpare.new()
	ret:init()
    return ret
end

function GuildFightBattleFinishPerpare:init()
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightBattleFinishPerpare.ExportJson")
	self:addChild(self._widget)
	self:setSize(CCSize(960,640))

	self.guildIcon1 = GuildIcon:create()
	self.guildIcon1:setPosition(ccp(296,379))
	self._widget:addChild(self.guildIcon1,2)

	self.guildIcon2 = GuildIcon:create()
	self.guildIcon2:setPosition(ccp(654,379))
	self._widget:addChild(self.guildIcon2,2)

	self.labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")
	self.imgWin = tolua.cast(self._widget:getChildByName("img_win"),"ImageView")
	self.labNum1 = tolua.cast(self._widget:getChildByName("lab_num1"),"Label")
	self.labNum2 = tolua.cast(self._widget:getChildByName("lab_num2"),"Label")
	self.labName1 = tolua.cast(self._widget:getChildByName("lab_name1"),"Label")
	self.labName2 = tolua.cast(self._widget:getChildByName("lab_name2"),"Label")

	self.btnInfo = tolua.cast(self._widget:getChildByName("btn_fight_info"),"Button")
	self.btnInfo:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightSchePanel)
	    end
	end)

	self._timerFunc = function()
		local nowTime = ServerTimerManager:getInstance():getCurTime()
		local dp = GuildDataProxy:getInstance()
		local sceneVo = dp:getGuildFightSceneVo()
		local sec = sceneVo.signup_start - nowTime
		self.labTime:setText( Helper.getChCoutStringTime(math.max(0,sec)) )
	end
	-- GuildDataProxy:getInstance():appendFightTimerRenderFunc(self._timerFunc)
end

function GuildFightBattleFinishPerpare:enter()
	--预先获取战队阵型
	TeamManager:getInstance():reqTeamAllInfo(TeamType.Guild_atk,true)
end

function GuildFightBattleFinishPerpare:update()
	
	local recordVo = GuildDataProxy:getInstance():getMyCombatRecordLastVo()
	local isEmpty = false
	if recordVo.name2 == "" then
		isEmpty = true
		self.labName2:setText("輪空")
		self.guildIcon2:setVisible(false)
		self.imgWin:setVisible(false)
	else
		self.guildIcon2:setVisible(true)
		self.guildIcon2:setId(recordVo.logoId2)
		self.guildIcon2:setLev(recordVo.lev2)
		self.labName2:setVisible(true)
		self.labName2:setText(recordVo.name2)
		self.labNum2:setVisible(true)
		self.labNum2:setText(string.format("(%d人)",recordVo.num2))
		self.imgWin:setVisible(true)
	end

	if recordVo.isWin == 1 then
		self.imgWin:setPositionX(359)
	else
		self.imgWin:setPositionX(699)
	end

	self.guildIcon1:setId(recordVo.logoId1)
	self.guildIcon1:setLev(recordVo.lev1)
	self.labName1:setText(recordVo.name1)
	self.labNum1:setText(string.format("(%d人)",recordVo.num1))

	self._timerFunc()
end

--------------------------------------------------------------------------------
--公会战 公布结果
GuildFightBattleFinish = class("GuildFightBattleFinish",function()
	return Layout:create()
end)

function GuildFightBattleFinish:create()
	local ret = GuildFightBattleFinish.new()
	ret:init()
    return ret
end

function GuildFightBattleFinish:init()
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightBattleFinish.ExportJson")
	self:addChild(self._widget)
	self:setSize(CCSize(960,640))

	self.btnInfo = tolua.cast(self._widget:getChildByName("btn_info"),"Button")
	self.btnInfo:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_SignupList)
	    end
	end)

	self.btnSignup = tolua.cast(self._widget:getChildByName("btn_signup"),"Button")
	self.btnSignup:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_SignupView)
	    end
	end)

	self.scrolRank = DisplayUtil.createAdaptScrollView(840,310,0,0,1)
    self.scrolRank:setPosition(ccp(30,177))
    self._widget:addChild(self.scrolRank)

	Notifier.regist(OrganizEvent.MSG_UPDATE_FINISH_RANK,function() 
        GuildRenderMgr:getInstance():renderFinishRankAdapt(self.scrolRank)

        self.scrolRank:stopAllActions()
        self.scrolRank:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
            CCCallFunc:create(function()
                local viewY = self.scrolRank:getInnerContainer():getPositionY()
                local viewRect = CCRectMake(0,math.abs(viewY),840,310)
                GuildRenderMgr:getInstance():refreshFinishRankList(viewRect,self.scrolRank)
            end),
            CCDelayTime:create(0.1))))
    end)

    self.labNum = tolua.cast(self._widget:getChildByName("lab_num"),"Label")
    self.labSignup = tolua.cast(self._widget:getChildByName("lab_signup"),"Label")

    Notifier.regist(OrganizEvent.MSG_UPDATE_FINISH_RANK_SIGNLIST,function() self:update() end)
end

function GuildFightBattleFinish:update()
		
	local sceneVo = GuildDataProxy:getInstance():getGuildFightSceneVo()
	self.labNum:setText(string.format("（已有%d個公會報名）",sceneVo.signupNum))
	if sceneVo.isSignup == 1 then
		self.labSignup:setText(string.format("（本公會已報名）"))
	else
		self.labSignup:setText(string.format("（本公會暫未報名）"))
	end

	local curPlayerVo = OrganizHelper.getCurPlayerVo()
	local isVis = curPlayerVo.clazz == ClazzType.Master or
					curPlayerVo.clazz == ClazzType.Deputy
	self.btnSignup:setVisible(isVis)
	self.btnSignup:setTouchEnabled(isVis)

	Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FINISH_RANK)
end

function GuildFightBattleFinish:enter()
	
end

--公会战 公布结果 排名条目
GuildFightBattleRankItem = class("GuildFightBattleRankItem",function()
	return Layout:create()
end)

function GuildFightBattleRankItem:create()
	local ret = GuildFightBattleRankItem.new()
	ret:init()
    return ret
end

function GuildFightBattleRankItem:init()
	self._widget = GuildDataProxy:getInstance():getWidgetGloryRankItem():clone()
	self:addChild(self._widget)
	self:setSize(CCSize(840,82))

	self.labRank = tolua.cast(self._widget:getChildByName("lab_rank"),"Label")
	self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
	self.labLev = tolua.cast(self._widget:getChildByName("lab_lev"),"Label")
	self.labWinPerc = tolua.cast(self._widget:getChildByName("lab_win_perc"),"Label")
	self.labWinNum = tolua.cast(self._widget:getChildByName("lab_win_num"),"Label")
	self.btnCheck = tolua.cast(self._widget:getChildByName("btn_check"),"Button")
	self.btnCheck:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightScorePanel,
	    		{id=self.rankVo.id,
	    		type=GuildFightScoreType.Last,
	    		name=self.rankVo.name})
	    end
	end)

	self.imgBg = tolua.cast(self._widget:getChildByName("img_bg"),"ImageView")
end

function GuildFightBattleRankItem:setData(vo)
	self.rankVo = vo
	self:update()
end

function GuildFightBattleRankItem:update()
	if self.rankVo.rank == 1 then
		self.labRank:setText("榮耀冠軍")
		self.labRank:setColor(ItemHelper.colors.orange)
	else
		self.labRank:setText(string.format("第%d名",self.rankVo.rank))
		self.labRank:setColor(ItemHelper.colors.blue)
	end
	self.labName:setText(self.rankVo.name)
	self.labLev:setText(string.format("（Lv.%d）",self.rankVo.lev))
	self.labWinPerc:setText(string.format("%.2f%%",self.rankVo.win_num/self.rankVo.session_max*100))
	self.labWinNum:setText(self.rankVo.win_num)

	local isVis = self.rankVo.rank % 2 == 1 
    self.imgBg:setVisible(isVis)
end

function GuildFightBattleRankItem:enter()
	
end
----------------------------------------------------------------------------
-- 公会战 场景
GuildFightScene = class("GuildFightScene",WindowBase)
GuildFightScene.__index = GuildFightScene
GuildFightScene._widget = nil
GuildFightScene.uiLayer = nil

local __instance = nil

function GuildFightScene:create()
    local ret = GuildFightScene.new()
    __instance = ret
    return ret
end

function GuildFightScene:init()
	HeroManager:getInstance():loadSkillIconPlist()
	ComResMgr:getInstance():loadOtherRes()
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/organiz/member/guild.plist")
	require "GuildIcon"
	ComResMgr:getInstance():loadResByName("ui/arena/arena_bg.plist","ui/arena/arena_bg.pvr.ccz")

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/organiz/member/fight/GuildFightScene.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.btnDesc = tolua.cast(self.uiLayer:getWidgetByName("btn_desc"),"Button")
    self.btnDesc:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Comm_DescPanel,
	    		{title="公會戰",content=OrganizCfg.GuildFightInfo,
	    		rewardArr = {{img="gold.png",lab="金幣"},
                         	{img="reward_enchan.png",lab="附魔書"},
                         	{img="reward_hero_exp.png",lab="經驗藥"},
                         	{img="reward_pet.png",lab="侍寵進階精華"}}})
	    end
	end)

    self.btnHistory = tolua.cast(self.uiLayer:getWidgetByName("btn_history"),"Button")
    self.btnHistory:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_FightScorePanel,
	    		{id=CharacterManager:getInstance():getGuildData():getId(),
	    		type=GuildFightScoreType.Last,
	    		name=CharacterManager:getInstance():getGuildData():getName()})
	    end
	end)

	self.btnGuild = tolua.cast(self.uiLayer:getWidgetByName("btn_guild"),"Button")
	self.btnGuild:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_GloryPanel)
	    end
	end)

	self.btnRank = tolua.cast(self.uiLayer:getWidgetByName("btn_rank"),"Button")
	self.btnRank:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	WindowCtrl:getInstance():open(CmdName.Guild_View_RankView)
	    end
	end)

	self.imgBg = ImageView:create()
 	self.imgBg:setPosition(ccp(480,320))
 	self._widget:addChild(self.imgBg)

 	self._runTimer = function()
 		self:runTimer()
 	end

	self.panelView = tolua.cast(self.uiLayer:getWidgetByName("panel_view"),"Layout")

	Notifier.regist(OrganizEvent.MSG_UPDATE_FIGHT_SCENE, function() self:update() end)
	Notifier.regist(OrganizEvent.GUILD_FIGHT_NEW_TIPS_SHOW,function(key) self:showNewsTip(key) end)
    Notifier.regist(OrganizEvent.GUILD_FIGHT_NEW_TIPS_HIDE,function(key) self:hideNewsTip(key) end) 
end

function GuildFightScene:open()

	self.imgBg:loadTexture("ui/organiz/member/fight/guild_fight_bg.jpg")
	self.imgBg:setScaleX(1/DisplayUtil.min_scale*DisplayUtil.max_scale)
	self.imgBg:setScaleY(1/DisplayUtil.min_scale*DisplayUtil.max_scale)
	--清理数据
	self.panelView:removeAllChildren()
	self.panelView:removeAllNodes()

	if self.params and self.params["norefresh"] == 1 then
		self:update()
	else
		GuildNetTask:getInstance():requestGuildFightInfo()
	end
	if GuildDataProxy:getInstance().fight_reward_news > 0 then
        self:showNewsTip(NewTipsEnum.guild_fight_reward)
    end
end

function GuildFightScene:update()
	local dp = GuildDataProxy:getInstance()
	local rm = GuildRenderMgr:getInstance()
	local sceneVo = dp:getGuildFightSceneVo()
	rm:showFightView(self.panelView,sceneVo.curMoment) 

	--取消绿点
	GuildDataProxy:getInstance().short_fight_news_enter = 0
	Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.guild)
	Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_NEW_TIPS_HIDE,NewTipsEnum.guild_fight)
end

--每秒钟调用
function GuildFightScene:runTimer()
	-- local listFuc = GuildDataProxy:getInstance():getFightTimerRenderFuncList()
	-- for k,func in pairs(listFuc) do
	-- 	func()
	-- end
end

function GuildFightScene:startSchedule()
	-- self._runTimer()
	-- TimerManager.addTimer(60*1000,self._runTimer,true)
end

function GuildFightScene:clearSchedule()
    -- TimerManager.removeTimer(self._runTimer)
end

function GuildFightScene:returnFun()
	WindowCtrl:getInstance():close(self.name)
	WindowCtrl:getInstance():open(CmdName.Guild_View_Member)
end

function GuildFightScene:close()
	self:clearSchedule()
	CCTextureCache:sharedTextureCache():removeTextureForKey("ui/organiz/member/fight/guild_fight_bg.jpg")
end

function GuildFightScene:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

-- 隐藏 新消息 提示
function GuildFightScene:hideNewsTip(key)
    local target = nil
    if key == NewTipsEnum.guild_fight_reward then
        target = self.btnGuild
    end
    if target and target:getChildByTag(2866) ~= nil then
        CharacterManager:getInstance():getBaseData():setNewsTipStatus(key,1) --0 显示  1 不显示
        target:removeChildByTag(2866,true)
    end
end

-- 展示 新消息 提示
function GuildFightScene:showNewsTip(key)
    local target = nil
    local pos = nil
    if key == NewTipsEnum.guild_fight_reward then
        target = self.btnGuild
        pos = ccp(50,20)
    end
    if target and target:getChildByTag(2866) == nil then
        local tips_img = ImageView:create()
        tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
        tips_img:setTag(2866)
        tips_img:setPosition(pos)
        target:addChild(tips_img)
        self:tipsPointPlayAct(tips_img)
    elseif target and target:getChildByTag(2866) ~= nil then
        local tips_img = target:getChildByTag(2866)
        self:tipsPointPlayAct(tips_img)
    end
end
