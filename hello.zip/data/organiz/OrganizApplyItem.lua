
--申请入会 条目
ApplyItem = class("ApplyItem",function()
    return Layout:create()
end)
ApplyItem.__index = ApplyItem
ApplyItem._widget 	= nil
ApplyItem.uiLayer = nil


function ApplyItem:create(playerVo)
    local ret = ApplyItem.new()
    ret:init(playerVo)
    return ret
end

--------------------------响应事件---------------------------------------------
-- local function event_btn_ignore(pSender,eventType)
-- 	if eventType == ComConstTab.TouchEventType.ended then
-- 	    GuildNetTask:getInstance():requestIgnoreJoin(pSender:getTag())
-- 	end
-- end

-- local function event_btn_agree(pSender,eventType)
--     if eventType == ComConstTab.TouchEventType.ended then
--         GuildNetTask:getInstance():requestAgreeJoin(pSender:getTag())
--     end
-- end

-- local function event_btn_icon(pSender,eventType)
--     if eventType == ComConstTab.TouchEventType.ended then
--         local playerVo = GuildDataProxy:getInstance():getApplyVoById(pSender:getTag())
--         WindowCtrl:getInstance():open(CmdName.Comm_PlayerInfo,{vo = playerVo})
--     end
-- end
--------------------------初始化----------------------------------------------
function ApplyItem:init(playerVo)

	self._widget = GuildDataProxy:getInstance():getWidgetApplyItem():clone()
    self:setSize(CCSize(880,140))
    self:addChild(self._widget)

    local btnIgnore = tolua.cast(self._widget:getChildByName("btn_ignore"),"Button")
    btnIgnore:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            GuildNetTask:getInstance():requestIgnoreJoin(playerVo.id)
        end
    end)

    local btnAgree = tolua.cast(self._widget:getChildByName("btn_agree"),"Button")
    btnAgree:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            GuildNetTask:getInstance():requestAgreeJoin(playerVo.id)
        end
    end)

    local p_icon = self._widget:getChildByName("p_icon")
    local icon = HeadIcon:create()
    icon:setScale(0.9)
	icon:setFaceId(playerVo.faceId,playerVo.sex)
    icon:setPosition(ccp(p_icon:getPosition()))
    icon:setClickEvent(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Comm_PlayerInfo,{vo = self.playerVo})
        end
    end)

    self.playerVo = playerVo
    self._widget:addChild(icon)

    self:update(playerVo)
end

function ApplyItem:update(playerVo)

	local labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    labName:setText(playerVo.name)

    local labLevel = tolua.cast(self._widget:getChildByName("lab_level"),"Label")
    labLevel:setText(playerVo.level)
end