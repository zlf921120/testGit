--修改成员条目
EditMemberItem = class("EditMemberItem",function()
    return Layout:create()
end)
EditMemberItem.__index = EditMemberItem
EditMemberItem._widget 	= nil
EditMemberItem.uiLayer = nil
EditMemberItem.id = ""

--成员管理 条目
function EditMemberItem:create()
    local ret = EditMemberItem.new()
    ret:init()
    return ret
end

--------------------------响应事件---------------------------------------------
local function event_btn_edit(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
        local btn = tolua.cast(pSender,"Button")
		-- Notifier.dispatchCmd(OrganizEvent.MSG_MEMBERCTL_PANEL,btn:getTag())
         WindowCtrl:getInstance():open(CmdName.Guild_View_EditMember,{id = btn:getTag()})
	end
end

--------------------------初始化----------------------------------------------
function EditMemberItem:init()

	self._widget = GuildDataProxy:getInstance():getWidgetEditItem():clone()
    self:addChild(self._widget)
    self:setSize(CCSize(880,140))

    self.btnEdit = tolua.cast(self._widget:getChildByName("btn_edit"),"Button")
    self.btnEdit:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
             WindowCtrl:getInstance():open(CmdName.Guild_View_EditMember,
                {id = self.playerVo.role_id:getKeyIdx() })
        end
    end)

    self.labClazz = tolua.cast(self._widget:getChildByName("lab_clazz"),"Label")
    self.labLevel = tolua.cast(self._widget:getChildByName("lab_level"),"Label")
    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labDonate = tolua.cast(self._widget:getChildByName("lab_donate"),"Label")
    self.labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")

    local p_icon = self._widget:getChildByName("p_icon")
    self.icon = HeadIcon:create()
    self.icon:setScale(0.9)
	
    self.icon:setPosition(ccp(p_icon:getPosition()))
    self.icon:setClickEvent(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            
            WindowCtrl:getInstance():open(CmdName.Comm_PlayerInfo,{vo = self.playerVo})
        end
    end)
    self._widget:addChild(self.icon)
end

function EditMemberItem:setData(vo)
    self.playerVo = vo
    self:update()
end

function EditMemberItem:update()

    local playerVo = self.playerVo

    local now = ServerTimerManager:getInstance():getCurTime()

    self.icon:setFaceId(playerVo.faceId,playerVo.sex)
    -- self.btnEdit:setTag(playerVo.id)

    self.labName:setText(playerVo.name)
    self.labLevel:setText(playerVo.level)
    self.labClazz:setText(ClazzTypeName[playerVo.clazz + 1])
    self.labDonate:setText(string.format("%s/%s",
        Helper.getChNumStr(playerVo.donateCur), 
        Helper.getChNumStr(playerVo.donateTotal)))
    self.labTime:setText(Helper.getChCoutStrTime( now - playerVo.historyLoginTime, 60 * 60 ))
end