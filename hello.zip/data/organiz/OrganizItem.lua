--公会 条目

OrganizItem = class("OrganizItem",function()
    return Layout:create()
end)
OrganizItem.__index = OrganizItem
OrganizItem._widget 	= nil
OrganizItem.uiLayer 	= nil
OrganizItem.organizVo = nil
OrganizItem._update = nil

function OrganizItem:create()
    local ret = OrganizItem.new()
    ret:init()
    return ret
end
----------------响应事件--------------------------------------------
local function event_btn_push(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        local _id = tolua.cast(pSender,"Button"):getTag()
        local organizVo = GuildDataProxy:getInstance():getGuildVoById(_id)

        local netTask = GuildNetTask:getInstance()

        if organizVo.status == JoinStatus.APPLY_JOIN then
            netTask:requestAppleJoinOrganiz(_id)
        elseif organizVo.status == JoinStatus.QUICI_JOIN then
            netTask:requestQuickJoinOrganiz(_id)
        elseif organizVo.status == JoinStatus.CANCEL_APPLY then
            netTask:requestCanelApply(_id)
        end
    end
end

---------------初始化-----------------------------------------------------

function OrganizItem:init()

    self._widget = GuildDataProxy:getInstance():getWidgetOriganItem():clone()
    self:setSize(CCSize(820,140))
    self:addChild(self._widget)

    local p_icon = self._widget:getChildByName("p_icon")
    self.imgLogo = GuildIcon:create()
    
    self.imgLogo:setPosition(ccp(p_icon:getPosition()))
    self._widget:addChild(self.imgLogo)

    self.btnPush = tolua.cast(self._widget:getChildByName("btn_push"),"Button")
    self.btnPush:addTouchEventListener(event_btn_push)

    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labDesc = tolua.cast(self._widget:getChildByName("lab_desc"),"Label")
    self.labTip = tolua.cast(self._widget:getChildByName("lab_tip"),"Label")
    self.labPopulation = tolua.cast(self._widget:getChildByName("lab_population"),"Label")
end

function OrganizItem:setData(vo)
    self.organizVo = vo
    self:update()
end

function OrganizItem:update()

    local organizVo = self.organizVo

    self.imgLogo:setId(organizVo.logoId)
    self.imgLogo:setLev(organizVo.lev)

    self.btnPush:setTag(organizVo.id)
    
    self.btnPush:setTitleText(JoinStatusName[ organizVo.status + 1])

    self.labName:setText(organizVo.name)
    self.labDesc:setText(Helper.insertnl(organizVo.desc,22,40))
    
    if organizVo.isActive == 0 then
        self.labTip:setVisible(false)
    else
        self.labTip:setText(string.format("%d級免申請加入",organizVo.freeLevel))
        self.labTip:setVisible(true)
    end

    self.labPopulation:setText("("..organizVo.population.."人)")
end

-----------------------------------------------------------------------------------------------------------------
--公会 条目 查找

OrganizItemFind = class("OrganizItemFind" ,function()
    return Layout:create()
end)
OrganizItemFind.__index = OrganizItemFind
OrganizItemFind._widget     = nil
OrganizItemFind.uiLayer    = nil
OrganizItemFind.organizVo = nil

function OrganizItemFind:create(organizVo)
    local ret = OrganizItemFind.new()
    ret:init(organizVo)
    return ret
end
----------------响应事件--------------------------------------------
local function event_btn_push_find(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        local _id = tolua.cast(pSender,"Button"):getTag()
        local organizVo = GuildDataProxy:getInstance():getFindGuildVoById(_id)
       
        local netTask = GuildNetTask:getInstance()

        if organizVo.status == JoinStatus.APPLY_JOIN then
            netTask:requestAppleJoinOrganiz(_id)
        elseif organizVo.status == JoinStatus.QUICI_JOIN then
            netTask:requestQuickJoinOrganiz(_id)
        elseif organizVo.status == JoinStatus.CANCEL_APPLY then
            netTask:requestCanelApply(_id)
        end
    end
end

---------------初始化-----------------------------------------------------
function OrganizItemFind:init(organizVo)

    self._widget = GuildDataProxy:getInstance():getWidgetOriganItem():clone()
    self:setSize(CCSize(820,140))
    self:addChild(self._widget)
    
    self.organizVo = organizVo
    self:update(self.organizVo)
    
    local p_icon = self._widget:getChildByName("p_icon")
    local imgLogo = GuildIcon:create()
    imgLogo:setId(organizVo.logoId)
    imgLogo:setLev(organizVo.lev)
    imgLogo:setPosition(ccp(p_icon:getPosition()))
    self._widget:addChild(imgLogo)

    -- Notifier.regist(OrganizEvent.CB_JOIN_ORGANIZ,function() self:update(self.organizVo) end)
end

function OrganizItemFind:update(organizVo)

    local btnPush = tolua.cast(self._widget:getChildByName("btn_push"),"Button")
    btnPush:setTag(organizVo.id)
    btnPush:addTouchEventListener(event_btn_push_find)
    btnPush:setTitleText(JoinStatusName[ organizVo.status + 1])

    local labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    labName:setText(organizVo.name)

    local labDesc = tolua.cast(self._widget:getChildByName("lab_desc"),"Label")
    labDesc:setText(organizVo.desc)

    local labTip = tolua.cast(self._widget:getChildByName("lab_tip"),"Label")
    if organizVo.isActive == 0 then
        labTip:setVisible(false)
    else
        labTip:setText(string.format("%d級免申請加入",organizVo.freeLevel))
        labTip:setVisible(true)
    end

    local labPopulation = tolua.cast(self._widget:getChildByName("lab_population"),"Label")
    labPopulation:setText("("..organizVo.population.."人)")

end
--------------------------------------------------------------
--内部公会 查看的 公会条目
GuildViewItem = class("GuildViewItem",function()
    return Layout:create()
end)
GuildViewItem.__index = GuildViewItem
GuildViewItem._widget     = nil
GuildViewItem.uiLayer     = nil
GuildViewItem.guildVo = nil

function GuildViewItem:create()
    local ret = GuildViewItem.new()
    ret:init()
    return ret
end
---------------初始化-----------------------------------------------------
function GuildViewItem:init()

    self._widget = GuildDataProxy:getInstance():getWidgetOriganItem():clone()
    self:setSize(CCSize(820,140))
    self:addChild(self._widget)

    self.labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    self.labDesc = tolua.cast(self._widget:getChildByName("lab_desc"),"Label")
    self.labTip = tolua.cast(self._widget:getChildByName("lab_tip"),"Label")

    self.labPopulation = tolua.cast(self._widget:getChildByName("lab_population"),"Label")
    self.btnPush = tolua.cast(self._widget:getChildByName("btn_push"),"Button")
    self.btnPush:setTouchEnabled(false)
    self.btnPush:setVisible(false)

    self.p_icon = self._widget:getChildByName("p_icon")
    self.imgLogo = GuildIcon:create()
    
    self.imgLogo:setPosition(ccp(self.p_icon:getPosition()))
    self._widget:addChild(self.imgLogo)
end

function GuildViewItem:setData(vo)
    self.guildVo = vo
    self:update()
end

function GuildViewItem:update()
    self.labName:setText(self.guildVo.name)
    self.labDesc:setText(Helper.insertnl(self.guildVo.desc,20,40))

    if self.guildVo.isActive == 0 then
        self.labTip:setVisible(false)
    else
        self.labTip:setText(string.format("%d級免申請加入",self.guildVo.freeLevel))
        self.labTip:setVisible(true)
    end

    self.labPopulation:setText("("..self.guildVo.population.."人)")

    self.imgLogo:setId(self.guildVo.logoId)
    self.imgLogo:setLev(self.guildVo.lev)
end
--------------------------------------------------------------
--公会战 申请条目
GuildSignupItem = class("GuildSignupItem",function()
    return Layout:create()
end)
GuildSignupItem.__index = GuildSignupItem
GuildSignupItem._widget     = nil
GuildSignupItem.uiLayer     = nil
GuildSignupItem.guildVo = nil

function GuildSignupItem:create()
    local ret = GuildSignupItem.new()
    ret:init()
    return ret
end

function GuildSignupItem:init()
    self._widget = GuildDataProxy:getInstance():getWidgetFightSignupItem():clone()
    self:setSize(CCSize(820,140))
    self:addChild(self._widget)
end