--公会 渲染助手
GuildRenderMgr = class("GuildRenderMgr")
GuildRenderMgr.dic = nil
GuildRenderMgr.showBossIdx = 1

local __instance = nil
local _allowInstance = false

function GuildRenderMgr:ctor()
    if not _allowInstance then
		error("GuildRenderMgr is a singleton class")
	end
	self:init()
end

function GuildRenderMgr:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = GuildRenderMgr.new()
		_allowInstance = false
	end

	return __instance
end

function GuildRenderMgr:destoryInstance()

	_allowInstance = false
	__instance = nil
end

function GuildRenderMgr:init()
	
	require "GuildDataProxy"
	require "OrganizItem"
	require "MemberItem"
	require "GivePhysicalItem"
	require "OrganizApplyItem"
	require "EditMemberItem"
	require "GuildBossItem"
	require "GuildRecordItem"
	require "GuildAuctionItem"
	require "GuildLogItem"
	require "GuildFightScene"
	require "GuildFightPlayerItem"

	self.dic = CCDictionary:create() --缓存
	self.dic:retain()
end

------------------------------------------------------------------------------------
local function _sortMemeberFunc(voList)
	local tmpMasterClazzVoList = {}
	local tmpNormalClazzVoList = {}
	for id,itemVo in pairs(voList) do
		if itemVo.clazz == ClazzType.Common then --平民
			table.insert(tmpNormalClazzVoList,itemVo)
		else
			table.insert(tmpMasterClazzVoList,itemVo) --有官位的
		end
	end
	--排序等级
	table.sort(tmpNormalClazzVoList,function(a,b)
		return a.donateTotal > b.donateTotal
	end)
	table.sort(tmpMasterClazzVoList,function(a,b)
		return a.clazz > b.clazz or (a.clazz == b.clazz and a.donateTotal > b.donateTotal )
	end)
	local tmpList = {}
	for i=1,#tmpMasterClazzVoList do
		table.insert(tmpList,tmpMasterClazzVoList[i])
	end
	for i=1,#tmpNormalClazzVoList do
		table.insert(tmpList,tmpNormalClazzVoList[i])
	end
	return tmpList
end

local function _sortMemberEditFunc(voList)
	local tmpMasterClazzVoList = {}
	local tmpNormalClazzVoList = {}
	for id,itemVo in pairs(voList) do
		-- print(" itemVo.role_id:match( CharacterManager:getInstance():getLoginData():getRoleId() ) ",itemVo.role_id:match( CharacterManager:getInstance():getLoginData():getRoleId() ))
		if itemVo.role_id:match( CharacterManager:getInstance():getLoginData():getRoleId() ) == false then--排除自己账号
			if itemVo.clazz == ClazzType.Common then --平民
				table.insert(tmpNormalClazzVoList,itemVo)
			else
				table.insert(tmpMasterClazzVoList,itemVo) --有官位的
			end
		end
	end
	--排序等级
	table.sort(tmpNormalClazzVoList,function(a,b)
		return a.donateTotal > b.donateTotal
	end)
	table.sort(tmpMasterClazzVoList,function(a,b)
		return a.clazz > b.clazz or (a.clazz == b.clazz and a.donateTotal > b.donateTotal )
	end)
	local tmpRenderVoList = {}
	for i=1,#tmpMasterClazzVoList do
		table.insert(tmpRenderVoList,tmpMasterClazzVoList[i])
	end
	for i=1,#tmpNormalClazzVoList do
		table.insert(tmpRenderVoList,tmpNormalClazzVoList[i])
	end
	return tmpRenderVoList
end

local function _sortAuctionFunc(voList)
	local tmpRenderList = {}
	local tmpArr1 = {}
	local tmpArr2 = {}
	local tmpArr3 = {}
	for k,v in pairs(voList) do
		if v.status == AuctionStatus.Normal then
			table.insert(tmpArr1,v)
		elseif v.status == AuctionStatus.HadBeen then
			table.insert(tmpArr2,v)
		elseif v.status == AuctionStatus.Forbid then
			table.insert(tmpArr3,v)
		end
	end
	table.sort(tmpArr1, function(a,b)
		return a.time < b.time
	end)
	table.sort(tmpArr2, function(a,b)
		return a.time < b.time
	end)
	table.sort(tmpArr3, function(a,b)
		return a.time < b.time
	end)
	for i=1,#tmpArr1 do
		table.insert(tmpRenderList,tmpArr1[i])
	end
	for i=1,#tmpArr2 do
		table.insert(tmpRenderList,tmpArr2[i])
	end
	for i=1,#tmpArr3 do
		table.insert(tmpRenderList,tmpArr3[i])
	end
	return tmpRenderList
end

local function _sortMemberGuildFunc(voList)
	local tmpList = {}
	for id,itemVo in pairs(voList) do
		table.insert(tmpList,itemVo)
	end
	--排序等级
	table.sort(tmpList,function(a,b)
		return a.lev > b.lev or (a.lev == b.lev and a.donateTodayAdd > b.donateTodayAdd)
	end)
	return tmpList
end

local function _sortGuildLogFunc(voList)
	local tmpList = {}
	for id,itemVo in pairs(voList) do
		table.insert(tmpList,itemVo)
	end
	table.sort(tmpList,function(a,b)
		return a.id > b.id
	end)
	return tmpList
end

local function _sortGloryLog(voList,voTitle)
	local tmpList = {}

	local tmpTitleTbl = {}
	for k,v in pairs(voTitle) do
		table.insert(tmpTitleTbl,v)
	end
	table.sort(tmpTitleTbl,function(a,b) return a.id > b.id end)

	local sortTbl = {} --分类 
	for i=1,#tmpTitleTbl do
		for k,v in pairs(voList) do
			if v.time == tmpTitleTbl[i].id then
				sortTbl[v.time] = sortTbl[v.time] or {}
				table.insert(sortTbl[v.time],v)
			end
		end
	end

	for i=1,#tmpTitleTbl do
		local v = tmpTitleTbl[i]
		table.insert( tmpList, v )
		for j=1,#sortTbl[v.id] do
			local item = sortTbl[v.id][j]
			table.insert( tmpList , item )
		end
	end
	return tmpList
end

local function _sortFightMyTeamFunc(voPlayer,voArea)
	local tmpList = {}
	local tmpArr1 = {}
	local tmpArr2 = {}
	local tmpArr3 = {}
	local tmpArr4 = {}

	for k,areaVo in pairs(voArea) do
		if areaVo.t == GuildFightArea.Protect then
			table.insert(tmpArr1,areaVo)
		elseif areaVo.t == GuildFightArea.Power then
			table.insert(tmpArr2,areaVo)
		elseif areaVo.t == GuildFightArea.Defense then
			table.insert(tmpArr3,areaVo)
		elseif areaVo.t == GuildFightArea.Common then
			table.insert(tmpArr4,areaVo)
		end
	end

	for k,playerVo in pairs(voPlayer) do
		if playerVo.guild_fight_area == GuildFightArea.Protect then
			table.insert(tmpArr1,playerVo)
		elseif playerVo.guild_fight_area == GuildFightArea.Power then
			table.insert(tmpArr2,playerVo)
		elseif playerVo.guild_fight_area == GuildFightArea.Defense then
			table.insert(tmpArr3,playerVo)
		elseif playerVo.guild_fight_area == GuildFightArea.Common then
			table.insert(tmpArr4,playerVo)
		end
	end

	table.sort( tmpArr1, function(a,b)
		if a.guild_fight_regional_time ~= nil and b.guild_fight_regional_time ~= nil then
			return a.guild_fight_regional_time < b.guild_fight_regional_time
		else
			return false
		end 
	end)

	table.sort( tmpArr2, function(a,b)
		if a.guild_fight_regional_time ~= nil and b.guild_fight_regional_time ~= nil then
			return a.guild_fight_regional_time > b.guild_fight_regional_time
		else
			return false
		end
	end)

	table.sort( tmpArr3, function(a,b)
		if a.guild_fight_regional_time ~= nil and b.guild_fight_regional_time ~= nil then
			return a.guild_fight_regional_time > b.guild_fight_regional_time
		else
			return false
		end
	end)

	table.sort( tmpArr4, function(a,b) 
		if a.fight_capacity ~= nil and b.fight_capacity ~= nil then
			return a.fight_capacity > b.fight_capacity 
		else
			return false
		end 
	end)
	
	for i=1,#tmpArr1 do
		table.insert(tmpList,tmpArr1[i])
	end
	for i=1,#tmpArr2 do
		table.insert(tmpList,tmpArr2[i])
	end
	for i=1,#tmpArr3 do
		table.insert(tmpList,tmpArr3[i])
	end
	for i=1,#tmpArr4 do
		table.insert(tmpList,tmpArr4[i])
	end
	return tmpList
end

local function _sortFightAllCombatFunc(voList,voTitle)
	local tmpList = {}

	local tmpTitleTbl = {}
	for k,v in pairs(voTitle) do
		table.insert(tmpTitleTbl,v)
	end
	table.sort(tmpTitleTbl,function(a,b) return a.id < b.id end)

	local sortTbl = {} --分类 
	for i=1,#tmpTitleTbl do
		for k,v in pairs(voList) do
			if v.id == tmpTitleTbl[i].id then
				sortTbl[v.id] = sortTbl[v.id] or {}
				table.insert(sortTbl[v.id],v)
			end
		end
	end

	for i=1,#tmpTitleTbl do
		local v = tmpTitleTbl[i]
		table.insert( tmpList, v )
		for j=1,#sortTbl[v.id] do
			local item = sortTbl[v.id][j]
			table.insert( tmpList , item )
		end
	end
	return tmpList
end

local function _sortGuildScheFunc(voList)
	local tmpList = {}
	for id,itemVo in pairs(voList) do
		table.insert(tmpList,itemVo)
	end
	table.sort(tmpList,function(a,b)
		return a.id < b.id
	end)
	return tmpList
end

local function _sortGuildSignupFunc(voList)
	local tmpList = {}
	for id,itemVo in pairs(voList) do
		table.insert(tmpList,itemVo)
	end
	table.sort(tmpList,function(a,b)
		return a.id > b.id
	end)
	return tmpList
end

local function _sortGuildFightRankFunc(voList)
	local tmpList = {}
	for id,itemVo in pairs(voList) do
		table.insert(tmpList,itemVo)
	end
	table.sort(tmpList,function(a,b)
		return a.rank < b.rank
	end)
	return tmpList
end

local function _sortGuildIdRankFunc(voList)
	local tmpList = {}
	for id,itemVo in pairs(voList) do
		table.insert(tmpList,itemVo)
	end
	table.sort(tmpList,function(a,b)
		return a.id < b.id
	end)
	return tmpList
end
------------------------------------------------------------------------------------

--渲染 公会 列表
function GuildRenderMgr:renderOrganizList(listView)
	
	listView:removeAllItems() --先清理

	local dp = GuildDataProxy:getInstance()
	local voList = dp:getGuildVoList()

	local tmpList = {}
	for id,itemVo in pairs(voList) do
		table.insert(tmpList,itemVo)
	end
	--排序等级
	table.sort(tmpList,function(a,b)
		return a.lev > b.lev or (a.lev == b.lev and a.donateTodayAdd > b.donateTodayAdd)
	end)

	local idx = 0
	local function step_create()
		idx = idx + 1
		local itemVo = tmpList[ idx ]
		if itemVo ~= nil then
			local item = OrganizItem:create(itemVo)
			self.dic:setObject(item,string.format("guilditem_%d",itemVo.id))
			listView:pushBackCustomItem(item)
		else
			listView:stopAllActions()
		end
	end

	listView:stopAllActions()
	listView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
		CCCallFunc:create(step_create),
		CCDelayTime:create(0.05))))
end

--更新 公会 item
function GuildRenderMgr:updateOrganizItem(id) 

	local item = self.dic:objectForKey(string.format("guilditem_%d",id)) 
	local organizVo = GuildDataProxy:getInstance():getGuildVoById(id)
	if item then
		item:update(organizVo)
	end
end

function GuildRenderMgr:renderOrganizListAdapt(scrol)

	local dp = GuildDataProxy:getInstance()
	local voList = dp:getGuildVoList()
	local tmpList = _sortMemberGuildFunc(voList)
	scrol:setScrollHeight(math.max(#tmpList,2)) --刷新高度

	for i=1,#tmpList do
		local pos = nil
		if #tmpList < 3 then
			pos = ccp(0, scrol:getSize().height - 140 * i)
		else
			pos = ccp(0,140 * (#tmpList - i) )
		end
		local v = tmpList[i]
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,4 do
		local key = string.format("guilditem_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(OrganizItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refresGuildVoList(viewRect,scrol)
end

function GuildRenderMgr:refresGuildVoList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getGuildVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,4,"guilditem_%d",_sortMemberGuildFunc(voList),scrol,820,140,rect)
end

function GuildRenderMgr:updateRecordItem(idx)
	local item = self.dic:objectForKey(string.format("recorditem_%d",idx))
	if item then
		item:update()
	end
end

--渲染 查找公会 条目
GuildRenderMgr.renderFindList = function(listView)
	
	listView:removeAllItems() --先清理

	local dp = GuildDataProxy:getInstance()
	local voList = dp:getFindGuildVoList()

	local tmpList = {}
	for id,itemVo in pairs(voList) do
		table.insert(tmpList,id)
	end

	local idx = 0
	local function step_create()
		idx = idx + 1
		local itemVo = dp:getFindGuildVoById( tmpList[idx] )
		if itemVo ~= nil then
			local item = OrganizItemFind:create(itemVo)
			__instance.dic:setObject(item,string.format("finditem_%d",idx))
			listView:pushBackCustomItem(item)
		else
			listView:stopAllActions()
		end
	end

	listView:stopAllActions()
	listView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
		CCCallFunc:create(step_create),
		CCDelayTime:create(0.05))))
end

function GuildRenderMgr:updateFindOrganizItem(id)
	local item = self.dic:objectForKey(string.format("finditem_%d",id)) 
	local organizVo = GuildDataProxy:getInstance():getFindGuildVoById(id)
	item:update(organizVo)
end

---------------------------------------------------------------------------------------------
--渲染 成员 条目
GuildRenderMgr.renderMemberList = function(listView)
	
	local dp = GuildDataProxy:getInstance()
	local voList = dp:getPlayerVoList()
	
	local tmpMasterClazzVoList = {}
	local tmpNormalClazzVoList = {}
	for id,itemVo in pairs(voList) do
		if itemVo.clazz == ClazzType.Common then --平民
			table.insert(tmpNormalClazzVoList,itemVo)
		else
			table.insert(tmpMasterClazzVoList,itemVo) --有官位的
		end
	end
	--排序等级
	table.sort(tmpNormalClazzVoList,function(a,b)
		return a.donateTotal > b.donateTotal
	end)
	table.sort(tmpMasterClazzVoList,function(a,b)
		return a.clazz > b.clazz or (a.clazz == b.clazz and a.donateTotal > b.donateTotal )
	end)
	local tmpRenderVoList = {}
	for i=1,#tmpMasterClazzVoList do
		table.insert(tmpRenderVoList,tmpMasterClazzVoList[i])
	end
	for i=1,#tmpNormalClazzVoList do
		table.insert(tmpRenderVoList,tmpNormalClazzVoList[i])
	end

	local idx = 0
	local function step_create()
		idx = idx + 1
		local itemVo = tmpRenderVoList[idx]
		if itemVo ~= nil then
			local item = MemberItem:create(itemVo)
			listView:pushBackCustomItem(item)
		else
			listView:stopAllActions()
		end
	end

	listView:removeAllItems() --先清理
	listView:stopAllActions()
	listView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
		CCCallFunc:create(step_create),
		CCDelayTime:create(0.05))))

end

function GuildRenderMgr:renderMemberListAdapt(scrol)
	local dp = GuildDataProxy:getInstance()
	local voList = dp:getPlayerVoList()
	local tmpList = _sortMemeberFunc(voList)
	scrol:setScrollHeight(math.max(#tmpList,3)) --刷新高度

	for i=1,#tmpList do
		local pos = nil
		if #tmpList < 3 then
			pos = ccp(0, scrol:getSize().height - 116 * i)
		else
			pos = ccp(0,116 * (#tmpList - i) )
		end
		local v = tmpList[i]
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,4 do
		local key = string.format("memberitem_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(MemberItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshViewMemberVoList(viewRect,scrol)
end
function GuildRenderMgr:refreshViewMemberVoList(rect,scrol)
	local voList = GuildDataProxy:getInstance():getPlayerVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,4,"memberitem_%d",_sortMemeberFunc(voList),scrol,540,116,rect)
end

--渲染 互赠体力 条目
GuildRenderMgr.renderGivePhysicalList = function(listView)
	
	local dp = GuildDataProxy:getInstance()
	local voList = dp:getPlayerVoList()

	local tmpList = {}
	for id,itemVo in pairs(voList) do
		table.insert(tmpList,id)
	end

	local idx = 0
	local function step_create()
		idx = idx + 1
		local itemVo = dp:getPlayerVoById( tmpList[idx] )
		if itemVo ~= nil then
			if itemVo.role_id:match( CharacterManager:getInstance():getLoginData():getRoleId() ) == false then
				local item = GiveItem:create(itemVo)
				__instance.dic:setObject(item,string.format("giveitem_%s",itemVo.id))
				listView:pushBackCustomItem(item)
			end
		else
			listView:stopAllActions()
		end
	end

	listView:removeAllItems() --先清理
	listView:stopAllActions()
	listView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
		CCCallFunc:create(step_create),
		CCDelayTime:create(0.05))))
end

function GuildRenderMgr:updateGiveItem(id)
	local item = self.dic:objectForKey(string.format("giveitem_%s",id)) 
	local itemVo = GuildDataProxy:getInstance():getPlayerVoById( id )
	item:update(itemVo)
end

-----------------------------------------------------------------------------------
-- --渲染 成员管理 条目
-- GuildRenderMgr.renderEditMemberList = function(listView)
	
-- 	local dp = GuildDataProxy:getInstance()
-- 	local voList = dp:getPlayerVoList()

-- 	local tmpMasterClazzVoList = {}
-- 	local tmpNormalClazzVoList = {}
-- 	for id,itemVo in pairs(voList) do
-- 		if itemVo.clazz == ClazzType.Common then --平民
-- 			table.insert(tmpNormalClazzVoList,itemVo)
-- 		else
-- 			table.insert(tmpMasterClazzVoList,itemVo) --有官位的
-- 		end
-- 	end
-- 	--排序等级
-- 	table.sort(tmpNormalClazzVoList,function(a,b)
-- 		return a.donateTotal > b.donateTotal
-- 	end)
-- 	table.sort(tmpMasterClazzVoList,function(a,b)
-- 		return a.clazz > b.clazz or (a.clazz == b.clazz and a.donateTotal > b.donateTotal )
-- 	end)
-- 	local tmpRenderVoList = {}
-- 	for i=1,#tmpMasterClazzVoList do
-- 		table.insert(tmpRenderVoList,tmpMasterClazzVoList[i])
-- 	end
-- 	for i=1,#tmpNormalClazzVoList do
-- 		table.insert(tmpRenderVoList,tmpNormalClazzVoList[i])
-- 	end

-- 	local idx = 0
-- 	local function step_create()
-- 		idx = idx + 1
-- 		local itemVo = tmpRenderVoList[idx]
-- 		if itemVo ~= nil then
-- 			if itemVo.id ~= CharacterManager:getInstance():getLoginData():getAcctId() then
-- 				local item = EditMemberItem:create(itemVo)
-- 				listView:pushBackCustomItem(item)
-- 			end
-- 		else
-- 			listView:stopAllActions()
-- 		end
-- 	end

-- 	listView:removeAllItems() --先清理
-- 	listView:stopAllActions()
-- 	listView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
-- 		CCCallFunc:create(step_create),
-- 		CCDelayTime:create(0.05))))
-- end
--渲染 成员管理 条目
function GuildRenderMgr:renderEditMemberListAdapt(scrol)

	local voList = GuildDataProxy:getInstance():getPlayerVoList()
	local tmpList = _sortMemberEditFunc(voList)
	if #tmpList < 4 then--刷新高度
		scrol:setScrollHeight(math.max(#tmpList,4))
	else
		scrol:setScrollHeight(#tmpList)
	end
	for i=1,#tmpList do
		if #tmpList < 4 then
			pos = ccp(0, scrol:getInnerContainer():getSize().height - 140 * i)
		else
			pos = ccp(0,140 * (#tmpList - i) )
		end
		local v = tmpList[i]
		v.posEditX = pos.x 
		v.posEditY = pos.y
	end

	for i=1,4 do
		local key = string.format("editmember_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(EditMemberItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),880,360)
    self:refreshViewEditVoList(viewRect,scrol)
end
function GuildRenderMgr:refreshViewEditVoList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getPlayerVoList()
	local tmpList = _sortMemberEditFunc(voList)
	scrol:setScrollHeight(math.max(#tmpList,3))
	for i=1,#tmpList do
		if #tmpList < 3 then
			pos = ccp(0, scrol:getInnerContainer():getSize().height - 140 * i)
		else
			pos = ccp(0,140 * (#tmpList - i) )
		end
		local v = tmpList[i]
		v.posEditX = pos.x 
		v.posEditY = pos.y
	end

	local ret = {}
	for i=1,#tmpList do
		local v = tmpList[i]
		if rect:intersectsRect(CCRectMake(v.posEditX,v.posEditY,880,140)) then
			table.insert(ret,v)
		end
	end

	for i=1,4 do
		local item = self.dic:objectForKey(string.format("editmember_%d",i))
		if item then
			local v = ret[i]
			if v ~= nil then
				item:setPosition(ccp(v.posEditX,v.posEditY))
				item:setData(v)
				if item:getParent() == nil then
					scrol:addChild(item)
				end
			else
				item:removeFromParentAndCleanup(false)
			end
		end
	end

end

--渲染 申请 条目
GuildRenderMgr.renderApplyList = function(listView)
	
	listView:removeAllItems() --先清理
	local dp = GuildDataProxy:getInstance()
	local voList = dp:getApplyVoList()

	local tmpList = {}
	for id,itemVo in pairs(voList) do
		table.insert(tmpList,id)
	end

	local idx = 0
	local function step_create()
		idx = idx + 1
		local itemVo = dp:getApplyVoById( tmpList[idx] )
		if itemVo ~= nil then
			local item = ApplyItem:create(itemVo)
			listView:pushBackCustomItem(item)
		else
			listView:stopAllActions()
		end
	end

	listView:stopAllActions()
	listView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
		CCCallFunc:create(step_create),
		CCDelayTime:create(0.05))))
end

--渲染Boss
function GuildRenderMgr:renderBossList(listView)
	local dp = GuildDataProxy:getInstance()
	local tmpList = dp.bossVoTblList

	local arr = CCArray:create()
	for i=1,#tmpList do
		local key = string.format("bossitem_%d",tmpList[i].id)
 		local item = self.dic:objectForKey(key)
 		if item == nil then
			arr:addObject(CCDelayTime:create(0.2))
		end
		arr:addObject(CCCallFunc:create(function()
	 		local item = self.dic:objectForKey(key)
 			if item == nil then
				item = GuildBossBigItem:create()
				item:setData( dp:getBossVoById(tmpList[i].id) )
				self.dic:setObject(item,key)
			end
			item:update()
			listView:pushBackCustomItem(item)
		end))
	end
	listView:removeAllItems()
	listView:stopAllActions()
	listView:runAction(CCSequence:create(arr))
end

--渲染竞拍列表
function GuildRenderMgr:renderAuctionListAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getAuctionVoList()
	local tmpRenderList = _sortAuctionFunc(voList)
	scrol:setInnerHeightWithList(tmpRenderList) --刷新高度

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpRenderList do
		local v = tmpRenderList[i]
		coutHeight = coutHeight + v.height
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,4 do
		local key = string.format("auctionitem_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildAuctionItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshViewAuctionVoList(viewRect,scrol)
end
function GuildRenderMgr:refreshViewAuctionVoList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getAuctionVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,4,"auctionitem_%d",_sortAuctionFunc(voList),scrol,850,142,rect)
end

--渲染竞拍列表
function GuildRenderMgr:renderMyAuctionListAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getMyAuctionVoList()
	local tmpRenderList = _sortAuctionFunc(voList)
	scrol:setInnerHeightWithList(tmpRenderList) --刷新高度

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpRenderList do
		local v = tmpRenderList[i]
		coutHeight = coutHeight + v.height
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,4 do
		local key = string.format("myauctionitem_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildMyAuctionItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshViewMyAuctionVoList(viewRect,scrol)
end
function GuildRenderMgr:refreshViewMyAuctionVoList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getMyAuctionVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,4,"myauctionitem_%d",_sortAuctionFunc(voList),scrol,850,142,rect)
end

--渲染 内部成员公会 列表
function GuildRenderMgr:renderMemberGuildListAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getGuildViewVoList()
	local tmpList = _sortMemberGuildFunc(voList)
	scrol:setScrollHeight(math.max(#tmpList,3)) --刷新高度

	for i=1,#tmpList do
		local pos = nil
		if #tmpList < 4 then
			pos = ccp(0, scrol:getSize().height - 140 * i)
		else
			pos = ccp(0,140 * (#tmpList - i) )
		end
		local v = tmpList[i]
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,4 do
		local key = string.format("memberguild_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildViewItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshViewGuildViewVoList(viewRect,scrol)
end
function GuildRenderMgr:refreshViewGuildViewVoList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getGuildViewVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,4,"memberguild_%d",_sortMemberGuildFunc(voList),scrol,820,140,rect)
end

--渲染竞拍 个人、公会 记录
function GuildRenderMgr:renderRecordList(listView)

	local dp = GuildDataProxy:getInstance()
	local tmpList = {}
	local myLen = 0
	for k,v in pairs( dp:getMyRecordVoList()) do
		table.insert(tmpList,v)
	end
	myLen = #tmpList
	for k,v in pairs( dp:getGuildRecordVoList()) do
		table.insert(tmpList,v)
	end
	-- table.sort(tmpList, function(a,b)
	-- 	return a.id < b.id
	-- end)
	local idx = 0
	local function step_create()

		if idx == 0 then
			listView:pushBackCustomItem( GuildRecordTitleItem:create("我的競拍") )
		end
		if idx == myLen then
			listView:pushBackCustomItem( GuildRecordTitleItem:create("公會競拍") )
		end
		idx = idx + 1
		local itemVo = tmpList[idx]
		if itemVo ~= nil then
			local item = GuildRecordItem:create(itemVo)
			self.dic:setObject(item,string.format("recorditem_%d",idx))
			listView:pushBackCustomItem(item)
		else
			listView:stopAllActions()
		end
	end

	listView:removeAllItems()
	listView:stopAllActions()
	listView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
		CCCallFunc:create(step_create),
		CCDelayTime:create(0.2))))
end

--渲染技能
function GuildRenderMgr:renderSkillList(scroll,func)
	
	local function createPosArr(len)
		local col = 3
		local row = math.ceil(len / 3)
		local ret = {}

		local baseX = 80
		local baseY = 80

		local idx = 0
		for i=0,row - 1 do

			for j=0,col - 1 do
				idx = idx + 1

				local height = 130
				local width = 130

				table.insert(ret, { x = baseX + j * width , y = baseY + (row - i - 1) * height })
			end
		end
		return ret
	end

	local dp = GuildDataProxy:getInstance()
	local canLearnTbl = dp:getCanLearnSkillTbl()
	local tmpList = {}
	for skill_id,v in pairs( dp:getSkillDescVoList()) do
		table.insert(tmpList,skill_id)
	end
	table.sort(tmpList, function(a,b)
		return a < b
	end)

	local posArr = createPosArr(#tmpList)

	local arr = CCArray:create()
	for i=1,#tmpList do

		local key = string.format("skillitem_%d",tmpList[i])
 		local item = self.dic:objectForKey(key)
 		if item == nil then
			arr:addObject(CCDelayTime:create(0.1))
		end
		arr:addObject(CCCallFunc:create(function()
	 		local item = self.dic:objectForKey(key)
	 		local lev = 0
			if dp:getMeSkillVoById(tmpList[i]) ~= nil then
				lev = dp:getMeSkillVoById(tmpList[i]).lev
			end
 			if item == nil then
				item = GuildSkillIcon:create() 
				item:setId(tmpList[i])
				item:setPosition(ccp(posArr[i].x,posArr[i].y))
				item:setClickEvent(func)
				self.dic:setObject(item,key)
			end
			item:setLev(lev)
			scroll:addChild(item)
			--处理绿点
			if canLearnTbl[ tmpList[i] ] ~= nil then
				Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_NEW_TIPS_SKILL_SHOW,tmpList[i])
			else
				Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_NEW_TIPS_SKILL_HIDE,tmpList[i])
			end
		end))
	end

	scroll:removeAllChildrenWithCleanup(true)
	scroll:stopAllActions()
	scroll:runAction(CCSequence:create(arr))
end

--渲染Boss 伤害排行
function GuildRenderMgr:renderBossHurtList(listView,boss_id)

	local dp = GuildDataProxy:getInstance()
	local tmpList = dp:getBossVoById(boss_id).hurtList
	table.sort(tmpList, function(a,b)
		return a.att > b.att
	end)

	local idx = 0
	local function step_create()
		idx = idx + 1
		local itemVo = tmpList[idx]
		if itemVo ~= nil then
			itemVo.id = idx
			local item = GuildBossHurtItem:create(itemVo)
			listView:pushBackCustomItem(item)
		else
			listView:stopAllActions()
		end
	end

	listView:removeAllItems()
	listView:stopAllActions()
	listView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
		CCCallFunc:create(step_create),
		CCDelayTime:create(0.1))))
end

--渲染内部公会 查看公会 列表
function GuildRenderMgr:renderAllMemberGuild(listView)

	listView:removeAllItems() --先清理

	local dp = GuildDataProxy:getInstance()
	local voList = dp:getGuildViewVoList()

	local tmpList = {}
	for id,itemVo in pairs(voList) do
		table.insert(tmpList,itemVo)
	end
	--排序等级
	table.sort(tmpList,function(a,b)
		return a.lev > b.lev or (a.lev == b.lev and a.donateTodayAdd > b.donateTodayAdd)
	end)

	local idx = 0
	local function step_create()
		idx = idx + 1
		local itemVo = tmpList[ idx ]
		if itemVo ~= nil then
			local item = GuildViewItem:create(itemVo)
			listView:pushBackCustomItem(item)
		else
			listView:stopAllActions()
		end
	end

	listView:stopAllActions()
	listView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
		CCCallFunc:create(step_create),
		CCDelayTime:create(0.1))))
end

--渲染公会战 报名 列表
function GuildRenderMgr:renderFightSignupListAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getFightSignupVoList()
	local tmpList = _sortGuildSignupFunc(voList)
	scrol:setInnerHeightWithList(tmpList) --刷新高度

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + 144
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,4 do
		local key = string.format("fightSignup_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildFightSignupItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshFightSignupVoList(viewRect,scrol)
end
function GuildRenderMgr:refreshFightSignupVoList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getFightSignupVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,4,"fightSignup_%d",_sortGuildSignupFunc(voList),scrol,844,144,rect)
end

--渲染公会战 结果 排名列表
function GuildRenderMgr:renderFinishRankAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getAllCombatRankVoList()
	local tmpList = _sortGuildFightRankFunc(voList)
	scrol:setInnerHeightWithList(tmpList) --刷新高度

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + 82
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,4 do
		local key = string.format("fightRank_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildFightBattleRankItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshFinishRankList(viewRect,scrol)
end
function GuildRenderMgr:refreshFinishRankList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getAllCombatRankVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,4,"fightRank_%d",_sortGuildFightRankFunc(voList),scrol,840,82,rect)
end

--渲染公会 日志 列表
function GuildRenderMgr:renderGuildLogListAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getFightSignupVoList()
	local tmpList = _sortMemberGuildFunc(voList)
	scrol:setScrollHeight(math.max(#tmpList,4)) --刷新高度

	for i=1,#tmpList do
		local pos = nil
		if #tmpList < 4 then
			pos = ccp(0, scrol:getSize().height - 140 * i)
		else
			pos = ccp(0,140 * (#tmpList - i) )
		end
		local v = tmpList[i]
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,4 do
		local key = string.format("guildlog_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildLogItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshGuildLogList(viewRect,scrol)
end
function GuildRenderMgr:refreshGuildLogList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getGuildLogVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,4,"guildlog_%d",_sortGuildLogFunc(voList),scrol,820,140,rect)
end

--初始化 公会战 对手列表区域
function GuildRenderMgr:initFightEnemyScrol(scrol)
	if scrol.bgProtect == nil then
		scrol.bgProtect = ImageView:create()
        scrol.bgProtect:setScale9Enabled(true)
        scrol.bgProtect:setSize(CCSize(309,130))
        scrol.bgProtect:setCapInsets(CCRect(25,20,15,20))
        scrol.bgProtect:setAnchorPoint(ccp(0,0))
        scrol.bgProtect:loadTexture("bg_14.png",UI_TEX_TYPE_PLIST)
        scrol.bgProtect:setVisible(false)
        scrol:addChild(scrol.bgProtect)
	end
	if scrol.bgPower == nil then
		scrol.bgPower = ImageView:create()
        scrol.bgPower:setScale9Enabled(true)
        scrol.bgPower:setSize(CCSize(309,130))
        scrol.bgPower:setCapInsets(CCRect(25,20,15,20))
        scrol.bgPower:setAnchorPoint(ccp(0,0))
        scrol.bgPower:loadTexture("bg_14.png",UI_TEX_TYPE_PLIST)
        scrol.bgPower:setVisible(false)
        scrol:addChild(scrol.bgPower)
	end
	if scrol.bgDefense == nil then
		scrol.bgDefense = ImageView:create()
        scrol.bgDefense:setScale9Enabled(true)
        scrol.bgDefense:setSize(CCSize(309,130))
        scrol.bgDefense:setCapInsets(CCRect(25,20,15,20))
        scrol.bgDefense:setAnchorPoint(ccp(0,0))
        scrol.bgDefense:loadTexture("bg_14.png",UI_TEX_TYPE_PLIST)
        scrol.bgDefense:setVisible(false)
        scrol:addChild(scrol.bgDefense)
	end
	if scrol.bgCommon == nil then
		scrol.bgCommon = ImageView:create()
        scrol.bgCommon:setScale9Enabled(true)
        scrol.bgCommon:setSize(CCSize(309,130))
        scrol.bgCommon:setCapInsets(CCRect(25,20,15,20))
        scrol.bgCommon:setAnchorPoint(ccp(0,0))
        scrol.bgCommon:loadTexture("bg_14.png",UI_TEX_TYPE_PLIST)
        scrol.bgCommon:setVisible(false)
        scrol:addChild(scrol.bgCommon)
	end
end

function GuildRenderMgr:refreshFightHeroBg(scrol,t)

	local dp = GuildDataProxy:getInstance()
	local commHeight = dp:getFightTeamAreaHeight(GuildFightArea.Common,t)
	local protectHeight = dp:getFightTeamAreaHeight(GuildFightArea.Protect,t)
	local powerHeight = dp:getFightTeamAreaHeight(GuildFightArea.Power,t)
	local defenseHeight = dp:getFightTeamAreaHeight(GuildFightArea.Defense,t)

	scrol.bgProtect:setSize(CCSize(880,protectHeight))
	scrol.bgPower:setSize(CCSize(880,powerHeight))
	scrol.bgDefense:setSize(CCSize(880,defenseHeight))
	scrol.bgCommon:setSize(CCSize(880,commHeight))
	scrol.bgProtect:setVisible(true)
	scrol.bgPower:setVisible(true)
	scrol.bgDefense:setVisible(true)
	scrol.bgCommon:setVisible(true)

	local offsetY = -10
	local offsetX = 0

	local size = scrol:getInnerContainerSize()
	scrol.bgProtect:setPosition(ccp(offsetX,size.height - protectHeight + offsetY))
	scrol.bgPower:setPosition(ccp(offsetX,size.height - protectHeight - powerHeight + offsetY))
	scrol.bgDefense:setPosition(ccp(offsetX,size.height - protectHeight - powerHeight - defenseHeight + offsetY))
	scrol.bgCommon:setPosition(ccp(offsetX, size.height - protectHeight - powerHeight - defenseHeight - commHeight + offsetY))
end

--渲染 公会战 我方 战队镜像列表
function GuildRenderMgr:renderFightPlayerListAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getFightMyTeamVoList()
	local voArea = GuildDataProxy:getInstance():getFightMyAreaVoList()
	local tmpList = _sortFightMyTeamFunc(voList,voArea)
	scrol:setInnerHeightWithList(tmpList) --刷新高度

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + v.height
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	self:refreshFightHeroBg(scrol,GuildFightTeamStatus.MyTeam)
	for i=1,4 do
		local key = string.format("fightarea_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildFightAreaTitle:create(),key)
		end
	end

	for i=1,6 do
		local key = string.format("fightplayer_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildFightPlayerItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshFightPlayerVoList(viewRect,scrol)
end	

function GuildRenderMgr:refreshFightPlayerVoList(rect,scrol)
	local voList = GuildDataProxy:getInstance():getFightMyTeamVoList()
	local voArea = GuildDataProxy:getInstance():getFightMyAreaVoList()
	local viewVoList = _sortFightMyTeamFunc(voList,voArea)

	local ret = {}
	for i=1,#viewVoList do
		local v = viewVoList[i]
		if rect:intersectsRect(CCRectMake(v.posX,v.posY,880,v.height)) then
			table.insert(ret,v)
		end
	end

	for i=1,4 do
		local item = self.dic:objectForKey(string.format("fightarea_%d",i))
		item:removeFromParentAndCleanup(false)
	end
	for i=1,6 do
		local item = self.dic:objectForKey(string.format("fightplayer_%d",i))
		item:removeFromParentAndCleanup(false)
	end

	local idx1 = 1
	local idx2 = 1
	for i=1,#ret do
		local v = ret[i]
		if v.widget == "fightarea_" then
			local item = self.dic:objectForKey(string.format(v.widget.."%d",idx1))
			if item then
				if item:getParent() == nil then
					scrol:addChild(item)
				end
				item:setPosition(ccp(v.posX,v.posY))
				item:setData(v)
				idx1 = idx1 + 1
			end
		elseif v.widget == "fightplayer_" then
			local item = self.dic:objectForKey(string.format(v.widget.."%d",idx2))
			if item then
				if item:getParent() == nil then
					scrol:addChild(item)
				end
				item:setPosition(ccp(v.posX,v.posY))
				item:setData(v)
				idx2 = idx2 + 1
			end
		end
	end
end

--渲染 公会战 敌方 战队镜像列表
function GuildRenderMgr:renderFightEnemyListAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getFightEnemyVoList()
	local voArea = GuildDataProxy:getInstance():getFightEnemyAreaVoList()
	local tmpList = _sortFightMyTeamFunc(voList,voArea)
	scrol:setInnerHeightWithList(tmpList) --刷新高度

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + v.height
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	self:refreshFightHeroBg(scrol,GuildFightTeamStatus.EnemyTeam)
	for i=1,4 do
		local key = string.format("fightarea_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildFightAreaTitle:create(),key)
		end
	end

	for i=1,6 do
		local key = string.format("fightplayer_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildFightPlayerItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshFightEnemyList(viewRect,scrol)
end	

function GuildRenderMgr:refreshFightEnemyList(rect,scrol)
	local voList = GuildDataProxy:getInstance():getFightEnemyVoList()
	local voArea = GuildDataProxy:getInstance():getFightEnemyAreaVoList()
	local viewVoList = _sortFightMyTeamFunc(voList,voArea)
	local ret = {}
	for i=1,#viewVoList do
		local v = viewVoList[i]
		if rect:intersectsRect(CCRectMake(v.posX,v.posY,880,v.height)) then
			table.insert(ret,v)
		end
	end

	for i=1,4 do
		local item = self.dic:objectForKey(string.format("fightarea_%d",i))
		item:removeFromParentAndCleanup(false)
	end
	for i=1,6 do
		local item = self.dic:objectForKey(string.format("fightplayer_%d",i))
		item:removeFromParentAndCleanup(false)
	end

	local idx1 = 1
	local idx2 = 1
	for i=1,#ret do
		local v = ret[i]
		if v.widget == "fightarea_" then
			local item = self.dic:objectForKey(string.format(v.widget.."%d",idx1))
			if item:getParent() == nil then
				scrol:addChild(item)
			end
			item:setPosition(ccp(v.posX,v.posY))
			item:setData(v)
			idx1 = idx1 + 1
		elseif v.widget == "fightplayer_" then
			local item = self.dic:objectForKey(string.format(v.widget.."%d",idx2))
			if item:getParent() == nil then
				scrol:addChild(item)
			end
			item:setPosition(ccp(v.posX,v.posY))
			item:setData(v)
			idx2 = idx2 + 1
		end
	end
end

--渲染 某个 公会的战绩
function GuildRenderMgr:renderGuildScoreList(listView)
	
	local dp = GuildDataProxy:getInstance()
	local voList = dp:getFightScoreList()
	local tmpList = _sortGuildIdRankFunc(voList)

	if #tmpList == 0 then return end

	local arr = CCArray:create()
	for i=1,#tmpList do
		local key = string.format("fightScore_%d",tmpList[i].id)
 		local item = self.dic:objectForKey(key)
 		if item == nil then
			arr:addObject(CCDelayTime:create(0.2))
		end
		arr:addObject(CCCallFunc:create(function()
	 		local item = self.dic:objectForKey(key)
 			if item == nil then
				item = GuildFightScoreItem:create()
				self.dic:setObject(item,key)
			end
			item:setData( dp:getFightScoreItemVoById(tmpList[i].id) )
			item:update()
			listView:pushBackCustomItem(item)
		end))
	end
	listView:removeAllItems()
	listView:stopAllActions()
	listView:runAction(CCSequence:create(arr))
end

-- --渲染 本公会 赛程
-- function GuildRenderMgr:renderGuildScheList(listView)
-- 	local dp = GuildDataProxy:getInstance()
-- 	local voList = dp:getFightScheItemVoList()
-- 	local tmpList = _sortGuildScheFunc(voList)

-- 	if #tmpList == 0 then return end

-- 	local arr = CCArray:create()
-- 	for i=1,#tmpList do
-- 		local key = string.format("scheItem_%d",tmpList[i].id)
--  		local item = self.dic:objectForKey(key)
--  		if item == nil then
-- 			arr:addObject(CCDelayTime:create(0.2))
-- 		end
-- 		arr:addObject(CCCallFunc:create(function()
-- 	 		local item = self.dic:objectForKey(key)
--  			if item == nil then
-- 				item = GuildFightScheItem:create()
-- 				self.dic:setObject(item,key)
-- 			end
-- 			item:setData( dp:getFightScheItemVoById(tmpList[i].id) )
-- 			item:update()
-- 			listView:pushBackCustomItem(item)
-- 		end))
-- 	end
-- 	listView:removeAllItems()
-- 	listView:stopAllActions()
-- 	listView:runAction(CCSequence:create(arr))
-- end

--渲染 我的公会 积分排行
function GuildRenderMgr:renderGloryRankAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getFightGloryMemberList()
	local tmpList = _sortGuildFightRankFunc(voList)
	scrol:setInnerHeightWithList(tmpList) --刷新高度

	if #tmpList == 0 then return end

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + 82
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,6 do
		local key = string.format("gloryRank_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildGloryRankItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshGloryRankList(viewRect,scrol)
end
function GuildRenderMgr:refreshGloryRankList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getFightGloryMemberList()
	DisplayUtil.refreshAdaptScrol(self.dic,6,"gloryRank_%d",_sortGuildFightRankFunc(voList),scrol,840,82,rect)
end

--渲染 我的公会 积分排行 (分配战利)
function GuildRenderMgr:renderGloryAllotRankAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getFightGloryMemberList()
	local tmpList = _sortGuildFightRankFunc(voList)
	scrol:setInnerHeightWithList(tmpList) --刷新高度

	if #tmpList == 0 then return end

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + 82
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,6 do
		local key = string.format("gloryAllotRank_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildGloryAllotItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshGloryAllotRankList(viewRect,scrol)
end
function GuildRenderMgr:refreshGloryAllotRankList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getFightGloryMemberList()
	DisplayUtil.refreshAdaptScrol(self.dic,6,"gloryAllotRank_%d",_sortGuildFightRankFunc(voList),scrol,840,82,rect)
end


--渲染 我的公会 战利
function GuildRenderMgr:renderGloryGiftAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getFightGloryGiftVoList()
	local tmpList = _sortGuildIdRankFunc(voList)
	scrol:setInnerHeightWithList(tmpList) --刷新高度

	if #tmpList == 0 then return end

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + 132
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,4 do
		local key = string.format("gloryGift_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildGloryGiftItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshGloryGiftList(viewRect,scrol)
end
function GuildRenderMgr:refreshGloryGiftList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getFightGloryGiftVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,4,"gloryGift_%d",_sortGuildIdRankFunc(voList),scrol,840,132,rect)
end

--渲染 公会 战利日志
function GuildRenderMgr:renderGloryLogAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getFightGloryLogVoList()
	local voTitle = GuildDataProxy:getInstance():getFightGloryLogTitleVoList()
	local tmpList = _sortGloryLog(voList,voTitle)
	scrol:setInnerHeightWithList(tmpList) --刷新高度

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + v.height
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,11 do
		local key = string.format("gloryLog_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildGloryLogItem:create(),key)
		end
	end

	for i=1,4 do
		local key = string.format("gloryLogTitle_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildGloryLogTitleItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshGloryLogList(viewRect,scrol)
end
function GuildRenderMgr:refreshGloryLogList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getFightGloryLogVoList()
	local voTitle = GuildDataProxy:getInstance():getFightGloryLogTitleVoList()
	local viewVoList = _sortGloryLog(voList,voTitle)

	local ret = {}
	for i=1,#viewVoList do
		local v = viewVoList[i]
		if rect:intersectsRect(CCRectMake(v.posX,v.posY,840,v.height)) then
			table.insert(ret,v)
		end
	end

	for i=1,11 do
		local item = self.dic:objectForKey(string.format("gloryLog_%d",i))
		item:removeFromParentAndCleanup(false)
	end
	for i=1,4 do
		local item = self.dic:objectForKey(string.format("gloryLogTitle_%d",i))
		item:removeFromParentAndCleanup(false)
	end

	local idx1 = 1
	local idx2 = 1
	for i=1,#ret do
		local v = ret[i]
		if v.widget == "gloryLog_" then
			local item = self.dic:objectForKey(string.format(v.widget.."%d",idx1))
			if item:getParent() == nil then
				scrol:addChild(item)
			end
			item:setPosition(ccp(v.posX,v.posY))
			item:setData(v)
			idx1 = idx1 + 1
		elseif v.widget == "gloryLogTitle_" then
			local item = self.dic:objectForKey(string.format(v.widget.."%d",idx2))
			if item:getParent() == nil then
				scrol:addChild(item)
			end
			item:setPosition(ccp(v.posX,v.posY))
			item:setData(v)
			idx2 = idx2 + 1
		end
	end
end

--公会战 场景  根据阶段 显示
function GuildRenderMgr:showFightView(contaniner,momentId)

	contaniner:removeAllChildren()
	contaniner:removeAllNodes()

	local view = self.dic:objectForKey(string.format("guildfightview_%d",momentId))
	if view == nil then
		if momentId == GuildFightMoment.SignupBefore then
			view = GuildFightSignupBefore:create()
		elseif momentId == GuildFightMoment.SignupIng then
			view = GuildFightSignupIng:create()
		elseif momentId == GuildFightMoment.SignupAfter then
			view = GuildFightSignupAfter:create()
		elseif momentId == GuildFightMoment.BattleBefore then
			view = GuildFightBattleBefore:create()
		elseif momentId == GuildFightMoment.BattleIng then
			view = GuildFightBattleIng:create()
		elseif momentId == GuildFightMoment.BattleAfter then
			view = GuildFightBattleAfter:create()
		elseif momentId == GuildFightMoment.BattleFinish then
			view = GuildFightBattleFinish:create()
		elseif momentId == GuildFightMoment.BattleFinishPerpare then
			view = GuildFightBattleFinishPerpare:create()
		end
		self.dic:setObject(view,string.format("guildfightview_%d",momentId))
	end
	
	view:enter()
	view:update()
	contaniner:addChild(view)
end

--渲染 公会战 全服 战况
function GuildRenderMgr:renderFightScheAllListAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getAllCombatRecordVoList()
	local voTitle = GuildDataProxy:getInstance():getAllCombatRecordTitleVoList()
	local tmpList = _sortFightAllCombatFunc(voList,voTitle)
	scrol:setInnerHeightWithList(tmpList) --刷新高度

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + v.height
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,4 do
		local key = string.format("fightAllCombatTitle_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildFightSituationTitleItem:create(),key)
		end
	end

	for i=1,5 do
		local key = string.format("fightAllCombat_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildFightSituationItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshFightScheAllList(viewRect,scrol)
end	
function GuildRenderMgr:refreshFightScheAllList(rect,scrol)
	local voList = GuildDataProxy:getInstance():getAllCombatRecordVoList()
	local voTitle = GuildDataProxy:getInstance():getAllCombatRecordTitleVoList()
	local viewVoList = _sortFightAllCombatFunc(voList,voTitle)

	local ret = {}
	for i=1,#viewVoList do
		local v = viewVoList[i]
		if rect:intersectsRect(CCRectMake(v.posX,v.posY,840,v.height)) then
			table.insert(ret,v)
		end
	end

	for i=1,4 do
		local item = self.dic:objectForKey(string.format("fightAllCombatTitle_%d",i))
		item:removeFromParentAndCleanup(false)
	end
	for i=1,5 do
		local item = self.dic:objectForKey(string.format("fightAllCombat_%d",i))
		item:removeFromParentAndCleanup(false)
	end

	local idx1 = 1
	local idx2 = 1
	for i=1,#ret do
		local v = ret[i]
		if v.widget == "fightAllCombatTitle_" then
			local item = self.dic:objectForKey(string.format(v.widget.."%d",idx1))
			if item:getParent() == nil then
				scrol:addChild(item)
			end
			item:setPosition(ccp(v.posX,v.posY))
			item:setData(v)
			idx1 = idx1 + 1
		elseif v.widget == "fightAllCombat_" then
			local item = self.dic:objectForKey(string.format(v.widget.."%d",idx2))
			if item:getParent() == nil then
				scrol:addChild(item)
			end
			item:setPosition(ccp(v.posX,v.posY))
			item:setData(v)
			idx2 = idx2 + 1
		end
	end
end

--渲染 日程 表 
function GuildRenderMgr:renderFightScheListAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getFightScheItemVoList()
	local tmpList = _sortGuildScheFunc(voList)
	scrol:setInnerHeightWithList(tmpList) --刷新高度
	if #tmpList == 0 then return end

	local innerSize = scrol:getInnerContainer():getSize()
	scrol:getInnerContainer():setSize(CCSize(innerSize.width,innerSize.height + 96))
	local coutHeight = 0
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + v.height
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,5 do
		local key = string.format("glorySche_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildFightScheItem:create(),key)
		end
	end

	--清空状态
	local dp = GuildDataProxy:getInstance()
	dp.curFocusScheId = dp:getFightCurFocusScheId()
	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshFightScheList(viewRect,scrol)
    
    if dp.curFocusScheId ~= -1 then
    	
    	local vo = dp:getFightScheItemVoById( dp.curFocusScheId )
	    --滑动
	    local percent = DisplayUtil.getScrollViewPercentWithPos(scrol, ccp(vo.posX,vo.posY + 50))
	    scrol:stopAllActions()
	    scrol:runAction(CCSequence:createWithTwoActions(
	        CCDelayTime:create(0.05),
	        CCCallFunc:create(function()
	            scrol:jumpToPercentVertical(100 - percent)
	        end)))
	end
end
function GuildRenderMgr:refreshFightScheList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getFightScheItemVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,5,"glorySche_%d",_sortGuildScheFunc(voList),scrol,840,116,rect)
end

--渲染 公会战 战斗力 排行
function GuildRenderMgr:renderPowerRankAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getPowerRankVoList()
	local tmpList = _sortGuildFightRankFunc(voList)
	scrol:setInnerHeightWithList(tmpList) --刷新高度

	if #tmpList == 0 then return end

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + v.height
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,4 do
		local key = string.format("powerRank_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildRankPowerItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshPowerRankList(viewRect,scrol)
end
function GuildRenderMgr:refreshPowerRankList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getPowerRankVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,4,"powerRank_%d",_sortGuildFightRankFunc(voList),scrol,840,95,rect)
end

--渲染 公会战 实时 排行
function GuildRenderMgr:renderCurRankAdapt(scrol)
	local voList = GuildDataProxy:getInstance():getCurRankVoList()
	local tmpList = _sortGuildFightRankFunc(voList)
	scrol:setInnerHeightWithList(tmpList) --刷新高度

	if #tmpList == 0 then return end

	local coutHeight = 0
	local innerSize = scrol:getInnerContainer():getSize()
	for i=1,#tmpList do
		local v = tmpList[i]
		coutHeight = coutHeight + v.height
		local pos = ccp(0,innerSize.height - coutHeight)
		v.posX = pos.x 
		v.posY = pos.y
	end

	for i=1,6 do
		local key = string.format("curRank_%d",i)
		if self.dic:objectForKey(key) == nil then
			self.dic:setObject(GuildRankCurItem:create(),key)
		end
	end

	local viewY = scrol:getInnerContainer():getPositionY()
    local viewRect = CCRectMake(0,math.abs(viewY),scrol:getSize().width,scrol:getSize().height)
    self:refreshCurRankList(viewRect,scrol)
end
function GuildRenderMgr:refreshCurRankList(rect,scrol)
	
	local voList = GuildDataProxy:getInstance():getCurRankVoList()
	DisplayUtil.refreshAdaptScrol(self.dic,6,"curRank_%d",_sortGuildFightRankFunc(voList),scrol,840,64,rect)
end