--公会 网络助手
GuildNetTask = class("GuildNetTask")

local __instance = nil
local _allowInstance = false

function GuildNetTask:ctor()
    if not _allowInstance then
		error("GuildNetTask is a singleton class")
	end
	self:init()
end

function GuildNetTask:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = GuildNetTask.new()
		_allowInstance = false
	end

	return __instance
end

function GuildNetTask:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function GuildNetTask:init()
	require "GuildVo"
	require "GuildDataProxy"
	require "ComSender"
	require "OrganizHelper"
	require "GuildFightRoleInfo"
	require "GuildRenderMgr"

	require "guild_pb"
	require "guild_combat_pb"
	
	--注册网络事件
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_get_id_rsp,"handleMyGuildInfo()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_lists_rsp,"handleOrganizItems()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_create_rsp,"handleCreateOrganiz()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_one_list_rsp,"handleMemberItems()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_select_rsp,"handleFindOrganiz()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_apply_rsp,"handleAppleOrganiz()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_handle_rsp,"handleGuildCommonHandle()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_free_apply_rsp,"handleQuickJoinOrganiz()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_cancel_apply_rsp,"handleCanelApply()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_worship_rsp,"handleWorship()")
 	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_physical_lists_rsp,"handleSendPhysicalStatus()")
 	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_worship_okami_rsp,"handleDescWorship()")
 	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_leader_apply_status_rsp,"handleCheckApplyTips()")
 	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_lookup_all_guild_rsp,"handleLookupAllGuild()")
 	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_contribute_num_rsp,"handleDonatePanelInfo()")
 	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_lookup_boss_rsp,"handleGuildBossList()")
 	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_combat_record_rsp,"handleGuildBossInfo()")
 	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_look_auction_rsp,"handleGuildAuctionList()")
 	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_auction_rsp,"handleGuildPushAuction()")
 	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_auction_record_rsp,"handleAuctionRecord()")
 	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_combat_entrance_rsp,"handleGuildFightInfo()")
 	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_combat_signup_rsp,"handleGuildFightSignup()")
 	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_change_team_rsp,"handleGuildFightMyTeamList()")
 	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_cheer_rsp,"handleGuildCheer()")
 	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_regional_rsp,"handleGuildFightEditArea()")
 	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_check_team_rsp,"handleGuildFightLockArea()")
 	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_signup_name_list_rsp,"handleGuildSignupList()")
 	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_dekaron_rsp,"handleGuildFightEnemyList()")
 	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_service_situation_rsp,"handleGuildFightAllScheList()")
 	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_members_mrole_rsp,"handleGuildFightEnemyPerpare()")
 	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_combat_results_rsp,"handleGuildFightResult()")
 	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_members_integral_rsp,"handleMemberFightRank()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_spoils_reward_rsp,"handleGuildGloryGift()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_spoils_log_rsp,"handleGuildGloryLog()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_spoils_gain_rsp,"handleSendGloryGift()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_change_gain_way_rsp,"handleEditGloryGiftWay()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_find_self_auction_rsp,"handleMYAuctionList()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.guild_auction_add_price_rsp,"handleAppendAuction()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_combat_world_rank_rsp,"handleGuildPowerRankList()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guild_combat_this_season_rsp,"handleGuildCurRankList()")

 	self._updateTeamType = function(teamType)
 		self:updateTeamType(teamType)
 	end

 	Notifier.regist(CmdName.TEAM_UPGRADE_HERO_SUCCESS,self._updateTeamType)
end

function GuildNetTask:requestMyGuildInfo()
	print("-----------requestMyGuildInfo-------------")
	local guild_get_id_req = guild_pb.guild_get_id_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_get_id_req,guild_get_id_req)
end

function handleMyGuildInfo(pkg)
	print("-----------handleMyGuildInfo-------------")
	local guild_get_id_rsp = guild_pb.guild_get_id_rsp()
	guild_get_id_rsp:ParseFromString(pkg)
	if guild_get_id_rsp.ret == error_code_pb.msg_ret.success then

		ComSender:getInstance():dealExtInfo(guild_get_id_rsp.ext) --注意！ ext可能携带被剔/加入 等修改公会id的信息！必须以下面逻辑为准!!

		local cm = CharacterManager:getInstance()
		local dp = GuildDataProxy:getInstance()
		local guildData = cm:getGuildData()
		guildData._id = guild_get_id_rsp.guild_id

		if guildData._id == 0 then  --判断是否已加入公会
	        WindowCtrl:getInstance():open(CmdName.Guild_View_Public)
	    else
	        WindowCtrl:getInstance():open(CmdName.Guild_View_Member)
	    end
	else
		Alert:show(Helper.getErrStr(guild_get_id_rsp.ret))
	end
end
-------------------------------加入公会 面板-------------------------------------------------------
--请求 公会 条目
function GuildNetTask:requestOrganizItems()
	
	print("-----------requestOrganizItems-------------")
	local guild_lists_req = guild_pb.guild_lists_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_lists_req,guild_lists_req)
end

--响应 公会 条目
function handleOrganizItems(pkg)
	print("-----------handleOrganizItems-------------")
	local guild_lists_rsp = guild_pb.guild_lists_rsp()
	guild_lists_rsp:ParseFromString(pkg)

	if guild_lists_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GuildDataProxy:getInstance()
		dp:clearGuildVoList()
		local lists = guild_lists_rsp.lists
		
		local lev = CharacterManager:getInstance():getTeamData():getLev()
		--排序 Id
		table.sort(lists,function(a,b)
			return a.id > b.id
		end)
		for i=1,table.getn(lists) do
			local itemVo = dp:createGuildVo()
			OrganizHelper.makeGuildInfo(itemVo,lists[i])

			-- print(" lists[i].lev ",lists[i].lev)
			if itemVo.isActive == 1 and itemVo.status == 0 and lev > itemVo.freeLevel - 1 then --该公会激活 并 可以正常加入 并超过免申请等级 则为快速登录
				itemVo.status = JoinStatus.QUICI_JOIN --快速登录
			end

			dp:setGuildVo(itemVo)
		end
		--通知场景开始渲染
		Notifier.dispatchCmd(OrganizEvent.GET_ORGANIZ_ITEM_SUCCESS)	

		ComSender:getInstance():dealExtInfo(guild_lists_rsp.ext)

	elseif guild_lists_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
        --跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	end
end
--请求 申请加入 公会
function GuildNetTask:requestAppleJoinOrganiz(id)

    print("-----------requestAppleJoinOrganiz-------------",id)
	local guild_apply_req = guild_pb.guild_apply_req()
	guild_apply_req.id = id 
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_apply_req,guild_apply_req)
end

--响应 申请加入 公会
function handleAppleOrganiz(pkg)

	local guild_apply_rsp = guild_pb.guild_apply_rsp()
	guild_apply_rsp:ParseFromString(pkg)

	print("-----------handleAppleOrganiz-------------" , guild_apply_rsp.ret)

	if guild_apply_rsp.ret == error_code_pb.msg_ret.success then

		local id = guild_apply_rsp.id
		local organizFindVo = GuildDataProxy:getInstance():getFindGuildVoById(id)
		local organizVo = GuildDataProxy:getInstance():getGuildVoById(id)

		local function progress(organizVo)
			if organizVo ~= nil then
				organizVo.status = guild_apply_rsp.status
			end
		end
		progress(organizFindVo)
		progress(organizVo)

		-- print(" organizVo.status ",organizVo.status)

		GuildRenderMgr:getInstance():updateOrganizItem(organizVo.id)
		if organizFindVo then
			GuildRenderMgr:getInstance():updateFindOrganizItem(organizFindVo.id)
		end

		Alert:show(OrganizMsgMap.success_apply_normal)

		ComSender:getInstance():dealExtInfo(guild_apply_rsp.ext)
		Notifier.dispatchCmd(OrganizEvent.GET_ORGANIZ_ITEM_SUCCESS)
		
	elseif guild_apply_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
        --跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_apply_rsp.ret))
	end
end

--请求 立即加入 公会
function GuildNetTask:requestQuickJoinOrganiz(id)

	print("-----------requestQuickJoinOrganiz-------------")
	local guild_free_apply_req = guild_pb.guild_free_apply_req()
	guild_free_apply_req.id = id 
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_free_apply_req,guild_free_apply_req)

end

--响应 立即加入 公会
function handleQuickJoinOrganiz(pkg)

	print("-----------handleQuickJoinOrganiz-------------")
	local guild_free_apply_rsp = guild_pb.guild_free_apply_rsp()
	guild_free_apply_rsp:ParseFromString(pkg)

	if guild_free_apply_rsp.ret == error_code_pb.msg_ret.success then

		OrganizHelper.refreshGuildInfo(guild_free_apply_rsp.lists)

		local dp = GuildDataProxy:getInstance()
		local memberArr = guild_free_apply_rsp.members

		for i=1,table.getn(memberArr) do
			local itemVo = dp:createPlayerVo()
			itemVo.guild = guild_free_apply_rsp.lists.name
			OrganizHelper.makeMemberInfo(itemVo,memberArr[i])
			
			local heroList = {}
			for j=1,#memberArr[i].hero do
				local v = memberArr[i].hero[j]
				table.insert(heroList,{ hero_id = v.hero_id , stars = v.stars })
			end
			itemVo.heroList = heroList
			
			dp:setPlayerVo(itemVo)
		end

		WindowCtrl:getInstance():close(CmdName.Guild_View_Public)-- 先关闭当前窗口
 
		WindowCtrl:getInstance():open(CmdName.Guild_View_Member) --跳转内部

		ComSender:getInstance():dealExtInfo(guild_free_apply_rsp.ext)
	else
		Alert:show(Helper.getErrStr(guild_free_apply_rsp.ret))
	end
end

-- 请求 取消申请
function GuildNetTask:requestCanelApply(id)
	
	print("-----------requestCanelApply-------------")
	local guild_cancel_apply_req = guild_pb.guild_cancel_apply_req()
	guild_cancel_apply_req.id = id 
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_cancel_apply_req,guild_cancel_apply_req)

end

-- 响应 取消申请
function handleCanelApply(pkg)

	print("-----------handleCanelApply-------------")
	local guild_cancel_apply_rsp = guild_pb.guild_cancel_apply_rsp()
	guild_cancel_apply_rsp:ParseFromString(pkg)

	if guild_cancel_apply_rsp.ret == error_code_pb.msg_ret.success then

		local id = guild_cancel_apply_rsp.id
		local lev = CharacterManager:getInstance():getTeamData():getLev()
		local organizFindVo = GuildDataProxy:getInstance():getFindGuildVoById(id)
		local organizVo = GuildDataProxy:getInstance():getGuildVoById(id)

		local function progress(organizVo)
			if organizVo ~= nil then
				organizVo.status = guild_cancel_apply_rsp.status

				if organizVo.isActive == 1 and organizVo.status == 0 and lev > organizVo.freeLevel - 1 then --该公会激活 并 可以正常加入 并超过免申请等级 则为快速登录
				organizVo.status = JoinStatus.QUICI_JOIN --快速登录
				end
			end
		end
		progress(organizFindVo)
		progress(organizVo)

		GuildRenderMgr:getInstance():updateOrganizItem(organizVo.id)
		if organizFindVo then
			GuildRenderMgr:getInstance():updateFindOrganizItem(organizFindVo.id)
		end

		-- Notifier.dispatchCmd(OrganizEvent.CB_JOIN_ORGANIZ) --刷新申请公会条目

		Alert:show(OrganizMsgMap.success_cancel_organiz)	
		Notifier.dispatchCmd(OrganizEvent.GET_ORGANIZ_ITEM_SUCCESS)
		ComSender:getInstance():dealExtInfo(guild_cancel_apply_rsp.ext)
	else
		Alert:show(Helper.getErrStr(guild_cancel_apply_rsp.ret))	
	end
end

--------------------------------创建公会 面板----------------------------------------------------
--请求 创建 公会
function GuildNetTask:requestCreateOrganiz(name,board,uin,channel_id,zone_id,icon)

	print("-----------requestCreateOrganiz-------------")
	local guild_create_req = guild_pb.guild_create_req()
	guild_create_req.name = name
	guild_create_req.board = board
	guild_create_req.icon = icon
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_create_req,guild_create_req)
end

--响应 创建 公会
function handleCreateOrganiz(pkg)

	local guild_create_rsp = guild_pb.guild_create_rsp()
	guild_create_rsp:ParseFromString(pkg)

	print("-----------handleCreateOrganiz-------------",guild_create_rsp.ret)
	if guild_create_rsp.ret == error_code_pb.msg_ret.success then
		
		OrganizHelper.refreshGuildInfo(guild_create_rsp.lists)

		local dp = GuildDataProxy:getInstance()
		local memberArr = guild_create_rsp.members

		for i=1,table.getn(memberArr) do
			local itemVo = dp:createPlayerVo()
			itemVo.guild = guild_create_rsp.lists.name
			OrganizHelper.makeMemberInfo(itemVo,memberArr[i])

			local heroList = {}
			for j=1,#memberArr[i].hero do
				local v = memberArr[i].hero[j]
				table.insert(heroList,{ hero_id = v.hero_id , stars = v.stars })
			end
			itemVo.heroList = heroList

			dp:setPlayerVo(itemVo)
		end

		local assetData = CharacterManager:getInstance():getAssetData()
		assetData._diamond = assetData._diamond - guild_create_rsp.gold
		
		Notifier.dispatchCmd(CmdName.RSP_UPDATE_ROLE_ASSET) --更新资产

		WindowCtrl:getInstance():close(CmdName.Guild_View_Public)-- 先关闭当前窗口
		WindowCtrl:getInstance():open(CmdName.Guild_View_Member)

		ComSender:getInstance():dealExtInfo(guild_create_rsp.ext)
	else
		if error_code_pb.msg_ret.err_in_cooldown == guild_create_rsp.ret then
			Alert:show("你剛退出公會，1小時後才能創建公會")
		else
			Alert:show(Helper.getErrStr(guild_create_rsp.ret))
		end
	end
end

-------------------------------查找公会 面板----------------------------------------------------
--请求 查找 公会
function GuildNetTask:requestFindOrganiz(txt)

    print("-----------requestFindOrganiz-------------",txt)
	local guild_select_req = guild_pb.guild_select_req()
	guild_select_req.name_id = txt
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_select_req,guild_select_req)
end

--响应 查找 公会
function handleFindOrganiz(pkg)

	print("-----------handleFindOrganiz-------------")
	
	local guild_select_rsp = guild_pb.guild_select_rsp()
	guild_select_rsp:ParseFromString(pkg)

	local dp = GuildDataProxy:getInstance()
	dp:clearFindGuildVoList()	--清理缓存

	if guild_select_rsp.ret == error_code_pb.msg_ret.success then

		local lev = CharacterManager:getInstance():getTeamData():getLev()---战队等级

		local lists = guild_select_rsp.lists

		local itemVo = dp:createGuildVo()
		OrganizHelper.makeGuildInfo(itemVo,lists)

		itemVo.area = OrganizArea.FIND_ORGANIZ

		if itemVo.isActive == 1 and itemVo.status == 0 and lev > itemVo.freeLevel - 1 then --该公会激活 并 可以正常加入 并超过免申请等级 则为快速登录
			itemVo.status = JoinStatus.QUICI_JOIN --快速登录
		end
		dp:setFindGuildVo(itemVo)

		ComSender:getInstance():dealExtInfo(guild_select_rsp.ext)
    else
    	Alert:show(Helper.getErrStr(guild_select_rsp.ret))
    end
	Notifier.dispatchCmd(OrganizEvent.MSG_FIND_ORGANIZ)
    
end

---------------------------------内部成员 面板---------------------------------------------------
--响应 公会通用操作(增删改查)
function handleGuildCommonHandle(pkg)
	print("-----------handleGuildCommonHandle-------------",string.len(pkg))

	local guild_handle_rsp = guild_pb.guild_handle_rsp()
	guild_handle_rsp:ParseFromString(pkg)

	if guild_handle_rsp.ret == error_code_pb.msg_ret.success then --只有成功时候才刷数据
		OrganizHelper.refreshGuildInfo(guild_handle_rsp.lists)

	elseif guild_handle_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	end

	if guild_handle_rsp.operate == OrganizCommHandle.guild_options then
		__instance:handleEditGuildSetting(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_flag then
		__instance:handleActiveOrganiz(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_lose_apply then
		__instance:handleIgnoreJoin(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_agree_apply then
		__instance:handleAgreeJoin(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_eliminate then
		__instance:handleAgreeJoin(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_appointment then
		__instance:handleAppoint(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_abdicate then
		__instance:handleSetJob(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_give_physical then
		__instance:handleSendPhysical(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_dissolution then
		__instance:handleDestoryOrganiz(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_sign_out then
		__instance:handleExitOrganiz(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_worship_reward then
		__instance:handleOrganizGetReward(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_add_lev then
		__instance:handleGuildLevup(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_add_contribute then
		__instance:handlePushDonate(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_send_group_mails then
		__instance:handleGuildMail(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_study_skill then
		__instance:handleLevupMeSkill(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_add_skill then
		__instance:handleLevupGuildSkill(guild_handle_rsp)
	elseif guild_handle_rsp.operate == OrganizCommHandle.guild_open_boss then
		__instance:handleActivateBoss(guild_handle_rsp)
	end

	ComSender:getInstance():dealExtInfo(guild_handle_rsp.ext)
end

--请求 获取内部 成员
function GuildNetTask:requestMemberItems()

	print("-----------requestMemberItems-------------")
	local guild_one_list_req = guild_pb.guild_one_list_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_one_list_req,guild_one_list_req)
end

--响应 获取内部 成员
function handleMemberItems(pkg)

	local guild_one_list_rsp = guild_pb.guild_one_list_rsp()
	guild_one_list_rsp:ParseFromString(pkg)

	print("-----------handleMemberItems-------------",guild_one_list_rsp.ret)

	if guild_one_list_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GuildDataProxy:getInstance()
		OrganizHelper.refreshGuildInfo(guild_one_list_rsp.lists)

		dp:clearPlayerVoList()

		local memberArr = guild_one_list_rsp.members
		--成员列表
		for i=1,table.getn(memberArr) do
			local itemVo = dp:createPlayerVo()
			itemVo.guild = guild_one_list_rsp.lists.name
			OrganizHelper.makeMemberInfo(itemVo,memberArr[i])

			local heroList = {}
			for j=1,#memberArr[i].hero do
				local v = memberArr[i].hero[j]
				table.insert(heroList,{ hero_id = v.hero_id , stars = v.stars })
			end
			itemVo.heroList = heroList
			dp:setPlayerVo(itemVo)
		end

		dp:clearApplyVoList()
		
		local applyArr = guild_one_list_rsp.apply_lists
        --申请列表
        for i=1,table.getn(applyArr) do
        	local itemVo = dp:createApplyVo()
			OrganizHelper.makeMemberInfo(itemVo,applyArr[i])
			dp:setApplyVo(itemVo)
        end
        CharacterManager:getInstance():getBaseData():setNewsTipStatus(NewTipsEnum.guild_apply,guild_one_list_rsp.apply_status)

        --公会技能列表
        local guildSkillArr = guild_one_list_rsp.lists.skills
        -- print(" 公會技能列表 #guildSkillArr ",#guildSkillArr)
        for i=1,#guildSkillArr do
        	local skillVo = dp:createSkillVo()
        	skillVo.id = guildSkillArr[i].skill_id
        	skillVo.lev = guildSkillArr[i].lev
        	dp:setGuildSkillVo(skillVo)
        end

		--通知场景开始渲染
		Notifier.dispatchCmd(OrganizEvent.GET_MEMBER_ITEM_SUCCESS)
		Notifier.dispatchCmd(OrganizEvent.GET_MEMBER_ORGANIZ_INFO)
		Notifier.dispatchCmd(OrganizEvent.CB_AGREE_IGNORE_ORGANIZ)

		ComSender:getInstance():dealExtInfo(guild_one_list_rsp.ext)

	elseif guild_one_list_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	end
end

--请求 设置公会 信息
function GuildNetTask:requestEditGuildSetting(lev,iconId,board)

	print("-------------------requestEditGuildSetting---------------------------",lev,iconId,board)
	local guild_handle_req = guild_pb.guild_handle_req()
	guild_handle_req.handle.type = OrganizCommHandle.guild_options
	guild_handle_req.handle.lev = lev
	guild_handle_req.handle.icon = iconId
	guild_handle_req.handle.board = board

	local loginData = CharacterManager:getInstance():getLoginData()
	OrganizHelper.makeRoleId( guild_handle_req.handle.role_id ,loginData:getRoleId() )

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_handle_req)
end

--响应 设置公会 信息
function GuildNetTask:handleEditGuildSetting(guild_handle_rsp)

	print("-------------------handleEditGuildSetting---------------------------")
	if guild_handle_rsp.ret == error_code_pb.msg_ret.success then
	
		Notifier.dispatchCmd(OrganizEvent.GET_MEMBER_ORGANIZ_INFO)
		Alert:show("設置成功")
	else
		Alert:show(Helper.getErrStr(guild_handle_rsp.ret))
	end
end

--请求 膜拜
function GuildNetTask:requestWorship(type,targetId,number)

	print("-------------------requestWorship---------------------------",number)
	local guildData = CharacterManager:getInstance():getGuildData()
	local guild_worship_req = guild_pb.guild_worship_req()
	guild_worship_req.type = type
	guild_worship_req.number = number

	local playerVo = GuildDataProxy:getInstance():getPlayerVoById(targetId)
	OrganizHelper.makeRoleId( guild_worship_req.role_id ,playerVo.role_id )

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_worship_req,guild_worship_req)
end
--响应 膜拜
function handleWorship(pkg)

	print("-------------------handleWorship---------------------------")
	local guild_worship_rsp = guild_pb.guild_worship_rsp()
	guild_worship_rsp:ParseFromString(pkg)

	if guild_worship_rsp.ret == error_code_pb.msg_ret.success then

		local assets = guild_worship_rsp.assets
		CharacterManager:getInstance():updateRoleAssets(assets) --更新资产
	
		local num = CharacterManager:getInstance():getGuildData():getWorshipToday() 
		CharacterManager:getInstance():getGuildData()._worship_today = num + 1

		Alert:show(OrganizMsgMap.success_worship_member)

		ComSender:getInstance():dealExtInfo(guild_worship_rsp.ext)

	elseif guild_worship_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		if error_code_pb.msg_ret.err_not_enough_num == guild_worship_rsp.ret then
			Alert:show("今日膜拜的次數已滿")
		else
			Alert:show(Helper.getErrStr(guild_worship_rsp.ret))
		end
	end

	Notifier.dispatchCmd(OrganizEvent.CB_CLOSE_CHOICE_WORSHIP) --关闭面板
end

--请求 领取膜拜奖励 面板(膜拜大神)
function GuildNetTask:requestDescWorship()

	print("-------------------requestDescWorship---------------------------")
	local guild_worship_okami_req = guild_pb.guild_worship_okami_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_worship_okami_req,guild_worship_okami_req)
end

--响应 领取膜拜奖励 面板(膜拜大神)
function handleDescWorship(pkg)

	local guild_worship_okami_rsp = guild_pb.guild_worship_okami_rsp()
	guild_worship_okami_rsp:ParseFromString(pkg)
	print("-------------------handleDescWorship---------------------------",guild_worship_okami_rsp.ret)

	if guild_worship_okami_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GuildDataProxy:getInstance()
		local descVo = dp:getWorshipDescVo()
		descVo.coutWorship = guild_worship_okami_rsp.worship_num
		descVo.surplusWorship = guild_worship_okami_rsp.worship_today
		descVo.rewardNum = guild_worship_okami_rsp.coin

		WindowCtrl:getInstance():open(CmdName.Guild_View_DescWorship)

		ComSender:getInstance():dealExtInfo(guild_worship_okami_rsp.ext)

	elseif guild_worship_okami_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_worship_okami_rsp.ret))
	end
end

--请求 获得 受拜奖励
function GuildNetTask:requestGetReward()
	print("-------------------requestOrganizGetReward---------------------------")
	local guild_worship_reward_req = guild_pb.guild_handle_req()
	guild_worship_reward_req.handle.type = OrganizCommHandle.guild_worship_reward

	local loginData = CharacterManager:getInstance():getLoginData()
	OrganizHelper.makeRoleId( guild_worship_reward_req.handle.role_id ,loginData:getRoleId() )

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_worship_reward_req)
end

--响应 获得 受拜奖励
function GuildNetTask:handleOrganizGetReward(guild_worship_reward_rsp)

	print("-------------------handleOrganizGetReward---------------------------")
	if guild_worship_reward_rsp.ret == error_code_pb.msg_ret.success then

		local assetData = guild_worship_reward_rsp.assets
		CharacterManager:getInstance():updateRoleAssets(assetData) --更新资产

		local descVo = GuildDataProxy:getInstance():getWorshipDescVo()
		descVo.rewardNum = 0

		local guildData = CharacterManager:getInstance():getGuildData() --取消绿点
   		if guildData:getWorshipReward() > 0 then
   			guildData._worship_reward = 0
   			Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_NEW_TIPS_HIDE,NewTipsEnum.guild_worship)
   		end

		Notifier.dispatchCmd(CmdName.RSP_UPDATE_ROLE_ASSET) --更新资产
		Notifier.dispatchCmd(OrganizEvent.CB_UPDATE_DESC) --更新面板

		Alert:show(OrganizMsgMap.success_get_reward)
	else
		Alert:show(Helper.getErrStr(guild_worship_reward_rsp.ret))
	end
end

--请求 已经赠送的 体力 列表
function GuildNetTask:requestSendPhysicalStatus()

	print("-------------------requestSendPhysicalStatus---------------------------")
	local guild_physical_lists_req = guild_pb.guild_physical_lists_req()
	guild_physical_lists_req.id = CharacterManager:getInstance():getGuildData():getId()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_physical_lists_req,guild_physical_lists_req)
end

--响应 已经赠送的 体力 列表
function handleSendPhysicalStatus(pkg)

	print("-------------------handleSendPhysicalStatus---------------------------")
	local guild_physical_lists_rsp = guild_pb.guild_physical_lists_rsp()
	guild_physical_lists_rsp:ParseFromString(pkg)

	if guild_physical_lists_rsp.ret == error_code_pb.msg_ret.success then

		local voList = GuildDataProxy:getInstance().playerVoList

		local playerIdList = guild_physical_lists_rsp.lists
		for i=1,table.getn(playerIdList) do
			local v = playerIdList[i].role_id
			local role_id = RoleId:create()
			role_id:setData( v.uin,v.channel_id,v.zone_id )
			local playerVo = GuildDataProxy:getInstance():getPlayerVoById(role_id:getKeyIdx())
			playerVo.physicalStatus = PhysicalStatus.HAD_SEND --已赠送
		end

	 	local givePhysicalVo = GuildDataProxy:getInstance():getGivePhysicalVo()
	 	givePhysicalVo.getRewardNum = guild_physical_lists_rsp.receive_num
	 	givePhysicalVo.sendRewardNum = guild_physical_lists_rsp.give_num

	 	-- print("  guild_physical_lists_rsp.receive_num ",guild_physical_lists_rsp.receive_num,guild_physical_lists_rsp.give_num)
		WindowCtrl:getInstance():open(CmdName.Guild_View_GivePhysical)

		ComSender:getInstance():dealExtInfo(guild_physical_lists_rsp.ext)

	elseif guild_physical_lists_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_physical_lists_rsp.ret))
	end
end

--请求 发送 体力
function GuildNetTask:requestSendPhysical(id)
	
	print("-------------------requestSendPhysical---------------------------",id)
	local guild_give_physical_req = guild_pb.guild_handle_req()
	local playerVo = GuildDataProxy:getInstance():getPlayerVoById(id)
	guild_give_physical_req.handle.type = OrganizCommHandle.guild_give_physical

	OrganizHelper.makeRoleId(guild_give_physical_req.handle.role_id,playerVo.role_id )

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_give_physical_req)
end
--响应 发送 体力
function GuildNetTask:handleSendPhysical(guild_give_physical_rsp)
	
	print("-------------------handleSendPhysical---------------------------")
	
	if guild_give_physical_rsp.ret == error_code_pb.msg_ret.success then

		local v = guild_give_physical_rsp.role_id
		local role_id = RoleId:create()
		role_id:setData( v.uin,v.channel_id,v.zone_id )
		local playerVo = GuildDataProxy:getInstance():getPlayerVoById(role_id:getKeyIdx())

		playerVo.physicalStatus = PhysicalStatus.HAD_SEND

		local givePhysicalVo = GuildDataProxy:getInstance():getGivePhysicalVo()
		givePhysicalVo.getRewardNum = guild_give_physical_rsp.receive_num
		givePhysicalVo.sendRewardNum = guild_give_physical_rsp.give_num

		GuildRenderMgr:getInstance():updateGiveItem(role_id:getKeyIdx())

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_GIVE_PHYSICAL) --更新赠送体力 面板
		
		Alert:show(OrganizMsgMap.success_send_phyiscal)
	else
		if error_code_pb.msg_ret.err_not_enough_num == guild_give_physical_rsp.ret then
			Alert:show("今日贈送體力的次數已滿")
		else
			Alert:show(Helper.getErrStr(guild_give_physical_rsp.ret))
		end
	end
end
---------------------------会长权限------------------------------------------------------------------
--请求 同意 入会
function GuildNetTask:requestAgreeJoin(applyId)

	print("-------------------requestAgreeJoin---------------------------")
	local applyVo = GuildDataProxy:getInstance():getApplyVoById(applyId)
	local guild_agree_apply_req = guild_pb.guild_handle_req()

	OrganizHelper.makeRoleId(guild_agree_apply_req.handle.role_id,applyVo.role_id )

	guild_agree_apply_req.handle.type = OrganizCommHandle.guild_agree_apply

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_agree_apply_req)
end
--响应 同意 入会 和 剔除玩家
function GuildNetTask:handleAgreeJoin(guild_agree_apply_rsp)

	print("-------------------handleAgreeJoin---------------------------")
	local v = guild_agree_apply_rsp.role_id
	local role_id = RoleId:create()
	role_id:setData( v.uin,v.channel_id,v.zone_id )
	local applyId = role_id:getKeyIdx()

	if guild_agree_apply_rsp.ret == error_code_pb.msg_ret.success then

		if GuildDataProxy:getInstance():getPlayerVoById(applyId) == nil then --没在公会 则同意加入

			GuildDataProxy:getInstance():removeApplyVoById(applyId)
			Notifier.dispatchCmd(OrganizEvent.CB_AGREE_IGNORE_ORGANIZ)

		else --有在公会  则剔除玩家  
			GuildDataProxy:getInstance():removePlayerVoById(applyId)

			Notifier.dispatchCmd(OrganizEvent.GET_MEMBER_ITEM_SUCCESS)  --更新  成员列表
			Notifier.dispatchCmd(OrganizEvent.MSG_EDIT_MEMBER_ITEM)     --更新  成员管理 列表

			Alert:show(OrganizMsgMap.success_kick_member)

			Notifier.dispatchCmd(OrganizEvent.CB_CLOSE_EDIT_MEMBER) --关闭面板
		end
	else
		Alert:show(Helper.getErrStr(guild_agree_apply_rsp.ret))
	end
end
--请求 忽略 入会
function GuildNetTask:requestIgnoreJoin(applyId)

	print("-------------------requestIgnoreJoin---------------------------",applyId)
	local applyVo = GuildDataProxy:getInstance():getApplyVoById(applyId)
	local guild_lose_apply_req = guild_pb.guild_handle_req()
	guild_lose_apply_req.handle.type = OrganizCommHandle.guild_lose_apply

	OrganizHelper.makeRoleId(guild_lose_apply_req.handle.role_id,applyVo.role_id)

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_lose_apply_req)
end
--响应 忽略 入会
function GuildNetTask:handleIgnoreJoin(guild_lose_apply_rsp)

	print("-------------------handleIgnoreJoin---------------------------")
	local v = guild_lose_apply_rsp.role_id
	local role_id = RoleId:create()
	role_id:setData( v.uin,v.channel_id,v.zone_id )
	local applyId = role_id:getKeyIdx()

	if guild_lose_apply_rsp.ret == error_code_pb.msg_ret.success then

		GuildDataProxy:getInstance():removeApplyVoById(applyId)
		Notifier.dispatchCmd(OrganizEvent.CB_AGREE_IGNORE_ORGANIZ)
	else
		Alert:show(Helper.getErrStr(guild_lose_apply_rsp.ret))
	end
end

--请求 剔除 成员
function GuildNetTask:requestKickMember(kickId)

	print("-----------------requestKickMember---------------------",kickId)

	local playerVo = GuildDataProxy:getInstance():getPlayerVoById(kickId)

	local guild_eliminate_req = guild_pb.guild_handle_req()
	guild_eliminate_req.handle.type = OrganizCommHandle.guild_eliminate

	OrganizHelper.makeRoleId(guild_eliminate_req.handle.role_id,playerVo.role_id)

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_eliminate_req)
end

--响应 剔除 成员  (合并到 同意加入的接口。。。)
function handleKickMember(pkg)
--[[
	local guild_eliminate_rsp = guild_pb.guild_eliminate_rsp()
	guild_eliminate_rsp:ParseFromString(pkg)

	local playerId = guild_eliminate_rsp.role_id.uin


	print("-------------------handleKickMember---------------------------",guild_eliminate_rsp.ret)

	if guild_eliminate_rsp.ret == error_code_pb.msg_ret.success then
		GuildDataProxy:getInstance():removePlayerVoById(playerId)

		Notifier.dispatchCmd(OrganizEvent.GET_MEMBER_ITEM_SUCCESS)  --更新  成员列表
		Notifier.dispatchCmd(OrganizEvent.MSG_EDIT_MEMBER_ITEM)     --更新  成员管理 列表

		Alert:show(OrganizMsgMap.success_kick_member)
	else 
		Alert:show(Helper.getErrStr(guild_eliminate_rsp.ret))
	end
	Notifier.dispatchCmd(OrganizEvent.CB_CLOSE_EDIT_MEMBER) --关闭面板
	]]

end

--请求 任命(副会长) 官位
function GuildNetTask:requestAppoint(id)

	print("-----------------requestAppoint---------------------")
	-- local guildId = CharacterManager:getInstance():getGuildData():getId()
	local playerVo = GuildDataProxy:getInstance():getPlayerVoById(id)

	-- local clazzType = ClazzType.Deputy
	-- if playerVo.clazz == ClazzType.Deputy then

	-- end

	local guild_appointment_req = guild_pb.guild_handle_req()
	guild_appointment_req.handle.type = OrganizCommHandle.guild_appointment
	-- guild_appointment_req.id = guildId

	OrganizHelper.makeRoleId(guild_appointment_req.handle.role_id,playerVo.role_id)

	guild_appointment_req.handle.post = ClazzType.Deputy
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_appointment_req)
end

--响应 任命(副会长) 官位
function GuildNetTask:handleAppoint(guild_appointment_rsp)

	print("-------------------handleAppoint---------------------------",guild_appointment_rsp.ret)
	-- local guild_appointment_rsp = guild_pb.guild_appointment_rsp()
	-- guild_appointment_rsp:ParseFromString(pkg)

	if guild_appointment_rsp.ret == error_code_pb.msg_ret.success then

		local playerId = OrganizHelper.exchageRoleIdKey(guild_appointment_rsp.role_id)

		local playerVo = GuildDataProxy:getInstance():getPlayerVoById(playerId)
		if playerVo.clazz == ClazzType.Deputy then --如果是副会长 则变成平民
			playerVo.clazz = ClazzType.Common
		elseif playerVo.clazz == ClazzType.Common then --反之
			playerVo.clazz = ClazzType.Deputy
		end

		Notifier.dispatchCmd(OrganizEvent.GET_MEMBER_ITEM_SUCCESS)  --更新  成员列表
		Notifier.dispatchCmd(OrganizEvent.MSG_EDIT_MEMBER_ITEM)     --更新  成员管理 列表

		Alert:show(OrganizMsgMap.success_set_clazz)
	else 
		Alert:show(Helper.getErrStr(guild_appointment_rsp.ret))
	end
	Notifier.dispatchCmd(OrganizEvent.CB_CLOSE_EDIT_MEMBER) --关闭面板
end

--请求 让位 官位
function GuildNetTask:requestSetJob(id)

	print("-----------------requestSetJob---------------------")
	local playerVo = GuildDataProxy:getInstance():getPlayerVoById(id)

	local guild_abdicate_req = guild_pb.guild_handle_req()
	guild_abdicate_req.handle.type = OrganizCommHandle.guild_abdicate

	OrganizHelper.makeRoleId(guild_abdicate_req.handle.role_id,playerVo.role_id )

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_abdicate_req)
end

--响应 让位 会长
function GuildNetTask:handleSetJob(guild_abdicate_rsp)

	print("-------------------handleSetJob---------------------------")

	if guild_abdicate_rsp.ret == error_code_pb.msg_ret.success then
		local playerId = OrganizHelper.exchageRoleIdKey(guild_abdicate_rsp.role_id)

		local playerVo = GuildDataProxy:getInstance():getPlayerVoById(playerId) --新会长
		playerVo.clazz = guild_abdicate_rsp.post

		local playerCurVo = OrganizHelper.getCurPlayerVo() --前会长
		playerCurVo.clazz = ClazzType.Common
		
		WindowCtrl:getInstance():close(CmdName.Guild_View_Permission)

		Notifier.dispatchCmd(OrganizEvent.GET_MEMBER_ITEM_SUCCESS)  --更新  成员列表
		Notifier.dispatchCmd(OrganizEvent.MSG_EDIT_MEMBER_ITEM)     --更新  成员管理 列表
		Notifier.dispatchCmd(OrganizEvent.GET_MEMBER_ORGANIZ_INFO)  --更新 公会信息

		Alert:show(OrganizMsgMap.success_let_clazz)
	else 
		Alert:show(Helper.getErrStr(guild_abdicate_rsp.ret))
	end
	Notifier.dispatchCmd(OrganizEvent.CB_CLOSE_EDIT_MEMBER) --关闭面板
end

--请求 普通退出 公会
function GuildNetTask:requestExitOrganiz()
	print("------------requestExitOrganiz-----------------")
	local guild_sign_out_req = guild_pb.guild_handle_req()
	guild_sign_out_req.handle.type = OrganizCommHandle.guild_sign_out

	local loginData = CharacterManager:getInstance():getLoginData()

	OrganizHelper.makeRoleId(guild_sign_out_req.handle.role_id,loginData:getRoleId())

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_sign_out_req)
end

--响应 普通退出 公会
function GuildNetTask:handleExitOrganiz(guild_sign_out_rsp)
	print("------------handleExitOrganiz-----------------")
	-- local guild_sign_out_rsp = guild_pb.guild_sign_out_rsp()
	-- guild_sign_out_rsp:ParseFromString(pkg)
  
	if guild_sign_out_rsp.ret == error_code_pb.msg_ret.success then

		CharacterManager:getInstance():getGuildData()._id = 0
		
  		Notifier.dispatchCmd( CmdName.Guild_Exit )
  		Alert:show("退出成功")
	else
		Alert:show(Helper.getErrStr(guild_sign_out_rsp.ret))
	end
end
--请求 解散 公会
function GuildNetTask:requestDestoryOrganiz()

	print("------------requestDestoryOrganiz-----------------")
	local guild_dissolution_req = guild_pb.guild_handle_req()
	guild_dissolution_req.handle.type = OrganizCommHandle.guild_dissolution

	local loginData = CharacterManager:getInstance():getLoginData()

	OrganizHelper.makeRoleId(guild_dissolution_req.handle.role_id,loginData:getRoleId())

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_dissolution_req)
end

--响应 解散 公会
function GuildNetTask:handleDestoryOrganiz(guild_dissolution_rsp)

	print("------------handleDestoryOrganiz-----------------")
	if guild_dissolution_rsp.ret == error_code_pb.msg_ret.success then

		CharacterManager:getInstance():getGuildData()._id = 0

		WindowCtrl:getInstance():close(CmdName.Guild_View_Member)  --先关闭当前窗体
	
  		Notifier.dispatchCmd( CmdName.Guild_Exit )

  		Alert:show("操作成功")
	else
		Alert:show(Helper.getErrStr(guild_dissolution_rsp.ret))
	end
end

--请求 查看是否有新申请者 消息
function GuildNetTask:requestCheckApplyTips()
	print("------------requestCheckApplyTips-----------------")
	local guild_leader_apply_status_rep = guild_pb.guild_leader_apply_status_rep()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_leader_apply_status_rep,guild_leader_apply_status_rep)
end

--响应 查看否有新申请者 消息
function handleCheckApplyTips(pkg)

	local guild_leader_apply_status_rsp = guild_pb.guild_leader_apply_status_rsp()
	guild_leader_apply_status_rsp:ParseFromString(pkg)
	print("------------handleCheckApplyTips-----------------")
	if guild_leader_apply_status_rsp.ret == error_code_pb.msg_ret.success then

		CharacterManager:getInstance():getBaseData():setNewsTipStatus(NewTipsEnum.guild_apply,guild_leader_apply_status_rsp.apply_status)
		
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_NEW_TIPS_HIDE,NewTipsEnum.guild_apply)
	else
		print(" handleCheckApplyTips err :",Helper.getErrStr(guild_leader_apply_status_rsp.ret))
	end
end
----------------------------------------------------
--被忽略 后 更新公会列表
function GuildNetTask:handleIgnoreBySvr(role_id,organizId)
	print("---------------handleIgnoreBySvr--------------------------")

	local lev = CharacterManager:getInstance():getTeamData():getLev()

	local organizVo = GuildDataProxy:getInstance():getGuildVoById(organizId)
	if organizVo == nil then return print("該玩家還沒初始化進入公會") end

	organizVo.status = JoinStatus.APPLY_JOIN --变回  普通申请
	--通知场景开始渲染
	Notifier.dispatchCmd(OrganizEvent.GET_ORGANIZ_ITEM_SUCCESS)	
end

--被任命 或被让位 后 更新公会
function GuildNetTask:handleAppointMentBySvr(v,pos)
		

	local playerId = OrganizHelper.exchageRoleIdKey(v)

	local playerVo = GuildDataProxy:getInstance():getPlayerVoById(playerId)
	if playerVo == nil then return print("該玩家還沒初始化進入公會") end
	playerVo.clazz = pos

	if pos == ClazzType.Common then --如果变成平民
		WindowCtrl:getInstance():close(CmdName.Guild_View_Permission) 
		WindowCtrl:getInstance():open(CmdName.Guild_View_Member)   --跳转 到 内部成员面板
	end

	Notifier.dispatchCmd(OrganizEvent.GET_MEMBER_ITEM_SUCCESS)  --更新  成员列表
	Notifier.dispatchCmd(OrganizEvent.MSG_EDIT_MEMBER_ITEM)     --更新  成员管理 列表
end

--被膜拜 后 更新数据
function GuildNetTask:handleDescWorshipBySvr(worship)

	local dp = GuildDataProxy:getInstance()
	local descVo = dp:getWorshipDescVo()
	if descVo == nil then return print("該玩家還沒初始化進入公會") end

	descVo.coutWorship = worship.worship_num
	descVo.surplusWorship = worship.worship_today
	descVo.rewardNum = worship.coin

	local guildData = CharacterManager:getInstance():getGuildData()
	guildData._worship_reward = descVo.rewardNum

	if guildData._worship_reward > 0 then
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_NEW_TIPS_SHOW,NewTipsEnum.guild_worship)
	end
end

--请求公会 Boss 列表 信息
function GuildNetTask:requestBossList()
	print("-------------------requestBossList---------------------------")
	local guild_lookup_boss_req = guild_pb.guild_lookup_boss_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_lookup_boss_req,guild_lookup_boss_req)
end

--响应公会 Boss 列表 信息
function handleGuildBossList(pkg)

	local guild_lookup_boss_rsp = guild_pb.guild_lookup_boss_rsp()
	guild_lookup_boss_rsp:ParseFromString(pkg)

	print("---------------handleGuildBossList--------------------------",guild_lookup_boss_rsp.ret)
	if guild_lookup_boss_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GuildDataProxy:getInstance()
		dp:cleanBossData()

		local info = guild_lookup_boss_rsp.boss
		-- print("#info.hp ",#info.hp)

		--曾经死亡列表情况
		for i=1,#info.dead do
			-- print(" dead ",info.dead[i].id)
			local bossVo = dp:getBossVoById( info.dead[i].id )
			bossVo.hadBeenFight = 1
		end

		for i=1,#info.hp do
			-- print(" hp ",info.hp[i].id,info.hp[i].hp)
		 	local bossVo = dp:getBossVoById( info.hp[i].id )
		 	bossVo.isActive = 1
		 	bossVo.hp = info.hp[i].hp
		 	--print("--> bossVo.hp ",bossVo.hp)
		end

		-- print("#info.open ",#info.open)
		for i=1,#info.open do
			-- print(" open ",info.open[i].id,info.open[i].num)
			local bossVo = dp:getBossVoById( info.open[i].id )
		 	bossVo.isActive = 1
		 	bossVo.active_num = info.open[i].num
		end

		for i=1,#info.kill do
			local v = info.kill[i]
			local bossVo = dp:getBossVoById( info.kill[i].boss_id )
			if v.kill_day > 0 then
				bossVo.leftDay = v.kill_day .. "天"
			end
			if v.kill_hours > 0 then
				bossVo.leftDay = v.kill_hours .. "小時"
			end
		end

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_BOSS_LIST)

	elseif guild_lookup_boss_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_lookup_boss_rsp.ret))
	end
end

--请求 公会 升级
function GuildNetTask:requestGuildLevup()

	print("-------------------requestGuildLevup---------------------------")
	local guild_handle_req = guild_pb.guild_handle_req()
	guild_handle_req.handle.type = OrganizCommHandle.guild_add_lev --公会升级

	local loginData = CharacterManager:getInstance():getLoginData()

	OrganizHelper.makeRoleId(guild_handle_req.handle.role_id,loginData:getRoleId())

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_handle_req)
end

--响应 公会 升级
function GuildNetTask:handleGuildLevup(guild_handle_rsp)
	print("---------------handleGuildLevup--------------------------",guild_handle_rsp.ret)
	if guild_handle_rsp.ret == error_code_pb.msg_ret.success then

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_GUILD_LEVUP)
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_PREMISSION)

		Alert:show("升級成功")
	else
		Alert:show(Helper.getErrStr(guild_handle_rsp.ret))
	end
end

--请求(公会内部)查看 所有公会
function GuildNetTask:requestLookupAllGuild()
	print("-----------requestLookupAllGuilde-------------")	
	local guild_lookup_all_guild_req = guild_pb.guild_lookup_all_guild_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_lookup_all_guild_req,guild_lookup_all_guild_req)

end

--相应(公会内部)查看 所有公会
function handleLookupAllGuild(pkg)
	
	local guild_lookup_all_guild_rsp = guild_pb.guild_lookup_all_guild_rsp()
	guild_lookup_all_guild_rsp:ParseFromString(pkg)

	print("-----------handleLookupAllGuild-------------",guild_lookup_all_guild_rsp.ret)

	if guild_lookup_all_guild_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GuildDataProxy:getInstance()
		local lists = guild_lookup_all_guild_rsp.lists
		for i=1,table.getn(lists) do
			local itemVo = dp:createGuildVo()
			OrganizHelper.makeGuildInfo(itemVo,lists[i])

			dp:setGuildViewVo(itemVo)
		end

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_MEMBER_SHOW_GUILD)

		ComSender:getInstance():dealExtInfo(guild_lookup_all_guild_rsp.ext)

	elseif guild_lookup_all_guild_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	end
end

--请求 提交 贡献
function GuildNetTask:requestPushDonate(type,step)
	print("-----------requestPushDonate-------------",type,step)	

	local guild_handle_req = guild_pb.guild_handle_req()
	guild_handle_req.handle.type = OrganizCommHandle.guild_add_contribute --公会贡献
	guild_handle_req.handle.contribute_type = type
	guild_handle_req.handle.contribute_coin_num = step

	local loginData = CharacterManager:getInstance():getLoginData()

	OrganizHelper.makeRoleId(guild_handle_req.handle.role_id,loginData:getRoleId())

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_handle_req)
end

--相应 提交 贡献
function GuildNetTask:handlePushDonate(guild_handle_rsp)
	print("-----------handlePushDonate-------------",guild_handle_rsp.ret)

	if guild_handle_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GuildDataProxy:getInstance()
    	local panelVo = dp:getDonatePanelVo()
    	if guild_handle_rsp.contribute_type == 0 then
    		-- panelVo.coutCoin = panelVo.coutCoin + 1
    		panelVo.coutCoin = guild_handle_rsp.cont_cointotal
    	elseif guild_handle_rsp.contribute_type == 1 then
    		-- panelVo.coutDiamon = panelVo.coutDiamon + 1
    	end

		CharacterManager:getInstance():updateRoleAssets(guild_handle_rsp.assets) --更新资产

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_DONATE_INFO)
		Alert:show("捐獻成功")

		Notifier.dispatchCmd(OrganizEvent.GET_MEMBER_ORGANIZ_INFO)
	else
		Alert:show(Helper.getErrStr(guild_handle_rsp.ret))
	end

end

--请求 学习技能
-- local _leupMeSkillId = 0
function GuildNetTask:requestLevupMeSkill(id)

	print("--------------- requestLevupMeSkill ---------------------",id)

	local guild_handle_req = guild_pb.guild_handle_req()
	guild_handle_req.handle.type = OrganizCommHandle.guild_study_skill --学习公会技能
	guild_handle_req.handle.skill_id = id

	-- _leupMeSkillId = id

	local loginData = CharacterManager:getInstance():getLoginData()

	OrganizHelper.makeRoleId(guild_handle_req.handle.role_id,loginData:getRoleId())

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_handle_req)

end

--响应 升级个人技能
function GuildNetTask:handleLevupMeSkill(guild_handle_rsp)

	print(" ------------------handleLevupMeSkill-------------------- ",guild_handle_rsp.ret)

	if guild_handle_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()

		local skillArr = guild_handle_rsp.skills
		for i=1,#skillArr do
			local skillVo = dp:getMeSkillVoById( skillArr[i].skill_id )
			if skillVo == nil then
				skillVo = dp:createSkillVo()
				skillVo.id = skillArr[i].skill_id
				dp:setMeSkillVo(skillVo)
			end
			skillVo.lev = skillArr[i].skill_lev
		end

		CharacterManager:getInstance():updateRoleAssets(guild_handle_rsp.assets) --更新资产

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_SKILL_SCENE)
		Alert:show("操作成功")
	else
		Alert:show(Helper.getErrStr(guild_handle_rsp.ret))
	end
end

--请求 升级公会技能
function GuildNetTask:requestLevupGuildSkill(id)

	print("--------------- requestLevupGuildSkill ---------------------",id)

	local guild_handle_req = guild_pb.guild_handle_req()
	guild_handle_req.handle.type = OrganizCommHandle.guild_add_skill 
	guild_handle_req.handle.skill_id = id

	local loginData = CharacterManager:getInstance():getLoginData()

	OrganizHelper.makeRoleId(guild_handle_req.handle.role_id,loginData:getRoleId())

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_handle_req)
end

--响应 升级公会技能
function GuildNetTask:handleLevupGuildSkill(guild_handle_rsp)

	print(" ------------------handleLevupGuildSkill-------------------- ",guild_handle_rsp.ret)

	if guild_handle_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()

		local skillArr = guild_handle_rsp.lists.skills
		for i=1,#skillArr do
			local skillVo = dp:getGuildSkillVoById( skillArr[i].skill_id )
			if skillVo == nil then
				skillVo = dp:createSkillVo()
				skillVo.id = skillArr[i].skill_id
				dp:setGuildSkillVo(skillVo)
			end
			skillVo.lev = skillArr[i].lev
		end

		WindowCtrl:getInstance():close(CmdName.Guild_View_Skill_Guild)
		
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_SKILL_SCENE)
		Notifier.dispatchCmd(OrganizEvent.GET_MEMBER_ORGANIZ_INFO)

		Alert:show("提升公會技能等級成功")
	else
		Alert:show(Helper.getErrStr(guild_handle_rsp.ret))
	end

end

--请求 邮件群发
function GuildNetTask:requestGuildMail(txt)

	print("--------------- requestGuildMail ---------------------",txt)

	local guild_handle_req = guild_pb.guild_handle_req()
	guild_handle_req.handle.type = OrganizCommHandle.guild_send_group_mails
	guild_handle_req.handle.mails_content = txt

	local loginData = CharacterManager:getInstance():getLoginData()

	OrganizHelper.makeRoleId(guild_handle_req.handle.role_id,loginData:getRoleId())

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_handle_req)

end

--响应 邮件群发
function GuildNetTask:handleGuildMail(guild_handle_rsp)

	print(" ------------------handleGuildMail-------------------- ",guild_handle_rsp.ret)

	if guild_handle_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GuildDataProxy:getInstance()

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_PREMISSION)

		Alert:show("發送成功")
		CharacterManager:getInstance():updateRoleAssets(guild_handle_rsp.assets) --更新资产
	else
		Alert:show(Helper.getErrStr(guild_handle_rsp.ret))
	end
end

--请求捐献次数
function GuildNetTask:requestDonatePanelInfo()

	print("--------------- requestDonatePanelInfo ---------------------")
	local guild_contribute_num_req = guild_pb.guild_contribute_num_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_contribute_num_req,guild_contribute_num_req)

end

--响应捐献次数
function handleDonatePanelInfo(pkg)

	local guild_contribute_num_rsp = guild_pb.guild_contribute_num_rsp()
	guild_contribute_num_rsp:ParseFromString(pkg)

	print("-----------handleDonatePanelInfo-------------",guild_contribute_num_rsp.ret)

	if guild_contribute_num_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()
		local panelVo = dp:getDonatePanelVo()
    	panelVo.coutCoin = guild_contribute_num_rsp.coin

    	print(" panelVo.coutCoin ",panelVo.coutCoin)
    	panelVo.coutDiamon = guild_contribute_num_rsp.gold

    	WindowCtrl:getInstance():open(CmdName.Guild_View_DonatePanel)

    	ComSender:getInstance():dealExtInfo(guild_contribute_num_rsp.ext)

    elseif guild_contribute_num_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	end
end

--请求 开启(重置)公会Boss
function GuildNetTask:requestActivateBoss(boss_id)

	print("--------------- requestActivateBoss ---------------------",boss_id)

	local guild_handle_req = guild_pb.guild_handle_req()
	guild_handle_req.handle.type = OrganizCommHandle.guild_open_boss
	guild_handle_req.handle.boss_id = boss_id

	local loginData = CharacterManager:getInstance():getLoginData()

	OrganizHelper.makeRoleId(guild_handle_req.handle.role_id,loginData:getRoleId())

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_handle_req,guild_handle_req)
end

--响应 开启(重置)公会Boss
function GuildNetTask:handleActivateBoss(guild_handle_rsp)

	print(" ------------------handleActivateBoss-------------------- ",guild_handle_rsp.ret)

	if guild_handle_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GuildDataProxy:getInstance()
		local bossVo = dp:getBossVoById(guild_handle_rsp.lists.boss_id)
		bossVo.hp = guild_handle_rsp.lists.hp
		bossVo.isActive = 1
		bossVo.hurtList = {}
		bossVo.leftDay = ""

		for i=1,#guild_handle_rsp.kill do
			local v = guild_handle_rsp.kill[i]
			if v.boss_id == guild_handle_rsp.lists.boss_id then
				if v.kill_day > 0 then
					bossVo.leftDay = v.kill_day .. "天"
				end
				if v.kill_hours > 0 then
					bossVo.leftDay = v.kill_hours .. "小時"
				end
			end
		end

		WindowCtrl:getInstance():close(CmdName.Guild_View_BossOpen)

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_BOSS_SCENE_ITEM,bossVo.id)
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_BOSS_INFO,bossVo)
		Alert:show("操作成功")
	else
		Alert:show(Helper.getErrStr(guild_handle_rsp.ret))
	end
end

--请求 Boss 详细信息
function GuildNetTask:requestGuildBossInfo(boss_id)
	print("--------------- requestGuildBossInfo ---------------------",boss_id)

	local guild_combat_record_req = guild_pb.guild_combat_record_req()
	guild_combat_record_req.boss_id = boss_id

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_combat_record_req,guild_combat_record_req)
end

--响应 Boss 详细信息
function handleGuildBossInfo(pkg)

	local guild_combat_record_rsp = guild_pb.guild_combat_record_rsp()
	guild_combat_record_rsp:ParseFromString(pkg)

	print("-----------handleGuildBossInfo-------------",guild_combat_record_rsp.ret)

	if guild_combat_record_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()

		local guildData = CharacterManager:getInstance():getGuildData()
		guildData._hasBeenFightNum = guild_combat_record_rsp.combat_num

		local bossVo = dp:getBossVoById(guild_combat_record_rsp.boss_id)
		bossVo.hurtList = {}
		for i=1,#guild_combat_record_rsp.att do
			local v = guild_combat_record_rsp.att[i]
			table.insert( bossVo.hurtList , { name = v.name , role_id = v.id,att = v.att })
		end

    	Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_BOSS_INFO,bossVo)  

    	ComSender:getInstance():dealExtInfo(guild_combat_record_rsp.ext)

    elseif guild_combat_record_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
    else
    	Alert:show(Helper.getErrStr(guild_combat_record_rsp.ret))
	end
end

--请求竞拍列表
function GuildNetTask:requestGuildAuctionList()

	print("--------------- requestGuildAuctionList ---------------------")
	local guild_look_auction_req = guild_pb.guild_look_auction_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_look_auction_req,guild_look_auction_req)
end

--响应竞拍列表
function handleGuildAuctionList(pkg)
	
	local guild_look_auction_rsp = guild_pb.guild_look_auction_rsp()
	guild_look_auction_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildAcutionList-------------------- ",guild_look_auction_rsp.ret)

	if guild_look_auction_rsp.ret == error_code_pb.msg_ret.success then

		local auctonArr = guild_look_auction_rsp.auction

		local dp = GuildDataProxy:getInstance()
		dp:clearAuctionVoList()

		for i=1,#auctonArr do
			local v = auctonArr[i]

			local auctionVo = dp:createAuctionVo()
			auctionVo.id = v.id
			auctionVo.base_id = v.base_id
			auctionVo.time = v.start_time
			auctionVo.num = v.quantity
			auctionVo.boss_id = v.source
			auctionVo.people = v.join_num
			auctionVo.status = AuctionStatus.Forbid
			auctionVo.top_price = v.top_price

			local fight_boss_arr = guild_look_auction_rsp.combat
			for k=1,#fight_boss_arr do
				local fight_boss = fight_boss_arr[k]
				if auctionVo.boss_id == fight_boss.id then
					auctionVo.status = AuctionStatus.Normal
				end
			end

			local self_auction_arr = guild_look_auction_rsp.self_auction
			-- print(" # #self_auction_arr",#self_auction_arr)
			for j=1,#self_auction_arr do
				local self_auction = self_auction_arr[j]
				
				if self_auction.id == auctionVo.id then --获取我的出价
					auctionVo.cost = self_auction.price
					auctionVo.status = AuctionStatus.HadBeen
				end
			end

			dp:setAuctionVo(auctionVo)
		end
		
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_AUCTION_LIST)

		ComSender:getInstance():dealExtInfo(guild_look_auction_rsp.ext)
	elseif guild_look_auction_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_look_auction_rsp.ret))
	end
end

--请求 竞拍记录 
function GuildNetTask:requestAuctionRecord()
	print(" --------------- requestAuctionRecord --------------- ")
	local guild_auction_record_req = guild_pb.guild_auction_record_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_auction_record_req,guild_auction_record_req)
end
--响应 竞拍记录
function handleAuctionRecord(pkg)

	local guild_auction_record_rsp = guild_pb.guild_auction_record_rsp()
	guild_auction_record_rsp:ParseFromString(pkg)

	print(" --------------------handleAuctionRecord------------------------- ",guild_auction_record_rsp.ret)

	if guild_auction_record_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GuildDataProxy:getInstance()
		dp:clearAuctionRecordVoList()

		local guildRecordArr = guild_auction_record_rsp.success --公会记录
		local myRecordArr = guild_auction_record_rsp.self_success --个人记录
		
		for i=1,#myRecordArr do
			local v = myRecordArr[i]
			local recordVo = dp:createRecordVo()
			recordVo.id = i
			recordVo.time = v.success_time
			recordVo.base_id = v.auction.base_id
			recordVo.num = v.auction.quantity
			recordVo.playerName = "我的出價"
			recordVo.isCurPlayer = true
			recordVo.cost = v.price
			recordVo.boss_id = v.auction.source
			dp:setMyRecordVo(recordVo)
		end

		for i=1,#guildRecordArr do
			local v = guildRecordArr[i]
			local recordVo = dp:createRecordVo()
			recordVo.id = i
			recordVo.base_id = v.auction.base_id
			recordVo.num = v.auction.quantity
			recordVo.boss_id = v.auction.source
			recordVo.playerName = v.name
			recordVo.isCurPlayer = false
			recordVo.cost = v.price
			recordVo.time = v.success_time
			dp:setGuildRecordVo(recordVo)
		end

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_RECORD_LIST)

		ComSender:getInstance():dealExtInfo(guild_auction_record_rsp.ext)
		
	elseif guild_auction_record_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_auction_record_rsp.ret))
	end
end

--请求 提交 竞拍
function GuildNetTask:requestPushAuction(id,cost)
	print("--------------- requestPushAuction ---------------------",id,cost)
	local guild_auction_req = guild_pb.guild_auction_req()
	guild_auction_req.self_auction.id = id
	guild_auction_req.self_auction.price = cost
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_auction_req,guild_auction_req)
end

--响应 提交 竞拍
function handleGuildPushAuction(pkg)

	local guild_auction_rsp = guild_pb.guild_auction_rsp()
	guild_auction_rsp:ParseFromString(pkg)
	print(" ------------------handlePushAuction-------------------- ",guild_auction_rsp.ret)
	local dp = GuildDataProxy:getInstance()
	if guild_auction_rsp.ret == error_code_pb.msg_ret.success then

		CharacterManager:getInstance():updateRoleAssets(guild_auction_rsp.assets) --更新资产
		Alert:show("操作成功")

		WindowCtrl:getInstance():close(CmdName.Guild_View_AuctionPanel)
		
		local self_auction = guild_auction_rsp.self_auction
		local auctionVo = dp:getAuctionVoById( self_auction.id )
		auctionVo.cost = self_auction.price
		auctionVo.status = AuctionStatus.HadBeen

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_AUCTION_LIST)

		ComSender:getInstance():dealExtInfo(guild_auction_rsp.ext)

	elseif guild_auction_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
    elseif guild_auction_rsp.ret == error_code_pb.msg_ret.err_guild_auction_not_top then
    	local self_auction = guild_auction_rsp.self_auction
    	local auctionVo = dp:getAuctionVoById( self_auction.id )
    	auctionVo.top_price = self_auction.top_price
    	Alert:show("已有其他玩家出更高的價格了哦~")
    	Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_AUCTION_INFO)
    	Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_MYAUCTION_LIST)
	else
		Alert:show(Helper.getErrStr(guild_auction_rsp.ret))
	end
end

--请求公会战 信息
function GuildNetTask:requestGuildFightInfo()
	print("--------------- requestGuildFightInfo ---------------------")
	local guild_combat_entrance_req = guild_combat_pb.guild_combat_entrance_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_combat_entrance_req,guild_combat_entrance_req)
end

--响应公会战 信息
function handleGuildFightInfo(pkg)

	local guild_combat_entrance_rsp = guild_combat_pb.guild_combat_entrance_rsp()
	guild_combat_entrance_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildFightInfo-------------------- ",guild_combat_entrance_rsp.ret)

	if guild_combat_entrance_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()
		local sceneVo = dp:getGuildFightSceneVo()
		--校正服务器时间
		ServerTimerManager:getInstance():setSrvTime(guild_combat_entrance_rsp.server_time) 

		dp:cleanFightScheVoList()
		sceneVo.scheduleList = {}
		local info = guild_combat_entrance_rsp.rule
----------------本公会 赛果-------------------------------------------------------------------
		dp:cleanMyCombatRecordVoList()
		local session = guild_combat_entrance_rsp.session
		print(" #比賽結果 ",#session)
		for i=1,#session do
			local recordVo = dp:createFightCombatRecordVo()
			OrganizHelper.makeFightCombat(recordVo,session[i])
			dp:setMyCombatRecordVo(recordVo)
		end
---------------赛季 总结果------------------------------------------------------------------
		dp:cleanAllCombatRankVoList()
		local allRecord = guild_combat_entrance_rsp.histort
		for i=1,#allRecord do
			local rankVo = dp:createFightCombatRankVo()
			OrganizHelper.makeAllCombatRank(rankVo,allRecord[i],guild_combat_entrance_rsp.histort_num)
			dp:setAllCombatRankVo(rankVo)
		end
-------------------------------------------------------------------------------------
		print(" 當前時間 ", os.date("%Y/%m/%d %X", ServerTimerManager:getInstance():getCurTime()) )
		sceneVo.signup_start = info.signup_start
		sceneVo.signup_end = info.signup_end

		local enemyVo = dp:createGuildVo()
		OrganizHelper.makeGuildInfo(enemyVo,guild_combat_entrance_rsp.other_info)
		sceneVo.enemyInfo = enemyVo
		print(" 對手名字 ",sceneVo.enemyInfo.name)

		print(" 報名開始 ",os.date("%Y/%m/%d %X",sceneVo.signup_start) )
		print(" 報名結束 ",os.date("%Y/%m/%d %X",sceneVo.signup_end) )
------------------------------------------------------------------
		local scheVo = dp:createFightScheItemVo()
		scheVo.time = info.signup_start
		scheVo.monent = GuildFightMoment.SignupIng
		dp:setFightScheItemVo(scheVo)

		for i=1,#info.matches do
			local v = info.matches[i]
			local sche = {}
			sche.matches = v.matches
			sche.ready_start = v.ready_start 
			if sche.matches == 1 then --第一场匹配结果延时1分钟（因为服务器生成对手要时间...）
				sche.ready_start = sche.ready_start + 60
			end
			sche.ready_end = v.ready_end
			sche.combat_start = v.combat_start
			sche.combat_end = v.combat_end

			print(" 場次 ",sche.matches)
			print(" 開始備戰 ",os.date("%Y/%m/%d %X",sche.ready_start))
			print(" 結束備戰 ",os.date("%Y/%m/%d %X",sche.ready_end))
			print(" 開始戰鬥 ",os.date("%Y/%m/%d %X",sche.combat_start))
			print(" 結束戰鬥 ",os.date("%Y/%m/%d %X",sche.combat_end))

			local scheVo = dp:createFightScheItemVo()
			scheVo.time = v.ready_start
			scheVo.monent = GuildFightMoment.SignupAfter
			scheVo.session = v.matches
			dp:setFightScheItemVo(scheVo)

			local scheVo = dp:createFightScheItemVo()
			scheVo.time = v.ready_end
			scheVo.monent = GuildFightMoment.BattleBefore
			scheVo.session = v.matches
			dp:setFightScheItemVo(scheVo)

			local scheVo = dp:createFightScheItemVo()
			scheVo.time = v.combat_start
			scheVo.monent = GuildFightMoment.BattleIng
			scheVo.session = v.matches
			dp:setFightScheItemVo(scheVo)

			if v.matches == #info.matches then --最后一场
				local scheVo = dp:createFightScheItemVo()
				scheVo.time = v.combat_end
				scheVo.monent = GuildFightMoment.BattleFinish
				scheVo.session = v.matches
				dp:setFightScheItemVo(scheVo)
			end

			table.insert(sceneVo.scheduleList,sche)
		end
		
		sceneVo.isSignup = guild_combat_entrance_rsp.is_signup
		sceneVo.isCheer = guild_combat_entrance_rsp.is_cheer
		sceneVo.signupNum = guild_combat_entrance_rsp.signup_num
		local monet,scheId = dp:getCurMoment(sceneVo)
		sceneVo.curMoment = monet
		sceneVo.curScheId = scheId
		sceneVo.mySessionScore = guild_combat_entrance_rsp.integral
		sceneVo.enemySessionScore = guild_combat_entrance_rsp.other_integral

		print(" sceneVo.isSignup ",sceneVo.isSignup,monet,scheId,sceneVo.isCheer)
----------------------------------------------------------------------------------------------
		-- dp:cleanFightMyTeamVoList()
		-- print("#我方鏡像",#guild_combat_entrance_rsp.self_team)
		-- for i=1,#guild_combat_entrance_rsp.self_team do
		-- 	local v = guild_combat_entrance_rsp.self_team[i]
		-- 	local playerVo = dp:getPlayerVoById( OrganizHelper.exchageRoleIdKey(v.id) )
		-- 	OrganizHelper.makeMemberInfo(playerVo,v)
		-- end
		-- dp:checkMakeHolderVo()

		-- dp:cleanFightEnemyVoList()
		-- print("#敵方鏡像",#guild_combat_entrance_rsp.other_team)
		-- for i=1,#guild_combat_entrance_rsp.other_team do
		-- 	local v = guild_combat_entrance_rsp.other_team[i]

		-- 	OrganizHelper.makeEnemyFightMember(v)
		-- end
		-- dp:makeAreaVoList(dp.fightEnemyVoList,dp.fightEnemyAreaVoList)
		local teamVo = dp:createFightTeamVo()
		teamVo.type = GuildFightTeamStatus.MyTeam
		teamVo.curNum = guild_combat_entrance_rsp.self_dead.surplus
		teamVo.maxNum = guild_combat_entrance_rsp.self_dead.max_num
		dp:setGuildFightTeamVo(teamVo)

		local teamVo = dp:createFightTeamVo()
		teamVo.type = GuildFightTeamStatus.EnemyTeam
		teamVo.curNum = guild_combat_entrance_rsp.other_dead.surplus
		teamVo.maxNum = guild_combat_entrance_rsp.other_dead.max_num
		dp:setGuildFightTeamVo(teamVo)
----------------------------------------------------------------------------------------------
		local hero_id = guild_combat_entrance_rsp.hero_id
		local myHp = guild_combat_entrance_rsp.my_hp

		dp.svrHpLen = #myHp
		for j=1,#hero_id do
			local heroVo = dp:createHeroVo()
			heroVo.id = hero_id[j].id
			heroVo.molecular = 1
			heroVo.denominator = 1

			for i=1,#myHp do --扣血
				if myHp[i].hero_id == heroVo.id then

					if myHp[i].molecular == 0 then --死了的英雄
						heroVo.molecular = 0
						heroVo.denominator = 0
					else
						heroVo.molecular = myHp[i].molecular
						heroVo.denominator = myHp[i].denominator
					end
				end
			end
			dp:setMyHeroVo(heroVo)
		end

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_SCENE)

		ComSender:getInstance():dealExtInfo(guild_combat_entrance_rsp.ext)

	elseif guild_combat_entrance_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_combat_entrance_rsp.ret))
	end
end

--请求公会报名 列表
function GuildNetTask:requestGuildSignupList()
	print("--------------- requestGuildSignupList ---------------------")
	local guild_signup_name_list_req = guild_combat_pb.guild_signup_name_list_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_signup_name_list_req,guild_signup_name_list_req)
end

--响应公会报名 列表
function handleGuildSignupList(pkg)
	local guild_signup_name_list_rsp = guild_combat_pb.guild_signup_name_list_rsp()
	guild_signup_name_list_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildSignupList-------------------- ",guild_signup_name_list_rsp.ret)

	if guild_signup_name_list_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GuildDataProxy:getInstance()
		dp:cleanFightSignupVoList()
		for i=1,#guild_signup_name_list_rsp.lists do
			local v = guild_signup_name_list_rsp.lists[i]
			local guildVo = dp:createGuildVo()
			OrganizHelper.makeGuildInfo(guildVo,v)
			dp:setFightSignupVo(guildVo)
		end

		local sceneVo = dp:getGuildFightSceneVo()
		sceneVo.signupNum = #guild_signup_name_list_rsp.lists

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_SIGNUPLIST)

		ComSender:getInstance():dealExtInfo(guild_signup_name_list_rsp.ext)	

	elseif guild_signup_name_list_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_signup_name_list_rsp.ret))
	end
end

--请求 申请公会战
function GuildNetTask:requestGuildFightSignup(txt)
	print("--------------- requestGuildSignupList ---------------------",txt)
	local guild_combat_signup_req = guild_combat_pb.guild_combat_signup_req()
	guild_combat_signup_req.declaration = txt
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_combat_signup_req,guild_combat_signup_req)
end

--响应 申请公会战
function handleGuildFightSignup(pkg)
	local guild_combat_signup_rsp = guild_combat_pb.guild_combat_signup_rsp()
	guild_combat_signup_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildFightSignup-------------------- ",guild_combat_signup_rsp.ret)

	if guild_combat_signup_rsp.ret == error_code_pb.msg_ret.success then

		WindowCtrl:getInstance():close(CmdName.Guild_View_SignupView)

		local dp = GuildDataProxy:getInstance()
		local sceneVo = dp:getGuildFightSceneVo()
		sceneVo.isSignup = 1
		sceneVo.signupNum = guild_combat_signup_rsp.signup_num

		local assetData = guild_combat_signup_rsp.assets
		CharacterManager:getInstance():updateRoleAssets(assetData) --更新资产
		OrganizHelper.refreshGuildInfo(guild_combat_signup_rsp.lists)

		Alert:show("報名成功")
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_SIGNUPING)
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FINISH_RANK_SIGNLIST)
		ComSender:getInstance():dealExtInfo(guild_combat_signup_rsp.ext)

	elseif guild_combat_signup_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_combat_signup_rsp.ret))
	end
end

--请求 查看我方备战 列表
function GuildNetTask:requestGuildFightMyTeamList()
	print("--------------- requestGuildFightMyTeamList ---------------------")
	local guild_change_team_req = guild_combat_pb.guild_change_team_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_change_team_req,guild_change_team_req)
end

--响应 查看我方备战 列表
function handleGuildFightMyTeamList(pkg)
	local guild_change_team_rsp = guild_combat_pb.guild_change_team_rsp()
	guild_change_team_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildFightMyTeamList-------------------- ",guild_change_team_rsp.ret)

	if guild_change_team_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()

		-- local v = guild_change_team_rsp.team
		-- local playerVo = dp:getPlayerVoById( OrganizHelper.exchageRoleIdKey(v.id) )
		-- OrganizHelper.makeMemberInfo(playerVo,v)
		-- dp:checkMakeHolderVo()
		dp:cleanFightMyTeamVoList()
		print("#我方鏡像",#guild_change_team_rsp.team)
		for i=1,#guild_change_team_rsp.team do
			local v = guild_change_team_rsp.team[i]
			local playerVo = dp:getPlayerVoById( OrganizHelper.exchageRoleIdKey(v.id) )
			OrganizHelper.makeMemberInfo(playerVo,v)
		end
		dp:checkMakeHolderVo()

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_MYTEAM_LIST)
		ComSender:getInstance():dealExtInfo(guild_change_team_rsp.ext)

	elseif guild_change_team_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_change_team_rsp.ret))
	end
end

--请求 查看 挑战对手 列表
function GuildNetTask:requestGuildFightEnemyList()
	print("--------------- requestGuildFightEnemyList ---------------------")
	local guild_dekaron_req = guild_combat_pb.guild_dekaron_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_dekaron_req,guild_dekaron_req)
end

--响应 查看 挑战对手 列表
function handleGuildFightEnemyList(pkg)
	local guild_dekaron_rsp = guild_combat_pb.guild_dekaron_rsp()
	guild_dekaron_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildFightEnemyList-------------------- ",guild_dekaron_rsp.ret)

	if guild_dekaron_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()
	
		local v = guild_dekaron_rsp.self_team
		local playerVo = dp:getPlayerVoById( OrganizHelper.exchageRoleIdKey(v.id) )
		OrganizHelper.makeMemberInfo(playerVo,v)
		dp:checkMakeHolderVo()

		dp:cleanFightEnemyVoList()
		for i=1,#guild_dekaron_rsp.other_team do
			local v = guild_dekaron_rsp.other_team[i]

			OrganizHelper.makeEnemyFightMember(v)
		end
		dp:makeAreaVoList(guild_dekaron_rsp.other_cheer,dp.fightEnemyAreaVoList)

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_ENEMY_LIST)

		ComSender:getInstance():dealExtInfo(guild_dekaron_rsp.ext)

	elseif guild_dekaron_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_dekaron_rsp.ret))
	end
end

--请求 公会战 修改队员 战区
function GuildNetTask:requestGuildFightEditArea(id,areaId)
	print("--------------- requestGuildFightEditArea ---------------------",id,areaId)
	local guild_regional_req = guild_combat_pb.guild_regional_req()
	local playerVo = GuildDataProxy:getInstance():getFightMyTeamVoById(id)
	OrganizHelper.makeRoleId(guild_regional_req.id,playerVo.role_id)
	guild_regional_req.regional = areaId
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_regional_req,guild_regional_req)
end

--响应 公会战 修改队员 战区
function handleGuildFightEditArea(pkg)
	local guild_regional_rsp = guild_combat_pb.guild_regional_rsp()
	guild_regional_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildFightEditArea-------------------- ",guild_regional_rsp.ret)

	if guild_regional_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GuildDataProxy:getInstance()
		local v = guild_regional_rsp.team
		local playerVo = dp:getPlayerVoById( OrganizHelper.exchageRoleIdKey(v.id) )
		OrganizHelper.makeMemberInfo(playerVo,v)
		dp:checkMakeHolderVo()

		WindowCtrl:getInstance():close(CmdName.Guild_View_FightEdit)

		Alert:show("設置成功")
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_MYTEAM_LIST)
		ComSender:getInstance():dealExtInfo(guild_regional_rsp.ext)

	elseif guild_regional_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_regional_rsp.ret))
	end
end

--请求 公会战 锁定队员 战区
function GuildNetTask:requestGuildFightLockArea(id)
	print("--------------- requestGuildFightLockArea ---------------------",id)
	local guild_check_team_req = guild_combat_pb.guild_check_team_req()
	local playerVo = GuildDataProxy:getInstance():getFightMyTeamVoById(id)
	OrganizHelper.makeRoleId(guild_check_team_req.id,playerVo.role_id)
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_check_team_req,guild_check_team_req)
end

--响应 公会战 锁定队员 战区
function handleGuildFightLockArea(pkg)
	local guild_check_team_rsp = guild_combat_pb.guild_check_team_rsp()
	guild_check_team_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildFightLockArea-------------------- ",guild_check_team_rsp.ret)

	if guild_check_team_rsp.ret == error_code_pb.msg_ret.success then

		local playerVo = GuildDataProxy:getInstance():getFightMyTeamVoById( OrganizHelper.exchageRoleIdKey(guild_check_team_rsp.id) )
		playerVo.guild_fight_islock = guild_check_team_rsp.check

		WindowCtrl:getInstance():close(CmdName.Guild_View_FightEdit)
		ComSender:getInstance():dealExtInfo(guild_check_team_rsp.ext)

	elseif guild_check_team_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_check_team_rsp.ret))
	end
end

--请求 公会助威
function GuildNetTask:requestGuildCheer()
	print("--------------- requestGuildCheer ---------------------")
	local guild_cheer_req = guild_combat_pb.guild_cheer_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_cheer_req,guild_cheer_req)
end

--响应 公会助威
function handleGuildCheer(pkg)
	local guild_cheer_rsp = guild_combat_pb.guild_cheer_rsp()
	guild_cheer_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildCheer-------------------- ",guild_cheer_rsp.ret)

	if guild_cheer_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()
		local sceneVo = dp:getGuildFightSceneVo()
		sceneVo.isCheer = 1
		OrganizHelper.refreshGuildInfo(guild_cheer_rsp.lists)

		WindowCtrl:getInstance():close(CmdName.Guild_View_CheerView)
		ComSender:getInstance():dealExtInfo(guild_cheer_rsp.ext)

		Alert:show("助威成功！")
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_SCENE)

	elseif guild_cheer_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_cheer_rsp.ret))
	end
end

--------------刷新 公会战 战斗血量----------------------------------
function GuildNetTask:handleGuildFightHpBySvr(my_hps,members_mroles)

	local dp = GuildDataProxy:getInstance()
	dp.svrHpLen = #my_hps
	for j=1,#my_hps do
		local heroVo = dp:getMyHeroVoById(my_hps[j].hero_id)

		heroVo.molecular = my_hps[j].molecular
		heroVo.denominator = my_hps[j].denominator
	end

	dp:cleanFightEnemyVoList()
	for i=1,#members_mroles do
		local v = members_mroles[i]

		OrganizHelper.makeEnemyFightMember(v)
	end
	-- dp:makeAreaVoList(dp.fightEnemyVoList,dp.fightEnemyAreaVoList)

	Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_ENEMY_LIST)
end

function GuildNetTask:updateTeamType(team_type)
	if team_type == TeamType.Guild_atk then
		GuildDataProxy:getInstance():setConfirmFightPos(1)
	end
end

--请求 我的公会 战利物品
function GuildNetTask:requestGuildGloryGift()
	print("--------------- requestGuildGloryGift ---------------------")
	local guild_spoils_reward_req = guild_combat_pb.guild_spoils_reward_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_spoils_reward_req,guild_spoils_reward_req)
end

--响应 我的公会 战利物品
function handleGuildGloryGift(pkg)
	local guild_spoils_reward_rsp = guild_combat_pb.guild_spoils_reward_rsp()
	guild_spoils_reward_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildGloryGift-------------------- ",guild_spoils_reward_rsp.ret)

	if guild_spoils_reward_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()
		dp:cleanFightGloryGiftVoList()

		print(" ##guild_spoils_reward_rsp.spoils ",#guild_spoils_reward_rsp.spoils)
		for i=1,#guild_spoils_reward_rsp.spoils do
			local v = guild_spoils_reward_rsp.spoils[i]
			local giftVo = dp:createFightGloryGiftVo()
			OrganizHelper.makeFightGloryGift(giftVo,v)
			dp:setFightGloryGiftVo(giftVo)
		end

		dp:getFightGlorySceneVo().allotType = guild_spoils_reward_rsp.gain_way

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_GIFT_LIST)
		ComSender:getInstance():dealExtInfo(guild_spoils_reward_rsp.ext)

	elseif guild_spoils_reward_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_spoils_reward_rsp.ret))
	end
end

--请求 我的公会 战利日志
function GuildNetTask:requestGuildGloryLog()
	print("--------------- requestGuildGloryLog ---------------------")
	local guild_spoils_log_req = guild_combat_pb.guild_spoils_log_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_spoils_log_req,guild_spoils_log_req)
end

--响应 我的公会 战利日志
function handleGuildGloryLog(pkg)
	local guild_spoils_log_rsp = guild_combat_pb.guild_spoils_log_rsp()
	guild_spoils_log_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildGloryLog-------------------- ",guild_spoils_log_rsp.ret)

	if guild_spoils_log_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()
		dp:cleanFightGloryLogVoList()

		local log = guild_spoils_log_rsp.log
		print(" #戰利日誌 ",#log)
		for i=1,#log do
			local logVo = dp:createFightGloryLogVo()
			OrganizHelper.makeGloryLog(logVo,log[i])
			dp:setFightGloryLogVo(logVo)
		end
		dp:makeLogTitleVoList(log)

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_LOG_LIST)
		ComSender:getInstance():dealExtInfo(guild_spoils_log_rsp.ext)

	elseif guild_spoils_log_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_spoils_log_rsp.ret))
	end
end

--请求 公会战 全部战况
function GuildNetTask:requestGuildFightAllScheList(type)
	print("--------------- requestGuildFightAllScheList ---------------------",type)
	local guild_service_situation_req = guild_combat_pb.guild_service_situation_req()
	guild_service_situation_req.type = type
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_service_situation_req,guild_service_situation_req)
end

--响应 公会战 全部战况
function handleGuildFightAllScheList(pkg)
	local guild_service_situation_rsp = guild_combat_pb.guild_service_situation_rsp()
	guild_service_situation_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildFightAllScheList-------------------- ",guild_service_situation_rsp.ret)

	if guild_service_situation_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()
		dp:cleanAllCombatRecordVoList()

		local session = guild_service_situation_rsp.session
		print(" #全服狀況 ",#session)
		for i=1,#session do
			local recordVo = dp:createFightCombatRecordVo()
			OrganizHelper.makeFightCombat(recordVo,session[i])
			dp:setAllCombatRecordVo(recordVo)
		end
		dp:makeAllCombatTitleVoList(session)

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_ALL_COMBAT_LIST)
		ComSender:getInstance():dealExtInfo(guild_service_situation_rsp.ext)

	elseif guild_service_situation_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_service_situation_rsp.ret))
	end
end

--请求 公会战 对手情报
function GuildNetTask:requestGuildFightEnemyPerpare()
	print("--------------- requestGuildFightEnemyPerpare ---------------------")
	local guild_members_mrole_req = guild_combat_pb.guild_members_mrole_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_members_mrole_req,guild_members_mrole_req)
end

--响应 公会战 对手情报
function handleGuildFightEnemyPerpare(pkg)

	local guild_members_mrole_rsp = guild_combat_pb.guild_members_mrole_rsp()
	guild_members_mrole_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildFightEnemyPerpare-------------------- ",guild_members_mrole_rsp.ret)

	if guild_members_mrole_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()
		dp:cleanFightEnemyVoList()
		-- print("#guild_combat_entrance_rsp.other_team ",#guild_members_mrole_rsp.other_team)
		for i=1,#guild_members_mrole_rsp.other_team do
			local v = guild_members_mrole_rsp.other_team[i]

			OrganizHelper.makeEnemyFightMember(v)
		end
		dp:makeAreaVoList(guild_members_mrole_rsp.other_cheer,dp.fightEnemyAreaVoList)

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_ENEMY_PERPARE_LIST)
		ComSender:getInstance():dealExtInfo(guild_members_mrole_rsp.ext)

	elseif guild_members_mrole_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_members_mrole_rsp.ret))
	end
end

--请求 某公会 战绩 (本届/上届)
function GuildNetTask:requestGuildFightResult(guildId,type)
	print("--------------- requestGuildFightResult ---------------------",guildId,type)
	local guild_combat_results_req = guild_combat_pb.guild_combat_results_req()
	guild_combat_results_req.id = guildId
	guild_combat_results_req.type = type
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_combat_results_req,guild_combat_results_req)
end

--响应 某公会 战绩 (本届/上届)
function handleGuildFightResult(pkg)
	local guild_combat_results_rsp = guild_combat_pb.guild_combat_results_rsp()
	guild_combat_results_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildFightResult-------------------- ",guild_combat_results_rsp.ret)

	if guild_combat_results_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()
		
		dp:clearFightScoreList()
		local session = guild_combat_results_rsp.session
		for i=1,#session do
			local recordVo = dp:createFightCombatRecordVo()
			OrganizHelper.makeFightCombat(recordVo,session[i])
			dp:setFightScoreItemVo(recordVo)
		end

		local sceneVo = dp:getFightScoreViewVo()
		sceneVo.scoreTotal = guild_combat_results_rsp.integraltotal
		sceneVo.win_num = guild_combat_results_rsp.win_num
		sceneVo.session_max = #session
		sceneVo.lastRank = guild_combat_results_rsp.last_rank

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_SCORE_LIST)

		ComSender:getInstance():dealExtInfo(guild_combat_results_rsp.ext)

	elseif guild_combat_results_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_combat_results_rsp.ret))
	end
end

--请求 公会战 成员排名
function GuildNetTask:requestMemberFightRank()
	print("--------------- requestMemberFightRank ---------------------")
	local guild_members_integral_req = guild_combat_pb.guild_members_integral_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_members_integral_req,guild_members_integral_req)
end

--响应 公会战 成员排名
function handleMemberFightRank(pkg)
	local guild_members_integral_rsp = guild_combat_pb.guild_members_integral_rsp()
	guild_members_integral_rsp:ParseFromString(pkg)
	print(" ------------------handleMemberFightRank-------------------- ",guild_members_integral_rsp.ret)

	if guild_members_integral_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()
		dp:cleanGloryMemberList()

		local info = guild_members_integral_rsp.integral
		print(" #積分排名 ",#info)
		for i=1,#info do
			local rankVo = dp:createFightGloryMember() 
			OrganizHelper.makeGloryMemberRank(rankVo,info[i])
			dp:setFightGloryMember(rankVo)
		end

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_RANK_LIST)
		ComSender:getInstance():dealExtInfo(guild_members_integral_rsp.ext)

	elseif guild_members_integral_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_members_integral_rsp.ret))
	end
end

--请求 修改 战利 分配方式
function GuildNetTask:requestEditGloryGiftWay(type)
	print("--------------- requestEditGloryGiftWay ---------------------",type)
	local guild_change_gain_way_req = guild_combat_pb.guild_change_gain_way_req()
	guild_change_gain_way_req.gain_way = type
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_change_gain_way_req,guild_change_gain_way_req)
end

--响应 修改 战利 分配方式
function handleEditGloryGiftWay(pkg)
	local guild_change_gain_way_rsp = guild_combat_pb.guild_change_gain_way_rsp()
	guild_change_gain_way_rsp:ParseFromString(pkg)
	print(" ------------------handleEditGloryGiftWay-------------------- ",guild_change_gain_way_rsp.ret)

	if guild_change_gain_way_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()

		dp:getFightGlorySceneVo().allotType = guild_change_gain_way_rsp.gain_way

		ComSender:getInstance():dealExtInfo(guild_change_gain_way_rsp.ext)

		if dp:getFightGlorySceneVo().allotType == 3 then  --自动分配
			Alert:show("自動分配會在每場公會戰結束後根據貢獻值自動分配獎勵，下一場公會戰結束後生效")
		else
			Alert:show("設置成功")
		end

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_GIFT_LIST)

	elseif guild_change_gain_way_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_change_gain_way_rsp.ret))
	end
end

--请求 分配公会战 战利物品
function GuildNetTask:requestSendGloryGift(role_id,id)
	print("--------------- requestSendGloryGift ---------------------",role_id:getKeyIdx(),id)
	local guild_spoils_gain_req = guild_combat_pb.guild_spoils_gain_req()
	OrganizHelper.makeRoleId(guild_spoils_gain_req.role_id,role_id)
	guild_spoils_gain_req.id = id
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_spoils_gain_req,guild_spoils_gain_req)
end

--响应 分配公会战 战利物品
function handleSendGloryGift(pkg)
	local guild_spoils_gain_rsp = guild_combat_pb.guild_spoils_gain_rsp()
	guild_spoils_gain_rsp:ParseFromString(pkg)
	print(" ------------------handleSendGloryGift-------------------- ",guild_spoils_gain_rsp.ret)

	if guild_spoils_gain_rsp.ret == error_code_pb.msg_ret.success then
		local dp = GuildDataProxy:getInstance()
		dp:cleanFightGloryGiftVoList()

		print(" #戰利物品 ",#guild_spoils_gain_rsp.spoils)
		for i=1,#guild_spoils_gain_rsp.spoils do
			local v = guild_spoils_gain_rsp.spoils[i]
			local giftVo = dp:createFightGloryGiftVo()
			OrganizHelper.makeFightGloryGift(giftVo,v)
			dp:setFightGloryGiftVo(giftVo)
		end

		Alert:show("分配成功")
		WindowCtrl:getInstance():close(CmdName.Guild_View_GloryAllotPanel)

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_GLORY_GIFT_LIST)
		ComSender:getInstance():dealExtInfo(guild_spoils_gain_rsp.ext)

	elseif guild_spoils_gain_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_spoils_gain_rsp.ret))
	end
end

--请求 查看我的竞拍列表
function GuildNetTask:requestMyAuctionList()
	print("--------------- requestMyAuctionList ---------------------")
	local guild_find_self_auction_req = guild_pb.guild_find_self_auction_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_find_self_auction_req,guild_find_self_auction_req)
end

--响应 查看我的竞拍列表
function handleMYAuctionList(pkg)
	local guild_find_self_auction_rsp = guild_pb.guild_find_self_auction_rsp()
	guild_find_self_auction_rsp:ParseFromString(pkg)
	print(" ------------------handleMYAuctionList-------------------- ",guild_find_self_auction_rsp.ret)

	if guild_find_self_auction_rsp.ret == error_code_pb.msg_ret.success then

		local auctonArr = guild_find_self_auction_rsp.self_auction
		local dp = GuildDataProxy:getInstance()
		dp:clearMyAuctionVoList()

		for i=1,#auctonArr do
			local v = auctonArr[i]
			local auctionVo = dp:createAuctionVo()
			auctionVo.id = v.id
			auctionVo.base_id = v.base_id
			auctionVo.time = v.start_time
			auctionVo.num = v.quantity
			auctionVo.cost = v.price
			auctionVo.boss_id = v.source
			auctionVo.people = v.join_num
			auctionVo.top_price = v.top_price
			dp:setMyAuctionVo(auctionVo)
		end

		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_MYAUCTION_LIST)
		ComSender:getInstance():dealExtInfo(guild_find_self_auction_rsp.ext)

	elseif guild_find_self_auction_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
	else
		Alert:show(Helper.getErrStr(guild_find_self_auction_rsp.ret))
	end
end

--请求 我的竞拍加价
local _lastAppendAuctionId = 0
function GuildNetTask:requestAppendAuction(id,cost)
	print("--------------- requestAppendAuction ---------------------",id,cost)
	local guild_auction_add_price_req = guild_pb.guild_auction_add_price_req()
	guild_auction_add_price_req.auction_id = id
	guild_auction_add_price_req.price = cost
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.guild_auction_add_price_req,guild_auction_add_price_req)

	_lastAppendAuctionId = id 
end

--响应 我的竞拍加价
function handleAppendAuction(pkg)
	local guild_auction_add_price_rsp = guild_pb.guild_auction_add_price_rsp()
	guild_auction_add_price_rsp:ParseFromString(pkg)
	print(" ------------------handleAppendAuction-------------------- ",guild_auction_add_price_rsp.ret)
	local dp = GuildDataProxy:getInstance()

	if guild_auction_add_price_rsp.ret == error_code_pb.msg_ret.success then

		CharacterManager:getInstance():updateRoleAssets(guild_auction_add_price_rsp.assets) --更新资产
		Alert:show("操作成功")

		local dp = GuildDataProxy:getInstance()
		dp:clearMyAuctionVoList()

		local auctonArr = guild_auction_add_price_rsp.self_auction
		for i=1,#auctonArr do
			local v = auctonArr[i]
			local auctionVo = dp:createAuctionVo()
			auctionVo.id = v.id
			auctionVo.base_id = v.base_id
			auctionVo.time = v.start_time
			auctionVo.num = v.quantity
			auctionVo.cost = v.price
			auctionVo.boss_id = v.source
			auctionVo.people = v.join_num
			auctionVo.top_price = v.top_price
			dp:setMyAuctionVo(auctionVo)
		end

		WindowCtrl:getInstance():close(CmdName.Guild_View_AuctionPanel)
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_MYAUCTION_LIST)

		ComSender:getInstance():dealExtInfo(guild_auction_add_price_rsp.ext)

	elseif guild_auction_add_price_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
    elseif guild_auction_add_price_rsp.ret == error_code_pb.msg_ret.err_guild_auction_not_top then
    	local auctionVo = dp:getMyAuctionVoById( _lastAppendAuctionId )
    	auctionVo.top_price = guild_auction_add_price_rsp.top_price
    	Alert:show("已有其他玩家出更高的價格了哦~")
    	Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_AUCTION_INFO)
    	Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_MYAUCTION_LIST)
	else
		Alert:show(Helper.getErrStr(guild_auction_add_price_rsp.ret))
	end
end

--请求公会战 实力排名
function GuildNetTask:requestGuildPowerRankList()
	print("--------------- requestGuildPowerRankList ---------------------")
	local guild_combat_world_rank_req = guild_combat_pb.guild_combat_world_rank_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_combat_world_rank_req,guild_combat_world_rank_req)
end

--响应公会战 实力排名
function handleGuildPowerRankList(pkg)
	local guild_combat_world_rank_rsp = guild_combat_pb.guild_combat_world_rank_rsp()
	guild_combat_world_rank_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildPowerRankList-------------------- ",guild_combat_world_rank_rsp.ret)

	if guild_combat_world_rank_rsp.ret == error_code_pb.msg_ret.success then

		local dp = GuildDataProxy:getInstance()
		dp:cleanPowerRankVoList()
		for i,v in ipairs(guild_combat_world_rank_rsp.rank) do
			local rankVo = dp:createFightPowerRankVo()
			OrganizHelper.makePowerCurRank(rankVo,v)
			dp:setPowerRankVo(rankVo)
		end
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_POWER_RANK_LIST)
		ComSender:getInstance():dealExtInfo(guild_combat_world_rank_rsp.ext)

	elseif guild_combat_world_rank_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
    else
    	Alert:show(Helper.getErrStr(guild_combat_world_rank_rsp.ret))
	end
end

--请求公会战 当前排名
function GuildNetTask:requestGuildCurRankList()
	print("--------------- requestGuildCurRankList ---------------------")
	local guild_combat_this_season_req = guild_combat_pb.guild_combat_this_season_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guild_combat_this_season_req,guild_combat_this_season_req)

end
--响应公会战 当前排名
function handleGuildCurRankList(pkg)

	local guild_combat_this_season_rsp = guild_combat_pb.guild_combat_this_season_rsp()
	guild_combat_this_season_rsp:ParseFromString(pkg)
	print(" ------------------handleGuildCurRankList-------------------- ",guild_combat_this_season_rsp.ret)

	if guild_combat_this_season_rsp.ret == error_code_pb.msg_ret.success then
		print(" #guild_combat_this_season_rsp.rank ",#guild_combat_this_season_rsp.rank)
		local dp = GuildDataProxy:getInstance()
		dp:cleanCurRankVoList()
		for i,v in ipairs(guild_combat_this_season_rsp.rank) do
			local rankVo = dp:createFightCurRankVo()
			OrganizHelper.makePowerCurRank(rankVo,v)
			dp:setCurRankVo(rankVo)
		end
		Notifier.dispatchCmd(OrganizEvent.MSG_UPDATE_FIGHT_CUR_RANK_LIST)
		ComSender:getInstance():dealExtInfo(guild_combat_this_season_rsp.ext)


	elseif guild_combat_this_season_rsp.ret == error_code_pb.msg_ret.err_server_not_schedule_query then --被剔除了
		CharacterManager:getInstance():getGuildData()._id = 0 --清理数据
		--跳转公开场景(被T)
        GuildDataProxy:getInstance():closeAllGuildView()
    else
    	Alert:show(Helper.getErrStr(guild_combat_this_season_rsp.ret))
	end
end