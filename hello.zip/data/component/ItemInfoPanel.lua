--物品 掉落物品 展示 面板
ItemInfoPanel = class("ItemInfoPanel",function()
    return DisplayUtil.newFitLayout()
end)
ItemInfoPanel.__index = ItemInfoPanel
ItemInfoPanel._widget     = nil
ItemInfoPanel.uiLayer    = nil

local __instance = nil

function ItemInfoPanel:getInstance()
    if not __instance then
        local ret = ItemInfoPanel.new()
        __instance = ret
        ret:init()
        ret:retain()
    end
    return __instance
end

-- local function event_img_shadow(pSender,eventType)
-- 	if eventType == ComConstTab.TouchEventType.ended then

--         WindowCtrl:getInstance():close(CmdName.Comm_ItemInfo)
-- 	end
-- end

local itemIcon = nil

function ItemInfoPanel:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("common/ItemInfoPanel.ExportJson")
    self:addChild(self._widget)

	-- local imgShadow = tolua.cast(self._widget:getChildByName("img_shadow"),"ImageView")
	-- imgShadow:addTouchEventListener(event_img_shadow)

    self.panelContent = self._widget:getChildByName("panel_content")

	itemIcon = ItemIcon:create()
	itemIcon:setScale(0.8)
    self.panelContent:addChild(itemIcon,3)
end

function ItemInfoPanel:setBaseId(id)

    local itemVo = ItemManager:getInstance():getItemModelByBaseId(id)

    local labName = tolua.cast(self.panelContent:getChildByName("lab_name"),"Label")
    labName:setText(itemVo.name)

	local p_icon = self.panelContent:getChildByName("p_icon")  
    itemIcon:setBaseId(id)
    itemIcon:setItemNum(1)
    itemIcon:setPosition(ccp(p_icon:getPosition()))

    local panelDescEqm = self.panelContent:getChildByName("panel_eqm")
    local panelDescNormal = self.panelContent:getChildByName("panel_normal")

    local imgBg = tolua.cast(self.panelContent:getChildByName("img_bg"),"ImageView")
   
    local labDesc = nil
    local bgSize = nil

    if itemVo.item_type == ItemHelper.itemType.gift then --礼包卡

        local rewardStr = ItemManager:getInstance():giftRelationListStr(itemVo.base_id)
        
        panelDescEqm:setVisible(false)
        panelDescNormal:setVisible(true)
        bgSize = CCSizeMake(548,188)

        labDesc = tolua.cast(panelDescNormal:getChildByName("lab_desc"),"Label")
        labDesc:setText(Helper.insertnl(itemVo.desc,21).. "\n".. rewardStr)

    elseif ItemManager:getInstance():isEqm(itemVo.item_type) == false then --普通物品
        panelDescEqm:setVisible(false)
        panelDescNormal:setVisible(true)
        bgSize = CCSizeMake(548,188)

        labDesc = tolua.cast(panelDescNormal:getChildByName("lab_desc"),"Label")
        labDesc:setText(Helper.insertnl(itemVo.desc,21))
    else  --装备物品
        panelDescEqm:setVisible(true)
        panelDescNormal:setVisible(false)
        bgSize = CCSizeMake(548,288)

        local labTeam = tolua.cast(panelDescEqm:getChildByName("lab_team"),"Label")
        labTeam:setText(itemVo.limit_lev)

        local labType = tolua.cast(panelDescEqm:getChildByName("lab_type"),"Label")
        labType:setText(ItemHelper:getTypeName(itemVo.item_type))

        local attr_flag = ItemHelper:getAttrFlagByLocation(itemVo.item_type)
        local labAppend = tolua.cast(panelDescEqm:getChildByName("lab_append"),"Label")
        labAppend:setText(AttrHelper:getAttrNameByFlag(attr_flag))

        local attrs = ItemManager:getInstance():getEqmBaseAttrAddQuality(itemVo.base_id)
        local labAppendValue = tolua.cast(panelDescEqm:getChildByName("lab_appendv"),"Label")
        labAppendValue:setText(attrs[attr_flag])

        labDesc = tolua.cast(panelDescEqm:getChildByName("lab_desc"),"Label")
        labDesc:setText(Helper.insertnl(itemVo.desc,21))
    end

    local offsetHeight = ( labDesc:getSize().height / 22 - 1 ) * 25
    imgBg:setSize(CCSizeMake(bgSize.width, bgSize.height + offsetHeight))
end

function ItemInfoPanel:setPosition(pos)
     self.panelContent:setPosition(pos)
end

function ItemInfoPanel:show(id,pos)

    local layer = GameLayerMgr:getInstance():getMsgLayer()
    local child = layer:getChildByTag(1105)
    if child ~= nil then
        layer:removeChildByTag(1105,false)
    end

    local panel = ItemInfoPanel:getInstance()
    panel:setBaseId(id)
    panel:setTag(1105)
    if pos ~= nil then
        panel:setPosition(pos)
    end
    layer:addChild(panel)
end

function ItemInfoPanel:hide()

    local layer = GameLayerMgr:getInstance():getMsgLayer()
    local child = layer:getChildByTag(1105)
    if child ~= nil then
        layer:removeChildByTag(1105,false)
    end

    ItemInfoPanel:getInstance():setPosition(ccp(197,211))
end