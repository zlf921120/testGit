-- 环形菜单
AnnularMenu = class("AnnularMenu",function()
	return Layout:create()
end)
AnnularMenu.__index = AnnularMenu
AnnularMenu.touchLayer = nil
AnnularMenu.touchCbFunc = nil

local _isMounseDown = false
local _prePoint = nil
local _nowPoint = nil
local _itemScaleA = 10
local _itemScaleB = 60
local _up = 90
local _childTbl = nil
local _childStatusMap = nil
local _childStatusIdxMap = nil
local _isRunning = false

function CC_DEGREES_TO_RADIANS(angle) 
	return angle * 0.01745329252
end

function AnnularMenu:create(childArr,size)
	local ret = AnnularMenu.new()
	ret:init(childArr,size)
	return ret
end

function AnnularMenu:init(childArr,size)

   	_childStatusMap = {}
   	_childStatusIdxMap = {}
	_childTbl = childArr
	self:setSize(size)

	local length = #childArr
	for i=1, length do
		local v = childArr[i]
		-- local angle = i * (360 / length);
		-- self:addChild(v)

		-- local size = self:getSize()
		-- local size = self:getContentSize()
		-- local scale = 0.3 + ((_itemScaleA + _itemScaleB * math.sin(CC_DEGREES_TO_RADIANS(angle))/ length) * 0.05 )

		-- local positionX = size.width / 2 - math.cos(CC_DEGREES_TO_RADIANS(angle)) * size.width / 2
		-- local positionY = size.height / 2 - math.sin(CC_DEGREES_TO_RADIANS(angle)) * _up

		-- local scale = scaleArr[i]
		-- local positionX = posArr[i].x
		-- local positionY = posArr[i].y
		-- v:setScale(scale)
		-- v:setPosition(ccp( positionX,positionY) )
		_childStatusIdxMap[v] = i

		table.insert(_childStatusMap, {scale = v:getScale(), positionX = v:getPositionX(), positionY = v:getPositionY(),localZ = v:getZOrder()})
	end

	self:sortOnDepth()
end

function AnnularMenu:sortOnDepth()
	local tmpTbl = {}
	for i=1,#_childTbl do
		table.insert(tmpTbl,_childTbl[i])
	end
	table.sort(tmpTbl, function(x,y) return x:getScaleX() < y:getScaleX() end)
	for j=1,#tmpTbl do
		local child = tmpTbl[j]
		child:setZOrder(j)
	end
end

function AnnularMenu:setDisableById(id)
	local child = _childTbl[id]
	-- child:setTouchEnabled(false)
	child:setColor(ccc3(150,150,150))
end

function AnnularMenu:setAbleById(id)
	local child = _childTbl[id]
	child:setColor(ccc3(255,255,255))
end

function AnnularMenu:getItemNextStatus(child)
	local idx = _childStatusIdxMap[child]
	if idx >= #_childStatusMap then
		idx = 1
	else
		idx = idx + 1
	end
	_childStatusIdxMap[child] = idx
	return _childStatusMap[idx]
end

function AnnularMenu:getItemPrevStatus(child)
	local idx = _childStatusIdxMap[child]
	if idx <= 1 then
		idx = #_childStatusMap
	else
		idx = idx - 1
	end
	_childStatusIdxMap[child] = idx
	return _childStatusMap[idx]
end

function AnnularMenu:turn(isNext)
	if _isRunning then return false end
	_isRunning = true
	for i=1,#_childTbl do
		local child = _childTbl[i]
		local status = nil
		if isNext then 
			status = self:getItemNextStatus(child)
		else              
			status = self:getItemPrevStatus(child)
		end
		child:runAction(CCScaleTo:create(0.2,status.scale))
		child:runAction(CCMoveTo:create(0.2,ccp(status.positionX,status.positionY)))
	end
	
	self:runAction(CCSequence:createWithTwoActions(
		CCDelayTime:create(0.4), 
		CCCallFunc:create(function()
			_isRunning = false
			self:sortOnDepth()
		end)))
	return true
end

function AnnularMenu:updateClickAble(nowIdx)
	for i=1,12 do
		if i <= nowIdx then
			self:setAbleById(i)
		else
			self:setDisableById(i)
		end
	end
end

function AnnularMenu:getItem(idx)
	return _childTbl[idx]
end

function AnnularMenu:jumpTo(child,idx)

	local lastIdx = _childStatusIdxMap[child]

	local dis = idx - lastIdx
	local flag = dis > 0

	for i=1,math.abs(dis) do
		for i=1,#_childTbl do
			local child = _childTbl[i]
			local status = nil
			if flag then 
				status = self:getItemNextStatus(child)
			else              
				status = self:getItemPrevStatus(child)
			end
			child:setScale(status.scale)
			child:setPosition(ccp(status.positionX,status.positionY))
			-- child:setZOrder(status.localZ)
		end
	end
	self:sortOnDepth()
end

function AnnularMenu:handleTouchBegan(x,y)
	_isMounseDown = true
	_prePoint = ccp(x,y)
	_nowPoint = ccp(x,y)
end


function AnnularMenu:handleTouchMoved(x,y,func)
	if _prePoint == nil then return end
	if _isRunning == true then return end
	_nowPoint = ccp(x,y)
	if _nowPoint.x - _prePoint.x > 20 then
		if self:turn(true) then
			func(true)
		end
	end
	if _nowPoint.x - _prePoint.x < -20 then
		if self:turn(false) then
			func(false)
		end
	end
end

function AnnularMenu:handleTouchEnded(x,y,func)
	if _isRunning == true then return end
	_isMounseDown = false
	local length = #_childTbl
	local clickTbl = {}
	for i=1, length do
		local child = _childTbl[i]
		local width = child:getContentSize().width
		local height = child:getContentSize().height
		local rect = CCRectMake(child:getPositionX() - width/2 ,child:getPositionY(),width,height)
		if rect:containsPoint(ccp(x,y)) then
			table.insert(clickTbl,child)
		end
	end
	if #clickTbl > 0 then
		local clickChild = nil
		if #clickTbl > 1 then
			table.sort(clickTbl, function(x,y) return x:getZOrder() > y:getZOrder() end)
		end
		clickChild = clickTbl[1]

		func(clickChild:getTag())
	end
end

function AnnularMenu:clean()
	_isRunning = false
end