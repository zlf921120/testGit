--加载圈
Loading = class("Loading",function()
	return DisplayUtil.newFitLayer()
end)
Loading.__index = Loading
Loading._widget 	= nil
Loading._uiLayer 	= nil

local __instance = nil

function Loading:getInstance()
    if not __instance then
        local ret = Loading.new()
        __instance = ret
        ret:initInstance()
        ret:retain()
    end
    return __instance
end

function Loading:destoryInstance()
    self:release()
    __instance = nil
end

function Loading:initInstance()

    require("TouchPriority")

    self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/common/Loading.ExportJson")
    self._uiLayer = TouchGroup:create()
    self._uiLayer:setTouchPriority(TouchPriority.lock)
    self._uiLayer:addWidget(self._widget)
    self:addChild(self._uiLayer)

    local x,y = self._widget:getChildByName("p_icon"):getPosition()
    require "AnimateManager"
    self.armLoadingPath = "ui/effects_ui/jiazaizhong/jiazaizhong.ExportJson"
    self.armLoading = AnimateManager:getInstance():getArmature(self.armLoadingPath, "jiazaizhong")
    self.armLoading:setPosition(ccp(x + 45,y))
    self._widget:addNode(self.armLoading)

    self.armPeoplePath = "ui/effects/zhiyinjingling01/zhiyinjingling01.ExportJson"
    local isFileExist = Global:isFileExist(self.armPeoplePath)
    if isFileExist then
        self.armPeople = AnimateManager:getInstance():getArmature(self.armPeoplePath, "zhiyinjingling01")
        self.armPeople:setScaleX(-1)
        self.armPeople:setPosition(ccp(x - 115,y - 80))
        self._widget:addNode(self.armPeople)
    end
end

function Loading:playAnim()

    self.armLoading:getAnimation():stop()
    self.armLoading:getAnimation():play("Animation1",-1,-1,1)

    if SceneCtrl:getInstance():getCurScene() == CmdName.MAIN_SCENE then

    	require "PetDataProxy"
    	require "AnimateManager"
		local res,name = PetDataProxy:getInstance():getCurPetRes()
        local x,y = self._widget:getChildByName("p_icon"):getPosition()
		if self.armPeoplePath ~= res and self.armPeople then
            self.armPeople:getAnimation():stop()
			self.armPeople:getAnimation():play("stand02",-1,-1,1)
            self.armPeople:getAnimation():setMovementEventCallFunc(function() end)
            self.armPeople:removeFromParentAndCleanup(true)
            -- self._widget:removeNode(self.armPeople)
            self.armPeople = nil
            AnimateManager:getInstance():clear(self.armPeoplePath)	 --不能立即清理！！
            self.armPeoplePath = res

            CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(res)
	        self.armPeople = CCArmature:create(name)
	        self.armPeople:setScaleX(-1)
		    self.armPeople:setPosition(ccp(x - 115,y - 80))
		    self._widget:addNode(self.armPeople)
            self.armPeople:getAnimation():stop()
            self.armPeople:getAnimation():play("stand02",-1,-1,1)
		else
			self.armPeople:getAnimation():stop()
    		self.armPeople:getAnimation():play("stand02",-1,-1,1)
		end
    else
        if self.armPeople then
        	self.armPeople:getAnimation():stop()
        	self.armPeople:getAnimation():play("stand02",-1,-1,1)
        end
    end
end

function Loading:stopAnim()
    self.armLoading:getAnimation():stop()
    if self.armPeople then
        self.armPeople:getAnimation():stop()
    end
end

function Loading:show()

    local loading = Loading:getInstance()
    if loading:getParent() ~= nil then return end

    -- Loading:hide()
    -- Global:setLoadingStatus(1)
    loading = Loading:getInstance()
    loading:setTag(1006)
    loading:playAnim()
    local layer = GameLayerMgr:getInstance():getMsgLayer()
    layer:addChild(loading)
    cclog("GameLayerMgr:getInstance():getMsgLayer()")
    cclog("GameLayerMgr:getInstance():getMsgLayer()")
    cclog("GameLayerMgr:getInstance():getMsgLayer()")
end

function Loading:hide()
    -- Global:setLoadingStatus(0)
    -- local loading = Loading:getInstance()
    -- if loading:getParent() then
    --     loading:removeFromParentAndCleanup(true)
    -- end

    local layer = GameLayerMgr:getInstance():getMsgLayer()
    local loading = Loading:getInstance()
    if loading ~= nil then
        loading:stopAnim()
        loading:removeFromParentAndCleanup(false)
    end
end