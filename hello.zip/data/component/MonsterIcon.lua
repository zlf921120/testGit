--
-- Author: lvgansheng
-- Date: 2014-08-07 15:11:47
-- 怪物头像

MonsterIcon = class("MonsterIcon", function() return Widget:create() end)

MonsterIcon.img = nil
MonsterIcon.info = nil
MonsterIcon.id = 0

local icon_width = 78
local icon_height = 78

function MonsterIcon:init()

    --判断是否已经加载过头像资源，没有则开始加载
    HeroManager:getInstance():loadHeroIconPlist()

	--图标背景框
	local iconBg = ImageView:create()
	iconBg:loadTexture("normal_bg.png",UI_TEX_TYPE_PLIST)
	self:addChild(iconBg)	
	
    self.icon_img = ImageView:create()
    self:addChild(self.icon_img)

    local icon_border = ImageView:create()
    icon_border:loadTexture("normal_border.png",UI_TEX_TYPE_PLIST)
	self:addChild(icon_border)	

	self.bossImg = ImageView:create()
	self.bossImg:setPosition(ccp(25,-40))
	self.bossImg:setRotation(18)
	self:addChild(self.bossImg)	
end

function MonsterIcon:create()
	local icon = MonsterIcon.new()
	icon:init()
	return icon
end

function MonsterIcon:setMonsterId(id)
	self.id = id
	self.info = MonsterManager:getInstance():getBaseInfo(id)
	local res_name = string.format("monster_%d.png",self.info.icon_res_id)

	self.icon_img:loadTexture(res_name,UI_TEX_TYPE_PLIST)
end

--设置图标的点击事件
function MonsterIcon:setClickEvent(click_event)
    self.icon_img:setTouchEnabled(true)
    self.icon_img:addTouchEventListener(click_event)
end

--设置是否boss图标
function MonsterIcon:setIsBoss(value)
	if value then
		self:setScale(1)
		self.bossImg:loadTexture("dungeon_boss.png",UI_TEX_TYPE_PLIST)
		self.bossImg:setVisible(true)
	else
		self:setScale(0.8)
		self.bossImg:setVisible(false)
	end
end