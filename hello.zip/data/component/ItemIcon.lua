--
-- Author: lvgansheng
-- Date: 2014-07-15 10:56:35
-- 通用物品图标

ItemIcon = class("ItemIcon", function() return Widget:create() end)

ItemIcon.base_id=nil 
ItemIcon.icon_bg =nil
ItemIcon.icon_img =nil
ItemIcon.num_label =nil
ItemIcon.select_img =nil

ItemIcon.icon_width = 90
ItemIcon.icon_height = 90

ItemIcon.half_width = 45
ItemIcon.half_height = 45

ItemIcon.name_label = nil

ItemIcon.enchant_lev = 0

--初始化
function ItemIcon:init()

    require("ItemHelper")

    --图标背景框
    ItemManager:getInstance():loadItemIconPlist()

    
	
     --图标背景框
    self.icon_bg = ImageView:create()
    self.icon_bg:loadTexture("normal_bg.png",UI_TEX_TYPE_PLIST)
    self:addChild(self.icon_bg) 
 
    self.icon_img = ImageView:create()
    self:addChild(self.icon_img)

    self.icon_border = ImageView:create()
    self.icon_border:loadTexture("normal_border.png",UI_TEX_TYPE_PLIST)
    self:addChild(self.icon_border) 

    self.num_label = Label:create()
    self.num_label:setAnchorPoint(ccp(1,1))
    self.num_label:setPosition(ccp(42,-45))
    self.num_label:setFontSize(22)
    self.num_label:setColor(ItemHelper.colors.yellow)
    -- self.lev_label:setText("LV.99")
    self:addChild(self.num_label)

    self.numTxt = Utils.createStrokeLab({label = self.num_label, outlinecolor = ccc3(0,0,0), anc_point=ccp(1,0)})
    self.numTxt:setPosition(ccp(0,0))
    self.num_label:addNode(self.numTxt)

    --显示数量
    self.eqm_lv_txt = Label:create()
    self.eqm_lv_txt:setAnchorPoint(ccp(1,0))
    self.eqm_lv_txt:setColor(ItemHelper.colors.yellow)
    self.eqm_lv_txt:setFontSize(22)
    self:addChild(self.eqm_lv_txt)
	self.eqm_lv_txt:setPosition(ccp(42,20))
    self.eqm_lv_txt:setVisible(false)

    self.is_show_eqm_lv = true

end

function ItemIcon:create()
    local icon = ItemIcon.new()
    icon:init()
    return icon   
end

function ItemIcon:setIsBattleAward(is_battle_award)
    self.is_battle_award = is_battle_award
    if self.eqm_lv_txt and is_battle_award then
        self.eqm_lv_txt:setPosition(ccp(-10,-45))
    end
end

--设置图标的点击事件
function ItemIcon:setTouchEvent(click_event)
    self.icon_bg:setTouchEnabled(true)
    self.icon_bg:addTouchEventListener(click_event)
end

function ItemIcon:getClickImg()
    return self.icon_bg
end

--设置图标的被选中状态
function ItemIcon:setItemIconSelect(is_select)
    if self.select_img == nil then
        self.select_img = ImageView:create() 
        self.select_img:loadTexture("item_select.png",UI_TEX_TYPE_PLIST)
        self:addChild(self.select_img) 
    end

    self.select_img:setVisible(is_select)
end

--设置物品的基础ID
function ItemIcon:setBaseId(base_id)
    self.base_id = base_id
    if  base_id > 0 then
        self.item_mode = ItemManager:getInstance():getItemModelByBaseId(base_id)
        local sex = CharacterManager:getInstance():getBaseData():getSex()
        local icon_res = ""
        if (self.item_mode.icon_id == 60016 or self.item_mode.icon_id == 44000) and
             sex == Helper.sex.female then --女
            icon_res = string.format("item_%d_f.png",self.item_mode.icon_id)
        else
            icon_res = string.format("item_%d.png",self.item_mode.icon_id)
        end
        self.icon_img:setVisible(true)
        self.icon_img:loadTexture(icon_res,UI_TEX_TYPE_PLIST) 

        local quality_path = string.format("quality_border_%d.png",self.item_mode.quality)
       
        self.icon_border:loadTexture(quality_path, UI_TEX_TYPE_PLIST)

        quality_path = string.format("quality_bg_%d.png",self.item_mode.quality)
        self.icon_bg:loadTexture(quality_path,UI_TEX_TYPE_PLIST)
        if ItemManager:getInstance():isEqm(self.item_mode.item_type) or 
           self.item_mode.item_type == ItemHelper.itemType.equip_fragment  then
            self.eqm_lv_txt:setVisible(self.is_show_eqm_lv)
        else
             self.eqm_lv_txt:setVisible(false)
        end
         self.eqm_lv_txt:setText(string.format("lv.%d",self.item_mode.limit_lev))
         --碎片
        self:showFragmentFlag( self.item_mode.item_type == ItemHelper.itemType.equip_fragment )
    else
        self.item_mode = nil
        self.icon_img:setVisible(false)
        self.icon_bg:loadTexture("normal_bg.png",UI_TEX_TYPE_PLIST)
        self.icon_border:loadTexture("normal_border.png", UI_TEX_TYPE_PLIST)
                -- self.quality_border:setVisible(false)
        -- self.icon_bg:loadTexture("normal_bg.png",UI_TEX_TYPE_PLIST)
        self.eqm_lv_txt:setVisible(false)
    end
   
end


function ItemIcon:isShowEqmLv(is_show)
    self.is_show_eqm_lv = is_show
    self.eqm_lv_txt:setVisible(is_show)
end

function ItemIcon:setItemNum(itemNum)
    self.numTxt:setText("")
    self.num_label:setVisible(false)
    if itemNum > 1 then
        self.numTxt:setText(itemNum)
        self.num_label:setVisible(true)
    elseif self.item_mode and 
        ItemManager:getInstance():isEqm(self.item_mode.item_type) 
        or self.item_mode.item_type==ItemHelper.itemType.equip_fragment then
        self.numTxt:setText(ItemHelper:getHeroPosShortName(self.item_mode.limit_stand))
        self.num_label:setVisible(true)
    end
end

function ItemIcon:setPowerNum(powered_lv)
    if powered_lv > 0 then
        self.numTxt:setText(string.format("+%d",powered_lv))
        self.num_label:setVisible(true)
    else
        self.numTxt:setText("")
        self.num_label:setVisible(false)
    end
end
--展示碎片 标志
function ItemIcon:showFragmentFlag(vis)
    if vis then
        if self.imgFragment == nil then
            self.imgFragment = ImageView:create()
            self.imgFragment:loadTexture("equip_fragment.png",UI_TEX_TYPE_PLIST)
            self.imgFragment:setPosition(ccp(-27,27))
            self:addChild(self.imgFragment)
        end
         self.imgFragment:setVisible(true)
    else
        -- if self.imgFragment ~= nil then
        --     self.imgFragment:removeFromParentAndCleanup(true)
        -- end
        if self.imgFragment ~= nil then
            self.imgFragment:setVisible(false)
        end
    end
end

--设置是否显示物品数量，默认显示
function ItemIcon:isShowNumLabel(visible)
    self.num_label:setVisible(visible)
end

--[[
    是否只是显示图标,隐藏背景和边框
]]
function ItemIcon:isShowIconOnly(value)

    if value == true then
        self.icon_bg:setVisible(false)
        self.icon_border:setVisible(false)
        self.numTxt:setVisible(false)
    else
        self.icon_bg:setVisible(true)
        self.icon_border:setVisible(true)
        self.numTxt:setVisible(true)
    end

end

function ItemIcon:setClickEnable(enable)
   self.icon_bg:setTouchEnabled(enable)
end

function ItemIcon:dispose()
    self:removeAllChildren()
end

--设置附魔特效
function ItemIcon:setEnchanteffect(enchant_lev)
    if self.enchant_lev == enchant_lev then
        return
    end

    self.enchant_lev = enchant_lev

    local effect_name = ItemHelper:getEnchentEffectName(enchant_lev)
    if enchant_lev>0 and effect_name then
        if self.enchant_effect  then
            self.enchant_effect:getAnimation():stop()
            self.enchant_effect:removeFromParentAndCleanup(true)
            self.enchant_effect = nil
        end

      
        local effect_path = string.format("ui/effects_ui/%s/%s.ExportJson",effect_name,effect_name)
        self.enchant_effect = AnimateManager:getInstance():getArmature(effect_path,effect_name)
        self.enchant_effect:getAnimation():playWithIndex(0,-1,-1,1)
        self:addNode(self.enchant_effect)
    else
        if self.enchant_effect then
            self.enchant_effect:getAnimation():stop()
            self.enchant_effect:removeFromParentAndCleanup(true)
            self.enchant_effect = nil
        end
    end
end

function ItemIcon:setBorderVisible(is_visible)
    self.icon_border:setVisible(is_visible)
end

function ItemIcon:hideExtInfo()
    
end
---------------------------------------------
function ItemIcon:isShowPercLab(vis)
    if vis then
        if self.labPerc == nil then
            self.labPerc = Label:create()
            self.labPerc:setColor(ItemHelper.colors.yellow)
            self.labPerc:setFontSize(24)
            self.labPerc:setPosition(ccp(3, -30))
            self:addChild(self.labPerc)
            self.tmp_quantity = 0
        end
    else
        if self.labPerc then
            self.labPerc:removeFromParentAndCleanup(true)
            self.labPerc = nil
        end
        self.tmp_quantity = nil
    end
end

function ItemIcon:setLabPercTxt(str)
    self.labPerc:setText(str)
end

function ItemIcon:isShowDelBtn(vis)
    if vis then
        if self.btnDel == nil then
            self.btnDel = Button:create()
            self.btnDel:loadTextureNormal("btn_up_11.png", UI_TEX_TYPE_PLIST)
            self.btnDel:loadTexturePressed("btn_down_11.png", UI_TEX_TYPE_PLIST)
            self.btnDel:setPosition(ccp(42, 42))
            self:addChild(self.btnDel)
        end
        self.btnDel:setVisible(true)
        self.btnDel:setTouchEnabled(true)
    else
        if self.btnDel then
            self.btnDel:setVisible(false)
            self.btnDel:setTouchEnabled(false)
        end
    end
end

function ItemIcon:setDelBtnFunc(func)
    if self.btnDel == nil then
        self.btnDel = Button:create()
        self.btnDel:loadTextureNormal("btn_up_11.png", UI_TEX_TYPE_PLIST)
        self.btnDel:loadTexturePressed("btn_down_11.png", UI_TEX_TYPE_PLIST)
        self.btnDel:setPosition(ccp(42, 42))
        self.btnDel:setVisible(false)
        self.btnDel:setTouchEnabled(false)
        self:addChild(self.btnDel)
    end
    if self.btnDel then
        self.btnDel:addTouchEventListener(func)
    end
end