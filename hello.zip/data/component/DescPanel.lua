--通用 规则 描述 面板

DescPanel = class("DescPanel",WindowBase)
DescPanel.__index = DescPanel
DescPanel._widget     = nil
DescPanel.uiLayer    = nil
DescPanel.is_dispose = true

local __instance = nil

function DescPanel:create()
    local ret = DescPanel.new()
    __instance = ret
    return ret   
end

function DescPanel:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end

function DescPanel:init()
	--加载纹理
    ComResMgr:getInstance():loadOtherRes()
	require "ItemIcon"
	require "ItemInfoPanel"

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/common/DescPanel.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

	self.labDesc = tolua.cast(self._widget:getChildByName("lab_desc"),"Label")

	self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
	self.btnClose:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then
			-- self:addCloseAnim()
			WindowCtrl:getInstance():close(self.name)
		end
	end)

	self.labTitle = tolua.cast(self.uiLayer:getWidgetByName("lab_title"),"Label")
	self.labDesc = tolua.cast(self.uiLayer:getWidgetByName("lab_desc"),"Label")
	self.scrolView = tolua.cast(self.uiLayer:getWidgetByName("scrol_view"),"ScrollView")
	self.labTitle1  = tolua.cast(self.uiLayer:getWidgetByName("lab_title1"),"Label")
	self.labTitle2  = tolua.cast(self.uiLayer:getWidgetByName("lab_title2"),"Label")

end

function DescPanel:open()
	
	self.title = self.params["title"]
	self.content = self.params["content"]
	self.innerHight = self.params["innerHight"] or 450
	self.rewardArr = self.params["rewardArr"] or {}
	
	-- self:addOpenAnim(function()
		self:update()
	-- end)
end

function DescPanel:update()

	self.labTitle:setText(self.title.."規則說明")
	self.labTitle1:setText(self.title.."核心獎勵：")
	self.labTitle2:setText(self.title.."戰鬥規則：")
	self.labDesc:setText(self.content)

	local offsetY = 130
	local nlCount = Helper.nlCount(self.content) --获取换行符个数
	local contentHeight = (nlCount + 4) * 22 + offsetY --根据字数约取高度

	self.scrolView:setInnerContainerSize(CCSize(840,contentHeight))

	self.labTitle1:setPosition(ccp(7,contentHeight - 12))
	self.labTitle2:setPosition(ccp(7,contentHeight - 103))

	local innerSize = self.scrolView:getInnerContainerSize()
	self.labDesc:setSize(CCSize(825,innerSize.height))
	self.labDesc:setPosition(ccp(8,innerSize.height - offsetY))

	local baseX = 56
	local rewardOffsetY = 58
	for i,v in ipairs(self.rewardArr) do
		local img = ImageView:create()
		img:loadTexture(v.img,UI_TEX_TYPE_PLIST)
		img:setAnchorPoint(ccp(0, 0.5))
		img:setPosition(ccp(baseX + (i-1) * 160 ,contentHeight - rewardOffsetY ))
		self.scrolView:addChild(img)

		local lab = Label:create()
		lab:setColor(ItemHelper.colors.yellow)
		lab:setFontSize(22)
		lab:setPosition(ccp(img:getPositionX()+img:getContentSize().width + 10, contentHeight - rewardOffsetY))
		lab:setAnchorPoint(ccp(0, 0.5))
		lab:setText(v.lab)
		self.scrolView:addChild(lab)
	end
end