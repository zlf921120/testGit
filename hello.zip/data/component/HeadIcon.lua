--
-- Author: lvgansheng
-- Date: 2014-08-07 16:30:28
-- 角色头像

HeadIcon = class("HeadIcon", DisplayUtil.newWidget)

HeadIcon.icon_img = nil

HeadIcon.face_id = 0

HeadIcon.icon_width = 111
HeadIcon.icon_height = 111

function HeadIcon:init(bg_type)
	--图标背景框

	local bg_type = bg_type or 1

	local bg_img_name = "head_icon_bg.png"

	if bg_type==2 then
		bg_img_name = "main_ui_head_bg.png"
	end

	self.iconBg = ImageView:create()
	self.iconBg:setTouchEnabled(false)
	self.iconBg:loadTexture(bg_img_name,UI_TEX_TYPE_PLIST)
	self:addChild(self.iconBg)	
	
    self.icon_img = ImageView:create()
    self.icon_img:setTouchEnabled(false)
    self:addChild(self.icon_img)

    HeroManager:getInstance():loadHeroIconPlist()
 --    local icon_border = ImageView:create()
 --    icon_border:loadTexture("head_icon_border.png",UI_TEX_TYPE_PLIST)
	-- self:addChild(icon_border)	

	-- self:setSize(self.iconBg:getSize())
end

function HeadIcon:create(bg_type)
	local icon = HeadIcon.new()
	icon:init(bg_type)
	-- icon:setFaceId(10000)
	--测试代码，聊天跟帮会信息结构中没有头像ID
	-- local idx = math.random(1,17)
	-- icon:setFaceId(10000+idx)
	return icon
end

function HeadIcon:setFaceId(face_id,gender)
	-- self.face_id = face_id
	-- if face_id == self.face_id then
	-- 	cclog("頭像沒變化")
	-- 	return
	-- end
	if face_id==0 then
		return 
	end

	self.face_id = face_id --暂时写死，等头像功能完善后去掉
	local res_name = string.format("face_%d.png",self.face_id)
	if self.face_id == HeroManager.LEADING_HERO_ID then
		local sex = CharacterManager:getInstance():getBaseData():getSex()
		if gender ~= nil then
			sex = gender
		end
		if sex == Helper.sex.female then
			res_name = "face_10000_f.png"
		else
			res_name = "face_10000_m.png"
		end
	end 
	if self.res_name == res_name then
		return
	end
	self.res_name = res_name
	self.icon_img:loadTexture(res_name,UI_TEX_TYPE_PLIST)
end

--GM 头像
function HeadIcon:setGmFace()
	self.icon_img:loadTexture("gm_10000.png",UI_TEX_TYPE_PLIST)
end

function HeadIcon:setDefaultFace()
	self.icon_img:loadTexture("face_10000_m.png",UI_TEX_TYPE_PLIST)
end

--设置图标的点击事件
function HeadIcon:setClickEvent(click_event)
    self.iconBg:setTouchEnabled(true)
    self.iconBg:addTouchEventListener(click_event)
end

function HeadIcon:isShowBg(is_visible)
	 self.iconBg:setVisible(is_visible)
end