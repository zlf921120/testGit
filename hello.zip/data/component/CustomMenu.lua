--
-- Author: lvgansheng
-- Date: 2014-07-03 17:55:53
-- 自定义menu控件

CustomMenu = class("CustomMenu", function() return CCMenu:create() end)
CustomMenu.item_arr = nil
CustomMenu.label_arr = nil
CustomMenu.cur_idx = 0 -- 当前选中的按钮

local scale_x = 1
local scale_y = 1

function CustomMenu:init()
	self.item_arr = CCArray:create()
	self.item_arr:retain()

	self.label_arr = CCArray:create()
	self.label_arr:retain()

end

function CustomMenu:create()
	local menu = CustomMenu.new()
	menu:init()
	return menu
end

local function getResPathByType(menu_type)
	if menu_type == 1 then
		return "btn_down_8.png","btn_up_8.png"
	end
end

function CustomMenu:setBtnScalex(value)
	scale_x = value
end

function CustomMenu:setBtnScaley(value)
	scale_y = value
end

--[[
@param data = {{txt:"按鈕文本"}}
--]]
function CustomMenu:setData(data,callback,menu_type)

	local function onMenuClick(tag, sender)
        self:setSelectedItem(tag)

        if callback ~= nil then
        	callback(tag)
        end
	end

	self._data = data
	local num = #data
	local temp_toggle = nil
	local label = nil
	local menu_type = menu_type or 1
	local normal_path, press_path = getResPathByType(menu_type)
	local ccsize = nil
	for i = 1,num do
		local one_menu_item_one = CCSprite:createWithSpriteFrameName(normal_path)
		local one_menu_item_two = CCSprite:createWithSpriteFrameName(press_path)
		local one_menu_item = CCMenuItemSprite:create(one_menu_item_one,one_menu_item_two)

		local two_menu_item_one = CCSprite:createWithSpriteFrameName(press_path)
		local two_menu_item_two = CCSprite:createWithSpriteFrameName(normal_path)
		-- two_menu_item_one:setPositionX(-10)
		local two_menu_item = CCMenuItemSprite:create(two_menu_item_one,two_menu_item_two)
		-- two_menu_item:setPositionX(-10)

		temp_toggle = CCMenuItemToggle:create(one_menu_item)
    	temp_toggle:addSubItem(two_menu_item)
 		
 		--temp_toggle:setScaleX(scale_x)
 		--temp_toggle:setScaleY(scale_y)
 		--设置按钮文本
 		ccsize = temp_toggle:getContentSize()
 		label = Label:create()
 		label:setFontSize(24)
 		label:setText(data[i].txt)
 		label:setPosition(ccp(ccsize.width/2,ccsize.height/2))
 		--label:setScaleX(1/scale_x)
 		label:setColor(ccc3(118, 88, 80))
 		--设置相关事件
 		temp_toggle:addChild(label,1)
 		temp_toggle:registerScriptTapHandler(onMenuClick)
 		-- temp_toggle:setPositionX(-100*i)
 		-- temp_toggle:setPositionY(-50*i)
 		self:addChild(temp_toggle,1,i)
 		self.item_arr:addObject(temp_toggle)
 		self.label_arr:addObject(label)
	end

	--默认选中第一个
	self:setSelectedItem(1)
end

--[[
@param index 从1开始，从上往下表示按钮的序号
--]]
function CustomMenu:setSelectedItem(index)

	local temp_toggle = self.item_arr:objectAtIndex(index-1)
	local toggle_label = self.label_arr:objectAtIndex(index-1)

	if temp_toggle == nil then
		cclog ("不存在此index的按鈕")
		return 
	end
	
	if self.cur_idx > 0 then
		local cur_toggle = self.item_arr:objectAtIndex(self.cur_idx-1)
		cur_toggle:setSelectedIndex(0)
    	cur_toggle:setEnabled(true)

    	local cur_toggle_label = self.label_arr:objectAtIndex(self.cur_idx-1)
    	cur_toggle_label:setColor(ccc3(118, 88, 80))
	end

	--设置为不可选
	temp_toggle:setSelectedIndex(1)
    temp_toggle:setEnabled(false)
    toggle_label:setColor(ccc3(251, 241,160))
    self.cur_idx = index
end

function CustomMenu:getSelectIdx()
	return self.cur_idx
end

function CustomMenu:setHideByTbl(tbl)
	for i=1,#self._data do
		local temp_toggle = self.item_arr:objectAtIndex(i-1)
		local toggle_label = self.label_arr:objectAtIndex(i-1)
		temp_toggle:setEnabled(true)
		temp_toggle:setVisible(true)
		toggle_label:setVisible(true)	
	end
	-- self:setSelectedItem(1)

	for i=1,#tbl do
		local temp_toggle = self.item_arr:objectAtIndex(tbl[i]-1)
		local toggle_label = self.label_arr:objectAtIndex(tbl[i]-1)
		temp_toggle:setEnabled(false)
		temp_toggle:setVisible(false)
		toggle_label:setVisible(false)
	end
end

function CustomMenu:getItemByIdx(idx)
	local temp_toggle = self.item_arr:objectAtIndex(idx-1)
	return temp_toggle
end

--[[
    更新按钮文本
]]
function CustomMenu:updateItemText(index, txt)
	if not self._data then
		return
	end

	local label = self.label_arr:objectAtIndex(index - 1)

	if not label then
		return
	end

	label:setText(txt)

end

