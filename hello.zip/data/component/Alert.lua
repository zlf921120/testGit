--提示

require("GameLayerMgr")
Alert = class("Alert",function()
    return DisplayUtil.newFitLayer()
end)
Alert.__index = Alert
Alert._widget 	= nil
Alert._uiLayer 	= nil
Alert._txt 	= nil

local __instance = nil

function Alert:create(txt)
    local ret = Alert.new()
    ret._txt = txt
    ret:init()
    return ret
end

function Alert:getInstance()
    if not __instance then
        local ret = Alert.new()
        __instance = ret
        ret:initInstance()
        ret:retain()
    end
    return __instance
end

function Alert:destoryInstance()
    self:release()
    __instance = nil
end

---------------初始化-----------------------------------------------------
function Alert:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/login/Alert/Alert.json")
    self._uiLayer = TouchGroup:create()
    self._uiLayer:addWidget(self._widget)
	self:addChild(self._uiLayer)

    local labTxt = tolua.cast(self._uiLayer:getWidgetByName("lab_title"),"Label")
    labTxt:setText(self._txt)
    labTxt:setColor(ccc3(251,241,160))

    local img9bg = tolua.cast(self._uiLayer:getWidgetByName("img_bgaleart"),"ImageView")

    img9bg:setSize(CCSizeMake( labTxt:getSize().width + 50, labTxt:getSize().height + 20 ))

    local action = CCSequence:createWithTwoActions(CCDelayTime:create(1),
        CCCallFunc:create(function()
            self:removeFromParentAndCleanup(true)
        end))
    self:runAction(action)

end
---------------初始化  单列---------------------------------------------------------------
function Alert:initInstance()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/common/Alert.ExportJson")
    self._uiLayer = TouchGroup:create()
    self._uiLayer:addWidget(self._widget)
    self:addChild(self._uiLayer)
end

function Alert:setText(txt,color)

    color = color or ccc3(251,241,160)

    local labTxt = tolua.cast(self._uiLayer:getWidgetByName("lab_title"),"Label")
    labTxt:setText(txt)
    labTxt:setColor(color)

    local img9bg = tolua.cast(self._uiLayer:getWidgetByName("img_bgaleart"),"ImageView")
    img9bg:setSize(CCSizeMake( labTxt:getSize().width + 50, labTxt:getSize().height + 20 ))
end

function Alert:animate()

    local img9bg = tolua.cast(self._uiLayer:getWidgetByName("img_bgaleart"),"ImageView")
    img9bg:setScale(0.3)
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.12,1.1))
    arr:addObject(CCScaleTo:create(0.1,1))
    arr:addObject(CCDelayTime:create(1))
    arr:addObject(CCScaleTo:create(0.1,0.01))
    arr:addObject(CCCallFunc:create(function()
        __instance:removeFromParentAndCleanup(false)
    end))
    img9bg:stopAllActions()
    img9bg:runAction(CCSequence:create(arr))
end
--------窗体 消息提示 展示(单列)-----------
function Alert:show(txt,color,rotate)
    local layer = GameLayerMgr:getInstance():getMsgLayer()
    local child = layer:getChildByTag(1005)
    if child ~= nil then
        layer:removeChildByTag(1005,false)
    end

    local alert = Alert:getInstance()
    alert:setTag(1005)
    alert:setPosition(ccp(480,320))
    alert:setText(txt,color)
    alert._widget:setRotation(rotate or 0)
    alert:animate()
    layer:addChild(alert)
end


--[[
    检查使用钻石
]]
function Alert:checkCostDiamond(costValue)

    local cm = CharacterManager:getInstance()

    local diamond = cm:getAssetData():getDiamond()

    if diamond < costValue then

        -- self:show("鑽石不足")
        WindowCtrl:getInstance():open(
                CmdName.Comm_MsgBox, 
                {
                    txt = "鑽石不足"
                }
            )

        return false
    end

    return true

end
