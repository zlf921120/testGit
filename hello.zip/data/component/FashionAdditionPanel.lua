--时装 总加成 提示面板
FashionAdditionPanel = class("FashionAdditionPanel",function()
    return DisplayUtil.newFitLayout()
end)

local __instance = nil

function FashionAdditionPanel:getInstance()
    if not __instance then
        local ret = FashionAdditionPanel.new()
        __instance = ret
        ret:init()
        ret:retain()
    end
    return __instance
end

function FashionAdditionPanel:init()
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/hero/fashion_tips/fashion_tips.ExportJson")
    self:addChild(self._widget)

    for i=1,12 do
    	self["lab_attr"..i] = tolua.cast(self._widget:getChildByName("lab_attr"..i),"Label")
    	self["lab_attr_v"..i] = tolua.cast(self._widget:getChildByName("lab_attr_v"..i),"Label")
    end

end

function FashionAdditionPanel:update(heroId)

    for i=1,12 do
        self["lab_attr"..i]:setVisible(false)
        self["lab_attr_v"..i]:setVisible(false)
    end

    local hm = HeroManager:getInstance()
    local heroInfo = hm:getHeroInfoById(heroId)
    local voList = heroInfo:getFashionSlotEquipsList()

    local totalAddition = {}

    for _,list in pairs(voList) do
        for _,v in pairs(list) do
            local addtions = hm:getFashionAddtion(v.mode.base_id,v.stars,heroId)

            for i,v in ipairs(addtions) do
                totalAddition[v.key] = v.value + (totalAddition[v.key] or 0 )
            end

        end
    end

    local idx = 1
    for key,value in pairs(totalAddition) do
        self["lab_attr"..idx]:setVisible(true)
        self["lab_attr_v"..idx]:setVisible(true)
        self["lab_attr"..idx]:setText(AttrHelper:getAttrNameByFlag(key))
        self["lab_attr_v"..idx]:setText(value)
        idx = idx + 1
    end
end

function FashionAdditionPanel:show(heroId)

	local layer = GameLayerMgr:getInstance():getMsgLayer()
    local child = layer:getChildByTag(3775)
    if child ~= nil then
        layer:removeChildByTag(3775,false)
    end

    local panel = FashionAdditionPanel:getInstance()
    panel:setTag(3775)
    panel:update(heroId)
    layer:addChild(panel)
end

function FashionAdditionPanel:hide()

	local layer = GameLayerMgr:getInstance():getMsgLayer()
    local child = layer:getChildByTag(3775)
    if child ~= nil then
        layer:removeChildByTag(3775,false)
    end
end