--
-- Author: lvgansheng
-- Date: 2014-12-12 14:31:50
-- 显示批量物品图标

BatchItemIcon = class("BatchItemIcon")

BatchItemIcon.DefaultScrollHeight = 400 --背包滚动层的默认高度
BatchItemIcon.DefaultIconWidth = 100 --物品图标的默认宽度
BatchItemIcon.DefaultIconHeight = 90 --物品图标的默认高度
BatchItemIcon.DefaultIconNum = 4 -- 背包一行显示的图标个数
BatchItemIcon.scal_value = 1 -- 缩放比例
BatchItemIcon.num_label_arr = nil
BatchItemIcon.eqm_lv_label_arr = nil

local old_pos_y = 0

function BatchItemIcon:init()
	require("BatchItemData")

	self.itemIconDic = {}
	self.icon_pos_dic = {}
	self.item_id_2_icon_dic = {}

	self.num_label_arr = CCArray:create()
	self.num_label_arr:retain()	

	self.eqm_lv_label_arr = CCArray:create()
	self.eqm_lv_label_arr:retain()

	self.sc_view = ScrollView:create()
    self.sc_view:setSize(CCSize(400, 190))
    self.sc_view:setDirection(SCROLLVIEW_DIR_VERTICAL)
    self.sc_view:setBounceEnabled(true)
    self.sc_view:setClippingEnabled(true)
    self.sc_view:retain()
    -- self.uiLayer:addWidget(self.sc_view)

    self.item_bg_batch_node = CCSpriteBatchNode:create("ui/common/common.pvr.ccz",10)
	self.item_icon_batch_node = CCSpriteBatchNode:create("ui/common/item_icon.pvr.ccz",10)
	self.item_border_batch_node = CCSpriteBatchNode:create("ui/common/common.pvr.ccz",10)
	self.ext_img_batch_node = CCSpriteBatchNode:create("ui/common/common.pvr.ccz",10) --显示一些额外的信息
 	self.label_layer = DisplayUtil.newLayer()

	self.sc_view:addNode(self.item_bg_batch_node)
	self.sc_view:addNode(self.item_icon_batch_node)
	self.sc_view:addNode(self.item_border_batch_node)
	self.sc_view:addNode(self.label_layer)
	self.sc_view:addNode(self.ext_img_batch_node)


	self.sc_view:addTouchEventListener(function(sender, eventType) 
		if eventType == ComConstTab.TouchEventType.ended then
			local tmp_y = self.sc_view:getInnerContainer():getPositionY()
			local touch_pos = self.sc_view:getTouchEndPos()
			
            local begin_touch_pos = self.sc_view:getTouchStartPos()
            local diff_value = begin_touch_pos.y-touch_pos.y
            if diff_value>60 or diff_value<-60 then
                return
            end

			local innerHeight = self.sc_view:getInnerContainerSize().height

			local rel_x = touch_pos.x-self.tmp_af_x
			local rel_y = touch_pos.y-self.tmp_af_y-tmp_y
			local tmp_row_value = (innerHeight-rel_y)/BatchItemIcon.DefaultIconHeight
			local tmp_col_value = (rel_x)/BatchItemIcon.DefaultIconWidth

			tempBtn = self.icon_pos_dic[self:getIconPosKey(tmp_row_value, tmp_col_value)]  

			if tempBtn==nil then
				cclog("這個位置沒東西~~~%f~~~~%f",tmp_row_value,tmp_col_value)
				return
			end

			local icon_rel_diff_x = rel_x-tempBtn:getRealPos().x
			local icon_rel_diff_y =tempBtn:getRealPos().y-rel_y
			cclog("icon_rel_diff_x=%f~~~~~icon_rel_diff_y=%f",icon_rel_diff_x,icon_rel_diff_y)
			if icon_rel_diff_x>40 and icon_rel_diff_y<50 and tempBtn:isSubIconShow() then
				tempBtn:subFeedNum()
			else
				tempBtn:addFeedNum()
			end

		elseif eventType == ComConstTab.TouchEventType.moved  then
			if -self.sc_view:getInnerContainer():getPositionY()-old_pos_y>-200 and 
				-self.sc_view:getInnerContainer():getPositionY()-old_pos_y<200 and old_pos_y~=0 then
				return
			end

			self:showDescLabel()
		end
	end)

end

function BatchItemIcon:create()
	local batch_item_icon = BatchItemIcon.new()
	batch_item_icon:init()
	return batch_item_icon
end

function BatchItemIcon:setAdjustPos()
	local temp_af = self.sc_view:nodeToWorldTransform()
	self.tmp_af_x = temp_af.tx 
	self.tmp_af_y = temp_af.ty 
end

function BatchItemIcon:setData(item_list)
	self.item_bg_batch_node:removeAllChildrenWithCleanup(true)       
	self.item_icon_batch_node:removeAllChildrenWithCleanup(true)
	self.item_border_batch_node:removeAllChildrenWithCleanup(true)       
	self.ext_img_batch_node:removeAllChildrenWithCleanup(true)       

	local item_list = item_list or {}
	local count =  #item_list
	self.icon_pos_dic = {}
	self.item_id_2_icon_dic= {}
	self:setScrollHeight(count)	
		
	local tmp_item_data = nil
	local tempBtn = nil
	local innerHeight = self.sc_view:getInnerContainerSize().height
	local tmp_row_value = 0
	local tmp_col_value = 0

	for i = 1,count do
		tmp_item_data = item_list[i]
		tempBtn = self.itemIconDic[tmp_item_data.id]
		if tempBtn == nil then
			tempBtn = BatchItemData:create(self.scal_value)
			self.itemIconDic[tmp_item_data.id] = tempBtn
		end

		tmp_row_value = math.modf((i-1)/BatchItemIcon.DefaultIconNum)
		tmp_col_value = (i-1)%BatchItemIcon.DefaultIconNum

		tempBtn:changeItemData(tmp_item_data)

		self.item_bg_batch_node:addChild(tempBtn:getIconBg())
		self.item_icon_batch_node:addChild(tempBtn:getItemIcon())
		self.item_border_batch_node:addChild(tempBtn:getIconBorder())
		self.ext_img_batch_node:addChild(tempBtn:getSubIcon())

		if tempBtn:isShowEqmFrag() then
			self.ext_img_batch_node:addChild(tempBtn:getEqmFragImg())
		end

		tempBtn:setRealPos(CCPoint(BatchItemIcon.DefaultIconWidth*tmp_col_value, 
			innerHeight -(BatchItemIcon.DefaultIconHeight*tmp_row_value)))

		self.icon_pos_dic[self:getIconPosKey(tmp_row_value, tmp_col_value)] = tempBtn
		self.item_id_2_icon_dic[tmp_item_data.id] = tempBtn
	end

	self:showDescLabel()
end

function BatchItemIcon:getIconPosKey(row_value, col_value)
	local row_value = math.floor(row_value)
	local col_value = math.floor(col_value)
	return row_value.."_"..col_value
end

function BatchItemIcon:setScrollHeight(itemNum) --设置背包滚动层高度
	local innerWidth = self.sc_view:getSize().width
	local innerHeight = math.ceil(itemNum/BatchItemIcon.DefaultIconNum)*BatchItemIcon.DefaultIconHeight --滚动框高度由物品个数决定
		
	if 	innerHeight<BatchItemIcon.DefaultScrollHeight then
		innerHeight = BatchItemIcon.DefaultScrollHeight
	end	

	self.sc_view:setInnerContainerSize(CCSize(innerWidth, innerHeight))
end	

function BatchItemIcon:getScView()
	return self.sc_view
end

function BatchItemIcon:setIconScal(scal_value)
	self.scal_value = scal_value
end

function BatchItemIcon:getItemIconDic()
	return self.itemIconDic
end

function BatchItemIcon:showDescLabel()
	self.label_layer:removeAllChildrenWithCleanup(true)
	old_pos_y = -self.sc_view:getInnerContainer():getPositionY()
	local idx = 0
	local eqm_lv_idx = 0
	local tmp_label = nil
	local tmp_count = self.num_label_arr:count()
	local tmp_eqm_lv_count = self.eqm_lv_label_arr:count()
	for i,tmp_icon in pairs(self.itemIconDic) do
		if tmp_icon:getRealPos().y>old_pos_y-500 and tmp_icon:getRealPos().y<old_pos_y+800 
			and tmp_icon:getIconBg():getParent() then
			
			--数量
			if idx>=tmp_count then
				tmp_label = CCLabelTTF:create()
				tmp_label:setAnchorPoint(ccp(0.5,0))
				tmp_label:setScale(self.scal_value)
				tmp_label:setFontSize(20)
				-- tmp_label:setString("12")
				-- tmp_label:setColor(ItemHelper.colors.yellow)
				-- tmp_label = Utils.createStrokeLabel(tmp_label,1,ccc3(0,0,0))
				self.num_label_arr:addObject(tmp_label)
			else
				tmp_label = self.num_label_arr:objectAtIndex(idx)
			end
			tmp_label:setString(tmp_icon:getNumDesc())
			tmp_icon:setCurNumLabel(tmp_label)
			tmp_label:setPosition(ccp(tmp_icon:getRealPos().x+42,tmp_icon:getRealPos().y-90))
			self.label_layer:addChild(tmp_label)
			idx = idx+1			

			--装备等级
			if tmp_icon:isShowEqmLv() then
				if eqm_lv_idx>=tmp_eqm_lv_count then
					tmp_label = CCLabelTTF:create()
					tmp_label:setAnchorPoint(ccp(1,1))
					tmp_label:setScale(self.scal_value)
					tmp_label:setFontSize(20)
					-- tmp_label:setString("12")
					tmp_label:setColor(ItemHelper.colors.yellow)
					self.eqm_lv_label_arr:addObject(tmp_label)
				else
					tmp_label = self.eqm_lv_label_arr:objectAtIndex(eqm_lv_idx)
				end
				tmp_label:setString(tmp_icon:getItemLvDesc())
		
				tmp_label:setPosition(ccp(tmp_icon:getRealPos().x+76,tmp_icon:getRealPos().y-20))
				self.label_layer:addChild(tmp_label)
				eqm_lv_idx = eqm_lv_idx+1
			end
		end
	end
end

--根据行列获取图标
--@param row_num 从0开始
--@param col_num 从0开始
function BatchItemIcon:getItemIconByRowCol(row_num, col_num)
	local tmp_icon = self.icon_pos_dic[self:getIconPosKey(row_num, col_num)]
	return tmp_icon
end

function BatchItemIcon:getIconByItemId(item_id)
	return self.item_id_2_icon_dic[item_id]
end