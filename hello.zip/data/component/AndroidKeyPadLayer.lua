--
-- Author: lvgansheng
-- Date: 2014-12-23 20:52:11
-- 安卓平台的实体按键响应层

--找到java无法监听返回键bug后需要去掉
AndroidKeyPadLayer = class("AndroidKeyPadLayer", DisplayUtil.newLayer)

function AndroidKeyPadLayer:init()
	self:setKeypadEnabled(true)
	self:registerScriptKeypadHandler(function(event)
	       if event == "back" then      
	       		cclog("press back btn")   
	       		SdkManager:exitSDK()   
	       	elseif event == "menu" then     
	       		cclog("press home btn")   
	       	end
	end)
end

function AndroidKeyPadLayer:create()
	local layer = AndroidKeyPadLayer.new()
	layer:retain()
	layer:init()
	return layer
end

function AndroidKeyPadLayer:setCurParent(parent_node)
	if self:getParent() then
		self:removeFromParentAndCleanup(true)
	end

	parent_node:addChild(self)
end