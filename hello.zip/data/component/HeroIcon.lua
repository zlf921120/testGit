--
-- Author: lvgansheng
-- Date: 2014-07-15 17:39:51
-- 通用英雄头像

HeroIcon = class("HeroIcon", function() return Widget:create() end)

HeroIcon.img = nil
HeroIcon.hero_info = nil

HeroIcon.id = 0

local icon_width = 90
local icon_height = 90

local star_dis = 20 --星星之间的距离

local default_border_path = "hero_quality_border_1.png"

HeroIcon.star_icons = nil

function HeroIcon:init()

	require("HeroHelper")

	self.star_icons = {}

    --判断是否已经加载过头像资源，没有则开始加载
    HeroManager:getInstance():loadHeroIconPlist()

	--图标背景框
	--local iconBg = ImageView:create()
	--iconBg:loadTexture("normal_bg.png",UI_TEX_TYPE_PLIST)
	--self:addChild(iconBg)	
	

    self.icon_border = ImageView:create()
    self.icon_border:loadTexture(default_border_path,UI_TEX_TYPE_PLIST)
	self:addChild(self.icon_border)	


    self.icon_img = ImageView:create()
    self.icon_img:setPositionY(12)
    self.icon_img:setPositionX(1)
    self:addChild(self.icon_img)

	-- local lev_bg =  ImageView:create()
	-- lev_bg:setScale(0.83)
 --    lev_bg:loadTexture("circle.png",UI_TEX_TYPE_PLIST)
 --    lev_bg:setPosition(ccp(42,42))
	-- self:addChild(lev_bg)	

	-- self.lev_label = Label:create()
	-- self.lev_label:setFontSize(20)
	-- self.lev_label:setColor(ItemHelper.colors.yellow)
	-- lev_bg:addChild(self.lev_label)	

	self.star_layer = DisplayUtil.newWidget()
	self:addChild(self.star_layer)
end

function HeroIcon:create()
	local icon = HeroIcon.new()
	icon:init()
	return icon
end

--设置自己英雄
function HeroIcon:setHeroId(id, sex)
	self.id = id
	if id == 0 then
		self.hero_info = nil
	else
		self.hero_info = HeroManager:getInstance():getHeroInfoById(id)
	end 

	self:setHeadImg(sex)
	self:updateExtInfo()
	self:setPosImg()
end

function HeroIcon:setHeadImg(sex)
	local sex = sex or CharacterManager:getInstance():getBaseData():getSex()
	if self.hero_info then
		self.icon_img:setVisible(true)
		self.icon_border:setVisible(true)
		-- local res_name = string.format("hero_%d.png",self.hero_info.icon_res_id)--新的头像还没有
		local res_name = string.format("hero_%d.png",self.hero_info.icon_res_id)
		if self.hero_info.base_id == HeroManager.LEADING_HERO_ID or 
			self.hero_info.base_id == HeroManager.PLOT_HERO_ID then
			-- local sex = CharacterManager:getInstance():getBaseData():getSex()
			if sex == Helper.sex.female then
				res_name = "hero_10000_f.png"
			else
				res_name = "hero_10000_m.png"
			end
		end
		-- self.icon_img:loadTexture("hero_10000_f.png",UI_TEX_TYPE_PLIST)
		self.icon_img:loadTexture(res_name,UI_TEX_TYPE_PLIST)
	else
		self.icon_border:setVisible(false)
		self.icon_img:setVisible(false)
		return
	end
end

--设置其它玩家的英雄
function HeroIcon:setOtherHeroInfo(hero_info, sex)
	self.hero_info = hero_info
	self:setHeadImg(sex)
	self:updateExtInfo()
end

function HeroIcon:updateExtInfo()

	--不需要显示头像以外的元素
	if self.is_hide_other_elem then
		return
	end

	if self.hero_info then
		self.star_layer:setVisible(true)
		--设置星级
		local star_icon = nil
		for i=1,HeroHelper.MaxStar do
			star_icon = self.star_icons[i]
			if self.hero_info.cur_stars<i then
				if star_icon ~= nil then
					star_icon:setVisible(false)
				end
			else
				if star_icon == nil then
					star_icon = ImageView:create()
					self.star_icons[i] = star_icon
					star_icon:setPositionY(-45)
					star_icon:setScale(0.3)
					self.star_layer:addChild(star_icon)
					star_icon:setPositionX(i*star_dis)
				end
				star_icon:setVisible(true)
				star_icon:loadTexture(HeroHelper.getStarResPath(self.hero_info.cur_stars), UI_TEX_TYPE_PLIST)
			end 
		end
		self.star_layer:setPositionX(-star_dis*self.hero_info.cur_stars/2-22)
	else
		self.star_layer:setVisible(false)
	end

	--更新品质框
	if self.hero_info and self.hero_info.cur_stars>0 then
		local quality_path = string.format("hero_quality_border_%d.png",self.hero_info.cur_stars)
		-- if self.quality_path ~= quality_path then
			-- self.quality_path = quality_path
			self.icon_border:loadTexture(quality_path,UI_TEX_TYPE_PLIST)
		-- end
	else
		-- if self.quality_path ~=	default_border_path then
		-- 	self.quality_path = default_border_path
		-- 	self.icon_border:loadTexture(self.quality_path,UI_TEX_TYPE_PLIST)
		-- end	
		self.icon_border:loadTexture(default_border_path,UI_TEX_TYPE_PLIST)
	end
end

--设置图标的点击事件
function HeroIcon:setClickEvent(click_event)
    self.icon_img:setTouchEnabled(true)
    self.icon_img:addTouchEventListener(click_event)
end

function HeroIcon:setIsActive(is_active)
	if is_active then
		self.icon_img:setColor(ccc3(255, 255, 255))
	else
		self.icon_img:setColor(ccc3(80, 80, 80))
	end
end


function HeroIcon:setIconColor(color_ccc3)
	self.icon_img:setColor(color_ccc3)
end

--隐藏除了头像以外的元素
function HeroIcon:hideOtherElem()
	self.is_hide_other_elem = true
	if self.star_layer then
		self.star_layer:setVisible(false)
	end

	if self.icon_border then
		 self.icon_border:setVisible(false)
	end

end

function HeroIcon:setIsShowPosImg(is_show)
	self.is_show_pos_img = is_show
end

function HeroIcon:setPosImg()
	if self.is_show_pos_img then
		if self.pos_img == nil then
			self.pos_img = ImageView:create()
			self.pos_img:setPosition(ccp(52	,-35))
			self:addChild(self.pos_img)
		end
		if self.hero_info then
			self.pos_img:loadTexture(ItemHelper:getHeroPosImgName(self.hero_info.pos), UI_TEX_TYPE_PLIST)
		end
		self.pos_img:setVisible(true)
	else
		if self.pos_img then
			self.pos_img:setVisible(false)
		end
	end
end