--滚动公告层
ScrollBroad = class("ScrollBroad",function()
    return DisplayUtil.newFitLayer()
end)
ScrollBroad.__index = ScrollBroad

local __instance = nil

function ScrollBroad:getInstance()
    if not __instance then
        local ret = ScrollBroad.new()
        __instance = ret
        ret:init()
        ret:retain()
    end
    return __instance
end

function ScrollBroad:init()

    self.panel = Layout:create()
    self.panel:setSize(CCSize(750,50))
    self.panel:setPosition(ccp(92,433))
    self.panel:setClippingEnabled(true)
    self:addChild(self.panel)

    local imgBg = ImageView:create()
    imgBg:loadTexture("bg_17.png",UI_TEX_TYPE_PLIST) 
    imgBg:setScaleX(9.8)
    imgBg:setOpacity(130)
    imgBg:setAnchorPoint(ccp(0,0.5))
    imgBg:setPosition(ccp(5,25))
    self.panel:addChild(imgBg)
end

function ScrollBroad:show()

    if SceneCtrl:getInstance():getCurScene() == CmdName.MAIN_SCENE and
        BattleManager:getInstance():isBattle() == false then --只有在主界面 非战斗 才显示
        local layer = GameLayerMgr:getInstance():getMsgLayer()
        if layer then
            local child = layer:getChildByTag(1009)
            if child ~= nil then
                layer:removeChildByTag(1009,false)
            end

            local view = ScrollBroad:getInstance()
            view:setTag(1009)
            view:setPosition(ccp(0,0))
            layer:addChild(view)
            view:checkShow()
        end
    end
end

function ScrollBroad:hide()
    local layer = GameLayerMgr:getInstance():getMsgLayer()
    if layer then
        local child = layer:getChildByTag(1009)
        if child ~= nil then
            layer:removeChildByTag(1009,false)
        end
    end
    TimerManager.removeTimer(ScrollBroad:getInstance().progressTimer)
end

function ScrollBroad.progressTimer()
    local dp = CharacterDataProxy:getInstance()
    local rtf = __instance.panel:getChildByTag(6954)
    local w = rtf:getSize().width
    local perc = math.abs( (rtf:getPositionX() + w) / (750 + w) )
    local arr = CCArray:create()
    arr:addObject(CCDelayTime:create(0.1))
    arr:addObject(CCMoveTo:create(10 * perc,ccp(-w,35)))
    arr:addObject(CCCallFunc:create(function()
        table.remove(dp:getScrolCacheList(),1) --清理队列 
        __instance.panel:removeChildByTag(6954,true)

        __instance:checkShow() --检测队列
    end))
    rtf:stopAllActions()
    rtf:runAction(CCSequence:create(arr))
end

function ScrollBroad:checkShow()
    local dp = CharacterDataProxy:getInstance()
    local voList = dp:getScrolCacheList()
    if #voList > 0 and BattleManager:getInstance():isBattle() == false then
        local rtf = self.panel:getChildByTag(6954)
        if rtf == nil then
            rtf = ChatHelper.createTextRtf(voList[1],0,50,ccp(0,1),true)
            rtf:setTag(6954)
            rtf:setPosition(ccp(700,35 ))
            self.panel:addChild(rtf)
        end

        TimerManager.addTimer(100,ScrollBroad:getInstance().progressTimer)
    else
        ScrollBroad:hide()
    end
end