-----------------------------------------------------------------------
--公会头像
GuildIcon = class("GuildIcon", function() return Widget:create() end)
GuildIcon.img = nil
GuildIcon.id = 0
GuildIcon.icon_img = nil

function GuildIcon:init()

	--判断是否已经加载过头像资源，没有则开始加载
	require "GuildLocalReader"
    GuildLocalReader:getInstance():loadInProxy()

	--图标背景框
	self.icon_bg = ImageView:create()
	self.icon_bg:loadTexture("normal_bg.png",UI_TEX_TYPE_PLIST)
	self:addChild(self.icon_bg)	    

	self.icon_img = ImageView:create()
    self:addChild(self.icon_img)

    self.icon_mask = ImageView:create()
    self.icon_mask:loadTexture("bg_17.png",UI_TEX_TYPE_PLIST)
    self.icon_mask:setPosition(ccp(0,-30))
    self.icon_mask:setScaleX(1.10)
    self.icon_mask:setScaleY(0.70)
    self.icon_mask:setVisible(false)
    self:addChild(self.icon_mask)

	local icon_border = ImageView:create()
    icon_border:loadTexture("normal_border.png",UI_TEX_TYPE_PLIST)
	self:addChild(icon_border)	

end

function GuildIcon:create()
	local icon = GuildIcon.new()
	icon:init()
	return icon
end

function GuildIcon:setId(id)
	self.id = id
	local iconVo = GuildDataProxy:getInstance():getIconVoById(self.id)
	if iconVo then
		local res_name = string.format("%s.png",iconVo.resId)
		self.icon_img:loadTexture(res_name,UI_TEX_TYPE_PLIST)
	end
end

function GuildIcon:getClickImg()
	return self.icon_img
end

function GuildIcon:setLev(lev)
	self.icon_mask:setVisible(lev > 0)
	if self.labLev == nil then
		self.labLev = Label:create()
		self.labLev:setAnchorPoint(ccp(0,0.5))
	    self.labLev:setPosition(ccp(-30,-30))
	    self.labLev:setFontSize(22)
	    self.labLev:setColor(ItemHelper.colors.yellow)
		self:addChild(self.labLev)
	end
	self.labLev:setText(string.format("Lv.%d",lev))
end

--设置图标的点击事件
function GuildIcon:setClickEvent(click_event)
    self.icon_img:setTouchEnabled(true)
    self.icon_img:addTouchEventListener(click_event)
end

-----------------------------------------------------------------------
--公会技能 图标
GuildSkillIcon = class("GuildSkillIcon", function() return Widget:create() end)
GuildSkillIcon.img = nil
GuildSkillIcon.id = 0
GuildSkillIcon.icon_img = nil
GuildSkillIcon.lev = 0

function GuildSkillIcon:init()

	--判断是否已经加载过头像资源，没有则开始加载
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/organiz/guild_skill.plist")

	--图标背景框
	self.icon_bg = ImageView:create()
	self.icon_bg:loadTexture("normal_bg.png",UI_TEX_TYPE_PLIST)
	self:addChild(self.icon_bg)	    

	self.icon_img = ImageView:create()
    self:addChild(self.icon_img)

    self.icon_mask = ImageView:create()
    self.icon_mask:loadTexture("bg_17.png",UI_TEX_TYPE_PLIST)
    self.icon_mask:setPosition(ccp(0,-30))
    self.icon_mask:setScaleX(1.10)
    self.icon_mask:setScaleY(0.70)
    self:addChild(self.icon_mask)

	local icon_border = ImageView:create()
    icon_border:loadTexture("normal_border.png",UI_TEX_TYPE_PLIST)
	self:addChild(icon_border)	
end

function GuildSkillIcon:create()
	local icon = GuildSkillIcon.new()
	icon:init()
	return icon
end

function GuildSkillIcon:setId(id)
	local res_name = string.format("guild_skill_icon_%d.png",id)
	self.icon_img:setTag(id) --标记id

	self.icon_img:loadTexture(res_name,UI_TEX_TYPE_PLIST)
end

function GuildSkillIcon:setLev(lev)
	if self.labLev == nil then
		self.labLev = Label:create()
		self.labLev:setAnchorPoint(ccp(0,0.5))
	    self.labLev:setPosition(ccp(-30,-30))
	    self.labLev:setFontSize(22)
	    self.labLev:setColor(ItemHelper.colors.yellow)
		self:addChild(self.labLev)
	end
	if lev <= 0 then
		self.labLev:setText("未學習")
	else
		self.labLev:setText(string.format("Lv.%d",lev))
	end
end

--设置图标的点击事件
function GuildSkillIcon:setClickEvent(click_event)
    self.icon_img:setTouchEnabled(true)
    self.icon_img:addTouchEventListener(click_event)
end

--显示向上图标
function GuildSkillIcon:showUpImg(vis)
	if vis then
        if self.imgUp == nil then
            self.imgUp = ImageView:create()
            self.imgUp:loadTexture("btn_up_12.png",UI_TEX_TYPE_PLIST)
            self.imgUp:setPosition(ccp(27,27))
            self:addChild(self.imgUp)
        end
    else
        if self.imgUp ~= nil then
            self.imgUp:removeFromParentAndCleanup(true)
        	self.imgUp = nil
        end
    end
end