
IntroTipsCfg = {
    FashionTips = "1.時裝目前僅開放英雄皮膚，神器及後續的功能敬請期待。\n" ..
                "2.時裝綁定在相應的英雄身上，一個英雄可同時獲得多件不同效果的時裝，每獲得一件時裝，英雄都能獲得全部的屬性加成。\n" ..
                "3.英雄獲得時裝後，玩家可以通過點擊\"选择此时装外形\"來選擇當前唯一顯示的時裝效果，如果不選擇顯示任何一件時裝效果，則英雄會顯示為最初的預設狀態，是否顯示時裝外形不影響屬性加成。\n" ..
                "4.英雄獲得時裝後，同時開啟該時裝部位的強化、附魔、鑒定、寶石功能，玩家可在鐵匠鋪進行相應的提升操作。\n" ..
                "5.英雄時裝的升階功能正在開發中，敬請期待。",

    StandTips = "1、將未上陣的英雄用於助陣，可提高所有上陣英雄的屬性。\n" ..
                "2、升級侍寵精靈的\"助阵术\"技能，可開啟助陣系統。\n"..
                "3、助陣術等級越高，可助陣英雄數及附加屬性值越多。\n"..
                "4、同一個英雄不能同時處於上陣和助陣狀態。",

    PowerTips = "1、任何上陣英雄身上的裝備都能強化。\n"..
                "2、裝備強化能為裝備附加額外屬性。\n"..
                "3、當英雄更換裝備時，新裝備會繼承強化等級。\n"..
                "4、更換上陣英雄時，裝備和相應的強化屬性都將轉移到新上陣英雄身上。\n"..
                "5、英雄的時裝可強化，但更換上陣英雄時，時裝和時裝的強化屬性僅保留在對應的英雄身上。\n"..
                "6、\"单件满级\"可將本件裝備強化至當前最高級。\n"..
                "7、\"批量强化\"可強化全部上陣英雄身上的裝備和時裝。\n"..
                "8、強化等級上限為戰隊等級。",

    IdentifyTips = "1、紫色及以上品質的裝備能夠通過消耗鑽石鑒定屬性。\n"..
                "2、裝備鑒定可以為裝備附加額外屬性。\n"..
                "3、鑒定屬性由裝備本身決定，裝備等級決定裝備鑒定屬性的最高星級，裝備的幸運值決定了裝備鑒定的最低星級。\n"..
                "4、當英雄更換裝備時，新裝備不會繼承鑒定屬性。\n"..
                "5、每件紫裝只能鑒定5次，首次鑒定免費。\n"..
                "6、消耗裝備碎片可以重置鑒定次數。\n"..
                "7、時裝沒有等級之分，其鑒定屬性的最高星級和最低星級同時都由幸運值決定。",

    EnchatTips = "1、任何上陣英雄身上的裝備都能附魔。\n"..
                "2、附魔可以按百分比提高裝備屬性。\n"..
                "3、當英雄更換裝備時，新裝備繼承附魔等級。\n"..
                "4、英雄的時裝可附魔，但更換上陣英雄時，時裝和時裝的附魔加成僅保留在對應的英雄身上。\n"..
                "5、消耗冗餘裝備和各級能量書可為裝備提供附魔能量。\n"..
                "6、附魔等級上限受戰隊等級影響。\n"..
                "7、當裝備附魔星數達到3星、6星、9星、12星時，裝備將附魔將突破至一個新的境界，出現新的特效。",

    GemTips = "1、任何上陣英雄身上的裝備都能鑲嵌寶石。\n"..
                "2、寶石可為裝備提供額外屬性。\n"..
                "3、當英雄更換裝備時，新裝備繼承寶石。\n"..
                "4、可在鑲嵌寶石介面，點擊寶石右下角\"上升箭头\"圖示，為寶石升級；點擊寶石右上角\"横杆\"圖示，拆卸寶石。\n"..
                "5、寶石升級消耗一定數量的同類寶石。\n"..
                "6、同一件裝備只能同時鑲嵌一顆相同顏色的寶石。\n"..
                "7、英雄的時裝可鑲嵌寶石，但更換上陣英雄時，時裝和時裝的寶石加成僅保留在對應的英雄身上。\n"..
                "8、可鑲嵌寶石的數量受戰隊等級影響。\n"..
                "9、同一英雄八件裝備都鑲嵌滿5級以上的寶石可以獲得寶石套效果。\n"..
                "10、6級以上的寶石套有珍惜屬性獎勵。",
                
    UpgradeTips = "1、等級在40級及以上，且紫色品質的裝備，能夠通過消耗裝備碎片和金幣進行升級。\n"..
                "2、升級可大幅提高裝備屬性。",
}


------------------------------------------------------------------
--通用点击  提示 
IntroTips = class("IntroTips",WindowBase)
IntroTips.__index = IntroTips
IntroTips._widget     = nil
IntroTips.is_dispose = true

local __instance = nil

function IntroTips:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
end

function IntroTips:create()
    local ret = IntroTips.new()
    __instance = ret
    return ret   
end

function IntroTips:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/common/Alert.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.img9bg = tolua.cast(self._widget:getChildByName("img_bgaleart"),"ImageView")
    self.img9bg:setPosition(ccp(480,320))

    self.labTxt = tolua.cast(self.img9bg:getChildByName("lab_title"),"Label")
    self.labTxt:setColor(ccc3(251,241,160))

    self.img9bg:setTouchEnabled(true)

    self._widget:setTouchEnabled(true)
    self._widget:setSize(CCSize(960,640))
    self._widget:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)
end

function IntroTips:open()

    local txt = self.params["txt"]
    local widthChar = self.params["widthChar"]

    local tbl = Utils.split(txt,"\n")
    local ret = ""
    for _,v in ipairs(tbl) do
        ret = ret .. Helper.insertnl(v,widthChar or 10) .. "\n"
    end

    self.labTxt:setText(ret)
    self.img9bg:setSize(CCSizeMake( self.labTxt:getSize().width + 50, self.labTxt:getSize().height + 20 ))
end
