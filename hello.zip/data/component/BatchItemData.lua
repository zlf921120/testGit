--批量显示物品元件的单个数据

BatchItemData = class("BatchItemData")
BatchItemData.itemData=nil 
BatchItemData.feed_num = 0

function BatchItemData:init(scal_value)
	self.scal_value = scal_value
	self.icon_bg = CCSprite:createWithSpriteFrameName("quality_bg_1.png")
	self.icon_bg:retain()
	self.icon_bg:setScale(self.scal_value)

	self.item_icon = CCSprite:createWithSpriteFrameName("item_10000.png")
	self.item_icon:retain()
	self.item_icon:setScale(self.scal_value)

	self.icon_border = CCSprite:createWithSpriteFrameName("quality_border_1.png")
	self.icon_border:retain()
	self.icon_border:setScale(self.scal_value)

	self.sub_icon = CCSprite:createWithSpriteFrameName("btn_up_11.png")
	self.sub_icon:setScale(self.scal_value)
	self.sub_icon:retain()
	self.sub_icon:setVisible(false)
end

function BatchItemData:changeItemData(itemData)
    self.itemData = itemData
  	self.feed_num = 0
    if self.icon_bg  then
    	self.icon_bg:initWithSpriteFrameName(string.format("quality_bg_%d.png",self.itemData.mode.quality))
    end

     if self.item_icon  then
    	self.item_icon:initWithSpriteFrameName(string.format("item_%d.png",self.itemData.mode.icon_id))
    end

     if self.icon_border  then
    	self.icon_border:initWithSpriteFrameName(string.format("quality_border_%d.png",self.itemData.mode.quality))
    end
    if self.sub_icon then
    	self.sub_icon:setVisible(false)
    end
    --碎片
    -- self:makeImgFragment( self.item_mode.item_type == ItemHelper.itemType.equip_fragment )
end

function BatchItemData:makeImgFragment(vis)
	if vis then
        if self.imgFragment == nil then
            self.imgFragment = CCSprite:createWithSpriteFrameName("equip_fragment.png")
            self.imgFragment:retain()
        end
    else
        if self.imgFragment ~= nil then
            self.imgFragment:removeFromParentAndCleanup(true)
            self.imgFragment:release()
            self.imgFragment = nil
        end
    end
end

function BatchItemData:create(scal_value)
    local icon = BatchItemData.new()
    icon:init(scal_value)
    return icon   
end

function BatchItemData:getIconBg()
	if self.icon_bg  then
		return self.icon_bg
	else
		self.icon_bg = CCSprite:createWithSpriteFrameName("quality_bg_1.png")
		self.icon_bg:retain()
		return self.icon_bg
	end
end

function BatchItemData:getItemIcon()
	if self.item_icon  then
		return self.item_icon
	else
		self.item_icon = CCSprite:createWithSpriteFrameName("item_10000.png")
		self.item_icon:retain()
		return self.item_icon
	end
end

function BatchItemData:getIconBorder()
	if self.icon_border  then
		return self.icon_border
	else
		self.icon_border = CCSprite:createWithSpriteFrameName("quality_border_1.png")
		self.icon_border:retain()
		return self.icon_border
	end
end

function BatchItemData:getSubIcon()
	if self.sub_icon  then
		return self.sub_icon
	else
		self.sub_icon = CCSprite:createWithSpriteFrameName("btn_up_11.png")
		self.sub_icon:setScale(self.scal_value)
		self.sub_icon:retain()
		return self.sub_icon
	end
end

function BatchItemData:setRealPos(real_pos)
	self.real_pos = real_pos
	self.icon_bg:setPosition(ccp(real_pos.x+42,real_pos.y-53))  
	self.item_icon:setPosition(ccp(real_pos.x+42,real_pos.y-53))
	self.icon_border:setPosition(ccp(real_pos.x+42,real_pos.y-53))

	if self.sub_icon  then
		self.sub_icon:setPosition(ccp(real_pos.x+68,real_pos.y-30))
	end

	if self.eqmFragImg then
		self.eqmFragImg:setPosition(ccp(real_pos.x-27,real_pos.y+27))
	end


	-- if self.item_mode.item_type == ItemHelper.itemType.equip_fragment then --碎片
	-- 	-- self.imgFragment
	-- end
	-- self.num_label:setPosition(real_pos)
end

function BatchItemData:getRealPos()
	return self.real_pos 
end

function BatchItemData:setNumLabel(tmp_num_label)
	self.tmp_num_label = tmp_num_label
end

function BatchItemData:getNumLabel()
	return self.tmp_num_label
end

function BatchItemData:getNumDesc()
    return string.format("%d/%d",self.feed_num,self.itemData.quantity)
end

-- 是否需要显示装备碎片图标
function BatchItemData:isShowEqmFrag()
	return self.itemData.mode.item_type == ItemHelper.itemType.equip_fragment
end

function BatchItemData:getEqmFragImg()
	if self.eqmFragImg  then
		return self.eqmFragImg
	else
		self.eqmFragImg = CCSprite:createWithSpriteFrameName("equip_fragment.png")
		self.eqmFragImg:retain()
		return self.eqmFragImg
	end
end

function BatchItemData:getItemLvDesc()
  return "lv."..self.itemData.mode.limit_lev
end

function BatchItemData:isShowEqmLv()
	return ItemManager:getInstance():isEqm(self.itemData.mode.item_type)
end

function BatchItemData:sendEvent()
	cclog("當前點中的物品是~~~~%s",self.itemData.mode.name)
	self:addFeedNum()
end

function BatchItemData:changeContent(change_type)
	if change_type == 1 then

		if self.itemData.quantity == self.feed_num then
			return
		end

		self.feed_num = self.feed_num + 1
		if self.sub_icon then
			self.sub_icon:setVisible(true)
		end
		
		-- self.quantity_label:setText(string.format("%d/%d",self.feed_num,self.item.quantity))
	elseif change_type == 2 then
		if self.feed_num == 1 or self.feed_num == 0 then
			self.feed_num = 0
			if self.sub_icon then
				self.sub_icon:setVisible(false)
			end
		else
			self.feed_num = self.feed_num-1
		end
		-- self.quantity_label:setText(string.format("%d/%d",self.feed_num,self.item.quantity))
	end
	if self.num_label then
		self.num_label:setString(self:getNumDesc()) 
	end
	return 1
end

function BatchItemData:subFeedNum() 
	local params = {}
	params.view_item = self
	params.change_type = 2
	Notifier.dispatchCmd(CmdName.EqmEnchantEnergy,params)

	
	-- local energy_num = ItemManager:getInstance():getEnchantEnergy(self.item.id)
	--Notifier.dispatchCmd(CmdName.EqmEnchantEnergy,params)
end

function BatchItemData:addFeedNum() 
	if self.itemData.quantity == self.feed_num then
		return
	end

	local energy_num = ItemManager:getInstance():getEnchantEnergy(self.itemData.id)
	-- Notifier.dispatchCmd(CmdName.EqmEnchantEnergy,energy_num)
	local params = {}
	params.view_item = self
	params.change_type = 1
	Notifier.dispatchCmd(CmdName.EqmEnchantEnergy,params)
end

function BatchItemData:getItemId()
	return self.itemData.id
end

function BatchItemData:setCurNumLabel(num_label)
	self.num_label = num_label
end

function BatchItemData:isSubIconShow()
	if self.sub_icon then
		return self.sub_icon:isVisible()
	end
	return false
end

--是否提供了附魔能量
function BatchItemData:isFeed()
	return self.feed_num>0 and self.icon_bg:getParent()
end

function BatchItemData:getFeedNum()
	return self.feed_num
end

function BatchItemData:setFeedNum()
	-- self.feed_num = feed_value
	local add_num = self:changeContent(1)
	if add_num~=nil then
		return add_num
	else
		return 0
	end
end

function BatchItemData:getItemData()
	return self.itemData
end