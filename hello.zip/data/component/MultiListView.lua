--
-- Author: thisgf
-- Date: 2014-01-15 17:49:38
-- 多行列列表容器

MultiListView = class("MultiListView")

--同步加载(默认)
MultiListView.SYNC_LOAD = 0
--异步加载
MultiListView.ASYNC_LOAD = 1


MultiListView._numRCChild = nil

MultiListView._itemSize = nil
MultiListView._barSize = nil
MultiListView._barChildStartX = nil
MultiListView._barChildDist = 0

MultiListView._barList = nil

MultiListView._itemInitX = 0
MultiListView._itemInitY = 0

MultiListView._listView = nil

--加载方式
MultiListView._loadType = 0
--加载间隔
MultiListView._loadInterval = 1
--每次加载数量
MultiListView._loadNumEvery = 0

MultiListView._loadIndex = 0

MultiListView._waitItemList = nil

MultiListView._onFillFunc = nil


local RCBar

function MultiListView:ctor()

    self._barList = {}

    self._onFillFunc = function()
        local i = 1
        local item
        while i < self._loadNumEvery do
            item = self._waitItemList[self._loadIndex]
            if not item then
                TimerManager.removeTimer(self._onFillFunc)
                break
            end
            self:addItem(item)
            i = i + 1
            table.remove(self._waitItemList, 1)
        end
    end

end


--[[
    初始化原列表容器
]]
function MultiListView:initRawListView(value)

    self._listView = value

    self:_initBarSize()
end

--[[
    设置子项尺寸
]]
function MultiListView:setItemSize(size)

    self._itemSize = size

    self:_initBarSize()

end

function MultiListView:_initBarSize()

    if not self._itemSize or not self._listView then
        return
    end

    local listSize = self._listView:getSize()

    self._barSize = CCSizeMake(listSize.width, self._itemSize.height)

    self:_initBarChildDist()

end

--[[
    设置行或列的子数量
]]
function MultiListView:setRCChildNum(value)

    self._numRCChild = value

    self:_initBarChildDist()

end

function MultiListView:_initBarChildDist()

    if not self._barSize or not self._numRCChild then
        return
    end

    --假设child的锚点是(0.5, 0.5)
    local remainX = (self._barSize.width - self._numRCChild * self._itemSize.width) / (self._numRCChild + 1)
    self._barChildDist = remainX + self._itemSize.width
    self._barChildStartX = remainX + self._itemSize.width * 0.5

end

function MultiListView:setMargin(value)

    self._listView:setItemsMargin(value)
end

function MultiListView:setItemInitPos(x, y)
    self._itemInitX = x
    self._itemInitY = y
end

--[[
    设置加载相关参数
]]
function MultiListView:setLoadParam(loadType, interval, num)
    
    interval = interval or 1
    num = num or 2

    self._loadType = loadType
    self._loadInterval = interval
    self._loadNumEvery = num
end

function MultiListView:addItem(item)

    local bar = self._barList[#self._barList]
    if bar == nil or bar:isFull() == true then
        bar = RCBar:create()
        bar:setSize(self._barSize)
        bar:setInitParam(
            self._numRCChild, 
            self._barChildStartX + self._itemInitX,
            self._itemInitY, 
            self._barChildDist
        )
        self._listView:pushBackCustomItem(bar)
        table.insert(self._barList, bar)
    end

    bar:addItem(item)

end

--[[
    添加项列表(可以配合异步加载)
]]
function MultiListView:addItems(list)

    if not self._waitItemList then
        self._waitItemList = list
    else
        for k, v in pairs(list) do
            table.insert(self._waitItemList, v)
        end
    end

    for k, v in pairs(self._waitItemList) do
        self:addItem(v)
    end
    self._waitItemList = nil

    -- if self._loadType == MultiListView.SYNC_LOAD then
    --     for k, v in pairs(self._waitItemList) do
    --         self:addItem(v)
    --     end
    -- else
    --     TimerManager.addFrame(self._loadInterval, self._onFillFunc, true)
    -- end

end

function MultiListView:removeItem(item)

    for i, v in ipairs(self._barList) do

        if v:removeItem(item) then
            break
        end
    end

    if self._waitItemList then
        for i, v in ipairs(self._waitItemList) do
            if v == item then
                table.remove(self._waitItemList, i)
                break
            end
        end
    end

end

function MultiListView:refreshView()

    self._listView:refreshView()
end

function MultiListView:getAllItem()

    local itemList = {}
    for i, v in ipairs(self._barList) do

        for k, v1 in ipairs(v:getItemList()) do
            table.insert(itemList, v1)
        end
    end

    return itemList
    
end

function MultiListView:removeAllChildren()

    for i, v in ipairs(self._barList) do
        v:clearItem()
    end 

    self._barList = {}
    self._listView:removeAllItems()

    self._waitItemList = nil

end

function MultiListView:getListView()

    return self._listView
end

function MultiListView:create()

    local mlv = MultiListView.new()

    return mlv
end

function MultiListView:dispose()

end


RCBar = class("RCBar", DisplayUtil.newLayout)

RCBar._maxChild = 0
RCBar._childStartX = 0
RCBar._childStartY = 0
RCBar._childDist = 0

RCBar._isFull = false

RCBar._itemList = nil

function RCBar:ctor()

    self:setAnchorPoint(ccp(0, 0))
    self._itemList = {}
    -- self:setBackGroundColorType(LAYOUT_COLOR_SOLID)
    -- self:setBackGroundColor(ccc3(128, 128, 0))
end

--[[
    设置初始化参数
]]
function RCBar:setInitParam(maxChild, childStartX, childStartY, childDist)

    self._maxChild = maxChild
    self._childStartX = childStartX
    self._childStartY = childStartY
    self._childDist = childDist

end

function RCBar:addItem(item)

    if self._isFull then
        return
    end

    local index = #self._itemList

    item:setPosition(ccp(
        self._childStartX + index * self._childDist, 
        self._childStartY
    ))
    table.insert(self._itemList, item)
    self:addChild(item)
    index = index + 1

    if index >= self._maxChild then
        self._isFull = true
    end

end

function RCBar:removeItem(item)

    local ri = nil

    for i, v in ipairs(self._itemList) do

        if v == item then

            ri = v
            table.remove(self._itemList, i)
            break
        end
    end

    if ri == nil then
        return false
    end

    for i, v in ipairs(self._itemList) do

        v:setPosition((i - 1) * self._childDist, 0)
    end

    self._isFull = false

    return true

end

function RCBar:removeItemWithIndex(index)

    if index < 1 or index > #self._itemList then
        return false
    end

    return self:removeItem(self._itemList[index])

end

function RCBar:clearItem()

    self:removeAllChildrenWithCleanup(true)

end

function RCBar:getItemList()

    return self._itemList
end

function RCBar:isFull()

    return self._isFull
end

function RCBar:create()

    local bar = RCBar.new()

    return bar
end


