--
-- Author: lvgansheng
-- Date: 2014-08-09 11:08:16
-- 技能图标

SkillIcon = class("SkillIcon", function() return Widget:create() end)

SkillIcon.img = nil
SkillIcon.hero_info = nil

SkillIcon.id = 0

local icon_width = 78
local icon_height = 78

function SkillIcon:init()

    --判断是否已经加载过头像资源，没有则开始加载
    HeroManager:getInstance():loadSkillIconPlist()

	--图标背景框
	local iconBg = ImageView:create()
	iconBg:loadTexture("normal_bg.png",UI_TEX_TYPE_PLIST)
	self:addChild(iconBg)	
	
    self.icon_img = ImageView:create()
    self:addChild(self.icon_img)

    local icon_border = ImageView:create()
    icon_border:loadTexture("normal_border.png",UI_TEX_TYPE_PLIST)
	self:addChild(icon_border)	
end

function SkillIcon:create()
	local icon = SkillIcon.new()
	icon:init()
	return icon
end

function SkillIcon:setSkillId(id)
	self.id = id
	local res_name = string.format("skill_%d.png",id)
	self.icon_img:loadTexture(res_name,UI_TEX_TYPE_PLIST)
end

function SkillIcon:setSkillLev(lev)
	self.lev = lev
end

--设置图标的点击事件
function SkillIcon:setClickEvent(click_event)
    self.icon_img:setTouchEnabled(true)
    self.icon_img:addTouchEventListener(click_event)
end

function SkillIcon:isOpen(is_open)
	if is_open then
		self.icon_img:setColor(ccc3(255, 255, 255))
	else
		self.icon_img:setColor(ccc3(80, 80, 30))
	end
end