--
-- Author: thisgf
-- Date: 2014-06-24 20:09:47
-- 单项选择组管理

RadioGroup = class("RaidoGroup")

RadioGroup._radioList = nil
RadioGroup._internalTouchFunc = nil
RadioGroup._touchEventListener = nil
RadioGroup._changeEventListener = nil
RadioGroup._selectedRadio = nil
RadioGroup._selectedIndex = 0

function RadioGroup:ctor()

	self._radioList = {}

	self._internalTouchFunc = function(sender, event)

		if event == 2 then
			self:setFocused(sender:getName())
		end

	    if self._touchEventListener then
	    	self._touchEventListener(sender, event)
	    end

	end

end

function RadioGroup:addRadio(...)

	local param = {...}

	if #param <= 0 then
		return
	end


	local has = false

	for i = 1, #param do

		has = false

		for _,v in ipairs(self._radioList) do

			if param[i]:getName() == v:getName() then

				has = true

				break
			end
		end

		if has == false then

			self._radioList[#self._radioList + 1] = param[i]

			param[i]:addTouchEventListener(self._internalTouchFunc)

		end

	end

end

function RadioGroup:removeRadio(...)

	local param = {...}

	if #param <= 0 then
		return
	end

	for i = 1, #param do

		for i,v in ipairs(self._radioList) do
			
			if param[i]:getName() == v:getName() then

				table.remove(self._radioList, i)

				v:addTouchEventListener(nil)

				break
			end

		end
	end

end

function RadioGroup:setRadioEnabled(index, value)

	local node = self._radioList[index]

	if not node then
		return
	end

	if value then
		if node == self._selectedRadio then
			return
		end
	end

	node:setTouchEnabled(value)

end

function RadioGroup:setEnabled(value)
	for k,v in pairs(self._radioList) do
		if v then
			v:setTouchEnabled(value)
		end
	end
end

--[[
    设置焦点项
]]
function RadioGroup:setFocused(nodeName)

	local isChange = false

	if self._selectedRadio ~= nil then

		if self._selectedRadio:getName() == nodeName then
			return isChange
		else
			self._selectedRadio:setTouchEnabled(true)
			self._selectedRadio:setFocused(false)
			self._selectedRadio = nil

			self._selectedIndex = 0

			isChange = true

		end
	end

	for i,v in ipairs(self._radioList) do

		if v:getName() == nodeName then

			self._selectedRadio = v
			self._selectedRadio:setFocused(true)
			self._selectedRadio:setTouchEnabled(false)

			isChange = true

			self._selectedIndex = i

			break
		end

	end

	if isChange then

		if self._changeEventListener ~= nil then
			self._changeEventListener()
		end
	end

	return isChange

end

--[[
    通过索引设置焦点
    @param index 索引
]]
function RadioGroup:setFocusedWithIndex(index)

	local node = self._radioList[index]

	if not node then
		return
	end

	return self:setFocused(node:getName())

end

--[[
    添加选项选择变化函数
    @value 函数 ep: func()
]]
function RadioGroup:addChangeEventListener(value)

	self._changeEventListener = value

end

function RadioGroup:addTouchEventListener(value)

	self._touchEventListener = value

end

--[[
    获取当前选择的项
]]
function RadioGroup:getSelectedRadio()
	return self._selectedRadio
end

--[[
    获取当前选项的索引
]]
function RadioGroup:getSelectedIndex()
	return self._selectedIndex
end

--[[
    通过索引获取单项
]]
function RadioGroup:getRadioWithIndex(index)
	return self._radioList[index]
end

function RadioGroup:dispose()
	
	self._changeEventListener = nil
	self._touchEventListener = nil
	self._radioList = nil

end

function RadioGroup:create()

	local group = RadioGroup.new()

	return group

end
