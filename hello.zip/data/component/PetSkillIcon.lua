-----------------------------------------------------------------------
--侍宠技能 图标
PetSkillIcon = class("PetSkillIcon", function() return Widget:create() end)
PetSkillIcon.img = nil
PetSkillIcon.id = 0
PetSkillIcon.icon_img = nil
PetSkillIcon.lev = 0

function PetSkillIcon:init()

	--判断是否已经加载过头像资源，没有则开始加载
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/team/team_skill_icon.plist")

	--图标背景框
	self.icon_bg = ImageView:create()
	self.icon_bg:loadTexture("normal_bg.png",UI_TEX_TYPE_PLIST)
	self:addChild(self.icon_bg)	    

	self.icon_img = ImageView:create()
    self:addChild(self.icon_img)

    self.icon_mask = ImageView:create()
    self.icon_mask:loadTexture("bg_17.png",UI_TEX_TYPE_PLIST)
    self.icon_mask:setPosition(ccp(0,-30))
    self.icon_mask:setScaleX(1.10)
    self.icon_mask:setScaleY(0.70)
    self:addChild(self.icon_mask)

	local icon_border = ImageView:create()
    icon_border:loadTexture("normal_border.png",UI_TEX_TYPE_PLIST)
	self:addChild(icon_border)	
end

function PetSkillIcon:create()
	local icon = PetSkillIcon.new()
	icon:init()
	return icon
end

function PetSkillIcon:setId(id)
	local res_name = string.format("team_skill_icon_%d.png",id)
	self.icon_img:setTag(id) --标记id

	self.icon_img:loadTexture(res_name,UI_TEX_TYPE_PLIST)
end

function PetSkillIcon:setLev(lev)
	if self.labLev == nil then
		self.labLev = Label:create()
		self.labLev:setAnchorPoint(ccp(0,0.5))
	    self.labLev:setPosition(ccp(-30,-30))
	    self.labLev:setFontSize(22)
	    self.labLev:setColor(ItemHelper.colors.yellow)
	    self.labLev:setTag(2015)
		self:addChild(self.labLev)
	end
	if lev <= 0 then
		self.labLev:setText("未學習")
	else
		self.labLev:setText(string.format("Lv.%d",lev))
	end
end


function PetSkillIcon:showAnim()

	local success_animate_path = "ui/hero/hero_skill/skill_upgrade/jinengshengji.ExportJson"
	if self.success_animation == nil then
	    self.success_animation = AnimateManager:getInstance():getArmature(success_animate_path,"jinengshengji") 
    end
    self.success_animation:getAnimation():setMovementEventCallFunc( function( armature, movementType, movementID )
        if movementType == AnimationMovementType.COMPLETE then
            self.success_animation:getAnimation():stop()
            self.success_animation:getAnimation():setMovementEventCallFunc(function() end)
            self.success_animation:removeFromParentAndCleanup(true)
            self.success_animation = nil

            AnimateManager:getInstance():clear(success_animate_path)
        end
    end )

    self.success_animation:removeFromParentAndCleanup(true)
   	self:addNode(self.success_animation)
    self.success_animation:getAnimation():playWithIndex(0,-1,-1,0)
end

function PetSkillIcon:showLearnAnim()
	local learn_animate_path = "ui/effects_ui/jinglingjineng/jinglingjineng.ExportJson"
	self:hideLearnAnim()

	self.learn_animation = AnimateManager:getInstance():getArmature(learn_animate_path,"jinglingjineng") 
   	self:addNode(self.learn_animation)
    self.learn_animation:getAnimation():play("Animation1",-1,-1,1)
end

function PetSkillIcon:hideLearnAnim()
	if self.learn_animation then
        self:removeNode(self.learn_animation)
        self.learn_animation = nil
    end
end

--设置图标的点击事件
function PetSkillIcon:setClickEvent(click_event)
    self.icon_img:setTouchEnabled(true)
    self.icon_img:addTouchEventListener(click_event)
end