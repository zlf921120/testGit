--
-- Author: thisgf
-- Date: 2014-07-02 19:16:39
-- 界面抽象类

require("WindowBase")

AbstView = class("AbstView", function() return WindowBase:create() end)

--是否打开中
AbstView._isOpen = false

--打开参数
AbstView.open_param = nil

AbstView._widgetGroup = nil
AbstView._base = nil

AbstView._widgetDict = nil

AbstView._currentWidget = nil
AbstView._currentPath = nil

function AbstView:ctor()

	self:_initData()
	self:_initUI()

end

function AbstView:_initData()
end

function AbstView:_initUI()
end

function AbstView:_initWidget(path)

	self:_initLayer()

	local widget = GUIReader:shareReader():widgetFromJsonFile(path)
	self._widgetGroup:addWidget(widget)

end

function AbstView:_initLayer()
	if self._widgetGroup then
		return
	end

	self._widgetGroup = TouchGroup:create()
	self.uiLayer = self._widgetGroup
	self:addChild(self._widgetGroup)
end

function AbstView:_updateWidget(path, isRetain)

	if not self._widgetDict then
		self._widgetDict = {}
	end

	if not isRetain then
		isRetain = false
	end

	if self._currentPath == path then
		return
	end

	self._currentPath = path

	self:_initLayer()

	if self._currentWidget then
		self._widgetGroup:removeWidget(self._currentWidget)
	end

	self._currentWidget = self._widgetDict[path]
	if not self._currentWidget then
		self._currentWidget = GUIReader:shareReader():widgetFromJsonFile(path)
		if isRetain then
			self._currentWidget:retain()
			self._widgetDict[path] = self._currentWidget
		end
	end

	self._widgetGroup:addWidget(self._currentWidget)

end

function AbstView:_getWidget(wName, wType)
	return tolua.cast(self._widgetGroup:getWidgetByName(wName), wType)
end

function AbstView:enter()
end

function AbstView:setParam(params)
	self.params = params
end

function AbstView:closeBySelf()
	WindowCtrl:getInstance():close(self.name)
end

function AbstView:dispose()

	if self._widgetDict then
		for path, widget in pairs(self._widgetDict) do
			widget:release()
			widget:removeFromParentAndCleanup(true)
		end
		
		self._widgetDict = nil
	end

end

function AbstView:create()
	
	local abstView = AbstView.new()
	-- abstView:_init(abstView)

	return abstView
end
