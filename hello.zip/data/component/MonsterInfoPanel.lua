--副本怪物 描述面板
MonsterInfoPanel = class("MonsterInfoPanel",function()
     return DisplayUtil.newFitLayout()
end)
MonsterInfoPanel.__index = MonsterInfoPanel
MonsterInfoPanel._widget    = nil
MonsterInfoPanel.uiLayer    = nil

local __instance = nil

function MonsterInfoPanel:getInstance()
    if not __instance then
        __instance = MonsterInfoPanel.new()
        __instance:init()
        __instance:retain()
    end
    return __instance
end

function MonsterInfoPanel:destoryInstance()
    self:release()
    __instance = nil
end

-- local function event_img_shadow(pSender,eventType)
-- 	if eventType == ComConstTab.TouchEventType.ended then
-- 		__instance:removeFromParentAndCleanup(true)
-- 	end
-- end

local mosterIcon = nil

function MonsterInfoPanel:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("common/MonsterInfoPanel.ExportJson")
    self:addChild(self._widget)

    self.panelContent = self._widget:getChildByName("panel_content")

    require "MonsterIcon"
    mosterIcon = MonsterIcon:create()
    self.panelContent:addChild(mosterIcon,3)

	-- local imgShadow = tolua.cast(self._widget:getChildByName("img_shadow"),"ImageView")
	-- imgShadow:addTouchEventListener(event_img_shadow)
end

function MonsterInfoPanel:setMonsterId(id)

    local monsterVo = MonsterManager:getInstance():getBaseInfo(id)

    local p_icon = self.panelContent:getChildByName("p_icon")
    mosterIcon:setMonsterId(id)
    mosterIcon:setScale(0.8)
    mosterIcon:setPosition(ccp(p_icon:getPosition()))

	local labDesc = tolua.cast(self.panelContent:getChildByName("lab_desc"),"Label")
	labDesc:setText(monsterVo.desc)
    local labName = tolua.cast(self.panelContent:getChildByName("lab_name"),"Label")
    labName:setText(monsterVo.name)
    local labLev = tolua.cast(self.panelContent:getChildByName("lab_level"),"Label")
    labLev:setText(monsterVo.lev)
end

function MonsterInfoPanel:setPosition(pos)
    self.panelContent:setPosition(pos)
end

function MonsterInfoPanel:show(id,pos)

    local layer = GameLayerMgr:getInstance():getMsgLayer()
    local child = layer:getChildByTag(1105)
    if child ~= nil then
        layer:removeChildByTag(1105,false)
    end

    local panel = MonsterInfoPanel:getInstance()
    panel:setMonsterId(id)
    panel:setTag(1105)
    if pos ~= nil then
        panel:setPosition(pos)
    end
    layer:addChild(panel)
end

function MonsterInfoPanel:hide()

    local layer = GameLayerMgr:getInstance():getMsgLayer()
    local child = layer:getChildByTag(1105)
    if child ~= nil then
        layer:removeChildByTag(1105,false)
    end

    MonsterInfoPanel:getInstance():setPosition(ccp(197,211))
end