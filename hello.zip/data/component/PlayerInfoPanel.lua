-- 通用 玩家信息弹窗

require("RoleId")

PlayerInfoPanel = class("PlayerInfoPanel",WindowBase)
PlayerInfoPanel.__index = PlayerInfoPanel
PlayerInfoPanel._widget     = nil
PlayerInfoPanel.uiLayer    = nil
PlayerInfoPanel.heroIconList = nil

PlayerInfoPanel.head_icon = nil

local __instance = nil

function PlayerInfoPanel:create()
    local ret = PlayerInfoPanel.new()
    __instance = ret
    return ret   
end
--------------------响应事件-----------------------------------
local function event_btn_close(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        WindowCtrl:getInstance():close(CmdName.Comm_PlayerInfo)
    end
end 
----------------------初始化--------------------------------------

function PlayerInfoPanel:init()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("common/PlayerInfo.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self._widget:addTouchEventListener(event_btn_close)

    local p_icon = self._widget:getChildByName("p_icon")
    self.head_icon = HeadIcon:create()
    self.head_icon:setScale(0.9)
    self.head_icon:setPosition(ccp(p_icon:getPosition()))
    self._widget:addChild(self.head_icon)

    require("PetHeadIcon")
    self.pet_head_icon = PetHeadIcon:create()
    self.pet_head_icon:setPosition(ccp(self.head_icon:getPositionX()+410,self.head_icon:getPositionY()-109))
    self.pet_head_icon:setScale(0.8)
    self._widget:addChild(self.pet_head_icon)

    self.black_list_btn =  tolua.cast(self.uiLayer:getWidgetByName("black_list_btn"), "Button")
    self.black_list_btn:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then 
            local isFriend = FriendMgr:getInstance():getIsFriendView()
            if not isFriend then
                local role_id = RoleId:create()
                role_id:setData(self.params["vo"].playerId, self.params["vo"].channelId, self.params["vo"].zoneId)
                SysSettingMgr:sendBlackListReq(2, role_id, self.params["vo"].name, 
                                            self.params["vo"].level, self.params["vo"].faceId)
            elseif self.params["vo"].isFriend ~= nil and self.params["vo"].isFriend then
                print("删除好友")
                self:showDelTips()
            end
            
        end
    end)
    require "HeroIcon"
    self.heroIconList = {}
    self.heroInfoList = {}
    local heroIconPos = ccp(self._widget:getChildByName("p_icon2"):getPosition())
    for i=1,6 do
        print("helper hero")
        local icon = HeroIcon:create()
        icon:setScale(0.5)
        icon:setPosition(ccp( heroIconPos.x + (i-1) * 80,heroIconPos.y ))
        self._widget:addChild(icon)
        table.insert(self.heroIconList,icon)

        table.insert(self.heroInfoList,HeroInfo.new())
    end
end

function PlayerInfoPanel:open()

    local playerVo = self.params["vo"]
    if playerVo == nil then return end

    local open_from = self.params["open_from"]

    local isNotCurPlayer = playerVo.id ~= CharacterDataProxy:getInstance():getAcctKeyId()

    print(" isNotCurPlayer ",playerVo.id,CharacterDataProxy:getInstance():getAcctKeyId())
    require("FriendMgr")
    local isFriend = FriendMgr:getInstance():getIsFriendView()
    if open_from == true and isNotCurPlayer then
        self.black_list_btn:setVisible(true)
        self.black_list_btn:setTitleText("黑名单")
        self.black_list_btn:setTouchEnabled(true)
    else
        self.black_list_btn:setVisible(false)
        self.black_list_btn:setTouchEnabled(false)
    end

    if isFriend then
        Notifier.dispatchCmd(CmdName.Friend_Check_Event, 2551)
        if playerVo.isFriend == false then
            self.black_list_btn:setVisible(false)
            self.black_list_btn:setTouchEnabled(false)
        else
            self.delInfo = playerVo.id
            self.black_list_btn:setVisible(true)
            self.black_list_btn:setTouchEnabled(true)
            self.black_list_btn:setTitleText("删除好友")
        end
    end

    -- local p_icon = self._widget:getChildByName("p_icon")
    -- local icon = HeadIcon:create()
    -- icon:setScale(0.9)
    if playerVo.isGm == 1 then --GM头像
        self.head_icon:setGmFace()
    else
        self.head_icon:setFaceId(playerVo.faceId,playerVo.sex)
    end
    -- icon:setPosition(ccp(p_icon:getPosition()))
    -- self._widget:addChild(icon)

    self.uiLayer:setTouchPriority(-2555)

	local labName = tolua.cast(self.uiLayer:getWidgetByName("lab_name"),"Label")
    labName:setText(playerVo.name)

    local labLevel = tolua.cast(self.uiLayer:getWidgetByName("lab_level"),"Label")
    labLevel:setText(playerVo.level)

    local labGuild = tolua.cast(self.uiLayer:getWidgetByName("lab_organiz"),"Label")
    if playerVo.guild == "" then
        labGuild:setText("暫無公會")
    else
        labGuild:setText(playerVo.guild)
    end

    if not isNotCurPlayer then
        local heroListMap = TeamManager:getInstance():getBattleData(TeamType.Normal):getHeroList()
        playerVo.heroList = {} 
        for k,v in pairs(heroListMap) do
            table.insert(playerVo.heroList,v.heroId)
        end
    end

    local labFight = tolua.cast(self.uiLayer:getWidgetByName("lab_fight"),"Label")
    labFight:setText(playerVo.fightValue)

    for i=1,6 do
        local icon = self.heroIconList[i]
        if playerVo.heroList and playerVo.heroList[i] ~= nil then
            if isNotCurPlayer then
                print("set other hero info")
                self.heroInfoList[i]:setOtherHeroInfo(playerVo.heroList[i].hero_id ,1,playerVo.heroList[i].stars)
                icon:setOtherHeroInfo(self.heroInfoList[i], playerVo.sex)
            else
                icon:setHeroId( playerVo.heroList[i] )
            end
            icon:setVisible(true)
        else
            icon:setVisible(false)
        end
    end

    -- 设置侍从精灵头像
    -- self.pet_head_icon:setPetStar(4)
    self.pet_head_icon:setPetStar(playerVo.pet_star)
end

function PlayerInfoPanel:close()
    local isFriend = FriendMgr:getInstance():getIsFriendView()
    if isFriend then
        Notifier.dispatchCmd(CmdName.Friend_Check_Event, -2551)
    end
end

function PlayerInfoPanel:showDelTips()
    local tips = GUIReader:shareReader():widgetFromJsonFile("ui/common/MsgBox.ExportJson")
    self.uiLayer:addWidget(tips)
    local btn_cencel = tolua.cast(tips:getChildByName("btn_cancel"), "Button")
    btn_cencel:addTouchEventListener(function(sender, event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            self.uiLayer:removeWidget(tips)
            WindowCtrl:getInstance():close(self.name)
        end
    end)
    local btn_ok = tolua.cast(tips:getChildByName("btn_ok"), "Button")
    btn_ok:addTouchEventListener(function(sender, event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            require("FriendMgr")
            FriendMgr:getInstance():sendDelProto(self.delInfo)
            self.uiLayer:removeWidget(tips)
            WindowCtrl:getInstance():close(self.name)
        end
    end)
    local lab_msg = tolua.cast(tips:getChildByName("lab_msg"), "Label")
    lab_msg:setText("确认删除该好友吗？")

    local lab_title = tolua.cast(tips:getChildByName("lab_title"), "Label")
    lab_title:setText("删除好友")
end