--消息框 
MsgBox = class("MsgBox",function() return WindowBase:create() end)
MsgBox.__index = MsgBox
MsgBox._widget 	= nil
MsgBox.uiLayer = nil
MsgBox._txt 	= nil
MsgBox._okFunc 	= nil
MsgBox._cancelFunc = nil
MsgBox._isOkClose = true
--关闭动画
MsgBox._isCloseAnimate = true

local __instance = nil

function MsgBox:create(txt)
    local ret = MsgBox.new()
    __instance = ret
    ret._txt = txt
    return ret
end
---------------------------------------------------------------------
--添加回调
function MsgBox:setCallBack(okFunc,cancelFunc)
	if type(okFunc) == "function" then
		self._okFunc = okFunc
	end
	if type(cancelFunc) == "function" then
		self._cancelFunc = cancelFunc
	end
end

----------------响应事件-------------------------------------------------
local function event_btn_ok(sender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		if __instance._isOkClose then
			if __instance._isCloseAnimate then
				__instance:addCloseAnim()
			else
				__instance:returnFun()
			end
		end
		if __instance._okFunc ~= nil then
			__instance._okFunc()
		end
	end
end

local function event_btn_cancel(sender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		if __instance._isCloseAnimate then
			__instance:addCloseAnim()
		else
			__instance:returnFun()
		end
		if __instance._cancelFunc ~= nil then
			__instance._cancelFunc()
		end

	end
end
---------------初始化-----------------------------------------------------
function MsgBox:open()

	local txt = self.params["txt"] or ""
	local rtf = self.params["rtf"]
	local okFunc = self.params["okFunc"]
	local cancelFunc = self.params["cancelFunc"]
	local okBtnName = self.params["okBtnName"]
	local cancelBtnName = self.params["cancelBtnName"]
	local _isSingleBtn = self.params["isSingleBtn"] or 0
	local _isExchangeBtn = self.params["isExchangeBtn"] or 0
	local labAlign = self.params["labAlign"] or kCCVerticalTextAlignmentCenter
	self._isOkClose = self.params["isOkClose"]
	if self._isOkClose == nil then
		self._isOkClose = true
	end

	if self.params["isCloseAnimate"] == nil then
		self._isCloseAnimate = true
	else
		self._isCloseAnimate = self.params["isCloseAnimate"]
	end

	self._okFunc = okFunc
	self._cancelFunc = cancelFunc

	if okBtnName ~= nil then
		self.btnOk:setTitleText(okBtnName)
	end
	if cancelBtnName ~= nil then
		self.btnCancel:setTitleText(cancelBtnName)
	end

	local labTxt = tolua.cast(self.uiLayer:getWidgetByName("lab_msg"),"Label")
	labTxt:setTextVerticalAlignment(labAlign)
    labTxt:setText(txt)

	if rtf ~= nil and type(rtf) == "table" then
		local child = self._widget:getChildByTag(1657)
		if child ~= nil then 
			self._widget:removeChild(child)
		end
		local rtfObj = ChatHelper.createRtf(rtf,320,170,ccp(0,1))
		rtfObj:setTag(1657)
		rtfObj:setPosition(ccp(323,420))
		self._widget:addChild(rtfObj,2)
	end
	self:isExchangeBtn(_isExchangeBtn == 1)
	self:isSingleBtn(_isSingleBtn == 1 )
    self:addOpenAnim()
end

function MsgBox:close()
	self.btnOk:setTitleText("確定")
	self.btnCancel:setTitleText("取消")
	self._isOkClose = true

	local child = self._widget:getChildByTag(1657)
	if child ~= nil then 
		self._widget:removeChild(child)
	end
end

function MsgBox:isSingleBtn(value)
	if value then
		self.btnOk:setPositionX(480)
		self.btnCancel:setVisible(false)
		self.btnCancel:setTouchEnabled(false)
	else
		self.btnCancel:setPositionX(377)
		self.btnOk:setPositionX(584)
		self.btnCancel:setVisible(true)
		self.btnCancel:setTouchEnabled(true)
	end
end

function MsgBox:isExchangeBtn(value)
	if value then
		self.btnOk:setPositionX(377)
		self.btnCancel:setPositionX(584)
	else
		self.btnOk:setPositionX(584)
		self.btnCancel:setPositionX(377)
	end
end

function MsgBox:init()
	require "ChatHelper"

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/common/MsgBox.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
	self:addChild(self.uiLayer)

    self.btnOk = tolua.cast(self.uiLayer:getWidgetByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(event_btn_ok)

    self.btnCancel = tolua.cast(self.uiLayer:getWidgetByName("btn_cancel"),"Button")
    self.btnCancel:addTouchEventListener(event_btn_cancel)
end

----------------------------------------------------------------------
--消息框 
WarningBox = class("WarningBox",function()
	return DisplayUtil.newFitLayer()
end)
WarningBox.__index = WarningBox
WarningBox._widget 	= nil
WarningBox.uiLayer = nil
WarningBox._txt 	= nil
WarningBox._okFunc 	= nil
WarningBox._cancelFunc = nil

local __instanceWarning = nil

function WarningBox:getInstance()
    if not __instanceWarning then
        local ret = WarningBox.new()
        __instanceWarning = ret
        ret:init()
        ret:retain()
    end
    return __instanceWarning
end
----------------响应事件-------------------------------------------------
local function event_btn_ok_warning(sender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		if __instanceWarning._okFunc ~= nil then
			__instanceWarning._okFunc()
		end
		__instanceWarning:close()
		__instanceWarning:removeFromParentAndCleanup(true)
	end
end

local function event_btn_cancel_warning(sender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		if __instanceWarning._cancelFunc ~= nil then
			__instanceWarning._cancelFunc()
		end
		__instanceWarning:close()
		__instanceWarning:removeFromParentAndCleanup(true)
	end
end
----------------------------------------------------------------------------

function WarningBox:init()
	require "ChatHelper"
	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/login/MsgBox/MsgBox.json")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
	self:addChild(self.uiLayer)

    self.btnOk = tolua.cast(self.uiLayer:getWidgetByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(event_btn_ok_warning)

    self.btnCancel = tolua.cast(self.uiLayer:getWidgetByName("btn_cancel"),"Button")
    self.btnCancel:addTouchEventListener(event_btn_cancel_warning)
end

function WarningBox:isSingleBtn(value)
	if value then
		self.btnOk:setPositionX(480)
		self.btnCancel:setVisible(false)
		self.btnCancel:setTouchEnabled(false)
	else
		self.btnCancel:setPositionX(377)
		self.btnOk:setPositionX(584)
		self.btnCancel:setVisible(true)
		self.btnCancel:setTouchEnabled(true)
	end
end

function WarningBox:open(params)

	self.params = params

	local txt = self.params["txt"] or ""
	local okFunc = self.params["okFunc"]
	local rtf = self.params["rtf"]
	local cancelFunc = self.params["cancelFunc"]
	local okBtnName = self.params["okBtnName"]
	local cancelBtnName = self.params["cancelBtnName"]

	if type(okFunc) == "function" then
		self._okFunc = okFunc
	end
	if type(cancelFunc) == "function" then
		self._cancelFunc = cancelFunc
	end
	if okBtnName ~= nil then
		local btnOk = tolua.cast(self.uiLayer:getWidgetByName("btn_ok"),"Button")
		btnOk:setTitleText(okBtnName)
	end
	if cancelBtnName ~= nil then
		local btnCancel = tolua.cast(self.uiLayer:getWidgetByName("btn_cancel"),"Button")
		btnCancel:setTitleText(cancelBtnName)
	end

	local labTxt = tolua.cast(self.uiLayer:getWidgetByName("lab_msg"),"Label")
    labTxt:setText(txt)

    if rtf ~= nil and type(rtf) == "table" then
		local child = self._widget:getChildByTag(1657)
		if child ~= nil then 
			self._widget:removeChild(child)
		end
		local rtfObj = ChatHelper.createRtf(rtf,320,170,ccp(0,1))
		rtfObj:setTag(1657)
		rtfObj:setPosition(ccp(323,420))
		self._widget:addChild(rtfObj,2)
	end

end

function WarningBox:close()
	self.btnOk:setTitleText("確定")
	self.btnCancel:setTitleText("取消")
	self._isOkClose = true

	local child = self._widget:getChildByTag(1657)
	if child ~= nil then 
		self._widget:removeChild(child)
	end
end

