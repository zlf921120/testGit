--
-- Author: lvgansheng
-- Date: 2014-09-13 15:55:50
-- OtherRoleInfoView


OtherRoleInfoView = class("OtherRoleInfoView", WindowBase)
OtherRoleInfoView.hero_icons = nil
OtherRoleInfoView.role_info = nil


function OtherRoleInfoView:init()
    self.hero_icons = {} 

	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/arena/arena_enemy_info/arena_enemy_info.ExportJson")
    self.uiLayer:addWidget(self.widget)

    -- local rank_label = tolua.cast(self.uiLayer:getWidgetByName("rank_label"), "Label") 
    -- rank_label:setVisible(false)

    self.head_icon = HeadIcon:create()
    -- self.head_icon:setScale(0.8)
    self.head_icon:setPosition(ccp(190,441))
    self.widget:addChild(self.head_icon,10)

    require("PetHeadIcon")
    self.pet_head_icon = PetHeadIcon:create()
    self.pet_head_icon:setPosition(ccp(765,324))
    self.widget:addChild(self.pet_head_icon,10)

    local panel = tolua.cast(self.uiLayer:getWidgetByName("Panel_326"), "Layout")
    panel:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
    		WindowCtrl:getInstance():close(self.name)
        end
    end)

    local icon_x = 191
    local icon_y = 216
    local setp_x = 113
    local hero_icon_one = HeroIcon:create()
    hero_icon_one:setScale(0.8)
    hero_icon_one:setPosition(ccp(icon_x,icon_y))
    self.uiLayer:addWidget(hero_icon_one)

    icon_x = icon_x + setp_x
    local hero_icon_two = HeroIcon:create()
    hero_icon_two:setScale(0.8)
    hero_icon_two:setPosition(ccp(icon_x,icon_y))
    self.uiLayer:addWidget(hero_icon_two)

    icon_x = icon_x + setp_x
    local hero_icon_three = HeroIcon:create()
    hero_icon_three:setScale(0.8)
    hero_icon_three:setPosition(ccp(icon_x,icon_y))
    self.uiLayer:addWidget(hero_icon_three)

    icon_x = icon_x + setp_x
    local hero_icon_four = HeroIcon:create()
    hero_icon_four:setScale(0.8)
    hero_icon_four:setPosition(ccp(icon_x,icon_y))
    self.uiLayer:addWidget(hero_icon_four)

    icon_x = icon_x + setp_x
    local hero_icon_five = HeroIcon:create()
    hero_icon_five:setScale(0.8)
    hero_icon_five:setPosition(ccp(icon_x,icon_y))
    self.uiLayer:addWidget(hero_icon_five)

    icon_x = icon_x + setp_x
    local hero_icon_six = HeroIcon:create()
    hero_icon_six:setScale(0.8)
    hero_icon_six:setPosition(ccp(icon_x,icon_y))
    self.uiLayer:addWidget(hero_icon_six)

    self.hero_icons[1] = hero_icon_one
    self.hero_icons[2] = hero_icon_two
    self.hero_icons[3] = hero_icon_three
    self.hero_icons[4] = hero_icon_four
    self.hero_icons[5] = hero_icon_five
    self.hero_icons[6] = hero_icon_six

    self.rank_num_img = LabelAtlas:create()
    self.rank_num_img:setProperty(0000,"ui/digit/digit_4.png",24,32,"0")
    self.uiLayer:addWidget(self.rank_num_img)
    self.rank_num_img:setPosition(ccp(650,405))
end

function OtherRoleInfoView:create()
    local enemy_info_view = OtherRoleInfoView.new()
    return enemy_info_view
end

function OtherRoleInfoView:open()
    self.role_info = self.params.role_info
    self.view_type = self.params.view_type or ArenaHelper.enemyInfoView.Normal
    self.params = nil

    self:changeContent()
end

function OtherRoleInfoView:close()
    self.params = nil
    self.role_info = nil
end

--改变显示内容
function OtherRoleInfoView:changeContent()
    -- cclog("角色的性別=%s",self.role_info.sex)
    self.head_icon:setFaceId(self.role_info.face_id, self.role_info.sex)
    
    local name_label = tolua.cast(self.uiLayer:getWidgetByName("name_label"), "Label") 
    name_label:setText(self.role_info.role_name)

    local lev_label = tolua.cast(self.uiLayer:getWidgetByName("lev_label"), "Label") 
    lev_label:setText(string.format("Lv.%d",self.role_info.team_lev))

    local rank_txt_label = tolua.cast(self.uiLayer:getWidgetByName("Label_333_Copy0"), "Label") 
    if self.view_type == ArenaHelper.enemyInfoView.Combat_Record  then
        self.rank_num_img:setVisible(false)
        rank_txt_label:setVisible(false)
    else
        rank_txt_label:setVisible(true)
        self.rank_num_img:setVisible(true)
        self.rank_num_img:setStringValue(self.role_info.rank)
    end

    local win_num_label = tolua.cast(self.uiLayer:getWidgetByName("win_num_label"), "Label") 
    win_num_label:setText(self.role_info.win_num)

    local fc_label = tolua.cast(self.uiLayer:getWidgetByName("fc_label"), "Label") 
    fc_label:setText(self.role_info.fight_capacity)

    local hero_icon = nil
    local hero_info = nil
    local heros = self.role_info.battle_data
    for i=1,#self.hero_icons do
        hero_icon = self.hero_icons[i]
        hero_info = heros[i]

        if hero_info ~= nil then
            hero_icon:setVisible(true)
            hero_icon:setOtherHeroInfo(hero_info, self.role_info.sex)
        else
            hero_icon:setOtherHeroInfo(nil)
        end
    end

    -- 设置侍从精灵头像
    self.pet_head_icon:setPetStar(self.role_info.pet_star)
end