--性别选择页面
GenderScene = class("GenderScene",WindowBase)
GenderScene.__index = GenderScene
GenderScene._widget = nil
GenderScene.uiLayer = nil
GenderScene._armaturePathMap = nil
GenderScene.is_dispose = true

local __instance = nil
local _imgClickTbl = nil
local _lastClick = nil
local _isRunningAction = false

function GenderScene:create()
     local ret = GenderScene.new()
    __instance = ret
    return ret
end

function GenderScene:getInstance()
	return __instance
end

function GenderScene:dispose()
	if self._widget then
		self._widget:removeFromParentAndCleanup(true)
	end
	-- self:removeFromParentAndCleanup(true)
	self:removeNotifier()
	CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile("ui/gender/gender.plist")
	CCTextureCache:sharedTextureCache():removeTextureForKey("i18n_gender_bg.png")

end

local function event_cb_close()

	--流失率节点，选择性别成功后
	SysSettingMgr:getInstance():sendWasteageCount(6)

	__instance.btnOk:setVisible(false)
	__instance.btnOk:setTouchEnabled(false)
	WindowCtrl:getInstance():close(CmdName.GENDER_SCENE)
------------------------------------------------------------------
	--加载剧情/新手引导
    -- if Global:getStringForKey( "isFinishGuideDungeon" .. Global:getStringForKey("username") ) == nil then
        require "GuideNetTask"
        GuideEventTask:getInstance()
        Notifier.dispatchCmd(GuideEvent.InitDungeon)
        GuideLocalReader:getInstance():loadInProxy()
    -- end
    require "BattleManager"
	BattleManager:getInstance():reqBattlePlot()
end

local function event_btn_ok(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		CharacterNetTask:getInstance():requestCreateGender(_lastClick:getTag())
	end
end

local function event_click_img(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		if _isRunningAction then return end

		if _lastClick == nil then	
			_lastClick = pSender
			__instance:disableAnim()
		elseif _lastClick ~= pSender then
			_lastClick = pSender 
			__instance:ableAnim()
			__instance:disableAnim()
		else
			return
		end
		__instance.btnOk:setVisible(true)
		__instance.btnOk:setTouchEnabled(true)
	end
end

function GenderScene:ableAnim()
	_isRunningAction = true 
	for i=1,#_imgClickTbl do
		local v = _imgClickTbl[i]
		if _lastClick == v then
			local idx = 3
			local arr = CCArray:create()
			v:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
			CCCallFunc:create(function()
				idx = idx + 1
				local value = 255 * (idx / 10)
				v:setColor(ccc3(value,value,value))
				if idx == 10 then v:stopAllActions() _isRunningAction = false end
			end),
			CCDelayTime:create(0.02))))
		end
	end
end

function GenderScene:disableAnim()
	_isRunningAction = true 
	for i=1,#_imgClickTbl do
		local v = _imgClickTbl[i]
		if _lastClick ~= v then
			local idx = 10
			local arr = CCArray:create()
			v:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
			CCCallFunc:create(function()
				idx = idx - 1
				local value = 255 * (idx / 10)
				v:setColor(ccc3(value,value,value))
				if idx == 3 then v:stopAllActions() _isRunningAction = false end
			end),
			CCDelayTime:create(0.02))))
		end
	end
end

function GenderScene:init()

 	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/gender/gender.plist")
	self._widget = GUIReader:shareReader():widgetFromJsonFile("gender/GenderScene.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
	self:addChild(self.uiLayer)

	local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
 	local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()
 	self.imgBg = ImageView:create()
	self.imgBg:loadTexture("i18n_gender_bg.png",UI_TEX_TYPE_PLIST)
 	self.imgBg:setPosition(ccp(480,320))
 	self.imgBg:setScaleX(1/DisplayUtil.min_scale*globa_scalx)
 	self.imgBg:setScaleY(1/DisplayUtil.min_scale*globa_scaly)
 	self._widget:getChildByName("panel_bg"):addChild(self.imgBg)
	
	-- self._armaturePathMap = {}

	self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
	self.btnOk:setVisible(false)
	self.btnOk:setTouchEnabled(false)
	self.btnOk:addTouchEventListener(event_btn_ok)

	self.imgMale = tolua.cast(self._widget:getChildByName("img_m"),"ImageView")
	self.imgMale:addTouchEventListener(event_click_img)
	self.imgMale:setTag(1)
	self.imgFemale = tolua.cast(self._widget:getChildByName("img_f"),"ImageView")
	self.imgFemale:addTouchEventListener(event_click_img)
	self.imgFemale:setTag(0)

	_imgClickTbl = {self.imgMale,self.imgFemale}

	Notifier.regist(CharacterEvent.CB_CLOSE_GENDER,event_cb_close)

	--流失率节点，选择性别前
	SysSettingMgr:getInstance():sendWasteageCount(5)
end

function GenderScene:removeNotifier()
	Notifier.remove(CharacterEvent.CB_CLOSE_GENDER,event_cb_close)
end

function GenderScene:removeArmatureInfo()
	-- for i=1,#self._armaturePathMap do
	-- 	local path = self._armaturePathMap[i]
	-- 	CCArmatureDataManager:sharedArmatureDataManager():removeArmatureFileInfo(path)
	-- end
end