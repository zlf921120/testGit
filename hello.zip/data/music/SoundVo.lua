
SoundVo = class("SoundVo")
SoundVo.id = 0
SoundVo.src = ""
SoundVo.type = 0