
--声音数据代理
SoundDataProxy = class("SoundDataProxy")
SoundDataProxy.voSoundList = {}

local __instance = nil
local _allowInstance = false

function SoundDataProxy:ctor()
    if not _allowInstance then
		error("SoundDataProxy is a singleton class")
	end
	self:init()
end

function SoundDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = SoundDataProxy.new()
		_allowInstance = false
	end

	return __instance
end

function SoundDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function SoundDataProxy:init()
	require "SoundVo"
end

function SoundDataProxy:getSoundVoList()
	return self.voSoundList
end

function SoundDataProxy:createSoundVo()
	return SoundVo.new()
end

function SoundDataProxy:setSoundVo(vo)
	self.voSoundList[ vo.id ] = vo
end

function SoundDataProxy:getSoundVoById(id)
	return self.voSoundList[id]
end