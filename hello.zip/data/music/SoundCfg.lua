--声音配置
SoundCfg = {}
SoundCfg.Btn1 = 10001
SoundCfg.MainBgMusic = 10008
SoundCfg.Victory = 10002
SoundCfg.Dungeonbackground01 = 10004
SoundCfg.Battle01 = 10005
SoundCfg.Battle02 = 10006
SoundCfg.Battle03 = 10007

SoundType = {
	background = 1, --背景音
	effect = 2,		--效果音
}