--声音本地xls 加载器
SoundLocalReader = class("SoundLocalReader")

local __instance = nil
local _allowInstance = false
local _hasLoad = false

function SoundLocalReader:ctor()
    if not _allowInstance then
		error("SoundLocalReader is a singleton class")
	end
	self:init()
end

function SoundLocalReader:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = SoundLocalReader.new()
		_allowInstance = false
	end

	return __instance
end

function SoundLocalReader:destoryInstance()
	_allowInstance = false
	__instance = nil
end

-------------初始化---------------------------
function SoundLocalReader:init()
	require "fnt_sound_data_pb"
	require "SoundDataProxy"
	require "SoundCfg"
	require "AudioEngine"
end

--获取 本地数据并创建值对象 
function SoundLocalReader:loadInProxy()

	if _hasLoad then return end--只加载一次
	_hasLoad = true

	local dp = SoundDataProxy:getInstance()
    local pbdata = FileUtils.readConfigFile("fnt_sound_data.dat")
    
    local msg = fnt_sound_data_pb.fnt_sound_data()
    msg:ParseFromString(pbdata)

    local resUnit = msg.sound_res_rows
    for i, v in pairs(resUnit) do
       	if v.id ~= nil then
	    	local soundVo = dp:createSoundVo()
	    	soundVo.id = v.id
	    	soundVo.src = CCFileUtils:sharedFileUtils():fullPathForFilename(v.file_name .. ".mp3")
	    	soundVo.type = v.type
	       	dp:setSoundVo(soundVo)
        end
    end

    self:preloadSounds()
end

function SoundLocalReader:preloadSounds()
	local dp = SoundDataProxy:getInstance()
	local voList = dp:getSoundVoList()
	for k,v in pairs(voList) do
		if v.type == SoundType.background then
			AudioEngine.preloadMusic(v.id)
		elseif v.type == SoundType.effect then
			AudioEngine.preloadMusic(v.id)
		end
	end
end