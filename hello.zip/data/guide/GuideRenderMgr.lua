-- 引导 渲染器
GuideRenderMgr = class("GuideRenderMgr")
GuideRenderMgr.touchAreaTbl = nil

local __instance = nil
local _allowInstance = false

function GuideRenderMgr:ctor()
    if not _allowInstance then
		error("GuideRenderMgr is a singleton class")
	end
	self:init()
end

function GuideRenderMgr:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = GuideRenderMgr.new()
		_allowInstance = false
	end

	return __instance
end

function GuideRenderMgr:destoryInstance()

	_allowInstance = false
	__instance = nil
end

function GuideRenderMgr:init()
	

end

--初始化锁屏遮罩
function GuideRenderMgr:renderInitMask(container)

	local lock_panel = CCLayerColor:create()
	lock_panel:setTag(1882)
	container:addNode(lock_panel,999)
	lock_panel:setContentSize(CCSize(960,640))
	-- lock_panel:setTouchPriority(TouchPriority.right-1)
	lock_panel:setTouchPriority(0)
	lock_panel:setTouchEnabled(true)
	lock_panel:registerScriptTouchHandler(function(eventType, x, y)
		if(eventType == "began") then
			local touchArea = CCRectMake(self.touchAreaTbl.x,
										self.touchAreaTbl.y,
										self.touchAreaTbl.w,
										self.touchAreaTbl.h)

			-- print(" (touchArea:containsPoint(ccp(x,y))) ",(touchArea:containsPoint(ccp(x,y))))

			if(touchArea:containsPoint(ccp(x,y))) then
				return  false
			else
				return true
			end
		end
	end,false,1,true)
end

--范围解锁
function GuideRenderMgr:renderUnlock(container,p1,p2)
	local w = math.abs(p2.x - p1.x)
	local h = math.abs(p2.y - p1.y)

	self.touchAreaTbl = {x = p1.x,y = p1.y, w = w,h = h}
end

--全锁屏
function GuideRenderMgr:renderLock(container)
	
	self.touchAreaTbl = {x = 0,y = 0, w = 0,h = 0}
end

--全解锁
function GuideRenderMgr:renderUnlockAll(container)

	self.touchAreaTbl = {x = 0,y = 0, w = 960,h = 640}
end

-- 剧情 延时清除
local function checkLazyRemove(eventId)
	local voList = GuideDataProxy:getInstance().voLazyRemoveList
	for i=1,#voList do
		if tonumber(voList[i].triggerId) == tonumber(eventId) and voList[i].obj then
			voList[i].obj:removeFromParentAndCleanup(true)
			voList[i].obj = nil
		end
	end
end

-- 副本教程 延时清除
local function checkDungeonTutorialLazyRemove(eventId)
	local voList = GuideDataProxy:getInstance().voDungeonTutorialLazyRemoveList
	for i=1,#voList do
		if tonumber(voList[i].triggerId) == tonumber(eventId) and voList[i].obj then
			voList[i].obj:removeFromParentAndCleanup(true)
			voList[i].obj = nil
		end
	end
end

-- 主界面教程 延时清除
local function checkMainTutorialLazyRemove(eventId)
	local voList = GuideDataProxy:getInstance().voMainTutorialLazyRemoveList
	for i=1,#voList do
		if tonumber(voList[i].triggerId) == tonumber(eventId) and voList[i].obj then
			voList[i].obj:removeFromParentAndCleanup(true)
			voList[i].obj = nil
		end
	end
end

-- 主界面教程提示 延时清除
local function checkMainTipTutorialLazyRemove(eventId)
	local voList = GuideDataProxy:getInstance().voMainTutorialTipLazyRemoveList
	for i=1,#voList do
		if tonumber(voList[i].triggerId) == tonumber(eventId) and voList[i].obj then
			voList[i].obj:removeFromParentAndCleanup(true)
			voList[i].obj = nil
		end
	end
end

--强制完成事件组
function GuideRenderMgr:forceFinishEvent()
	local dp = GuideDataProxy:getInstance()
	local eventVo = dp:getMainTutorialVoById(dp.nowMainTutroialEventId)
	print(" 強制清除新手引導!!!!  ",dp.nowMainTutroialEventId)
	local function clearAll(animTbl)
		for k,v in pairs(animTbl) do --清理动画
			if v.obj then
				v.obj:stopAllActions()
				v.obj:removeFromParentAndCleanup(true)
				v.obj = nil
			end
		end
	end

	if eventVo and eventVo.animObjTbl and Utils.get_length_from_any_table(eventVo.animObjTbl) ~= 0 then
		clearAll(eventVo.animObjTbl)
	end
	if eventVo then
		dp:setGuideEventForceFinish(eventVo) --终止该组的所有步骤
	end
end

--强制完成步骤
function GuideRenderMgr:forceFinishStep()
	local dp = GuideDataProxy:getInstance()
	local eventVo = dp:getMainTutorialVoById(dp.nowMainTutroialEventId)
	print(" 強制完成新手步驟!!!!  ",dp.nowMainTutroialEventId)
	local function clearAll(animTbl)
		for k,v in pairs(animTbl) do --清理动画
			if v.obj then
				v.obj:stopAllActions()
				v.obj:removeFromParentAndCleanup(true)
				v.obj = nil
			end
		end
	end

	if eventVo and eventVo.animObjTbl and Utils.get_length_from_any_table(eventVo.animObjTbl) ~= 0 then
		Notifier.dispatchCmd(GuideEvent.Main,{GuideCondType.Trigger,eventVo.id}) --正常完成播放
		clearAll(eventVo.animObjTbl)
	end
end

-- 快速跳过 剧情
local function quickComplete(eventVo,animTbl,lockContainer,viewContainer)
	if eventVo.id < GuideDataProxy:getInstance().nowEventId then return end

	local function clearAll(animTbl)
		for k,v in pairs(animTbl) do --清理动画
			if v.isLazyDel == 0 then
				if v.obj then
					v.obj:stopAllActions()
					v.obj:removeFromParentAndCleanup(true)
					v.obj = nil
				end
			else
				table.insert(GuideDataProxy:getInstance().voLazyRemoveList,v) --缓存 延时清理
			end
		end

		checkLazyRemove(eventVo.id)
		GuideDungeon:hide(viewContainer,eventVo.endType) --清理引导

		tolua.cast(viewContainer:getChildByName("img_clickview"),"ImageView"):setTouchEnabled(false)
	end
---------------------------------------
	if eventVo.screenAct then return end
	--跳过事件
	print("跳過事件 。。",eventVo.id)
	viewContainer:stopAllActions()

	clearAll(animTbl)
	Notifier.dispatchCmd(GuideEvent.Dungeon,{GuideCondType.Trigger,eventVo.id}) --正常完成播放

	if eventVo.endType == GuideEndType.AfterToDo then --后置动画结束
		if __instance:checkPlayNewHeroAnim(eventVo) == false then
			BattleController:getInstance():showBattleResult()
		end
	elseif eventVo.endType == GuideEndType.BeforeToDo then --前置动画结束
		Notifier.dispatchCmd(GuideEvent.PerStoryComplete) 

		BattleController:getInstance():moveUI()
		GuideDataProxy:getInstance():isCanShowVipSpeepTips()
	end
end

--副本教程播放结束
local function animCompleteDungeonTutorial(eventVo,animTbl,lockContainer,viewContainer)
	local function clearAll(animTbl)
		for k,v in pairs(animTbl) do --清理动画
			if v.isLazyDel == 0 then
				if v.obj then
					v.obj:stopAllActions()
					v.obj:removeFromParentAndCleanup(true)
					v.obj = nil
				end
			else
				table.insert(GuideDataProxy:getInstance().voDungeonTutorialLazyRemoveList,v) --缓存 延时清理
			end
		end
	
		checkDungeonTutorialLazyRemove(eventVo.id)
		GuideDungeon:hideTutorial(viewContainer,eventVo.endType) --清理引导
	end
---------------------------------------
	local function endProgress()
		clearAll(animTbl)
		-- if Global:getStringForKey(string.format("guideDungeonTutrial%s%d",Global:getStringForKey("username"),eventVo.id)) == nil
		-- 	and eventVo.condTbl[1].type == "begin" then
		-- 	Global:setStringForKey(string.format("guideDungeonTutrial%s%d",Global:getStringForKey("username"),eventVo.id),"done")
		-- end
		if eventVo.condTbl[1].type == "begin" then
			eventVo.hasEndExecute = 1
			GuideNetTask:getInstance():requestRecordPlotId(eventVo.id)
		end
		Notifier.dispatchCmd(GuideEvent.Dungeon,{GuideCondType.Trigger,eventVo.id}) --正常完成播放
	end

	local imgClickLab = tolua.cast(viewContainer:getChildByName("img_clicklab"),"ImageView")
	imgClickLab:setTouchEnabled(false)

	if eventVo.islock == 2 then
		Notifier.dispatchCmd(CmdName.BATTLE_CONTROL_STONE,false) --暗掉石头
	elseif eventVo.islock == 3 then
		Notifier.dispatchCmd(CmdName.BATTLE_CONTROL_STONE,false) --暗掉石头
	elseif eventVo.islock == 1 then
		Notifier.dispatchCmd(CmdName.BATTLE_CONTROL_STONE,true) --恢复石头
	end

	local t = eventVo.endCond.type
	if t == "normal" then
		if eventVo.endType == GuideEndType.AfterToDo then
			Notifier.dispatchCmd(CmdName.BATTLE_CONTROL_STONE,true) --恢复石头
		end
		endProgress()
	elseif t == "time" then --延时
		viewContainer:runAction(CCSequence:createWithTwoActions( --todo
			CCDelayTime:create(tonumber(eventVo.endCond.params[1] / 1000)),
			CCCallFunc:create(endProgress)))
	elseif t == "line" then --连连看事件(连完必定灰掉石头)
		local tmpCheckCompleteTutorial = function()
			endProgress()
			Notifier.removeByName(GuideEvent.LineFinish) --移除连线事件
			Notifier.dispatchCmd(CmdName.BATTLE_CONTROL_STONE,false) --灰掉石头
		end
		if eventVo.islock == 1 then
    		__instance:renderUnlock(lockContainer,eventVo.p1,eventVo.p2)
	    elseif eventVo.islock == 0 then
			__instance:renderLock(lockContainer)
	    end
	    Notifier.removeByName(GuideEvent.LineFinish)
		Notifier.regist(GuideEvent.LineFinish,tmpCheckCompleteTutorial)
	elseif t == "click" then
		local imgClickTutorial = tolua.cast(viewContainer:getChildByName("img_clicktutorial"),"ImageView")
		imgClickTutorial:setTouchEnabled(true)
		imgClickTutorial:addTouchEventListener(function(pSender,eventType)
			if eventType == ComConstTab.TouchEventType.ended then
				imgClickTutorial:setTouchEnabled(false)
				if eventVo.endType == GuideEndType.AfterToDo then
					Notifier.dispatchCmd(CmdName.BATTLE_CONTROL_STONE,true) --恢复石头
				end
				endProgress()
			end
		end)
		__instance:renderUnlockAll(lockContainer)
	end
end

--主界面引导 教程
local function animCompleteMainTutorial(eventVo,animTbl,lockContainer,viewContainer)

	local function clearAll(animTbl)
		for k,v in pairs(animTbl) do --清理动画
			if v.isLazyDel == 0 then
				if v.obj then
					v.obj:stopAllActions()
					v.obj:removeFromParentAndCleanup(true)
					v.obj = nil
				end
			else
				table.insert(GuideDataProxy:getInstance().voMainTutorialLazyRemoveList,v) --缓存 延时清理
			end
		end
		WindowCtrl:getInstance():close(CmdName.Comm_Guide)
		checkMainTutorialLazyRemove(eventVo.id)
	end
---------------------------------------
	local function endProgress()
		clearAll(animTbl)
		-- if Global:getStringForKey(string.format("guideMainStart%s%d", Global:getStringForKey("username"),eventVo.id)) == nil then
		-- 	Global:setStringForKey(string.format("guideMainStart%s%d", Global:getStringForKey("username"),eventVo.id),"done")
		-- end
		if eventVo.isRecord == GuideEndType.Record then
			-- local groupVo = GuideDataProxy:getInstance():getMainGroupVoById(eventVo.groupId)
			-- GuideNetTask:getInstance():requestRecordGuideId(groupVo.beginId)
			GuideNetTask:getInstance():requestRecordGuideId(eventVo.id)
			eventVo.hasRecord = 1
		end
		Notifier.dispatchCmd(GuideEvent.Main,{GuideCondType.Trigger,eventVo.id}) --正常完成播放
	end

	local function createTmpClick(eventVo,lockContainer,viewContainer)
		if eventVo.islock == 1 then
    		__instance:renderUnlock(lockContainer,eventVo.p1,eventVo.p2)
	    elseif eventVo.islock == 0 then
			__instance:renderLock(lockContainer)
	    end

	    local midPos = MathUtil.getMiddlePos(eventVo.p1,eventVo.p2)
	    local tmpClickImg = ImageView:create()
	    tmpClickImg:setTouchEnabled(true)
	    tmpClickImg:setScale(2)
	    tmpClickImg:setVisible(false)
	    tmpClickImg:loadTexture("ui/guide/guide/guide_img_mask.png")
	    tmpClickImg:setPosition(midPos)
	    viewContainer:addChild(tmpClickImg)
	    tmpClickImg:addTouchEventListener(function(pSender,eventType)
	    	if eventType == ComConstTab.TouchEventType.ended then
	    		Notifier.dispatchCmd(GuideEvent.Force,eventVo.endCond.params[1])
	    		tmpClickImg:removeFromParentAndCleanup(true)
	   	 	end
	    end)
	end

	createTmpClick(eventVo,lockContainer,viewContainer)

	Notifier.regist(GuideEvent.StepFinish,function(key)
		if eventVo.endCond.key == key then
			endProgress()
		end
	end)

end

-- 新手引导 提示
local function animCompleteMainFlagTutorial(eventVo,animTbl,container)

	local function clearAll(animTbl)
		for k,v in pairs(animTbl) do --清理动画
			if v and v.obj then
				v.obj:stopAllActions()
				v.obj:removeFromParentAndCleanup(true)
				v.obj = nil
				v = nil
			end
		end
	end

	local function endProgress()
		if Utils.get_length_from_any_table(animTbl) ~= 0 then
			print("清理完成 !!!!!!!")
			clearAll(animTbl)
			GuideLayer:hide(eventVo.groupType) --清理引导
		end

		-- if Global:getStringForKey(string.format("guideMainStart%s%d", Global:getStringForKey("username"),eventVo.id)) == nil then
		-- 	Global:setStringForKey(string.format("guideMainStart%s%d", Global:getStringForKey("username"),eventVo.id),"done")
		-- end
		if eventVo.isRecord == GuideEndType.Record then
			-- local groupVo = GuideDataProxy:getInstance():getMainGroupVoById(eventVo.groupId)
			-- GuideNetTask:getInstance():requestRecordGuideId(groupVo.beginId)
			GuideNetTask:getInstance():requestRecordGuideId(eventVo.id)
			eventVo.hasRecord = 1
		end
		Notifier.dispatchCmd(GuideEvent.Main,{GuideCondType.Trigger,eventVo.id}) --正常完成播放
	end

	local layerClickLab = container.lock_lab_layer  --有可能是其他容器(按钮,面板等)，所以要判断是否存在
	if layerClickLab then
		layerClickLab:setTouchEnabled(false)
	end
	
	if eventVo.endCond.key == "normal" then
		endProgress()
	elseif eventVo.endCond.key == "click_10000" then
		local tmpClickImg = ImageView:create()
	    tmpClickImg:setTouchEnabled(true)
	    tmpClickImg:setScale(50)
	    tmpClickImg:setVisible(false)
	    tmpClickImg:loadTexture("ui/guide/guide/guide_img_mask.png")
	    tmpClickImg:setPosition(ccp(480,320))

	    if layerClickLab then
	    	layerClickLab:setTouchEnabled(true)
	    	layerClickLab:addChild(tmpClickImg)
	    else
	    	container:addChild(tmpClickImg)
		end

	    tmpClickImg:addTouchEventListener(function(pSender,eventType)
	    	if eventType == ComConstTab.TouchEventType.ended then
	    		if layerClickLab then
	    			layerClickLab:setTouchEnabled(false)
	    		end
	    		endProgress()
	    		tmpClickImg:removeFromParentAndCleanup(true)
	   	 	end
	    end)

	elseif eventVo.endCond.type == "time" then --延时
		container:runAction(CCSequence:createWithTwoActions(
			CCDelayTime:create(tonumber(eventVo.endCond.params[1] / 1000)),
			CCCallFunc:create(endProgress)))
	else
		Notifier.removeByName(GuideEvent.StepFinish)
		Notifier.regist(GuideEvent.StepFinish,function(key)
			if eventVo.endCond.key == key then
				endProgress(eventVo,animTbl)
			end
		end)
	end
end

--剧情播放结束
local function animComplete(eventVo,animTbl,lockContainer,viewContainer)

	local function clearAll(animTbl)
		for k,v in pairs(animTbl) do --清理动画
			if v.isLazyDel == 0 then
				if v.obj then
					-- print(" 清理骨骼 ",tostring(v.obj))
					v.obj:stopAllActions()
					v.obj:removeFromParentAndCleanup(true)
					v.obj = nil
				end
			else
				table.insert(GuideDataProxy:getInstance().voLazyRemoveList,v) --缓存 延时清理
			end
		end

		checkLazyRemove(eventVo.id)
		GuideDungeon:hide(viewContainer,eventVo.endType) --清理引导

		tolua.cast(viewContainer:getChildByName("img_clickview"),"ImageView"):setTouchEnabled(false)
	end
---------------------------------------
	local function endProgress()
		if eventVo.endType == GuideEndType.AfterToDo then
			if __instance:checkPlayNewHeroAnim(eventVo) == false then
				clearAll(animTbl)
				Notifier.dispatchCmd(GuideEvent.Dungeon,{GuideCondType.Trigger,eventVo.id}) --正常完成播放

				BattleController:getInstance():showBattleResult()
				ComResMgr:getInstance():clearCache()
			else
				local function tmpClickFunc()
					Notifier.removeByName(GuideEvent.ClickFinish)
					clearAll(animTbl)
					Notifier.dispatchCmd(GuideEvent.Dungeon,{GuideCondType.Trigger,eventVo.id}) --正常完成播放
				end

				Notifier.removeByName(GuideEvent.ClickFinish)
				Notifier.regist(GuideEvent.ClickFinish,tmpClickFunc)
			end
		elseif eventVo.endType == GuideEndType.BeforeToDo then --前置动画结束
			clearAll(animTbl)
			Notifier.dispatchCmd(GuideEvent.Dungeon,{GuideCondType.Trigger,eventVo.id}) --正常完成播放

			Notifier.dispatchCmd(GuideEvent.PerStoryComplete)
			
			BattleController:getInstance():moveUI()
			GuideDataProxy:getInstance():isCanShowVipSpeepTips()
		elseif eventVo.endType == GuideEndType.ForceQuite then --强制结束
			clearAll(animTbl)
			CCArmatureDataManager:sharedArmatureDataManager():removeArmatureFileInfo("shikongniuquxiaoguo") --手动删除资源
			CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile("ui/guide/shikongniuqu1.plist")
			CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile("ui/guide/shikongniuqu2.plist")

			Notifier.dispatchCmd(GuideEvent.Dungeon,{GuideCondType.Trigger,eventVo.id}) --正常完成播放

			GameLayerMgr:getInstance():darkMainScene()
			BattleManager:getInstance():reqBattleEnd()
			BattleManager:getInstance():reqBattleStart(10000, 1,TeamType.Normal)
		elseif eventVo.endType == GuideEndType.Normal then --正常结束
			clearAll(animTbl)
			Notifier.dispatchCmd(GuideEvent.Dungeon,{GuideCondType.Trigger,eventVo.id}) --正常完成播放
		end
	end

	local t = eventVo.endCond.type
	if t == "normal" then
		endProgress()
	elseif t == "time" then --延时
		viewContainer:runAction(CCSequence:createWithTwoActions(
			CCDelayTime:create(tonumber(eventVo.endCond.params[1] / 1000)),
			CCCallFunc:create(endProgress)))
	end
end

-- 主教程 检测 播放结束
local function checkMainTutorial(eventVo,animTbl,lockContainer,viewContainer)
	eventVo.cout = eventVo.cout + 1
	print("新手引導 eventVo.cout ,eventVo.total", eventVo.id,eventVo.cout , eventVo.total)
	if eventVo.cout == eventVo.total then
		animCompleteMainTutorial(eventVo,animTbl,lockContainer,viewContainer)
	end
end

local function checkMainFlagTutorial(eventVo,animTbl,container)
	eventVo.cout = eventVo.cout + 1
	print("引導 eventVo.cout ,eventVo.total", eventVo.id,eventVo.cout , eventVo.total)
	if eventVo.cout == eventVo.total then
		animCompleteMainFlagTutorial(eventVo,animTbl,container)
	end
end

-- 剧情检测播放结束
local function checkComplete(eventVo,animTbl,lockContainer,viewContainer)
	eventVo.cout = eventVo.cout + 1
	print("劇情 eventVo.cout ,eventVo.total", eventVo.id,eventVo.cout , eventVo.total)
	if eventVo.cout == eventVo.total then
		animComplete(eventVo,animTbl,lockContainer,viewContainer)
	end
end

-- 剧情教程检测播放结束
local function checkCompleteTutorial(eventVo,animTbl,lockContainer,viewContainer)
	eventVo.cout = eventVo.cout + 1
	print("教程 eventVo.cout ,eventVo.total", eventVo.id,eventVo.cout , eventVo.total)
	if eventVo.cout == eventVo.total then
		animCompleteDungeonTutorial(eventVo,animTbl,lockContainer,viewContainer)
	end
end

--解析 剧情
function GuideRenderMgr:renderEventVo(lockContainer,viewContainer,id)
	
	viewContainer:setTouchEnabled(true)
	lockContainer:setTouchEnabled(true)

	print(" 劇情id ",id)
    local eventVo = GuideDataProxy:getInstance():getStoryEventVoById(id)
    eventVo.hasExecute = 1 --已经执行过
    GuideDataProxy:getInstance().nowEventId = eventVo.id

	if eventVo.condTbl[1].type == "into" and eventVo.isSkipRecord == 0 then
		GuideNetTask:getInstance():requestRecordPlotId(id)
	end
	if eventVo.isRecord == 1 then
		GuideNetTask:getInstance():requestRecordPlotId(eventVo.replayBeginId)
	end

    local baseData = CharacterManager:getInstance():getBaseData()
    -- print("event begin => eventVo.cout,eventVo.total", eventVo.id,eventVo.cout , eventVo.total)
    if eventVo.islock == 1 then
    	self:renderUnlock(lockContainer,eventVo.p1,eventVo.p2)
    elseif eventVo.islock == 0 then
		self:renderLock(lockContainer)		
    end
-----------------------------------------------------------------------------------------
    local function progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
    	if eventVo.id < GuideDataProxy:getInstance().nowEventId then return end
		checkComplete(eventVo,animObjTbl,lockContainer,viewContainer)
	end
-----------------------------------------------------------------------------------------
    local animObjTbl = {} --所有动画体 用于清理

    for i=1,table.getn(eventVo.animTbl) do

    	local animVo = eventVo.animTbl[i]

    	if animVo.type == "res" or animVo.type == "npc" or animVo.type == "effect" then

    		GuideDataProxy:getInstance()._animatrueRemoveList[ animVo.path ] = "mark" --记录资源路径，后面删除

	    	CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(animVo.path)
	    	local armature = CCArmature:create(animVo.name)
	    	armature:setPosition(ccp(animVo.x,animVo.y))

	    	if animVo.x2 ~= nil then --位移动画
	    		local arr = CCArray:create()
		    	arr:addObject(CCMoveTo:create(animVo.moveTime,ccp(animVo.x2 ,animVo.y2)))
		    	arr:addObject(CCCallFuncN:create(function()
		    		progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer) --位移结束
		    	end))
		    	armature:runAction(CCSequence:create(arr))
	    	end

	    	if animVo.name == "shikongniuquxiaoguo" then --全屏特效 要自适应 全屏
	    		local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
 				local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()
	    		armature:setScaleX(1/DisplayUtil.min_scale*DisplayUtil.max_scale)
		 		armature:setScaleY(1/DisplayUtil.min_scale*DisplayUtil.max_scale)
	    	else
		    	armature:setScaleX(animVo.flip * animVo.scale)
		    	armature:setScaleY(animVo.scale)
	    	end
	    	armature:setTag(0) --循环播放计数器
	    	
	    	local shadow = CCSprite:createWithSpriteFrameName("yingzi.png")  --添加影子
	    	armature:addChild(shadow)

	    	viewContainer:addNode(armature,animVo.layer)
	    	-------------------------------------------------------------------------------------------
	    	--延时删除
	    	if animVo.delayWay and animVo.delayWay[1] == "till" then
	    		table.insert(animObjTbl,{ type = animVo.delayWay[1], isLazyDel = 1, obj = armature ,triggerId = animVo.delayWay[3]})
	    	else
	    		table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = armature})
	    	end
	    	-------------------------------------------------------------------------------------------
	    	if animVo.gap == nil then
		    	armature:getAnimation():setMovementEventCallFunc(function(armatureBack,movementType,movementID)
			        if movementType == AnimationMovementType.COMPLETE or 
						movementType == AnimationMovementType.LOOP_COMPLETE then

						if armature:getTag() == 0 then --循环锁
							progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
							armature:setTag(1)
						end
					end
				end)
	    	end
	    	-------------------------------------------------------------------------------------------
	    	--延时播放
	    	if animVo.delayWay and animVo.delayWay[1] == "delay" then
	    		local delayTime = animVo.delayWay[2]
	    		local arr = CCArray:create()
	    		arr:addObject(CCHide:create())
	    		arr:addObject(CCDelayTime:create(tonumber(delayTime) / 1000))
	    		arr:addObject(CCShow:create())
	    		arr:addObject(CCCallFunc:create(function()
	    			if animVo.gap ~= nil then
	    				self:playGapFrame(armature,animVo.play,tonumber(animVo.from),tonumber(animVo.to),function()

	    					if armature:getTag() == 0 then --循环锁
	    						progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
	    						armature:setTag(1)
	    					end

	    				end,animVo.rep)

	    			else
						armature:getAnimation():play(animVo.play,0,-1,animVo.rep)
					end
	    		end))
	    		armature:runAction(CCSequence:create(arr))
	    	else
	    		if animVo.gap ~= nil then
	    			self:playGapFrame(armature,animVo.play,tonumber(animVo.from),tonumber(animVo.to),function()

	    				if armature:getTag() == 0 then --循环锁
    						progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
    						armature:setTag(1)
	    				end

	    			end,animVo.rep)
	    		else
	    			armature:getAnimation():play(animVo.play,0,-1,animVo.rep)
	    		end
	    	end
			if eventVo.isCanPass == 1 then --是否能跳过剧情
				local imgClickView = tolua.cast(viewContainer:getChildByName("img_clickview"),"ImageView")
				imgClickView:setTouchEnabled(true)
		    	imgClickView:addTouchEventListener(function(pSender,eventType)
		    		if eventType == ComConstTab.TouchEventType.ended then 
		    			imgClickView:setTouchEnabled(false)
			   			quickComplete(eventVo,animObjTbl,lockContainer,viewContainer)
		   			end
		    	end)
	    	end
	    	self:renderUnlockAll(lockContainer)

-------------------------------------------------------------------------------------------
	    elseif animVo.type == "story" then

	    	local imgClickView = tolua.cast(viewContainer:getChildByName("img_clickview"),"ImageView")
	    	imgClickView:setTouchEnabled(false)

	    	local img = ImageView:create()
	    	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_img_story.plist")
	    	img:loadTexture("guide_img_story.png",UI_TEX_TYPE_PLIST)
	    	img:setPosition(ccp(animVo.x,animVo.y))
	    	viewContainer:addChild(img,5)

	    	if animVo.head ~= "0" then --
	    		-- CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA8888)
	    		CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile(string.format("ui/guide/guide/guide_head_%d.plist",animVo.head))
		    	local img2 = ImageView:create()
		    	img2:loadTexture(string.format("guide_head_%d.png",animVo.head),UI_TEX_TYPE_PLIST)
		    	if animVo.head == "10001" then
		    		if baseData:getSex() == CharacterCfg.Female then
		    			CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_head_10001_f.plist")
		    			img2:loadTexture("guide_head_10001_f.png",UI_TEX_TYPE_PLIST) --女主角头像
		    		end
		    	elseif animVo.head == "10014" then
		    		if baseData:getSex() == CharacterCfg.Female then
		    			CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_head_10014_f.plist")
		    			img2:loadTexture("guide_head_10014_f.png",UI_TEX_TYPE_PLIST) --女主角头像
		    		end
		    	end
		    	img2:setPosition(ccp(animVo.x - 250,animVo.y + 100))
		    	viewContainer:addChild(img2,4)
		    	-- CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA4444)
		    	table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = img2})
	    	end

	    	local imgClickLab = tolua.cast(viewContainer:getChildByName("img_clicklab"),"ImageView")
	    	imgClickLab:setTouchEnabled(true)
	    	imgClickLab:addTouchEventListener(function(pSender,eventType)
	    		if eventType == ComConstTab.TouchEventType.ended then 
	    			-- print(" 點擊劇情 ",eventVo.id)
		   			if self:isAllLabAnimFinish(animObjTbl) then
		   				imgClickLab:setTouchEnabled(false)
		   			else
		   				self:showAllLab(animObjTbl)
		   			end
		   			progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
	   			end
	    	end)

	    	local imgArrow2 = ImageView:create()
	    	imgArrow2:loadTexture("ui/guide/guide/guide_img_arrows2.png")
	    	imgArrow2:setPosition(ccp(712,50))
	    	viewContainer:addChild(imgArrow2,5)

	    	local imgArrow = ImageView:create()	
	    	imgArrow:loadTexture("ui/guide/guide/guide_img_arrow.png")
	    	imgArrow:setPosition(ccp(712,70))
	    	viewContainer:addChild(imgArrow,5)
	    	imgArrow:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
				CCMoveBy:create(0.8, ccp(0,-10)),
				CCMoveBy:create(0.8, ccp(0, 10)))))

	    	table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = img})
	    	table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = imgArrow2})
	    	table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = imgArrow})

-------------------------------------------------------------------------------------------  	
		  	if eventVo.labTbl then --放置文本

		   		local txt1 = eventVo.labTbl[1] --文本1
		   		local baseData = CharacterManager:getInstance():getBaseData()
				txt1 = string.gsub(txt1,"hero",baseData:getName())

				local lab1 = Label:create()
				lab1:setAnchorPoint(ccp(0,1))
				lab1:setColor(ccc3(251,241,160))

				lab1:setFontSize(22)

				lab1:setPosition(ccp(animVo.x - 150, animVo.y + 100))
				lab1:setTag(2) --状态:[0:动画开始,1:动画进行中,2:动画已完成]
				lab1:setText(txt1)
				viewContainer:addChild(lab1,10)
				table.insert(animObjTbl,{ type = "", clazz = "label", txt = txt1, isLazyDel = 0, obj = lab1})

				local txt2 = eventVo.labTbl[2]  --文本2
				if baseData:getSex() == CharacterCfg.Female and #eventVo.labTbl == 3 then
					txt2 = eventVo.labTbl[3]
				end

				txt2 = string.gsub(txt2,"hero",baseData:getName())

				if self:isRtfTxt(txt2) then --富文本
					local tblRtf = loadstring("return {" .. txt2 .. "}")()
					local rtf = DisplayUtil.createRtfLab(tblRtf,17)
					rtf:setTag(0)
					rtf:setPosition(ccp(animVo.x - 150, animVo.y + 40))
					self:showRtfAnim(rtf,txt2,function()
			    		progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
			    	end)
					viewContainer:addNode(rtf,10)
					table.insert(animObjTbl,{ type = "", clazz = "rtf", isLazyDel = 0, obj = rtf})
				else  --普通文本
					-- txt2 = Helper.insertnl(txt2,17)
					local lab2 = Label:create()
					lab2:setAnchorPoint(ccp(0,1))
					lab2:setColor(ccc3(251,241,160))
					lab2:setFontSize(22)
					lab2:setTag(0)
					lab2:ignoreContentAdaptWithSize(false)
					lab2:setSize(CCSize(350,500))
					lab2:setPosition(ccp(animVo.x - 150, animVo.y + 40))
					self:showLabAnim(lab2,txt2,function()
			    		progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
			    	end)
					viewContainer:addChild(lab2,10)
					table.insert(animObjTbl,{ type = "", clazz = "label", txt = txt2, isLazyDel = 0, obj = lab2})
				end
		  	end

	    	self:renderUnlockAll(lockContainer)
----------------------------------------------------------------------------------------	    	
	    elseif animVo.type == "create" then
	    	local flag = CharacterManager:getInstance():getBaseData():getHasCreateName()
	    	if flag == 0 then --未改名字
	    		require "GuideCreateNamePanel"
		    	local panel = GuideCreateNamePanel:create()
		    	panel:setCallBackFunc(function() 
		    		self:renderUnlockAll(lockContainer)
		    		progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer) 
		    	end)
		    	viewContainer:addChild(panel)
		    	self:renderUnlockAll(lockContainer)
		    	table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = panel})
	    	elseif flag == 1 then --已改名
	    		progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
	    	end
----------------------------------------------------------------------------------------	
	    elseif animVo.type == "change" then
    		require "GuideChangeSkinView"
	    	local panel = GuideChangeSkinView:create(function() 
	    		self:renderUnlockAll(lockContainer)
	    		progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer) 
	    	end, animVo.effectId,animVo.heroId )
	    	viewContainer:addChild(panel)
	    	self:renderUnlockAll(lockContainer)
	    	table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = panel})
----------------------------------------------------------------------------------------	    	
    	elseif animVo.type == "dark" then
    		local img = CCSprite:create(animVo.path)
    		img:setPosition(ccp(animVo.x,animVo.y))
    		-- img:setContentSize(CCSize(960,640))
    		img:setScale(animVo.scale)
    		img:setOpacity(0)
    		viewContainer:addNode(img,animVo.layer)
			progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
			table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = img})

    		local function perpare()
				local startPosY = viewContainer:getPositionY()
				if animVo.play == "shake" then
					local function shakeAction()
						local arr = CCArray:create()
						arr:addObject( CCPlace:create(ccp(0,-30)) )
						arr:addObject( CCDelayTime:create(0.1) )
						arr:addObject( CCPlace:create(ccp(0,50)) )
						arr:addObject( CCDelayTime:create(0.1) )
						arr:addObject( CCPlace:create(ccp(0,-20)) )
						arr:addObject( CCDelayTime:create(0.1) )
						arr:addObject( CCPlace:create(ccp(-40,0)) )
						arr:addObject( CCDelayTime:create(0.1) )
						arr:addObject( CCPlace:create(ccp(60,0)) )
						arr:addObject( CCPlace:create(ccp(-20,0)) )
						arr:addObject( CCDelayTime:create(0.1) )
						arr:addObject( CCPlace:create(ccp(0,-40)) )
						arr:addObject( CCDelayTime:create(0.1) )
						arr:addObject( CCPlace:create(ccp(0,50)) )
						arr:addObject( CCPlace:create(ccp(0,-10)) )
						arr:addObject( CCDelayTime:create(0.1) )
						viewContainer:runAction(CCRepeatForever:create(CCSequence:create(arr)))
					end
					if animVo.delay ~= 0 then
						viewContainer:runAction(CCSequence:createWithTwoActions(
							CCDelayTime:create(animVo.delay),
							CCCallFunc:create(function()
							viewContainer:stopAllActions()

							shakeAction()
							end)))
					else
						shakeAction()
					end
				end
				
				if eventVo.labTbl then --放置文本
					local lab = Label:create()
			    	lab:setAnchorPoint(ccp(0,1))
			    	lab:setColor(ccc3(251,241,160))
			    	lab:setFontSize(26)
			    	lab:setPosition(ccp(animVo.x - 300, animVo.y))
					local txt = Helper.insertnl(eventVo.labTbl[1],23)
					self:showLabAnim(lab,txt,function()
						viewContainer:stopAllActions()
						viewContainer:setPositionY(startPosY)
						lab:setVisible(false)
						
						progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)							
			    	end,0.1)
			    	viewContainer:addChild(lab,animVo.layer)
				    table.insert(animObjTbl,{ type = "", clazz = "label", txt = txt, isLazyDel = 0, obj = lab})
				end
			end

			local arr = CCArray:create()
			arr:addObject(CCDelayTime:create(1))
			arr:addObject(CCFadeIn:create(0.5))
			arr:addObject(CCCallFunc:create(perpare))
    		img:runAction(CCSequence:create(arr))

    	elseif animVo.type == "darklayer" then

    		local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
    		local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()
    		local shadow = CCLayerColor:create(ccc4(0, 0, 0, 255))
    		shadow:setOpacity(0)
		    shadow:setScaleX(1/DisplayUtil.min_scale*globa_scalx)
		    shadow:setScaleY(1/DisplayUtil.min_scale*globa_scaly)
	    	viewContainer:addNode(shadow,animVo.layer)
	    	table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = shadow})

	    	local arr = CCArray:create()
	    	local delayTime = 0
	    	if animVo.delayWay and animVo.delayWay[1] == "delay" then
	    		delayTime = tonumber(animVo.delayWay[2]) / 1000
	    	end
			arr:addObject(CCDelayTime:create(delayTime))
			arr:addObject(CCFadeIn:create(0.5))
			arr:addObject(CCCallFunc:create(function() 
				progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer) 
			end))
    		shadow:runAction(CCSequence:create(arr))

    	elseif animVo.type == "light" then

    		local img = CCSprite:create(animVo.path)
    		img:setPosition(ccp(animVo.x,animVo.y))
    		img:setScale(animVo.scale)
    		viewContainer:addNode(img,animVo.layer)
			progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
			table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = img})

			local arr = CCArray:create()
			arr:addObject(CCFadeOut:create(0.5))
    		img:runAction(CCSequence:create(arr))
    	end
    end
----------------------------------------------------------------------------------------
	if eventVo.screenAct then --镜头移动
		local tbl = eventVo.screenAct
		if tbl[1] == "right" then dir = -1 else dir = 1 end

		local movePos = BattleController:getInstance():calcMapMovePos(tonumber(tbl[2]))
		
		BattleController:getInstance():moveMapBy(tonumber(tbl[2]), nil, tonumber(tbl[3]))

		local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
 		local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()

		viewContainer:runAction(CCSequence:createWithTwoActions(
			CCMoveBy:create(tonumber(tbl[3]),ccp(dir * movePos * (1/DisplayUtil.min_scale*globa_scalx) ,0)),
			CCCallFunc:create(function()
				progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
				--通知
			end)))
	end
end
----------------------------------------------------------------------------------------------
--渲染教程
function GuideRenderMgr:renderDungeonTutorialVo(lockContainer,viewContainer,id)
	
	viewContainer:setTouchEnabled(false)
	lockContainer:setTouchEnabled(false)

    local eventVo = GuideDataProxy:getInstance():getDungeonTutorialVoById(id)
	eventVo.hasExecute = 1 --已经执行过
	print(" 教程id ",id)

	self:renderLock(lockContainer)
-----------------------------------------------------------------------------------------
    local function progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
		--播放完成
		local stayTime = 0
		if animVo and animVo.delayWay and animVo.delayWay[1] == "stay" then
			stayTime = animVo.delayWay[2]
		end
		--停留时间
		TimerManager.addTimer(stayTime * 1000,function()
			checkCompleteTutorial(eventVo,animObjTbl,lockContainer,viewContainer)
		end)
	end
-----------------------------------------------------------------------------------------
    local animObjTbl = {} --所有动画体 用于清理
    for i=1,table.getn(eventVo.animTbl) do

    	local animVo = eventVo.animTbl[i]

    	if animVo.type == "res" or animVo.type == "npc" then

	    	CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(animVo.path)
	    	local armature = CCArmature:create(animVo.name)
	    	armature:setPosition(ccp(animVo.x,animVo.y))

	    	if animVo.x2 ~= nil then --位移动画
	    		local arr = CCArray:create()
		    	arr:addObject(CCMoveTo:create(animVo.moveTime,ccp(animVo.x2,animVo.y2)))
		    	arr:addObject(CCCallFuncN:create(function()

		    		progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer) --位移结束
		    	end))
		    	armature:runAction(CCSequence:create(arr))
	    	end

	    	armature:setScaleX(animVo.flip)
	    	armature:setTag(0) --循环播放计数器
	    	viewContainer:addNode(armature,10 - animVo.layer)
	    	-------------------------------------------------------------------------------------------
	    	--延时删除
	    	if animVo.delayWay and animVo.delayWay[1] == "till" then
	    		table.insert(animObjTbl,{ type = animVo.delayWay[1], isLazyDel = 1, obj = armature ,triggerId = animVo.delayWay[3]})
	    	else
	    		table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = armature})
	    	end
	    	-------------------------------------------------------------------------------------------
	    	if animVo.gap == nil then 
		    	armature:getAnimation():setMovementEventCallFunc(function(armatureBack,movementType,movementID)
			        if movementType == AnimationMovementType.COMPLETE or 
						movementType == AnimationMovementType.LOOP_COMPLETE then

						if armature:getTag() == 0 then --循环锁
							progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
							armature:setTag(1)
						end
					end
				end)
	    	end
	    	-------------------------------------------------------------------------------------------
	    	--延时播放
	    	if animVo.delayWay and animVo.delayWay[1] == "delay" then
	    		local delayTime = animVo.delayWay[2]
	    		local arr = CCArray:create()
	    		arr:addObject(CCHide:create())
	    		arr:addObject(CCDelayTime:create(tonumber(delayTime)))
	    		arr:addObject(CCShow:create())
	    		arr:addObject(CCCallFunc:create(function()
    				if animVo.gap ~= nil then
	    				self:playGapFrame(armature,animVo.play,tonumber(animVo.from),tonumber(animVo.to),function()

	    					if armature:getTag() == 0 then --循环锁
	    						progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
	    						armature:setTag(1)
	    					end

	    				end,animVo.rep)
	    			else
						armature:getAnimation():play(animVo.play,0,-1,animVo.rep)
					end
    			end))
				armature:runAction(CCSequence:create(arr))
	    	else
	    		if animVo.gap ~= nil then
	    			self:playGapFrame(armature,animVo.play,tonumber(animVo.from),tonumber(animVo.to),function()

	    				if armature:getTag() == 0 then --循环锁
    						progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
    						armature:setTag(1)
	    				end

	    			end,animVo.rep)
	    		else
	    			armature:getAnimation():play(animVo.play,0,-1,animVo.rep)
	    		end
	    	end
-------------------------------------------------------------------------------------------
	    elseif animVo.type == "guide" then

	    	local function showGuide()
	    		--点击文本快速显示
	    		local imgClickLab = tolua.cast(viewContainer:getChildByName("img_clicklab"),"ImageView")
		    	imgClickLab:setTouchEnabled(true)
		    	imgClickLab:addTouchEventListener(function(pSender,eventType)
		    		if eventType == ComConstTab.TouchEventType.ended then 
			   			if self:isAllLabAnimFinish(animObjTbl) then
			   				imgClickLab:setTouchEnabled(false)
			   			else
			   				self:showAllLab(animObjTbl)
			   			end
			   			progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
		   			end
		    	end)
		    	self:renderUnlockAll(lockContainer)

		    	-- CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA8888)
		    	local img = ImageView:create()
		    	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_img_tutorial.plist")
		    	img:loadTexture("guide_img_tutorial.png",UI_TEX_TYPE_PLIST)
		    	img:setPosition(ccp(animVo.x,animVo.y))
		    	viewContainer:addChild(img,2)
		    	
		    	local img2 = ImageView:create()
		    	-- img2:loadTexture("ui/guide/guide/guide_tutorial.png")
		    	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_tutorial.plist")
		    	img2:loadTexture("guide_tutorial.png",UI_TEX_TYPE_PLIST)
		    	img2:setPosition(ccp(animVo.x - 250,animVo.y + 100))
		    	viewContainer:addChild(img2,3)
		    	-- CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA4444)
		    	table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = img})
		    	table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = img2})

		    	progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
	-------------------------------------------------------------------------------------------  	
			  	if eventVo.labTbl then --放置文本

					local txt2 = eventVo.labTbl[1]  --文本2

					if self:isRtfTxt(txt2) then --富文本
						local tblRtf = loadstring("return {" .. txt2 .. "}")()
						local rtf = DisplayUtil.createRtfLab(tblRtf,14)
						rtf:setTag(0)
						rtf:setPosition(ccp(animVo.x - 150, animVo.y + 40))
						self:showRtfAnim(rtf,txt2,function()
				    		progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
				    	end)
						viewContainer:addNode(rtf,10)
						table.insert(animObjTbl,{ type = "", clazz = "rtf", isLazyDel = 0, obj = rtf})
					else  --普通文本
						-- txt2 = Helper.insertnl(txt2,14)
						local lab2 = Label:create()
						lab2:setAnchorPoint(ccp(0,1))
						lab2:setColor(ccc3(251,241,160))
						lab2:setFontSize(22)
						lab2:ignoreContentAdaptWithSize(false)
						lab2:setSize(CCSize(350,500))
						lab2:setTag(0)
						lab2:setPosition(ccp(animVo.x - 150, animVo.y + 40))
						self:showLabAnim(lab2,txt2,function()
				    		progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
				    	end)
						viewContainer:addChild(lab2,10)
						table.insert(animObjTbl,{ type = "", clazz = "label", txt = txt2, isLazyDel = 0, obj = lab2})
					end

			  	end
		  	end

		  	if animVo.delayWay and animVo.delayWay[1] == "delay" then --延时播放
		    	local delayTime = animVo.delayWay[2]
		    	local arr = CCArray:create()
		    	arr:addObject(CCDelayTime:create(tonumber(delayTime) / 1000))
		    	arr:addObject(CCCallFunc:create(showGuide))
		    	viewContainer:runAction(CCSequence:create(arr))
		    else --马上播放
		    	showGuide()
		    end
---------------------------------------------------------------------------------------------------		  	
		elseif animVo.type == "finger" then --引导手指事件
			
			local img = ImageView:create()
			img:setAnchorPoint(ccp(0,1))
			img:loadTexture(animVo.path)
			self:showLineAnim(img,viewContainer,animObjTbl,function()
				progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
			end,animVo.moveTbl,animVo.moveTime,eventVo.id)

			progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
    	end
    end

end
---------------------------------------------------------------------------------------------------
-- 渲染主界面教程
function GuideRenderMgr:renderMainTutorialVo(lockContainer,viewContainer,id)
	viewContainer:setTouchEnabled(true)
	lockContainer:setTouchEnabled(true)

	print("指引 id ",id)
    local eventVo = GuideDataProxy:getInstance():getMainTutorialVoById(id)
    eventVo.hasExecute = 1

    self:renderLock(lockContainer)
    local function progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
		checkMainTutorial(eventVo,animObjTbl,lockContainer,viewContainer)
	end
-----------------------------------------------------------------------------------------
    local animObjTbl = {} --所有动画体 用于清理

    --服务端记录
    if eventVo.isRecord == GuideEndType.HeadRecord then
		GuideNetTask:getInstance():requestRecordGuideId(eventVo.id)
		eventVo.hasRecord = 1
	end

    for i=1,table.getn(eventVo.animTbl) do

    	local animVo = eventVo.animTbl[i]

    	if animVo.type == "res" or animVo.type == "npc" then
			CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(animVo.path)
	    	local armature = CCArmature:create(animVo.name)
	    	armature:setPosition(ccp(animVo.x,animVo.y))

	    	if animVo.x2 ~= nil then --位移动画
	    		local arr = CCArray:create()
		    	arr:addObject(CCMoveTo:create(animVo.moveTime,ccp(animVo.x2,animVo.y2)))
		    	arr:addObject(CCCallFuncN:create(function()
		    		progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer) --位移结束
		    	end))
		    	armature:runAction(CCSequence:create(arr))
	    	end

	    	armature:setScaleX(animVo.flip * animVo.scale)
	    	armature:setScaleY(animVo.scale)
	    	armature:setTag(0) --循环播放计数器

	    	print(" [渲染完成 res]  ",animVo.target,id)
	    	viewContainer:addNode(armature,100)
	    	table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = armature })
	    	-------------------------------------------------------------------------------------------
    		if animVo.gap ~= nil then
    			progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
    			self:playGapFrame(armature,animVo.play,tonumber(animVo.from),tonumber(animVo.to),function()
    			end,animVo.rep)
    		else
    			progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
    			armature:getAnimation():play(animVo.play,0,-1,animVo.rep)
    		end

	    elseif animVo.type == "guide" then

	    	local function showGuide()
				-- CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA8888)
		    	local img = ImageView:create()
		    	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_img_tutorial.plist")
		    	img:loadTexture("guide_img_tutorial.png",UI_TEX_TYPE_PLIST)
		    	img:setPosition(ccp(animVo.x,animVo.y))
		    	viewContainer:addChild(img,2)
		    	
		    	local img2 = ImageView:create()
		    	-- img2:loadTexture("ui/guide/guide/guide_tutorial.png")
		    	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_tutorial.plist")
		    	img2:loadTexture("guide_tutorial.png",UI_TEX_TYPE_PLIST)
		    	img2:setPosition(ccp(animVo.x - 250,animVo.y + 100))
		    	viewContainer:addChild(img2,3)
		    	-- CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA4444)

		    	table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = img})
		    	table.insert(animObjTbl,{ type = "", isLazyDel = 0, obj = img2})

		    	progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
	-------------------------------------------------------------------------------------------  	
			  	if eventVo.labTbl then --放置文本
			  		for i=1,table.getn(eventVo.labTbl) do
			  			
				    	-- local txt = Helper.insertnl(eventVo.labTbl[i],15)
				    	local txt = eventVo.labTbl[i]
				    	local lab = Label:create()
				    	lab:ignoreContentAdaptWithSize(false)
						lab:setSize(CCSize(350,500))
				    	lab:setAnchorPoint(ccp(0,1))
				    	lab:setColor(ccc3(251,241,160))
				    	lab:setFontSize(22)
				    	lab:setTextAreaSize(CCSize(300,300))
						lab:setTag(0)
						lab:setPosition(ccp(animVo.x - 150, animVo.y + 40))
						self:showLabAnim(lab,txt,function()
							local imgClickLab = tolua.cast(viewContainer:getChildByName("img_clicklab"),"ImageView")
							imgClickLab:setTouchEnabled(false)
				    		progreeEnd(eventVo,animVo,animObjTbl,lockContainer,viewContainer)
				    	end)
				    	viewContainer:addChild(lab,3)

				    	table.insert(animObjTbl,{ type = "", clazz = "label", txt = txt, isLazyDel = 0, obj = lab})
			    	end
			  	end
		  	end

		  	if animVo.delayWay and animVo.delayWay[1] == "delay" then --延时播放
		    	local delayTime = animVo.delayWay[2]
		    	local arr = CCArray:create()
		    	arr:addObject(CCDelayTime:create(tonumber(delayTime) / 1000))
		    	arr:addObject(CCCallFunc:create(showGuide))
		    	viewContainer:runAction(CCSequence:create(arr))
		    else --马上播放
		    	showGuide()
		    end
---------------------------------------------------------------------------------------------------		  	
	    end
	end
end
---------------------------------------------------------------------------------------------------

function GuideRenderMgr:renderMainFlag(container,id,target,forcePos)
	local function progreeEnd(eventVo,animVo,animObjTbl,container)
		if eventVo.id < GuideDataProxy:getInstance().nowMainTutroialEventId then return print("越界了！！！",eventVo.id) end
		checkMainFlagTutorial(eventVo,animObjTbl,container)
	end
	local eventVo = GuideDataProxy:getInstance():getMainTutorialVoById(id)
    eventVo.hasExecute = 1
    print("Flag提示",id,target)
    -----------------------------------------------------------------------------------------
    if eventVo.animObjTbl == nil then  --所有动画体 用于清理(单列)
    	eventVo.animObjTbl = {}
    end
    --服务端记录
    if eventVo.isRecord == GuideEndType.HeadRecord then
		GuideNetTask:getInstance():requestRecordGuideId(eventVo.id)
		eventVo.hasRecord = 1
	end

    for i=1,table.getn(eventVo.animTbl) do

    	local animVo = eventVo.animTbl[i]

    	if animVo.target == target and animVo.renderedLock == nil then --根据容器 匹配需要显示的元素

    		animVo.renderedLock = "done" --渲染锁 确保只渲染一次

			if animVo.type == "res" or animVo.type == "npc" then
				CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(animVo.path)
		    	local armature = CCArmature:create(animVo.name)
		    	if forcePos ~= nil then
		    		armature:setPosition(ccp(animVo.x + forcePos.x,animVo.y + forcePos.y))
		    	else
		    		armature:setPosition(ccp(animVo.x,animVo.y))
		   	 	end
		    	if animVo.x2 ~= nil then --位移动画
		    		local arr = CCArray:create()
			    	arr:addObject(CCMoveTo:create(animVo.moveTime,ccp(animVo.x2,animVo.y2)))
			    	arr:addObject(CCCallFuncN:create(function()
			    		progreeEnd(eventVo,animVo,eventVo.animObjTbl,container) --位移结束
			    	end))
			    	armature:runAction(CCSequence:create(arr))
		    	end

		    	armature:setScaleX(animVo.flip * animVo.scale)
		    	armature:setScaleY(animVo.scale)
		    	armature:setTag(0) --循环播放计数器

		    	print(" [渲染完成 res]  ",animVo.target,id)
		    	container:addNode(armature,100)

		    	table.insert(eventVo.animObjTbl,{ type = "", isLazyDel = 0, obj = armature , container = container})
		    	-------------------------------------------------------------------------------------------
	    		if animVo.gap ~= nil then
	    			progreeEnd(eventVo,animVo,eventVo.animObjTbl,container)
	    			self:playGapFrame(armature,animVo.play,tonumber(animVo.from),tonumber(animVo.to),function()
	    			end,animVo.rep)
	    		else
	    			progreeEnd(eventVo,animVo,eventVo.animObjTbl,container)
	    			armature:getAnimation():play(animVo.play,0,-1,animVo.rep)
	    		end

	    	elseif animVo.type == "guide" then
	    		-- CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA8888)
				local img = ImageView:create()
				CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_img_tutorial.plist")
				img:loadTexture("guide_img_tutorial.png",UI_TEX_TYPE_PLIST)
				img:setPosition(ccp(animVo.x,animVo.y))
				container:addChild(img,2 + 10)
				
				local img2 = ImageView:create()
				-- img2:loadTexture("ui/guide/guide/guide_tutorial.png")
				CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_tutorial.plist")
				img2:loadTexture("guide_tutorial.png",UI_TEX_TYPE_PLIST)
				img2:setPosition(ccp(animVo.x - 250,animVo.y + 100))
				container:addChild(img2,3 + 10)
				print(" [渲染完成 guide]  ",animVo.target,id)
				-- CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA4444)

				table.insert(eventVo.animObjTbl,{ type = "", isLazyDel = 0, obj = img})
				table.insert(eventVo.animObjTbl,{ type = "", isLazyDel = 0, obj = img2})

				progreeEnd(eventVo,animVo,eventVo.animObjTbl,container)
		-------------------------------------------------------------------------------------------  	
			  	if eventVo.labTbl then --放置文本
			  		for i=1,table.getn(eventVo.labTbl) do
			  			
				    	-- local txt = Helper.insertnl(eventVo.labTbl[i],15)
				    	local txt = eventVo.labTbl[i]
				    	local lab = Label:create()
				    	lab:setAnchorPoint(ccp(0,1))
				    	lab:ignoreContentAdaptWithSize(false)
						lab:setSize(CCSize(350,500))
				    	lab:setColor(ccc3(251,241,160))
				    	lab:setFontSize(22)
				    	lab:setTextAreaSize(CCSize(300,300))
						lab:setTag(0)
						lab:setPosition(ccp(animVo.x - 150, animVo.y + 40))
						self:showLabAnim(lab,txt,function() 
							progreeEnd(eventVo,animVo,eventVo.animObjTbl,container)
						end)
				    	container:addChild(lab,3 + 10)

				    	table.insert(eventVo.animObjTbl,{ type = "", clazz = "label", txt = txt, isLazyDel = 0, obj = lab})
			    	end
			  	end

			  	--快速显示文本 
			  	local layerClickLab = container.lock_lab_layer
				if layerClickLab ~= nil then
			    	layerClickLab:setTouchEnabled(true)
			    	layerClickLab:addTouchEventListener(function(pSender,eventType)
			    		if eventType == ComConstTab.TouchEventType.ended then 
				   			if self:isAllLabAnimFinish(eventVo.animObjTbl) then
				   				layerClickLab:setTouchEnabled(false)
				   			else
				   				self:showAllLab(eventVo.animObjTbl)
				   			end
				   			progreeEnd(eventVo,animVo,eventVo.animObjTbl,container)
			   			end
			    	end)
		   		end
		   	elseif animVo.type == "img" then

		   		local img = ImageView:create()
		   		img:loadTexture(animVo.path)
		   		img:setPosition(ccp(animVo.x,animVo.y))
		   		container:addChild(img)
		   		table.insert(eventVo.animObjTbl,{ type = "", isLazyDel = 0, obj = img})
		   		progreeEnd(eventVo,animVo,eventVo.animObjTbl,container)

			elseif animVo.type == "move" then

				local mainscene = WindowCtrl:getInstance():getMainScene()
				mainscene:moveByClient(animVo.perc,animVo.moveTime)
				mainscene:runAction(CCSequence:createWithTwoActions(
					CCDelayTime:create(animVo.moveTime),
					CCCallFunc:create(function()
						progreeEnd(eventVo,animVo,eventVo.animObjTbl,container)
					end)))
			elseif animVo.type == "close" then

				local layer = GameLayerMgr:getInstance():getFreshmanTipLayer()
				layer:runAction(CCCallFunc:create(function() --延时机制
					if WindowCtrl:getInstance():getWaitWinNum() > 0 then
		                Notifier.regist(CmdName.LastWaitWinClosed,function()
		                    Notifier.removeByName(CmdName.LastWaitWinClosed)
		                   	
		                   	if animVo.where == "all" then
		                   		WindowCtrl:getInstance():closeAllWin()
		                   		progreeEnd(eventVo,animVo,eventVo.animObjTbl,container)
		                   	end
		                end)
		            else
		               	if animVo.where == "all" then
		                   	WindowCtrl:getInstance():closeAllWin()
		                   	progreeEnd(eventVo,animVo,eventVo.animObjTbl,container)
		                end
		            end
				end))
			elseif animVo.type == "open" then
				if animVo.where == "activate10002" then
					WindowCtrl:getInstance():open(CmdName.Comm_Activate,{id=10002})	
					progreeEnd(eventVo,animVo,eventVo.animObjTbl,container)
				end
			end
		end

	end
end
--选帧播放
function GuideRenderMgr:playGapFrame(armature,name,from,to,func,rep)
	print(" =========== DisplayUtil.playGapFrame ============= ",name,from,to)
	armature:setVisible(false)
	armature:getAnimation():play(name,0,-1,0)
	if from == to then
		armature:getAnimation():gotoAndPause(from)
		armature:setVisible(true)
		func()
	else
		local cout = from
		local function progress()
			armature:getAnimation():gotoAndPause(cout)
			armature:setVisible(true)
			if cout == to then
				func()
				if rep == 1 then
					cout = from
				else
					armature:stopAllActions()
				end
			end

			if from > to then
				cout = cout - 1
			else
				cout = cout + 1
			end
		end

		armature:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
			CCDelayTime:create(0.04),
			CCCallFunc:create(progress))))
	end
end

--文字动画
function GuideRenderMgr:showLabAnim(label,txt,func,interval)
	local tblStr = Helper.separate(txt)
	local strOut = ""
	local cout = 0
	local arr = CCArray:create()
	arr:addObject(CCDelayTime:create( interval or 0.06))
	arr:addObject(CCCallFunc:create(function()
		label:setTag(1)

		cout = cout + 1
		for i=1,cout do
			if tblStr[i] ~=nil then
				strOut = strOut .. tblStr[i]
			end
		end
		label:setText( strOut )
		strOut = ""
		if cout == #tblStr then
			label:stopAllActions()
			func()
			label:setTag(2)
		end
	end))

	label:runAction(CCRepeatForever:create(CCSequence:create(arr)))
	label:setTag(0) --是否正在播放动画 0初始 1播放中 2播放完
end

function GuideRenderMgr:showRtfAnim(rtf,txt,func,interval)
	
	local cout = 0
	local arr = CCArray:create()
	arr:addObject(CCDelayTime:create( interval or 0.06))
	arr:addObject(CCCallFunc:create(function()
		rtf:setTag(1)

		cout = cout + 1
		rtf:setVisibleAtIndex(cout,true)
		if cout == #rtf.labTbl then
			rtf:stopAllActions()

			func()
			rtf:setTag(2)
		end
	end))

	rtf:setAllVisible(false)
	rtf:runAction(CCRepeatForever:create(CCSequence:create(arr)))
	rtf:setTag(0) --是否正在播放动画 0初始 1播放中 2播放完
end

function GuideRenderMgr:showAllLab(animObjTbl)
	for i=1,#animObjTbl do
		local animVo = animObjTbl[i]
		if animVo.clazz == "label" then
			local label = animVo.obj
			label:stopAllActions()
			label:setText(animVo.txt)
			label:setTag(2)
		elseif animVo.clazz == "rtf" then
			local rtf = animVo.obj
			rtf:setAllVisible(true)
			rtf:setTag(2)
		end
	end
end

function GuideRenderMgr:isAllLabAnimFinish(animObjTbl)
	local ret = true
	for i=1,#animObjTbl do
		local animVo = animObjTbl[i]
		if animVo.clazz == "label" or animVo.clazz == "rtf" then
			local lab = animObjTbl[i].obj
			if lab and lab:getTag() ~= 2 then
				ret = false
			end
		end
	end
	return ret
end

--判断该字符串是否富文本
function GuideRenderMgr:isRtfTxt(txt)
	local ret = Helper.separate(txt)[1] == "{" 
	return ret
end

--检测是否播放新英雄动画
function GuideRenderMgr:checkPlayNewHeroAnim(eventVo)
	local ret = false
	local voList = eventVo.getHeroTbl
	if voList[1] ~= nil then
		require "GuideHeroAnim"
		GuideHeroAnim:show(tonumber(voList[1]))
		table.remove(voList,1)
		ret = true
	end
	return ret
end

--展示练练看动画
function GuideRenderMgr:showLineAnim(img,viewContainer,animObjTbl,func,moveTbl,interval,triggerId)
	local widget = Widget:create()
	widget:addChild(img)

	func() --立即触发 不用等播完才回调

	img:setTag(0)
	img:setPosition(moveTbl[1])
	local arr = CCArray:create()
	local lineArmatureTbl = {}
	for i=1,#moveTbl do
		arr:addObject( CCMoveTo:create( interval, moveTbl[i]) )
		arr:addObject( CCCallFunc:create(function()
			local imgCircle = ImageView:create()
			imgCircle:loadTexture("ui/guide/guide/guide_cricle.png")
			imgCircle:setPosition(moveTbl[i])
			widget:addChild(imgCircle)
			table.insert(lineArmatureTbl,imgCircle)
		end) )
		if i ~= 1 then
			arr:addObject( CCCallFunc:create(function()
				local lineArmature = ImageView:create()
				lineArmature:setAnchorPoint(ccp(0,0.5))
				lineArmature:loadTexture("ui/guide/guide/guide_line.png")
				local deg = MathUtil.getAngleWithTwoPoint(moveTbl[i-1], moveTbl[i])
				lineArmature:setRotation(MathUtil.rad2deg(deg))
				lineArmature:setPosition(moveTbl[i-1])
				widget:addChild(lineArmature)
				table.insert(lineArmatureTbl,lineArmature)
			end))
		end
	end
	arr:addObject(CCDelayTime:create(2.5))
	arr:addObject(CCCallFunc:create(function()
		for i=1,#lineArmatureTbl do
			lineArmatureTbl[i]:removeFromParentAndCleanup(true)
			lineArmatureTbl[i] = nil
		end
	end))
	arr:addObject(CCCallFunc:create(function()
		if img:getTag() == 0 then
			img:setTag(2)
		end
	end))
	img:runAction(CCRepeatForever:create(CCSequence:create(arr)))
	viewContainer:addChild(widget)

	table.insert(animObjTbl,{ type = "", isLazyDel = 1, obj = widget, triggerId = triggerId})
end
