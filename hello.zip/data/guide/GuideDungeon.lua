
--副本引导 和 剧情
GuideDungeon = class("GuideDungeon")
GuideDungeon.__index = GuideDungeon
GuideDungeon._widget     = nil
GuideDungeon.uiLayer    = nil

local __instance = nil

function GuideDungeon.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, GuideDungeon)
    return target
end

function GuideDungeon:getInstance()
    if not __instance then
        local ret = GuideDungeon.extend(DisplayUtil.newFitLayer())
        __instance = ret
        ret:init()
        ret:retain()
    end
    return __instance
end

function GuideDungeon:destoryInstance()
    self:release()
    __instance = nil
end
----------------------响应事件---------------------------------
function GuideDungeon:event_show_guide(id)

    local panel = self._widget:getChildByName("panel_main")
    local eventVo = GuideDataProxy:getInstance():getStoryEventVoById(id)

    self:show(panel,eventVo.endType)
    GuideRenderMgr:getInstance():renderEventVo(self._widget,panel,id) --渲染事件

    local eventVo = GuideDataProxy:getInstance():getStoryEventVoById(id)
    if eventVo.condTbl[1].type == "into" then
        panel:setPosition(ccp(0,0))
    end
end

function GuideDungeon:event_show_tutorial(id)

    local panel = self._widget:getChildByName("panel_main")
    local eventVo = GuideDataProxy:getInstance():getDungeonTutorialVoById(id)

    self:showTutorial(panel,eventVo.endType)
    GuideRenderMgr:getInstance():renderDungeonTutorialVo(self._widget,panel,id) --渲染事件
end

local function event_show_alert(txt)
    local child = __instance.uiLayer:getChildByTag(1005)
    if child ~= nil then
        child:removeFromParentAndCleanup(true)
    end
    --弹出提示信息
    local alert = Alert:create(txt)
    alert:setTag(1005)
    alert:setPosition(ccp(480,320))
    __instance.uiLayer:addChild(alert)
end
----------------------初始化---------------------------------
function GuideDungeon:init()

    ComResMgr:getInstance():loadOtherRes()
    local size = CCEGLView:sharedOpenGLView():getFrameSize()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("guide/GuideDungeon.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)
    
    require "GuideRenderMgr"
    GuideRenderMgr:getInstance():renderInitMask(self._widget) --初始化遮罩层

    Notifier.regist(GuideEvent.ShowDungeon,function(id) self:event_show_guide(id) end) --展示剧情
    Notifier.regist(GuideEvent.DungeonTutorial,function(id) self:event_show_tutorial(id) end) --展示副本教程
    Notifier.regist(CharacterEvent.SHOW_ERR_ALERT,event_show_alert)
end

function GuideDungeon:saftClean(viewContaniner,endType)
     if endType >= 1 then
        local tmpCleanTbl = {}
        local arr = viewContaniner:getChildren()
        for i=0,arr:count()-1 do
            local c = tolua.cast(arr:objectAtIndex(i),"Widget")
            if c:getName() == "img_clickview" or
                c:getName() == "img_clicklab" or 
                 c:getName() == "img_clicktutorial" then
                --不删除
            else
                table.insert(tmpCleanTbl,c)
            end
        end
        for i=1,#tmpCleanTbl do
            tmpCleanTbl[i]:removeFromParentAndCleanup(true)
        end
        viewContaniner:removeAllNodes()

        --------------清理缓存-------------------
        local sfc = CCSpriteFrameCache:sharedSpriteFrameCache()
        for i=10001,10024 do
           sfc:removeSpriteFramesFromFile(string.format("ui/guide/guide/guide_head_%d.plist",i))
        end
        sfc:removeSpriteFramesFromFile("ui/guide/guide/guide_img_story.plist")
        sfc:removeSpriteFramesFromFile("ui/guide/guide/guide_img_tutorial.plist")
        sfc:removeSpriteFramesFromFile("ui/guide/guide/guide_tutorial.plist")
        sfc:removeSpriteFramesFromFile("ui/guide/guide/guide_head_10001_f.plist")

        --------------清理骨骼-------------------
        local voList = GuideDataProxy:getInstance()._animatrueRemoveList
        for k,v in pairs(voList) do
            AnimateManager:getInstance():clear(k)
        end
        GuideDataProxy:getInstance()._animatrueRemoveList = {}
    end
    
end

--移除 剧情
function GuideDungeon:hide(viewContaniner,endType)
    local layer = BattleController:getInstance():getPlotLayer()
    local child = layer:getChildByTag(1142)
    if child ~= nil then
        child:stopAllActions()
        layer:removeChildByTag(1142,false)
    end

    self:saftClean(viewContaniner,endType)

    BattleController:getInstance():showMapOnly(false)
end

--移除 引导
function GuideDungeon:hideTutorial(viewContaniner,endType)
    local layer = BattleController:getInstance():getPlotLayer()
    local child = layer:getChildByTag(1142)
    if child ~= nil then
        child:stopAllActions()
        layer:removeChildByTag(1142,false)
    end

    self:saftClean(viewContaniner,endType)
end

--展示 剧情
function GuideDungeon:show(viewContaniner,endType)

	local layer = BattleController:getInstance():getPlotLayer()
    local child = layer:getChildByTag(1142)
    if child ~= nil then
        child:stopAllActions()
        layer:removeChildByTag(1142,false)
    end

    local guideScene = GuideDungeon:getInstance()
    guideScene:setTag(1142)
    layer:addChild(guideScene)

    BattleController:getInstance():showMapOnly(true)
end

--展示引导
function GuideDungeon:showTutorial(viewContaniner,endType)

    local layer = BattleController:getInstance():getPlotLayer()
    local child = layer:getChildByTag(1142)
    if child ~= nil then
        child:stopAllActions()
        layer:removeChildByTag(1142,false)
    end

    local guideScene = GuideDungeon:getInstance()
    guideScene:setTag(1142)
    layer:addChild(guideScene)

    BattleController:getInstance():showMapOnly(false)
end

---------------------------------------------------------------
GuideVipSpeedTips = class("GuideVipSpeedTips",function()
    return DisplayUtil.newFitLayer()
end)

function GuideVipSpeedTips:getInstance()
    if not __instanceVipSpeedTips then
        local ret = GuideVipSpeedTips.new()
        __instanceVipSpeedTips = ret
        ret:init()
        ret:retain()
    end
    return __instanceVipSpeedTips
end

function GuideVipSpeedTips:destoryInstance()
    self:release()
    __instanceVipSpeedTips = nil
end

function GuideVipSpeedTips:init()
    self._widget = GUIReader:shareReader():widgetFromJsonFile("guide/GuideVipSpeed.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.imgClick = tolua.cast(self._widget:getChildByName("img_click"),"ImageView")
    self.imgClick:setTouchEnabled(false)
    self.imgClick:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            GuideVipSpeedTips:hide()
        end
    end)
end

function GuideVipSpeedTips:show()
    local layer = BattleController:getInstance():getPlotLayer()
    local child = layer:getChildByTag(1342)
    if child ~= nil then
        child:stopAllActions()
        layer:removeChildByTag(1342,false)
    end

    local tips = GuideVipSpeedTips:getInstance()
    tips:setTag(1342)
    layer:addChild(tips)

    tips.imgClick:setTouchEnabled(false)
    tips:stopAllActions()
    tips:runAction(CCSequence:createWithTwoActions(
        CCDelayTime:create(2), CCCallFunc:create(function()
            tips.imgClick:setTouchEnabled(true)
        end)))
end

function GuideVipSpeedTips:hide()
    local layer = BattleController:getInstance():getPlotLayer()
    local child = layer:getChildByTag(1342)
    if child ~= nil then
        child:stopAllActions()
        layer:removeChildByTag(1342,false)
    end
end
