-- 引导变身时装英雄
GuideChangeSkinView = class("GuideChangeSkinView",function()
	return Layout:create()
end)
GuideChangeSkinView.__index = GuideChangeSkinView
GuideChangeSkinView._widget = nil

local __instance = nil

function GuideChangeSkinView:create(func,effectId,heroId)
    local ret = GuideChangeSkinView.new()
    ret:init(func,effectId,heroId)
   	__instance = ret
    return ret
end

function GuideChangeSkinView:init(func,effectId,heroId)

	self._cbFunc = func
	if effectId == 100001 then
		local sex = CharacterManager:getInstance():getBaseData():getSex()
		if sex == CharacterCfg.Female then
	        effectId = 100002
	    elseif sex == CharacterCfg.Male then
	        effectId = 100001
	    end
	end
	self._effectId = effectId
	self._heroId = heroId

	self._widget = GUIReader:shareReader():widgetFromJsonFile("guide/GuideNewSkin.ExportJson")
    self:addChild(self._widget)

    local p_1 = ccp(471,307)
    self.armHero = AnimateManager:getInstance():getArmatureFromEffectId(self._effectId)
    self.armHero:getAnimation():play("stand",-1,-1,1)
    local heroPanel = CCLayer:create()
    local heroBottomPanel = CCLayer:create()

    self.imgClick = tolua.cast(self._widget:getChildByName("panel_click"),"Layout")
    self._widget:addNode(heroBottomPanel)
    self._widget:addNode(heroPanel)
    heroPanel:setPosition(p_1)
    heroBottomPanel:setPosition(p_1)
    heroPanel:addChild(self.armHero)
    self.armHero:getAnimation():play("stand")

    local stard_act_list = HeroManager:getInstance():getHeroActListById(tonumber(self._heroId)) 
    local cur_action_idx = 0

    --英雄随即动作播放完成后
    local function playCallBack(armature, movementType, movementID)
        if movementType == AnimationMovementType.COMPLETE then 
            --播放一个动作后，移除关联特效
            if stard_act_list[cur_action_idx] and 
                stard_act_list[cur_action_idx][2] ~= nil then
                EffectManager:getInstance():removeEffect(heroPanel,stard_act_list[cur_action_idx][2], nil, 0)
            end

            if stard_act_list[cur_action_idx] and 
                stard_act_list[cur_action_idx][3] ~= nil and
                stard_act_list[cur_action_idx][3] >0 then
                    EffectManager:getInstance():removeEffect(heroBottomPanel,stard_act_list[cur_action_idx][3], nil, 0)
            end

            cur_action_idx = cur_action_idx +1
            if cur_action_idx>#stard_act_list then
                self.armHero:getAnimation():play("stand")

                self.imgClick:setTouchEnabled(true)
            else
                self.armHero:getAnimation():play(stard_act_list[cur_action_idx][1],-1,-1,0)
                if stard_act_list[cur_action_idx][2] ~= nil then
                    EffectManager:getInstance():playEffect(heroPanel,stard_act_list[cur_action_idx][2], nil, 0)
                end

                if stard_act_list[cur_action_idx][3] ~= nil and stard_act_list[cur_action_idx][3]>0 then
                    EffectManager:getInstance():playEffect(heroBottomPanel,stard_act_list[cur_action_idx][3], nil, 0)
                end
            end
        end
    end

    local function startAnim()
        cur_action_idx = 1

        self.armHero:getAnimation():setMovementEventCallFunc(playCallBack)
        self.armHero:getAnimation():play(stard_act_list[cur_action_idx][1],-1,-1,0)

        if stard_act_list[cur_action_idx][2] ~= nil then
            EffectManager:getInstance():playEffect(heroPanel,stard_act_list[cur_action_idx][2], nil, 0)
        end
    end

    startAnim() --开始播放

    self.imgClick:setTouchEnabled(false)
    self.imgClick:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then 
            self.imgClick:setTouchEnabled(false)
            startAnim()
        end
    end)


    self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then
			if self._cbFunc then
                BattleController:getInstance():transformEntity(self._heroId,self._effectId)

				self._cbFunc()
			end
		end
	end)

    --弹出首充界面
    WindowCtrl:getInstance():open(CmdName.Reward_FirstRechargeView)

end