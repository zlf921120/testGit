-- 新手引导配置
GuideCfg =
{
	High = "high",  --高于
	Low  = "low",	--低于
	Start = "start", --开始
	Running = "running", --进行中
	End = "end", --结束
	Me = "me",  --我方
	Enemy = "enemy", --敌方
}

--vip加速提示 副本
GuideSpeedTips = {
	dungeonId = 10008,
	diff = 1
}
--引导类型
GuideCondType =
{
----------播放 条件-----------------
	Into 	= 1,  	--进入
	Pass 	= 2,	--通关
	Task 	= 3,	--任务
	Kill 	= 4,	--杀死
	Hp 		= 5,	--血量
	Round	= 6,	--回合
	Fight	= 7,	--发起战斗
	Move	= 8,	--移动
	Trigger	= 9,	--回调触发
	Find	= 10,	--发现
	Skill 	= 11,	--技能
	Story	= 12,	--剧情
	Begin 	= 15,   --开始连线
	Team	= 18,   --战队升级
	Get 	= 19,	--获取
-----------结束 条件-----------------
	Normal 	= 13, 	--正常结束
	Click 	= 14,	--点击结束
	Choice  = 16,	--选择结束
	Open 	= 17,	--开启面板
}

--剧情/引导 结束类型
GuideEndType =
{
	--剧情-------
	Normal = 0,  	--普通结束
	AfterToDo = 1, 	--后置动画结束
	BeforeToDo = 2, --前置动画结束
	ForceQuite = 4, --强制结束
	--新手引导-------
	Record = 1, --记录引导id
	HeadRecord = 2, --事件前置 记录引导id
	TutorialBegin = 1, --教程开始
	TutorialEnd = 2,   --教程结束
}
--获取英雄动画 的播放区域
GuideGetHeroArea = 
{
	Battle = 0,
	Lottery = 1,
	MainScene = 2,
	HeroListView = 3,
}

--创建名字 的面板区域
GuideCreateNameArea = 
{
	MainScene = 0,
	BattleScene = 1,
}