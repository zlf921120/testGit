
----------------------------------------------------------------------------
-- 引导 本地xls数据读取类
GuideLocalReader = class("GuideLocalReader")

local __instance = nil
local _allowInstance = false
local _hasLoad = false

function GuideLocalReader:ctor()
    if not _allowInstance then
		error("GuideLocalReader is a singleton class")
	end
	self:init()
end

function GuideLocalReader:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = GuideLocalReader.new()
		_allowInstance = false
	end

	return __instance
end

function GuideLocalReader:init()
	require "GuideRenderMgr"
	require "GuideDataProxy"
	require "GuideNetTask"
	require "GuideDungeon"
	require "GuideEvent"
	require "GuideScene"
	require "GuideCfg"
	require "fnt_guide_data_pb"
	require "fnt_nickname_data_pb"
	require "EffectManager"
	require "HeroInfo"
	require "CombatGemMsg"

	GuideEventTask:getInstance()
	GuideNetTask:getInstance()
end

function GuideLocalReader:loadInProxy()
	if _hasLoad then return end--只加载一次
	_hasLoad = true
	local dp = GuideDataProxy:getInstance()
-----------------------------------------------------------
    local pbdata = FileUtils.readConfigFile("fnt_guide_data.dat")
    local msg = fnt_guide_data_pb.fnt_guide_data()
    msg:ParseFromString(pbdata)

    local function make_cond(eventVo,key) --创建条件 值对象
    	local condVo = dp:createCondVo()
    	condVo.key = key
    	condVo.params = {}
		local t = Utils.split(key,"_")
		for i=1,table.getn(t) do
			if i == 1 then
				condVo.type = t[i]
			else
				table.insert(condVo.params,t[i])
			end
		end
		return condVo
	end

	local function insert_anim(eventVo,anim_p,anim,anim_way,anim_repeat,anim_layer)
		local p = Utils.split(anim_p,",")
		local tbl = Utils.split(anim,"_")
		local wayTbl = Utils.split(anim_way,"_")
		local anim_layer = anim_layer or 0
		if tbl[1] == "res" then
			if anim_way ~= "" then
				local flipX = 1
				if wayTbl[2] == "turn" then
					flipX = -1
				end
				local obj = { path = string.format("ui/guide/%s.ExportJson",tbl[2]) , name = tbl[2] ,play = tbl[3], type = tbl[1], x = p[1], y = p[2], x2 = p[3], y2 = p[4],moveTime = p[5], mode = wayTbl[1],flip = flipX ,rep = anim_repeat,layer = anim_layer ,scale = tbl[4] or 1 }
				if wayTbl[3] == "gap" then  --播放间隔帧
					obj.from = wayTbl[4]  
					obj.to = wayTbl[5]
					obj.gap = wayTbl[3]
				end
				table.insert(eventVo.animTbl,obj)
			else
				table.insert(eventVo.animTbl,{ path = string.format("ui/guide/%s.ExportJson",tbl[2]) , name = tbl[2], play = tbl[3], type = tbl[1], x = p[1], y = p[2] , x2 = p[3], y2 = p[4],moveTime = p[5], rep = anim_repeat,layer = anim_layer})
			end
		elseif tbl[1] == "npc" or tbl[1] == "effect" then
			local effectVo = nil
			if tbl[1] == "npc" then
				local effectId = tonumber(tbl[2])
				if effectId == 100001 then
					local sex = CharacterManager:getInstance():getBaseData():getSex()
					if sex == CharacterCfg.Female then
				        effectId = 100002
				    elseif sex == CharacterCfg.Male then
				        effectId = 100001
				    end
				end
				effectVo = EffectManager:getInstance():getActionData(effectId)
			elseif tbl[1] == "effect" then
				effectVo = EffectManager:getInstance():getEffectData(tonumber(tbl[2]))
			end
			if anim_way ~= "" then
				local flipX = 1
				if wayTbl[2] == "turn" then
					flipX = -1
				end
				local obj = { path = effectVo._fileFullPathName , name = effectVo:getFileName(), play = tbl[3], type = tbl[1], x = p[1], y = p[2], x2 = p[3], y2 = p[4], moveTime = p[5], mode = wayTbl[1],flip = flipX ,rep = anim_repeat ,layer = anim_layer ,scale = tbl[4] or 1 }
				if wayTbl[3] == "gap" then  --播放间隔帧
					obj.from = wayTbl[4]  
					obj.to = wayTbl[5]
					obj.gap = wayTbl[3]
				end
				table.insert(eventVo.animTbl,obj)
			else
				table.insert(eventVo.animTbl,{ path = effectVo._fileFullPathName , name = effectVo:getFileName(), play = tbl[3], type = tbl[1], x = p[1], y = p[2] ,x2 = p[3], y2 = p[4],moveTime = p[5], rep = anim_repeat ,layer = anim_layer})
			end
		elseif tbl[1] == "story" then
			
			table.insert(eventVo.animTbl,{ path = string.format("guide_img_story.png",tbl[2]), type = tbl[1], head = tbl[2], x = p[1], y = p[2] ,layer = anim_layer})
		elseif tbl[1] == "guide" then

			table.insert(eventVo.animTbl,{ path = string.format("guide_img_tutorial.png",tbl[2]), type = tbl[1], x = p[1], y = p[2], layer = anim_layer })
		elseif tbl[1] == "img" then

			table.insert(eventVo.animTbl,{ path = string.format("ui/guide/guide/i18n_guide_%s.png",tbl[2]), type = tbl[1], x = p[1], y = p[2] })
		elseif tbl[1] == "create" then

			table.insert(eventVo.animTbl,{ path = "ui/guide/GuideCreateName.ExportJson", type = tbl[1] })
		elseif tbl[1] == "change" then

			table.insert(eventVo.animTbl,{ path = "ui/guide/GuideNewSkin.ExportJson", type = tbl[1], effectId = tonumber(tbl[3]), heroId = tonumber(tbl[4]) })
		elseif tbl[1] == "finger" then
			local moveTbl = {}
			for i=1,#p do
				if i %2 == 0 then
					table.insert(moveTbl,ccp( p[i-1],p[i] ))
				end
			end
			table.insert(eventVo.animTbl,{ path = string.format("ui/guide/guide/guide_%s.png",tbl[2]), type = tbl[1], moveTbl = moveTbl ,moveTime = p[#p], layer = anim_layer})
		elseif tbl[1] == "dark" then
			local obj = { path = string.format("ui/guide/guide/guide_img_mask.png"), type = tbl[1], scale = 50 ,x = p[1], y = p[2] , layer = anim_layer }
			if anim_way ~= "" then -- shake_normal_delay_1
				if wayTbl[1] == "shake" then
					obj.play = "shake"
					obj.delay = wayTbl[4] or 0
				end
			end
			table.insert(eventVo.animTbl,obj)
		elseif tbl[1] == "darklayer" then

			table.insert(eventVo.animTbl,{ type = tbl[1] , layer = anim_layer })
		elseif tbl[1] == "light" then

			table.insert(eventVo.animTbl,{ path = string.format("ui/guide/guide/guide_img_mask.png"), type = tbl[1], scale = 50 ,x = p[1], y = p[2] , layer = anim_layer })
		elseif tbl[1] == "close" then --特殊动作 没有资源
			
			table.insert(eventVo.animTbl,{ type = tbl[1] , where = tbl[2] })
		elseif tbl[1] == "move" then --特殊动作 没有资源

			table.insert(eventVo.animTbl,{ type = tbl[1] , perc = tbl[2], moveTime = tbl[3] })
		elseif tbl[1] == "open" then --特殊动作 没有资源
			table.insert(eventVo.animTbl,{ type = tbl[1] , where = tbl[2] })
		end
		if #p >= 3 then  --如果有位移 也要 递增进度总数(因为要等到移动完才算结束事件)
			eventVo.total = eventVo.total + 1
		end
		eventVo.total = eventVo.total + 1 --统计进度
	end

	local function make_ainm_delay(animVo,anim_delay)
		animVo.delayWay = Utils.split(anim_delay,"_")
	end

	local function insert_lab(eventVo,lab)
		if lab == nil then return end
		eventVo.labTbl = Utils.split(lab,"_")
		eventVo.total = eventVo.total + 1
	end

	local function insert_get_hero(eventVo,getHero)
		if getHero ~= "" then
			eventVo.getHeroTbl = Utils.split(getHero,",")
		else
			eventVo.getHeroTbl = {}
		end
	end
-------------------------------------------------------------------------------
	local storyDungeonReplayTbl = {}
    local storyDungeonUnit = msg.guide_dungeon_rows
    for k,v in ipairs(storyDungeonUnit) do
    	if v.id ~= nil then
    		local eventVo = dp:createEventVo()
    		eventVo.id = v.id --事件id
    		eventVo.animTbl = {} --创建动画容器

	    	if v.cond1 ~= "" then  --条件1
	    		eventVo.condTbl = {}
	    		table.insert(eventVo.condTbl,make_cond(eventVo,v.cond1))
	    	end
	    	if v.cond2 ~= "" then  --条件2
	    		table.insert(eventVo.condTbl,make_cond(eventVo,v.cond2))
	    	end
	    	eventVo.islock = v.islock
	    	if v.islock == 1 then --是否锁屏
	    		local tbl = Utils.split(v.area_click,",")
	    		eventVo.p1 = ccp(tbl[1],tbl[2])
	    		eventVo.p2 = ccp(tbl[3],tbl[4])
	    	end
	    	
	    	if v.anim1 and v.anim1 ~= "" and v.anim1_p ~= "" then --动画1
	    		insert_anim(eventVo,v.anim1_p,v.anim1,v.anim1_way,v.anim1_repeat,v.anim1_layer)
	    		if v.anim1_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim1_delay)
		    	end
	    	end

	    	if v.anim2 and v.anim2 ~= "" and v.anim2_p ~= "" then --动画2
	    		insert_anim(eventVo,v.anim2_p,v.anim2,v.anim2_way,v.anim2_repeat,v.anim2_layer)
	    		if v.anim2_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim2_delay)
		    	end
	    	end

	    	if v.anim3 and v.anim3 ~= "" and v.anim3_p ~= "" then --动画3
	    		insert_anim(eventVo,v.anim3_p,v.anim3,v.anim3_way,v.anim3_repeat,v.anim3_layer)
	    		if v.anim3_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim3_delay)
		    	end
	    	end

	    	if v.anim4 and v.anim4 ~= "" and v.anim4_p ~= "" then --动画4
	    		insert_anim(eventVo,v.anim4_p,v.anim4,v.anim4_way,v.anim4_repeat,v.anim4_layer)
	    		if v.anim4_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim4_delay)
		    	end
	    	end

	    	if v.anim5 and v.anim5 ~= "" and v.anim5_p ~= "" then --动画5
	    		insert_anim(eventVo,v.anim5_p,v.anim5,v.anim5_way,v.anim5_repeat,v.anim5_layer)
	    		if v.anim5_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim5_delay)
		    	end
	    	end

	    	if v.anim6 and v.anim6 ~= "" and v.anim6_p ~= "" then --动画6
	    		insert_anim(eventVo,v.anim6_p,v.anim6,v.anim6_way,v.anim6_repeat,v.anim6_layer)
	    		if v.anim6_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim6_delay)
		    	end
	    	end

	    	if v.anim7 and v.anim7 ~= "" and v.anim7_p ~= "" then --动画7
	    		insert_anim(eventVo,v.anim7_p,v.anim7,v.anim7_way,v.anim7_repeat,v.anim7_layer)
	    		if v.anim7_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim7_delay)
		    	end
	    	end

	    	if v.anim8 and v.anim8 ~= "" and v.anim8_p ~= "" then --动画8
	    		insert_anim(eventVo,v.anim8_p,v.anim8,v.anim8_way,v.anim8_repeat,v.anim8_layer)
	    		if v.anim8_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim8_delay)
		    	end
	    	end

	    	if v.anim9 and v.anim9 ~= "" and v.anim9_p ~= "" then --动画9
	    		insert_anim(eventVo,v.anim9_p,v.anim9,v.anim9_way,v.anim9_repeat,v.anim9_layer)
	    		if v.anim9_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim9_delay)
		    	end
	    	end

	    	if v.anim10 and v.anim10 ~= "" and v.anim10_p ~= "" then --动画10
	    		insert_anim(eventVo,v.anim10_p,v.anim10,v.anim10_way,v.anim10_repeat,v.anim10_layer)
	    		if v.anim10_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim10_delay)
		    	end
	    	end

	    	if v.anim11 and v.anim11 ~= "" and v.anim11_p ~= "" then --动画11
	    		insert_anim(eventVo,v.anim11_p,v.anim11,v.anim11_way,v.anim11_repeat,v.anim11_layer)
	    		if v.anim11_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim11_delay)
		    	end
	    	end

	    	if v.anim12 and v.anim12 ~= "" and v.anim12_p ~= "" then --动画12
	    		insert_anim(eventVo,v.anim12_p,v.anim12,v.anim12_way,v.anim12_repeat,v.anim12_layer)
	    		if v.anim12_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim12_delay)
		    	end
	    	end

	    	if v.lab1 and v.lab1 ~= "" then  --文本1
	    		insert_lab(eventVo,v.lab1)
	    	end

	    	if v.lab2 and v.lab2 ~= "" then  --文本2
	    		insert_lab(eventVo,v.lab2)
	    	end

	    	if v.lab3 and v.lab3 ~= "" then  --文本3
	    		insert_lab(eventVo,v.lab3)
	    	end

	    	if v.lab4 and v.lab4 ~= "" then  --文本4
	    		insert_lab(eventVo,v.lab4)
	    	end

	    	if v.lab5 and v.lab5 ~= "" then  --文本5
	    		insert_lab(eventVo,v.lab5)
	    	end

	    	if v.lab6 and v.lab6 ~= "" then  --文本6
	    		insert_lab(eventVo,v.lab6)
	    	end

	    	-- if v.lab7 and v.lab7 ~= "" then  --文本7
	    	-- 	insert_lab(eventVo,v.lab7)
	    	-- end

	    	-- if v.lab8 and v.lab8 ~= "" then  --文本8
	    	-- 	insert_lab(eventVo,v.lab2)
	    	-- end

	    	-- if v.lab9 and v.lab9 ~= "" then  --文本9
	    	-- 	insert_lab(eventVo,v.lab9)
	    	-- end

	    	-- if v.lab10 and v.lab10 ~= "" then  --文本10
	    	-- 	insert_lab(eventVo,v.lab10)
	    	-- end

	    	-- if v.lab11 and v.lab11 ~= "" then  --文本11
	    	-- 	insert_lab(eventVo,v.lab11)
	    	-- end

	    	-- if v.lab12 and v.lab12 ~= "" then  --文本12
	    	-- 	insert_lab(eventVo,v.lab12)
	    	-- end

	    	if v.screen ~= "" then --镜头移动
	    		eventVo.screenAct = Utils.split(v.screen,",")
	    		eventVo.total = eventVo.total + 1
	    	end

	    	insert_get_hero(eventVo,v.get_hero)

	    	eventVo.isOffset = v.is_offset or 0
	    	eventVo.isCanPass = v.is_can_pass
	    	eventVo.endType = v.endType  --结束类型
	    	eventVo.endCond = make_cond(eventVo,v.cond_end) --结束条件
	    	if v.is_replay > 0 then
	    		table.insert(storyDungeonReplayTbl,eventVo.id)
	    	end
	    	dp:setStoryEventVo(eventVo)
    	end
    end

    local function make_replay_gap(gap1,gap2)
    	local replayTbl = {}
    	local replayEvtVo = nil
    	for id,eventVo in pairs(dp:getStoryEventVoList()) do
    		if id >= gap1 and id < gap2 then
    			eventVo.isSkipRecord = 1
    			eventVo.replayEndId = gap2
    		end
    		if id >= gap1 or id <= gap2 then
    			table.insert(replayTbl,id)
    		end
    		if gap2 == id then
    			eventVo.isRecord = 1
    			eventVo.replayBeginId = gap1
    			replayEvtVo = eventVo
    		end
    	end
    	replayEvtVo.replayTbl = replayTbl
    end
    while #storyDungeonReplayTbl > 0 do
    	local gap1 = storyDungeonReplayTbl[1]
    	local gap2 = storyDungeonReplayTbl[2]
    	make_replay_gap(gap1,gap2)
    	table.remove(storyDungeonReplayTbl,1)
    	table.remove(storyDungeonReplayTbl,1)
    end
-----------------------------------------------------------------------------------------
---- 副本引导
    local tutorialDungeonUnit = msg.tutorial_dungeon_rows
	for k,v in pairs(tutorialDungeonUnit) do
	  	if v.id ~= nil then
    		local eventVo = dp:createEventVo()
    		eventVo.id = v.id --事件id
    		eventVo.animTbl = {} --创建动画容器

    		if v.cond1 ~= "" then  --条件1
	    		eventVo.condTbl = {}
	    		table.insert(eventVo.condTbl,make_cond(eventVo,v.cond1))
	    	end
	    	if v.cond2 ~= "" then  --条件2
	    		table.insert(eventVo.condTbl,make_cond(eventVo,v.cond2))
	    	end
	    	eventVo.islock = v.islock
	    	if v.islock == 1 then --是否锁屏
	    		local tbl = Utils.split(v.area_click,",")
	    		eventVo.p1 = ccp(tbl[1],tbl[2])
	    		eventVo.p2 = ccp(tbl[3],tbl[4])
	    	end
	    	
	    	if v.anim1 ~= "" and v.anim1_p ~= "" then --动画1
	    		insert_anim(eventVo,v.anim1_p,v.anim1,v.anim1_way,v.anim1_repeat,v.anim1_layer)
	    		if v.anim1_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim1_delay)
		    	end
	    	end

	    	if v.anim2 ~= "" and v.anim2_p ~= "" then --动画2
	    		insert_anim(eventVo,v.anim2_p,v.anim2,v.anim2_way,v.anim2_repeat,v.anim2_layer)
	    		if v.anim2_delay ~= "" then
	    			local animVo = eventVo.animTbl[#eventVo.animTbl]
		    		make_ainm_delay(animVo,v.anim2_delay)
		    	end
	    	end

	    	if v.lab1 ~= "" then  --文本1
	    		insert_lab(eventVo,v.lab1)
	    	end
	    	eventVo.endType = v.endType  --结束类型
	    	eventVo.endCond = make_cond(eventVo,v.cond_end) --结束条件
	    	dp:setDungeonTutorialEventVo(eventVo)
    	end
	end
----------------------------------------------------------------------------------------------
-- 主场景 新手引导
	local tutorialMainUnit = msg.guide_normal_rows
	for k,v in pairs(tutorialMainUnit) do
	  	if v.id ~= nil then
	  		local eventVo = dp:createEventVo()
	  		eventVo.id = v.id 
	  		eventVo.groupId = v.group
	  		eventVo.groupType = v.step_type
	  		eventVo.animTbl = {} --创建动画容器
	  		if v.cond1 ~= "" then  --条件1
	    		eventVo.condTbl = {}
	    		table.insert(eventVo.condTbl,make_cond(eventVo,v.cond1))
	    	end
	    	if v.cond2 ~= "" then  --条件2
	    		table.insert(eventVo.condTbl,make_cond(eventVo,v.cond2))
	    	end
	    	if v.cond3 ~= "" then  --条件3
	    		table.insert(eventVo.condTbl,make_cond(eventVo,v.cond3))
	    	end
	    	if v.conds ~= "" then --其他条件
	    		table.insert(eventVo.condTbl,make_cond(eventVo,v.conds))
	    	end
	    	eventVo.islock = v.islock
	    	if v.islock == 1 then --是否锁屏
	    		local tbl = Utils.split(v.area_click,",")
	    		eventVo.p1 = ccp(tbl[1],tbl[2])
	    		eventVo.p2 = ccp(tbl[3],tbl[4])
	    	end
	    	
	    	if v.anim1 ~= "" and v.anim1_p ~= "" then --动画1
	    		insert_anim(eventVo,v.anim1_p,v.anim1,v.anim1_way,v.anim1_repeat,v.anim1_layer)
	    		local animVo = eventVo.animTbl[#eventVo.animTbl]
	    		animVo.target = v.target1
	    		if v.anim1_delay ~= "" then
		    		make_ainm_delay(animVo,v.anim1_delay)
		    	end
	    	end
	    	if v.anim2 ~= "" and v.anim2_p ~= "" then --动画2
	    		insert_anim(eventVo,v.anim2_p,v.anim2,v.anim2_way,v.anim2_repeat,v.anim2_layer)
	    		local animVo = eventVo.animTbl[#eventVo.animTbl]
	    		animVo.target = v.target2
	    		if v.anim2_delay ~= "" then
		    		make_ainm_delay(animVo,v.anim2_delay)
		    	end
	    	end
	    	if v.anim3 ~= "" and v.anim3_p ~= "" then --动画3
	    		insert_anim(eventVo,v.anim3_p,v.anim3,v.anim3_way,v.anim3_repeat,v.anim3_layer)
	    		local animVo = eventVo.animTbl[#eventVo.animTbl]
	    		animVo.target = v.target3
	    		if v.anim3_delay ~= "" then
		    		make_ainm_delay(animVo,v.anim3_delay)
		    	end
	    	end

	    	if v.lab1 ~= "" then  --文本1
	    		insert_lab(eventVo,v.lab1)
	    	end

	    	if v.lab2 ~= "" then  --文本2
	    		insert_lab(eventVo,v.lab2)
	    	end

	    	if v.lab3 ~= "" then  --文本3
	    		insert_lab(eventVo,v.lab3)
	    	end

	    	if v.screen ~= "" then --镜头移动
	    		eventVo.screenAct = Utils.split(v.screen,",")
	    		eventVo.total = eventVo.total + 1
	    	end
	    	local groupVo = dp:getMainGroupVoById(eventVo.groupId)
	    	if eventVo.groupType == 1 then
	    		groupVo.beginId = eventVo.id
	    	end
	    	table.insert(groupVo.memberTbl,eventVo.id)

	    	eventVo.isRecord = v.is_request
	    	eventVo.endType = v.endType  --结束类型
	    	eventVo.endCond = make_cond(eventVo,v.cond_end) --结束条件
	    	dp:setMainTutorialEventVo(eventVo)
	  	end
	end


----------------------------------------------------------------------------------------------
    --剧情英雄
	local heros = msg.guide_hero_rows

	local hero_one_data

	for k,v in pairs(heros) do

		if v.base_id then

			hero_one_data = HeroInfo.new()
            hero_one_data:setBaseData(
            	v.base_id, 
            	v.animat_res_id, 
            	v.icon_res_id, 
            	v.img_res_id, 
                v.name, 
                v.pos, 
                v.lev, 
                v.stars, 
                v.race, 
                v.atk_type, 
                v.desc, 
                v.soul_gem_id
            )
            hero_one_data:setExtData(
            	v.base_id, 
            	v.lev, 
            	v.stars, 
            	0, 
            	nil
            )
            hero_one_data.hurt_audio_id = v.hurt_audio_id
            hero_one_data:setDefaultSkill(
            	v.act_skill1, 
            	v.act_skill2, 
            	v.act_skill3, 
            	v.pas_skill1, 
            	v.pas_skill2, 
            	v.pas_skill3
            )

            one_attr_data = HeroBaseAttr:create()
            one_attr_data:setData(AttrHelper.attr_flag.hp,v.hp_max)
            one_attr_data:setData(AttrHelper.attr_flag.hp_cur,v.hp_max)
            one_attr_data:setData(AttrHelper.attr_flag.atk,v.atk)
            one_attr_data:setData(AttrHelper.attr_flag.pdef,v.pdef)
            one_attr_data:setData(AttrHelper.attr_flag.crit,v.crit)
            one_attr_data:setData(AttrHelper.attr_flag.block,v.block)
            one_attr_data:setData(AttrHelper.attr_flag.def_break,v.def_break)
            one_attr_data:setData(AttrHelper.attr_flag.evasion,v.evasion)
            one_attr_data:setData(AttrHelper.attr_flag.atk_speed,v.atk_speed)

            one_attr_data:setData(AttrHelper.attr_flag.fight_back,v.fight_back)
            one_attr_data:setData(AttrHelper.attr_flag.reduce_harm,v.reduce_harm)
            one_attr_data:setData(AttrHelper.attr_flag.real_harm,v.real_harm)
            one_attr_data:setData(AttrHelper.attr_flag.anti_stun,v.anti_stun)
            one_attr_data:setData(AttrHelper.attr_flag.anti_silent,v.anti_silent)
            one_attr_data:setData(AttrHelper.attr_flag.anti_chaos,v.anti_chaos)
            one_attr_data:setData(AttrHelper.attr_flag.anti_stone,v.anti_stone)
            one_attr_data:setData(AttrHelper.attr_flag.anti_polymorph,v.anti_polymorph)
            one_attr_data:setData(AttrHelper.attr_flag.anti_taunt,v.anti_taunt)
            one_attr_data:setData(AttrHelper.attr_flag.anti_sleep,v.anti_sleep)

            one_attr_data:setData(AttrHelper.attr_flag.tought,v.tought)
            one_attr_data:setData(AttrHelper.attr_flag.break_atk,v.break_atk)
            one_attr_data:setData(AttrHelper.attr_flag.suck_blood,v.suck_blood)
            one_attr_data:setData(AttrHelper.attr_flag.stare,v.stare)

            hero_one_data.attrs = {}
            for k, v in pairs(one_attr_data:getAttrs()) do
            	hero_one_data.attrs[AttrHelper:getAttrStrFlag(k)] = v
            end

            dp:addHero(hero_one_data, v.battle_pos)
		end

	end

-----------------------------------------
    --消除珠子
    local stones = msg.guide_stone_rows

    local index = 0
    local waitIndex = 0

    local waitNum = 0

    local gemMsg

    for k, v in pairs(stones) do
    	if v.gem_type then

    		index = index + 1

    		if index <= 10 then
	    		gemMsg = CombatGemMsg:create(index, v.gem_type)
    			dp:addClearGem(gemMsg, true)
    		else

    			waitIndex = waitIndex + 1
    			gemMsg = CombatGemMsg:create(waitIndex, v.gem_type)
    			dp:addClearGem(gemMsg, false)
    			waitNum = waitNum + 1

    			if waitNum >= 3 then
    				dp:addWaitNum(waitNum)
    				waitNum = 0
    			end
    		end
    	end
    end

    if waitNum > 0 then
    	dp:addWaitNum(waitNum)
    end

-----------------------------------------------------------------------------
--加速提示副本
	local dungeon_tips = msg.dungeon_tips_rows
	for k,v in pairs(dungeon_tips) do
		if v.speed_tips ~= nil then
			local tbl = Utils.split(v.speed_tips,"_")
			GuideSpeedTips.dungeonId = tonumber(tbl[2])
			GuideSpeedTips.diff = tonumber(tbl[3])
		end
	end
-------------------------------------------------------------------------------
--玩家名称
	if CharacterManager:getInstance():getBaseData():getHasCreateName() == 0 then --未改名
		local pbdata = FileUtils.readConfigFile("fnt_nickname_data.dat")
	    local msg = fnt_nickname_data_pb.fnt_nickname_data()
	    msg:ParseFromString(pbdata)

	    local nicknameUnit = msg.random_name_rows
	    for k,v in pairs(nicknameUnit) do
	    	if v.male_pre ~= nil and v.male_pre ~= "" then --男
	    		table.insert(dp.nicknameTbl1,v.male_pre)
	    	end
	    	if v.male_suf ~= nil and v.male_suf ~= "" then
	    		table.insert(dp.nicknameTbl2,v.male_suf)
	    	end
	    	if v.female_pre ~= nil and v.female_pre ~= "" then --女
	    		table.insert(dp.nicknameTbl3,v.female_pre)
	    	end
	    	if v.female_suf ~= nil and v.female_suf ~= "" then
	    		table.insert(dp.nicknameTbl4,v.female_suf)
	    	end
	    end
	end
-----------------------------------------------------------------------------------
	dp:setMainBeenDoneList( CharacterManager:getInstance():getBaseData():getGuideList() )
	dp:setStoryBeenDoneList( CharacterManager:getInstance():getBaseData():getPlotList() )
end