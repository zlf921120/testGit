--引导 事件 值对象
GuideEventVo = class("GuideEventVo")
GuideEventVo.id = 0
GuideEventVo.p1 = nil  --坐标1
GuideEventVo.p2 = nil  --坐标2 (构成一个范围)
GuideEventVo.screenAct = nil --镜头移动
GuideEventVo.hasExecute = 0 --是否已执行(开始时候 标记)
GuideEventVo.hasDispatchEvent = 0 --是否已经广播过事件
GuideEventVo.hasRecord = 0 --服务端是否已记录
GuideEventVo.condTbl = nil --触发条件 满足所有条件才会触发该事件
GuideEventVo.endCond = nil --结束条件
GuideEventVo.animTbl = nil --动画列表
GuideEventVo.labTbl  = nil --文本列表
GuideEventVo.cout = 0     --事件进度数
GuideEventVo.total = 0    --事件总进度	
GuideEventVo.endType = 0 --结束类型
GuideEventVo.getHeroTbl = nil --获得英雄列表
GuideEventVo.isCanPass = 0 --是否能跳过
GuideEventVo.isRecord = 0 --是否请求记录
GuideEventVo.replayBeginId = 0 --剧情重播段的 第一帧id
GuideEventVo.isSkipRecord = 0 --是否跳过请求记录
GuideEventVo.replayTbl = nil --剧情重播的列表
GuideEventVo.groupType = 0 --在组内的类型 
GuideEventVo.container = nil --新手引导 动画 作用容器名
GuideEventVo.anims = "" --其他动画行为(但不是真实存在资源，比如关掉面板)
GuideEventVo.hasEndExecute = 0 --是否已执行(结束时候 标记)

function GuideEventVo:isCanLaunch() --是否能触发事件
	local ret = true
	for i=1,#self.condTbl do
		if self.condTbl[i].isDone == 0 then --没满足这条件
			ret = false
			break
		end
	end
	return ret
end

function GuideEventVo:clearCondDone()
	for i=1,#self.condTbl do
		self.condTbl[i].isDone = 0
	end
end

--触发条件 值对象
GuideCondVo = class("GuideCondVo")
GuideCondVo.key = ""   --条件完整名称
GuideCondVo.type = 0   --条件类型
GuideCondVo.params = nil --条件参数(坐标,npcId等等)
GuideCondVo.isDone = 0 --是否满足这条件  --[动态]
GuideCondVo.status = 0 --条件状态(开始,进行中,完成) 非动态

--新手引导组对象
GuideGroupVo = class("GuideGroupVo")
GuideGroupVo.id = 0 --组号
GuideGroupVo.beginId = 0 --开始步骤事件的id
GuideGroupVo.memberTbl = nil --组内成员id (eventId)