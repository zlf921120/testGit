
--新手引导事件
GuideEvent =
{
	Dungeon = "guide_dungeon",	--副本 引导
	Common = "guide_common",	--普通 引导
	Main = "guide_main", --主界面 引导

	DungeonTutorial = "guide_dungeon_tutorial", --副本教程 
	ShowDungeon = "guide_show_dungeon", --展示副本 引导
	ShowCommon = "guide_show_common",   --展示通用 引导
	ShowGuide = "guide_show_main", --展示主界面 教程
	ShowGuideTip = "guide_show_maintip", --展示主界面 提示
	ShowStepAnim = "guide_show_step_anim", --展示主界面 步骤动画

	InitDungeon = "guide_dungeon_init", --初始化 副本引导事件
	InitMain = "guide_main_init", --初始化 主界面引导事件

	ShowResuleView = "guide_show_resule_view", --展示结算面板

	LineFinish = "guide_dungeon_line_finish", --连线完成
	ClickFinish = "guide_dungeon_click_finish",--点击事件完成
	StepFinish = "guide_main_step_finish", --步骤完成

	PerStoryComplete = "guide_dungeon_perStoryComplete", --前置动画结束

	Force = "guide_force" , --强制事件
}

