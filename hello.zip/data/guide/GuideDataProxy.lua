
--新手引导  数据代理
GuideDataProxy = class("GuideDataProxy")
GuideDataProxy.voStoryEventList = {} --剧情事件
GuideDataProxy.voDungeonTutorialEventList = {} --副本教程 事件
GuideDataProxy.voMainTutorialEventList = {} --主界面教程 事件
GuideDataProxy.voMainGroupList = {} --主界面教程 组列表
GuideDataProxy.voLazyRemoveList = {}  --剧情延时清理
GuideDataProxy.voDungeonTutorialLazyRemoveList = {} --副本教程 延时清理
GuideDataProxy.voMainTutorialLazyRemoveList = {} --主界面教程 延时清理 
GuideDataProxy.voMainTutorialTipLazyRemoveList = {}  --主界面教程 提示 延时清理 
GuideDataProxy.nowEventId = 0 --当前剧情 事件id
GuideDataProxy.nowMainTutroialEventId = 0 --当前主界面教程 事件id
GuideDataProxy.showGetHeroArea = -1 --展示获得英雄动画区域
GuideDataProxy.showCreateNameArea = -1 --展示创建名称区域
--------------------------------------------------
GuideDataProxy.nicknameTbl1 = {} --昵称1组
GuideDataProxy.nicknameTbl2 = {} --昵称2组
GuideDataProxy.nicknameTbl3 = {} --昵称3组
GuideDataProxy.nicknameTbl4 = {} --昵称4组

GuideDataProxy._heroes = {}  --剧情英雄数据
GuideDataProxy._initGemList = {}   --初始化的石头
GuideDataProxy._waitGemList = {}   --等待中的石头
GuideDataProxy._waitGemNumList = {} --等待中的数量列表
----------------------------------------------------
GuideDataProxy._animatrueRemoveList = {}  --记录骨骼动画曾加载的资源

local __instance = nil
local _allowInstance = false

function GuideDataProxy:ctor()
    if not _allowInstance then
		error("GuideDataProxy is a singleton class")
	end
	self:init()
end

function GuideDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = GuideDataProxy.new()
		_allowInstance = false
	end

	return __instance
end

function GuideDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function GuideDataProxy:init()

	require "GuideVo"
end

function GuideDataProxy:createEventVo()
	return GuideEventVo.new()
end

function GuideDataProxy:setStoryEventVo(vo)
	self.voStoryEventList[ vo.id ] = vo
end

function GuideDataProxy:getStoryEventVoById(id)
	return self.voStoryEventList[ id ]
end

function GuideDataProxy:getStoryEventVoList()
	return self.voStoryEventList
end
----------------------------------------------------
function GuideDataProxy:setDungeonTutorialEventVo(vo)
	self.voDungeonTutorialEventList[ vo.id ] = vo
end

function GuideDataProxy:getDungeonTutorialVoById(id)
	return self.voDungeonTutorialEventList[ id ]
end

function GuideDataProxy:getDungeonTutorialVoList()
	return self.voDungeonTutorialEventList
end
-------------------------------------------------
function GuideDataProxy:setMainTutorialEventVo(vo)
	self.voMainTutorialEventList[ vo.id ] = vo
end

function GuideDataProxy:getMainTutorialVoById(id)
	return self.voMainTutorialEventList[ id ]
end

function GuideDataProxy:getMainTutorialVoList()
	return self.voMainTutorialEventList
end

function GuideDataProxy:getMainTutorialVoArr()
	local ret = {}
	for k,v in pairs(self.voMainTutorialEventList) do
		table.insert(ret,v)
	end
	table.sort( ret, function(a,b) return a.id < b.id end )
	return ret
end
-------------------------------------------------
function GuideDataProxy:createCondVo()
	return GuideCondVo.new()
end

function GuideDataProxy:createMainGroupVo()
	return GuideGroupVo.new()
end

function GuideDataProxy:getMainGroupVoById(id)
	local ret = self.voMainGroupList[id]
	if ret == nil then
		local groupVo = self:createMainGroupVo()
		groupVo.id = id
		groupVo.memberTbl = {}
		self.voMainGroupList[id] = groupVo
		ret = groupVo
	end
	return ret
end

--获取现在进行中的新手引导组号
function GuideDataProxy:getNowGroupId()
	local eventVo = self:getMainTutorialVoById(self.nowMainTutroialEventId)
	if eventVo then
		return eventVo.groupId
	else
		return nil
	end
end

function GuideDataProxy:setMainBeenDoneList(list)
	for i=1,#list do
		print(" 已經完成的新手引導步驟: ",list[i].guide_id)
		local v = self.voMainTutorialEventList[ list[i].guide_id ]
		if v then
			v.hasExecute = 1
			v.hasDispatchEvent = 1
			v.hasRecord = 1
			-- if Global:getStringForKey(string.format("guideMainStart%s%d", Global:getStringForKey("username"),v.id)) == nil then
			-- 	Global:setStringForKey(string.format("guideMainStart%s%d", Global:getStringForKey("username"),v.id),"done")
			-- end
			self:setGuideEventForceFinish(v)
		end
	end
end

function GuideDataProxy:setStoryBeenDoneList(list)
	for i=1,#list do
		print(" 已經播放過的劇情: ",list[i].guide_id)
		local v = self.voStoryEventList[ list[i].guide_id ]
		if v ~= nil then
			v.hasExecute = 1
		end
		local v2 = self.voDungeonTutorialEventList[ list[i].guide_id ]
		if v2 ~= nil then
			v2.hasExecute = 1
			v2.hasEndExecute = 1
		end
	end
end

--在面板[打开]时候检测是否 有新手引导事件动画需要显示
function GuideDataProxy:checkGuideLazyShowAnim(tbl)
	local eventVo = self:getMainTutorialVoById(self.nowMainTutroialEventId) --当前正在执行的教程步骤
	if eventVo == nil then return end
	for i=1,#eventVo.animTbl do
		for j=1,#tbl do
			if tbl[j].target == eventVo.animTbl[i].target then
				GuideRenderMgr:getInstance():renderMainFlag(tbl[j].container,eventVo.id,tbl[j].target)
			end
		end
	end
end

--设置该引导组全部完成所有步骤
function GuideDataProxy:setGuideEventForceFinish(eventVo)
	local groupVo = self:getMainGroupVoById( eventVo.groupId )
	for i=1,#groupVo.memberTbl do
	 	local id = groupVo.memberTbl[i]
	 	local v = self:getMainTutorialVoById(id)
	 	v.hasExecute = 1
	 	v.hasDispatchEvent = 1
	 -- 	if Global:getStringForKey(string.format("guideMainStart%s%d", Global:getStringForKey("username"),v.id)) == nil then
		-- 	Global:setStringForKey(string.format("guideMainStart%s%d", Global:getStringForKey("username"),v.id),"done")
		-- end
		v.animTbl = {} --清空引导动画
	end
end
---------------------------------------------------------
function GuideDataProxy:cleanDungeonTutorialCond()
	for k,v in pairs(self.voDungeonTutorialEventList) do
		if v.hasExecute == 0 then
			v:clearCondDone()
		end
	end
end

function GuideDataProxy:cleanDungeonStoryCond()
	for k,v in pairs(self.voStoryEventList) do
		if v.hasExecute == 0 then
			v:clearCondDone()
		end
	end
end

function GuideDataProxy:cleanMainTutorialCond()
	for k,v in pairs(self.voMainTutorialLazyRemoveList) do
		if v.hasExecute == 0 then
			v:clearCondDone()
		end
	end
end

--(用最近已完成的新手引导教程id) 返回指向下一个条进度的教程id
function GuideDataProxy:getNearMainTutorialId()
	local ret = nil
	local tmpTbl = {}
	for k,v in pairs(self.voMainTutorialEventList) do
		if v.hasExecute == 1 then
			table.insert(tmpTbl,v.id)
		end
	end
	if #tmpTbl ~= 0 then 
		for i=10001,12000 do
			local cache = Global:getStringForKey(string.format("guideMainStart%s%d", Global:getStringForKey("username"),i))
			if cache ~= nil then
				table.insert(tmpTbl,i)
			end
		end
		table.sort(tmpTbl,function(a,b) --排序
				return a > b
		end)
		local groupVo = self:getMainGroupVoById( self:getMainTutorialVoById( tmpTbl[1] ).groupId)
		self:delMainLocalCacheById(groupVo.id)
		ret = groupVo.beginId

		
		-- local eventVo = self:getMainTutorialVoById(tmpTbl[1])
		-- if eventVo.isRecord == 1 then
		-- 	local nextGroup = self:getMainGroupVoById( eventVo.groupId + 1 )
		-- 	if nextGroup ~= nil then
		-- 		ret = nextGroup.beginId
		-- 	end
		-- else
		-- 	ret = tmpTbl[1] -- 最大
		-- end
	end
	return ret
end

--清理本地新手教程缓存
function GuideDataProxy:delMainLocalCacheById(id)

	local eventVo = self:getMainTutorialVoById(id)
	local groupVo = self:getMainGroupVoById( eventVo.groupId )
	-- for i=1,#groupVo.memberTbl do
	-- 	Global:setStringForKey(string.format("guideMainStart%s%d", Global:getStringForKey("username"),groupVo.memberTbl[i]),nil)
	-- end
end

----------------------------------------------------------
function GuideDataProxy:getRandomName()
	local ret = ""
	local bd = CharacterManager:getInstance():getBaseData()
	if bd:getSex() == CharacterCfg.Male then
		ret = (self.nicknameTbl1[ math.random(1,#self.nicknameTbl1) ] or "") .. (self.nicknameTbl2[ math.random(1,#self.nicknameTbl2) ] or "")
	else
		ret = (self.nicknameTbl3[ math.random(1,#self.nicknameTbl3) ] or "") .. (self.nicknameTbl4[ math.random(1,#self.nicknameTbl4) ] or "")
	end
	return ret
end
----------------------------------------------------------
--是否有后置剧情
function GuideDataProxy:isHasPosStoryDungeon(dungeonId,diff)
	local ret = nil
	for k,eventVo in pairs(self:getStoryEventVoList()) do
		for k1,condVo in pairs(eventVo.condTbl) do
		 	if condVo.type == "pass" and tonumber(condVo.params[2]) == dungeonId and tonumber(condVo.params[3]) == diff and
		 		#eventVo.condTbl == 1 and eventVo.hasExecute == 0 then
		 		ret = eventVo.id
		 		break
		 	end
		end 
	end
	-- print(" 是否有後置劇情 ",ret)
	return ret
end

--是否有前置剧情
function GuideDataProxy:isHasPerStoryDungeon(dungeonId,diff)
	local ret = nil
	for k,eventVo in pairs(self:getStoryEventVoList()) do
		for k1,condVo in pairs(eventVo.condTbl) do
			if condVo.type == "into" and tonumber(condVo.params[2]) == dungeonId and tonumber(condVo.params[3]) == diff and
		 		#eventVo.condTbl == 1 then
		 	end

		 	if condVo.type == "into" and tonumber(condVo.params[2]) == dungeonId and tonumber(condVo.params[3]) == diff and
		 		#eventVo.condTbl == 1 and eventVo.hasExecute == 0 then
		 		-- and Global:getStringForKey(string.format("guideDungeonStart%s%d", Global:getStringForKey("username"),eventVo.id)) == nil then --有前置剧情 且马上播放
		 		ret = eventVo.id
		 		break
		 	end
		end 
	end
	return ret
end

--是否有前置教程
function GuideDataProxy:isHasPerTutorialDungeon(dungeonId,diff)
	local ret = false
	for k,tutorialVo in pairs(self:getDungeonTutorialVoList()) do
		for k1,condVo in pairs(tutorialVo.condTbl) do
			if condVo.type == "begin" and tonumber(condVo.params[2]) == dungeonId and tonumber(condVo.params[3]) == diff then
		 		ret = true
		 		break
		 	end
		end
	end
	return ret
end

--是否由剧情控制石头状态
function GuideDataProxy:isControlStoneByTutorial(dungeonId,diff)
	local ret = false
	for k,tutorialVo in pairs(self:getDungeonTutorialVoList()) do
		for k1,condVo in pairs(tutorialVo.condTbl) do
			if condVo.type == "begin" and tonumber(condVo.params[2]) == dungeonId and tonumber(condVo.params[3]) == diff then
		 		local condVo2 = tutorialVo.condTbl[2]
		 		local bm = BattleManager:getInstance()
		 		if condVo2.type == "round" and 
		 			tonumber(condVo2.params[1]) == bm:getWaveIndex() and 
		 			tonumber(condVo2.params[2]) == bm:getRoundIndex() and tutorialVo.hasEndExecute == 0 then
		 			-- and Global:getStringForKey(string.format("guideDungeonTutrial%s%d",Global:getStringForKey("username"),tutorialVo.id)) == nil then
		 			ret = true
		 		end
		 	end
		end
	end
	return ret
end
--是否可以展示vip提速提示
function GuideDataProxy:isCanShowVipSpeepTips(extra_cond)
	local startData = BattleManager:getInstance():getStartData()
	local vipLev = CharacterDataProxy:getInstance():getVipLev()
	local isFirstCout = Global:getStringForKey("speedTipCout") == nil
	
	if startData and startData.id == 50000 then
		return --虚拟副本
	end

	if startData and startData.id >= GuideSpeedTips.dungeonId and 
		startData.subId >= GuideSpeedTips.diff and 
		vipLev == 0 and 
		BattleManager:getInstance():showAccelerate() then
			if extra_cond == nil then
				if isFirstCout then
					GuideVipSpeedTips:show()
					Global:setStringForKey("speedTipCout",0)
				elseif tonumber(Global:getStringForKey("speedTipCout")) == 10 then
					GuideVipSpeedTips:show()
					Global:setStringForKey("speedTipCout",0)
				end
			elseif extra_cond then
				if isFirstCout then
					GuideVipSpeedTips:show()
					Global:setStringForKey("speedTipCout",0)
				elseif tonumber(Global:getStringForKey("speedTipCout")) == 10 then
					GuideVipSpeedTips:show()
					Global:setStringForKey("speedTipCout",0)
				end
			end
	end
end

function GuideDataProxy:addHero(heroData, battlePos)
	self._heroes[battlePos] = heroData
end

--[[
    英雄列表
]]
function GuideDataProxy:getHeroes()
	return self._heroes
end

function GuideDataProxy:addClearGem(gem, isInit)

	if isInit then
		table.insert(self._initGemList, gem)
	else
		table.insert(self._waitGemList, gem)
	end

end

function GuideDataProxy:addWaitNum(value)
	table.insert(self._waitGemNumList, value)
end

function GuideDataProxy:getInitGemList()
	return self._initGemList
end

function GuideDataProxy:getWaitGemNumList()
	return self._waitGemNumList
end

function GuideDataProxy:getWaitGemList()
	return self._waitGemList
end