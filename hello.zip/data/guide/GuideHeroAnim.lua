--副本中 获得新英雄 的动画层
GuideHeroAnim = class("GuideHeroAnim")
GuideHeroAnim.__index = GuideHeroAnim
GuideHeroAnim._widget     = nil
GuideHeroAnim.uiLayer    = nil

local __instance = nil

function GuideHeroAnim.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, GuideHeroAnim)
    return target
end

function GuideHeroAnim:getInstance()
    if not __instance then
        local ret = GuideHeroAnim.extend(DisplayUtil.newFitLayer())
        __instance = ret
        ret:init()
        ret:retain()
    end
    return __instance
end

function GuideHeroAnim:destoryInstance()
    self:release()
    __instance = nil
end

function GuideHeroAnim:init()

    self.uiLayer = TouchGroup:create()
    self:addChild(self.uiLayer)  
end

function GuideHeroAnim:update(heroId)
    require "LotteryRenderMgr"
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/lottery/lottery.plist")

    self._widget = GUIReader:shareReader():widgetFromJsonFile("guide/GuideCardAnim.ExportJson")
    self.uiLayer:addWidget(self._widget)
    GuideDataProxy:getInstance().showGetHeroArea = GuideGetHeroArea.Battle --记录
    --延时
    self:showNewHeroAnim(heroId,function()
        LotteryRenderMgr:getInstance():renderShowCard( self._widget,heroId )
    end)
end

function GuideHeroAnim:showNewHeroAnim(heroId,func)

    local panel = self._widget:getChildByName("panel_perpare")
    local p_1 = ccp(480,343)

    local child = panel:getChildByTag(1864)
    if child ~= nil then
        child:removeFromParentAndCleanup(true)
    end
    local child = panel:getNodeByTag(1869)
    if child ~= nil then
        child:removeFromParentAndCleanup(true)
    end
    local child = panel:getNodeByTag(5841)
    if child ~= nil then
        child:removeFromParentAndCleanup(true)
    end
    local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
    local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()
    --------------------------------------------------------------------------
    CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo("ui/effects_ui/xinyingxionghuode/xinyingxionghuode.ExportJson")
    local armature = CCArmature:create("xinyingxionghuode")
    armature:getAnimation():play("Animation1",0,-1,1)
    armature:setPosition(p_1)
    armature:setTag(1869)
    panel:addNode(armature,2)

    local shadow = CCLayerColor:create(ccc4(0, 0, 0, 180))
    shadow:setScaleX(1/DisplayUtil.min_scale*globa_scalx)
    shadow:setScaleY(1/DisplayUtil.min_scale*globa_scaly)
    shadow:setTag(5841)
    panel:addNode(shadow)

    require "HeadIcon"
    local icon = HeadIcon:create()
    icon:setFaceId(heroId)
    icon:isShowBg(false)
    icon:setTag(1864)
    icon:setPosition(p_1)
    panel:addChild(icon,2)
    panel:setVisible(true)
    panel:setTouchEnabled(false) --一开始不能点击

    local arr = CCArray:create()
    arr:addObject(CCDelayTime:create(1))
    arr:addObject(CCCallFunc:create(function()
        panel:setTouchEnabled(true)
    end))
    panel:runAction(CCSequence:create(arr))
--------------------------------------------------------------------------
    panel:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            Notifier.dispatchCmd(GuideEvent.ClickFinish) --广播事件
            panel:setVisible(false)
            panel:setTouchEnabled(false)
            func()
        end
    end)
end

--移除 获得英雄动画
function GuideHeroAnim:hide()
    local layer = BattleController:getInstance():getHeroAnimLayer()
    local child = layer:getChildByTag(1523)
    if child ~= nil then
        child:stopAllActions()
        layer:removeChildByTag(1523,false)
    end
end

--展示 获得英雄动画
function GuideHeroAnim:show(heroId)
    local layer = BattleController:getInstance():getHeroAnimLayer()
    local child = layer:getChildByTag(1523)
    if child ~= nil then
        child:stopAllActions()
        layer:removeChildByTag(1523,false)
    end

    local guideScene = GuideHeroAnim:getInstance()
    guideScene:setTag(1523)
    guideScene:update(heroId)
    layer:addChild(guideScene)
end

--------------------------------------------------------------
-- 主界面 获得新英雄动画层
GuideHeroAnimScene = class("GuideHeroAnimScene",WindowBase)
GuideHeroAnimScene.__index = GuideHeroAnimScene
GuideHeroAnimScene._widget     = nil
GuideHeroAnimScene.uiLayer    = nil
GuideHeroAnimScene.is_dispose = true

function GuideHeroAnimScene:create()
    local ret = GuideHeroAnimScene.new()
    __instance = ret
    return ret   
end

function GuideHeroAnimScene:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
end

function GuideHeroAnimScene:init()
    require "LotteryRenderMgr"
    require "ItemIcon"
    self.uiLayer = TouchGroup:create()
    self.uiLayer:setTouchPriority(-500)
    self:addChild(self.uiLayer,0)

    self._widget = Layout:create()
    self._widget:setZOrder(10)
    self._widget:setTouchEnabled(true)
    self._widget:setSize(CCSize(960,640))
    self.uiLayer:addWidget(self._widget)
end

function GuideHeroAnimScene:open()

    require "GuideDataProxy"
    -- GuideDataProxy:getInstance().showGetHeroArea = GuideGetHeroArea.MainScene --记录

    local heroId = self.params["hero_id"]
    local heroItemVo = self.params["heroItemVo"]
    local area = self.params["area"]

    GuideDataProxy:getInstance().showGetHeroArea = area
 
    local animLayer = Layout:create() --临时容器
    animLayer:setTag(1358)
    self._widget:addChild(animLayer,10)
    LotteryRenderMgr:getInstance():renderShowCard(animLayer,heroId,heroItemVo)
end

function GuideHeroAnimScene:close()
    if GuideDataProxy:getInstance().showGetHeroArea == GuideGetHeroArea.MainScene then
        require "RewardDataProxy"
        local heroList = RewardDataProxy:getInstance():getFirstChargeGetHeroList()
        table.remove(heroList,1)

        if #heroList > 0 then
           WindowCtrl:getInstance():open(CmdName.GuideHeroAnimScene,
                {hero_id = heroList[1].heroId,heroItemVo = heroList[1],area = GuideGetHeroArea.MainScene})
        end
    end
end

