
----新手引导 网络代理----------------------------------------------------
GuideNetTask = class("GuideNetTask")

local __instanceNetTask = nil
local _allowInstanceNetTask = false

function GuideNetTask:ctor()
    if not _allowInstanceNetTask then
		error("GuideNetTask is a singleton class")
	end
	self:init()
end

function GuideNetTask:getInstance()
	if not __instanceNetTask then
		_allowInstanceNetTask = true
		__instanceNetTask = GuideNetTask.new()
		_allowInstanceNetTask = false
	end

	return __instanceNetTask
end

function GuideNetTask:destoryInstance()
	_allowInstanceNetTask = false
	__instanceNetTask = nil
end

function GuideNetTask:init()
	require "GuideEvent"
	require "GuideCfg"
	require "guide_pb"
	require "proto_cmd_2_pb"

	Notifier.regist(GuideEvent.ShowResuleView,function()
		
	 	BattleController:getInstance():showBattleResult()
	end)

	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guide_info_rsp,"handleRecordGuideId()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.guide_plot_rsp,"handleRecordPlotId()")
end

function GuideNetTask:event_hero_anim(heroId)
	local voList = GuideDataProxy:getInstance():getHerAnimList()
	table.insert(voList,heroId)

	GuideRenderMgr:getInstance():checkPlayNewHeroAnim()
end

--请求记录新手引导id
function GuideNetTask:requestRecordGuideId(id)
	print("-----------------------requestRecordGuideId------------------------",id)
	local guide_info_rep = guide_pb.guide_info_rep()
	guide_info_rep.id = id
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guide_info_rep,guide_info_rep)
end

--响应记录新手引导id
function handleRecordGuideId(pkg)

	local guide_info_rsp = guide_pb.guide_info_rsp()
	guide_info_rsp:ParseFromString(pkg)

	print("---------------------handleRecordGuideId----------------------",guide_info_rsp.ret)
	if guide_info_rsp.ret == error_code_pb.msg_ret.success then
		GuideDataProxy:getInstance():getMainTutorialVoById(guide_info_rsp.id).hasExecute = 1
		GuideDataProxy:getInstance():getMainTutorialVoById(guide_info_rsp.id).hasRecord = 1

		ComSender:getInstance():dealExtInfo(guide_info_rsp.ext)
	else
		print("錯誤 handleRecordGuideId "..Helper.getErrStr(guide_info_rsp.ret))
	end
end

--请求记录剧情id
function GuideNetTask:requestRecordPlotId(id)
	print("-----------------------requestRecordPlotId------------------------",id)
	local guide_plot_req = guide_pb.guide_plot_req()
	guide_plot_req.id = id
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.guide_plot_req,guide_plot_req)
end

--响应记录剧情id
function handleRecordPlotId(pkg)
	local guide_plot_rsp = guide_pb.guide_plot_rsp()
	guide_plot_rsp:ParseFromString(pkg)

	print("---------------------handleRecordPlotId----------------------",guide_plot_rsp.ret)
	if guide_plot_rsp.ret == error_code_pb.msg_ret.success then
		-- GuideDataProxy:getInstance():getStoryEventVoById(guide_plot_rsp.id).hasExecute = 1
		ComSender:getInstance():dealExtInfo(guide_plot_rsp.ext)
	else
		print("錯誤 handleRecordPlotId "..Helper.getErrStr(guide_plot_rsp.ret))
	end
end

----副本引导 事件代理------------------------------------------------------
GuideEventTask = class("GuideEventTask")

local __instanceEventTask = nil
local _allowInstanceEventTask = false

function GuideEventTask:ctor()
    if not _allowInstanceEventTask then
		error("GuideEventTask is a singleton class")
	end
	self:init()
end

function GuideEventTask:getInstance()
	if not __instanceEventTask then
		_allowInstanceEventTask = true
		__instanceEventTask = GuideEventTask.new()
		_allowInstanceEventTask = false
	end

	return __instanceEventTask
end

function GuideEventTask:destoryInstance()
	_allowInstanceEventTask = false
	__instanceEventTask = nil
end

function GuideEventTask:init()
	require "GuideCfg"
	require "GuideEvent"
	require "GuideRenderMgr"
	require "GuideDataProxy"
---------------------------------------------------------
	local function initDungeon()
    	require "GuideLocalReader"
    	Notifier.removeByName(GuideEvent.InitDungeon)
	end
	Notifier.regist(GuideEvent.InitDungeon,initDungeon)
-----------------------------------------------------------
	Notifier.regist(GuideEvent.Dungeon,function(msg)
		if msg[1] == GuideCondType.Into then
			self:event_dungeon_into(msg)
		elseif msg[1] == GuideCondType.Begin then
			self:event_dungeon_begin(msg)
		elseif msg[1] == GuideCondType.Pass then
			self:event_dungeon_pass(msg)
		elseif msg[1] == GuideCondType.Task then
			self:event_dungeon_task(msg)
		elseif msg[1] == GuideCondType.Kill then
			self:event_dungeon_kill(msg)
		elseif msg[1] == GuideCondType.Hp then
			self:event_dungeon_hp(msg)
		elseif msg[1] == GuideCondType.Round then
			self:event_dungeon_round(msg)
		elseif msg[1] == GuideCondType.Fight then
			self:event_dungeon_fight(msg)
		elseif msg[1] == GuideCondType.Move then
			self:event_dungeon_move(msg)
		elseif msg[1] == GuideCondType.Trigger then
			self:event_dungeon_trigger(msg)
		elseif msg[1] == GuideCondType.Find then
			self:event_dungeon_find(msg)
		elseif msg[1] == GuideCondType.Skill then
			self:event_dungeon_skill(msg)
		end
	end)
-----------------------------------------------------------	
	local function initMain()
		require "GuideLocalReader"
    	Notifier.removeByName(GuideEvent.InitMain)
	end
	Notifier.regist(GuideEvent.InitMain,initMain)
	-----------------------------------------------------------
	Notifier.regist(GuideEvent.Main,function(msg)
		if msg[1] == GuideCondType.Into then
			self:event_main_into(msg)
		elseif msg[1] == GuideCondType.Trigger then
			self:event_main_trigger(msg)
		elseif msg[1] == GuideCondType.Open then
			self:event_main_open(msg)
		elseif msg[1] == GuideCondType.Task then
			self:event_task_finish(msg)
		elseif msg[1] == GuideCondType.Team then
			self:event_main_teamlev(msg)
		elseif msg[1] == GuideCondType.Get then
			self:event_main_get(msg)
		end
	end)
	Notifier.regist(CmdName.BATTLE_RSP_START,function()
		if Global:getStringForKey("speedTipCout") ~= nil then
			local speedTipCout = tonumber(Global:getStringForKey("speedTipCout"))
			Global:setStringForKey("speedTipCout",math.min(10,speedTipCout + 1))
		end
	end)
	Notifier.regist(CmdName.BATTLE_RSP_END,function()
		self:event_main_pass()
		local startData = BattleManager:getInstance():getStartData()
		if startData.id == 50000 then --模拟副本
			GameLayerMgr:getInstance():darkMainScene()
			TimerManager.addTimer(2500,function() --错峰加载
				WindowCtrl:getInstance():closeAllWin()
				local dm = DungeonManager:getInstance()
				dm:setCurrentHandleDungeonData(dm:getDungeonData(10000,1))
				WindowCtrl:getInstance():open(CmdName.Dungeon_View)
			end)
		else
			GameLayerMgr:getInstance():lightMainScene()
		end

		local dp = GuideDataProxy:getInstance()
		local nowEvtVo = dp:getStoryEventVoById(dp.nowEventId)
		if nowEvtVo and nowEvtVo.isSkipRecord == 1 then --如果是需要重复播放的剧情 中途退出要清掉记录
			local tbl = dp:getStoryEventVoById(nowEvtVo.replayEndId).replayTbl
			for k,id in pairs(tbl) do
				dp:getStoryEventVoById(id).hasExecute = 0
				dp:getStoryEventVoById(id).cout = 0
			end
		end
	end)
-----------------------------------------------------------
	Notifier.regist(GuideEvent.ShowStepAnim,function(params)
		
		print(" 現在的引導步驟目標是: ",params.target,params.id)
		if params.target == "mainguide" then

			-- TimerManager.addTimer(220,function() --延时
				GameLayerMgr:getInstance():cleanMsgLayer()
				WindowCtrl:getInstance():close(CmdName.Comm_Guide)
				WindowCtrl:getInstance():open(CmdName.Comm_Guide)
				Notifier.dispatchCmd(GuideEvent.ShowGuide,params.id) --先发事件
			-- end)
		elseif params.target == "freashman_layer" then

		 	GuideLayer:getInstance()
		 	Notifier.dispatchCmd(GuideEvent.ShowGuideTip,params)

		elseif params.target == "main_scene" then
			local mainscene = WindowCtrl:getInstance():getMainScene()
			GuideRenderMgr:getInstance():renderMainFlag(mainscene,params.id,params.target)
		elseif params.target == "window" then--临时写死弹窗 抽宝箱
			local mainscene = WindowCtrl:getInstance():getMainScene()
			GuideRenderMgr:getInstance():renderMainFlag(mainscene,params.id,params.target)	
		end
	end)

	Notifier.regist(CmdName.ERR_SERVER,function() --网络有误的情况下 不能显示黑层
		GameLayerMgr:getInstance():lightMainScene()
	end)
end

function GuideEventTask:forceExecuteMainTurtuial(id)
	require "GuideDataProxy"
	require "GuideLocalReader"
	GuideLocalReader:getInstance():loadInProxy()
	local dp = GuideDataProxy:getInstance()
	local v = dp:getMainTutorialVoById(id)
	print("debug 觸發教程！！！ ",id)
	-- dp.nowMainTutroialEventId = id
	-- for i=1,#v.animTbl do
	-- 	Notifier.dispatchCmd(GuideEvent.ShowStepAnim,{ id = v.id, target = v.animTbl[i].target})
	-- end

	dp.nowMainTutroialEventId = id
	if WindowCtrl:getInstance():getWaitWinNum() > 0 then
        Notifier.regist(CmdName.LastWaitWinClosed,function()
            Notifier.removeByName(CmdName.LastWaitWinClosed)
            for i=1,#v.animTbl do
            	if v.animTbl[i] then
					Notifier.dispatchCmd(GuideEvent.ShowStepAnim,{ id = v.id, target = v.animTbl[i].target})
				end
			end
        end)
    else

    	print(" v.animTbl ",#v.animTbl)
        for i=1,#v.animTbl do
        	if v.animTbl[i] then
				Notifier.dispatchCmd(GuideEvent.ShowStepAnim,{ id = v.id, target = v.animTbl[i].target})
			end
		end
    end
end

-----------触发条件---------------------------------
local function checkDispatchEvent()
	local dp = GuideDataProxy:getInstance()
	local voList = dp:getStoryEventVoList()
	for k,v in pairs(voList) do
		if v.hasExecute == 0 and v:isCanLaunch() then --可触发事件
			-- if Global:getStringForKey(string.format("guideDungeonStart%s%d",Global:getStringForKey("username"),v.id)) == nil then
				GuideDungeon:getInstance()
				Notifier.dispatchCmd(GuideEvent.ShowDungeon,v.id)
			-- end
		end
	end
end

local function checkDispatchDungeonTutorialEvent()
	local dp = GuideDataProxy:getInstance()
	local voList = dp:getDungeonTutorialVoList()
	for k,v in pairs(voList) do
		if v.hasExecute == 0 and v:isCanLaunch() then --可触发事件
			-- if Global:getStringForKey(string.format("guideDungeonTutrial%s%d",Global:getStringForKey("username"),v.id)) == nil then
				GuideDungeon:getInstance()
				Notifier.dispatchCmd(GuideEvent.DungeonTutorial,v.id)
			-- end
		end
	end
end

local function checkDispatchMainTutorialEvent()
	local dp = GuideDataProxy:getInstance()
	local voArr = dp:getMainTutorialVoArr()
	for k,v in ipairs(voArr) do
		if v.hasDispatchEvent == 0 and v:isCanLaunch() then --可触发事件
			v.hasDispatchEvent = 1 

			-- if Global:getStringForKey(string.format("guideMainStart%s%d",Global:getStringForKey("username"),v.id)) == nil then
					--新手引导 保底
					if v.groupType == 1 then --引导组首个
						GuideRenderMgr:getInstance():forceFinishEvent() 
					end
					print(" 觸發教程！！！ ",v.id)
					dp.nowMainTutroialEventId = v.id

					local layer = GameLayerMgr:getInstance():getFreshmanTipLayer()
					layer:runAction(CCCallFunc:create(function() --延时机制

						if WindowCtrl:getInstance():getWaitWinNum() > 0 then
			                Notifier.regist(CmdName.LastWaitWinClosed,function()
			                    Notifier.removeByName(CmdName.LastWaitWinClosed)
			                    for i=1,#v.animTbl do
			                    	if v.animTbl[i] then
										Notifier.dispatchCmd(GuideEvent.ShowStepAnim,{ id = v.id, target = v.animTbl[i].target})
									end
								end
			                end)
			            else
			                for i=1,#v.animTbl do
			                	if v.animTbl[i] then
									Notifier.dispatchCmd(GuideEvent.ShowStepAnim,{ id = v.id, target = v.animTbl[i].target})
								end
							end
			            end
					end))
			-- end
		end
	end
end

local function executeCond(key) --满足 剧情 条件
	local voList = GuideDataProxy:getInstance():getStoryEventVoList()

	for k,v in pairs(voList) do
		local condTbl = v.condTbl 
		for j=1,table.getn(condTbl) do
			if condTbl[j].key == key then
				condTbl[j].isDone = 1 
			end
		end
	end
end

local function executeCondDungeonTutorial(key) --满足 剧情 教程 条件
	local voList2 = GuideDataProxy:getInstance():getDungeonTutorialVoList()

	for k,v in pairs(voList2) do
		local condTbl = v.condTbl 
		for j=1,table.getn(condTbl) do
			if condTbl[j].key == key then
				condTbl[j].isDone = 1 
			end
		end
	end
end

local function checkIsPassDungeon(dungeonId,diff)
	local ret = true
	local dungeonVo = DungeonManager:getInstance():getScheduleDungeonData(dungeonId,diff)
	if dungeonVo == nil then
		ret = false
	else
		ret = dungeonVo._score ~= 0
	end
	return ret
end

local function executeCondMainTutorial(key) --满足 主界面 教程 条件
	local voList = GuideDataProxy:getInstance():getMainTutorialVoList()
	for k,v in pairs(voList) do
		local condTbl = v.condTbl 
		for j=1,table.getn(condTbl) do
			if condTbl[j].key == key then
				condTbl[j].isDone = 1
			end
			if condTbl[j].type == "nopass" and condTbl[j].params[1] == "dungeon" then --是否有某关副本没打
				local ret = checkIsPassDungeon(tonumber(condTbl[j].params[2]),tonumber(condTbl[j].params[3])) 
				if ret then
				 	condTbl[j].isDone = 0 
				else
					condTbl[j].isDone = 1
				end
			end
			if condTbl[j].type == "eqm" and condTbl[j].params[1] == "nothing" then -- 检测身上有没装备
				local ret = ItemManager:getInstance():hasEqm()
				if ret then
				 	condTbl[j].isDone = 0 
				else
					condTbl[j].isDone = 1
				end
			end
			if condTbl[j].type == "has" and condTbl[j].params[1] == "item" then --检测背包有没有对应物品
				local num = ItemManager:getInstance():getQuantityByBaseId(tonumber(condTbl[j].params[2]))
				if num > 0 then
					condTbl[j].isDone = 1
				else
					condTbl[j].isDone = 0
				end
			end
			if condTbl[j].type == "no" and condTbl[j].params[1] == "upskill" then --检测有没升级或技能
				local ret = HeroManager:getInstance():isHeroLearnSkill()
				if ret then
					condTbl[j].isDone = 0
				else
					condTbl[j].isDone = 1
				end
			end
			if condTbl[j].type == "no" and condTbl[j].params[1] == "strong" then --检测有没强化过装备
				local ret = ItemManager:getInstance():eqmHasDoSth(HeroHelper.forgePanelType.powered)
				if ret then
					condTbl[j].isDone = 0
				else
					condTbl[j].isDone = 1
				end
			end
			if condTbl[j].type == "noget" and condTbl[j].params[1] == "dungeonbox1" then --检测是否获得通关副本宝箱1
				local ret = DungeonManager:getInstance():isHasGetBox(1,1,2)
				if ret then
					condTbl[j].isDone = 0
				else
					condTbl[j].isDone = 1
				end
			end
			if condTbl[j].type == "no" and condTbl[j].params[1] == "enchant" then --检测有没有附魔过
				local ret = ItemManager:getInstance():eqmHasDoSth(HeroHelper.forgePanelType.enchant)
				if ret then
					condTbl[j].isDone = 0
				else
					condTbl[j].isDone = 1
				end
			end
			if condTbl[j].type == "no" and condTbl[j].params[1] == "upspriteskill" then --检测有没有升级过战队技能
				local ret = TeamManager:getInstance():isHasBeenUpSkill()
				if ret then
					condTbl[j].isDone = 0
				else
					condTbl[j].isDone = 1
				end
			end
			if condTbl[j].type == "no" and condTbl[j].params[1] == "getlotterybox" then
				local ret = CharacterManager:getInstance():getBaseData():isGetGuideLotteryBox()
				if ret == 1 then
					condTbl[j].isDone = 0
				else
					condTbl[j].isDone = 1
				end
			end
			if condTbl[j].type == "no" and condTbl[j].params[1] == "sprite" then
				local ret = PetDataProxy:getInstance():isCurPetActivate()
				if ret == 1 then
					condTbl[j].isDone = 0
				else
					condTbl[j].isDone = 1
				end
			end
			if condTbl[j].type == "has" and condTbl[j].params[1] == "sprite" then
				local ret = PetDataProxy:getInstance():isCurPetActivate()
				if ret == 0 then
					condTbl[j].isDone = 0
				else
					condTbl[j].isDone = 1
				end
			end
			if condTbl[j].type == "has" and condTbl[j].params[1] == "done" then
				local eventVo = GuideDataProxy:getInstance():getMainTutorialVoById(tonumber(condTbl[j].params[2]))
				if eventVo.hasExecute == 1 then
					condTbl[j].isDone = 1
				else
					condTbl[j].isDone = 0
				end
			end
			if condTbl[j].type == "has" and condTbl[j].params[1] == "activate" then
				if ActivateDataProxy:getInstance():isCanOpen(tonumber(condTbl[j].params[2]), nil, false) then
					condTbl[j].isDone = 1
				else
					condTbl[j].isDone = 0
				end
			end
			if condTbl[j].type == "no" and condTbl[j].params[1] == "stand" then
				if Utils.get_length_from_any_table(TeamManager:getInstance():getStandbyData(TeamType.Normal):getHeroList()) == 0 then
					condTbl[j].isDone = 1
				else
					condTbl[j].isDone = 0
				end
			end
			if condTbl[j].type == "no" and condTbl[j].params[1] == "guide" then
				--资源本 有没有 打过 用是否有执行新手引导来判断 （默认可执行）
				condTbl[j].isDone = 1
			end
 		end
	end
end

local function unexecuteCondMainTutorial(key) --取消满足 主界面 教程 条件 
	local voList = GuideDataProxy:getInstance():getMainTutorialVoList()
	for k,v in pairs(voList) do
		local condTbl = v.condTbl 
		for j=1,table.getn(condTbl) do
			if condTbl[j].key == key then
				condTbl[j].isDone = 0
			end
		end
	end
end

--初始化角色 触发新手引导
function GuideEventTask:initCheckDispMainTutorial()

	local key = string.format("teamlev_%d",CharacterDataProxy:getInstance():getTeamLev())
	executeCondMainTutorial(key)

	--初始化 副本数据
	local voDungeonList = DungeonManager:getInstance():getDungeonDataDic()
	for k,list in pairs(voDungeonList) do
		for k,v in pairs(list) do
			if v._score ~= 0 then
				local key = string.format("pass_dungeon_%d_%d",v._id,v._diff)
				executeCondMainTutorial(key)
				checkDispatchMainTutorialEvent()
			end
		end
	end	
end

function GuideEventTask:event_dungeon_into(msg)

	local startData = BattleManager:getInstance():getStartData()
	local dungeonId = startData.id
	local diff = startData.subId
	local key = string.format("into_dungeon_%d_%d",dungeonId,diff)

	print(" event_dungeon_into !!!! ",key)

	local dp = GuideDataProxy:getInstance()
	dp:isCanShowVipSpeepTips(dp:isHasPerStoryDungeon(dungeonId,diff) == nil)

	executeCond(key)      --剧情
	checkDispatchEvent()

	executeCondDungeonTutorial(key)   --教程
	checkDispatchDungeonTutorialEvent()
end

function GuideEventTask:event_dungeon_begin(msg)

	local startData = BattleManager:getInstance():getStartData()
	local dungeonId = startData.id
	local diff = startData.subId
	local key = string.format("begin_dungeon_%d_%d",dungeonId,diff)

	print(" event_dungeon_begin !!! ",key)

	executeCondDungeonTutorial(key)   --教程
	checkDispatchDungeonTutorialEvent()
end

function GuideEventTask:event_main_into(msg)
	local where = msg[2]
	local key = string.format("begin_%s",where)

	executeCondMainTutorial(key)
	checkDispatchMainTutorialEvent()
end

function GuideEventTask:event_main_teamlev(msg)
	local oldLev = msg[2]
	local newLev = msg[3]

	for i = oldLev,newLev do
		local key = string.format("teamlev_%d",i)

		print(" event_main_teamlev !!! ",key)

		executeCondMainTutorial(key)
		checkDispatchMainTutorialEvent()
	end
end

function GuideEventTask:event_main_get(msg)

	local obj = msg[2]
	local key = string.format("get_new_%s",obj)
	
	print(" event_main_get !! ",key)

	executeCondMainTutorial(key)
	checkDispatchMainTutorialEvent()
end

function GuideEventTask:event_main_trigger(msg)

	local eventId = msg[2]
	local key = string.format("triggered_%d",eventId)

	print(" event_main_trigger !! ",key)

	executeCondMainTutorial(key)
	checkDispatchMainTutorialEvent()
end

function GuideEventTask:event_main_choice(msg)

	executeCondMainTutorial(key)
	checkDispatchMainTutorialEvent()
end

function GuideEventTask:event_main_open(msg)

	local panel = msg[2]
	local key = string.format("open_%s",panel)

	executeCondMainTutorial(key)
	checkDispatchMainTutorialEvent()
end

function GuideEventTask:event_main_pass()
	local startData = BattleManager:getInstance():getStartData()
	local dungeonId = startData.id 
	local diff = startData.subId

	local isWin = true
	local batResData = BattleManager:getInstance():getBattleResultData()
	if batResData ~= nil then
		isWin = batResData.resultType == BattleResultType.VICTORY
	else
		if ( dungeonId == 50000 and diff == 1) then --序章要胜利
			isWin = true
		else
			isWin = false
		end
	end
	if isWin then
		local key = string.format("pass_dungeon_%d_%d",dungeonId,diff)

		print(" event_main_pass !! ",key)

		executeCondMainTutorial(key)
		checkDispatchMainTutorialEvent()
	end  
end

function GuideEventTask:event_task_finish(msg)

	local taskId = msg[2]
	local key = string.format("task_finish_%d",taskId)

	print(" event_task_finish !! ",key)

	executeCondMainTutorial(key)
	checkDispatchMainTutorialEvent()
end

function GuideEventTask:event_dungeon_pass(msg)
	local startData = BattleManager:getInstance():getStartData()  --还没看过剧情
	local dp = GuideDataProxy:getInstance()
	-- if Global:getStringForKey(string.format("guideDungeonEnd%d%d%s",startData.id,startData.battleType,Global:getStringForKey("username"))) == nil then
	-- 	Global:setStringForKey(string.format("guideDungeonEnd%d%d%s",startData.id,startData.battleType,Global:getStringForKey("username")),"done")
	local eventId = dp:isHasPosStoryDungeon(startData.id, startData.subId)
	if eventId ~= nil then
		local eventVo = dp:getStoryEventVoById( eventId )
		GuideNetTask:getInstance():requestRecordPlotId(eventVo.id)

		local dungeonId = msg[2]
		local diff = msg[3]
		local key = string.format("pass_dungeon_%d_%d",dungeonId,diff)

		executeCond(key)
		checkDispatchEvent()
	else --已经看过剧情
 		BattleController:getInstance():showBattleResult()
	end
end

function GuideEventTask:event_dungeon_task(msg)
	local status = msg[2]
	local taskId = msg[3]
	local key = string.format("task_%s_%d",status,taskId)
	
	executeCond(key)
	checkDispatchEvent()
end

function GuideEventTask:event_dungeon_kill(msg)
	local npcId = msg[2]
	local key = string.format("kill_npc_%d",npcId)

	executeCond(key)
	checkDispatchEvent()
end

function GuideEventTask:event_dungeon_hp(msg)
	local status = msg[2]
	local npcId = msg[3]
	local perc = msg[4]
	local key = string.format("hp_%s_%d_%d",status,npcId,perc)

	executeCond(key)
	checkDispatchEvent()
end

function GuideEventTask:event_dungeon_round(msg)
	local wave = msg[2]
	local num = msg[3]
	local key = string.format("round_%d_%d",wave,num)

	print(" event_dungeon_round !!! ",key)

	executeCondDungeonTutorial(key)
	checkDispatchDungeonTutorialEvent()

	executeCond(key)
	checkDispatchEvent()
end

function GuideEventTask:event_dungeon_fight(msg)
	local status = msg[2]
	local num = msg[3]
	local key = string.format("fight_%s_%d",status,num)

	executeCond(key)
	checkDispatchEvent()
end

function GuideEventTask:event_dungeon_move(msg)

	local npcId = msg[2]
	local rect = msg[3]
	local key = string.format("move_%d_%d_%d_%d",rect.origin.x,rect.origin.y,rect.size.width,rect.size.height)

	executeCond(key)
	checkDispatchEvent()
end

function GuideEventTask:event_dungeon_trigger(msg)
	local eventId = msg[2]
	local key = string.format("triggered_%d",eventId)
	
	print(" event_dungeon_trigger  ",key)
	executeCond(key)
	checkDispatchEvent()

	executeCondDungeonTutorial(key)   --教程
	checkDispatchDungeonTutorialEvent()
end

function GuideEventTask:event_dungeon_find(msg)
	local npcId = msg[2]
	local key = string.format("find_npc_%d",npcId)

	executeCond(key)
	checkDispatchEvent()
end

function GuideEventTask:event_dungeon_skill(msg)
	local obj = msg[2]
	local skillId = msg[3]
	local key = string.format("skill_%s_%d",obj,skillId)

	executeCond(key)
	checkDispatchEvent()
end