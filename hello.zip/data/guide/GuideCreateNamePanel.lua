--引导创建 姓名 展示 面板(剧情里面)
GuideCreateNamePanel = class("GuideCreateNamePanel",function()
	return Layout:create()
end)
GuideCreateNamePanel.__index = GuideCreateNamePanel
GuideCreateNamePanel._widget = nil

local __instance = nil
local inputName = nil
local btnPanelOk = nil

function GuideCreateNamePanel:create()
    local ret = GuideCreateNamePanel.new()
    ret:init()
   	__instance = ret
    return ret
end

local function event_cb_ok()
	if __instance._cbFunc ~= nil then
		Notifier.removeByName(CharacterEvent.CB_CLOSE_NAME)
		CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile("ui/guide/guideCreateName.plist")
		TimerManager.addTimer(500,function() --延时
			__instance._cbFunc()
		end)
	end
end

local function event_cb_update()
	btnPanelOk:setTouchEnabled(true)
	inputName:setEnabled(true)
end

local function checkName(txt)
	if string.len(txt) == 0 then
		Notifier.dispatchCmd(CharacterEvent.SHOW_ERR_ALERT,"名字不能為空")
		return false
	end
 	if Helper.hasSensitiveWord(txt) then
 		Notifier.dispatchCmd(CharacterEvent.SHOW_ERR_ALERT,"名字含有非法字元")
 		return false
 	end
	return true
end

local function event_btn_ok(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		local txt = inputName:getText()
		if checkName(txt) then
			btnPanelOk:setTouchEnabled(false)
			inputName:setEnabled(false)
			CharacterNetTask:getInstance():requestCreateName(txt)
			--预加载
			WindowCtrl:getInstance():getWinByName(CmdName.Comm_Guide)
		end
	end
end

local function event_btn_random(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		inputName:setText( GuideDataProxy:getInstance():getRandomName() )
	end
end

function GuideCreateNamePanel:setCallBackFunc(func)
	self._cbFunc = func
end

function GuideCreateNamePanel:init()
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guideCreateName.plist")
	self._widget = GUIReader:shareReader():widgetFromJsonFile("guide/GuideCreateName.ExportJson")
    self:addChild(self._widget)

    local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
 	local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()
    local shadow = tolua.cast(self._widget:getChildByName("img_shadow"),"ImageView")
    shadow:setOpacity(140)
    shadow:setSize(CCSizeMake(960,640))
    shadow:setScaleX(1/DisplayUtil.min_scale*globa_scalx)
    shadow:setScaleY(1/DisplayUtil.min_scale*globa_scaly)
    shadow:loadTexture("ui/guide/guide/guide_img_mask.png")

    btnPanelOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
    btnPanelOk:addTouchEventListener(event_btn_ok)

   	local btnRandom = tolua.cast(self._widget:getChildByName("btn_random"),"Button")
   	btnRandom:addTouchEventListener(event_btn_random)

   	local imgHero = tolua.cast(self._widget:getChildByName("img_hero"),"ImageView")
	   	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_head_10001.plist")
	   	imgHero:loadTexture("guide_head_10001.png",UI_TEX_TYPE_PLIST)
   	if CharacterManager:getInstance():getBaseData():getSex() == CharacterCfg.Female then
   		CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_head_10001_f.plist")
	    imgHero:loadTexture("guide_head_10001_f.png",UI_TEX_TYPE_PLIST) --女主角头像
	end

   	local inputBg = self._widget:getChildByName("img_inputbg")

   	inputName = CCEditBox:create(CCSize(220,35),CCScale9Sprite:create("ui/login/resource/img/img_empty.png"))
   	inputName:setTouchPriority(-1)
	inputName:setMaxLength(12)
	inputName:setFontSize(14)
	inputName:setPlaceHolder("請輸入名字")
	inputName:setPosition(ccp(inputBg:getPositionX() + 14,inputBg:getPositionY()))
   	self._widget:addNode(inputName,4)

   	Notifier.regist(CharacterEvent.CB_CLOSE_NAME,event_cb_ok)
   	Notifier.regist(CharacterEvent.CB_UPDATE_CREATE_NAME_PANEL,event_cb_update)
   	require "GuideCfg"
   	GuideDataProxy:getInstance().showCreateNameArea = GuideCreateNameArea.BattleScene
end
----------------------------------------------------------------------------------------------
-- 主界面的 改名层
GuideCreateNameScene = class("GuideCreateNameScene",WindowBase)
GuideCreateNameScene.__index = GuideCreateNameScene
GuideCreateNameScene._widget = nil
GuideCreateNameScene.uiLayer = nil
GuideCreateNameScene.is_dispose = true

local __instanceScene = nil
local inputNameScene = nil
local btnOkScene = nil

function GuideCreateNameScene:create()
    local ret = GuideCreateNameScene.new()
    __instanceScene = ret
    ret:init()
    return ret
end

function GuideCreateNameScene:dispose()
	if self._widget then
		self._widget:removeFromParentAndCleanup(true)
	end
	Notifier.removeByName(CharacterEvent.CB_CLOSE_NAME)
	CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile("ui/guide/guideCreateName.plist")
end

local function event_cb_ok_scene()
	WindowCtrl:getInstance():close(CmdName.NICKNAME_SCENE)
	GameLayerMgr:getInstance():darkMainScene()
	GuideLocalReader:getInstance():loadInProxy()

	local dm = DungeonManager:getInstance()
	dm:setCurrentHandleDungeonData(dm:getDungeonData(10000,1))
	WindowCtrl:getInstance():open(CmdName.Dungeon_View)
	BattleManager:getInstance():reqBattleStart(10000, 1,TeamType.Normal)
end

local function event_cb_update_scene()
	btnOkScene:setTouchEnabled(true)
	inputNameScene:setEnabled(true)
end

local function checkName_scene(txt)
	if string.len(txt) == 0 then
			Alert:show("名字不能為空")
		return false
	end
	if Helper.hasSensitiveWord(txt) then
 		Alert:show("名字含有非法字元")
 		return false
 	end
	return true
end

local function event_btn_ok_scene(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		local txt = inputNameScene:getText()
		if checkName_scene(txt) then
			inputNameScene:setEnabled(false)
			btnOkScene:setTouchEnabled(false)
			CharacterNetTask:getInstance():requestCreateName(txt)
			--预加载
			WindowCtrl:getInstance():getWinByName(CmdName.Comm_Guide)
		end
	end
end

local function event_btn_random_scene(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		require "GuideLocalReader"
		GuideLocalReader:getInstance():loadInProxy()
		inputNameScene:setText( GuideDataProxy:getInstance():getRandomName() )
	end
end

function GuideCreateNameScene:init()

	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guideCreateName.plist")
	self._widget = GUIReader:shareReader():widgetFromJsonFile("guide/GuideCreateName.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
 	local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()
    local shadow = tolua.cast(self._widget:getChildByName("img_shadow"),"ImageView")
    -- shadow:setOpacity(140)
    shadow:setOpacity(0)
    shadow:setSize(CCSizeMake(960,640))
    shadow:setScaleX(1/DisplayUtil.min_scale*globa_scalx)
    shadow:setScaleY(1/DisplayUtil.min_scale*globa_scaly)
    shadow:loadTexture("ui/guide/guide/guide_img_mask.png")

    btnOkScene = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
    btnOkScene:addTouchEventListener(event_btn_ok_scene)
   	
   	local btnRandom = tolua.cast(self._widget:getChildByName("btn_random"),"Button")
   	btnRandom:addTouchEventListener(event_btn_random_scene)

   	local imgHero = tolua.cast(self._widget:getChildByName("img_hero"),"ImageView")
	   	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_head_10001.plist")
	   	imgHero:loadTexture("guide_head_10001.png",UI_TEX_TYPE_PLIST)
   	if CharacterManager:getInstance():getBaseData():getSex() == CharacterCfg.Female then
   		CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/guide/guide/guide_head_10001_f.plist")
	    imgHero:loadTexture("guide_head_10001_f.png",UI_TEX_TYPE_PLIST) --女主角头像
	end

   	local inputBg = self._widget:getChildByName("img_inputbg")

   	inputNameScene = CCEditBox:create(CCSize(220,35),CCScale9Sprite:create("ui/login/resource/img/img_empty.png"))
   	inputNameScene:setTouchPriority(-1000)
	inputNameScene:setMaxLength(12)
	inputNameScene:setFontSize(14)
	inputNameScene:setPlaceHolder("請輸入名字")
	inputNameScene:setPosition(ccp(inputBg:getPositionX() + 14,inputBg:getPositionY()))
   	self._widget:addNode(inputNameScene,3)

   	Notifier.regist(CharacterEvent.CB_CLOSE_NAME,event_cb_ok_scene)
   	Notifier.regist(CharacterEvent.CB_UPDATE_CREATE_NAME_PANEL,event_cb_update_scene)
	require "GuideCfg"
   	GuideDataProxy:getInstance().showCreateNameArea = GuideCreateNameArea.MainScene
end

function GuideCreateNameScene:open()

end