
--新手引导层
GuideScene = class("GuideScene",WindowBase)
GuideScene.__index = GuideScene
GuideScene._widget  = nil
GuideScene.uiLayer  = nil

local __instance = nil

local panelMain = nil
local panelBag = nil

function GuideScene:create()
    local ret = GuideScene.new()
    __instance = ret
    return ret  
end 

----------------------响应事件---------------------------------
function GuideScene:event_show_guide(id)

    local panel = self._widget:getChildByName("panel_main")

    GuideRenderMgr:getInstance():renderMainTutorialVo(self._widget,panel,id) --渲染事件

    local eventVo = GuideDataProxy:getInstance():getMainTutorialVoById(id)
    if eventVo.condTbl[1].type == "into" then
        panel:setPosition(ccp(0,0))
    end

    self.eventId = eventVo.id 
end
----------------------初始化---------------------------------
function GuideScene:init()

    require "GuideRenderMgr"
    require "GuideDataProxy"
    require "GuideLocalReader"
    require "GuideNetTask"

    self._widget = GUIReader:shareReader():widgetFromJsonFile("guide/GuideScene.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:setTouchPriority(-500)
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    GuideRenderMgr:getInstance():renderInitMask(self._widget) --初始化遮罩层
    Notifier.regist(GuideEvent.ShowGuide,function(id) self:event_show_guide(id) end)
end

function GuideScene:dispose()
    if self._widget  then
        self._widget:removeFromParentAndCleanup(true)
    end
    self:removeFromParentAndCleanup(true)
    __instance = nil

    local sfc = CCSpriteFrameCache:sharedSpriteFrameCache()
    sfc:removeSpriteFramesFromFile("ui/guide/guide/guide_img_tutorial.plist")
    sfc:removeSpriteFramesFromFile("ui/guide/guide/guide_tutorial.plist")
    AnimateManager:getInstance():clear("ui/guide/gongnengyindao.ExportJson")
end

function GuideScene:open()
    self:isShowBg(false)
    self:isShowReturnBtn(false)
end

function GuideScene:close()
    if self.eventId == 10002 then --结束弹窗
        self.is_dispose = true 
    end
end
--------------------------------------------------------------------
--新手引导 悬浮层
GuideLayer = class("GuideLayer")
GuideLayer.__index = GuideLayer
GuideLayer._widget  = nil
GuideLayer.uiLayer  = nil

local __instanceLayer = nil

function GuideLayer.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, GuideLayer)
    return target
end

function GuideLayer:getInstance()
    if not __instanceLayer then
        local ret = GuideLayer.extend(DisplayUtil.newFitLayer())
        __instanceLayer = ret
        ret:init()
        ret:retain()
    end
    return __instanceLayer
end

function GuideLayer:destoryInstance()
    self:release()
    __instanceLayer = nil
end

function GuideLayer:init()

    if self.lock_ui_layer == nil then
        self.lock_ui_layer = TouchGroup:create()
        self.lock_ui_layer:setTouchPriority(-500)
        self:addChild(self.lock_ui_layer,0)
    end

    self.lock_lab_layer = Layout:create()
    self.lock_lab_layer:setZOrder(10)
    self.lock_lab_layer:setTouchEnabled(false)
    self.lock_lab_layer:setSize(CCSize(960,640))
    self.lock_ui_layer:addWidget(self.lock_lab_layer)

    Notifier.regist(GuideEvent.ShowGuideTip,function(params) self:event_show_guide(params) end)
end

function GuideLayer:event_show_guide(params)

    self:show()
    GuideRenderMgr:getInstance():renderMainFlag(self,params.id,params.target)
end

function GuideLayer:show()

	local tipLayer = GameLayerMgr:getInstance():getFreshmanTipLayer()
    local child = tipLayer:getChildByTag(1942)
    if child ~= nil then
        child:stopAllActions()
        tipLayer:removeChildByTag(1942,false)
    end

    local guideLayer = GuideLayer:getInstance()
    guideLayer:setTag(1942)
    tipLayer:addChild(guideLayer)
end

function GuideLayer:hide(groupType)

    local layer = GameLayerMgr:getInstance():getFreshmanTipLayer()
    local child = layer:getChildByTag(1942)
    if child ~= nil then
        child:stopAllActions()
        layer:removeChildByTag(1942,false)
    end

    self:saftClean(groupType)
end

function GuideLayer:saftClean(groupType)
    
    if groupType == GuideEndType.TutorialEnd then
        
        -- local tmpCleanTbl = {}
        -- local arr = self:getChildren()
        -- for i=0,arr:count()-1 do
        --     local c = arr:objectAtIndex(i)
        --     if c == self.lock_ui_layer then
        --         --不删除
        --     else
        --         table.insert(tmpCleanTbl,c)
        --     end
        -- end
        -- for i=1,#tmpCleanTbl do
        --     tmpCleanTbl[i]:removeFromParentAndCleanup(true)
        -- end
        -- self:removeAllNodes()

        --------------清理缓存-------------------
        local sfc = CCSpriteFrameCache:sharedSpriteFrameCache()
        sfc:removeSpriteFramesFromFile("ui/guide/guide/guide_img_tutorial.plist")
        sfc:removeSpriteFramesFromFile("ui/guide/guide/guide_tutorial.plist")
        AnimateManager:getInstance():clear("ui/guide/gongnengyindao.ExportJson")
    end
end