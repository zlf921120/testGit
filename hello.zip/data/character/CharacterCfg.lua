--角色配置
CharacterCfg = {}
CharacterCfg.Female = 0 --女
CharacterCfg.Male = 1 --男
--类型
CharacterCfg.Name = 1 --名称
CharacterCfg.Gender = 2 --性别
CharacterCfg.Face = 3--头像

--角色标示
RoleFlag = {}
RoleFlag.Normal = 0 --普通玩家
RoleFlag.Gm = 1 	--GM
RoleFlag.Guider = 2 --指导员
RoleFlag.Guild = 3 --公会管理员

--新消息提示目标
NewTipsEnum = {}
NewTipsEnum.mail = "mail"
NewTipsEnum.chat = "chat"
NewTipsEnum.vip = "vip"
NewTipsEnum.first_charge = "first_charge"
NewTipsEnum.mainui_guild_fight = "mainui_guild_fight"
NewTipsEnum.guild_apply = "guild_apply"
NewTipsEnum.guild_worship = "guild_worship"
NewTipsEnum.guild_skill = "guild_skill"
NewTipsEnum.guild_fight = "guild_fight"
NewTipsEnum.guild_myauction = "guild_myauction"
NewTipsEnum.guild_boss = "guild_boss"
NewTipsEnum.guild_fight_reward = "guild_fight_reward"
NewTipsEnum.guild = "guild"
NewTipsEnum.lottery = "lottery"
NewTipsEnum.notice = "notice"
NewTipsEnum.task_physical = "task_physical"
NewTipsEnum.reward = "reward" --奖励发放(活动)
NewTipsEnum.festival = "festival" --节日活动
NewTipsEnum.arena = "arena"
NewTipsEnum.mystery = "mystery"
NewTipsEnum.vip_gift = "has_gift"
NewTipsEnum.guard = "guard"  --守卫
NewTipsEnum.login_buy_coin = "login_buy_coin" --首次免费购买金币
NewTipsEnum.sky_battle = "sky_battle" --天空之役 
NewTipsEnum.friend = "friend" --有人申请添加好友


--新功能图标提示
NewImgEnum = {}
NewImgEnum.arena = 100004
NewImgEnum.guild = 100012
NewImgEnum.glory = 100010
NewImgEnum.tower = 100008
NewImgEnum.forge_enchant = 100009
NewImgEnum.forge_gem = 100011
NewImgEnum.forge_identity = 100005
NewImgEnum.forge_upgrade = 100014
NewImgEnum.dungeon_diff2 = 100001
NewImgEnum.dungeon_diff3 = 100007
NewImgEnum.mystery = 100015 --神秘商人
NewImgEnum.robdungeon = 100017
NewImgEnum.secret = 100018
NewImgEnum.sky_battle = 100019
NewImgEnum.secret_diff2 = 100020 --解谜副本难度2
