--
-- Author: thisgf
-- Date: 2014-06-12 16:27:34
-- 角色事件

CharacterEvent = class("CharacterEvent")

--通知登录成功, 进去主界面
CharacterEvent.RSP_LOGIN_SUCCESS = "CharacterEvent.RSP_LOGIN_SUCCESS"

--通知登录失败
CharacterEvent.RSP_LOGIN_FAIL = "CharacterEvent.RSP_LOGIN_FAIL"

--通知获取到角色信息
CharacterEvent.RSP_GET_ROLE_INFO = "CharacterEvent.RSP_GET_ROLE_INFO"

--通知更新角色资产
CharacterEvent.RSP_UPDATE_ROLE_ASSET = "CharacterEvent.RSP_UPDATE_ROLE_ASSET"

--通知体力同步时间
CharacterEvent.RSP_PHYSICAL_SYNC = "CharacterEvent.RSP_PHYSICAL_SYNC"
--回调关闭性别面板
CharacterEvent.CB_CLOSE_GENDER = "CharacterEvent.CB_CLOSE_GENDER"
--回调关闭姓名剧情面板
CharacterEvent.CB_CLOSE_NAME = "CharacterEvent.CB_CLOSE_NAME"
--更新 名字面板
CharacterEvent.CB_UPDATE_CREATE_NAME_PANEL = "CharacterEvent.CB_UPDATE_CREATE_NAME_PANEL"
--通知提示
CharacterEvent.SHOW_ERR_ALERT = "CharacterEvent.SHOW_ERR_ALERT"