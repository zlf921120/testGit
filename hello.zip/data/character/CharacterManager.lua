--
-- Author: thisgf
-- Date: 2014-06-12 11:21:07
-- 人物管理器

require "role_pb"
require "zone_pb"
require "guild_pb"

require "IManager"
require "CharacterEvent"
require "CharacterNetTask"
require "CharacterDataProxy"
require "CharacterLocalReader"
require "ResContendManager"

--登录状态
LoginStatus = {
    QUICK_LOGIN_FAIL = 1,
    MANUAL_LOGIN_FAIL = 2,
    ZONE_LOGIN_FAIL = 3,
}


--登录数据
local LoginData = class("LoginData")

LoginData._roldId = nil
-- --帐号ID
-- LoginData._acctId = 0

-- --帐号名
-- LoginData._acctName = ""

-- --渠道ID
-- LoginData._channelId = 1

-- --区ID
-- LoginData._zoneId = 1

-- --区名字
-- LoginData._zoneName = ""

-- --登录session
-- LoginData._session = ""

-- --设备ID
-- LoginData._deviceId = 0

function LoginData:getAcctId()
	return LoginDataProxy:getInstance()._acctId
end

function LoginData:getAcctName()
	return LoginDataProxy:getInstance()._acctName
end

function LoginData:getChannelId()
	return LoginDataProxy:getInstance()._channelId
end

function LoginData:getZoneId()
	return LoginDataProxy:getInstance()._zoneId
end

function LoginData:getZoneName()
	return LoginDataProxy:getInstance()._zoneName
end

function LoginData:getSession()
	return LoginDataProxy:getInstance()._session
end

function LoginData:getDeviceId()
	return LoginDataProxy:getInstance()._deviceId
end

function LoginData:getRoleId()
	if self._roldId == nil then
		require "RoleId"
		self._roldId = RoleId:create()
		self._roldId:setData(self:getAcctId(),self:getChannelId(),self:getZoneId())
	end
	return self._roldId
end

--角色基础数据
local RoleBaseData = class("RoleBaseData")

--名字
RoleBaseData._name = ""
--性别
RoleBaseData._sex = 1
--头像ID
RoleBaseData._faceId = 0
--vip级别
RoleBaseData._vip_lv = -1
--vip经验
RoleBaseData._vip_exp = 0
--充值卡类型(月卡/季卡/年卡)
RoleBaseData._pay_goods_type = 0
--充值卡剩余天数
RoleBaseData._pay_end_day = 0
--是否已经取名字了
RoleBaseData._hasCreateName = 1 
--已开启功能列表
RoleBaseData._activateList = nil
RoleBaseData._chargeStatus = 0
--新消息提示
RoleBaseData._newsTipList = nil
RoleBaseData._showIconList = nil
--是否已经领取过 新手宝箱
RoleBaseData._isGetGuideLotteryBox = nil
--角色标示
RoleBaseData._roleFlag = 0
--角色在服务端的唯一标识
RoleBaseData._uid = ""

function RoleBaseData:getName()
	return self._name
end

function RoleBaseData:getSex()
	return self._sex
end

function RoleBaseData:getFaceId()
	return self._faceId
end

function RoleBaseData:getVipLv()
	return self._vip_lv
end

function RoleBaseData:getVipExp()
	return self._vip_exp
end

function RoleBaseData:getPayGoodsType()
	return self._pay_goods_type
end

function RoleBaseData:getUid()
	return self._uid
end


function RoleBaseData:getPayEndDay()
	return self._pay_end_day
end

function RoleBaseData:getUid()
	return self._uid
end

function RoleBaseData:getHasCreateName()
	return self._hasCreateName
end

function RoleBaseData:getHasCreateGender()
	return self._hasCreateGender
end

function RoleBaseData:getActivateList()
	return self._activateList
end	

function RoleBaseData:getGuideList()
	return self._guideList
end

function RoleBaseData:getPlotList()
	return self._plotList
end

function RoleBaseData:getNewsTipList()
	return self._newsTipList
end

function RoleBaseData:getShowIconList()
	return self._showIconList
end

function RoleBaseData:setNewsTipStatus(t,v)
	self._newsTipList[t] = v
end

function RoleBaseData:isGetGuideLotteryBox()
	return self._isGetGuideLotteryBox
end

function RoleBaseData:getChargeStatus()
	return self._chargeStatus
end

function RoleBaseData:getRoleFlag()
	return self._roleFlag
end

--角色资产数据
local RoleAssetData = class("RoleAssetData")
--经验
RoleAssetData._exp = 0
--金币
RoleAssetData._gold = 0
--钻石
RoleAssetData._diamond = 0
--体力
RoleAssetData._physical = 0
--竞技场积分
RoleAssetData._arena_point = 0
--荣耀之路积分
RoleAssetData._glory_point = 0
--爬塔积分
RoleAssetData._tower_point = 0
--英雄技能点
RoleAssetData._skill_point = 0
--天空之役积分
RoleAssetData._skywarPoint = 0
RoleAssetData._guild_donate = 0 --当前贡献
RoleAssetData._guild_donate_total = 0 --总贡献
RoleAssetData._guild_donate_today_limit = 0 --今日贡献上限

function RoleAssetData:getExp()
	return self._exp
end

function RoleAssetData:getGold()
	return self._gold
end

function RoleAssetData:getDiamond()
	return self._diamond
end

function RoleAssetData:getPhysical()
	return self._physical
end

function RoleAssetData:setPhysical(v)
	local old_physical = self._physical
	self._physical = math.max(0,v)
	if old_physical~=self._physical then
		--跨体力
		if old_physical >= CharacterDataProxy:getInstance():getCurLevPhysicalMax() and
			self._physical < CharacterDataProxy:getInstance():getCurLevPhysicalMax() then
			
			local sceneVo = CharacterDataProxy:getInstance():getCheckPhysicalSceneVo()
			sceneVo.lastTime = ServerTimerManager:getInstance():getCurTime()
			--重置体力
			CharacterDataProxy:getInstance().refreshPhysicalTimer()
			CharacterDataProxy:getInstance().resetPhysicalTimer()
		end

		local target_unix_time = CharacterDataProxy:getInstance():getRecoverAllPhysicalTime()
		if target_unix_time>0 then
			SysSettingMgr:getInstance():addOneOffNoticeByUnixTime(SysSettingMgr.TipsNameList.FULL_PHYS_TIPS, 
												ServerTimerManager:getInstance():transSrvTime2Client(target_unix_time))
		end
	end
end

function RoleAssetData:getArenaPoint()
	return self._arena_point
end

function RoleAssetData:getGloryPoint()
	return self._glory_point
end

function RoleAssetData:getTowerPoint()
	return self._tower_point
end

function RoleAssetData:getSkillPoint()
	return self._skill_point
end

function RoleAssetData:getSkywarPoint()
	return self._skywarPoint
end

function RoleAssetData:getDonate()
	return self._guild_donate
end

function RoleAssetData:getDonateTotal()
	return self._guild_donate_total
end

function RoleAssetData:getDonateTodayLimit()
	return self._guild_donate_today_limit
end

--角色战队数据
local TeamBaseData = class("TeamBaseData")
--战队等级
TeamBaseData._lev = 0
--经验
TeamBaseData._exp = 0
--战斗力
TeamBaseData._fc = 0

function TeamBaseData:getLev()
	return self._lev
end

function TeamBaseData:getExp()
	return self._exp
end

function TeamBaseData:getFC()
	return self._fc
end


local GuildData = class("GuildData")  --角色公会数据
GuildData._id = 0 	  --公会id
GuildData._name = ""  --公会名称
GuildData._desc = ""  --公会宣言
GuildData._lev = 0    --公会等级
GuildData._maxnum = 0  --公会最大 人口数
GuildData._curnum = 0 --公会当前 人数
GuildData._logoId = 0  --公会图标id
GuildData._free = 0  --免申请等级
GuildData._post = 0  --所在公会的职位
GuildData._declaration = ""  --公会战 口号
GuildData._worship_reward = 0  --膜拜奖励
GuildData._isActive = 0 --激活状态
GuildData._hasBeenFightNum = 0 --已挑战次数
GuildData._isReadyGuildFight = 0 --是否已准备好 公会战
GuildData._cheerNum = 0 --助威人数 

function GuildData:getId()
	return self._id 
end

function GuildData:getName()
	return self._name
end

function GuildData:getDesc()
	return self._desc
end

function GuildData:getMaxnum()
	return self._maxnum
end

function GuildData:getCurrNum()
	return self._curnum
end

function GuildData:getLogoId()
	return self._logoId
end

function GuildData:getFree()
	return self._free
end

function GuildData:getPost()
	return self._post
end

function GuildData:getLev()
	return self._lev
end

function GuildData:getWorshipReward()
	return self._worship_reward
end

function GuildData:getWorshipToday()
	return self._worship_today
end

function GuildData:getIsActive()
	return self._isActive
end

function GuildData:getHasBeenFightNum()
	return self._hasBeenFightNum
end

function GuildData:initJoinGuild()
	self._worship_today = VipDataProxy:getInstance():getPrivilegeValue( VipPrivilegeType.GuildWorshipMax )
end

function GuildData:getDeclaration()
	return self._declaration
end

function GuildData:getCheerNum()
	return self._cheerNum
end

local loginData = nil
local baseData = nil
local assetData = nil
local teamData = nil
local guildData = nil

CharacterManager = class("CharacterManager", IManager.new())
--登录数据
CharacterManager._loginData = nil
--角色基础数据
CharacterManager._baseData = nil
--角色资产数据
CharacterManager._assetData = nil
--角色战队数据
CharacterManager._teamData = nil
--角色公会数据
CharacterManager._guildData = nil
--是否已经初始化角色信息
CharacterManager._isInitRoleInfo = false

function CharacterManager:getLoginData()
	return self._loginData
end

function CharacterManager:getBaseData()
	return self._baseData
end

function CharacterManager:getAssetData()
	return self._assetData
end

function CharacterManager:getTeamData()
	return self._teamData
end

function CharacterManager:getGuildData()
	return self._guildData
end

function CharacterManager:getIsInitRoleInfo()
	return self._isInitRoleInfo
end

--是否登陆初始化
CharacterManager._initLogin = false
CharacterManager._hasInitAssetData = false

local _instance = nil
local _allowInstance = false

function CharacterManager:ctor()
	
	if not _allowInstance then
		error("CharacterManager is a singleton class")
	end

	self._logPrefix = "人物調試"

	self._loginData = LoginData.new()
	self._baseData = RoleBaseData.new()
	self._assetData = RoleAssetData.new()
	self._teamData = TeamBaseData.new()
	self._guildData = GuildData.new()

	loginData = self._loginData
	baseData = self._baseData
	assetData = self._assetData
	teamData = self._teamData
	guildData = self._guildData
end

function CharacterManager:getInstance()

	if not _instance then
		_allowInstance = true
		_instance = CharacterManager.new()
		_allowInstance = false
	end

	return _instance

end

--[[
    请求角色信息
]]
function CharacterManager:requireRoleInfo()

	if _isInitRoleInfo == true then return end
	print("  請求角色資訊 ")

	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.role_info_rsp, "onRoleInfoRsp()")
		
	local dp = LoginDataProxy:getInstance()

	local infoReq = role_pb.role_info_req()
	infoReq.rid.uin = dp._acctId
	infoReq.rid.channel_id = dp._channelId
	infoReq.rid.zone_id = dp._zoneId

	--发送设备信息
	local net_work_state = ""
	if Global:getNetWorkState()==Helper.NetWorkState.WIFI then
		net_work_state="wifi"
	else
		net_work_state="gprs"
	end

	local platFormName = "unknow_device"
	if Global:getTargetPlatform() == Helper.TargetPlatForms.ANDROID then
		platFormName = "android"
	elseif Global:getTargetPlatform() == Helper.TargetPlatForms.IOS then
		platFormName = "ios"
	else
		platFormName = "win32"
	end


	local os_type = nil
	if Global["comFunForLua"] then
		os_type = Global:comFunForLua(3,"")
	end
	--如果获取不到，则只显示设备类型
	if os_type==nil or os_type=="" then
		os_type = platFormName
	end

	local device_type = nil
	if Global["comFunForLua"] then
 		device_type = Global:comFunForLua(2,"")
	end

	--如果获取不到，则只显示设备类型
	if device_type==nil or device_type=="" then
		device_type = platFormName
	end

	infoReq.device_info = net_work_state.."$"..device_type.."$"..os_type

	-- self:log("uin:%d, channel_id:%d, zone_id:%d", loginData._acctId, loginData._channelId, loginData._zoneId)

	local serialize = infoReq:SerializeToString()

	local byteSize = string.len(serialize)
	-- self:log("-------------%d", byteSize)

	-- Global:sendPkg(proto_cmd_pb.msg_cmd.role_info_req, serialize, byteSize)

	self:sendProto(infoReq)
end

--[[
    请求角色资源数据
]]
function CharacterManager:requireRoleAsset()

	print("  請求角色資來源資料  ")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.role_assets_rsp, "onRoleAssetRsp()")

	local assetReq = role_pb.role_assets_req()
	local dp = LoginDataProxy:getInstance()

	assetReq.rid.uin = dp._acctId
	assetReq.rid.channel_id = dp._channelId 
	assetReq.rid.zone_id = dp._zoneId

	-- Global:sendPkg(proto_cmd_pb.msg_cmd.role_assets_req, assetReq:SerializeToString(), assetReq:ByteSize())

	self:sendProto(assetReq)
end

function CharacterManager:setIsGameStart(is_start)
	self._is_game_star = is_start
end

function CharacterManager:isGameStart()
	return self._is_game_star 
end

--[[
    角色信息响应
]]

function onRoleInfoRsp(protoData)

	_instance._is_game_star = true

	print("  角色信息回應  ")
	_instance._isInitRoleInfo = true

	local infoRsp = role_pb.role_info_rsp()
	infoRsp:ParseFromString(protoData)

	if infoRsp.ret ~= error_code_pb.msg_ret.success then
        _instance:dealLoginError(infoRsp.ret)
        return 
    end 

	--设置最近领取限时体力时间
	TaskManager:getInstance():setPhysicalGetTime(infoRsp.physical_info.limit_physcial_time)
	
	--系统时间校正
	ServerTimerManager:getInstance():setSrvTime(infoRsp.system_info.time)
	ServerTimerManager:getInstance():setOpenDay(infoRsp.system_info.open_day)
	--角色体力信息处理
	CharacterNetTask:getInstance():setPhyStatus(infoRsp.physical_info.physical_num,infoRsp.physical_info.last_time)
	--角色初始化信息
	_instance:setRoleBaseInfo(infoRsp.base_info)

	--背包初始化
	ItemManager:getInstance():initBackPackData(infoRsp.bag_info.items)

	--任务处理
	TaskManager:getInstance():initTaskInfo(infoRsp.task_info.tasks, 
               infoRsp.task_info.done_tasks , infoRsp.task_info.future_tasks)


	--英雄信息处理
	HeroManager:getInstance():initHeroList(infoRsp.hero_info.heros, infoRsp.hero_info.type) 

	--战队初始化
	TeamManager:getInstance():_freshTeamInfoBySrv(infoRsp.team_info.type, infoRsp.team_info.base, 
								infoRsp.team_info.combat_info, infoRsp.team_info.standby_info, 
								infoRsp.team_info.skills)
	--侍宠初始化
	require "PetDataProxy"
	PetDataProxy:getInstance():makeRefreshPet(infoRsp.team_info.sprite)

	--战队站位对应的装备信息初始化
	HeroManager:getInstance():setHeroAllEqms(infoRsp.eqm_info.eqms)
	DungeonManager:getInstance():initResDungeonSchedule(infoRsp.dungeon_info.open_res_duns)

	--副本进度初始化
	DungeonManager:getInstance():initDungeonSchedule(
		infoRsp.dungeon_info.progs_normal, 
		infoRsp.dungeon_info.progs_hard, 
		infoRsp.dungeon_info.progs_nightmare, 
		infoRsp.dungeon_info.chapter_info, 
		infoRsp.dungeon_info.buy_dungeon
	)

	local guardIds = {}
	for i, v in ipairs(infoRsp.dungeon_info.res_dun_guard_base_ids) do
		guardIds[i] = v
	end
	ResContendManager:getInstance():initIllustrateAttr(guardIds)
	

	--初始化绿点
	HeroManager:getInstance():initInitBattleEqmStatus()
	--初始化公告
	require "NoticeDataProxy"
	NoticeDataProxy:getInstance():makeNoticeBySvr(infoRsp.notice_info.notices)

	--设置需要重置相关信息的时间时间
	SysSettingMgr:getInstance():setFetchRestInfoTime(infoRsp.fetch_reset_info_time)

	Notifier.dispatchCmd(CmdName.RSP_GET_ROLE_INFO)
end

function CharacterManager:setRoleBaseInfo(srv_base_info)
	baseData._name = srv_base_info.base.name
	baseData._sex = srv_base_info.base.sex
	baseData._faceId = srv_base_info.base.face_id
	baseData._hasCreateGender = srv_base_info.s_sex
	baseData._hasCreateName = srv_base_info.s_name --是否改名字
	baseData._vip_lv = srv_base_info.vip.lev
	baseData._vip_exp = srv_base_info.vip.exp
	baseData._pay_goods_type = srv_base_info.charge_info.goods_type
	baseData._pay_end_day = srv_base_info.charge_info.end_day
	baseData._activateList = srv_base_info.activate
	baseData._guideList = srv_base_info.guide
	baseData._plotList = srv_base_info.plot
	baseData._roleFlag = srv_base_info.label --角色标示(gm/指导员)
	baseData._uid = srv_base_info.base.acct_id
	teamData._lev = srv_base_info.team_base.lev
	teamData._exp = srv_base_info.team_base.exp

	--抽奖提示
	require "LotteryDataProxy"
	require "GuildDataProxy"
	LotteryDataProxy:getInstance():setNewsTipBoxs(srv_base_info.green.bronze,srv_base_info.green.gold)
	--聊天提示
	require "ChatDataProxy"
	ChatDataProxy:getInstance():makeChatNewTips(srv_base_info.green.new_chats)
	local isShowChat = 1 --0显示 1 不显示
	local isShowFirstCharge = 1 --0显示 1 不显示
	local isShowFirstChargeIcon = 1 --0显示 1 不显示
	local isShowFightReward = 1 --0显示 1 不显示
	local isShowFriend = 1 --0显示 1 不显示
	if #srv_base_info.green.new_chats > 0 then isShowChat = 0 end
	baseData._chargeStatus = srv_base_info.green.activitie_is_charge
	if baseData._chargeStatus == 1 then 
		isShowFirstCharge = 0 
		isShowFirstChargeIcon = 0
	end
	if baseData._chargeStatus == 0 then
		isShowFirstChargeIcon = 0
	end
	if srv_base_info.green.login_new_spoils_green == 1 then
		isShowFightReward = 0
		GuildDataProxy:getInstance().fight_reward_news = 1
	end

	if srv_base_info.green.sns_request_friend == 1 then
		isShowFriend = 0
	end
	--绿点提示
	require "MailDataProxy"
	MailDataProxy:getInstance():setInitMailList( srv_base_info.green.mail )
	baseData._newsTipList = {mail = MailDataProxy:getInstance():isHasUnreadLettle(),
							 chat = isShowChat,
							 vip = srv_base_info.green.vip_gift,
							 guard = #srv_base_info.green.rob_res_duns > 0 and 0 or 1,
							 first_charge = isShowFirstCharge,
							 guild = isShowFightReward,
							 login_buy_coin = srv_base_info.green.login_buy_coin,
							 friend = isShowFriend} 
	baseData._showIconList = {first_charge = isShowFirstChargeIcon}
	require "SignDataProxy"						 
	SignDataProxy:getInstance().hasNewTips = srv_base_info.green.signin

	baseData._isGetGuideLotteryBox = srv_base_info.green.boxdraw_people --新手抽奖宝箱
	CharacterManager:getInstance():updateRoleAssets(srv_base_info.assets)
	--奖励发放
	require "RewardDataProxy"
	RewardDataProxy:getInstance():saveRewardInfo(srv_base_info.green.activitie)
	--节日活动
	require "FestivalDataProxy"
	FestivalDataProxy:getInstance():saveRewardInfo(srv_base_info.green.holiday)
	--被攻占的资源本
	ResContendManager:getInstance():setBeRobResDun(srv_base_info.green.rob_res_duns)

	guildData._id = srv_base_info.guild.id
	guildData._name = srv_base_info.guild.name
	guildData._worship_reward = srv_base_info.guild.worship_reward
	guildData._worship_today = srv_base_info.guild.worship_today
	guildData._apply_list = srv_base_info.guild.apply_list
	guildData._curnum = srv_base_info.guild.members
	guildData._post = srv_base_info.guild.post
	guildData._skills = srv_base_info.guild.skills
	guildData._logoId = srv_base_info.guild.guild_icon
	guildData._lev = srv_base_info.guild.lev
	guildData._cheerNum = srv_base_info.guild.cheer_num
	GuildDataProxy:getInstance():getGuildFightSceneVo().isCheer = srv_base_info.guild.is_ready

    GuildDataProxy:getInstance():makeMeGuildSkillBySvr()
    GuildDataProxy:getInstance():saveGuildFightRule(srv_base_info.guild_role)

    require "SkywarManager"
    SkywarManager:getInstance():setOpenTime(srv_base_info.sky_battle_periods)
    require "secret/SecretDataProxy"
    SecretDataProxy:getInstance():setHasBeenDone(srv_base_info.puzzle_dungeon)
end

--[[
    角色资产响应
]]
function onRoleAssetRsp(protoData)
	print(" 角色資產回應 ")
	local assetRsp = role_pb.role_assets_rsp()
	assetRsp:ParseFromString(protoData)

	if assetRsp.ret~=error_code_pb.msg_ret.success then
		cclog("角色資產回應失敗~~~%d",assetRsp.ret)
		cclog("角色資產回應失敗~~~%d",assetRsp.ret)
		cclog("角色資產回應失敗~~~%d",assetRsp.ret)
		cclog("角色資產回應失敗~~~%d",assetRsp.ret)
		cclog("角色資產回應失敗~~~%d",assetRsp.ret)
		return
	end

	local dp = CharacterManager:getInstance()
	dp:updateRoleAssets(assetRsp.assets)

	ComSender:getInstance():dealExtInfo(assetRsp.ext)
end

--更新角色资产信息
function CharacterManager:updateRoleAssets(assets)

	assetData._gold = assets.coin
	assetData._diamond = assets.gold
	assetData:setPhysical( assets.physical )
	assetData._arena_point = assets.arena_integral
	assetData._glory_point = assets.glory_integral
	assetData._tower_point = assets.climbing_integral
	assetData._skill_point = assets.skill_point
	assetData._guild_donate = assets.guild_contribute
	assetData._guild_donate_total = assets.guild_total_contribute
	assetData._guild_donate_today_limit = assets.guild_contribute_limit
	assetData._skywarPoint = assets.sky_battle_point

	Notifier.dispatchCmd(CmdName.RSP_UPDATE_ROLE_ASSET)
end

--更新战队信息
function CharacterManager:updateTeam(team_info)
	teamData._lev = team_info.lev
	teamData._exp = team_info.exp
	teamData._fc = team_info.fc
	Notifier.dispatchCmd(CmdName.CHARACTER_RSP_UPDATE_TEAM)
end

--更新玩家名字
function CharacterManager:updateRoleName(name)
	baseData._hasCreateName = 1
	-- print("改名字")
	baseData._name = name
	Notifier.dispatchCmd(CmdName.RSP_UPDATE_ROLE_INFO)

	-- 发送fbid给服务端
    require("FbRewardMgr")
    
    if SdkManager:getSdkPlatform() == SdkHelper.channel.lunplay then
      local fbid = FbRewardMgr:getInstance():getId()
      if fbid ~= "" and fbid ~= nil then
        FbRewardMgr:getInstance():sendAutoFriend(fbid)
      end
    end
end

--更新玩家VIP信息
function CharacterManager:updateVIPdata(vip_lv, vip_exp)

	-- 升级则打开VIP面板
	local is_lv_up = false 
	if baseData._vip_lv~=-1 and vip_lv>baseData._vip_lv then
		is_lv_up = true
	end
	local oldVipLev = baseData._vip_lv
	local oldVipExp = baseData._vip_exp

	baseData._vip_lv = vip_lv
	baseData._vip_exp = vip_exp
	Notifier.dispatchCmd(CmdName.VIP_INFO_UPDATE,{oldVipLev = oldVipLev,oldVipExp = oldVipExp})

	if is_lv_up == true then

		--当前显示的不是VIP面板，则弹出VIP面板
		if WindowCtrl:getInstance():getCurFirshWinName() ~= CmdName.Vip_View then
			WindowCtrl:getInstance():open(CmdName.Vip_View)
		end
	end
end

--更新充值付费信息
function CharacterManager:updatePayData(pay_goods_type, pay_end_day)
	baseData._pay_goods_type = pay_goods_type
	baseData._pay_end_day = pay_end_day
	Notifier.dispatchCmd(VipEvent.CB_UPDATE_SCENE)
end

--[[
    添加角色钻石
]]
function CharacterManager:addRoleDiamond(diamond)

	assetData._diamond = assetData._diamond + diamond

	if assetData._diamond < 0 then
		assetData._diamond = 0
	end

	Notifier.dispatchCmd(CmdName.RSP_UPDATE_ROLE_ASSET)
end

--[[
    添加角色体力
]]
function CharacterManager:addRolePhysical(physical)

	assetData:setPhysical( assetData:getPhysical() + physical )

	Notifier.dispatchCmd(CmdName.RSP_UPDATE_ROLE_ASSET)

end

-- 6分钟自动加体力
function CharacterManager:addAutoRolePhysical(physical)
	local physicalMax = CharacterDataProxy:getInstance():getLevPhysicalMax()
	if assetData:getPhysical() >= physicalMax then
		return
	end
	
	assetData:setPhysical( math.min(assetData:getPhysical() + physical,physicalMax) )
	Notifier.dispatchCmd(CmdName.RSP_UPDATE_ROLE_ASSET)
end

--凌晨5点刷新
function CharacterManager:refreshCharacter(info)
	print("info.combat_boss_num",info.combat_boss_num)
	self:getGuildData()._hasBeenFightNum = info.combat_boss_num
end

---------------------------------------------------
function CharacterManager:showAlert(txt)
    -- Notifier.dispatchCmd(LoginEvent.SHOW_ALERT,txt) --提示信息
end

--处理登陆时候的错误，区别于helper中的Helper.getErrStr
function CharacterManager:dealLoginError(errcode)
	if errcode == error_code_pb.msg_ret.err_zone_role_no_login then 
		Notifier.dispatchCmd(LoginEvent.SHOW_MSGBOX,
		{txt = "您的帳號出現異常，已被封號。\n如有問題請聯繫客服處理。",
			okBtnName = "退出",
			okFunc = function()
				 SceneCtrl:getInstance():reLogin()
			end})
	else
		Notifier.dispatchCmd(LoginEvent.SHOW_MSGBOX,
		{txt = "您的帳號出現異常:"..errcode.."\n如有問題請聯繫客服處理。",
			okBtnName = "退出",
			okFunc = function()
				 SceneCtrl:getInstance():reLogin()
			end})
	end
end

--[[
    是否同服玩家
]]
function CharacterManager:isSameServer(roleId)
	return loginData:getChannelId() == roleId.channel_id and 
			loginData:getZoneId() == roleId.zone_id
end