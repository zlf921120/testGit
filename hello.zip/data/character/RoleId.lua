--
-- Author: lvgansheng
-- Date: 2014-08-13 17:34:41
-- 角色ID

RoleId = class("RoleId")

RoleId.uin = 0         -- 角色唯一标识（目前等同于acct_id）
RoleId.channel_id = 0     -- 渠道ID
RoleId.zone_id =0       -- 区ID

function RoleId:create()
	local role_id = RoleId.new()
	return role_id
end


function RoleId:setData(uin, channel_id, zone_id)
	self.uin = uin       
	self.channel_id = channel_id     
	self.zone_id = zone_id    
end

--[[
    匹配
]]
function RoleId:match(other)
	return self.uin == other.uin and self.channel_id == other.channel_id and self.zone_id == other.zone_id
end

function RoleId:getKeyIdx()
	return string.format("%d_%d_%d",self.uin,self.channel_id,self.zone_id)
end
