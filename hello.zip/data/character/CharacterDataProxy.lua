
--角色 数据代理
CharacterDataProxy = class("CharacterDataProxy")

CharacterDataProxy.lev_physical_max = {} --战队等级 对应 体力上限

CharacterDataProxy.lev_physical_add = {} --战队等级 对应 体力购买量
CharacterDataProxy.lev_coin_add = {} --战队 金币购买量

CharacterDataProxy.buycout_diamon_physical = {} --购买次数 对应 购买体力 钻石消耗
CharacterDataProxy.buycout_diamon_coin = {} --购买次数 对应 购买金币 钻石消耗

CharacterDataProxy.buyCoinScene = nil --购买金币场景
CharacterDataProxy.buyCoinItemVoList = {} --购买金币条目表

CharacterDataProxy.checkPhysicalSceneVo = nil --检查体力状态 面板
CharacterDataProxy.scendPhysicalTimer = nil

CharacterDataProxy.mainSceneNewsTipList = {} --主场景 新消息提示 列表

CharacterDataProxy.isCanRefresh = 1

CharacterDataProxy.scrolBroadList = {} --滚屏缓冲池
CharacterDataProxy.guildChatCacheList = {} --公会聊天缓冲池
CharacterDataProxy.worldChatCacheList = {} --世界聊天缓冲池
CharacterDataProxy._isShowingScrolBroad = false

local __instance = nil
local _allowInstance = false

function CharacterDataProxy:ctor()
    if not _allowInstance then
		error("CharacterDataProxy is a singleton class")
	end
	self:init()
end

function CharacterDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = CharacterDataProxy.new()
		_allowInstance = false
	end

	return __instance
end

function CharacterDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function CharacterDataProxy:init()
	require "BuyCoinVo"
end

-----------------------------------------------------------
--获取当前角色的 唯一id
function CharacterDataProxy:getAcctKeyId()
	return CharacterManager:getInstance():getLoginData():getRoleId():getKeyIdx()
end

-- 获取购买体力 上限
function CharacterDataProxy:getBuyPhysicalMax()

	local vipLevelVo = VipDataProxy:getInstance():getCurVipLevelVo()
	return vipLevelVo.privilegeTbl[ VipPrivilegeType.BuyPhysical ].value
end
-- 获取 购买金币 上限
function CharacterDataProxy:getBuyCoinMax()
	local vipLevelVo = VipDataProxy:getInstance():getCurVipLevelVo()
	return vipLevelVo.privilegeTbl[ VipPrivilegeType.BuyCoin ].value
end
-- 获取 战队等级 对应 体力上限
function CharacterDataProxy:getLevPhysicalMax()

	local level = self:getTeamLev()
	return self.lev_physical_max[ level ]
end

-- 根据等级，获取 战队等级 对应 体力上限
function CharacterDataProxy:getLevPhysicalMaxByLev(lev)
	return self.lev_physical_max[ lev ]
end

function CharacterDataProxy:getCurLevPhysicalMax()
	return self.lev_physical_max[ self:getTeamLev() ] 
end

-- 获取 战队 体力增加量
function CharacterDataProxy:getLevPhysicalAdd()
	local level = self:getTeamLev()
	return self.lev_physical_add[ level ]
end

-- 传入旧等级+新等级，计算出中间体力的增长量
function CharacterDataProxy:getLevPhysicalAddByLev(old_lev, new_lev)
	-- local diff = new_lev - old_lev
	local add_value = 0
	for i=old_lev+1,new_lev do
		add_value = add_value + self.lev_physical_add[ i ]
	end 
	return add_value
end

-- 获取 战队 金币增加量
function CharacterDataProxy:getLevCoinAdd()

	local level = self:getTeamLev()
	return self.lev_coin_add[ level ]
end

-- 获取 购买[体力]次数 对应 钻石消耗
function CharacterDataProxy:getBuyCoutDiamonPhysical(cout)
	return self.buycout_diamon_physical[ cout ]
end

-- 获取 购买[金币]次数 对应 钻石消耗
function CharacterDataProxy:getBuyCoutDiamonCoin( cout )
	return self.buycout_diamon_coin[ cout ]
end

-- 获取 当前战队等级
function CharacterDataProxy:getTeamLev()
	return CharacterManager:getInstance():getTeamData():getLev()
end

-- 获取 当前VIP等级
function CharacterDataProxy:getVipLev()
	return CharacterManager:getInstance():getBaseData():getVipLv()
end
--------------------------------------------
function CharacterDataProxy:createBuyCoinItemVo()
	local ret = BuyCoinItemVo.new()
	table.insert(self.buyCoinItemVoList,ret)
	return ret
end

function CharacterDataProxy:getBuyCoinItemVoList()
	return self.buyCoinItemVoList
end

function CharacterDataProxy:clearBuyCoinItemVoList()
	for k,v in pairs(self.buyCoinItemVoList) do
		self.buyCoinItemVoList[ k ] = nil
	end
	self.buyCoinItemVoList = {}
end
---------------------------
function CharacterDataProxy:getBuyCoinSceneVo()
	if self.buyCoinScene == nil then
		self.buyCoinScene = BuyCoinSceneVo.new()
	end
	return self.buyCoinScene
end
-----------------------------
function CharacterDataProxy:getCheckPhysicalSceneVo()
	if self.checkPhysicalSceneVo == nil then
		self.checkPhysicalSceneVo = CheckPhysicalSceneVo.new()
	end
	return self.checkPhysicalSceneVo
end
--------------------------------------------------------
function CharacterDataProxy:getMainSceneNewsTipList()
	return self.mainSceneNewsTipList
end

--刷新购买金币
function CharacterDataProxy:refreshBuyCoinPhysical(info)
	if self.buyCoinScene ~= nil then
		self.buyCoinScene.hadBuyNum = info.coin_num
	end
	if self.checkPhysicalSceneVo ~= nil then
		self.checkPhysicalSceneVo.buyCout = info.physical_num
	end
end

function CharacterDataProxy:makeScrolCacheList(ext)
	-- print(" #self.scrolBroadList ",#self.scrolBroadList)

	for i=1,#ext do
		-- local testData = {}
	 --    testData.type = "txt"
	 --    testData.txt = ext[i]
	 --    local str = json.encode({testData})
	 	
	 	local v = string.gsub(ext[i],"\\u","|")
		table.insert(self.scrolBroadList,v)
	end

	ScrollBroad:show()
end

function CharacterDataProxy:makeGuildChatCacheList(ext,type)
	require "GuildPopChatView"
	for i,v in ipairs(ext) do
		if type == ChatArea.ORGANIZ and math.abs(ServerTimerManager:getInstance():getCurTime() - v.time) < 5 * 60 and Helper.mathCurRoId(v.from) == false then --公会
			local json1,json2 = ChatHelper.getJsonFromChatTxt(v.content,ItemHelper.colors.yellow,10000)
			if string.len(json1) > 0 then
				table.insert(self.guildChatCacheList,{name=v.from_name,level=v.team_lev,txt=json1})
			end
			-- if string.len(json2) > 0 then
			-- 	table.insert(self.guildChatCacheList,{name=v.from_name,level=v.team_lev,txt=json2,isSecondLine=1})
			-- end
		end
	end
	-- 
	GuildPopChatView:getInstance().progressTimer()
end

function CharacterDataProxy:makeWorldChatCacheList(ext,type)
	require "GuildPopChatView"
	for i,v in ipairs(ext) do
		if type == ChatArea.WORLD and math.abs(ServerTimerManager:getInstance():getCurTime() - v.time) < 5 * 60 and Helper.mathCurRoId(v.from) == false then --世界
			local json1,json2 = ChatHelper.getJsonFromChatTxt(v.content,ItemHelper.colors.yellow,10000)
			if string.len(json1) > 0 then
				if Helper.hasSensitiveWord(v.content) == false then
					print("世界冒泡無遮罩詞！！")
					table.insert(self.worldChatCacheList,{name=v.from_name,level=v.team_lev,txt=json1})
				end
			end
			-- if string.len(json2) > 0 then
			-- 	table.insert(self.guildChatCacheList,{name=v.from_name,level=v.team_lev,txt=json2,isSecondLine=1})
			-- end
		end
	end
	GuildPopChatView:getInstance():setChatArea(ChatArea.WORLD)
	-- GuildPopChatView:show()
	GuildPopChatView:getInstance().progressTimer()
end


function CharacterDataProxy:getScrolCacheList()
	return self.scrolBroadList
end

function CharacterDataProxy:getGuildChatCacheList()
	return self.guildChatCacheList
end

function CharacterDataProxy:getWorldChatCacheList()
	return self.worldChatCacheList
end

--获取最终恢复满 体力的时间戳
function CharacterDataProxy:getRecoverAllPhysicalTime()
	local dp = CharacterDataProxy:getInstance()
	local assetData = CharacterManager:getInstance():getAssetData()
	local sceneVo = dp:getCheckPhysicalSceneVo()
	local physicalMax = dp:getLevPhysicalMax()
	local physicalNow = assetData:getPhysical()
	if physicalMax > physicalNow then
		dis = physicalMax - physicalNow
		-- print(" sceneVo.lastTime ",sceneVo.lastTime,dis)

		local nowTime = ServerTimerManager:getInstance():getCurTime()
		local coutTimeAll = (6 * 60 - (nowTime - sceneVo.lastTime)) + (dis - 1) * 6 * 60
		return coutTimeAll + nowTime
	else
		return 0
	end
end

--刷新定时器
function CharacterDataProxy.refreshPhysicalTimer()
	local cm = CharacterManager:getInstance()
	local dp = CharacterDataProxy:getInstance()

	local sceneVo = dp:getCheckPhysicalSceneVo()
	local nowTime = ServerTimerManager:getInstance():getCurTime()
    local addPhys = math.floor( ( nowTime - sceneVo.lastTime ) / 360 )--加的体力数
    local disTime = ( nowTime - sceneVo.lastTime ) % 360  --剩余秒数
    if addPhys ~= 0 then
        sceneVo.lastTime = nowTime - disTime
        cm:addAutoRolePhysical(addPhys)
    end
end
--重置定时器
function CharacterDataProxy.resetPhysicalTimer()
	local dp = CharacterDataProxy:getInstance()
	local sceneVo = dp:getCheckPhysicalSceneVo()
    local nowTime = ServerTimerManager:getInstance():getCurTime()
    local disTime = ( nowTime - sceneVo.lastTime ) % 360  --剩余秒数
    sceneVo.countTime = 6 * 60 - disTime   --倒计时数

	Timer.setTimer(sceneVo.countTime,function()
        CharacterDataProxy:getInstance().refreshPhysicalTimer()
        TimerManager.removeTimer(CharacterDataProxy:getInstance().refreshPhysicalTimer)
        TimerManager.addTimer(1000 * 6 * 60,CharacterDataProxy:getInstance().refreshPhysicalTimer,true)
    end)
end