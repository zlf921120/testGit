
----------------------------------------------------------------------------
-- 角色 本地xls数据读取类
CharacterLocalReader = class("CharacterLocalReader")

local __instance = nil
local _allowInstance = false
local _hasLoad = false

function CharacterLocalReader:ctor()
    if not _allowInstance then
		error("CharacterLocalReader is a singleton class")
	end
	self:init()
end

function CharacterLocalReader:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = CharacterLocalReader.new()
		_allowInstance = false
	end

	return __instance
end

function CharacterLocalReader:init()
	require "fnt_vip_data_pb"
	require "fnt_physical_data_pb"
	require "CharacterDataProxy"
	require "VipDataProxy"
	require "VipCfg"
end

--获取 本地数据并创建值对象 
function CharacterLocalReader:loadInProxy()

	if _hasLoad then return end--只加载一次
	_hasLoad = true

	local dp = CharacterDataProxy:getInstance()

	local pbdata = FileUtils.readConfigFile("fnt_physical_data.dat")
	
    local msg = fnt_physical_data_pb.fnt_physical_data()
    msg:ParseFromString(pbdata)

	--战队 购买体力 金币 上限
    local levelUnit = msg.lev_physical_limit_rows
	for i=1,table.getn(levelUnit) do
		local item = levelUnit[i]
		if item.lev then
			dp.lev_physical_max[ item.lev ] = item.physical
			dp.lev_physical_add[ item.lev ] = item.add_physical
			dp.lev_coin_add[ item.lev ] = item.add_coin
		end
	end

	--购买体力 和 金币 对应的 钻石值
	local diamonUnit = msg.loss_gold_rows
	for i=1,table.getn(diamonUnit) do
		local item = diamonUnit[i]
		if item.num then
			dp.buycout_diamon_physical[ item.num ] = item.diamon_physical --购买次数 对应 购买体力 钻石消耗
			dp.buycout_diamon_coin[ item.num ] = item.diamon_coin --购买次数 对应 购买金币 钻石消耗
		end
	end

-----------------------------------------------------------------------------------------------
	local dpVip = VipDataProxy:getInstance()
	local pbdata = FileUtils.readConfigFile("fnt_vip_data.dat")
	local msg = fnt_vip_data_pb.fnt_vip_data()
    msg:ParseFromString(pbdata)

	--vip 特权
    local vipUnit = msg.vip_privilege_rows
	for i=1,table.getn(vipUnit) do
		local v = vipUnit[i]
		if v.lev then

			local vipLevelVo = dpVip:createVipLevelVo()
			vipLevelVo.level = v.lev
			vipLevelVo.expMax = v.vip_exp
			vipLevelVo.giftId = v.gift_id

			if v.gift_id ~= 0 then
				local giftVo = dpVip:createVipGiftVo()
				giftVo.id = v.vip_gift
				vipLevelVo.giftVo = giftVo
			end

			if v.is_dungeon_sweep == 1 then
				local privilegeVo = dpVip:createPrivilegeVo( VipPrivilegeType.DungeonDiff2Dadius, 3 )  --副本 困难扫荡3次
				vipLevelVo.privilegeTbl[ VipPrivilegeType.DungeonDiff2Dadius ] = privilegeVo
			end

			if v.dungeon_radius_diff1_10 == 1 then
				local privilegeVo = dpVip:createPrivilegeVo( VipPrivilegeType.DungeonDiff1Dadius, 10 )  --副本 普通扫荡10次
				vipLevelVo.privilegeTbl[ VipPrivilegeType.DungeonDiff1Dadius ] = privilegeVo
			end

			if v.is_arean_reset == 1 then
				local privilegeVo = dpVip:createPrivilegeVo( VipPrivilegeType.ArenaCD, 1 )  --消除竞技场 CD
				vipLevelVo.privilegeTbl[ VipPrivilegeType.ArenaCD ] = privilegeVo
			end

			if v.guild_worship3 == 1 then
				local privilegeVo = dpVip:createPrivilegeVo( VipPrivilegeType.GuildWorship3, 1 )  --公会膜拜 豪华类型
				vipLevelVo.privilegeTbl[ VipPrivilegeType.GuildWorship3 ] = privilegeVo
			end

			vipLevelVo.privilegeTbl[ VipPrivilegeType.BuyCoin ] 		= dpVip:createPrivilegeVo( VipPrivilegeType.BuyCoin, v.buy_coin )		--购买金币
			vipLevelVo.privilegeTbl[ VipPrivilegeType.BuyPhysical ] 	= dpVip:createPrivilegeVo( VipPrivilegeType.BuyPhysical, v.buy_physical )			--购买体力
			vipLevelVo.privilegeTbl[ VipPrivilegeType.DungeonDiff2 ]	= dpVip:createPrivilegeVo( VipPrivilegeType.DungeonDiff2, v.buy_dungeon_diff2 )	--副本 困难 战斗次数
			vipLevelVo.privilegeTbl[ VipPrivilegeType.DungeonDiff3 ]	= dpVip:createPrivilegeVo( VipPrivilegeType.DungeonDiff3, v.buy_dungeon_diff3 )		--副本 噩梦 战斗次数
			vipLevelVo.privilegeTbl[ VipPrivilegeType.BuyArenaReset ]	= dpVip:createPrivilegeVo( VipPrivilegeType.BuyArenaReset, v.arena_max )				--购买 竞技场重置 次数
			vipLevelVo.privilegeTbl[ VipPrivilegeType.MysteryShop ]		= dpVip:createPrivilegeVo( VipPrivilegeType.MysteryShop, v.mystery_refresh ) 		--购买 刷新 神秘商店
			vipLevelVo.privilegeTbl[ VipPrivilegeType.ResetTowerLimit ]	= dpVip:createPrivilegeVo( VipPrivilegeType.ResetTowerLimit, v.reset_tower ) 			--购买 恶魔塔重置 次数
			vipLevelVo.privilegeTbl[ VipPrivilegeType.ResetGloryLimit ]	= dpVip:createPrivilegeVo( VipPrivilegeType.ResetGloryLimit, v.glory_reset )				--购买 星空神殿重置 次数
			vipLevelVo.privilegeTbl[ VipPrivilegeType.GuildWorshipMax ] = dpVip:createPrivilegeVo( VipPrivilegeType.GuildWorshipMax, v.worship_max )			--膜拜 上限
			vipLevelVo.privilegeTbl[ VipPrivilegeType.GuildDonateCoin ] = dpVip:createPrivilegeVo( VipPrivilegeType.GuildDonateCoin, v.donate_coin ) --公会捐献金币上限

			dpVip:setVipLevelVo(vipLevelVo)
		end
	end

	--vip 特权展示
	local viewUnit = msg.vip_view_rows
	for i=1,table.getn(viewUnit) do
		local v = viewUnit[i]
		if v.lev then
			local vipLevelVo = dpVip:getVipLevelVoById(v.lev)
			table.insert(vipLevelVo.viewPrivilegeTbl,v.privilege_content)
		end
	end

	--vip 礼包项展示
	local giftUnit = msg.vip_gift_rows
	for i=1,#giftUnit do
		local v = giftUnit[i]
		if v.gift_id then
			local vipLevelVo = dpVip:getLevelVoByGiftId(v.gift_id)
			if vipLevelVo ~= nil then
				local giftItemVo = dpVip:createVipGiftItemVo()
				giftItemVo.giftId = v.gift_id
				giftItemVo.baseId = v.base_id
				giftItemVo.num = v.num
				table.insert(vipLevelVo.giftVo.giftItemTbl,giftItemVo)
			end
		end
	end
end
