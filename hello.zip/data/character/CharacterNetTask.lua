
--角色 网络助手
CharacterNetTask = class("CharacterNetTask")

local __instance = nil
local _allowInstance = false

function CharacterNetTask:ctor()
    if not _allowInstance then
		error("CharacterNetTask is a singleton class")
	end
	self:init()
end

function CharacterNetTask:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = CharacterNetTask.new()
		_allowInstance = false
	end

	return __instance
end

function CharacterNetTask:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function CharacterNetTask:init()
	require "physical_pb"
	require "BuyAssetCfg"
	require "CharacterCfg"
	--注册网络事件
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.buy_physical_info_rsp,"handleCheckBuyPhysical()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.physical_add_rsp,"handleBuyPhysical()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.buy_coin_info_rsp,"handleCheckBuyCoin()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.coin_add_rsp,"handleBuyCoin()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.coin_add_base_rsp,"handleMultBuyCoin()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.physical_time_rsp,"handlePhysicalStatus()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.role_change_sexname_rsp,"handleChangeNameOrGender()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.role_activate_rsp,"handleRoleActivate()")
    Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.limit_physical_reward_rsp,"onGetLimitPhysicalRsp()")

end

--请求 体力描述
function CharacterNetTask:requestPhysicalStatus()
	print("----------------------requestPhysicalStatus-----------------------")
	local physical_time_req = physical_pb.physical_time_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.physical_time_req,physical_time_req)
end

--响应 体力描述
function handlePhysicalStatus(pkg)
	print("----------------------handlePhysicalStatus-----------------------")
	local physical_time_rsp = physical_pb.physical_time_rsp()
    physical_time_rsp:ParseFromString(pkg)

    if physical_time_rsp.ret == error_code_pb.msg_ret.success then

    	-- ComSender:getInstance():dealExtInfo(physical_time_rsp.ext)

    	-- local sceneVo = CharacterDataProxy:getInstance():getCheckPhysicalSceneVo()
    	-- -- sceneVo.time = physical_time_rsp.time
    	-- sceneVo.buyCout = physical_time_rsp.physical_num
    	-- sceneVo.lastTime = physical_time_rsp.last_time

    	-- local assetData = CharacterManager:getInstance():getAssetData()
    	-- assetData._physical = physical_time_rsp.physical

      	print(" physical_time_rsp.time ",os.date("%Y/%m/%d %X",physical_time_rsp.time))
      	print(" physical_time_rsp.last_time ",os.date("%Y/%m/%d %X",physical_time_rsp.last_time))

    	-- Notifier.dispatchCmd(CharacterEvent.RSP_PHYSICAL_SYNC)
    	
    	-- __instance:setPhyStatus(physical_time_rsp.physical_num, physical_time_rsp.physical, 
    	-- 						physical_time_rsp.last_time, physical_time_rsp.time)
   	end
end

function CharacterNetTask:setPhyStatus(srv_physical_num, srv_last_time)

	local sceneVo = CharacterDataProxy:getInstance():getCheckPhysicalSceneVo()
	-- sceneVo.time = physical_time_rsp.time
	sceneVo.buyCout = srv_physical_num
	sceneVo.lastTime = srv_last_time

	-- local assetData = CharacterManager:getInstance():getAssetData()
	-- assetData._physical = srv_physical

  	-- print(" physical_time_rsp.time ", srv_time)
  	-- print(" physical_time_rsp.last_time ",srv_last_time)

	-- Notifier.dispatchCmd(CharacterEvent.RSP_PHYSICAL_SYNC)
end

--请求 购买前 的体力状态
function CharacterNetTask:requestCheckBuyPhysical()

	print("----------------------requestCheckBuyPhysical-----------------------")
	local buy_physical_info_req = physical_pb.buy_physical_info_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.buy_physical_info_req,buy_physical_info_req)
end

--响应 购买前 的体力状态
function handleCheckBuyPhysical(pkg)

	local buy_physical_info_rsp = physical_pb.buy_physical_info_rsp()
    buy_physical_info_rsp:ParseFromString(pkg)

    print("----------------------handleCheckBuyPhysical-----------------------",buy_physical_info_rsp.ret)

    if buy_physical_info_rsp.ret == error_code_pb.msg_ret.success then

    	ComSender:getInstance():dealExtInfo(buy_physical_info_rsp.ext)

    	local hadBuyNum = buy_physical_info_rsp.num
    	local diamon = buy_physical_info_rsp.spend
    	local physical = buy_physical_info_rsp.physical

    	if hadBuyNum < CharacterDataProxy:getInstance():getBuyPhysicalMax() then
    		WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,
	    		{txt = string.format(BuyAssetCfg.buyPhysicalTip,diamon,physical,hadBuyNum),
	         	okFunc = function() 
	         		CharacterNetTask:getInstance():requestBuyPhysical()
	         	end})
    	else
    		--__instance:showAlert(BuyAssetCfg.err_buy_physcial_coutfull)
    		WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()
                -- --发送充值请求
                -- require "VipNetTask"
                -- VipNetTask:getInstance():requestVipInfo()
                WindowCtrl:getInstance():open(CmdName.Vip_View)
                
            end, txt = string.format(BuyAssetCfg.UpLevelVipTip),
            okBtnName = "查看"})
		end
    	
    else
   		__instance:showAlert(Helper.getErrStr(buy_physical_info_rsp.ret))
    end
end

--请求 购买体力
function CharacterNetTask:requestBuyPhysical()

	print("----------------------requestBuyPhysical-----------------------")
	local physical_add_req = physical_pb.physical_add_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.physical_add_req,physical_add_req)
end

--响应 购买体力
function handleBuyPhysical(pkg)
	
	local physical_add_rsp = physical_pb.physical_add_rsp()
    physical_add_rsp:ParseFromString(pkg)

    print("----------------------handleBuyPhysical-----------------------",physical_add_rsp.ret)
    if physical_add_rsp.ret == error_code_pb.msg_ret.success then
    	
    	ComSender:getInstance():dealExtInfo(physical_add_rsp.ext)

    	local physical = physical_add_rsp.physical
    	local diamon = physical_add_rsp.spend
    	--更新购买体力时间
    	local sceneVo = CharacterDataProxy:getInstance():getCheckPhysicalSceneVo()
	    sceneVo.time = physical_add_rsp.now_time
	    sceneVo.buyCout = sceneVo.buyCout + 1
	    sceneVo.lastTime = physical_add_rsp.now_time

    	local assetData = CharacterManager:getInstance():getAssetData()
    	assetData._diamond = assetData._diamond - diamon
    	assetData._physical = assetData._physical + physical

    	Notifier.dispatchCmd(CmdName.RSP_UPDATE_ROLE_ASSET)

   		WindowCtrl:getInstance():close(CmdName.Comm_MsgBox) --关闭窗体
    else
   		__instance:showAlert(Helper.getErrStr(physical_add_rsp.ret))
    end
end

--请求 购买前 金币状态
function CharacterNetTask:requestCheckBuyCoin()

	print("----------------------requestCheckBuyCoin-----------------------")
	local buy_coin_info_req = physical_pb.buy_coin_info_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.buy_coin_info_req,buy_coin_info_req)
end
--响应 购买前 金币状态
function handleCheckBuyCoin(pkg)

	print("----------------------handleCheckBuyCoin-----------------------")
	local buy_coin_info_rsp = physical_pb.buy_coin_info_rsp()
    buy_coin_info_rsp:ParseFromString(pkg)

    if buy_coin_info_rsp.ret == error_code_pb.msg_ret.success then

    	ComSender:getInstance():dealExtInfo(buy_coin_info_rsp.ext)

    	local hadBuyNum = buy_coin_info_rsp.num
    	local lastBuyCout = buy_coin_info_rsp.last_num

		local dp = CharacterDataProxy:getInstance()
		dp:clearBuyCoinItemVoList()
		dp.isCanRefresh = 0
		
		local lists = buy_coin_info_rsp.lists --保存历史记录

		for i=1,table.getn(lists) do
	    	local itemVo = dp:createBuyCoinItemVo()
			itemVo.diamon = lists[i].gold
			itemVo.coin = lists[i].coin
	    end

		local sceneVo = dp:getBuyCoinSceneVo()
		sceneVo.hadBuyNum = hadBuyNum
		sceneVo.lastTimeBuyNum = lastBuyCout
		sceneVo.coin = dp:getLevCoinAdd()
		sceneVo.diamon = dp:getBuyCoutDiamonCoin( sceneVo.hadBuyNum )
	
		WindowCtrl:getInstance():open(CmdName.Character_buyCoin)
    else
   		__instance:showAlertBuyCoin(Helper.getErrStr(buy_coin_info_rsp.ret))
    end
end

--请求 购买金币
function CharacterNetTask:requestBuyCoin()

	print("----------------------requestBuyCoin-----------------------")
	local coin_add_req = physical_pb.coin_add_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.coin_add_req,coin_add_req)
end

--响应 购买金币
function handleBuyCoin(pkg)
	print("----------------------handleBuyCoin-----------------------")
	local coin_add_rsp = physical_pb.coin_add_rsp()
    coin_add_rsp:ParseFromString(pkg)

    if coin_add_rsp.ret == error_code_pb.msg_ret.success then

    	ComSender:getInstance():dealExtInfo(coin_add_rsp.ext)

    	local lists = coin_add_rsp.lists

	    local diamon = coin_add_rsp.lists[#lists].spend
	    local coin = coin_add_rsp.lists[#lists].coin
	    local newcoin = coin_add_rsp.lists[#lists].newcoin
	    local isBoom = false
	    if coin * 2 == newcoin then print("暴擊!!!!") isBoom = true end

	   	local assetData = CharacterManager:getInstance():getAssetData()
	    assetData._diamond = assetData._diamond - diamon
	    assetData._gold = assetData._gold + newcoin

	    local dp = CharacterDataProxy:getInstance()
	   	--dp:clearBuyCoinItemVoList()

	    local sceneVo = dp:getBuyCoinSceneVo()
	    sceneVo.hadBuyNum = sceneVo.hadBuyNum + 1

	    --sceneVo.lastTimeBuyNum = lastBuyCout
		sceneVo.coin = dp:getLevCoinAdd()
		sceneVo.diamon = dp:getBuyCoutDiamonCoin( sceneVo.hadBuyNum )

	    for i=1,table.getn(lists) do

	    	local itemVo = dp:createBuyCoinItemVo()
			--itemVo.id = 1 
			itemVo.diamon = lists[i].spend
			itemVo.coin = lists[i].newcoin

	    end
		--dp:setBuyCoinItemVo(itemVo)

		Notifier.dispatchCmd(BuyAssetEvent.CB_UPDATE_SCENE)
	    Notifier.dispatchCmd(CmdName.RSP_UPDATE_ROLE_ASSET)
	    -- Notifier.dispatchCmd(BuyAssetEvent.CB_SHOW_COIN_RECODE)  --展示记录
	    Notifier.dispatchCmd(BuyAssetEvent.CB_SHOW_ANIM,{ num = newcoin,isBoom = isBoom})

	else
		__instance:showAlertBuyCoin(Helper.getErrStr(coin_add_rsp.ret))
   	end
end

--请求 连续购买金币 
function CharacterNetTask:requestMultBuyCoin(num)
	print("----------------------requestMultBuyCoin-----------------------",num)
	local coin_add_base_req = physical_pb.coin_add_base_req()
	coin_add_base_req.num = num
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.coin_add_base_req,coin_add_base_req)
end

--响应 连续购买金币
function handleMultBuyCoin(pkg)
	
	local coin_add_base_rsp = physical_pb.coin_add_base_rsp()
    coin_add_base_rsp:ParseFromString(pkg)

    print("----------------------handleMultBuyCoin-----------------------",coin_add_base_rsp.ret )

    if coin_add_base_rsp.ret == error_code_pb.msg_ret.success then

    	ComSender:getInstance():dealExtInfo(coin_add_base_rsp.ext)

	    local dp = CharacterDataProxy:getInstance()
	    --dp:clearBuyCoinItemVoList()

	    local assetData = CharacterManager:getInstance():getAssetData()

	    local sceneVo = dp:getBuyCoinSceneVo()

	    local lists = coin_add_base_rsp.lists
	    local isBoom = false
	    local newcoin = 0
	    for i=1,table.getn(lists) do

	    	if lists[i].coin * 2 == lists[i].newcoin then 
	    		isBoom = true
	    	end
	    	newcoin = newcoin + lists[i].newcoin

		    sceneVo.hadBuyNum = sceneVo.hadBuyNum + 1  --更新场景

	    	local itemVo = dp:createBuyCoinItemVo() --购买记录
			--itemVo.id = i
			itemVo.diamon = lists[i].spend
			itemVo.coin = lists[i].newcoin
			--dp:setBuyCoinItemVo(itemVo)

		    assetData._diamond = assetData._diamond - lists[i].spend --更新资产
		    assetData._gold = assetData._gold + lists[i].newcoin
	    end

	    sceneVo.coin = dp:getLevCoinAdd()
		sceneVo.diamon = dp:getBuyCoutDiamonCoin( sceneVo.hadBuyNum )
		
	    Notifier.dispatchCmd(BuyAssetEvent.CB_UPDATE_SCENE)
	    Notifier.dispatchCmd(CmdName.RSP_UPDATE_ROLE_ASSET)
	    -- Notifier.dispatchCmd(BuyAssetEvent.CB_SHOW_COIN_RECODE)  --展示记录
	    Notifier.dispatchCmd(BuyAssetEvent.CB_SHOW_ANIM,{num = newcoin, isBoom = isBoom})

	else
		__instance:showAlertBuyCoin(Helper.getErrStr(coin_add_base_rsp.ret))
	end

	WindowCtrl:getInstance():close(CmdName.Character_buyMultCoin)
end

--请求创建性别
function CharacterNetTask:requestCreateGender(flag)
	print("----------------------requestCreateGender-----------------------",flag)
	local role_change_sexname_req = role_pb.role_change_sexname_req()
	role_change_sexname_req.type = CharacterCfg.Gender
	role_change_sexname_req.sex = flag
	role_change_sexname_req.name = ""
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.role_change_sexname_req,role_change_sexname_req)
end

--请求创建姓名
function CharacterNetTask:requestCreateName(name)
	print("----------------------requestCreateName-----------------------",name)
	local role_change_sexname_req = role_pb.role_change_sexname_req()
	role_change_sexname_req.type = CharacterCfg.Name
	role_change_sexname_req.name = name
	role_change_sexname_req.sex = 1
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.role_change_sexname_req,role_change_sexname_req)
end

--发出修改头像协议 
function CharacterNetTask:sendChangeHeadReq(face_id)
	local change_req = role_pb.role_change_sexname_req()
	change_req.type = CharacterCfg.Face
	change_req.face_id = face_id
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.role_change_sexname_req,change_req)
end

--响应创建性别 或 名字
function handleChangeNameOrGender(pkg)
	
	local role_change_sexname_rsp = role_pb.role_change_sexname_rsp()
    role_change_sexname_rsp:ParseFromString(pkg)
    print("----------------------handleChangeNameOrGender-----------------------",role_change_sexname_rsp.ret)
    if role_change_sexname_rsp.ret == error_code_pb.msg_ret.success then
    	if role_change_sexname_rsp.type == CharacterCfg.Gender then
    		CharacterManager:getInstance():getBaseData()._sex = role_change_sexname_rsp.sex

    		Notifier.dispatchCmd(CharacterEvent.CB_CLOSE_GENDER)
    	elseif role_change_sexname_rsp.type == CharacterCfg.Name then
    		CharacterManager:getInstance():updateRoleName(role_change_sexname_rsp.name)
    		
    		Notifier.dispatchCmd(CharacterEvent.CB_CLOSE_NAME)
    	elseif role_change_sexname_rsp.type == CharacterCfg.Face then
    		Alert:show("修改頭像成功")
			CharacterManager:getInstance():getBaseData()._faceId = role_change_sexname_rsp.face_id
    		Notifier.dispatchCmd(CmdName.UpdateHeadIconSuc, role_change_sexname_rsp.face_id) 
    	end

    	ComSender:getInstance():dealExtInfo(role_change_sexname_rsp.ext)

    else
    	local area = GuideDataProxy:getInstance().showCreateNameArea
    	local txt = Helper.getErrStr(role_change_sexname_rsp.ret)
    	if area == GuideCreateNameArea.BattleScene then
    		Notifier.dispatchCmd(CharacterEvent.SHOW_ERR_ALERT,txt)
    	elseif area == GuideCreateNameArea.MainScene then
    		Alert:show(txt)
    	end
    	Notifier.dispatchCmd(CharacterEvent.CB_UPDATE_CREATE_NAME_PANEL)
	end
end

--请求开启新功能
function CharacterNetTask:requestRoleActivate(activateId)
	print("-------------------requestRoleActivate------------------",activateId)
	local role_activate_req = role_pb.role_activate_req()
	role_activate_req.activate_id = activateId
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.role_activate_req,role_activate_req)
end
--响应开启新功能
function handleRoleActivate(pkg)
	local role_activate_rsp = role_pb.role_activate_rsp()
    role_activate_rsp:ParseFromString(pkg)
    print("------------------------handleRoleActivate--------------",role_activate_rsp.ret)
	if role_activate_rsp.ret == error_code_pb.msg_ret.success then
		ComSender:getInstance():dealExtInfo(role_activate_rsp.ext)
	else
		-- Alert:show(Helper.getErrStr(role_activate_rsp.ret))
	end
end

function CharacterNetTask:reqGetLimitPhysical()
    local req = physical_pb.limit_physical_reward_req()
    ComSender:getInstance():send(proto_cmd_pb.msg_cmd.limit_physical_reward_req, req)
end

--响应限时体力奖励
function onGetLimitPhysicalRsp(protoData)

    local physicalRsp = physical_pb.limit_physical_reward_rsp()
    physicalRsp:ParseFromString(protoData)

    if physicalRsp.ret ~= error_code_pb.msg_ret.success then
        Helper.showErrMsg(physicalRsp.ret)
        return
    end

    ComSender:getInstance():dealExtInfo(physicalRsp.ext)
    CharacterManager:getInstance():updateRoleAssets(physicalRsp.assets)
    TaskManager:getInstance():setPhysicalGetTime(physicalRsp.time)

    --通知界面更新
    Notifier.dispatchCmd(CmdName.UpdateTaskView)

    --更新绿点
    Notifier.dispatchCmd(CmdName.UpdateGreenTipsPoint)

    -- WindowCtrl:getInstance():open(CmdName.Finish_Task_View, {task_id =  task_info.mode.id, 
    --                               open_from = TaskHelper.send_reward_from.task_item})

end

----------------------------------------------------------------------
--提示信息
function CharacterNetTask:showAlert(txt)
    -- Notifier.dispatchCmd(CmdName.MAINUI_SHOW_ALERT,txt) --提示信息
    Alert:show(txt)
end

function CharacterNetTask:showAlertBuyCoin(txt)
	-- Notifier.dispatchCmd(BuyAssetEvent.BUYCOIN_SHOW_ALERT,txt) --提示信息
	Alert:show(txt)
end