--聊天
ChatLocalReader = class("ChatLocalReader")
local __instance = nil
local _allowInstance = false
local _hasLoad = false

function ChatLocalReader:ctor()
    if not _allowInstance then
		error("ChatLocalReader is a singleton class")
	end
	self:init()
end

function ChatLocalReader:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = ChatLocalReader.new()
		_allowInstance = false
	end

	return __instance
end

function ChatLocalReader:init()
	require "fnt_keyword_data_pb"
end

function ChatLocalReader:loadInProxy()

	if _hasLoad then return end --只加载一次
	_hasLoad = true

	local pbdata = FileUtils.readConfigFile("fnt_keyword_data.dat")
    local msg = fnt_keyword_data_pb.fnt_keyword_data()
    msg:ParseFromString(pbdata)

    local wordUnit = msg.keyword_info_rows
    for i, v in pairs(wordUnit) do
    	if v.word and v.word ~= "" then
    		table.insert(ChatHelper.sensitiveTbl,v.word)
    	end
    end
end