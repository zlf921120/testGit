--聊天渲染逻辑
ChatRenderMgr = {}

--添加聊天条目
ChatRenderMgr.pushChatItem = function(listView,chatVo)

	ChatRenderMgr.checkRemoveItem(listView) --清除缓存
	local itemGrid = ChatItemGrid:create(chatVo)

	listView:pushBackCustomItem(itemGrid)

	listView:refreshView()
	listView:scrollToBottom(0.2,false)
end
-- --添加GM反馈条目
-- ChatRenderMgr.pushGmFbItem = function(listView,chatVo)
		
-- 	ChatRenderMgr.checkRemoveItem(listView) --清除缓存
-- 	local itemGrid = ChatItemGrid:create(fbVo)

-- 	listView:pushBackCustomItem(itemGrid)

-- 	listView:refreshView()
-- 	listView:scrollToBottom(0.2,false)
-- end

--检测 渲染聊天项
function ChatRenderMgr.checkRendChatList(listWorld,listOrganiz,listGm)

	local dp = ChatDataProxy:getInstance()
	local tmpList = dp:getChatCacheList()

	local idx = 1

	local function step_create()
		local paramVo = tmpList[idx]
		if paramVo ~= nil then
			local listView = nil
			local item = nil
			if paramVo.area == ChatArea.WORLD then
				ChatHelper.setChatArea(paramVo.area)
				item = ChatItemGrid:create(paramVo.chatVo)
				listView = listWorld
			elseif paramVo.area == ChatArea.ORGANIZ then
				item = ChatItemGrid:create(paramVo.chatVo)
				listView = listOrganiz
			elseif paramVo.area == ChatArea.GM then
				item = ChatItemGrid:create(paramVo.chatVo)
				listView = listGm
			end
			listView:pushBackCustomItem(item)
			listView:refreshView()
			listView:scrollToBottom(0.2,false)

			table.remove( dp:getChatCacheList(), 1)
		else
			listWorld:stopAllActions()
		end
	end

	listWorld:stopAllActions()
	listWorld:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
		CCCallFunc:create(step_create),
		CCDelayTime:create(0.15))))
end


ChatRenderMgr.makeRefreshRtf = function(listView)
	local len = listView:getItems():count()
	for i=1,len do
		if listView:getItem(i-1).rtf1 then
			listView:getItem(i-1).rtf1:refresh()
		end
		if listView:getItem(i-1).rtf2 then
			listView:getItem(i-1).rtf2:refresh()
		end
	end
end

--GM 自动回复
ChatRenderMgr.pushGMAutoFbItem = function(listView)
	
    local autoGmChatVo = ChatDataProxy:getInstance().gmAutoChatVo
    autoGmChatVo.time = ServerTimerManager:getInstance():getCurTime() -- 玩家时间
    local itemAutoGrid = ChatItemGrid:create(autoGmChatVo)
    listView:pushBackCustomItem(itemAutoGrid)
    listView:refreshView()
    listView:scrollToBottom(0.2,false)
end

--检查是否需要删除聊天记录
ChatRenderMgr.checkRemoveItem = function(listView)
	
	if listView:getItems():count() > 15 then
		listView:removeItem(0)
	end
end

--添加表情面板
local FacePanelWidget = nil
ChatRenderMgr.addFacePanel = function(container,x,y)
	if FacePanelWidget == nil then
		-- local FacePanel = ChatFacePanel:getInstance()
		FacePanelWidget = ChatFacePanel:getInstance()
		FacePanelWidget:setPosition(ccp(x,y))
	end
end

--展示表情面板
ChatRenderMgr.showFacePanel = function(container)
	-- FacePanelWidget:forcePage()
	container:addChild(FacePanelWidget,10)
end

--隐藏表情面板
ChatRenderMgr.hideFacePanel = function(container)
	if FacePanelWidget ~= nil then
		container:removeChild(FacePanelWidget,true)
	end
end

--清理缓存
ChatRenderMgr.clear = function(listWorld,listOrganiz,listGm)
	if FacePanelWidget ~= nil then
		FacePanelWidget = nil
	end

	listWorld:removeAllItems() --清理聊天记录 
	listOrganiz:removeAllItems()
	listGm:removeAllItems() 

	ChatNetTask:getInstance():clear()
end
