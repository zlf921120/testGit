
--玩家信息 值对象

ChatPlayerVo = class("ChatPlayerVo")
ChatPlayerVo.id = 0				--id
ChatPlayerVo.playerId = 0		--玩家id
ChatPlayerVo.zoneId = 0 		--玩家区id
ChatPlayerVo.channelId = 0 		--玩家渠道id
ChatPlayerVo.name = ""			--名称
ChatPlayerVo.level = 0			--等级
ChatPlayerVo.guild = ""		--帮会
ChatPlayerVo.txt = ""			--聊天内容
ChatPlayerVo.time = 0 			--聊天时间
ChatPlayerVo.roleFlag = 0 		--角色标识
ChatPlayerVo.fightValue = 0		--战斗力
ChatPlayerVo.heroList = nil
ChatPlayerVo.sex = 0
ChatPlayerVo.param = nil --参数

--GM 反馈
ChatFreeBackVo = class("ChatFreeBackVo")
ChatFreeBackVo.id = 0 
ChatFreeBackVo.type = 0 --反馈类型
ChatFreeBackVo.name = ""			--名称
ChatFreeBackVo.level = 0			--等级
ChatFreeBackVo.organiz = ""		--帮会
ChatFreeBackVo.title = ""
ChatFreeBackVo.txt = ""
ChatFreeBackVo.time = 0
ChatFreeBackVo.answer = ""
ChatFreeBackVo.faceId = 0
