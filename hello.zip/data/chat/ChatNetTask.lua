
--聊天网络代理
ChatNetTask = class("ChatNetTask")
ChatNetTask._hasGetHistoryWorld = false
ChatNetTask._hasGetHistoryOrganiz = false
ChatNetTask._hasGetHistoryGm = false

local __instance = nil
local _allowInstance = false

function ChatNetTask:ctor()
    if not _allowInstance then
		error("ChatNetTask is a singleton class")
	end
	self:init()
end

function ChatNetTask:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = ChatNetTask.new()
		_allowInstance = false
	end
	return __instance
end

function ChatNetTask:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function ChatNetTask:init()
	require "ChatDataProxy"
	require "chat_pb"
	require "proto_cmd_pb"
	require "proto_cmd_2_pb"
	--注册事件
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.chat_say_rsp,"handleChatRoom()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.chat_info_rsp,"handleChatCycle()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.chat_fb_info_rsp,"handleGmChatCycle()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.chat_fb_rsp,"handleGmChat()")
	
	Notifier.regist(ChatEvent.LEVUP_TEAM,function(param)
		if param[1] < 12 and param[2] >= 12 then --开放 聊天 功能 要推送一条 系统消息
			local dp = ChatDataProxy:getInstance()
			local list = dp:getSystemCacheList()
			Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.chat)
			table.insert(list,dp:createSystemChatVo("親愛的玩家，你現在已經可以在世界頻道聊天了哦~快和大家打聲招呼吧！"))
		end
	end)
end

--请求 世界聊天信息
function ChatNetTask:requestWorldChat(txt)

	print( " ---------requestWorldChat---------  ",txt)

	local chat_say_req = chat_pb.chat_say_req()
	chat_say_req.content = txt
	chat_say_req.type = ChatArea.WORLD --世界聊天
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.chat_say_req,chat_say_req)
end

--响应   聊天回调
function handleChatRoom(pkg)

	local chat_say_rsp = chat_pb.chat_say_rsp()
	chat_say_rsp:ParseFromString(pkg)

	print("---------------handleChatRoom--------------",chat_say_rsp.ret)

	if chat_say_rsp.ret == error_code_pb.msg_ret.success then

		local dp = ChatDataProxy:getInstance()

		local playerVo = dp:createChatVo()
		print("##chat_say_rsp.msgs",#chat_say_rsp.msgs)
		local idx = math.max(#chat_say_rsp.msgs-14,1)
		for i= idx,#chat_say_rsp.msgs do
			local v = chat_say_rsp.msgs[i]

			playerVo.role_id = RoleId:create()
			playerVo.role_id:setData(v.from.uin, v.from.channel_id,v.from.zone_id)
			playerVo.id = playerVo.role_id:getKeyIdx()
			playerVo.txt = v.content
			playerVo.faceId = v.face_id
			playerVo.level = v.team_lev
			playerVo.name = v.from_name
			playerVo.time = v.time
			if v.guild_id > 0 then
				playerVo.roleFlag = RoleFlag.Guild
				playerVo.param["join_guild_flag"] = JoinStatus.APPLY_JOIN
				if v.guild_is_activation == 1 and playerVo.level > v.guild_apply_lev - 1 then
					playerVo.param["join_guild_flag"] = JoinStatus.QUICI_JOIN
				end
				playerVo.param["guild_id"] = v.guild_id
			else
				playerVo.roleFlag = v.label
			end
			playerVo.guild = v.team_guild
			playerVo.fightValue = v.team_fc
			playerVo.sex = v.sex
			playerVo.txt = chat_say_rsp.msgs[i].content
			playerVo.faceId = chat_say_rsp.msgs[i].face_id
			playerVo.level = chat_say_rsp.msgs[i].team_lev
			playerVo.name = chat_say_rsp.msgs[i].from_name
			playerVo.time = chat_say_rsp.msgs[i].time
			playerVo.roleFlag = chat_say_rsp.msgs[i].label
			playerVo.guild = chat_say_rsp.msgs[i].team_guild
			playerVo.fightValue = chat_say_rsp.msgs[i].team_fc
			playerVo.sex = chat_say_rsp.msgs[i].sex
			playerVo.pet_star = chat_say_rsp.msgs[i].sprite_stars

			local heroList = {}
			for j=1,#v.chat_heros do
				local hero = v.chat_heros[j]
				table.insert(heroList,{ hero_id = hero.hero_id , stars = hero.hero_stars })
			end
			playerVo.heroList = heroList

			local param = {area = chat_say_rsp.type,chatVo = playerVo}
			table.insert(dp:getChatCacheList(),param)
		end

		Notifier.dispatchCmd(ChatEvent.UPDATE_CHAT_LIST)

		ComSender:getInstance():dealExtInfo(chat_say_rsp.ext)
	else
		Alert:show(Helper.getErrStr(chat_say_rsp.ret))
	end
end

--请求 轮询 世界聊天
function ChatNetTask:requestWorldChatCycle()

	print( " ---------requestWorldChatCycle---------  ")
	local chat_info_req = chat_pb.chat_info_req()
	if self._hasGetHistoryWorld == false then
	 	self._hasGetHistoryWorld = true 
	 	chat_info_req.is_relogin = 1
	else
		chat_info_req.is_relogin = 0
	end
	
	chat_info_req.type = ChatArea.WORLD --世界聊天
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.chat_info_req,chat_info_req)
end

--响应 轮询聊天
function handleChatCycle(pkg)

	print("----------handleChatCycle-----------")
	local chat_info_rsp = chat_pb.chat_info_rsp()
	chat_info_rsp:ParseFromString(pkg)

	if chat_info_rsp.ret == error_code_pb.msg_ret.success then

		local dp = ChatDataProxy:getInstance()
		local playerVo = dp:createChatVo()



		local idx = math.max(#chat_info_rsp.msgs-14,1)
		print("##chat_info_rsp.msgs",#chat_info_rsp.msgs)
		for i=idx,#chat_info_rsp.msgs do

			

			while true do
				
				if chat_info_rsp.type == ChatArea.WORLD then
					if Helper.hasSensitiveWord(chat_info_rsp.msgs[i].content) then
						print("有遮罩詞，開始跳了",Helper.hasSensitiveWord(chat_info_rsp.msgs[i].content))
						if CharacterManager:getInstance():getLoginData():getRoleId():match(chat_info_rsp.msgs[i].from) == false then
							break
						end
					end
				end

				local v = chat_info_rsp.msgs[i]
				local playerVo = dp:createChatVo()
				playerVo.role_id = RoleId:create()
				playerVo.role_id:setData(v.from.uin, v.from.channel_id,v.from.zone_id)
				playerVo.id = playerVo.role_id:getKeyIdx()
				playerVo.txt = v.content
				playerVo.faceId = v.face_id
				playerVo.level = v.team_lev
				playerVo.name = v.from_name
				playerVo.time = v.time
				if v.guild_id > 0 then
					playerVo.roleFlag = RoleFlag.Guild
					playerVo.param["join_guild_flag"] = JoinStatus.APPLY_JOIN
					if v.guild_is_activation == 1 and playerVo.level > v.guild_apply_lev - 1 then
						playerVo.param["join_guild_flag"] = JoinStatus.QUICI_JOIN
					end
					playerVo.param["guild_id"] = v.guild_id
				else
					playerVo.roleFlag = v.label
				end
				playerVo.guild = v.team_guild
				playerVo.fightValue = v.team_fc
				playerVo.sex = v.sex
				playerVo.txt = chat_info_rsp.msgs[i].content
				playerVo.faceId = chat_info_rsp.msgs[i].face_id
				playerVo.level = chat_info_rsp.msgs[i].team_lev
				playerVo.name = chat_info_rsp.msgs[i].from_name
				playerVo.time = chat_info_rsp.msgs[i].time
				playerVo.roleFlag = chat_info_rsp.msgs[i].label
				playerVo.guild = chat_info_rsp.msgs[i].team_guild
				playerVo.fightValue = chat_info_rsp.msgs[i].team_fc
				playerVo.sex = chat_info_rsp.msgs[i].sex
				playerVo.pet_star = chat_info_rsp.msgs[i].sprite_stars

				local heroList = {}
				for j=1,#v.chat_heros do
					local hero = v.chat_heros[j]
					table.insert(heroList,{ hero_id = hero.hero_id , stars = hero.hero_stars })
				end
				playerVo.heroList = heroList

				local param = {area = chat_info_rsp.type,chatVo = playerVo}
				table.insert( dp:getChatCacheList(), param )
				break
			end
		end
		--公会聊天冒泡
		CharacterDataProxy:getInstance():makeGuildChatCacheList(chat_info_rsp.msgs,chat_info_rsp.type)
		--世界聊天冒泡
		CharacterDataProxy:getInstance():makeWorldChatCacheList(chat_info_rsp.msgs,chat_info_rsp.type)
-----------检查 系统消息 推送-----------------------------------------------
		local sysList = dp:getSystemCacheList()
		if #sysList > 0 then 
			for i=1,#sysList do
				sysList[i].id = i + 1000 --重新编辑id
				-- dp:setChatVo(sysList[i])

				local param = {area = ChatArea.WORLD,chatVo = sysList[i]}
				table.insert( dp:getChatCacheList(), param )
			end
			dp._systemCacheList = {}
		end
----------------------------------------------------------
		Notifier.dispatchCmd(ChatEvent.UPDATE_CHAT_LIST)

		ComSender:getInstance():dealExtInfo(chat_info_rsp.ext)
	end

end

--发送帮会聊天信息
function ChatNetTask:requestOrganizChat(txt)

	print( " ---------requestOrganizChat---------  ",txt)
	local chat_say_req = chat_pb.chat_say_req()
	chat_say_req.content = txt
	chat_say_req.type = ChatArea.ORGANIZ
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.chat_say_req,chat_say_req)
end


--请求 轮询 公会聊天
function ChatNetTask:requestOrganizChatCycle()

	print( " ---------requestOrganizChatCycle---------  ")
	local chat_info_req = chat_pb.chat_info_req()
	if self._hasGetHistoryOrganiz == false then
	 	self._hasGetHistoryOrganiz = true 
	 	chat_info_req.is_relogin = 1
	else
		chat_info_req.is_relogin = 0
	end
	chat_info_req.type = ChatArea.ORGANIZ --公会聊天
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.chat_info_req,chat_info_req)
end

-- 请求 私人 聊天
function ChatNetTask:requestPrivateChat(txt)

	print( " ---------requestPrivateChat---------  ",txt)

	local chat_say_req = chat_pb.chat_say_req()
	chat_say_req.content = txt
	chat_say_req.type = ChatArea.PRIVATE
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.chat_say_req,chat_say_req)
end

function ChatNetTask:clear()
	self._hasGetHistoryOrganiz = false
	self._hasGetHistoryWorld = false
	self._hasGetHistoryGm = false
end
--请求玩家信息
function ChatNetTask:requestPlayerInfo(id)

end

--请求 GM 轮询
function ChatNetTask:requestGmChatCycle(t)
	
	print(" --------------requestGmChatCycle--------------------- ",t)
	local chat_fb_info_req = chat_pb.chat_fb_info_req()
	if self._hasGetHistoryGm == false then
		self._hasGetHistoryGm = true
		chat_fb_info_req.is_relogin = 1
	else
		chat_fb_info_req.is_relogin = 0
	end
	chat_fb_info_req.fbtype = t
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.chat_fb_info_req,chat_fb_info_req)
end

--响应 GM 轮询
function handleGmChatCycle(pkg)

	local chat_fb_info_rsp = chat_pb.chat_fb_info_rsp()
	chat_fb_info_rsp:ParseFromString(pkg)

	print("----------------handleGmChatCycle-------------------------",chat_fb_info_rsp.ret)
	if chat_fb_info_rsp.ret == error_code_pb.msg_ret.success then

		local dp = ChatDataProxy:getInstance()
		
		print(" #chat_fb_info_rsp.msgs ",#chat_fb_info_rsp.msgs)
		for i=1,table.getn(chat_fb_info_rsp.msgs) do

			local fbVo = dp:createGmFbVo()
			fbVo.id = chat_fb_info_rsp.msgs[i].mid
			fbVo.faceId = 10001
			fbVo.isGm = 1
			fbVo.level = 100
			fbVo.name = "小精靈"
			fbVo.heroList = {}
			fbVo.roleFlag = RoleFlag.Gm
			fbVo.fightValue = 1000000
			fbVo.type = chat_fb_info_rsp.msgs[i].fbtype
			fbVo.title = chat_fb_info_rsp.msgs[i].title
			fbVo.txt = chat_fb_info_rsp.msgs[i].answer
			if fbVo.txt == "" then fbVo.txt = "您的问题已提交，GM会在2个工作日内对您回复。" end
			fbVo.time = chat_fb_info_rsp.msgs[i].time
			-- fbVo.answer = chat_fb_info_rsp.msgs[i].answer
			-- dp:setGmFbVo(fbVo)
			--如果该玩家是 下线后 再上线 才收到该信息 要自己推自己的问题
			if ChatDataProxy:getInstance():isHasBeenSend(chat_fb_info_rsp.msgs[i].content) == false then
		        local curPlayerVo = dp:getChatVoById( CharacterDataProxy:getInstance():getAcctKeyId() ) --单列
		        curPlayerVo.txt = chat_fb_info_rsp.msgs[i].content
		        curPlayerVo.time = chat_fb_info_rsp.msgs[i].time

				local param = {area = ChatArea.GM,chatVo = curPlayerVo }
				Notifier.dispatchCmd(ChatEvent.PUSH_CHATITEM,param)
			end

			local param = {area = ChatArea.GM,chatVo = fbVo}
			Notifier.dispatchCmd(ChatEvent.PUSH_CHATITEM,param)
		end

		Notifier.dispatchCmd(ChatEvent.UPDATE_CHAT_LIST)

		ComSender:getInstance():dealExtInfo(chat_fb_info_rsp.ext)

	end
end

--请求GM反馈
function ChatNetTask:requestGmChat(t,title,content)

	print("-----------------requestGmChat----------------------- ",t,title,content)
	local chat_fb_req = chat_pb.chat_fb_req()
	chat_fb_req.fbtype = t
	chat_fb_req.title = title
	chat_fb_req.content = content
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.chat_fb_req,chat_fb_req)
end

--响应GM反馈
function handleGmChat(pkg)

	local chat_fb_rsp = chat_pb.chat_fb_rsp()
	chat_fb_rsp:ParseFromString(pkg)

	print("---------------------handleGmChat-----------------",chat_fb_rsp.ret)

	if chat_fb_rsp.ret == error_code_pb.msg_ret.success then

		ComSender:getInstance():dealExtInfo(chat_fb_rsp.ext)
	end
end
