--表情面板
ChatFacePanel = class("ChatFacePanel",function()
    return Layout:create()
end)
ChatFacePanel.__index = ChatFacePanel
ChatFacePanel._widget     = nil
ChatFacePanel.uiLayer    = nil

local __instance = nil

function ChatFacePanel:getInstance()
    if not __instance then
        __instance = ChatFacePanel.new()
        __instance:init()
        __instance:retain()
    end
    return __instance   
end
-------------------响应事件--------------------------------------
local lastPageIdxImg = nil
local lastFaceTypeImgBtn = nil
local lastPage = nil

-- local function event_btn_face(pSender,eventType)
--     if eventType == ComConstTab.TouchEventType.ended then
--         local id = tolua.cast(pSender,"Button"):getTag()
--         Notifier.dispatchCmd(ChatEvent.INSERT_FACE,ChatFaceSet[id]) --通知主场景 插入表情占位文本
--     end
-- end

local function event_btn_delete(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        Notifier.dispatchCmd(ChatEvent.DELETE_TXT) --通知主场景 要删字符
    end
end

local function event_btn_normal(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then

        __instance.pageFace:setVisible(true)
        __instance.pageFace:setZOrder(4)

        if pSender ~= lastFaceTypeImgBtn then
            lastFaceTypeImgBtn:loadTexture("bg_16.png",UI_TEX_TYPE_PLIST)
            pSender:loadTexture("bg_15.png",UI_TEX_TYPE_PLIST)
            lastFaceTypeImgBtn = pSender

            local pageMax = 1
            for i=1,3 do
                local imgIdx = tolua.cast(__instance._widget:getChildByName(string.format("img_idx_%d",i)),"ImageView")
                imgIdx:setVisible(i <= pageMax )
            end

            lastPage:setVisible(false)
            lastPage:setZOrder(2)
            lastPage = __instance.pageFace
        end
    end
end

-- local function event_btn_more(pSender,eventType)
--     if eventType == ComConstTab.TouchEventType.ended then
--         -- if pSender ~= lastFaceTypeImgBtn then
--             -- lastFaceTypeImgBtn:loadTexture("bg_16.png",UI_TEX_TYPE_PLIST)
--             -- pSender:loadTexture("bg_15.png",UI_TEX_TYPE_PLIST)
--             -- lastFaceTypeImgBtn = pSender


--         -- end
--     end
-- end

local function event_btn_vip(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then

        __instance:initPage(2)

        __instance.pageVip:setVisible(true)
        __instance.pageVip:setZOrder(4)

        if pSender ~= lastFaceTypeImgBtn then
            lastFaceTypeImgBtn:loadTexture("bg_16.png",UI_TEX_TYPE_PLIST)
            pSender:loadTexture("bg_15.png",UI_TEX_TYPE_PLIST)
            lastFaceTypeImgBtn = pSender

            local pageMax = 1
            for i=1,3 do
                local imgIdx = tolua.cast(__instance._widget:getChildByName(string.format("img_idx_%d",i)),"ImageView")
                imgIdx:setVisible(i <= pageMax )
            end

            lastPage:setVisible(false)
            lastPage:setZOrder(2)
            lastPage = __instance.pageVip
        end
    end
end

local function event_page_change(pSender,eventType)
    if eventType == ComConstTab.PageEventType.turning then
        local pageView = tolua.cast(pSender, "PageView")
        local idx = pageView:getCurPageIndex() + 1

        local nowPageIdxImg = tolua.cast(__instance._widget:getChildByName(string.format("img_idx_%d",idx)),"ImageView")
        if nowPageIdxImg == lastPageIdxImg then return end
        
        nowPageIdxImg:loadTexture("chat_p1.png",UI_TEX_TYPE_PLIST)
        lastPageIdxImg:loadTexture("chat_p2.png",UI_TEX_TYPE_PLIST)
        lastPageIdxImg = nowPageIdxImg
    end
end
----------------------初始化--------------------------------------
function ChatFacePanel:initPage(t)
    if self.initPageTbl[t] == nil then
        self.initPageTbl[t] = "done"

        if t == 1 then --普通表情

            local faceId = 1
            local pageMax = 1
            for i=1,3 do
                local imgIdx = tolua.cast(self._widget:getChildByName(string.format("img_idx_%d",i)),"ImageView")
                imgIdx:setVisible(i <= pageMax )
            end

            for i=1,pageMax do
                local facePage = tolua.cast(ChatDataProxy:getInstance():getFacePageWidget():clone(),"Layout")
                self.pageFace:addPage(facePage)
                for j=1,24 do
                    local btn = tolua.cast(facePage:getChildByName(string.format("btn_face%d",j)),"Button") 
                    if faceId <= 24 then
                        btn:loadTextureNormal(string.format("face/%03d1.png",faceId),UI_TEX_TYPE_PLIST)
                        btn:setTag(faceId)       --标记id
                        faceId = faceId + 1
                        btn:addTouchEventListener(function(pSender,eventType)
                            if eventType == ComConstTab.TouchEventType.ended then
                                local id = tolua.cast(pSender,"Button"):getTag()
                                Notifier.dispatchCmd(ChatEvent.INSERT_FACE,ChatFaceSet[id]) --通知主场景 插入表情占位文本
                            end
                        end)   
                    else
                        btn:removeFromParent()
                    end    
                end
            end
        elseif t == 2 then --vip表情

            local faceId = 100 --vip从 100 起
            local pageMax = 1
            for i=1,3 do
                local imgIdx = tolua.cast(self._widget:getChildByName(string.format("img_idx_%d",i)),"ImageView")
                imgIdx:setVisible(i <= pageMax )
            end

            local faceCout = 1
            for i=1,pageMax do
                local facePage = tolua.cast(ChatDataProxy:getInstance():getFacePageWidget():clone(),"Layout")
                self.pageVip:addPage(facePage)
                for j=1,24 do
                    local btn = tolua.cast(facePage:getChildByName(string.format("btn_face%d",j)),"Button") 
                    if faceCout < 17 then
                        btn:loadTextureNormal(string.format("face/%03d1.png",faceId),UI_TEX_TYPE_PLIST)
                        btn:setTag(faceCout)       --标记id
                        faceId = faceId + 1
                        faceCout = faceCout + 1
                        btn:addTouchEventListener(function(pSender,eventType)
                            if eventType == ComConstTab.TouchEventType.ended then

                                if CharacterDataProxy:getInstance():getVipLev() < 1 then
                                    Alert:show("開啟VIP後即可使用哦")
                                else
                                    local id = tolua.cast(pSender,"Button"):getTag()
                                    Notifier.dispatchCmd(ChatEvent.INSERT_FACE,ChatVipFaceSet[id]) --通知主场景 插入表情占位文本
                                end
                            end
                        end)   
                    else
                        btn:removeFromParent()
                    end    
                end
            end
        end

    end
end

function ChatFacePanel:init()
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/chat/face.plist")
    self._widget = GUIReader:shareReader():widgetFromJsonFile("chat/FacePanel.ExportJson")
    self:addChild(self._widget)

    self.initPageTbl = {}

    self.pageFace = tolua.cast(self._widget:getChildByName("page_face"),"PageView")
    self.pageFace:addEventListenerPageView(event_page_change)

    self.pageVip = tolua.cast(self._widget:getChildByName("page_vip"),"PageView")
    self.pageVip:addEventListenerPageView(event_page_change)

    lastPage = self.pageFace
    lastPageIdxImg = tolua.cast(self._widget:getChildByName("img_idx_1"),"ImageView")

    self:initPage(1)

    local btnDelete = tolua.cast(self._widget:getChildByName("btn_delete"),"Button")
    btnDelete:addTouchEventListener(event_btn_delete)

    self.btnNormal = tolua.cast(self._widget:getChildByName("img_normal"),"ImageView")
    self.btnNormal:addTouchEventListener(event_btn_normal)
    self.btnVip = tolua.cast(self._widget:getChildByName("img_vip"),"ImageView")
    self.btnVip:addTouchEventListener(event_btn_vip)
    -- self.btnMore = tolua.cast(self._widget:getChildByName("img_more"),"ImageView")
    -- self.btnMore:addTouchEventListener(event_btn_more)
    lastFaceTypeImgBtn = self.btnNormal
end

function ChatFacePanel:forcePage()

    self.pageFace:setVisible(true)
    self.pageFace:setZOrder(4)

    if lastFaceTypeImgBtn and self.btnNormal ~= lastFaceTypeImgBtn then
        lastFaceTypeImgBtn:loadTexture("bg_16.png",UI_TEX_TYPE_PLIST)
        self.btnNormal:loadTexture("bg_15.png",UI_TEX_TYPE_PLIST)
        lastFaceTypeImgBtn = self.btnNormal

        lastPage:setVisible(false)
        lastPage:setZOrder(2)
        lastPage = self.pageFace
    end
end