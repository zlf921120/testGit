--聊天助手类
require "json"
ChatHelper = {}

ChatHelper.sensitiveTbl = {} --敏感词表
ChatHelper.ChatArea = nil    --聊天的区域

--通过普通文本创建 图文混排
function ChatHelper.createRtfFormTxt(txt,forceColor)

  local jsonTxt1,jsonTxt2 = ChatHelper.getJsonFromChatTxt(txt,forceColor)
	----------------------------------------------------
  local rtf1 = nil
  local rtf2 = nil

  if string.len(jsonTxt1) > 0 then
     rtf1 = ChatHelper.createNodeRtf(jsonTxt1,650,50,ccp(0,0))
  end
  if string.len(jsonTxt2) > 0 then
      rtf2 = ChatHelper.createNodeRtf(jsonTxt2,650,50,ccp(0,0))
  end
	return rtf1,rtf2
end

function ChatHelper.setChatArea(area)
    ChatHelper.ChatArea = area
end

--根据聊天文本转化成json
function ChatHelper.getJsonFromChatTxt(txt,forceColor,firstLineWidth,secondLineWidth)
  

      if ChatHelper.ChatArea ~= ChatArea.WORLD then
          --过滤敏感词
          for k,v in pairs(ChatHelper.sensitiveTbl) do
            txt = string.gsub(txt,v,"*")
          end
      end
      ChatHelper.ChatArea = nil  --还原

    txt = string.gsub(txt,[[\n]],"") --过滤换行
    --分离字符串
    local tblStr = Helper.separate(txt)

    local firstLine = {coutWidth = 0 , content = "" ,limitWidth = firstLineWidth or 590}
    local secondLine = {coutWidth = 0 , content = "" ,limitWidth = secondLineWidth or 440}

    local function limitStrWidth(str,obj,tbl,idx)

        if obj.coutWidth >= obj.limitWidth then return obj.coutWidth end

        if str == "/" then  --表情符
            local t1 = tbl[idx + 1] or "" --后面一个字符
            local t2 = tbl[idx + 2] or "" --后面一个字符
            local t3 = tbl[idx + 3] or "" --后面一个字符

            local strFace = ChatFace[ t1..t2..t3 ]
            if strFace ~= nil then --表情存在

                obj.coutWidth = obj.coutWidth + ChatFaceWidth[ t1..t2..t3 ]

                str = string.format("|%s|",strFace)
                table.remove(tbl,idx + 1) --删除后三个元素
                table.remove(tbl,idx + 1)
                table.remove(tbl,idx + 1)
            end
        else  --普通文本
          if str:byte() > 128 then --中文
              obj.coutWidth = obj.coutWidth + 22
          else --英文 
              obj.coutWidth = obj.coutWidth + 12
          end
        end
        --截取长度
        if obj.coutWidth < obj.limitWidth then
            obj.content = obj.content .. str
        end

        return obj.coutWidth
    end

    local isAddSuffix = false --是否加后缀
    for k,v in ipairs(tblStr) do
      if limitStrWidth(tblStr[k],firstLine,tblStr,k) > firstLine.limitWidth then --换行

         if limitStrWidth(tblStr[k],secondLine,tblStr,k) > secondLine.limitWidth then --尾行
              isAddSuffix = true
         end
      end
    end

    if isAddSuffix then
        secondLine.content = secondLine.content .. "..." --加省略后缀
    end
  -----------------------------------------------------------
  --通过普通文本 获取 富文本 json
  local function getJson4Rtf(txt)
    local jsonTable = {}
    local arr = Utils.Split(txt,"|")

    for i,elementStr in ipairs(arr) do
      local elementTbl = {}

      if string.find(elementStr,"/%d%d%d") ~= nil then  --表情元素
        if string.sub(elementStr,1,2) == "/0" then  --普通 表情
            elementTbl.param = {normalFace=1}
        end

        elementTbl.type = "anim"
        elementTbl.name = "face/"..string.sub(elementStr,2)
        elementTbl.playTime = 0.5
        elementTbl.isLoop = -1
      else                        --文本元素
        elementTbl.type = "txt"
        elementTbl.txt = elementStr
        elementTbl.fontSize = 22
        elementTbl.color = forceColor
      end
      table.insert(jsonTable,elementTbl)
    end
    return json.encode(jsonTable)
  end
  ----------------------------------------------------
  local jsonTxt1 = ""
  local jsonTxt2 = ""
  if string.len(firstLine.content) > 0 then
      jsonTxt1 = getJson4Rtf(firstLine.content,forceColor)
  end
  if string.len(secondLine.content) > 0 then
      jsonTxt2 = getJson4Rtf(secondLine.content,forceColor)
  end
  return jsonTxt1,jsonTxt2
end

--根据 tbl 创建富文本
function ChatHelper.createRtf(luaTable,width,height,anchorPoint)
  
  local rtf = RichText:create()
  rtf:ignoreContentAdaptWithSize(false)
  rtf:setAnchorPoint(anchorPoint or ccp(0,0.5))
  rtf:setSize(CCSize(width,height))
  
  for i,v in ipairs(luaTable) do
      local item = nil
      if v.txt ~= nil then
        v.color = v.color or ccc3(251,241,160)
        v.fontName = v.fontName or ""
        v.fontSize = v.fontSize or 22
        item = RichElementText:create(i,v.color,255,v.txt,v.fontName,v.fontSize)
        rtf:pushBackElement(item)
      elseif v.img ~= nil then
        local node = CCSprite:createWithSpriteFrameName(v.path)
        if node ~= nil then
          item = RichElementCustomNode:create(i,v.color,255,node)
          rtf:pushBackElement(item)
        end
      elseif v.anim ~= nil then
        local node = DisplayUtil.createAnimWithPlayTime(v.name,v.playTime,v.isLoop)
        if node ~= nil then
          item = RichElementCustomNode:create(i,v.color,255,node)
          rtf:pushBackElement(item)
        end
      end
  end
  return rtf
end

--根据json创建富文本
function ChatHelper.createTextRtf(jsonStr,width,height,anchorPoint,isUnicode)

  local rtf = RichText:create()
  if width == 0 then
    rtf:ignoreContentAdaptWithSize(true)
  else
    rtf:ignoreContentAdaptWithSize(false)
    rtf:setSize(CCSize(width,height))
  end
  rtf:setAnchorPoint(anchorPoint or ccp(0,1))

  local luaTable = json.decode(jsonStr)
  for i,v in ipairs(luaTable) do

    v.color = v.color or "FBF1A0"
    -- v.a = 255 
    v.r = tonumber(string.sub(v.color,1,2),16)
    v.g = tonumber(string.sub(v.color,3,4),16)
    v.b = tonumber(string.sub(v.color,5,6),16)
    v.fontName = v.fontName or ""
    v.fontSize = v.fontSize or 20

      local item = nil
      if v.type == "txt" then
        v.fontName = v.fontName or ""
        v.fontSize = v.fontSize or 22
        if isUnicode then
          v.txt = Helper.muliStrConvUtf8(v.txt)
          -- print(" 换后 ",v.txt )
        end
        v.txt = string.gsub(v.txt or "","┌","\"") --英文双引号 直接替换
        v.txt = string.gsub(v.txt or "","┬"," ") --英文空格 直接替换
        item = RichElementText:create(i,ccc3(v.r,v.g,v.b),255,v.txt,v.fontName,v.fontSize)
        rtf:pushBackElement(item)
      elseif v.type == "img" then
        local node = CCSprite:createWithSpriteFrameName(v.path)
        if node ~= nil then
          item = RichElementCustomNode:create(i,ccc3(v.r,v.g,v.b),255,node)
          rtf:pushBackElement(item)
        end
      elseif v.type == "anim" then
        local node = DisplayUtil.createAnimWithPlayTime(v.name,v.playTime,v.isLoop)
        if node ~= nil then
          item = RichElementCustomNode:create(i,ccc3(v.r,v.g,v.b),255,node)
          if v.param and v.param["normalFace"] == 1 then
              node:setScale(0.8)
          end
          rtf:pushBackElement(item)
        end
      end
  end
  return rtf
end

function ChatHelper.createTextRtfs(jsonStr,width,height,anchorPoint)

  local widget = Widget:create()
  local linesTable = json.decode(jsonStr)

  local lineHeight = 0
  for line=1,#linesTable do

      local rtf = RichText:create()
      rtf:ignoreContentAdaptWithSize(false)
      rtf:setAnchorPoint(anchorPoint or ccp(0,0))
      -- rtf:setSize(CCSize(width,height))
      
      local lineStr = ""
      for i,v in ipairs(linesTable[line]) do
        v.color = v.color or "FBF1A0"
        v.r = tonumber(string.sub(v.color,1,2),16)
        v.g = tonumber(string.sub(v.color,3,4),16)
        v.b = tonumber(string.sub(v.color,5,6),16)
        v.fontName = v.fontName or ""
        v.fontSize = v.fontSize or 20

          local item = nil
          if v.type == "txt" then
            v.fontName = v.fontName or ""
            v.fontSize = v.fontSize or 22
            v.txt = string.gsub(v.txt or "","┌","\"") --英文双引号 直接替换
            v.txt = string.gsub(v.txt or "","┬"," ") --英文空格 直接替换

            lineStr = lineStr .. v.txt

            item = RichElementText:create(i,ccc3(v.r,v.g,v.b),255,v.txt,v.fontName,v.fontSize)
            rtf:pushBackElement(item)
          elseif v.type == "img" then
            local node = CCSprite:createWithSpriteFrameName(v.path)
            if node ~= nil then
              item = RichElementCustomNode:create(i,ccc3(v.r,v.g,v.b),255,node)
              rtf:pushBackElement(item)
            end
          elseif v.type == "anim" then
            local node = DisplayUtil.createAnimWithPlayTime(v.name,v.playTime,v.isLoop)
            if node ~= nil then
              item = RichElementCustomNode:create(i,ccc3(v.r,v.g,v.b),255,node)
              rtf:pushBackElement(item)
            end
          end
      end

      
      local rtfSize,rtfHeight = Helper.makeStrSize(lineStr,750)
      -- print(" lineStr ",lineStr,rtfHeight )
      rtf:setSize(rtfSize)
      if string.len(lineStr) == 0 then
          lineHeight = lineHeight + 22 + 2
      else
          lineHeight = lineHeight + rtfHeight + 2
      end
      
      rtf:setPosition(ccp(0,-lineHeight))
      widget:setSize(CCSize(width, widget:getSize().height + rtf:getSize().height ))
      widget:addChild(rtf)
  end
  return widget,lineHeight
end

--根据json创建富文本(非RichText控件)
function ChatHelper.createNodeRtf(jsonStr,width,height,anchorPoint)

  local rtf = CCNode:create()
  rtf:setAnchorPoint(anchorPoint)
  rtf:setContentSize(CCSize(width,height))
  rtf.animTbl = {}

  local luaTable = json.decode(jsonStr)
  for i,v in ipairs(luaTable) do

    v.color = v.color or "FBF1A0"
    v.a = 255 
    v.r = tonumber(string.sub(v.color,1,2),16)
    v.g = tonumber(string.sub(v.color,3,4),16)
    v.b = tonumber(string.sub(v.color,5,6),16)
    v.fontName = v.fontName or ""
    v.fontSize = v.fontSize or 20
    
    local item = nil
    if v.type == "txt" then
      local label = Label:create()
      label:setText(v.txt)
      label:setFontSize(v.fontSize)
      label:setColor(ccc3(v.r,v.g,v.b))
      label:setFontName(v.fontName)
      label:setAnchorPoint(ccp(0,0))
      rtf:addChild(label)
    elseif v.type == "img" then
      local img = CCSprite:createWithSpriteFrameName(v.path)
      if img then
        img:setAnchorPoint(ccp(0,0))
        rtf:addChild(img)
      end
    elseif v.type == "anim" then
      local node = DisplayUtil.createAnimWithPlayTime(v.name,v.playTime,v.isLoop)
      if node then
        node:setAnchorPoint(ccp(0,0))
        if v.param and v.param["normalFace"] == 1 then
            node:setScale(0.8)
        end
        rtf:addChild(node)
      end
      table.insert(rtf.animTbl,{node=node,name=v.name,playTime=v.playTime,isLoop=v.isLoop})
    end
  end
-------------------------------------------------------
  function rtf:refresh()
    for i=1,#rtf.animTbl do
        local v = rtf.animTbl[i]
        DisplayUtil.makeSpriteWithPlayTime(v.node,v.name,v.playTime,v.isLoop)
    end
  end  
--------reloadData-----------------------------------
  local childArr = rtf:getChildren()
  local offsetX = 0
  if childArr then
    for i=0,childArr:count() - 1 do
      local child = childArr:objectAtIndex(i)
      child:setPosition(ccp(offsetX,0))
      offsetX = offsetX + child:getContentSize().width
    end
  end
  return rtf
end
