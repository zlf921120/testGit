
--聊天事件

ChatEvent =
{
	PUSH_CHATITEM 	= "chat_push_chatitem",		--推出一条聊天信息
	PUSH_GMFBITEM   = "chat_push_gm_fbitem",	--推送一条 GM反馈信息
	SHOW_PLAYERINFO = "chat_show_playerinfo",	--在展示玩家信息
	DELETE_TXT 		= "chat_delete_txt",		--删除字符
	INSERT_FACE 	= "chat_insert_face",		--插入表情占位符
	UPDATE_CHAT_LIST = "chat_update_chat_list", --更新聊天列表
	LEVUP_TEAM = "chat_team_levup", --战队升级
}