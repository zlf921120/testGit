
--聊天数据代理
ChatDataProxy = class("ChatDataProxy")
ChatDataProxy.voList = {}
ChatDataProxy.gmFbVoList = {}
ChatDataProxy.chatItemWidget = nil
ChatDataProxy.gmAutoChatVo = nil --Gm自动回复
ChatDataProxy._chatNewsArr = {}
ChatDataProxy._chatCacheList = {}
ChatDataProxy._systemCacheList = {} --系统自动 推送

local __instance = nil
local _allowInstance = false

function ChatDataProxy:ctor()
    if not _allowInstance then
		error("ChatDataProxy is a singleton class")
	end
	self:init()
end

function ChatDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = ChatDataProxy.new()
		_allowInstance = false
	end
	return __instance
end

function ChatDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function ChatDataProxy:init()
	require "ChatPlayerVo"
	require "CharacterManager"
	require "TeamManager"
	require "ChatEvent"
	--装载当前玩家数据

	local roleBaseData = CharacterManager:getInstance():getBaseData()
	local roleLoginData = CharacterManager:getInstance():getLoginData()
	local roleTeamData = CharacterManager:getInstance():getTeamData()
	local roleGuildData = CharacterManager:getInstance():getGuildData()
	--当前自身聊天值
	local curChatVo = ChatPlayerVo.new()
	curChatVo.faceId = roleBaseData:getFaceId()
	curChatVo.role_id = RoleId:create()
	curChatVo.role_id:setData(roleLoginData:getAcctId(), roleLoginData:getChannelId(), roleLoginData:getZoneId())
	curChatVo.id = curChatVo.role_id:getKeyIdx()
	curChatVo.name = roleBaseData:getName()
	curChatVo.level = roleTeamData:getLev()
	curChatVo.roleFlag = roleBaseData:getRoleFlag()
	curChatVo.guild = roleGuildData:getName()

	self.voList[ curChatVo.id ] = curChatVo

	--GM 自动回复
	self.gmAutoChatVo = ChatPlayerVo.new()
	self.gmAutoChatVo.id = 0
	self.gmAutoChatVo.isGm = 1
	self.gmAutoChatVo.name = "小精靈"
	self.gmAutoChatVo.level = 100
	self.gmAutoChatVo.fightValue = 1000000
	self.gmAutoChatVo.roleFlag = 1
	self.gmAutoChatVo.heroList = {}
	self.gmAutoChatVo.txt = "您的問題已提交，GM會在2個工作日內對您回復。"

end

function ChatDataProxy:getChatItemWidget()
	if self.chatItemWidget == nil then
		self.chatItemWidget = GUIReader:shareReader():widgetFromJsonFile("chat/ChatItem.ExportJson")
		self.chatItemWidget:retain()
	end
	return self.chatItemWidget
end

function ChatDataProxy:getFacePageWidget()
	if self.facePageWidget == nil then
		self.facePageWidget = GUIReader:shareReader():widgetFromJsonFile("chat/FacePage.ExportJson")
		self.facePageWidget:retain()
	end
	return self.facePageWidget
end

--GM反馈 检测所有聊天内容是否有自己聊过的话
function ChatDataProxy:isHasBeenSend(txt)
	local ret = false
	local arr = ChatScene:getInstance().listGm:getItems()
	local len = arr:count()
	for i=0,len - 1 do
		local item = arr:objectAtIndex(i)
		if item.txt == txt then
			ret = true
			break
		end
	end
	return ret
end

--推送 系统消息 
function ChatDataProxy:createSystemChatVo(txt)
	--系统回复 
	local systemChatVo = ChatPlayerVo.new()
	systemChatVo.id = 0
	systemChatVo.isGm = 1
	systemChatVo.name = "小精靈"
	systemChatVo.level = 100
	systemChatVo.fightValue = 1000000
	systemChatVo.roleFlag = 1
	systemChatVo.heroList = {}
	systemChatVo.txt = ""
	systemChatVo.txt = txt
	return systemChatVo
end

function ChatDataProxy:getChatVoList()
	return self.voList
end

function ChatDataProxy:getChatVoById(id)

	local roleLoginData = CharacterManager:getInstance():getLoginData()
	local acctKeyId = roleLoginData:getRoleId():getKeyIdx()
	if id == acctKeyId then --如果是自身 玩家  则刷新数据
		local roleBaseData = CharacterManager:getInstance():getBaseData()
		local roleGuildData = CharacterManager:getInstance():getGuildData()
		local roleTeamData = CharacterManager:getInstance():getTeamData()
		local curChatVo = self.voList[id]
		curChatVo.faceId = roleBaseData:getFaceId()
		curChatVo.level = roleTeamData:getLev()
		curChatVo.faceId = roleBaseData:getFaceId()
		curChatVo.name = roleBaseData:getName()
		curChatVo.guild = roleGuildData:getName()
	end
	return self.voList[id]
end

function ChatDataProxy:setChatVo(vo)
	self.voList[vo.id] = vo
end

function ChatDataProxy:createChatVo()
	local ret = ChatPlayerVo.new()
	ret.param = {}
	return ret
end

function ChatDataProxy:createGmFbVo()
	return ChatFreeBackVo.new()
end

function ChatDataProxy:setGmFbVo(vo)
	self.gmFbVoList[ vo.id ] = vo
end

function ChatDataProxy:getGmFbById(id)
	return self.gmFbVoList[ id ]
end

function ChatDataProxy:clear()
	for id,v in pairs(self.voList) do
		self.voList[id] = nil
	end
	self.voList = {}
end

function ChatDataProxy:getChatNews()
	return self._chatNewsArr
end	

function ChatDataProxy:getChatNewsById(id)
	return self._chatNewsArr[ id ]
end

function ChatDataProxy:makeChatNewTips(ext)
	self._chatNewsArr = {}
	for i=1,#ext do
		self._chatNewsArr[ ext[i] ] = "done"
	end
	return Utils.get_length_from_any_table( self._chatNewsArr ) > 0
end

function ChatDataProxy:isShowMainSceneTips()
	if Utils.get_length_from_any_table( self._chatNewsArr ) > 0 then
		Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.chat)
	else
		Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.chat)
	end
end

function ChatDataProxy:getChatCacheList()
	return self._chatCacheList
end

function ChatDataProxy:getSystemCacheList()
	return self._systemCacheList
end