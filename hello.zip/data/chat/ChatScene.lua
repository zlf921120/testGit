
--聊天场景
ChatScene = class("ChatScene",WindowBase)
ChatScene.__index = ChatScene
ChatScene._widget = nil
ChatScene.uiLayer = nil
ChatScene.gmSelectType = 11 --默认枚举
ChatScene.listGm = nil

local __instance = nil

function ChatScene:create()
    local ret = ChatScene.new()
    __instance = ret
    return ret   
end

-------------响应事件-----------------------------------------------
local btnSend = nil
local listWorld = nil
local listOrganiz = nil
local listGm = nil
local inputChat = nil
local btnFace = nil
local imgStatus = nil
local p_facepanel = nil

local panelWorld = nil
local panelGuild = nil 
local panelGm = nil

local btnWorld = nil 
local btnOrganiz = nil
local btnGm = nil

local curChatArea = 1
local btnLast = nil
local lastPanel = nil
local __isShowFacePanel = false

local TxtRepeatNum_world = 0    --世界聊天中重复发送的话的次数
local __isCanSend_world = true        --判断是否过了15秒可以发送聊天
local txtWorld = nil            --暂存世界聊天的内容用以判断是否重复

local function event_btn_send(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then

        local txt = inputChat:getText()
        if CharacterDataProxy:getInstance():getVipLev() < 1 then
            for k,v in pairs(ChatVipFaceSet) do
                txt = string.gsub(txt,v,"")
            end
        end
        local len = string.len(txt)
        if len == 0 then return end

        local dp = ChatDataProxy:getInstance() 
        local curPlayerVo = dp:getChatVoById(CharacterDataProxy:getInstance():getAcctKeyId()) --单列
        curPlayerVo.txt = txt
        curPlayerVo.time = ServerTimerManager:getInstance():getCurTime()
        
        curPlayerVo.fightValue = TeamManager:getInstance():getBattleData(TeamType.Normal):getFightCapacity()

        if curChatArea == ChatArea.WORLD then
            if CharacterDataProxy:getInstance():getTeamLev() < 12 then
                Alert:show("您的戰隊等級未滿12級，加油升級哦。")
            else
                if __isCanSend_world then
                    if txtWorld ~= txt then
                        txtWorld = txt
                        TxtRepeatNum_world = 1
                    else
                        TxtRepeatNum_world = TxtRepeatNum_world + 1
                        if TxtRepeatNum_world > 2 then
                            Alert:show("請不要一直說同一句話哦。")
                            return
                        end
                    end
                    ChatNetTask:getInstance():requestWorldChat(txt) --发送 世界聊天请求
                    __isCanSend_world = false
                    --添加计时函数
                    __instance:startScheduleWorldChatInterval()
                else
                    Alert:show("每次發言間隔不能低於15秒哦。")
                    return
                end




                
                -- ChatRenderMgr.pushChatItem(listWorld,curPlayerVo.id)
            end
        elseif curChatArea == ChatArea.ORGANIZ then
            ChatNetTask:getInstance():requestOrganizChat(txt) --发送 公会聊天请求
            -- ChatRenderMgr.pushChatItem(listOrganiz,curPlayerVo.id)   
        elseif curChatArea == ChatArea.GM then --发送 GM 反馈请求
            ChatNetTask:getInstance():requestGmChat( __instance.gmSelectType,"",txt)

            ChatRenderMgr.pushChatItem(listGm,curPlayerVo)
            ChatRenderMgr.pushGMAutoFbItem(listGm)
        end

        --清空输入框
        inputChat:setText("")
        --关闭表情面板
        ChatRenderMgr.hideFacePanel(__instance._widget)
        __isShowFacePanel = false
        imgStatus:loadTexture("chat_face.png",UI_TEX_TYPE_PLIST)
    end
end

local function event_ckb_face(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        __isShowFacePanel = not __isShowFacePanel   --取反
        if __isShowFacePanel then
            ChatRenderMgr.addFacePanel(__instance._widget,p_facepanel:getPosition())   --创建表情面板
            ChatRenderMgr.showFacePanel(__instance._widget)
            imgStatus:loadTexture("chat_key.png",UI_TEX_TYPE_PLIST)
        else
            ChatRenderMgr.hideFacePanel(__instance._widget)
            imgStatus:loadTexture("chat_face.png",UI_TEX_TYPE_PLIST)
        end
    end
end

local function event_btn_world(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        Notifier.dispatchCmd(ChatEvent.UPDATE_CHAT_LIST)

        curChatArea = ChatArea.WORLD
        panelWorld:setVisible(true)
        panelWorld:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        __instance:hideNewsTip(ChatArea.WORLD) --删除绿点
        if btnLast ~= btn then
            btnLast:setFocused(false)
            btnLast:setTitleColor(ccc3(245,204,85))
            btnLast = btn

            __instance:hideNewsTip(ChatArea.WORLD) --删除绿点

            lastPanel:setVisible(false)
            lastPanel:setZOrder(3)
            lastPanel = panelWorld
            --开启世界聊天 轮询
            __instance:startScheduleWorld()
        end
    end
end

local function forceToWorld()
    curChatArea = ChatArea.WORLD
    panelWorld:setVisible(true)
    panelWorld:setZOrder(4)

    btnWorld:setFocused(true)
    btnWorld:setTitleColor(ccc3(210,253,238))
    if btnLast and btnLast ~= btnWorld then
        btnLast:setFocused(false)
        btnLast:setTitleColor(ccc3(245,204,85))
        btnLast = btnWorld

        lastPanel:setVisible(false)
        lastPanel:setZOrder(3)
        lastPanel = panelWorld
    end
end

local function event_btn_organiz(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        Notifier.dispatchCmd(ChatEvent.UPDATE_CHAT_LIST)

        local id = CharacterManager:getInstance():getGuildData():getId()
        if id == 0 then --没有公会
            Alert:show(ChatCfg.ForbitTip)
        else
            curChatArea = ChatArea.ORGANIZ
            panelGuild:setVisible(true)
            panelGuild:setZOrder(4)

            local btn = tolua.cast(pSender,"Button")
            btn:setFocused(true)
            btn:setTitleColor(ccc3(210,253,238))
            if btnLast ~= btn then
                btnLast:setFocused(false)
                btnLast:setTitleColor(ccc3(245,204,85))
                btnLast = btn

                __instance:hideNewsTip(ChatArea.ORGANIZ) --删除绿点

                lastPanel:setVisible(false)
                lastPanel:setZOrder(3)
                lastPanel = panelGuild
                --开启世界聊天 轮询
                __instance:startScheduleOrganiz()
            end
        end
    end    
end


local function event_btn_gm(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        Notifier.dispatchCmd(ChatEvent.UPDATE_CHAT_LIST)

        curChatArea = ChatArea.GM
        panelGm:setVisible(true)
        panelGm:setZOrder(4)

        local btn = tolua.cast(pSender,"Button")
        btn:setFocused(true)
        btn:setTitleColor(ccc3(210,253,238))
        if btnLast ~= btn then
            btnLast:setFocused(false)
            btnLast:setTitleColor(ccc3(245,204,85))
            btnLast = btn

            __instance:hideNewsTip(ChatArea.GM) --删除绿点

            lastPanel:setVisible(false)
            lastPanel:setZOrder(3)
            lastPanel = panelGm
            --开启世界GM 轮询
            __instance:startScheduleGM()
        end
    end
end

local function event_tab_suggest(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        __instance.imgSelect:setPosition(ccp(pSender:getPosition()))
        __instance.imgBgSelect:setPosition(ccp(182,317))
        __instance.labSuggest:setColor(ccc3(245,204,85))
        __instance.labBug:setColor(ccc3(118,88,80))

        __instance.gmSelectType = ChatGMType.Suggest
    end
end

local function event_tab_bug(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        __instance.imgSelect:setPosition(ccp(pSender:getPosition()))
        __instance.imgBgSelect:setPosition(ccp(648,317))
        __instance.labSuggest:setColor(ccc3(118,88,80))
        __instance.labBug:setColor(ccc3(245,204,85))

        __instance.gmSelectType = ChatGMType.Bug
    end
end

--推出 聊天记录
local function event_push_chatitem(param)

    local area = param.area
    local chatVo = param.chatVo

    if area == ChatArea.WORLD then
        -- ChatRenderMgr.pushChatItem(listWorld,id)
        -- __instance:hideNewsTip(ChatArea.WORLD) --删除绿点
    elseif area == ChatArea.ORGANIZ then
        -- ChatRenderMgr.pushChatItem(listOrganiz,id)
        --  __instance:hideNewsTip(ChatArea.ORGANIZ) --删除绿点
    elseif area == ChatArea.GM then
        ChatRenderMgr.pushChatItem(listGm,chatVo)
        __instance:hideNewsTip(ChatArea.GM) --删除绿点
    end
end

-- --推出一条GM 反馈
-- local function event_push_gmitem(param)

--     local t = param.type
--     local id = param.id

--     ChatRenderMgr.pushGmFbItem(listGm,id)
-- end

--响应删除字符
local function event_delete_txt()
    local tblStr = Helper.separate(inputChat:getText())

    if table.getn(tblStr) < 1 then return end
    table.remove(tblStr)
    local nowStr = Utils.Join("",tblStr)
    inputChat:setText(nowStr)
end

--插入表情占位符
local function event_insert_face(faceName)
    inputChat:setText(inputChat:getText()..faceName)
end

local function event_update_chatlist()
    ChatRenderMgr.checkRendChatList(listWorld,listOrganiz,listGm)
end
---------------初始化-----------------------------------------------------

function ChatScene:init()
    require "ChatHelper"
    require "ChatRenderMgr"
    require "ChatDataProxy"
    require "ChatNetTask"
    require "ChatCfg"
    require "ChatEvent"
    require "FacePanel"
    require "ChatItem"
    require "PlayerInfoPanel"
    require "ChatLocalReader"
    --加载纹理
    ComResMgr:getInstance():loadOtherRes()
    --加载过滤词
    ChatLocalReader:getInstance():loadInProxy()

    self:addDefaultShadow()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("chat/ChatScene.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    btnWorld = tolua.cast(self.uiLayer:getWidgetByName("btn_world"),"Button")
    btnWorld:addTouchEventListener(event_btn_world)

    btnGm = tolua.cast(self._widget:getChildByName("btn_gm"),"Button")
    btnGm:addTouchEventListener(event_btn_gm)
    btnLast = btnGm--注意!!(不要用btnWorld)

    btnOrganiz = tolua.cast(self.uiLayer:getWidgetByName("btn_organiz"),"Button")
    btnOrganiz:addTouchEventListener(event_btn_organiz)

    btnSend = tolua.cast(self.uiLayer:getWidgetByName("btn_send"),"Button")
    btnSend:addTouchEventListener(event_btn_send)

    btnFace = tolua.cast(self.uiLayer:getWidgetByName("btn_face"),"Button")
    btnFace:addTouchEventListener(event_ckb_face)

    imgStatus = tolua.cast(self.uiLayer:getWidgetByName("img_status"),"ImageView")

    panelWorld = tolua.cast(self._widget:getChildByName("panel_all"),"Layout")
    panelGuild = tolua.cast(self._widget:getChildByName("panel_guild"),"Layout")
    panelGm = tolua.cast(self._widget:getChildByName("panel_gm"),"Layout")
    lastPanel = panelGm--注意!!(不要用btnWorld)

    listWorld = tolua.cast(panelWorld:getChildByName("list_world"),"ListView")
    listOrganiz = tolua.cast(panelGuild:getChildByName("list_organiz"),"ListView")
    listGm = tolua.cast(panelGm:getChildByName("list_gm"),"ListView")

    DisplayUtil.makeVisibleListView(listWorld,115,350)
    DisplayUtil.makeVisibleListView(listOrganiz,115,350)

    self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)
    self.listGm = listGm
    self.imgBgSuggest = tolua.cast(panelGm:getChildByName("img_bgsuggest"),"ImageView")
    self.imgBgSuggest:addTouchEventListener(event_tab_suggest)
    self.imgBgBug = tolua.cast(panelGm:getChildByName("img_bgbug"),"ImageView")
    self.imgBgBug:addTouchEventListener(event_tab_bug)
    self.imgSelect = panelGm:getChildByName("img_select")
    self.imgBgSelect = panelGm:getChildByName("img_bgselect")
    self.labSuggest = panelGm:getChildByName("lab_suggest")
    self.labBug = panelGm:getChildByName("lab_bug")

    inputChat = CCEditBox:create(CCSize(500,35),CCScale9Sprite:create("ui/login/resource/img/img_empty.png"))
    inputChat:setPosition(ccp(self._widget:getChildByName("img_bginput"):getPosition()))
    inputChat:setPlaceHolder("請輸入聊天資訊")
    inputChat:setInputMode(kEditBoxInputModeSingleLine)
    inputChat:setFontSize(22)
    self._widget:addNode(inputChat,3)
    
    p_facepanel = self.uiLayer:getWidgetByName("p_facepanel")

    self._progressSchedWorldChatInterval = function()
        self:progressSchedWorldChatInterval()
    end
    self._progressSchedWorld = function()
        self:progressSchedWorld()
    end
    self._progressSchedGuild = function()
        self:progressSchedGuild()
    end
    self._progressSchedPrivate = function()
        self:progressSchedPrivate()
    end
    self._progressSchedGm = function()
        self:progressSchedGm()
    end
    --注册事件
    Notifier.regist(ChatEvent.PUSH_CHATITEM,event_push_chatitem) 
    -- Notifier.regist(ChatEvent.PUSH_GMFBITEM,event_push_gmitem)   
    Notifier.regist(ChatEvent.DELETE_TXT,event_delete_txt)
    Notifier.regist(ChatEvent.INSERT_FACE,event_insert_face)
    Notifier.regist(ChatEvent.UPDATE_CHAT_LIST,event_update_chatlist)
end

function ChatScene:extTouchPriority(value)
    inputChat:setTouchPriority(value)
end

function ChatScene:progressSchedWorldChatInterval()
    __isCanSend_world = true
    TimerManager.removeTimer(self._progressSchedWorldChatInterval)
end
function ChatScene:progressSchedWorld()
    ChatNetTask:getInstance():requestWorldChatCycle()
end

function ChatScene:progressSchedGuild()
    ChatNetTask:getInstance():requestOrganizChatCycle()
end

function ChatScene:progressSchedPrivate()
    ChatNetTask:getInstance():requestPrivateChatCycle()
end

function ChatScene:progressSchedGm()
    ChatNetTask:getInstance():requestGmChatCycle(self.gmSelectType)
end
--------------------------------------------------------------------------------
-- 开启世界频道 发送间隔定时器
function ChatScene:startScheduleWorldChatInterval()
    --self:clearSchedule()
    TimerManager.addTimer(15000,self._progressSchedWorldChatInterval,true)
    --self._progressSchedWorldChatInterval()
end
-- 开启世界频道 定时器
function ChatScene:startScheduleWorld()
    self:clearSchedule()
    TimerManager.addTimer(8000,self._progressSchedWorld,true)
    self._progressSchedWorld()
end
-- 开启公会频道 定时器 
function ChatScene:startScheduleOrganiz()
    self:clearSchedule()
    TimerManager.addTimer(8000,self._progressSchedGuild,true)
    self._progressSchedGuild()
end
-- 开启私聊频道 定时器
function ChatScene:startSchedulePrivate()
    self:clearSchedule()
    TimerManager.addTimer(8000,self._progressSchedPrivate,true)
    self._progressSchedPrivate()
end

function ChatScene:startScheduleGM()
    self:clearSchedule()
    TimerManager.addTimer(8000,self._progressSchedGm,true)
    self._progressSchedGm()
end

--清理定时器
function ChatScene:clearSchedule()
    TimerManager.removeTimer(self._progressSchedWorld)
    TimerManager.removeTimer(self._progressSchedGuild)
    TimerManager.removeTimer(self._progressSchedPrivate)
    TimerManager.removeTimer(self._progressSchedGm)
end

function ChatScene:getInstance()
    return __instance
end

function ChatScene:checkShowTips(forceArea)
    local dp = ChatDataProxy:getInstance()
    for k,v in pairs(ChatArea) do
        if dp:getChatNewsById(v) ~= nil then
            self:showNewsTip(v)
        else
            self:hideNewsTip(v)
        end
    end
             
    local tmpArea = { ChatArea.WORLD, ChatArea.ORGANIZ, ChatArea.GM }  --绿点区域
    local idx = 1
    for i=1,#tmpArea do
        if dp:getChatNewsById(tmpArea[i]) ~= nil then
            idx = tmpArea[i]
            break
        end
    end
    if forceArea ~= nil then
        idx = forceArea
    end
    
    if idx == ChatArea.WORLD then
        event_btn_world(btnWorld,ComConstTab.TouchEventType.ended)
        self:startScheduleWorld()
    elseif idx == ChatArea.ORGANIZ then
        event_btn_organiz(btnOrganiz,ComConstTab.TouchEventType.ended)
        self:startScheduleOrganiz()
    elseif idx == ChatArea.GM then    
        event_btn_gm(btnGm,ComConstTab.TouchEventType.ended)
        self:startScheduleGM()
    end
end

function ChatScene:open()
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/chat/face.plist")
    if self.params and self.params["area"] == ChatArea.ORGANIZ then
        self:checkShowTips(ChatArea.ORGANIZ)
    else
        self:checkShowTips()
    end
-------------------------------------------------------------------
    --刷新富文本 (为了副本文本动画不会停止播放)
    ChatRenderMgr.makeRefreshRtf(listWorld)
    ChatRenderMgr.makeRefreshRtf(listOrganiz)
    ChatRenderMgr.makeRefreshRtf(listGm)
    listWorld:jumpToBottom()
    listOrganiz:jumpToBottom()
    listGm:jumpToBottom()

    if self.params and self.params["dialog"] == 1 then
        self.containerType = WindowHelper.containerType.right
        self.win_type = WindowHelper.win_type.second_unfull
        self.btnClose:setVisible(true)
        self.btnClose:setTouchEnabled(true)
        self:isShowBg(false)
        self:isShowReturnBtn(false)
        self:isShowShadowBg(true)
    else
        self.containerType = WindowHelper.containerType.left  
        self.win_type = WindowHelper.win_type.second_full 
        self.btnClose:setVisible(false)
        self.btnClose:setTouchEnabled(false)
        self:isShowBg(true)
        self:isShowReturnBtn(true)
        self:isShowShadowBg(false)
    end

    GuildPopChatView:hide()
end

function ChatScene:showNewsTip(key)
    local target = nil
    local pos = nil
    if key == ChatArea.GM then
        target = btnGm
        pos = ccp(40,20)
    elseif key == ChatArea.WORLD then
        target = btnWorld
        pos = ccp(40,20)
    elseif key == ChatArea.ORGANIZ then
        target = btnOrganiz
        pos = ccp(40,20)
    end
    if target and target:getChildByTag(2866) == nil then
        local tips_img = ImageView:create()
        tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
        tips_img:setTag(2866)
        tips_img:setPosition(pos)
        target:addChild(tips_img)
        self:tipsPointPlayAct(tips_img)
    elseif target and target:getChildByTag(2866) ~= nil then
        local tips_img = target:getChildByTag(2866)
        self:tipsPointPlayAct(tips_img)
    end
end

-- 隐藏 新消息 提示
function ChatScene:hideNewsTip(key)
    local target = nil
    ChatDataProxy:getInstance()._chatNewsArr[ key ] = nil
    if key == ChatArea.GM then
        target = btnGm
    elseif key == ChatArea.WORLD then
        target = btnWorld
    elseif key == ChatArea.ORGANIZ then
        target = btnOrganiz
    end
    if target and target:getChildByTag(2866) ~= nil then
        target:removeChildByTag(2866,true)
    end
end

function ChatScene:refreshNewsTipAct()
    if btnGm:getChildByTag(2866) ~= nil then
        self:tipsPointPlayAct(btnGm:getChildByTag(2866))
    end
    if btnWorld:getChildByTag(2866) ~= nil then
        self:tipsPointPlayAct(btnWorld:getChildByTag(2866))
    end
    if btnOrganiz:getChildByTag(2866) ~= nil then
        self:tipsPointPlayAct(btnOrganiz:getChildByTag(2866))
    end
end

function ChatScene:hasTips()
    local ret = false
    if btnGm:getChildByTag(2866) ~= nil then
        ret = true
    end
    if btnWorld:getChildByTag(2866) ~= nil then
        ret = true
    end
    if btnOrganiz:getChildByTag(2866) ~= nil then
        ret = true
    end
end

function ChatScene:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)
end

function ChatScene:close()
    forceToWorld()
    self:clearSchedule()
    inputChat:setText("") --清空

    __isShowFacePanel = false --关闭面板
    ChatRenderMgr.hideFacePanel(__instance._widget)

    WindowCtrl:getInstance():close(CmdName.Comm_PlayerInfo)

    listWorld:stopAllActions()

    if self:hasTips() then
        Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.chat)
    else
        Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.chat)
    end
end
