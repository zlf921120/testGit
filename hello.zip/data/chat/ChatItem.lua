
--聊天条目
ChatItemGrid = class("ChatItemGrid",function() 
    return Layout:create()
end)
ChatItemGrid.__index = ChatItemGrid
ChatItemGrid._widget = nil
ChatItemGrid.txt = ""

function ChatItemGrid:create(playerVo,area)
    local ret = ChatItemGrid.new()
    ret:init(playerVo,area)
    return ret   
end

---------------初始化-----------------------------------------------------
function ChatItemGrid:init(playerVo)

    require "Utils"
    require "DisplayUtil"
    require "ChatHelper"

    self._widget = ChatDataProxy:getInstance():getChatItemWidget():clone()
    self:setSize(CCSize(900,115))
    self:addChild(self._widget)

    self.panelLev = tolua.cast(self._widget:getChildByName("panel_lev"),"Layout")
    self.panelFlag = tolua.cast(self._widget:getChildByName("panel_flag"),"Layout")

    local labName = tolua.cast(self._widget:getChildByName("lab_name"),"Label")
    labName:setText(playerVo.name)

    local labLevel = tolua.cast(self.panelLev:getChildByName("lab_level"),"Label")
    labLevel:setText(playerVo.level)
    self.labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")

    local colorStr = nil
    local labFlag = tolua.cast(self.panelFlag:getChildByName("lab_flag"),"Label")
    if playerVo.roleFlag == RoleFlag.Normal then --普通玩家
        labFlag:setText("")

        self.panelFlag:setEnabled(false)
        self.panelLev:setEnabled(true)
    elseif playerVo.roleFlag == RoleFlag.Gm then
        labFlag:setText("【GM】")
        labFlag:setColor(ccc3(255,0,0))

        self.panelFlag:setEnabled(true)
        self.panelLev:setEnabled(false)
        colorStr = "FF0000"
    elseif playerVo.roleFlag == RoleFlag.Guider then 
        labFlag:setText("【新手指導員】")
        labFlag:setColor(ccc3(11,212,81))

        self.panelFlag:setEnabled(true)
        self.panelLev:setEnabled(false)
        colorStr = "0BD451"
    elseif playerVo.roleFlag == RoleFlag.Guild then
        labFlag:setText("")

        self.panelFlag:setEnabled(false)
        self.panelLev:setEnabled(true)

        self:showJoinBtn(playerVo.param["guild_id"],playerVo.param["join_guild_flag"])
    end

    local icon = HeadIcon:create()
    self._widget:addChild(icon)
    icon:setScale(0.9)
    if playerVo.isGm == 1 then --GM头像
        icon:setGmFace()
    else
        icon:setFaceId(playerVo.faceId,playerVo.sex)
    end
    
    icon:setPosition(ccp(47,65))
    icon:setClickEvent(function(pSender,eventType)   
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Comm_PlayerInfo,{vo = playerVo, open_from = true})
        end
    end)

    self.labTime:setText(os.date("%X",playerVo.time))

    self.colorStr = colorStr
    self.txt = playerVo.txt
    self.rtf1,self.rtf2 = ChatHelper.createRtfFormTxt(playerVo.txt,colorStr)

    if self.rtf1 then
        self.rtf1:setPosition(ccp(239,62))
        self._widget:addNode(self.rtf1)
    end

    if self.rtf2 then
        self.rtf2:setPosition(ccp(239,24))
        self._widget:addNode(self.rtf2)
    end
end

function ChatItemGrid:showJoinBtn(id,flag)
    require "OrganizCfg"
    require "GuildNetTask"
    if self.btnJoin == nil then
        self.btnJoin = Button:create()
        self.btnJoin:loadTextureNormal("btn_up_1.png", UI_TEX_TYPE_PLIST)
        self.btnJoin:loadTexturePressed("btn_down_1.png", UI_TEX_TYPE_PLIST)
        self.btnJoin:setTitleText("我要加入")
        self.btnJoin:setTitleColor(ccc3(0xFB, 0xF1, 0xA0))
        self.btnJoin:setTitleFontSize(22)
        self.btnJoin:setPosition(ccp(751, 60))
        self._widget:addChild(self.btnJoin)
        self.btnJoin:addTouchEventListener(function(sender,event_type)
            if event_type == ComConstTab.TouchEventType.ended then
                if flag == JoinStatus.APPLY_JOIN then
                    GuildNetTask:getInstance():requestAppleJoinOrganiz(id)
                elseif flag == JoinStatus.QUICI_JOIN then
                    GuildNetTask:getInstance():requestQuickJoinOrganiz(id)
                end
            end
        end)
        self.labTime:setVisible(false)
    end
end
