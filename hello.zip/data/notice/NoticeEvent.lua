
--公告事件
NoticeEvent = {
	CB_UPDATE_GET_REWARD = "NOTICE_CB_UPDATE_GET_REWARD", --获取公告物品
	CB_UPDATE_REMOVE_NOTICE = "NoticeEvent.CB_UPDATE_REMOVE_NOTICE" --删除过期公告
}


