--公告 数据代理
NoticeDataProxy = class("NoticeDataProxy")
NoticeDataProxy.noticeVoList = {}
NoticeDataProxy.nowPageIdx = 0

local __instance = nil
local _allowInstance = false

function NoticeDataProxy:ctor()
    if not _allowInstance then
		error("NoticeDataProxy is a singleton class")
	end
	self:init()
end

function NoticeDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = NoticeDataProxy.new()
		_allowInstance = false
	end

	return __instance
end

function NoticeDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function NoticeDataProxy:init()
	require "NoticeVo"
	require "NoticeEvent"
end

function NoticeDataProxy:createNoticeVo()
	return NoticeVo.new()
end

function NoticeDataProxy:setNoticeVo(vo)
	self.noticeVoList[ vo.id ] = vo
end

function NoticeDataProxy:getNoticeVoById(id)
	return self.noticeVoList[ id ]
end

function NoticeDataProxy:getNoticeVoByIdx(idx)
	local tmpList = {}
	for k,v in pairs(self.noticeVoList) do
		table.insert(tmpList,v)
	end
	table.sort(tmpList, function(a,b) return a.time > b.time end)
	for i=1,#tmpList do
		tmpList[i].idx = i
	end
	return tmpList[idx]
end

--排序公告
function NoticeDataProxy:sortNotice()
	local tmpList = {}
	for i,v in pairs(self.noticeVoList) do
		table.insert( tmpList, v)
	end
	table.sort(tmpList, function(a,b) return a.time > b.time end)
	for i=1,#tmpList do 
		tmpList[i].idx = i
	end
end

function NoticeDataProxy:getNoticeVoList()
	return self.noticeVoList
end

function NoticeDataProxy:cleanNoticeVoList()
	self.noticeVoList = {}
end

function NoticeDataProxy:createRewardVo()
	return NoticeRewardVo.new()
end

function NoticeDataProxy:isPopNotice()
	local ret = false
	local idx = 1
	for k,v in pairs(self.noticeVoList) do
		if v.isPop == 1 then --是否弹窗 0：不弹窗 1：弹窗
			v.isPop = 0
			ret = true
		end
	end
	return ret,idx
end

function NoticeDataProxy:cleanPop()
	for k,v in pairs(self.noticeVoList) do
		-- if v.isPop == 1 then --是否弹窗 0：不弹窗 1：弹窗
			v.isPop = 0
			-- ret = true
		-- end
	end
end

function NoticeDataProxy:checkRemoveNotice()
	-- print(" -------------checkRemoveNotice------------- ")
	local isDirty = false
	for k,v in pairs(self.noticeVoList) do
		if ServerTimerManager:getInstance():getCurTime() >= v.cleanTime then
			self.noticeVoList[k] = nil --删除数据
			isDirty = true
		end
	end
	 
	local hasNotice = false --正在看的公告是否还在
	for k,v in pairs(self.noticeVoList) do
		if self.nowPageIdx == v.idx then
			hasNotice = true 
			break
		end
	end

	if isDirty then
		local newPageIdx = 1
		if hasNotice then
			newPageIdx = self.nowPageIdx
		else
			if Utils.get_length_from_any_table(self.noticeVoList) > 0 then
				newPageIdx = 1 
			else
				WindowCtrl:getInstance():close(CmdName.Notice_Scene)
				Alert:show("清理過期公告完成")
				return 
			end
		end
		print(" 清理後的 newPageIdx ！！！ ",newPageIdx)
		Notifier.dispatchCmd(NoticeEvent.CB_UPDATE_REMOVE_NOTICE,newPageIdx)
	end

	self:refreshViewTips()
end
--刷新提示绿点 和 图标的显示
function NoticeDataProxy:refreshViewTips()
	local isHideNewTips = true
	for k,v in pairs( self:getNoticeVoList() ) do
		if v.isShowTip == 1 then
			isHideNewTips = false
			break
		end
	end
	-- print(" isHideNewTips ",isHideNewTips)
	if isHideNewTips then
		Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.notice)
	end

	local isHideNewIcon = true
	for k,v in pairs( self:getNoticeVoList() ) do
		if v.iteminfos and #v.iteminfos > 0 or v.isShowTip == 1 then--有物品或者没读
			isHideNewIcon = false
		end
	end
	if isHideNewIcon then
		Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_ICON,NewTipsEnum.notice)
	end
end

function NoticeDataProxy:checkPopNotice()
	-- print(" -----------------checkPopNotice--   ")
	if Utils.get_length_from_any_table( self:getNoticeVoList() ) > 0  then
		local isShowNewTips = false
		for k,v in pairs(self:getNoticeVoList()) do
			-- print(" v.isShowTip ",v.isShowTip,v.isPop)
			if v.isShowTip == 1 then
				isShowNewTips = true
				break
			end
		end
		-- print(" isShowNewTips ",isShowNewTips)

		if isShowNewTips then
			Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.notice)
		end
		Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_ICON,NewTipsEnum.notice)
	end
	--新账号不弹出
	if CharacterManager:getInstance():getBaseData():getHasCreateGender() == 0 then --未选择
		 return 
	elseif CharacterManager:getInstance():getBaseData():getHasCreateGender() == 1 and 
		CharacterManager:getInstance():getBaseData():getHasCreateName()== 0 then
		return
	end
	if WindowCtrl:getInstance():hasWin() then --有窗体则 不弹
		return
	end

	local isPop,idx = self:isPopNotice()
	-- print("[isPopNotice]!!!! isPop,idx ",isPop,idx)
    if isPop then --直接显示
        WindowCtrl:getInstance():open(CmdName.Notice_Scene,{idx = idx})
    end
end

function NoticeDataProxy:makeNoticeBySvr(notices)

	-- print(" ------------------makeNoticeBySvr-------------------  ")

	for i=1,#notices do
        local noticeVo = self:createNoticeVo()
        -- noticeVo.idx = i
        noticeVo.id = notices[i].nid
        noticeVo.title = notices[i].title
        noticeVo.from = notices[i].appellation
        noticeVo.content = notices[i].content
        noticeVo.signname = notices[i].sign_name
        noticeVo.iteminfos = notices[i].item_info
        noticeVo.time = notices[i].start_timer
        noticeVo.cleanTime = notices[i].end_timer
        noticeVo.isPop = notices[i].type
        noticeVo.isShowTip = notices[i].showlight --[默认1] 0：不显示 1：显示
        noticeVo.isAutoRemove = notices[i].auto_del

        -- print(" notices[i].isShowTip ", noticeVo.isPop , noticeVo.id ,notices[i].showlight,noticeVo.iteminfos)
        self:setNoticeVo(noticeVo)
    end

    self:sortNotice()

end

--清理自动删除的公告
function NoticeDataProxy:cleanAutoRemove()
	for k,v in pairs( self:getNoticeVoList() ) do
		if v.isAutoRemove == 1 then
			if v.iteminfos and #v.iteminfos > 0 then
				--有附件没领 不删
			else
				self.noticeVoList[ k ] = nil
			end
		end
	end
	self:sortNotice()
end