
--公告 场景
NoticeScene = class("NoticeScene",WindowBase)
NoticeScene.__index = NoticeScene
NoticeScene._widget = nil
NoticeScene.uiLayer = nil
NoticeScene.nowPageIdx = 0

local __instance = nil

function NoticeScene:create()
    local ret = NoticeScene.new()
    __instance = ret
    return ret
end

-------------响应事件-----------------------------------------------
local function event_btn_close(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		__instance:addCloseAnim(function()
			
		end)
	end
end

local function event_btn_left(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		__instance:turnPage( __instance.nowPageIdx - 1 )
	end
end

local function event_btn_right(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		__instance:turnPage( __instance.nowPageIdx + 1 )
	end
end

local function event_btn_get(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		NoticeNetTask:getInstance():requestGetReward(pSender:getTag())
	end
end

function NoticeScene:init()

	require "NoticeRenderMgr"
	require "NoticeDataProxy"
	require "NoticeEvent"
	require "NoticeCfg"
	require "NoticeNetTask"

	self._widget = GUIReader:shareReader():widgetFromJsonFile("notice/NoticeScene.ExportJson")
	self.uiLayer = TouchGroup:create()
	self.uiLayer:addWidget(self._widget)
 	self:addChild(self.uiLayer)

 	self.scrolCotent = tolua.cast(self.uiLayer:getWidgetByName("scroll_content"),"ScrollView")

 	self.btnLeft = tolua.cast(self.uiLayer:getWidgetByName("btn_left"),"Button")
 	self.btnLeft:addTouchEventListener(event_btn_left)

 	self.btnRight = tolua.cast(self.uiLayer:getWidgetByName("btn_right"),"Button")
 	self.btnRight:addTouchEventListener(event_btn_right)

 	self.btnGet = tolua.cast(self.scrolCotent:getChildByName("panel_bottom"):getChildByName("btn_get"),"Button")
 	self.btnGet:addTouchEventListener(event_btn_get)

 	self.btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
 	self.btnClose:addTouchEventListener(event_btn_close)

 	Notifier.regist(NoticeEvent.CB_UPDATE_GET_REWARD,function(idx)
 	 	NoticeRenderMgr:getInstance():renderNoticeContent(self.scrolCotent,self._widget,idx) 
 	end)
 	Notifier.regist(NoticeEvent.CB_UPDATE_REMOVE_NOTICE,function(idx)
 		self:turnPage(idx) 
 	end)
end

function NoticeScene:open()

	self:addOpenAnim(function()
		local idx = 1
		if self.params then
			idx = self.params["idx"]
		end
		self:turnPage(idx)
	end)
end

function NoticeScene:close()

	NoticeDataProxy:getInstance():cleanPop()

	NoticeDataProxy:getInstance():refreshViewTips()
	NoticeDataProxy:getInstance():cleanAutoRemove()
end

function NoticeScene:turnPage(idx)

	local voList = NoticeDataProxy:getInstance():getNoticeVoList()
	local maxPage = Utils.get_length_from_any_table(voList)

	if idx < 0 or idx > maxPage then return end

	self.btnLeft:setEnabled(true)
	self.btnRight:setEnabled(true)

	self.nowPageIdx = idx
	NoticeDataProxy:getInstance().nowPageIdx = idx

	if maxPage == 1 then
		self.btnRight:setEnabled(false)
	end


	--切换页面
	if idx <= 1 then
		self.btnLeft:setEnabled(false)

		NoticeRenderMgr:getInstance():renderNoticeContent(self.scrolCotent,self._widget,idx)
	else

		NoticeRenderMgr:getInstance():renderNoticeContent(self.scrolCotent,self._widget,idx)

		if idx >= maxPage then
			self.btnRight:setEnabled(false)
		end
	end
end

