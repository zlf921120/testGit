--公告 网络助手
NoticeNetTask = class("NoticeNetTask")

local __instance = nil
local _allowInstance = false

function NoticeNetTask:ctor()
    if not _allowInstance then
		error("NoticeNetTask is a singleton class")
	end
	self:init()
end

function NoticeNetTask:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = NoticeNetTask.new()
		_allowInstance = false
	end

	return __instance
end

function NoticeNetTask:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function NoticeNetTask:init()

	require "notice_pb"

	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.notice_get_rsp,"handleNoticeGetReward()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.notice_readed_rsp,"handleReadedNotice()")
	
end

--请求获取 奖励
function NoticeNetTask:requestGetReward(id)

	print("----------------------requestGetReward-----------------------",id)
	local notice_get_req = notice_pb.notice_get_req()
	notice_get_req.nid = id
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.notice_get_req,notice_get_req)

end

--响应获取 奖励
function handleNoticeGetReward(pkg)

	local notice_get_rsp = notice_pb.notice_get_rsp()
    notice_get_rsp:ParseFromString(pkg)

    print("--------------------handleNoticeGetReward-------------------------------",notice_get_rsp.ret)

	if notice_get_rsp.ret == error_code_pb.msg_ret.success then

		local items = notice_get_rsp.items
		local assets = notice_get_rsp.assets

		-- print(" notice_get_rsp.nid  ",notice_get_rsp.nid )
		local noticeVo = NoticeDataProxy:getInstance():getNoticeVoById( notice_get_rsp.nid )
		for i=1,#noticeVo.iteminfos do --清理缓存
			NoticeRenderMgr:getInstance().dic:removeObjectForKey(string.format("noticeitem%d_%d",noticeVo.id,i))
		end
		-- print(" noticeVo.id 清理物品成功 ",noticeVo.id)
		noticeVo.iteminfos = nil

		ItemManager:getInstance():addMultiItem(items) --更新背包
		CharacterManager:getInstance():updateRoleAssets(assets) --更新资产	

		Alert:show("領取成功")
		Notifier.dispatchCmd( NoticeEvent.CB_UPDATE_GET_REWARD, NoticeDataProxy:getInstance().nowPageIdx )

		ComSender:getInstance():dealExtInfo(notice_get_rsp.ext)
	else
		if notice_get_rsp.ret == error_code_pb.msg_ret.err_mail_item_already_picked then
			local noticeVo = NoticeDataProxy:getInstance():getNoticeVoById( notice_get_rsp.nid )
			noticeVo.iteminfos = nil
			Notifier.dispatchCmd( NoticeEvent.CB_UPDATE_GET_REWARD, NoticeDataProxy:getInstance().nowPageIdx )
    	end
    	Alert:show(Helper.getErrStr(notice_get_rsp.ret))
   	end
end

function NoticeNetTask:requestReadedNotice(id)

	print("----------------------requestReadedNotice-----------------------",id)
	local notice_readed_req = notice_pb.notice_readed_req()
	notice_readed_req.nid = id
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.notice_readed_req,notice_readed_req)
end

function handleReadedNotice(pkg)

	local notice_readed_rsp = notice_pb.notice_readed_rsp()
    notice_readed_rsp:ParseFromString(pkg)

    print("--------------------handleReadedNotice-------------------------------",notice_readed_rsp.ret)

	if notice_readed_rsp.ret == error_code_pb.msg_ret.success then


		ComSender:getInstance():dealExtInfo(notice_readed_rsp.ext)
	else
    	print(" handleReadedNotice ",Helper.getErrStr(notice_readed_rsp.ret))
   	end
end