-- 公告 渲染逻辑
NoticeRenderMgr = class("NoticeRenderMgr")
NoticeRenderMgr.dic = nil

local __instance = nil
local _allowInstance = false

function NoticeRenderMgr:ctor()
    if not _allowInstance then
		error("NoticeRenderMgr is a singleton class")
	end
	self:init()
end

function NoticeRenderMgr:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = NoticeRenderMgr.new()
		_allowInstance = false
	end

	return __instance
end

function NoticeRenderMgr:destoryInstance()

	_allowInstance = false
	__instance = nil
end

function NoticeRenderMgr:init()
	
	require "ItemIcon"
	self.dic = CCDictionary:create() --缓存
	self.dic:retain()

end

function NoticeRenderMgr:renderNoticeContent(scrollView,container,idx)

	scrollView:setInnerContainerSize(CCSize(750,470))

	local panelBottom = scrollView:getChildByName("panel_bottom")

	--清理奖励 物品
	for i=1000,1005 do
		panelBottom:removeChild(panelBottom:getChildByTag(i))
	end
	if scrollView:getChildByTag(3241) ~= nil then
		scrollView:removeChildByTag(3241,true)
	end

	local dp = NoticeDataProxy:getInstance()
	local noticeVo = dp:getNoticeVoByIdx(idx)
	local noticeVoList = dp:getNoticeVoList()

	noticeVo.isShowTip = 0 --主动清掉提示

	dp.nowPageIdx = idx

	NoticeNetTask:getInstance():requestReadedNotice(noticeVo.id) --请求服务端记录

	local labTitle = tolua.cast(container:getChildByName("lab_title"),"Label")
	labTitle:setText(noticeVo.title)

 	local labFrom = tolua.cast(scrollView:getChildByName("lab_from"),"Label")
 	labFrom:setPosition(ccp(24,447))
 	labFrom:setText(noticeVo.from)
 	require "ChatHelper"

 	-- noticeVo.content = '[{"type":"txt","txt":"more than 200","color":"ff0000","fontSize": 20},{"type":"txt","txt":"With ","fontSize": 20},{"type":"txt","txt":"Commuity: ","color":"953734","fontSize": 20},{"type":"txt","txt":"projects and initiatives under development at The Apache Software Foundation, here\'s what\'s happened over the past week: The ASF @ 15  -The Apache Software Foundation Marks 15 Years of Open Source Innovation and Community Leadership - ","fontSize": 20}]'
 	-- print(" noticeVo.content -->",noticeVo.content)

 	local rtf,offsetY = ChatHelper.createTextRtfs(noticeVo.content,700,150)
 	rtf:setTag(3241)
 	rtf:setPosition(ccp(24,400))
 	scrollView:addChild(rtf)

 	local labPage = tolua.cast(scrollView:getChildByName("lab_page"),"Label")
 	labPage:setPosition(ccp(690,445))
	labPage:setText( string.format( "%d/%d", idx,Utils.get_length_from_any_table(noticeVoList)) )

	panelBottom:setPosition(ccp(24,0))

	local btnGet = tolua.cast(panelBottom:getChildByName("btn_get"),"Button")
	btnGet:setTag(noticeVo.id)  --记录当前公告id

 	local labSign = tolua.cast(panelBottom:getChildByName("lab_sign"),"Label")
 	labSign:setText(noticeVo.signname)

 	local labTime = tolua.cast(panelBottom:getChildByName("lab_time"),"Label")
 	labTime:setText(os.date("%Y.%m.%d %H:%M",noticeVo.time))

 	local p_1 = panelBottom:getChildByName("p_1")

 	-- print(" noticeVo.iteminfos ",noticeVo.iteminfos,noticeVo.id)

 	if noticeVo.iteminfos and #noticeVo.iteminfos > 0 then

 		btnGet:setEnabled(true)

 		-- print(" noticeVo.iteminfos ",#noticeVo.iteminfos)

		local arr = CCArray:create()

	 	for i=1,#noticeVo.iteminfos do
	 		if i <= 5 then --最大显示5个
	 			local itemInfo = noticeVo.iteminfos[i]
		 		local itemIcon = self.dic:objectForKey(string.format("noticeitem%d_%d",noticeVo.id,i))
		 		if itemIcon == nil then
	 				arr:addObject(CCDelayTime:create(0.1))
	 			end
	 			arr:addObject(CCCallFunc:create(function()

	 				local itemInfo = noticeVo.iteminfos[i]
			 		local itemIcon = self.dic:objectForKey(string.format("noticeitem%d_%d",noticeVo.id,i))
			 		if itemIcon == nil then
						itemIcon = ItemIcon:create()
						itemIcon:setBaseId(itemInfo.base_id)
						itemIcon:isShowNumLabel(true)
						itemIcon:setItemNum(itemInfo.quantity)
						itemIcon:setScale(0.8)
						itemIcon:setPosition(ccp(p_1:getPositionX() + i * (-100),p_1:getPositionY()))
						self.dic:setObject(itemIcon,string.format("noticeitem%d_%d",noticeVo.id,i))
					end
					panelBottom:addChild(itemIcon,5,1000 + i)

	 			end))
			end
		end
		scrollView:stopAllActions()
		scrollView:runAction(CCSequence:create(arr))
	else
		btnGet:setEnabled(false)
	end

	-------------------------动态调整滑块----------------------------------------------------------------------
	local dic = offsetY + (470-400) + panelBottom:getSize().height - scrollView:getSize().height
	if dic > 0 then

		scrollView:setInnerContainerSize(CCSize(scrollView:getSize().width,scrollView:getSize().height + dic ))
		local size = scrollView:getInnerContainerSize()
		-- 偏移所有
	    for i = 0, scrollView:getChildrenCount() - 1 do
	        local child = tolua.cast(scrollView:getChildren():objectAtIndex(i),"CCNode")
	        child:setPositionY(child:getPositionY() + dic)
	    end

	    panelBottom:setPositionY(0)
	end

-----------------------回赠按钮调整--------------------------------------------
end