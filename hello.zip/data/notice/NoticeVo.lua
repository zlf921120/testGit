
--公告 值对象
NoticeVo = class("NoticeVo")
NoticeVo.idx = 0 --页面下标
NoticeVo.id = 0 --唯一标识
NoticeVo.title = ""  --标题
NoticeVo.from = "" --来自
NoticeVo.time = 0 --发送时间
NoticeVo.cleanTime = 0 --清理时间
NoticeVo.content = 0 --内容
NoticeVo.signname = "" --署名
NoticeVo.iteminfos = nil --奖励物品列表
NoticeVo.isPop = false --是否弹窗
NoticeVo.isShowTip = 0 --是否要显示提示
NoticeVo.isAutoRemove = 0 --是否自动删除