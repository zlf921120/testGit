--
-- Author: thisgf
-- Date: 2015-01-15 20:18:29
-- 资源争夺相关数据结构

require "CombatVO"

--资源本基本数据
ResDungeonBaseData = class("ResDungeonBaseData")

--基础ID
ResDungeonBaseData.baseId = 0
--怪物列表
ResDungeonBaseData.monsterList = nil
--怪物名称
ResDungeonBaseData.monsterName = nil
--怪物等级
ResDungeonBaseData.monsterLevel = nil
--每小时产出类型
ResDungeonBaseData.produceType = 0
--每小时产出数量
ResDungeonBaseData.produceHour = 0
--第一次击败奖励类型
ResDungeonBaseData.firstRewardType = 0
--第一次击败奖励数量
ResDungeonBaseData.firstRewardQty = 0
--固定奖励类型
ResDungeonBaseData.fixRewardType = 0
--固定奖励数量
ResDungeonBaseData.fixRewardQty = 0


function ResDungeonBaseData:ctor()
end

function ResDungeonBaseData:create()
    return ResDungeonBaseData.new()
end


--资源本数据
ResDungeonData = class("ResDungeonData")

--基本数量
ResDungeonData.baseData = nil

--副本ID
ResDungeonData.id = 0
--基础ID
ResDungeonData.baseId = 0
--等级
ResDungeonData.level = 0
--占领状态
ResDungeonData.status = 0
--占领者ID
ResDungeonData.ownerId = nil
--占领者名字
ResDungeonData.ownerName = nil
--占领者等级
ResDungeonData.ownerLevel = 0
--能抢夺资源值
ResDungeonData.numContendRes = 0
--守卫列表
ResDungeonData.guards = nil
--占领时间(自己占领时>0)
ResDungeonData.ownTime = 0
--可收获资源量(自己占领时>0)
ResDungeonData.canGainsRes = 0
--到满的剩余时间
ResDungeonData.remainTime = 0
--资源满的总时间
ResDungeonData.maxFullTime = 0

--是否可以变对手
ResDungeonData.canChangeOppo = false

--产出速度(每小时)
ResDungeonData.produceSpeed = 0


function ResDungeonData:ctor()
end

function ResDungeonData:create()
    return ResDungeonData.new()
end



--守卫基本数据
ResGuardData = class("ResGuardData")

--基础ID
ResGuardData.baseId = 0
--模型ID
ResGuardData.modelId = 0
--头像ID
ResGuardData.avatarId = 0
ResGuardData.name = nil
ResGuardData.desc = nil
--1-6
ResGuardData.pos = 0
--前/中/后
ResGuardData.rowPos = 0
ResGuardData.race = 0
ResGuardData.attackType = 0
ResGuardData.stars = 0
ResGuardData.level = 1
ResGuardData.default_skills = nil --默认技能
ResGuardData.pas_skills = nil --默认技能
ResGuardData._pasSkillDataList = nil --被动技能列表
ResGuardData.atk_actions = nil --攻击动作列表
ResGuardData.dead_audio_id = 0

--当前升阶经验
ResGuardData.currentExp = 0

--升阶总经验
ResGuardData.totalExp = 0

--升阶总金币
ResGuardData.totalGold = 0

-- ResGuardData.currentHp = 0

--基础属性数据
ResGuardData.attrData = nil

--战斗用的属性
ResGuardData.battleAttrData = nil
ResGuardData._encryptAttrData = nil

--图鉴属性
ResGuardData.isAttrData = nil

function ResGuardData:ctor()

    self.default_skills = {}
    self.pas_skills = {}
    self.atk_actions = {}
    self._pasSkillDataList = {}

    self._encryptAttrData = BattleEncryptAttrData:create()

end

--设置守卫默认的技能
function ResGuardData:setDefaultSkill(act_skill1, act_skill2, act_skill3, pas_skill1, pas_skill2, pas_skill3)
    table.insert(self.default_skills,act_skill1)
    table.insert(self.default_skills,act_skill2)
    table.insert(self.default_skills,act_skill3)
    table.insert(self.pas_skills,pas_skill1)
    table.insert(self.pas_skills,pas_skill2)
    table.insert(self.pas_skills,pas_skill3)

    local skillInfo = nil
    for i, v in ipairs(self.pas_skills) do
        skillInfo = GuardSkillInfo:create()
        skillInfo:setData(v, 1)

        self._pasSkillDataList[i] = skillInfo
    end

end

--设置守卫技能对应的动作
function ResGuardData:setAtkAction(action1, action2, action3)

    table.insert(self.atk_actions, action1)
    table.insert(self.atk_actions, action2)
    table.insert(self.atk_actions, action3)
end

--[[
    获取当前等级
]]
function ResGuardData:getCurLevel()
    return self.level
end

--[[
    获取被动技能数据列表
]]
function ResGuardData:getPasSkillDataList()
    return self._pasSkillDataList
end

function ResGuardData:getEncryptAttrData()
    return self._encryptAttrData
end

function ResGuardData:setModelId(value)
    self.modelId = value
end

function ResGuardData:getModelId()
    return self.modelId
end

function ResGuardData:create()
    return ResGuardData.new()
end


--资源守卫属性数据
ResGuardAttrData = class("ResGuardAttrData")
ResGuardAttrData._attrs = nil

function ResGuardAttrData:ctor()
    self._attrs = {}
end

function ResGuardAttrData:setData(at, value)
    self._attrs[at] = value
end

function ResGuardAttrData:getData(at)
    return self._attrs[at]
end

function ResGuardAttrData:getAttrs()
    return self._attrs
end

function ResGuardAttrData:create()
    return ResGuardAttrData.new()
end


GuardSkillInfo = class("GuardSkillInfo")

GuardSkillInfo.skill_id = 0 --技能id
GuardSkillInfo.skill_lev = 0 --技能等级
GuardSkillInfo.is_open = false

function GuardSkillInfo:setData(skill_id, skill_lev)
    self.skill_id = skill_id
    self.skill_lev = skill_lev
    if skill_lev > 0 then
        self.is_open = true
    else
        self.is_open = false
    end
end

function GuardSkillInfo:getSkillId()
    return self.skill_id
end

function GuardSkillInfo:getSkillLevel()
    return self.skill_lev
end

function GuardSkillInfo:isOpen()
    return self.is_open
end

function GuardSkillInfo:create()
    local skill_info = GuardSkillInfo.new()
    return skill_info
end


--守卫升阶数据
GuardUpgradeCostData = class("GuardUpgradeCostData")

GuardUpgradeCostData.stars = 0
GuardUpgradeCostData.card = 0
GuardUpgradeCostData.gold = 0
GuardUpgradeCostData.growRation1 = 0
GuardUpgradeCostData.growRation2 = 0

function GuardUpgradeCostData:ctor()
end

function GuardUpgradeCostData:create()
    return GuardUpgradeCostData.new()
end


--资本本记录数据
ResRecordData = class("ResRecordData")

ResRecordData.time = 0
ResRecordData.camp = 0
ResRecordData.result = 0
ResRecordData.target = nil
ResRecordData.recordKey = nil
ResRecordData.dunId = 0
ResRecordData.res = 0

function ResRecordData:ctor()
end

function ResRecordData:create()
    return ResRecordData.new()
end


--资源守卫图鉴
ResGuardISData = class("ResGuardISData")

ResGuardISData.id = 0
ResGuardISData.attrData = nil

function ResGuardISData:ctor()

end

function ResGuardISData:create()
    return ResGuardISData.new()
end

--守卫映射 物品
ResGuardGoods = class("ResGuardGoods")
ResGuardGoods.guardId = 0 --守卫id
ResGuardGoods.baseId = 0 --物品id
ResGuardGoods.star = 0 --星数

function ResGuardGoods:create()
    return ResGuardGoods.new()
end
