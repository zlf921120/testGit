--
-- Author: thisgf
-- Date: 2015-02-10 13:24:02
-- 资源守卫图鉴属性总加成

ResContendAllISView = class("ResContendAllISView", AbstView.create)

ResContendAllISView._attrLabelList = nil

local MAX_ATTRS = 13

function ResContendAllISView:ctor()

end

function ResContendAllISView:init()
    
    self:_initLayer()

    local function onClose(sender, event)
        self:closeBySelf()
    end

    local alphaImage = ImageView:create()
    alphaImage:loadTexture("img_empty.png", UI_TEX_TYPE_PLIST)
    alphaImage:setAnchorPoint(ccp(0, 0))
    alphaImage:setScale9Enabled(true)
    alphaImage:setCapInsets(CCRect(0, 0, 1, 1))
    alphaImage:setSize(DisplayUtil.visibleSize)
    self._widgetGroup:addWidget(alphaImage)
    alphaImage:setTouchEnabled(true)
    alphaImage:addTouchEventListener(onClose)

    local bgImage = ImageView:create()
    bgImage:loadTexture("bg_2.png", UI_TEX_TYPE_PLIST)
    bgImage:setScale9Enabled(true)
    bgImage:setCapInsets(CCRect(30, 30, 20, 20))
    bgImage:setSize(CCSize(330, 400))
    bgImage:setPosition(DisplayUtil.centerPos)
    self._widgetGroup:addChild(bgImage)

    local titleLabel = Label:create()
    titleLabel:setColor(ccc3(0xff, 0x99, 0x00))
    titleLabel:setText("圖鑒收集總加成")
    titleLabel:setFontSize(22)
    titleLabel:setPosition(ccp(0, 180))
    bgImage:addChild(titleLabel)

    self._attrLabelList = {}

    local label
    for i = 1, MAX_ATTRS do
        label = Label:create()
        label:setColor(ccc3(0x11, 0xff, 0x00))
        label:setFontSize(20)
        label:setAnchorPoint(ccp(0, 0.5))
        label:setPosition(ccp(-50, 135 - (i - 1)*25))
        bgImage:addChild(label)
        self._attrLabelList[i] = label
    end

end

function ResContendAllISView:open()
    
    local attrs = self.params:getAttrs()

    for k, v in ipairs(self._attrLabelList) do
        v:setText("")
    end

    local index = 1

    for k, v in pairs(attrs) do

        if v > 0 then
            local label = self._attrLabelList[index]
            if not label then
                break
            end
            label:setText(
                string.format(
                    "%s+%d", 
                    AttrHelper:getAttrNameByFlag(k),
                    v
                )
            )
            index = index + 1
        end

    end

end

function ResContendAllISView:create()
    return ResContendAllISView.new()
end
