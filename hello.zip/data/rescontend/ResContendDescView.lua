--
-- Author: thisgf
-- Date: 2015-01-15 14:10:39
-- 资源争夺描述界面

require "TeamEnum"
require "ResContendData"
require "EffectManager"
require "ResContendGuardIcon"

ResContendDescView = class("ResContendDescView", AbstView.create)

ResContendDescView._rm = nil

ResContendDescView._dunId = 0
ResContendDescView._dunDiff = 0

ResContendDescView._guardIconList = {}

ResContendDescView._onRspDungeonData = nil
ResContendDescView._onUpdatePutOnGuard = nil
ResContendDescView._onUpdateGatherAsset = nil
ResContendDescView._onBattleRspEnd = nil
ResContendDescView._onUpdateGreen = nil


ResContendDescView._resDungeonData = nil

ResContendDescView._ownTime = 0
ResContendDescView._onUpdateOwnTime = nil
ResContendDescView._currentGatherAsset = 0
ResContendDescView._remainTime = 0
ResContendDescView._maxTime = 0
ResContendDescView._produceSecond = 0

ResContendDescView._gatherStatus = 0
ResContendDescView._robIdVersionDict = nil


ResContendDescView._descLabel = nil
ResContendDescView._levelLabel = nil
ResContendDescView._produceSpeedLabel = nil
ResContendDescView._guardLabel = nil
ResContendDescView._guardLevelLabel = nil

ResContendDescView._contendPanel = nil
ResContendDescView._assetImage1 = nil
ResContendDescView._numAssetLabel = nil

ResContendDescView._outPanel = nil
ResContendDescView._defenseTimeLabel = nil
ResContendDescView._assetImage2 = nil
ResContendDescView._numGatherAssetLabel = nil

ResContendDescView._guardNameLabel = nil

ResContendDescView._largeAssetPanel = nil
ResContendDescView._largeAssetImage = nil
ResContendDescView._gatherTipEffect = nil
ResContendDescView._labelFullCD = nil
ResContendDescView._beContendEffect = nil
ResContendDescView._gatherSuccessEffect = nil

ResContendDescView._assetImage = nil
ResContendDescView._ruleButton = nil
ResContendDescView._recordButton = nil
ResContendDescView._changeButton = nil
ResContendDescView._setButton = nil
ResContendDescView._attackButton = nil
ResContendDescView._dispatchButton = nil

ResContendDescView._recordTipImage = nil

ResContendDescView.btn_effect = nil                     --更换对手按钮特效
local btn_effect_path = "ui/effects_ui/UI_jianglilingqu/UI_jianglilingqu.ExportJson"

local _widgetPath = "ui/res_contend/res_contend_desc.json"

local MAX_ICON = 6

local GuardIcon

function ResContendDescView:ctor()
    
    self:_initData()
    self:_initUI()

    self:isShowBg(false)

end

function ResContendDescView:_initData()

    self._rm = ResContendManager:getInstance()

    self._onRspDungeonData = function(data)
        self:_updateDungeonData(data)
    end

    self._onUpdatePutOnGuard = function(dunId)

        if self._dunId ~= dunId then
            return
        end

        local guardDict = self._rm:getPutOnGuards(self._dunId)
        self:_updatePutOnGuard(guardDict)
    end

    self._onUpdateGatherAsset = function()
        self:_playGatherEffect()
    end

    self._onBattleRspEnd = function()
        self:_battleEnd()
    end

    self._onUpdateGreen = function()
        self:_showRecordTip()
    end
    
    ComResMgr:getInstance():loadResWithPlist(
        "ui/res_contend/res_contend_ui.plist"
    )

    self._onUpdateOwnTime = function()

        --超过48小时不显示时分秒
        if self._ownTime > 172800 then
            self._defenseTimeLabel:setText("2天以上")
            TimerManager.removeTimer(self._onUpdateOwnTime)
        else
            self._defenseTimeLabel:setText(Utils.formatTime(self._ownTime, ":"))
        end
        self._ownTime = self._ownTime + 1

        self._numGatherAssetLabel:setText(tostring(math.floor(self._currentGatherAsset)))
        
        if self._remainTime > 0 then
            self._remainTime = self._remainTime - 1
            self._currentGatherAsset = self._currentGatherAsset + self._produceSecond
        end

        if self._currentGatherAsset >= 1 then
            if self._gatherStatus ~= 1 then
                -- self._largeAssetImage:setTouchEnabled(true)
                self._largeAssetImage:setVisible(false)
                self._gatherTipEffect:setVisible(true)
                self._gatherTipEffect:getAnimation():playWithIndex(0)
                self._gatherStatus = 1
            end
        else
            if self._gatherStatus ~= 0 then
                self._largeAssetImage:loadTexture("rdui_treasure_open.png", UI_TEX_TYPE_PLIST)
                -- self._largeAssetImage:setTouchEnabled(false)
                self._largeAssetImage:setVisible(true)
                self._gatherTipEffect:setVisible(false)
                self._gatherTipEffect:getAnimation():stop()
                self._gatherStatus = 0
            end
        end

    end

    self._robIdVersionDict = {}

    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)

end

function ResContendDescView:_initUI()
    
    self:_initWidget(_widgetPath)

    local function onAssetClick(sender, event)
        if event ~= TOUCH_EVENT_ENDED then
            return
        end

        self._rm:reqGatherRes(self._dunId)
    end

    self._largeAssetPanel = self:_getWidget("panel_asset_large", ComponentType.LAYOUT)
    self._largeAssetImage = self:_getWidget("image_asset_large", ComponentType.IMAGE_VIEW)
    self._largeAssetImage:addTouchEventListener(onAssetClick)
    self._largeAssetImage:setTouchEnabled(true)
    self._labelFullCD = self:_getWidget("label_full_cd", ComponentType.LABEL)

    self._gatherTipEffect = EffectManager:getInstance():createUIAnimate("baozangkelingqu")
    self._gatherTipEffect:setVisible(false)
    -- self._gatherTipEffect:addTouchEventListener(onAssetClick)
    self._largeAssetPanel:addNode(self._gatherTipEffect)

    self._beContendEffect = EffectManager:getInstance():createUIAnimate("beizhanling")
    self._beContendEffect:setVisible(false)
    self._beContendEffect:setPosition(ccp(30, 10))
    self._largeAssetImage:addNode(self._beContendEffect)

    self._gatherSuccessEffect = EffectManager:getInstance():createUIAnimate("shouquchenggong")
    self._gatherSuccessEffect:setVisible(false)
    -- self._gatherSuccessEffect:setPosition(ccp(30, 10))
    self._largeAssetPanel:addNode(self._gatherSuccessEffect)


    self._descLabel = self:_getWidget("label_desc", ComponentType.LABEL)
    self._levelLabel = self:_getWidget("label_level", ComponentType.LABEL)
    self._produceSpeedLabel = self:_getWidget("label_p_speed", ComponentType.LABEL)
    self._guardLabel = self:_getWidget("label_guard", ComponentType.LABEL)
    self._guardLevelLabel = self:_getWidget("label_guard_level", ComponentType.LABEL)
    self._guardNameLabel = self:_getWidget("label_guard_name", ComponentType.LABEL)

    self._contendPanel = self:_getWidget("panel_contend", ComponentType.LAYOUT)
    self._contendPanel:setEnabled(false)
    self._assetImage1 = self:_getWidget("image_asset_1", ComponentType.IMAGE_VIEW)
    self._numAssetLabel = self:_getWidget("label_num_asset", ComponentType.LABEL)
    
    self._ourPanel = self:_getWidget("panel_our", ComponentType.LAYOUT)
    self._defenseTimeLabel = self:_getWidget("label_defense_time", ComponentType.LABEL)
    self._assetImage2 = self:_getWidget("image_asset_2", ComponentType.IMAGE_VIEW)
    self._numGatherAssetLabel = self:_getWidget("label_gather_asset", ComponentType.LABEL)
    

    self._ruleButton = self:_getWidget("button_rule", ComponentType.BUTTON)
    self._recordButton = self:_getWidget("button_record", ComponentType.BUTTON)

    self._recordTipImage = ImageView:create()
    self._recordTipImage:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
    self._recordTipImage:setEnabled(false)
    self._recordTipImage:setPosition(ccp(52, 14))
    self._recordButton:addChild(self._recordTipImage)

    self._changeButton = self:_getWidget("button_change", ComponentType.BUTTON)
    self._setButton = self:_getWidget("button_set", ComponentType.BUTTON)
    self._attackButton = self:_getWidget("button_attack", ComponentType.BUTTON)
    self._dispatchButton = self:_getWidget("button_dispatch", ComponentType.BUTTON)
    self._dispatchButton:setEnabled(false)

    self._assetImage = self:_getWidget("image_asset", ComponentType.IMAGE_VIEW)

    local infoContainer = self:_getWidget("image_guard_info", ComponentType.IMAGE_VIEW)
    local icon
    for i = 1, MAX_ICON do
        -- icon = GuardIcon:create()
        icon = ResContendGuardIcon:create()
        icon:setScale(0.8)
        icon:setPosition(ccp(-100 + (MAX_ICON - i) * 91, 0))
        infoContainer:addChild(icon)
        self._guardIconList[i] = icon
    end

    local function onButtonClick(sender, event)
        if event ~= TOUCH_EVENT_ENDED then
            return
        end

        if sender == self._setButton then
            WindowCtrl:getInstance():open(
                CmdName.Team_View, 
                {
                    id = self._dunId, 
                    subId = self._dunDiff, 
                    btnOkTitle = "進攻"
                }
            )
        elseif sender == self._ruleButton then
            -- WindowCtrl:getInstance():open(CmdName.RES_CONTEND_RULE_VIEW)
            WindowCtrl:getInstance():open(CmdName.Comm_DescPanel,
           {title="資源搶奪本",content=DungeonCfg.ResDungeonDesc,
            rewardArr = {{img="diamond.png",lab="鑽石"},
                         {img="gold.png",lab="金幣"},
                         {img="reward_hero_exp.png",lab="經驗藥"}}})

        elseif sender == self._recordButton then
            self:_hideRecrodTip()
            WindowCtrl:getInstance():open(CmdName.RES_CONTEND_RECORD_VIEW, self._dunId)
        elseif sender == self._attackButton then
            local heros = TeamManager:getInstance():getBattleHeroList()
            if table.maxn(heros) == 0 then
                WindowCtrl:getInstance():open(
                    CmdName.Team_View, 
                    {
                        id = self._dunId, 
                        subId = self._dunDiff, 
                        btnOkTitle = "進攻"
                    }
                )
            else
                BattleManager:getInstance():reqBattleStart(
                    self._dunId, 
                    self._dunDiff,
                    TeamType.Normal
                )
                --新手引导
                if GuideDataProxy:getInstance().nowMainTutroialEventId == 11005 then
                    Notifier.dispatchCmd(GuideEvent.StepFinish,"click_startbattle_resdungeon")
                end
            end
        elseif sender == self._changeButton then
            self._rm:reqChangeDungeon(self._dunId)
        elseif sender == self._dispatchButton then
            WindowCtrl:getInstance():open(
                CmdName.RES_CONTEND_GUARD_VIEW,
                {
                    dunId = self._dunId,
                    tag = 1
                }
            )
        end

    end

    self._ruleButton:addTouchEventListener(onButtonClick)
    self._changeButton:addTouchEventListener(onButtonClick)
    self._setButton:addTouchEventListener(onButtonClick)
    self._recordButton:addTouchEventListener(onButtonClick)
    self._attackButton:addTouchEventListener(onButtonClick)
    self._dispatchButton:addTouchEventListener(onButtonClick)

end

function ResContendDescView:open()

    DungeonView:getInstance():setTurnBtnView(false)
    DungeonView:getInstance():lockPanel(true)

    local id = self.params["dunId"]
    local diff = self.params["diff"]

    self._dunId = id
    self._dunDiff = diff

    Notifier.regist(CmdName.RES_CT_RSP_DUNGEON_DATA, self._onRspDungeonData)
    Notifier.regist(CmdName.RES_CT_UPDATE_PUTON_GUARD, self._onUpdatePutOnGuard)
    Notifier.regist(CmdName.RES_CT_UPDATE_GATHER, self._onUpdateGatherAsset)
    Notifier.regist(CmdName.BATTLE_RSP_END, self._onBattleRspEnd)
    Notifier.regist(CmdName.RES_CT_UPDATE_GREEN, self._onUpdateGreen)

    self._rm:reqDungeonInfo(self._dunId)

    local dungeonData = DungeonManager:getInstance():getDungeonData(
        self._dunId, self._dunDiff
    )

    -- self._resDungeonData = DungeonManager:getInstance():getResDungeonData(self._dunId)
    -- self._produceSecond = self._resDungeonData.produceHour / 3600

    -- self._produceSpeedLabel:setText(string.format(
    --     "%d/1小時", 
    --     self._resDungeonData.produceHour
    -- ))

    self._descLabel:setText(dungeonData._desc)
    self._labelFullCD:setText("")
    self._defenseTimeLabel:setText("")
    self._attackButton:setEnabled(false)
    self._setButton:setEnabled(false)
    self._changeButton:setEnabled(false)
    self._dispatchButton:setEnabled(false)

    --新手引导
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 11002 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"click_dungeon_90000")
    end

    self:_showRecordTip()

end

function ResContendDescView:showStepAnim(param)
    if param.target == "resdungeon_btnfight" then
        local btn = self._attackButton
        GuideRenderMgr:getInstance():renderMainFlag(btn,param.id,param.target)
    end
end

function ResContendDescView:_showRecordTip()

    

    local robs = self._rm:getBeRobIds()
    if not robs or #robs == 0 then
        self:_hideRecrodTip()
        return
    end

    local version = nil

    for _, v in ipairs(robs) do
        if v[2] == self._dunId then
            if self._robIdVersionDict[self._dunId] == v[1] then
                return
            end

            version = v[1]

            break
        end
    end

    if not version then
        self:_hideRecrodTip()
        return
    end

    self._robIdVersionDict[self._dunId] = version

    self._recordTipImage:setEnabled(true)
    self._recordTipImage:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    self._recordTipImage:runAction(forever_seqAction)
end

function ResContendDescView:_hideRecrodTip()
    self._recordTipImage:setEnabled(false)
    self._recordTipImage:stopAllActions()
end

function ResContendDescView:close()

    Notifier.remove(CmdName.RES_CT_RSP_DUNGEON_DATA, self._onRspDungeonData)
    Notifier.remove(CmdName.RES_CT_UPDATE_PUTON_GUARD, self._onUpdatePutOnGuard)
    Notifier.remove(CmdName.RES_CT_UPDATE_GATHER, self._onUpdateGatherAsset)
    Notifier.remove(CmdName.BATTLE_RSP_END, self._onBattleRspEnd)
    Notifier.remove(CmdName.RES_CT_UPDATE_GREEN, self._onUpdateGreen)

    DungeonView:getInstance():setTurnBtnView(true)
    DungeonView:getInstance():lockPanel(false)
    DungeonView:getInstance():_setChapterTitle()

    self._gatherTipEffect:getAnimation():stop()
    self._beContendEffect:getAnimation():stop()
    self._gatherSuccessEffect:getAnimation():stop()

end

function ResContendDescView:_updateDungeonData(data)

    self._produceSecond = data.produceSpeed / 3600

    self._produceSpeedLabel:setText(string.format(
        "%d/1小時", 
        data.produceSpeed
    ))

    self._levelLabel:setText(string.format("%d級", data.level))

    local assetName = ResContendEnum.REWARD_ASSET[data.baseData.produceType]
    self._numAssetLabel:setText(tostring(data.numContendRes))

    self._assetImage:loadTexture(assetName, UI_TEX_TYPE_PLIST)
    self._assetImage1:loadTexture(assetName, UI_TEX_TYPE_PLIST)
    self._assetImage2:loadTexture(assetName, UI_TEX_TYPE_PLIST)

    self._contendPanel:setEnabled(false)
    self._ourPanel:setEnabled(false)

    for _, v in pairs(self._guardIconList) do
        v:setIconData(0, 0)
    end

    self._changeButton:setEnabled(data.canChangeOppo)
    self:setBtnEffect(self._changeButton:isEnabled())

    TimerManager.removeTimer(self._onUpdateOwnTime)

    if data.status == ResContendEnum.STATUS.NONE then
        self._guardLabel:setText("敵方守衛:")
        self._guardLabel:setColor(ccc3(0xff, 0x99, 0x00))
        self._guardLevelLabel:setText(string.format("Lv.%d", data.baseData.monsterLevel))
        self._guardNameLabel:setText(string.format("%s", data.baseData.monsterName))

        self._contendPanel:setEnabled(true)

        for pos, mid in ipairs(data.baseData.monsterList) do
            local monsterInfo = MonsterManager:getInstance():getBaseInfo(mid)
            local guardIcon = self._guardIconList[pos]
            guardIcon:setIconData(monsterInfo.icon_res_id, 0)
            guardIcon:setStars(0)
        end

        self._setButton:setEnabled(true)
        self._attackButton:setEnabled(true)

        self._dispatchButton:setEnabled(false)

        self._largeAssetImage:loadTexture("rdui_treasure_close.png", UI_TEX_TYPE_PLIST)
        self._largeAssetImage:setVisible(true)
        -- self._largeAssetImage:setTouchEnabled(false)
        self._beContendEffect:setVisible(true)
        self._beContendEffect:getAnimation():playWithIndex(0)
        self._labelFullCD:setEnabled(false)

        self._gatherTipEffect:setVisible(false)
        self._gatherTipEffect:getAnimation():stop()

    elseif data.status == ResContendEnum.STATUS.OUR then

        self:_updatePutOnGuard(data.guards)

        self._guardLevelLabel:setText(string.format("Lv.%d", data.ownerLevel))
        self._guardNameLabel:setText(string.format("%s", data.ownerName))

        self._ownTime = data.ownTime
        self._remainTime = data.remainTime
        self._maxTime = data.maxFullTime
        self._currentGatherAsset = data.canGainsRes

        self._gatherStatus = -1

        TimerManager.addTimer(1000, self._onUpdateOwnTime, true)
        self:_onUpdateOwnTime()

        self._ourPanel:setEnabled(true)

        self._setButton:setEnabled(false)
        self._attackButton:setEnabled(false)

        self._dispatchButton:setEnabled(true)

        -- self._largeAssetImage:loadTexture("rdui_treasure_open.png", UI_TEX_TYPE_PLIST)
        -- self._largeAssetImage:setTouchEnabled(true)
        self._labelFullCD:setEnabled(true)
        if data.remainTime == 0 then
            self._labelFullCD:setText("資源已滿，請儘快領取")
        else
            local remainTime = os.date("!%H小時%M分後滿", data.remainTime)
            self._labelFullCD:setText(remainTime)
        end

        self._beContendEffect:setVisible(false)
        self._beContendEffect:getAnimation():stop()
        
    elseif data.status == ResContendEnum.STATUS.ENEMY then

        for pos, gd in pairs(data.guards) do
            local guardIcon = self._guardIconList[pos]
            guardIcon:setIconData(gd.avatarId, gd.rowPos)
            guardIcon:setStars(gd.stars)
        end

        self._guardLabel:setText("敵方佔領中...")
        self._guardLabel:setColor(ccc3(0x06, 0xff, 0x00))
        self._guardLevelLabel:setText(string.format("Lv.%d", data.ownerLevel))
        self._guardNameLabel:setText(string.format("%s", data.ownerName))

        self._contendPanel:setEnabled(true)

        self._setButton:setEnabled(true)
        self._attackButton:setEnabled(true)

        self._dispatchButton:setEnabled(false)

        self._largeAssetImage:loadTexture("rdui_treasure_close.png", UI_TEX_TYPE_PLIST)
        -- self._largeAssetImage:setTouchEnabled(false)
        self._largeAssetImage:setVisible(true)
        self._labelFullCD:setEnabled(false)

        self._beContendEffect:setVisible(true)
        self._beContendEffect:getAnimation():playWithIndex(0)

        self._gatherTipEffect:setVisible(false)
        self._gatherTipEffect:getAnimation():stop()

    end

end

function ResContendDescView:_updatePutOnGuard(guardDict)
    
    if not guardDict then
        return
    end

    if Utils.get_length_from_any_table(guardDict) == 0 then
        self._guardLabel:setText("請派遣守衛")
        self._guardLabel:setColor(ccc3(0xff, 0xf0, 0x00))
    else
        self._guardLabel:setText("我方佔領中...")
        self._guardLabel:setColor(ccc3(0x00, 0x84, 0xff))
    end

    for _, icon in ipairs(self._guardIconList) do
        icon:setIconData(0, 0)
    end

    local gi
    for pos, gd in pairs(guardDict) do
        gi = self._guardIconList[pos]
        gi:setIconData(gd.avatarId, gd.rowPos)
        gi:setStars(gd.stars)
    end

end

function ResContendDescView:_battleEnd()

    local resultData = BattleManager:getInstance():getBattleResultData()
    if not resultData then
        return
    end
    
    if BattleManager:getInstance():getIsOB() == false and 
        resultData.resultType == BattleResultType.VICTORY and 
        resultData.resContendData 
    then
        WindowCtrl:getInstance():open(CmdName.RES_CONTEND_OT_VIEW, {
            dunId = self._dunId, 
            res = resultData.resContendData
        })

    end

end

function ResContendDescView:_playGatherEffect()
    
    self._gatherSuccessEffect:setVisible(true)

    local animation = self._gatherSuccessEffect:getAnimation()
    animation:stop()

    local function movementCallback(armature, movementType, movementID)

        if movementType == ComConstTab.MovementEventType.COMPLETE then
            animation:stop()
            armature:setVisible(false)
            animation:setMovementEventCallFunc(Helper.tempAction)
        end
    end

    animation:setMovementEventCallFunc(movementCallback)
    animation:playWithIndex(0, -1, -1, 0)

end

function ResContendDescView:setBtnEffect(is_visible)
    if is_visible then
        if self.btn_effect == nil then
            self.btn_effect = AnimateManager:getInstance():getArmature(btn_effect_path,"UI_jianglilingqu") 
            -- self.btn_effect:setPosition(ccp(160,78))
            self.btn_effect:retain()
        end
        self.btn_effect:removeFromParentAndCleanup(true)
        self._changeButton:addNode(self.btn_effect)
        self.btn_effect:getAnimation():playWithIndex(0)
    else
        if self.btn_effect then
            self.btn_effect:getAnimation():stop()
            self.btn_effect:removeFromParentAndCleanup(true)
        end
    end
end


function ResContendDescView:create()

    local descView = ResContendDescView.new()
    return descView
end


--守卫图标
GuardIcon = class("GuardIcon", DisplayUtil.newWidget)

GuardIcon._iconImage = nil

function GuardIcon:ctor()
    
    local image = ImageView:create()
    image:loadTexture("normal_bg.png", UI_TEX_TYPE_PLIST)
    self:addChild(image)

    local border = ImageView:create()
    border:loadTexture("normal_border.png", UI_TEX_TYPE_PLIST)
    self:addChild(border)

    self._iconImage = ImageView:create()
    self:addChild(self._iconImage)

end

function GuardIcon:setIconId(value)
    if value == 0 then
        self._iconImage:setVisible(false)
    else
        self._iconImage:setVisible(true)
        self._iconImage:loadTexture(string.format("monster_%d.png", value), UI_TEX_TYPE_PLIST)
    end
end

function GuardIcon:create()
    return GuardIcon.new()
end
