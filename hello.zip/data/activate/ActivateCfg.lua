--激活 新功能 配置

ActivateCfg = {
	Altar = 10002, --召唤法阵(抽奖宝箱)
	Arena = 10004, --竞技场
	Authenticate = 10005, --鉴定
	Enchant = 10009, --附魔
	Forge = 10003, --强化
	Upgrade = 10014, --装备升级
	Glory = 10010, --星空神殿
	Inlay = 10011, --宝石镶嵌
	Tower = 10008, --恶魔塔
	Diff3 = 10007, --副本 噩梦难度
	Diff2 = 10001, --副本 困难难度
	Teature = 10006, --副本 宝藏副本
	Guild = 10012, --公会
	Elf = 10013, --侍宠精灵
	Mystery = 10015, --神秘商人
	Robdungeon = 10017, --资源抢夺本
	Secret = 10018, --解谜副本
	SkyBattle = 10019, --天空之役
	SecretDiff2 = 10020, --解谜副本难度2
}

--预备激活功能 背景图 映射
ActivatePerpareImg = {}
ActivatePerpareImg[10012] = "i18n_activate_guild_perpare.png"
ActivatePerpareImg[10004] = "i18n_activate_arena_perpare.png"

--激活 新功能 条件类型
ActivateCondType = {
	-- TeamLevelUp = 1, --战队等级
	HeroLevelUp = 2, --英雄等级
	TaskFinish = 3,   --完成任务
	DungeonPass = 4, --副本通关
}