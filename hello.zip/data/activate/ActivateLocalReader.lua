----------------------------------------------------------------------------
-- 激活功能 本地xls数据读取类
ActivateLocalReader = class("ActivateLocalReader")

local __instance = nil
local _allowInstance = false
local _hasLoad = false

function ActivateLocalReader:ctor()
    if not _allowInstance then
		error("ActivateLocalReader is a singleton class")
	end
	self:init()
end

function ActivateLocalReader:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = ActivateLocalReader.new()
		_allowInstance = false
	end

	return __instance
end

function ActivateLocalReader:init()
	require "fnt_activate_data_pb"
	require "ActivateDataProxy"
	require "ActivateNetTask"
	ActivateEventTask:getInstance()
end

function ActivateLocalReader:loadInProxy()

	if _hasLoad then return end--只加载一次
	_hasLoad = true
	
	local dp = ActivateDataProxy:getInstance()
-----------------------------------------------------------
    local pbdata = FileUtils.readConfigFile("fnt_activate_data.dat")
    local msg = fnt_activate_data_pb.fnt_activate_data()
    msg:ParseFromString(pbdata)

    local function make_cond(key) --创建条件 值对象
    	local condVo = dp:createCondVo()
    	condVo.key = key
    	condVo.params = {}
		local t = Utils.split(key,"_")
		for i=1,table.getn(t) do
			if i == 1 then
				condVo.type = t[i]
				-- print(" condVo.type ",condVo.type)
			else
				table.insert(condVo.params,t[i])
			end
		end
		return condVo
	end

	local function make_perpare_tip(mainCondVo,leftCondVo,key)
		if leftCondVo.type == "teamlev" then
			leftCondVo.forbid = string.format(key,mainCondVo.params[1])
		elseif leftCondVo.type == "dungeonpass" then
			local dungeonVo = DungeonManager:getInstance():getDungeonData(tonumber(mainCondVo.params[1]),tonumber(mainCondVo.params[2]))
			leftCondVo.forbid = string.format(key,dungeonVo._name,DungeonType[tonumber(mainCondVo.params[2])])
		end
	end
	local function make_tip(idx,eventVo,key) --创建未满足时 的提示
		local condVo = eventVo.condTbl[idx]
		if condVo.type == "teamlev" then
			condVo.forbid = string.format(key,condVo.params[1])
		elseif condVo.type == "dungeonpass" then
			local dungeonVo = DungeonManager:getInstance():getDungeonData(tonumber(condVo.params[1]),tonumber(condVo.params[2]))
			condVo.forbid = string.format(key,dungeonVo._name,DungeonType[tonumber(condVo.params[2])])
		else
			condVo.forbid = key
		end
	end

-------------------------------------------------------------
	local activateUnit = msg.activate_item_rows
    for k,v in pairs(activateUnit) do
    	if v.id ~= nil then
    		local eventVo = dp:createEventVo()
    		eventVo.id = v.id --事件id
    		if v.cond1 ~= "" then  --条件1
	    		eventVo.condTbl = {}
	    		table.insert(eventVo.condTbl,make_cond(v.cond1))
	    	end
	    	if v.cond2 ~= "" then  --条件2
	    		table.insert(eventVo.condTbl,make_cond(v.cond2))
	    	end
	    	if v.forbid1 ~= "" then
	    		make_tip(1,eventVo,v.forbid1)
	    	end
	    	-- if v.forbid2 ~= "" then
	    	-- 	make_tip(2,eventVo,v.forbid2)
	    	-- end

	    	if v.left_cond1 ~= "" then
	    		eventVo.leftCond = make_cond(v.left_cond1)
	    		make_perpare_tip(eventVo.condTbl[1],eventVo.leftCond,v.perpare_forbid)
	    	end

	    	eventVo.icon = v.icon
	    	eventVo.title = v.title
	    	eventVo.desc = v.desc
	    	eventVo.newViewId = v.view_id
	    	eventVo.is_no_pop = v.is_no_pop
    		dp:setEventVo(eventVo)
    	end
    end

end