--激活功能  数据代理
ActivateDataProxy = class("ActivateDataProxy")
ActivateDataProxy.voEventList = {} --激活功能事件
-- ActivateDataProxy.viewNewVoList = {} --显示新功能图标项列表
local __instance = nil
local _allowInstance = false

function ActivateDataProxy:ctor()
    if not _allowInstance then
		error("ActivateDataProxy is a singleton class")
	end
	self:init()
end

function ActivateDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = ActivateDataProxy.new()
		_allowInstance = false
	end

	return __instance
end

function ActivateDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function ActivateDataProxy:init()
	require "ActivateVo"
	require "ActivateCfg"
end

function ActivateDataProxy:createEventVo()
	return ActivateEventVo.new()
end
--获取已开启的功能id列表
function ActivateDataProxy:setHadBeenDoneList(list)
	for i=1,#list do
		print( " 已啟動id ",list[i].activate_id)
		--debug
		-- if list[i].activate_id ~= 10020 then
			local voEvent = self.voEventList[ list[i].activate_id ] 
			if voEvent then
				voEvent.hasExecute = 1
			end
		-- end
	end

	for k,voEvent in pairs(self.voEventList) do
		if voEvent.hasExecute == 1 then
			for k,v in pairs(list) do
				if voEvent.newViewId == v.activate_id then
					voEvent.hasViewNew = 1
					break
				end 
			end
		end
	end

	self:checkShowNewsImg() 
end

--检测是否显示[New]标示图标
function ActivateDataProxy:checkShowNewsImg()

	for k,v in pairs(self.voEventList) do
		-- print(" v.hasExecute ",v.id,v.hasExecute,v.hasViewNew)
		if v.hasExecute == 1 and v.hasViewNew == 0 then
			
			Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_IMG,v.newViewId) --显示new图
		end
	end
end

function ActivateDataProxy:getEventVoByViewNewId(viewId)
	for k,v in pairs(self.voEventList) do
		if v.newViewId == viewId then
			return v
		end
	end
end

function ActivateDataProxy:setEventVoDoneViewNew(viewId)
	local voEvent = self:getEventVoByViewNewId(viewId)
	if voEvent and voEvent.hasViewNew == 0 then
		voEvent.hasViewNew = 1
		Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_IMG,voEvent.newViewId)
		Timer.setTimer(1.5,function() --延后发请求
			CharacterNetTask:getInstance():requestRoleActivate(voEvent.newViewId)
		end)
	end
end

function ActivateDataProxy:isCanHideForgetNew()
	local voEvtEnchant = self:getEventVoByViewNewId(NewImgEnum.forge_enchant) 
	local voEvtGem = self:getEventVoByViewNewId(NewImgEnum.forge_gem) 
	local voEvtIdent = self:getEventVoByViewNewId(NewImgEnum.forge_identity) 
	local voEvtUpgrade = self:getEventVoByViewNewId(NewImgEnum.forge_upgrade)

	local e1 = voEvtEnchant.hasExecute == 1 and voEvtEnchant.hasViewNew == 0
	local e2 = voEvtGem.hasExecute == 1 and voEvtGem.hasViewNew == 0
	local e3 = voEvtIdent.hasExecute == 1 and voEvtIdent.hasViewNew == 0
	local e4 = voEvtUpgrade.hasExecute == 1 and voEvtUpgrade.hasViewNew == 0

	return e1 == false or e2 == false or e3 == false
end

function ActivateDataProxy:isCanHideDungeonNew()
	local voEvtDungeonDiff1 = self:getEventVoByViewNewId(NewImgEnum.dungeon_diff2)
	local voEvtDungeonDiff2 = self:getEventVoByViewNewId(NewImgEnum.dungeon_diff3)

	local e1 = voEvtDungeonDiff1.hasExecute == 1 and voEvtDungeonDiff1.hasViewNew == 0
	local e2 = voEvtDungeonDiff2.hasExecute == 1 and voEvtDungeonDiff2.hasViewNew == 0
	
	return e1 == false and e2 == false
end

function ActivateDataProxy:getEventVoList()
	return self.voEventList
end

function ActivateDataProxy:setEventVo(vo)
	self.voEventList[ vo.id ] = vo
end

function ActivateDataProxy:getEventVoById(id)
	return self.voEventList[ id ]
end

function ActivateDataProxy:createCondVo()
	return ActivateCondVo.new()
end

function ActivateDataProxy:cleanCond()
	for k,v in pairs(self.voEventList) do
		if v.hasExecute == 0 then
			v:clearCondDone()
		end
	end
end

--获取 锻造场 未开启的功能
function ActivateDataProxy:getForgeHideTbl()
	local ret = {}
	if self:isCanOpen(ActivateCfg.Authenticate,nil,false) == false then
		table.insert(ret,2)
	end
	if self:isCanOpen(ActivateCfg.Enchant,nil,false) == false then
		table.insert(ret,3)
	end
	if self:isCanOpen(ActivateCfg.Inlay,nil,false) == false then
		table.insert(ret,4)
	end
	if self:isCanOpen(ActivateCfg.Upgrade,nil,false) == false then
		table.insert(ret,5)
	end
	return ret
end
------------------------------------------------------------------------------
--检测 锻造屋内的new图 是否要显示
function ActivateDataProxy:showForgeNewImg(func)
	local voEvtEnchant = self:getEventVoByViewNewId(NewImgEnum.forge_enchant) 
	local voEvtGem = self:getEventVoByViewNewId(NewImgEnum.forge_gem) 
	local voEvtIdent = self:getEventVoByViewNewId(NewImgEnum.forge_identity) 
	local voEvtUpgrade = self:getEventVoByViewNewId(NewImgEnum.forge_upgrade)

	if voEvtEnchant.hasExecute == 1 and voEvtEnchant.hasViewNew == 0 then
		func(NewImgEnum.forge_enchant)
	end
	if voEvtGem.hasExecute == 1 and voEvtGem.hasViewNew == 0 then
		func(NewImgEnum.forge_gem)
	end
	if voEvtIdent.hasExecute == 1 and voEvtIdent.hasViewNew == 0 then
		func(NewImgEnum.forge_identity)
	end
	if voEvtUpgrade.hasExecute == 1 and voEvtUpgrade.hasViewNew == 0 then
		func(NewImgEnum.forge_upgrade)
	end
end

function ActivateDataProxy:showSecretNewImg(func)
	local voEvtDfif2 = self:getEventVoByViewNewId(NewImgEnum.secret_diff2) 

	if voEvtDfif2.hasExecute == 1 and voEvtDfif2.hasViewNew == 0 then
		func(NewImgEnum.secret_diff2)
	end
end

--检测 副本内的new图 是否要显示
function ActivateDataProxy:showDungeonNewImg(func)
	local voEvtDungeonDiff1 = self:getEventVoByViewNewId(NewImgEnum.dungeon_diff2)
	local voEvtDungeonDiff2 = self:getEventVoByViewNewId(NewImgEnum.dungeon_diff3)

	if voEvtDungeonDiff1.hasExecute == 1 and voEvtDungeonDiff1.hasViewNew == 0 then
		func(NewImgEnum.dungeon_diff2)
	end
	if voEvtDungeonDiff2.hasExecute == 1 and voEvtDungeonDiff2.hasViewNew == 0 then
		func(NewImgEnum.dungeon_diff3)
	end
end

----------------------------------------------------
-- 该账号是否满足开放条件
function ActivateDataProxy:isCanOpen(targetId, func, is_need_alert)
	local eventVo = self:getEventVoById(targetId)
	if eventVo then
		-- print(" ActivateDataProxy---->  eventVo.hasExecute ",targetId,eventVo.hasExecute)
		if eventVo.hasExecute == 1 then
			if func then
				func()
			end
			return true 
		end
		for i=1,#eventVo.condTbl do
			if eventVo.condTbl[i]:hasBeDone(is_need_alert) == false then
				-- print(" 不開啟 功能 ",targetId)
				return false
			end
		end

		if func then
			func() --都满足条件了
		end
		return true
	else
		return false
	end
end