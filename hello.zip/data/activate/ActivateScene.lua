--激活 功能面板
ActivateScene = class("ActivateScene",WindowBase)
ActivateScene.__index = ActivateScene
ActivateScene._widget = nil
ActivateScene.uiLayer = nil

function ActivateScene:create()
    local ret = ActivateScene.new()
    __instance = ret
    return ret   
end

local function event_btn_close(sender, eventType)
    if eventType == ComConstTab.TouchEventType.ended then
       	__instance:addCloseAnim()

       	ActivateDataProxy:getInstance():cleanCond()
    end
end

function ActivateScene:init()
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/activate/activate.plist")

	self._widget = GUIReader:shareReader():widgetFromJsonFile("activate/ActivateScene.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    local panel_main = tolua.cast(self._widget,"Layout")
	panel_main:addTouchEventListener(event_btn_close)
end

function ActivateScene:open()

	local id = self.params["id"]

	local eventVo = ActivateDataProxy:getInstance():getEventVoById(id)

	local imgIcon = tolua.cast(self._widget:getChildByName("img_icon"),"ImageView")
	imgIcon:loadTexture(string.format("activate_%s.png",eventVo.icon),UI_TEX_TYPE_PLIST)
	local labTitle = tolua.cast(self._widget:getChildByName("lab_title"),"Label")
	labTitle:setText(eventVo.title)
	local labDesc = tolua.cast(self._widget:getChildByName("lab_desc"),"Label")
	labDesc:setText(eventVo.desc)

	local p_1 = self._widget:getChildByName("p_1")
	local armature1 = AnimateManager:getInstance():getArmature("ui/effects_ui/xingongnengkaiqi/xingongnengkaiqi.ExportJson","xingongnengkaiqi")
	armature1:getAnimation():play("Animation1",0,-1,1)
	armature1:setPosition(ccp(p_1:getPosition()))
	armature1:setTag(240)
	self._widget:addNode(armature1)

	self:addOpenAnim()
end

function ActivateScene:close()
	if self._widget:getNodeByTag(240) ~= nil then
        self._widget:removeNodeByTag(240)
    end
	AnimateManager:getInstance():clear("ui/effects_ui/xingongnengkaiqi/xingongnengkaiqi.ExportJson")
	--新手引导
	if GuideDataProxy:getInstance().nowMainTutroialEventId == 11100 then
       Notifier.dispatchCmd(GuideEvent.StepFinish,"click_activate_10002")
    end
end