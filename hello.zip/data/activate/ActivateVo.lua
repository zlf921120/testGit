--激活 事件 值对象
ActivateEventVo = class("ActivateEventVo")
ActivateEventVo.id = 0
ActivateEventVo.newViewId = 0 --new图id
ActivateEventVo.hasExecute = 0
ActivateEventVo.hasViewNew = 0 --是否已经展示了New图
ActivateEventVo.leftCond = nil --"倒計時" 显示条件
ActivateEventVo.condTbl = nil  --条件数组
ActivateEventVo.icon = ""
ActivateEventVo.title = ""
ActivateEventVo.desc = ""
ActivateEventVo.is_no_pop = 0

function ActivateEventVo:isCanLaunch() --是否能触发事件
	local ret = true
	for i=1,#self.condTbl do
		if self.condTbl[i].isDone == 0 then --没满足这条件
			ret = false
			break
		end
	end
	return ret
end

function ActivateEventVo:clearCondDone()
	for i=1,#self.condTbl do
		self.condTbl[i].isDone = 0
	end
end

--触发条件 值对象
ActivateCondVo = class("ActivateCondVo")
ActivateCondVo.key = ""   --条件完整名称
ActivateCondVo.type = 0   --条件类型
ActivateCondVo.params = nil --条件参数(坐标,npcId等等)
ActivateCondVo.isDone = 0 --是否满足这条件  --[动态]
ActivateCondVo.forbid = "" --未满足时的提示

--[[
@params is_need_alert 是否显示提示语 true表示显示
--]]
function ActivateCondVo:hasBeDone(is_need_alert) --是否满足条件
	local ret = true
	if self.type == "teamlev" then
		local lev = CharacterDataProxy:getInstance():getTeamLev()
		if lev < tonumber(self.params[1]) then
			ret = false
		end
	elseif self.type == "dungeonpass" then
		DungeonManager:getInstance():parseDungeonData()
		local dungeonVo = DungeonManager:getInstance():getScheduleDungeonData(tonumber(self.params[1]),tonumber(self.params[2]))
		if dungeonVo == nil then
			ret = false
		else
			ret = dungeonVo._score ~= 0
		end
	elseif self.type == "has" and self.params[1] == "done" then --是否完成新手引导步骤
		local eventVo = GuideDataProxy:getInstance():getMainTutorialVoById(tonumber(self.params[2]))
		if eventVo.hasRecord == 1 then
			ret = true
		else
			ret = false
		end
	elseif self.type == "secretpass" then
		local curMaxDiff = SecretDataProxy:getInstance():getPassMaxDiff()
		if curMaxDiff >= tonumber(self.params[2]) then
			ret = true
		else
			ret = false
		end
	end
	if ret == false and is_need_alert~=false then
		Alert:show(self.forbid)
	end
	return ret
end