--激活新功能 事件
ActivateEvent = {
	Activate = "activate_activate",
	InitActivate = "activete_init",
}