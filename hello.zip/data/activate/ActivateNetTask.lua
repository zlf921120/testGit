
---------------------------------------------------------------------------
--激活功能事件代理
ActivateEventTask = class("ActivateEventTask")

local __instanceEventTask = nil
local _allowInstanceEventTask = false

function ActivateEventTask:ctor()
    if not _allowInstanceEventTask then
		error("ActivateEventTask is a singleton class")
	end
	self:init()
end

function ActivateEventTask:getInstance()
	if not __instanceEventTask then
		_allowInstanceEventTask = true
		__instanceEventTask = ActivateEventTask.new()
		_allowInstanceEventTask = false
	end

	return __instanceEventTask
end

function ActivateEventTask:destoryInstance()
	_allowInstanceEventTask = false
	__instanceEventTask = nil
end

-----------触发条件---------------------------------
local function checkDispatchEvent() 

	local dp = ActivateDataProxy:getInstance()
	local voList = dp:getEventVoList()
	local tmpList = {}
	for k,v in pairs( voList ) do
		table.insert(tmpList,v)
	end
	table.sort(tmpList, function(a,b)
		return a.id < b.id
	end)

	for idx=1,#tmpList do --注！一定要顺序遍历
		local v = tmpList[idx]
		if v.hasExecute == 0 and v:isCanLaunch() then --可触发事件
			v.hasExecute = 1
			TimerManager.addTimer(1000*idx,function() --延时请求
				CharacterNetTask:getInstance():requestRoleActivate(v.id)
			end)
			idx = idx + 1
			if v.is_no_pop == 0 then
				WindowCtrl:getInstance():open(CmdName.Comm_Activate,{id = v.id})
			end
			if v.id == NewTipsEnum.lottery then --开启 宝箱 抽奖
				LotteryDataProxy:getInstance().progressSchedule()
			end
			dp:checkShowNewsImg()
		end
		if v.leftCond ~= nil then --预备激活 功能
			if v.leftCond.isDone == 1 then
				Notifier.dispatchCmd(CmdName.MAIN_SHOW_ACTIVATE_ITEM,v.id)
			end
			if v.hasExecute == 1 then --已经激活的功能 不用显示预备激活
				Notifier.dispatchCmd(CmdName.MAIN_HIDE_ACTIVATE_ITEM,v.id)
			end
		end
	end
end

-- function ActivateEventTask:debugDoneDungeon()
-- 	local dp = ActivateDataProxy:getInstance()
-- 	local voEvtDungeonDiff1 = dp:getEventVoByViewNewId(NewImgEnum.dungeon_diff2)
-- 	local voEvtDungeonDiff2 = dp:getEventVoByViewNewId(NewImgEnum.dungeon_diff3)
-- 	voEvtDungeonDiff2.hasExecute = 1
-- 	voEvtDungeonDiff1.hasExecute = 1 
-- 	WindowCtrl:getInstance():open(CmdName.Comm_Activate,{id = voEvtDungeonDiff1.id})

-- 	dp:checkShowNewsImg()
-- end

local function executeCond(key) --满足 条件
	local voList = ActivateDataProxy:getInstance():getEventVoList()

	for k,v in pairs(voList) do
		local condTbl = v.condTbl 
		for j=1,table.getn(condTbl) do
			if condTbl[j].key == key then
				condTbl[j].isDone = 1 
			end
		end

		if v.leftCond ~= nil then --预备激活 功能
			if v.leftCond.key == key then
				v.leftCond.isDone = 1
			end
		end
	end
end
-------------------------------------------------------
function ActivateEventTask:init()
	require "ActivateEvent"
	require "ActivateCfg"
	require "ActivateDataProxy"
	require "ActivateLocalReader"
	require "DungeonManager"
	require "BattleManager"
	local function initActivate()
    	-- DungeonManager:getInstance():parseDungeonData()

    	ActivateLocalReader:getInstance():loadInProxy()
    	ActivateDataProxy:getInstance():setHadBeenDoneList(CharacterManager:getInstance():getBaseData():getActivateList())

    	Notifier.removeByName(ActivateEvent.InitActivate)
	end
	Notifier.regist(ActivateEvent.InitActivate,initActivate)

--------------------------------------------------------------
	Notifier.regist(CmdName.BATTLE_RSP_END,function()
		self:activateHandleBattleEnd()
	end)
	Notifier.regist(ActivateEvent.Activate,function(msg)
		if msg[1] == ActivateCondType.HeroLevelUp then
			self:event_hero_levelup(msg)
		elseif msg[1] == ActivateCondType.TeamLevelUp then
			self:event_team_levelup(msg)
		elseif msg[1] == ActivateCondType.TaskFinish then
			self:event_task_finish(msg)
		end
	end)
	-- Notifier.regist(GuideEvent.Main,function(msg)
	-- 	if msg[1] == GuideCondType.Trigger then
	-- 		self:event_tutoral_trigger(msg)
	-- 	end
	-- end)
end

function ActivateEventTask:activateHandleBattleEnd()
	local batResData = BattleManager:getInstance():getBattleResultData()
	if BattleManager:getInstance():getIsOB() or batResData == nil then
        return
    end

	local startData = BattleManager:getInstance():getStartData()
	local dungeonId = startData.id
	local diff = startData.subId
	self:event_dungeon_pass({dungeonId,diff})
end

function ActivateEventTask:event_team_levelup(msg)
	local oldLev = msg[2]
	local newLev = msg[3]

	for i = oldLev,newLev do
		local key = string.format("teamlev_%d",i)

		executeCond(key)
		checkDispatchEvent()
	end
end

-- function ActivateEventTask:event_tutoral_trigger(msg)
-- 	local eventId = msg[2]
-- 	local key = string.format("has_done_%d",eventId)

-- 	print(" event_tutoral_trigger !! ",key)
-- 	executeCond(key)
-- 	checkDispatchEvent()
-- end

function ActivateEventTask:event_hero_levelup(msg)
	local lev = msg[2]
	local key = string.format("herolev_%d",lev)

	executeCond(key)
	checkDispatchEvent()
end

function ActivateEventTask:event_task_finish(msg)
	local taskId = msg[2]
	local key = string.format("task_%d",taskId)

	executeCond(key)
	checkDispatchEvent()
end

function ActivateEventTask:event_dungeon_pass(msg)
	local dungeonId = msg[1]
	local diff = msg[2]
	local key = string.format("dungeonpass_%d_%d",dungeonId,diff)

	executeCond(key)
	checkDispatchEvent()
end

function ActivateEventTask:event_secret_pass()
	--初始化 解谜副本
	local maxDiff = SecretDataProxy:getInstance():getPassMaxDiff()
	for i=2,4 do
		if maxDiff >= i then
			local key = string.format("secretpass_diff_%d",i)
			executeCond(key)
		end
	end

	checkDispatchEvent()
end

function ActivateEventTask:initPerpareItem()
	local teamLev = CharacterManager:getInstance():getTeamData():getLev()
	local voList = ActivateDataProxy:getInstance():getEventVoList()
	local tmpList = {}
	for k,v in pairs( voList ) do
		table.insert(tmpList,v)
	end
	table.sort(tmpList, function(a,b)
		return a.id < b.id
	end)
	
	for i=1,#tmpList do
		local v = tmpList[i]
		if v.leftCond ~= nil then --预备激活 功能
			-- print(" tonumber(v.leftCond.params[1]) ",tonumber(v.leftCond.params[1]) , tonumber(v.condTbl[1].params[1]) )
			if tonumber(v.leftCond.params[1]) <= teamLev and tonumber(v.condTbl[1].params[1]) > teamLev then
				v.leftCond.isDone = 1
			end
		end
	end

	for i=1,#tmpList do
		local v = tmpList[i]
		if v.leftCond ~= nil then --预备激活 功能
			if v.leftCond.isDone == 1 then
				Notifier.dispatchCmd(CmdName.MAIN_SHOW_ACTIVATE_ITEM,v.id)
			end
			if v.hasExecute == 1 then --已经激活的功能 不用显示预备激活
				Notifier.dispatchCmd(CmdName.MAIN_HIDE_ACTIVATE_ITEM,v.id)
			end
		end
	end

	--初始化 副本数据
	local voDungeonList = DungeonManager:getInstance():getDungeonDataDic()
	for k,list in pairs(voDungeonList) do
		for k,v in pairs(list) do
			if v._score ~= 0 then
				local key = string.format("dungeonpass_%d_%d",v._id,v._diff)
				executeCond(key)
			end
		end
	end

	if ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Secret,nil,false) then --开启解谜副本
		--初始化 解谜副本
		local maxDiff = SecretDataProxy:getInstance():getPassMaxDiff()
		-- print(" maxDiff ",maxDiff)
		for i=2,4 do
			if maxDiff >= i then
				local key = string.format("secretpass_diff_%d",i)
				executeCond(key)
			end
		end
	end
	checkDispatchEvent()
end