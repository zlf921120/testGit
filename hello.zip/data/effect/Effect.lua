--
-- Author: thisgf
-- Date: 2014-06-18 14:20:15
-- 特效显示类

require "AnimateManager"
require "EffectEnum"
require "DisplayUtil"

Effect = class("Effect", DisplayUtil.newNode)

Effect.UNIQUE_KEY = 1

Effect._effectId = 0
Effect._fileName = ""
Effect._effectData = nil

--特效容器
Effect._container = nil

Effect._armatureEffect = nil
Effect._particleEffect = nil

--是否已经初始化
Effect._isInit = false

--是否循环
Effect._isLoop = -1

--是否播放中
Effect._isPlay = false
--延迟播放时间
Effect._delay = 0
--延迟序列动作
Effect._delayAction = nil
Effect._delayCallFunc = nil
--当前播放次数
Effect._curPlayTimes = 0
--总共的播放次数
Effect._totalPlayTimes = 0

--相同时的区别
Effect._sameUnique = 0


--粒子特效播放完成函数
Effect._particlePlayedFunc = nil

Effect._internalCallback = nil

--回调函数字典
Effect._callbackDict = nil

Effect._completeCallback = nil
Effect._completeCallbackParams = nil

Effect._triggerCallback = nil
Effect._triggerCallbackParm = nil

Effect._beginCallback = nil
Effect._beginCallbackParam = nil

Effect._isAutoRemove = true

local _animateManager

--[[
    获取特效文件路径
]]
--[[
local function getEffectPath(fileName, effectType)
	if effectType == EffectType.SequenceEffect or effectType==EffectType.Action then
		return string.format("ui/effects/%s/%s.ExportJson", fileName, fileName)
	elseif effectType == EffectType.ParticleEffect then
		return string.format("ui/effects/particle/%s.plist", fileName)
	end

	return nil

end
]]--

function Effect:ctor(effectId)

	self._effectId = effectId

	self._effectData = EffectManager:getInstance():getEffectData(effectId)

	if not self._effectData then
		cclog("---------此特效%d沒有配置資料", effectId)
	end

	self._fileName = self._effectData._fileName

	self._callbackDict = {}

	_animateManager = AnimateManager:getInstance()

	self:_genEffect()

end

function Effect:setLoop(isLoop)
	self._isLoop = isLoop

	if self._isLoop == -1 then
		self._totalPlayTimes = self._effectData._playTimes
	elseif self._isLoop == 0 then
		self._totalPlayTimes = 0
	else
		self._totalPlayTimes = isLoop
	end

end

--[[
    设置播放延迟时间(ms)
    @param value
]]
function Effect:setDelay(value)
	self._delay = value
end

function Effect:setIsAutoRemove(value)
	self._isAutoRemove = value
end

--[[
    设置和EffectManager交互的完成函数
]]
function Effect:_setInternalComplete(value)
	self._internalCallback = value
end

function Effect:setCallback(value)

	for k,v in pairs(value) do

		if k == CallbackType.complete then

			if type(v) == "function" then

				self._callbackDict[CallbackType.complete] = v

				self._completeCallbackParams = value.completeParams

			else
				self._callbackDict[CallbackType.complete] = nil
				self._completeCallbackParams = nil

			end
		end
	end

	self._completeCallback = completeCallback

end

function Effect:setContainer(value)

	self._container = value
end

function Effect:_genEffect()

	if self._isInit then
		return
	end

	self._isInit = true

	--local effectPath = getEffectPath(self._fileName, self._effectData:getType())
	local effectPath = self._effectData._fileFullPathName

	if self._effectData._type == EffectType.SequenceEffect then   --序列帧特效

		--特效名称为文件名称
		self._armatureEffect = _animateManager:getArmature(effectPath, self._fileName)
		self:addChild(self._armatureEffect)
		self._armatureEffect:setVisible(false)
		self._armatureEffect:getAnimation():setMovementEventCallFunc(function(...) self:_movementEventCallFunc(...) end)

	elseif self._effectData._type == EffectType.ParticleEffect then  --粒子特效

		self._particleEffect = CCParticleSystemQuad:create(effectPath)
		self._particleEffect:stopSystem()
		self:addChild(self._particleEffect)
		self._particleEffect:setVisible(false)

	end

end

--动画片段播放完成回调
function Effect:_movementEventCallFunc(armature, movementType, movementID)

	if movementType == AnimationMovementType.COMPLETE or 
		movementType == AnimationMovementType.LOOP_COMPLETE then

		self:_playComplete()

	end

end

function Effect:setSameUnique(value)
	self._sameUnique = value
end

function Effect:getSameUnique()
	return self._sameUnique
end

--开始播放
function Effect:play()

	if self._isPlay then
		return
	end

	if self._armatureEffect or self._particleEffect then

		self._isPlay = true

		if self._delay > 0 then

			self._delayCallFunc = function()
			    self:_startPlay()
			end

			TimerManager.addTimer(self._delay, self._delayCallFunc, false)

			return

		else
			self:_startPlay()
		end

	end

end

function Effect:_startPlay()

	if self._armatureEffect then

		self._armatureEffect:setVisible(true)
		self._armatureEffect:getAnimation():playWithIndex(0)

	elseif self._particleEffect then

		self._particlePlayedFunc = function()
		    self:_playComplete()
		end

		self._particleEffect:setVisible(true)
		self._particleEffect:resetSystem()

		--非循环播放
		if self._effectData._duration > 0 then
			TimerManager.addTimer(self._effectData._duration, self._particlePlayedFunc, false)
		end

	end

end

--重置播放
function Effect:reset()

	self:stop()
	self:play()

end

--停止播放
function Effect:stop()

	if self._isPlay == false then
		return
	end

	self._curPlayTimes = 0

	TimerManager.removeTimer(self._delayCallFunc)
	TimerManager.removeTimer(self._particlePlayedFunc)

	self._isPlay = false

	if self._armatureEffect then

		self._armatureEffect:getAnimation():stop()
		-- self._armatureEffect:setVisible(false)

	elseif self._particleEffect then

		self._particleEffect:stopSystem()
		self._particleEffect:setVisible(false)

	end

end

function Effect:_playComplete()

	if self._effectData._type == EffectType.SequenceEffect then
		--循环播放
		if self._totalPlayTimes == 0 then
			return
		else

			self._curPlayTimes = self._curPlayTimes + 1
			if self._curPlayTimes < self._totalPlayTimes then
				return
			end
		end

	elseif self._effectData._type == EffectType.ParticleEffect then

	end

	self:stop()

	if self._internalCallback then
		self._internalCallback(self)
	end

end

function Effect:getEffectId()
	return self._effectId
end

function Effect:getContainer()
	return self._container
end

function Effect:getData()
	return self._effectData
end

--[[
    获取显示内容
    @return armature/particle
]]
function Effect:getContent()

	if self._armatureEffect then
		return self._armatureEffect
	end

	return self._particleEffect

end

--是否播放中
function Effect:isPlay()
	return self._isPlay
end

function Effect:isAutoRemove()
	return self._isAutoRemove
end

function Effect:dispose()

	self:stop()

	self._container = nil
	self._internalCallback = nil
	self._callbackDict = nil

	TimerManager.removeTimer(self._delayCallFunc)
	TimerManager.removeTimer(self._particlePlayedFunc)

	if self._armatureEffect then
		self._armatureEffect:removeFromParentAndCleanup(true)
	end

	if self._effectData._type == EffectType.SequenceEffect then
		AnimateManager:getInstance():releaseArmature(self._effectData._fileFullPathName)
	end

	self._effectData = nil

	self:removeFromParentAndCleanup(true)

end

function Effect:create(effectId)

	local effect = Effect.new(effectId)

	return effect

end

