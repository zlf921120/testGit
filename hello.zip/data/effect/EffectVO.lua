--
-- Author: thisgf
-- Date: 2014-06-18 14:20:28
-- 特效数据类

EffectType = {
    SequenceEffect = 1,   --序列帧特效
    ParticleEffect = 2,    --粒子特效
    Action = 3             --动作文件
}

ActionPath = "ui/effects"
ParticleEffectPath = "ui/effects/particle"

EffectVO = class("EffectVO")

EffectVO._id = 0

--文件名称
EffectVO._fileName = ""
--播放次数(0表示循环播放)
EffectVO._playTimes = 0
--类型
EffectVO._type = 1
--持续时间(粒子特效, 0表示一直播放)
EffectVO._duration = 0

--路径
EffectVO._fileFullPathName = ""

--运动速度
EffectVO._moveSpeed = 0

--是否跟随人物反转
EffectVO._needFlip = true

--特效层次
EffectVO._hierarchy = 1

--飞行特效方向
EffectVO._flyDirectType = 1

--飞行起始点
EffectVO._flyStartPos = nil

--飞行目标点
EffectVO._flyTargetPos = nil

function EffectVO:getFileName()
	return self._fileName
end

function EffectVO:getPlayTimes()
	return self._playTimes
end

function EffectVO:getType()
	return self._type
end

function EffectVO:getDuration()
	return self._duration
end

function EffectVO:getMoveSpeed()
	return self._moveSpeed
end

function EffectVO:needFlip()
	return self._needFlip
end

function EffectVO:getHierarchy()
	return self._hierarchy
end

function EffectVO:getFlyDirectType()
	return self._flyDirectType
end

function EffectVO:getFlyStartPos()
	return self._flyStartPos
end

function EffectVO:getFlyTargetPos()
	return self._flyTargetPos
end

--文件路径
function EffectVO:getFileFullPathName()
	return self._fileFullPathName
end

function EffectVO:ctor()
end

function EffectVO:create()

	local effectData = EffectVO.new()

	return effectData

end

--模型动画数据
ModelAnimationVO = class("ModelAnimationVO", EffectVO:create())

--入场动作起始帧
ModelAnimationVO.enterFromFrame = nil
--入场动作结束帧
ModelAnimationVO.enterToFrame = nil

--默认飞行特效
ModelAnimationVO.defaultFlyEffect = 0

--默认身体高度
ModelAnimationVO.defaultBodyHeight = 0

ModelAnimationVO.skillHaloOffset = nil

function ModelAnimationVO:ctor()

end

function ModelAnimationVO:create()

	local data = ModelAnimationVO.new()
	return data
end


