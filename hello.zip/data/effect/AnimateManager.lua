--
-- Author: thisgf
-- Date: 2014-06-19 10:29:38
-- 动画管理器

AnimateManager = class("AnimateManager")

AnimateManager._animationWithFrameList = nil

AnimateManager._armaturePathDict = nil

local _armatureManager = nil

local _instance
local _allowInstance

--骨骼动画回收对象
local ArmatureGCObject = nil

function AnimateManager:ctor()

	_armatureManager = CCArmatureDataManager:sharedArmatureDataManager()

	self._animationWithFrameList = {}

	self._armaturePathDict = {}

	-- TimerManager.addTimer(Helper.GC_TIME.ARMATURE, function() 
	-- 	self:_startGC()
	-- end, true)

end

function AnimateManager:getInstance()
	
	if not _instance then
		_allowInstance = true
		_instance = AnimateManager.new()
		_allowInstance = false
	end

	return _instance
end

--[[
    获取骨骼动画
    @param configPath 配置文件路径
    @param armatureName 骨骼动画名字
    @return CCArmature
]]
function AnimateManager:getArmature(configPath, armatureName)

	local gcObject = self._armaturePathDict[configPath]

	-- 统计使用数量
	if not gcObject then

		gcObject = ArmatureGCObject:create()
		gcObject.retainCount = 1

		-- _armatureManager:addArmatureFileInfo(configPath)
		self._armaturePathDict[configPath] = gcObject
		
	else
		gcObject.retainCount = gcObject.retainCount + 1
	end

	_armatureManager:addArmatureFileInfo(configPath)
	local armature = CCArmature:create(armatureName)

	return armature

end

function AnimateManager:getArmatureFromEffectId(value)

	local actionData
	repeat
		actionData = EffectManager:getInstance():getActionData(value)
		if actionData then
			break
		end

		actionData = EffectManager:getInstance():getEffectData(value)
		if actionData then
			break
		end
		
	until true

	if not actionData then
		return
	end

	return self:getArmature(actionData:getFileFullPathName(), actionData:getFileName())
end

function AnimateManager:getArmatureAsync()

end

function AnimateManager:getAnimationFromArmature(configPath, armatureName)
	
	local armature = self:getArmature(configPath, armatureName)

	return armature:getAnimation()

end

function AnimateManager:clear(configPath)
	_armatureManager:removeArmatureFileInfo(configPath)
end

--[[
    根据帧播放骨骼动画
    @param animation
    @param fromFrame 起始帧
    @param toFrame 结束帧
    @param playTimes 播放次数(0:循环, >0:N次)
    @param callback 完成回调
]]
function AnimateManager:playAnimationWithFrame(animation, animationName, fromFrame, toFrame, playTimes, callback)

	animation:play(animationName, -1, -1, 0)
	animation:gotoAndPause(fromFrame)

	if fromFrame == toFrame then
		if callback then
			callback(1)
		end
		return
	end

	local increase = 1

	local currentTimes = 0

	if toFrame < fromFrame then
		increase = -1
	end

	local currentFrame = fromFrame

	local function enterFrame()

		currentFrame = currentFrame + increase

		animation:gotoAndPause(currentFrame)

		if currentFrame == toFrame then

			currentFrame = fromFrame
			if playTimes > 0 then

				currentTimes = currentTimes + 1

				if currentTimes == playTimes then

					self._animationWithFrameList[animation] = nil
					TimerManager.removeTimer(enterFrame)
				end
			end

			if callback then
				callback(currentTimes)
			end

		end

	end

	local oldFunc = self._animationWithFrameList[animation]
	if oldFunc then
		TimerManager.removeTimer(oldFunc)
	end

	self._animationWithFrameList[animation] = enterFrame

	TimerManager.addTimer(40, enterFrame, true)

end

--[[
    停止根据帧的动画播放
]]
function AnimateManager:stopAnimationWithFrame(animation)

	local oldFunc = self._animationWithFrameList[animation]

	if oldFunc then
		TimerManager.removeTimer(oldFunc)
	end

	self._animationWithFrameList[animation] = nil

end

--[[
    释放骨骼动画
]]
function AnimateManager:releaseArmature(configPath)

	local gcObject = self._armaturePathDict[configPath]

	if not gcObject then
		return
	end

	gcObject.retainCount = gcObject.retainCount - 1

	if gcObject.retainCount < 1 then
		self._armaturePathDict[configPath] = nil
		_armatureManager:removeArmatureFileInfo(configPath)
		-- cclog("釋放的骨骼動畫路徑~~~%s",configPath)
	end

end

--[[
    手动删除动画文件
]]
function AnimateManager:removeArmatureWithManual(configPath)

	local gcObject = self._armaturePathDict[configPath]

	if gcObject then
		if gcObject.retainCount > 1 then
			cclog("回收數量大於1的骨骼動畫:%s", configPath)
		end
	end

	self._armaturePathDict[configPath] = nil

	_armatureManager:removeArmatureFileInfo(configPath)

end

function AnimateManager:_startGC()

	for configPath, v in pairs(self._armaturePathDict) do
		if v.retainCount < 1 then
			_armatureManager:removeArmatureFileInfo(configPath)
			self._armaturePathDict[configPath] = nil
		end
	end

end


ArmatureGCObject = class("ArmatureGCObject")

--剩余次数
ArmatureGCObject.retainCount = 0

--回收类型(手动/自动回收)
ArmatureGCObject.gcType = 0

function ArmatureGCObject:ctor()
end

function ArmatureGCObject:create()

	local gcObject = ArmatureGCObject.new()

	return gcObject

end