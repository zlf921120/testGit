--
-- Author: thisgf
-- Date: 2014-06-19 15:10:39
-- 特效枚举

--特效类型
EffectType = {
	--序列帧特效
    SequenceEffect = 1,
    --粒子特效
    ParticleEffect = 2,
    --动作
    Action = 3
}

--特效层次类型
EffectHierarchyType = 
{
    TOP = 1,
    BOTTOM = 2
}

--动画块事件类型
AnimationMovementType = {

    START = 0,
	COMPLETE = 1,
	LOOP_COMPLETE = 2
	
}

--回调类型
CallbackType = {

    complete = "onComplete"

}


EffectEnum = {}

--男主角动作ID
EffectEnum.MALE_ACTION_ID = 30000
--女主角动作ID
EffectEnum.FEMALE_ACTION_ID = 30001
--男主角白骑士ID
EffectEnum.MALE_WHITE_ACTION_ID = 30019
--女主角白骑士ID
EffectEnum.FEMALE_WHITE_ACTION_ID = 30020
