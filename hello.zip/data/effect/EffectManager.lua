-- Author: thisgf
-- Date: 2014-06-18 11:05:33
-- 特效管理器

require "fnt_effect_data_pb"
require "EffectVO"
require "Effect"
require "DisplayUtil"
require "FileUtils"

EffectManager = class("EffectManager")

--特效容器字典
EffectManager._effectContainerDict = nil
--特效数据字典
EffectManager._effectDataDict = nil

--动作数据字典(区别于特效数据)
EffectManager._actionDataDict = nil

EffectManager._isParseData = false


local _instance
local _allowInstance

function EffectManager:ctor()

	self._effectContainerDict = {}
	self._effectDataDict = {}
	self._actionDataDict = {}

end

function EffectManager:getInstance()

	if not _instance then
		_allowInstance = true
		_instance = EffectManager.new()
		_allowInstance = false
	end

	return _instance

end

function EffectManager:parseEffectData()

	if self._isParseData == true then
		return
	end

	self._isParseData = true

	local configData = FileUtils.readConfigFile("fnt_effect_data.dat")

	local effect_data_pb = fnt_effect_data_pb.fnt_effect_data()
	effect_data_pb:ParseFromString(configData)

	local effectData = nil

	for k,v in pairs(effect_data_pb.effect_rows) do

		if v.id ~= nil then

			if v.type == EffectType.Action then
				effectData = ModelAnimationVO:create()
			else
				effectData = EffectVO:create()
			end

			effectData._id = v.id
			effectData._fileName = v.file_name
			effectData._type = v.type
			effectData._playTimes = v.play_times
			effectData._duration = v.duration
			effectData._moveSpeed = v.fly_speed
			effectData._needFlip = v.need_flip == 1
			
			-- if effectData._moveSpeed ~= 0 then
			-- 	effectData._playTimes = 0
			-- end
			
			if v.type == EffectType.Action then
				self._actionDataDict[v.id] = effectData
				effectData._fileFullPathName = string.format( "%s/%s/%s.ExportJson", ActionPath, v.file_name, v.file_name )
			elseif v.type == EffectType.SequenceEffect then
				self._effectDataDict[v.id] = effectData
				effectData._fileFullPathName = string.format( "%s/%s/%s.ExportJson", ActionPath, v.file_name, v.file_name )
			else
				self._effectDataDict[v.id] = effectData
				effectData._fileFullPathName = string.format( "%s/%s.plist", ParticleEffectPath, v.file_name )
			end
		end
	end

	for k, v in pairs(effect_data_pb.animation_data_rows) do

		if v.id then

			local actionData = self._actionDataDict[v.id]

			if actionData then

				local frameList = Utils.split(v.enter_frame, ",")

				actionData.enterFromFrame = tonumber(frameList[1])
				actionData.enterToFrame = tonumber(frameList[2])

				actionData.defaultFlyEffect = v.default_fly_effect

				actionData.defaultBodyHeight = v.body_height

				if #v.skill_halo_offset > 0 then
					local soList = Utils.split(v.skill_halo_offset, ",")
					actionData.skillHaloOffset = ccp(
						tonumber(soList[1]), tonumber(soList[2])
					)
				end

			end
		end
	end

	for k, v in pairs(effect_data_pb.effect_relate_rows) do
		if v.id then
			effectData = self._effectDataDict[v.id]

			if effectData then
				effectData._hierarchy = v.hierarchy
				effectData._flyDirectType = v.fly_direct_type
				if #v.fly_start_pos > 0 then
					local startPosList = Utils.split(v.fly_start_pos, ",")
					effectData._flyStartPos = ccp(tonumber(startPosList[1]), tonumber(startPosList[2]))
				end

				if #v.fly_target_pos > 0 then
					local targetPosList = Utils.split(v.fly_target_pos, ",")
					effectData._flyTargetPos = ccp(tonumber(targetPosList[1]), tonumber(targetPosList[2]))
				end
			end
		end
	end

end

--[[
    获取特效配置数据
    @param effectId 特效ID
    @return EffectVO
]]
function EffectManager:getEffectData(effectId)
	return self._effectDataDict[effectId]
end

--[[
    获取动作配置数据
    @param actionId 动作id
    @return EffectVO
]]
function EffectManager:getActionData(actionId, sex)

	local sex = sex or CharacterManager:getInstance():getBaseData():getSex()
	if actionId == EffectEnum.MALE_ACTION_ID then
		-- local sex = CharacterManager:getInstance():getBaseData():getSex()
		if sex == Helper.sex.female then
			actionId = EffectEnum.FEMALE_ACTION_ID
		end
	elseif actionId == EffectEnum.MALE_WHITE_ACTION_ID then
		-- local sex = CharacterManager:getInstance():getBaseData():getSex()
		if sex == Helper.sex.female then
			actionId = EffectEnum.FEMALE_WHITE_ACTION_ID
		end
	end
	return self._actionDataDict[actionId]
end

--[[
    播放特效
    @param container 特效容器
    @param effectId 特效ID
    @param completeCallback 回调函数 ep. function(container, effectId)
    @param delay(ms) 延迟多久播放
    @param isRepeatAdd 如果存在的时候是否再添加
    @param isLoop -1 根据配置表, 0 循环, >1 次数
    @param isAutoRemove 当次数播放完是否自动移除
]]
function EffectManager:playEffect(container, effectId, completeCallback, delay, isRepeatAdd, isLoop, isAutoRemove)

	if effectId ==nil or effectId == 0 then
		return
	end

	delay = delay or 0
	
	isLoop = isLoop or -1

	if isAutoRemove == nil then
		isAutoRemove = true
	end

	local effectList = nil
	effectList = self._effectContainerDict[container] or {}

	local isCreate = false

	local effect = nil

	if self._effectContainerDict[container] then

		if isRepeatAdd then

			isCreate = true

		else
			effect = self:getEffect(container, effectId)
			if effect then

				if not effect:isPlay() then
					effect:play()
				end

				isCreate = false
			else
				isCreate = true
			end
		end
	else

		self._effectContainerDict[container] = effectList

		isCreate = true

	end

	if not isCreate then
		return
	end

	Effect.UNIQUE_KEY = Effect.UNIQUE_KEY + 1

	effect = Effect:create(effectId)
	effect:setLoop(isLoop)
	effect:setDelay(delay)
	effect:setIsAutoRemove(isAutoRemove)
	effect:setContainer(container)
	-- effect:setCallback(completeCallback)
	effect:_setInternalComplete(function(e) self:_effectCallback(e) end)
	effect:setCallback({[CallbackType.complete] = completeCallback})
	effect:setSameUnique(Effect.UNIQUE_KEY)
	container:addChild(effect)


	effectList[#effectList + 1] = effect

	effect:play()

	return effect

end

--[[
    暂停特效
]]
function EffectManager:pauseEffect(container, effectId)


end

function EffectManager:stopEffect(container, effectId)

	local effect = self:getEffect(container, effectId)

	if effect == nil then
		return
	end

	effect:stop()

end

function EffectManager:_effectCallback(effect)

	local container = effect._container
	local effectId = effect._effectId

	local callbackDict = effect._callbackDict

	if effect:isAutoRemove() == true then
		self:removeEffect(container, effectId, effect:getSameUnique())
	end

    if callbackDict[CallbackType.complete] then
    	callbackDict[CallbackType.complete](container, effectId)
    end

end

--[[
    移除单个特效
]]
function EffectManager:removeEffect(container, effectId, sameUnique)

	local effectList  = self._effectContainerDict[container]

	if not effectList then
		return
	end

	local index = 0
	local effect = nil

	for i, v in ipairs(effectList) do

		if v._effectId == effectId then

			repeat

				if sameUnique ~= nil then
					if v:getSameUnique() ~= sameUnique then
						break
					end
				end

			    index = i

			    effect = v
				
			until true

			if effect then
			    break
			end
			
		end
	end

	if index == 0 then
		return
	end

	table.remove(effectList, index)
	effect:dispose()

end

--[[
    清除容器上的特效
]]
function EffectManager:clearEffect(container)

	local effectList  = self._effectContainerDict[container]

	if not effectList then
		return
	end

	for _, v in ipairs(effectList) do
		v:dispose()
	end

	effectList = nil
	self._effectContainerDict[container] = nil

end

function EffectManager:getEffect(container, effectId)

	local effectList  = self._effectContainerDict[container]

	if not effectList then
	    return nil
	end

	for _, v in ipairs(effectList) do

		if v._effectId == effectId then
		    return v
		end
	end

	return nil

end

--[[
    创建一个ui特效
    @param 特效名字
]]
function EffectManager:createUIAnimate(aName)

	local effectPath = string.format("ui/effects_ui/%s/%s.ExportJson", aName, aName)

	return AnimateManager:getInstance():getArmature(effectPath, aName)

end



