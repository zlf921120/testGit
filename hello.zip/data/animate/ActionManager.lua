--
-- Author: lvgansheng
-- Date: 2014-06-24 11:49:41
-- 动作管理器

require("ActionHelper")
require("Action")

ActionManager = class("ActionManager")
ActionManager.action_dic = nil --正在执行动作的对象字典

local _instance = nil
local _allowInstance = false
 
function ActionManager:ctor()

    if not _allowInstance then
        error("ActionManager is a singleton class,please call getInstance method")
    end

    self.action_arr = {}
end

function ActionManager:getInstance()

    if _instance == nil then
        _allowInstance = true
        _instance = ActionManager.new()
        _allowInstance = false
    end

    return _instance

end

--[[
    播放相应动作
    @param target 需要播放动作的对象
    @param act_type 动作类型，参考ActionHelper文件
    @param params 动作参数
    @param callback 完成动作后的回调函数
    @param attacker 攻击方 --只有战斗才需要
    @param defender 防御方 --只有战斗才需要
--]]
function ActionManager:playAction(target, act_type, params, callback, attacker,defender)
	self:removeAct(target) --移除之前的动作
    local action = nil
    action = Action:create(target, act_type, params, callback, attacker, defender)
    self.action_arr[target] = action
    action:setCompFun(function(e) self:actComp(e) end)  --播放完成后，默认会执行的方法
	action:execute()
end

--动作播放完成后执行的函数
function ActionManager:actComp(action)
     self:removeAct(action.target)
end

--移除相应动作
function ActionManager:removeAct(target)
     if self.action_arr[target] then
        local action = self.action_arr[target]
        self.action_arr[target] = nil
        action:dispose()
        action = nil
     end
end

--[[
    播放一个序列动作
]]
function ActionManager:runSequenceActions(node, ...)

    local actionArray = CCArray:create()

    local actions = {...}

    for i, v in ipairs(actions) do
        actionArray:addObject(v)
    end

    local sequenceAction = CCSequence:create(actionArray)
    node:runAction(sequenceAction)

end