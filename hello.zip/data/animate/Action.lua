--
-- Author: lvgansheng
-- Date: 2014-06-24 11:57:29
-- 播放动作
require("animate/ActFactory")

Action = class("Action")

Action.target = nil --需要播放动作的目标
Action.act_type = 0 --动作类型
Action.call_back = nil -- 回调函数
Action.compFun = nil -- 回调函数
Action.act_arr = nil -- 动作总数组
Action.num = 0 -- 记录当前执行到第几个序列
Action.attacker = nil-- 攻击方
Action.defender = nil -- 受击方

function Action:init(target, act_type, params, callback,  attacker,defender)
	local action = nil

	self.target = target 
	self.call_back = callback
	self.attacker = attacker
	self.defender = defender
 
	self.num = 0
	self.act_arr = CCArray:create()
	self.act_arr:retain()
	
	local arr = nil
	if act_type == ActionHelper.act_type.short_dis_attack then
		arr = Act_Factory:short_dis_attack(target,params,function() self:next_step() end, attacker,defender)
	elseif act_type == ActionHelper.act_type.normal_remote_effect then
		arr = Act_Factory:remote_effect(target,params,function() self:next_step() end, attacker,defender)
	elseif act_type == ActionHelper.act_type.normal_hurt then
		arr = Act_Factory:normal_hurt(target,params,function() self:next_step() end, attacker,defender)
	elseif act_type == ActionHelper.act_type.long_dis_attack then
		arr = Act_Factory:long_dis_attack(target,params,function() self:next_step() end, attacker,defender)
	elseif act_type == ActionHelper.act_type.stand then
		arr = Act_Factory:stand(target,params,function() self:next_step() end, attacker,defender)
	end

	self.act_arr:addObjectsFromArray(arr)

end

function Action:create(target, act_type, params, callback, attacker,defender)
	local act = Action.new()
	act:init(target, act_type, params, callback, attacker,defender)
	return act

end

--执行
function Action:execute()
	local action = CCSequence:create(self.act_arr:objectAtIndex(self.num))
	self.target:runAction(action)
end

--执行下一个动作序列
function Action:next_step()
	self.num = self.num + 1

	if  self.act_arr:count () < self.num+1 then

		if self.call_back then  --有回调就执行回调
			self:call_back()
		end 

		self.compFun(self)
		return
	end

	local temp_arr = self.act_arr:objectAtIndex(self.num)
	local action = CCSequence:create(temp_arr)
	self.target:runAction(action)
	-- self.target:setScaleX(-self.target:getScaleX())
end

--动作播放完成后执行的函数
function Action:setCompFun(compFun)
	self.compFun = compFun
end

--销毁
function Action:dispose()
	if self.call_back then 
		self.call_back = nil
	end

	if self.act_arr then 
		self.act_arr:removeAllObjects()
		self.act_arr:release()
	end

	if self.target then 
		self.target = nil
	end

	if self.compFun then
		self.compFun = nil
	end

	self.attacker = nil
	self.defender = nil
end
