--
-- Author: Your Name
-- Date: 2014-06-24 16:28:11
--

ActionHelper = {}

ActionHelper.act_type = {} --动作种类
ActionHelper.act_type.stand = 1 --播放待机
ActionHelper.act_type.run = 2 --播放跑动
ActionHelper.act_type.attack = 3 --播放攻击动作
ActionHelper.act_type.short_dis_attack = 4 -- 通用近程攻击
ActionHelper.act_type.long_dis_attack = 5 -- 通用远程攻击
ActionHelper.act_type.normal_remote_effect = 6 --通用远程特效
ActionHelper.act_type.normal_hurt = 7 --通用受击特效