--
-- Author: lvgansheng
-- Date: 2014-06-24 14:02:25
-- 动作测试

require("animate/ActionManager")
require("TimerManager")

local hero_left = nil
local hero_right = nil
ActionTest = {}
ActionTest.lay = nil

local function remote_attack()
   TimerManager.removeTimer(remote_attack)
   ActionManager:getInstance():playAction(hero_left, ActionHelper.act_type.long_dis_attack,{2,-500,0},function() cclog ("這是回呼函數2") end,hero_left,hero_right)
end

local function action_comp()
  cclog ("complete function")
  TimerManager.addTimer(2500, remote_attack)
end

function ActionTest:one()
  local scene = CCScene:create()
  ActionTest.lay = CCLayer:create()
  scene:addChild(ActionTest.lay)
  CCDirector:sharedDirector():runWithScene(scene)

  hero_left = AnimateManager:getInstance():getArmature("ui/test/shizijun-shizizhan.ExportJson","shizijun-shizizhan")
  hero_left:setScaleX(-1)
  hero_left:setPosition(ccp(200,200))
  ActionTest.lay:addChild(hero_left)  

  hero_right = AnimateManager:getInstance():getArmature("ui/test/shizijun-shizizhan.ExportJson","shizijun-shizizhan")
  hero_right:setPosition(ccp(800,200))
  hero_right:getAnimation():play("stand")
  ActionTest.lay:addChild(hero_right)  

  ActionManager:getInstance():playAction(hero_left, ActionHelper.act_type.short_dis_attack,{2,500,0},action_comp,hero_left,hero_right)
end
	
	
