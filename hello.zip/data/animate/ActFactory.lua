--
-- Author: lvgansheng
-- Date: 2014-06-25 11:01:00
-- 动作工厂

require("EffectManager")
Act_Factory = {}

--近战通用攻击, 测试用
function Act_Factory:short_dis_attack(target,params,next_step, attacker,defender)
	
	local function show_hurt()
		ActionManager:getInstance():playAction(defender, ActionHelper.act_type.normal_hurt,{0.7},nil)
	end

	local arr1 = CCArray:create()
	arr1:addObject(Act_Factory:getRunAction(target))
	arr1:addObject(Act_Factory:getMoveAction(params[1], params[2],params[3]))
	arr1:addObject(Act_Factory:getAttackAction(target,false))
	arr1:addObject(CCCallFuncN:create(function() show_hurt() end))
	arr1:addObject(CCDelayTime:create(0.8)) 
	arr1:addObject(CCCallFuncN:create(function() next_step() end))

	local arr4 = Act_Factory:moveBack(target,params,next_step)

	local arr = CCArray:create()
	arr:addObject(arr1)
	arr:addObject(arr4)
	return arr
end

--远程通用攻击, 测试用
function Act_Factory:long_dis_attack(target,params,next_step, attacker,defender)
	local arr1 = CCArray:create()
	arr1:addObject(CCCallFuncN:create(function() target:getAnimation():play("attack03",-1,-1,0)  end))
	arr1:addObject(CCDelayTime:create(0.3)) --攻击动作开始0.3s后，出现远程攻击效果
	arr1:addObject(CCCallFuncN:create(function() next_step() end))	

	local function show_fly_effect( )
		local effect = EffectManager:getInstance():playEffect(ActionTest.lay,10003,nil,200)
		effect:setPosition(ccp(target:getPositionX()+50,target:getPositionY()))
		ActionManager:getInstance():playAction(effect, ActionHelper.act_type.normal_remote_effect,{0.4,defender:getPositionX()-attacker:getPositionX(),0},function ()  end,attacker,defender)
	end

	local arr2 = CCArray:create()
	arr2:addObject(CCCallFuncN:create(function() show_fly_effect() end))

	arr2:addObject(CCDelayTime:create(0.3))
	arr2:addObject(Act_Factory:getStandAction(target))
	arr2:addObject(CCCallFuncN:create(function() next_step() end))

	local arr = CCArray:create()
	arr:addObject(arr1)
	arr:addObject(arr2)

	return arr
end

--通用特效移动
function Act_Factory:remote_effect(target,params,next_step, attacker,defender)
	local arr1 = CCArray:create()
	arr1:addObject(Act_Factory:getMoveAction(params[1], params[2],params[3]))
	arr1:addObject(CCCallFuncN:create(function() EffectManager:getInstance():getEffect(ActionTest.lay,10003):setVisible(false) end))
	arr1:addObject(CCCallFuncN:create(function() ActionManager:getInstance():playAction(defender, ActionHelper.act_type.normal_hurt
									,{0.2},function ()  end,attacker,defender) end))
	arr1:addObject(CCCallFuncN:create(function() EffectManager:getInstance():removeEffect(ActionTest.lay,10003)end))
	arr1:addObject(CCCallFuncN:create(function() next_step() end))
	local arr = CCArray:create()
	arr:addObject(arr1)

	return arr
end

--通用受击
function Act_Factory:normal_hurt(target, params, next_step)
	local arr1 = CCArray:create()
	arr1:addObject(CCCallFuncN:create(function() EffectManager:getInstance():playEffect(target,10002,nil,30) end))
	arr1:addObject(CCCallFuncN:create(function() target:getAnimation():play("hurt")  end))
	arr1:addObject(CCDelayTime:create(params[1])) --受击状态维持0.7s
	--arr1:addObject(CCCallFuncN:create(function() EffectManager:getInstance():getEffect(target,10002):setVisible(false) end))
	arr1:addObject(CCCallFuncN:create(function() target:getAnimation():play("stand")  end))
	arr1:addObject(CCCallFuncN:create(function() EffectManager:getInstance():removeEffect(target,10002)  end))
	arr1:addObject(CCCallFuncN:create(function() next_step() end))
	local arr =CCArray:create()
	arr:addObject(arr1)

	return arr
end

--攻击完成后退回原位置
function Act_Factory:moveBack(target,params,next_step)
	local arr =  CCArray:create()
	arr:addObject(CCCallFuncN:create(function() target:setScaleX(-target:getScaleX()) end))
	arr:addObject(Act_Factory:getRunAction(target))
	arr:addObject(Act_Factory:getMoveAction(params[1],params[2],params[3]):reverse())
	arr:addObject(CCCallFuncN:create(function() target:setScaleX(-target:getScaleX()) end))
	arr:addObject(Act_Factory:getStandAction(target))
	arr:addObject(CCCallFuncN:create(function() next_step() end))

	return arr
end

function Act_Factory:stand(target)
	local arr1 = CCArray:create()
	arr1:addObject(Act_Factory:getStandAction(target))
	local arr = CCArray:create()
	arr:addObject(arr1)
	return arr
end

function Act_Factory:attack(target,isloop)
	local arr = CCArray:create()
	arr:addObject(Act_Factory:getAttackAction(target,isloop))
	return arr
end

function Act_Factory:run(target)
	local arr = CCArray:create()
	arr:addObject(Act_Factory:getRunAction(target))
	return arr
end


--一些基础的动作

--获取一个站立的action
function Act_Factory:getStandAction(target,isloop)
	local loop = -1
	if isloop == false then 
		loop = 0
	end
	return CCCallFuncN:create(function() target:getAnimation():play("stand",-1,-1,loop)  end)
end

--跑动
function Act_Factory:getRunAction(target,isloop)
	local loop = -1
	if isloop == false then 
		loop = 0
	end	
	return CCCallFuncN:create(function() target:getAnimation():play("run",-1,-1,loop)  end)
end

--技能1
function Act_Factory:getAttackAction(target, skillIndex, isloop)
	local loop = -1
	if isloop == false then 
		loop = 0
	end
	cclog( "&&&&&&&&&&&&&&entid action:%d,------------", target:getEntityID() )
	local strSkillName = string.format( "attack0%d", skillIndex )
	return CCCallFuncN:create(function() target:getAnimation():play(strSkillName,-1,-1,loop)  end)
end

--受击
function Act_Factory:getHurtAction(target,isloop)
	local loop = -1
	if isloop == false then 
		loop = 0
	end
	return CCCallFuncN:create(function() target:getAnimation():play("hurt", -1, -1, loop)  end)
end

--死亡
function Act_Factory:getDeadAction(target,isloop)
	local loop = -1
	if isloop == false then 
		loop = 0
	end
	return CCCallFuncN:create(function() target:getAnimation():play("dead",-1,-1,loop)  end)
end

--播放胜利动作
function Act_Factory:runWinAction(target)
	-- local loop = -1
	-- if isloop == false then 
	-- 	loop = 0
	-- end
	-- --target:getAnimation():play("celebrate01",-1,-1,loop)
	-- return CCCallFuncN:create(function() target:getAnimation():play("celebrate02",-1,-1,loop)  end)

	local animation = target:getAnimation()

	local function playCallBack(armature, movementType, movementID)
		
		if movementType == ComConstTab.MovementEventType.COMPLETE then
			animation:play("celebrate02", -1, -1, 1)
		end
	end

	animation:setMovementEventCallFunc(playCallBack)
	animation:play("celebrate01", -1, -1, 0)

end

--跳过
function Act_Factory:getJumpAction(duration,pos_x,pos_y)
	return CCJumpTo:create(duration, ccp(pos_x,pos_y), 100, 1)
end

--移动
function Act_Factory:getMoveAction(duration,pos_x,pos_y)
	return CCMoveBy:create(duration, ccp(pos_x,pos_y))	
end

--移动到指定位置
function Act_Factory:getMoveToAction(duration,pos_x,pos_y)
	return CCMoveTo:create(duration, ccp(pos_x,pos_y))	
end

--延时
function Act_Factory:getDealayAction(dealay)
	return CCDelayTime:create(dealay)
end

--[[
多次受击
@param target 播放对象
@param loop_count 播放次数
@param callback 回调函数，每播放一次执行一次
@param comp_callback 完成时的回调函数，播放次数为0时调用
--]]
function Act_Factory:getMultiAttack(target,loop_count,callback,comp_callback)

	local loop_count = loop_count
	local animation = target:getAnimation()
	local callback = callback
	local comp_callback = comp_callback

	local function playCallBack(armature, movementType, movementID)
		--if movementType == MovementType.COMPLETE then --非循环播放完成时
		--cclog( "getMultiAttack:armature name:%s, movementID:%s",   armature:getName(), movementID )
		if movementType == 1 then
			if callback~=nil then
				callback()
			end
				
			loop_count = loop_count -1
			if loop_count == 0 then
				--cclog("播放次數為0了")
				animation:stop()
				if comp_callback~=nil then
					comp_callback()
				end
				animation:setMovementEventCallFunc(function()end)
			else
				--cclog("繼續播放,當前是第%d次",loop_count)
				animation:stop()
				animation:play("hurt",-1,-1,0)				
			end
		end
	end
	animation:setMovementEventCallFunc(playCallBack)
	animation:play("hurt",-1,-1,0)
	
end

--[[
    获取一个僵直后退的动作
    @param entityType 左/右方
]]
function Act_Factory:getStiffBackAction(entityType)

	local xDist = 0
	local duration = 0.2
	if entityType == BattleType.ATTACKER then
		xDist = -30
	else
		xDist = 30
	end

	return self:getMoveAction(duration, xDist, 0)

end

--[[
    获取战斗特效动作
]]
function Act_Factory:getEffectAction(entity, effectId, callback, delay)

	return CCCallFuncN:create(function() EffectManager:getInstance():playEffect(
			entity:getRenderNode():getEffectContainer(),
			effectId,
			callback,
			delay) 
		end)

end

--[[
    获取受伤后退动作
]]
function Act_Factory:getHurtBackAction(entity)

	local entityType = entity:getEntityType()

	local xDist = 0
	local duration = 0.1
	if entityType == BattleType.ATTACKER then
		xDist = -30
	else
		xDist = 30
	end

	local mainContainer = entity:getRenderNode():getMainContainer()

	return CCCallFuncN:create(function() mainContainer:setPosition(ccp(xDist, 0)) end)

end

--[[
    获取受伤重置动作
]]
function Act_Factory:getHurtResetAction(entity)

	local mainContainer = entity:getRenderNode():getMainContainer()

	return CCCallFuncN:create(function() mainContainer:setPosition(ccp(0, 0)) end)

end