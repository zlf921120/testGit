-- 节日活动 数据代理
FestivalDataProxy = class("FestivalDataProxy")
FestivalDataProxy.viewSortList = {}
FestivalDataProxy.menuItemVoList = {}
FestivalDataProxy.menuItemVoDic = {}
FestivalDataProxy.festivalVoList = {}
FestivalDataProxy.allRewardList = {} --所有奖励映射 列表
FestivalDataProxy.curTipsTarget = {}
FestivalDataProxy.curIconsTarget = {}

local __instance = nil
local _allowInstance = false

function FestivalDataProxy:ctor()
    if not _allowInstance then
		error("FestivalDataProxy is a singleton class")
	end
	self:init()
end

function FestivalDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = FestivalDataProxy.new()
		_allowInstance = false
	end

	return __instance
end

function FestivalDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function FestivalDataProxy:init()
	require "FestivalVo"
	require "FestivalCfg"
	require "FestivalLocalReader"
	require "FestivalNetTask"
end

function FestivalDataProxy:createMenuItemVo()
	return FestivalMenuVo.new()
end

function FestivalDataProxy:createFestivalVo()
	return FestivalVo.new()
end

function FestivalDataProxy:createEmptyItemVo()
	return FestivalEmptyItemVo.new()
end

function FestivalDataProxy:setMenuItemVo(vo)
	self.menuItemVoList[ vo.id ] = vo
	self.menuItemVoDic[ string.format("%d_%d",vo.festival_id,vo.act_id) ] = vo
end

function FestivalDataProxy:getMenuItemVoById( id )
	return self.menuItemVoList[ id ]
end

function FestivalDataProxy:getMenuItemVoByActId(festival_id,act_id)
	return self.menuItemVoDic[ string.format("%d_%d",festival_id,act_id) ]
end

function FestivalDataProxy:getMenuItemVoList()
	return self.menuItemVoList
end

function FestivalDataProxy:getMenuListByFestivalId(festival_id)
	local ret = {}
	for _,v in pairs(self.menuItemVoList) do
		if v.festival_id == festival_id then
			table.insert(ret,v)
		end
	end
	return ret
end

function FestivalDataProxy:getFestivalVoList()
	return self.festivalVoList
end

function FestivalDataProxy:getAllRewardList()
	return self.allRewardList
end

function FestivalDataProxy:getRewardListById(id)
	return self.allRewardList[id]
end

function FestivalDataProxy:getRewardListItemById(actId,id)
	return self.allRewardList[actId][id]
end
----------------------------------------------------
function FestivalDataProxy:createRechargeItemVo()
	return FestivalRechargeItemVo.new()
end

function FestivalDataProxy:createEnchantItemVo()
	return FestivalEnchantItemVo.new()
end

function FestivalDataProxy:createExchangeItemVo()
	return FestivalExchangeItemVo.new()
end

function FestivalDataProxy:createFirstChargeItemVo()
	return FestivalFirstChargeItemVo.new()
end

function FestivalDataProxy:createRecostItemVo()
	return FestivalRecostItemVo.new()
end

function FestivalDataProxy:createCircChargeItemVo()
	return FestivalCircChargeItemVo.new()
end

function FestivalDataProxy:createGemLevupItemVo()
	return FestivalGemLevupItemVo.new()
end

function FestivalDataProxy:getViewSortList(festival_id)
	local ret = {}
	for id,v in pairs(self.viewSortList) do
		if v.festival_id == festival_id then
			table.insert(ret,v)
		end
	end
	table.sort( ret, function(a,b) return a.sort<b.sort end )
	return ret
end
--------------------------------------------------
--是否满足 累计充值量
function FestivalDataProxy:isCanGetRecharge(id)
	local menuVo = self:getMenuItemVoById(id)
	local voList = self:getRewardListById(menuVo.act_id)
	local ret = false
	for _,v in pairs(voList) do

		local isGet = false
		for _,charge in ipairs(menuVo.rewardInfos.finish_total_charge) do
			if charge == v.total then
				isGet = true
				break
			end
		end
		
		if menuVo.rewardInfos.total_charge >= v.total and isGet == false then
			ret = true
			break
		end
	end
	return ret
end
--是否可领 兑换奖励
function FestivalDataProxy:isCanGetExchange(id)
	local menuVo = self:getMenuItemVoById(id)
	local voList = self:getRewardListById(menuVo.act_id)
	local ret = false
	for _,v in pairs(voList) do

		if menuVo.rewardInfos.exchange_num < v.exchange_num and 
			ItemManager:getInstance():getQuantityByBaseId(v.cost[1].base_id) >= v.cost[1].num then
			ret = true
			break
		end
	end
	return ret
end

--是否满足 附魔量
function FestivalDataProxy:isCanGetEnchant(id)
	local menuVo = self:getMenuItemVoById(id)
	local voList = menuVo.rewardInfos.enchant
	local cout = 0
	for _,v in pairs(voList) do
		if v.num > 0 then
			cout = cout +1
		end
	end
	return cout > 0
end

--是否可 领取活动首充
function FestivalDataProxy:isCanGetFirstCharge(id)
	local menuVo = self:getMenuItemVoById(id)
	return menuVo.rewardInfos.is_charge == 1
end

--是否可 领取累计消费
function FestivalDataProxy:isCanGetRecost(id)
	local menuVo = self:getMenuItemVoById(id)
	local total_cost = menuVo.rewardInfos.total_cost
	local voList = self:getRewardListById(menuVo.act_id)
	local arr = menuVo.rewardInfos.total_cost_arr
	local cout = 0
	for _,v in pairs(voList) do
		if v.cost <= total_cost then
			local isGet = 0
			for _,vv in pairs(arr) do
				if v.cost == vv then
					isGet = 1
				end
			end
			if isGet == 0 then
				cout = cout + 1
			end
		end
	end
	return cout > 0
end

--是否可 领取循环充值
function FestivalDataProxy:isCanGetCircRecharge(id)
	local menuVo = self:getMenuItemVoById(id)
	local circle_charge = menuVo.rewardInfos.circle_charge
	local voList = self:getRewardListById(menuVo.act_id)
	local cout = 0
	for _,v in pairs(voList) do
		if circle_charge >= v.charge then
			cout = cout + 1
		end
	end
	return cout > 0
end

--是否显示活动图标
function FestivalDataProxy:isShowFestivalIcon()
		
	self.curIconsTarget = {}

	for festival_id,v in pairs(self.festivalVoList) do
		local cout = 0
		local voList = self:getMenuListByFestivalId(festival_id)
		for _,v in pairs(voList) do
			if self:isValidFestival(v.id) == false then
				cout = cout + 1
			end
		end

		if cout == Utils.get_length_from_any_table(voList) then
			self.curIconsTarget[festival_id] = 1
		end
	end

	if Utils.get_length_from_any_table(self.curIconsTarget) > 0 then
		Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_ICON,NewTipsEnum.festival)
	else
		Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_ICON,NewTipsEnum.festival)
	end
end

function FestivalDataProxy:getCurTipsTarget()
	return self.curTipsTarget
end

function FestivalDataProxy:getCurIconsTarget()
	return self.curIconsTarget
end

--是否显示绿点
function FestivalDataProxy:isShowNewsTips()

	self.curTipsTarget = {}

	for festival_id,v in pairs(self.festivalVoList) do
		local isShowNewsTips = false
		local voList = self:getMenuListByFestivalId(festival_id)

		self.curTipsTarget[festival_id] = 0

		for _,viewVo in pairs(voList) do
			if viewVo.act_id == FestivalTypeItemCfg.FirstCharge then
				isShowNewsTips = self:isCanGetFirstCharge(viewVo.id)
			elseif viewVo.act_id == FestivalTypeItemCfg.Recharge then
				isShowNewsTips = self:isCanGetRecharge(viewVo.id) 
			elseif viewVo.act_id == FestivalTypeItemCfg.Enchant then
				isShowNewsTips = self:isCanGetEnchant(viewVo.id)
			elseif viewVo.act_id == FestivalTypeItemCfg.Exchange then
				isShowNewsTips = self:isCanGetExchange(viewVo.id) 
			elseif viewVo.act_id == FestivalTypeItemCfg.Recost then
				isShowNewsTips = self:isCanGetRecost(viewVo.id)
			elseif viewVo.act_id == FestivalTypeItemCfg.CirculRecharge then
				isShowNewsTips = self:isCanGetCircRecharge(viewVo.id)
			end
			if isShowNewsTips then
				self.curTipsTarget[festival_id] = 1
				break
			end
		end
	end

	Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.festival)
	Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.festival)
end

function FestivalDataProxy:saveRewardInfo(infos)
	require "FestivalLocalReader"
	FestivalLocalReader:getInstance():loadInProxy()

	self.festival_infos = infos
end

function FestivalDataProxy:delayExcFestivalInfos()
	if self.festival_infos then
		self:makeFestivalInfos(self.festival_infos)
	end
end

function FestivalDataProxy:makeFestivalInfos(infos)

	-- print(" #activitie_holiday_entrance_rsp.holiday ",#infos)
	for _,v in ipairs(infos) do
		for _,vv in ipairs(v.son) do

			local menuVo = self:getMenuItemVoByActId(v.holiday_id,vv.son_id)
			if menuVo then
				menuVo.rewardInfos = {}
				menuVo.rewardInfos["total_charge"] = vv.total_charge
				menuVo.rewardInfos["is_charge"] = vv.is_charge
				menuVo.rewardInfos["finish_total_charge"] = {}
				for _,vvv in ipairs(vv.finish_total_charge) do
					table.insert(menuVo.rewardInfos["finish_total_charge"],vvv.charge)
				end
				menuVo.rewardInfos["enchant"] = {}
				for _,vvv in ipairs(vv.enchant) do
					table.insert(menuVo.rewardInfos["enchant"],{lev=vvv.enchant_lev,num=vvv.enchant_num})
				end
				print(" vv.loss_gold ",vv.loss_gold)
				print(" vv.for_charge ",vv.for_charge - vv.for_charge_finish_gold)
				menuVo.rewardInfos["total_cost"] = vv.loss_gold
				menuVo.rewardInfos["circle_charge"] = vv.for_charge - vv.for_charge_finish_gold
				menuVo.rewardInfos["total_cost_arr"] = {}
				for _,vvv in ipairs(vv.loss_gold_reward) do
					table.insert(menuVo.rewardInfos["total_cost_arr"],vvv.gold)
				end
				menuVo.rewardInfos["exchange_num"] = vv.exchange_num
			end
		end
	end

	self:isShowFestivalIcon()
	self:isShowNewsTips()
end

--该活动是否有效
function FestivalDataProxy:isValidFestival(id)
	local ret = false
	local menuVo = self:getMenuItemVoById(id)
	if menuVo then
		local nowTime = ServerTimerManager:getInstance():getCurTime()
		if nowTime >= menuVo.start_time and nowTime < menuVo.end_time then
			local leftTime = math.max(0,menuVo.end_time - nowTime)
			ret = true
		elseif nowTime < menuVo.start_time then --未到期
			ret = false
		elseif nowTime >= menuVo.end_time then --过期
			ret = false
		end
	end
	return ret
end

function FestivalDataProxy:getPhysicalAddition()
	return self.physical_addition
end

--节日期间体力活动 增量
function FestivalDataProxy:getFestivalGetPhysicalAddition(num)
	local ret = num
	for k,menuVo in pairs(self.menuItemVoList) do
		if menuVo.act_id == FestivalTypeItemCfg.Physical then
			if self:isValidFestival(menuVo.id) then
				ret = self.physical_addition + num
			end
		end
	end
	return ret
end

--节日期间体力活动
function FestivalDataProxy:getFestivalGetPhysicalDesc(txt,num)
	local ret = txt
	for k,menuVo in pairs(self.menuItemVoList) do
		if menuVo.act_id == FestivalTypeItemCfg.Physical then
			if self:isValidFestival(menuVo.id) then
				ret = string.gsub(txt,"60點",self.physical_addition + num.."點")
			end
		end
	end
	return ret
end
--------------------------------------------------------------
function FestivalDataProxy:getWidgetExchangeItem()
	if self.widgetFestivalItem == nil then
		self.widgetFestivalItem = GUIReader:shareReader():widgetFromJsonFile("festival/FestivalExchangeItem.ExportJson")
		self.widgetFestivalItem:retain()
	end
	return self.widgetFestivalItem
end

function FestivalDataProxy:getWidgetLoginItem()
	if self.widgetLoginItem == nil then
		self.widgetLoginItem = GUIReader:shareReader():widgetFromJsonFile("reward/RewardLoginItem.ExportJson")
		self.widgetLoginItem:retain()
	end
	return self.widgetLoginItem
end

function FestivalDataProxy:getWidgetMenuItem()
	if self.widgetMenuItem == nil then
		self.widgetMenuItem = GUIReader:shareReader():widgetFromJsonFile("reward/RewardMenuItem.ExportJson")
		self.widgetMenuItem:retain()
	end
	return self.widgetMenuItem
end

function FestivalDataProxy:getWidgetArenaItem()
	if self.widgetArenaItem == nil then
		self.widgetArenaItem = GUIReader:shareReader():widgetFromJsonFile("reward/RewardArenaItem.ExportJson")
		self.widgetArenaItem:retain()
	end
	return self.widgetArenaItem
end