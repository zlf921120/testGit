
--节日事件
FestivalEvent = {}
FestivalEvent.UPDATE_ITEM = "FestivalEvent.UPDATE_ITEM"
FestivalEvent.UPDATE_SCENE = "FestivalEvent.UPDATE_SCENE"

--节日活动配置
FestivalCfg = {}

FestivalTypeCfg = {
	F_0501 = 10000, --五一劳动节
	F_0601 = 10001, --六一儿童节
}

FestivalTypeItemCfg = {
	FirstCharge = 50000, --首次充值
	Recharge = 50001, --累计充值
	Enchant = 50200, --附魔奖励
	Exchange = 50300, --兑换
	Physical = 59999, --体力
	DungeonExp2 = 59998, --噩梦副本钻石翻牌英雄武魂翻倍
	ArenaReward2 = 59997, --竞技积分双倍
	TowerReward2 = 59996, --恶魔塔积分双倍
	GloryReward2 = 59995, --星空神殿积分双倍
	SkyBattleReward2 = 59994, --天空之役积分双倍
	DungeonResReward2 = 59993, --宝藏本资源产出双倍
	ResContentReward2 = 59992, --抢夺本抢夺本产出双倍
	Recost = 50100, --累计消费
	CirculRecharge = 50003, --循环充值
	GemLevup = 50201, --宝石升级 
}
