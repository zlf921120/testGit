-----------------------------------------------------------------------------------
--兑换充值
FestivalExchangeView = class("FestivalExchangeView",function()
	return Layout:create()
end)

function FestivalExchangeView:create(id)
    local ret = FestivalExchangeView.new()
    ret:init(id)
    return ret
end

function FestivalExchangeView:init(id)

	self._widget = GUIReader:shareReader():widgetFromJsonFile("reward/RewardLoginView.ExportJson")
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	self.listView = tolua.cast(self._widget:getChildByName("list_view"),"ListView")

	self.viewVo = FestivalDataProxy:getInstance():getMenuItemVoById(id)

	self.labRegulationFix = CCLabelTTF:create("活動規則：","",22)
	self.labRegulationFix:setAnchorPoint(ccp(0,0.5))
	self.labRegulationFix:setPosition(ccp(520,479))
	self.labRegulationFix:setColor(ccc3(0xFE,0xE1,0x6B))
	
	self._widget:addNode( Utils.createStrokeLabel(self.labRegulationFix,1,ccc3(55,25,25))) 

	self.labRegulation = CCLabelTTF:create(self.viewVo.desc,"",22)
	self.labRegulation:setDimensions(CCSize(254,195))
	self.labRegulation:setAnchorPoint(ccp(0,1))
	self.labRegulation:setHorizontalAlignment(kCCTextAlignmentLeft)
	self.labRegulation:setPosition(ccp(638,490))
	self.labRegulation:setColor(ccc3(0xFE,0xE1,0x6B))

	self._widget:addNode( Utils.createStrokeLabel(self.labRegulation,1,ccc3(55,25,25)))

	self.labTimeValFix = CCLabelTTF:create("活動時間：","",22)
	self.labTimeValFix:setAnchorPoint(ccp(0,0.5))
	self.labTimeValFix:setPosition(ccp(521,392))
	self.labTimeValFix:setColor(ccc3(0xFE,0xE1,0x6B))
	
	self._widget:addNode( Utils.createStrokeLabel(self.labTimeValFix,1,ccc3(55,25,25)))

	self.labTimeVal = CCLabelTTF:create("","",22)
	self.labTimeVal:setAnchorPoint(ccp(0,0.5))
	self.labTimeVal:setPosition(ccp(641,391))
	self.labTimeVal:setColor(ccc3(0xFE,0xE1,0x6B))

	self._widget:addNode( Utils.createStrokeLabel(self.labTimeVal,1,ccc3(55,25,25)))
end

function FestivalExchangeView:setData(menuVo)

	self.viewVo = menuVo
end

function FestivalExchangeView:enter()

	local dp = FestivalDataProxy:getInstance()
	local rm = FestivalRenderMgr:getInstance()

	local tmpList = {}
	for k,v in pairs( dp:getRewardListById(self.viewVo.act_id)) do
		table.insert(tmpList,v)
	end

	table.sort(tmpList, function(a,b)
		return a.id < b.id
	end)

	local arr = CCArray:create()
	for i=1,#tmpList do
		local key = string.format("viewitem_%d_%d_%d",self.viewVo.festival_id,self.viewVo.act_id,tmpList[i].id)
 		local item = rm.dic:objectForKey(key)
 		if item == nil then
			arr:addObject(CCDelayTime:create(0.2))
		end
		arr:addObject(CCCallFunc:create(function()
	 		local item = rm.dic:objectForKey(key)
 			if item == nil then
				item = FestivalExchangeItem:create( dp:getRewardListItemById(self.viewVo.act_id,tmpList[i].id),self.viewVo )
				rm.dic:setObject(item,key)
			end
			item:update()
			self.listView:pushBackCustomItem(item)
		end))
	end
	self.listView:removeAllItems()
	self.listView:stopAllActions()
	self.listView:runAction(CCSequence:create(arr))

	self.labTimeVal:stopAllActions()
	self.labTimeVal:runAction(CCRepeatForever:create(
		CCSequence:createWithTwoActions(CCDelayTime:create(1),
			CCCallFunc:create(function()
				local str,isRefresh = self.viewVo:getLeftTime()
				self.labTimeVal:setString(str)
				if isRefresh == false then
					self.labTimeVal:stopAllActions()
				end
			end))))
end
-----------------------------------------------------------------------------------
--首次充值
FestivalFirstChargeView = class("FestivalFirstChargeView",function()
	return Layout:create()
end)

function FestivalFirstChargeView:create(id)
    local ret = FestivalFirstChargeView.new()
    ret:init(id)
    return ret
end

function FestivalFirstChargeView:init(id)

	self._widget = GUIReader:shareReader():widgetFromJsonFile("reward/RewardLoginView.ExportJson")
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	self.listView = tolua.cast(self._widget:getChildByName("list_view"),"ListView")

	self.viewVo = FestivalDataProxy:getInstance():getMenuItemVoById(id)

	self.labRegulationFix = CCLabelTTF:create("活動規則：","",22)
	self.labRegulationFix:setAnchorPoint(ccp(0,0.5))
	self.labRegulationFix:setPosition(ccp(520,479))
	self.labRegulationFix:setColor(ccc3(0xFE,0xE1,0x6B))
	
	self._widget:addNode( Utils.createStrokeLabel(self.labRegulationFix,1,ccc3(55,25,25))) 

	self.labRegulation = CCLabelTTF:create(self.viewVo.desc,"",22)
	self.labRegulation:setDimensions(CCSize(254,195))
	self.labRegulation:setAnchorPoint(ccp(0,1))
	self.labRegulation:setHorizontalAlignment(kCCTextAlignmentLeft)
	self.labRegulation:setPosition(ccp(638,490))
	self.labRegulation:setColor(ccc3(0xFE,0xE1,0x6B))

	self._widget:addNode( Utils.createStrokeLabel(self.labRegulation,1,ccc3(55,25,25)))

	self.labTimeValFix = CCLabelTTF:create("活動時間：","",22)
	self.labTimeValFix:setAnchorPoint(ccp(0,0.5))
	self.labTimeValFix:setPosition(ccp(521,392))
	self.labTimeValFix:setColor(ccc3(0xFE,0xE1,0x6B))
	
	self._widget:addNode( Utils.createStrokeLabel(self.labTimeValFix,1,ccc3(55,25,25)))

	self.labTimeVal = CCLabelTTF:create("","",22)
	self.labTimeVal:setAnchorPoint(ccp(0,0.5))
	self.labTimeVal:setPosition(ccp(641,391))
	self.labTimeVal:setColor(ccc3(0xFE,0xE1,0x6B))

	self._widget:addNode( Utils.createStrokeLabel(self.labTimeVal,1,ccc3(55,25,25)))
end

function FestivalFirstChargeView:setData(menuVo)

	self.viewVo = menuVo
end

function FestivalFirstChargeView:enter()

	local dp = FestivalDataProxy:getInstance()
	local rm = FestivalRenderMgr:getInstance()

	local tmpList = {}
	for k,v in pairs( dp:getRewardListById(self.viewVo.act_id)) do
		table.insert(tmpList,v)
	end

	table.sort(tmpList, function(a,b)
		return a.id < b.id
	end)

	local arr = CCArray:create()
	for i=1,#tmpList do
		local key = string.format("viewitem_%d_%d_%d",self.viewVo.festival_id,self.viewVo.act_id,tmpList[i].id)
 		local item = rm.dic:objectForKey(key)
 		if item == nil then
			arr:addObject(CCDelayTime:create(0.2))
		end
		arr:addObject(CCCallFunc:create(function()
	 		local item = rm.dic:objectForKey(key)
 			if item == nil then
				item = FestivalFirstchargeItem:create( dp:getRewardListItemById(self.viewVo.act_id,tmpList[i].id),self.viewVo)
				rm.dic:setObject(item,key)
			end
			item:update()
			self.listView:pushBackCustomItem(item)
		end))
	end
	self.listView:removeAllItems()
	self.listView:stopAllActions()
	self.listView:runAction(CCSequence:create(arr))

	self.labTimeVal:stopAllActions()
	self.labTimeVal:runAction(CCRepeatForever:create(
		CCSequence:createWithTwoActions(CCDelayTime:create(1),
			CCCallFunc:create(function()
				local str,isRefresh = self.viewVo:getLeftTime()
				self.labTimeVal:setString(str)
				if isRefresh == false then
					self.labTimeVal:stopAllActions()
				end
			end))))
end
-----------------------------------------------------------------------------------
--累计充值
FestivalRechargeView = class("FestivalRechargeView",function()
	return Layout:create()
end)

function FestivalRechargeView:create(id)
    local ret = FestivalRechargeView.new()
    ret:init(id)
    return ret
end

function FestivalRechargeView:init(id)

	self._widget = GUIReader:shareReader():widgetFromJsonFile("reward/RewardLoginView.ExportJson")
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	self.listView = tolua.cast(self._widget:getChildByName("list_view"),"ListView")

	self.viewVo = FestivalDataProxy:getInstance():getMenuItemVoById(id)

	self.labRegulationFix = CCLabelTTF:create("活動規則：","",22)
	self.labRegulationFix:setAnchorPoint(ccp(0,0.5))
	self.labRegulationFix:setPosition(ccp(520,479))
	self.labRegulationFix:setColor(ccc3(0xFE,0xE1,0x6B))
	-- self.labRegulationFix:enableStroke(ccc3(55,25,25),1,true)
	--self._widget:addNode( Utils.createStroke(self.labRegulationFix,1,ccc3(55,25,25)) )
	self._widget:addNode( Utils.createStrokeLabel(self.labRegulationFix,1,ccc3(55,25,25))) 

	self.labRegulation = CCLabelTTF:create(self.viewVo.desc,"",22)
	self.labRegulation:setDimensions(CCSize(254,195))
	self.labRegulation:setAnchorPoint(ccp(0,1))
	self.labRegulation:setHorizontalAlignment(kCCTextAlignmentLeft)
	self.labRegulation:setPosition(ccp(638,490))
	self.labRegulation:setColor(ccc3(0xFE,0xE1,0x6B))
	-- self.labRegulation:enableStroke(ccc3(55,25,25),1,true)
	--self._widget:addNode( Utils.createStroke(self.labRegulation,1,ccc3(55,25,25)) )
	self._widget:addNode( Utils.createStrokeLabel(self.labRegulation,1,ccc3(55,25,25)))

	self.labTimeValFix = CCLabelTTF:create("活動時間：","",22)
	self.labTimeValFix:setAnchorPoint(ccp(0,0.5))
	self.labTimeValFix:setPosition(ccp(521,392))
	self.labTimeValFix:setColor(ccc3(0xFE,0xE1,0x6B))
	-- self.labTimeValFix:enableStroke(ccc3(55,25,25),1,true)
	--self._widget:addNode( Utils.createStroke(self.labTimeValFix,1,ccc3(55,25,25)) )
	self._widget:addNode( Utils.createStrokeLabel(self.labTimeValFix,1,ccc3(55,25,25)))

	self.labTimeVal = CCLabelTTF:create("","",22)
	self.labTimeVal:setAnchorPoint(ccp(0,0.5))
	self.labTimeVal:setPosition(ccp(641,391))
	self.labTimeVal:setColor(ccc3(0xFE,0xE1,0x6B))
	-- self.labTimeVal:enableStroke(ccc3(55,25,25),1,true)
	--self._widget:addNode( Utils.createStroke(self.labTimeVal,1,ccc3(55,25,25)) )
	self._widget:addNode( Utils.createStrokeLabel(self.labTimeVal,1,ccc3(55,25,25)))
end

function FestivalRechargeView:setData(menuVo)

	self.viewVo = menuVo
end

function FestivalRechargeView:enter()

	local dp = FestivalDataProxy:getInstance()
	local rm = FestivalRenderMgr:getInstance()

	local tmpList = {}
	for k,v in pairs( dp:getRewardListById(self.viewVo.act_id)) do
		table.insert(tmpList,v)
	end

	table.sort(tmpList, function(a,b)
		return a.id < b.id
	end)

	local arr = CCArray:create()
	for i=1,#tmpList do
		local key = string.format("viewitem_%d_%d_%d",self.viewVo.festival_id,self.viewVo.act_id,tmpList[i].id)
 		local item = rm.dic:objectForKey(key)
 		if item == nil then
			arr:addObject(CCDelayTime:create(0.2))
		end
		arr:addObject(CCCallFunc:create(function()
	 		local item = rm.dic:objectForKey(key)
 			if item == nil then
				item = FestivalRechargeItem:create( dp:getRewardListItemById(self.viewVo.act_id,tmpList[i].id),self.viewVo)
				rm.dic:setObject(item,key)
			end
			item:update()
			self.listView:pushBackCustomItem(item)
		end))
	end
	self.listView:removeAllItems()
	self.listView:stopAllActions()
	self.listView:runAction(CCSequence:create(arr))

	self.labTimeVal:stopAllActions()
	self.labTimeVal:runAction(CCRepeatForever:create(
		CCSequence:createWithTwoActions(CCDelayTime:create(1),
			CCCallFunc:create(function()
				local str,isRefresh = self.viewVo:getLeftTime()
				self.labTimeVal:setString(str)
				if isRefresh == false then
					self.labTimeVal:stopAllActions()
				end
			end))))
end
---------------------------------------------------------------------------------
--附魔奖励
FestivalEnchantView = class("FestivalEnchantView",function()
	return Layout:create()
end)

function FestivalEnchantView:create(id)
    local ret = FestivalEnchantView.new()
    ret:init(id)
    return ret
end

function FestivalEnchantView:init(id)

	self._widget = GUIReader:shareReader():widgetFromJsonFile("reward/RewardLoginView.ExportJson")
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	self.listView = tolua.cast(self._widget:getChildByName("list_view"),"ListView")
	
	DisplayUtil.makeVisibleListView(self.listView,142,300)
	self.viewVo = FestivalDataProxy:getInstance():getMenuItemVoById(id)

	self.labRegulationFix = CCLabelTTF:create("活動規則：","",22)
	self.labRegulationFix:setAnchorPoint(ccp(0,0.5))
	self.labRegulationFix:setPosition(ccp(520,479))
	self.labRegulationFix:setColor(ccc3(0xFE,0xE1,0x6B))
	self._widget:addNode( Utils.createStrokeLabel(self.labRegulationFix,1,ccc3(55,25,25))) 

	self.labRegulation = CCLabelTTF:create(self.viewVo.desc,"",22)
	self.labRegulation:setDimensions(CCSize(254,195))
	self.labRegulation:setAnchorPoint(ccp(0,1))
	self.labRegulation:setHorizontalAlignment(kCCTextAlignmentLeft)
	self.labRegulation:setPosition(ccp(638,490))
	self.labRegulation:setColor(ccc3(0xFE,0xE1,0x6B))
	self._widget:addNode( Utils.createStrokeLabel(self.labRegulation,1,ccc3(55,25,25)))

	self.labTimeValFix = CCLabelTTF:create("活動時間：","",22)
	self.labTimeValFix:setAnchorPoint(ccp(0,0.5))
	self.labTimeValFix:setPosition(ccp(521,392))
	self.labTimeValFix:setColor(ccc3(0xFE,0xE1,0x6B))
	self._widget:addNode( Utils.createStrokeLabel(self.labTimeValFix,1,ccc3(55,25,25)))

	self.labTimeVal = CCLabelTTF:create("","",22)
	self.labTimeVal:setAnchorPoint(ccp(0,0.5))
	self.labTimeVal:setPosition(ccp(641,391))
	self.labTimeVal:setColor(ccc3(0xFE,0xE1,0x6B))
	self._widget:addNode( Utils.createStrokeLabel(self.labTimeVal,1,ccc3(55,25,25)))
end

function FestivalEnchantView:setData(menuVo)

	self.viewVo = menuVo
	
end

function FestivalEnchantView:enter()

	local dp = FestivalDataProxy:getInstance()
	local rm = FestivalRenderMgr:getInstance()

	local tmpList = {}
	for k,v in pairs( dp:getRewardListById(self.viewVo.act_id)) do
		table.insert(tmpList,v)
	end
	table.sort(tmpList, function(a,b)
		return a.id < b.id
	end)
	
	local arr = CCArray:create()
	for i=1,#tmpList do
		local key = string.format("viewitem_%d_%d_%d",self.viewVo.festival_id,self.viewVo.act_id,tmpList[i].id)
 		local item = rm.dic:objectForKey(key)
 		if item == nil then
			arr:addObject(CCDelayTime:create(0.2))
		end
		arr:addObject(CCCallFunc:create(function()
	 		local item = rm.dic:objectForKey(key)
 			if item == nil then
				item = FestivalEnchantItem:create( dp:getRewardListItemById(self.viewVo.act_id,tmpList[i].id),self.viewVo)
				rm.dic:setObject(item,key)
			end
			item:update()
			self.listView:pushBackCustomItem(item)
		end))
	end
	self.listView:removeAllItems()
	self.listView:stopAllActions()
	self.listView:runAction(CCSequence:create(arr))

	self.labTimeVal:stopAllActions()
	self.labTimeVal:runAction(CCRepeatForever:create(
		CCSequence:createWithTwoActions(CCDelayTime:create(1),
			CCCallFunc:create(function()
				local str,isRefresh = self.viewVo:getLeftTime()
				self.labTimeVal:setString(str)
				if isRefresh == false then
					self.labTimeVal:stopAllActions()
				end
			end))))
end
---------------------------------------------------------------------------------
--体力奖励
FestivalEmptyView = class("FestivalEmptyView",function()
	return Layout:create()
end)

function FestivalEmptyView:create(id)
    local ret = FestivalEmptyView.new()
    ret:init(id)
    return ret
end

function FestivalEmptyView:init(id)

	self._widget = GUIReader:shareReader():widgetFromJsonFile("reward/RewardLoginView.ExportJson")
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	self.listView = tolua.cast(self._widget:getChildByName("list_view"),"ListView")
	
	DisplayUtil.makeVisibleListView(self.listView,142,300)
	self.viewVo = FestivalDataProxy:getInstance():getMenuItemVoById(id)

	self.labRegulationFix = CCLabelTTF:create("活動規則：","",22)
	self.labRegulationFix:setAnchorPoint(ccp(0,0.5))
	self.labRegulationFix:setPosition(ccp(520,479))
	self.labRegulationFix:setColor(ccc3(0xFE,0xE1,0x6B))
	self._widget:addNode( Utils.createStrokeLabel(self.labRegulationFix,1,ccc3(55,25,25))) 

	self.labRegulation = CCLabelTTF:create(self.viewVo.desc,"",22)
	self.labRegulation:setDimensions(CCSize(254,195))
	self.labRegulation:setAnchorPoint(ccp(0,1))
	self.labRegulation:setHorizontalAlignment(kCCTextAlignmentLeft)
	self.labRegulation:setPosition(ccp(638,490))
	self.labRegulation:setColor(ccc3(0xFE,0xE1,0x6B))
	self._widget:addNode( Utils.createStrokeLabel(self.labRegulation,1,ccc3(55,25,25)))

	self.labTimeValFix = CCLabelTTF:create("活動時間：","",22)
	self.labTimeValFix:setAnchorPoint(ccp(0,0.5))
	self.labTimeValFix:setPosition(ccp(521,392))
	self.labTimeValFix:setColor(ccc3(0xFE,0xE1,0x6B))
	self._widget:addNode( Utils.createStrokeLabel(self.labTimeValFix,1,ccc3(55,25,25)))

	self.labTimeVal = CCLabelTTF:create("","",22)
	self.labTimeVal:setAnchorPoint(ccp(0,0.5))
	self.labTimeVal:setPosition(ccp(641,391))
	self.labTimeVal:setColor(ccc3(0xFE,0xE1,0x6B))
	self._widget:addNode( Utils.createStrokeLabel(self.labTimeVal,1,ccc3(55,25,25)))
end

function FestivalEmptyView:setData(menuVo)

	self.viewVo = menuVo
end

function FestivalEmptyView:enter()

	local dp = FestivalDataProxy:getInstance()
	local rm = FestivalRenderMgr:getInstance()

	local tmpList = {}
	for k,v in pairs( dp:getRewardListById(self.viewVo.act_id)) do
		table.insert(tmpList,v)
	end
	table.sort(tmpList, function(a,b)
		return a.id < b.id
	end)
	
	local arr = CCArray:create()
	for i=1,#tmpList do
		local key = string.format("viewitem_%d_%d_%d",self.viewVo.festival_id,self.viewVo.act_id,tmpList[i].id)
 		local item = rm.dic:objectForKey(key)
 		if item == nil then
			arr:addObject(CCDelayTime:create(0.2))
		end
		arr:addObject(CCCallFunc:create(function()
	 		local item = rm.dic:objectForKey(key)
 			if item == nil then
				item = FestivalPhysicalItem:create( dp:getRewardListItemById(self.viewVo.act_id,tmpList[i].id),self.viewVo)
				rm.dic:setObject(item,key)
			end
			item:update()
			self.listView:pushBackCustomItem(item)
		end))
	end
	self.listView:removeAllItems()
	self.listView:stopAllActions()
	self.listView:runAction(CCSequence:create(arr))

	self.labTimeVal:stopAllActions()
	self.labTimeVal:runAction(CCRepeatForever:create(
		CCSequence:createWithTwoActions(CCDelayTime:create(1),
			CCCallFunc:create(function()
				local str,isRefresh = self.viewVo:getLeftTime()
				self.labTimeVal:setString(str)
				if isRefresh == false then
					self.labTimeVal:stopAllActions()
				end
			end))))
end


-----------------------------------------------------------------------------------
--累计消费
FestivalRecostView = class("FestivalRecostView",function()
	return Layout:create()
end)

function FestivalRecostView:create(id)
    local ret = FestivalRecostView.new()
    ret:init(id)
    return ret
end

function FestivalRecostView:init(id)

	self._widget = GUIReader:shareReader():widgetFromJsonFile("reward/RewardLoginView.ExportJson")
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	self.listView = tolua.cast(self._widget:getChildByName("list_view"),"ListView")

	self.viewVo = FestivalDataProxy:getInstance():getMenuItemVoById(id)

	self.labRegulationFix = CCLabelTTF:create("活動規則：","",22)
	self.labRegulationFix:setAnchorPoint(ccp(0,0.5))
	self.labRegulationFix:setPosition(ccp(520,479))
	self.labRegulationFix:setColor(ccc3(0xFE,0xE1,0x6B))
	-- self.labRegulationFix:enableStroke(ccc3(55,25,25),1,true)
	--self._widget:addNode( Utils.createStroke(self.labRegulationFix,1,ccc3(55,25,25)) )
	self._widget:addNode( Utils.createStrokeLabel(self.labRegulationFix,1,ccc3(55,25,25))) 

	self.labRegulation = CCLabelTTF:create(self.viewVo.desc,"",22)
	self.labRegulation:setDimensions(CCSize(254,195))
	self.labRegulation:setAnchorPoint(ccp(0,1))
	self.labRegulation:setHorizontalAlignment(kCCTextAlignmentLeft)
	self.labRegulation:setPosition(ccp(638,490))
	self.labRegulation:setColor(ccc3(0xFE,0xE1,0x6B))
	-- self.labRegulation:enableStroke(ccc3(55,25,25),1,true)
	--self._widget:addNode( Utils.createStroke(self.labRegulation,1,ccc3(55,25,25)) )
	self._widget:addNode( Utils.createStrokeLabel(self.labRegulation,1,ccc3(55,25,25)))

	self.labTimeValFix = CCLabelTTF:create("活動時間：","",22)
	self.labTimeValFix:setAnchorPoint(ccp(0,0.5))
	self.labTimeValFix:setPosition(ccp(521,392))
	self.labTimeValFix:setColor(ccc3(0xFE,0xE1,0x6B))
	-- self.labTimeValFix:enableStroke(ccc3(55,25,25),1,true)
	--self._widget:addNode( Utils.createStroke(self.labTimeValFix,1,ccc3(55,25,25)) )
	self._widget:addNode( Utils.createStrokeLabel(self.labTimeValFix,1,ccc3(55,25,25)))

	self.labTimeVal = CCLabelTTF:create("","",22)
	self.labTimeVal:setAnchorPoint(ccp(0,0.5))
	self.labTimeVal:setPosition(ccp(641,391))
	self.labTimeVal:setColor(ccc3(0xFE,0xE1,0x6B))
	-- self.labTimeVal:enableStroke(ccc3(55,25,25),1,true)
	--self._widget:addNode( Utils.createStroke(self.labTimeVal,1,ccc3(55,25,25)) )
	self._widget:addNode( Utils.createStrokeLabel(self.labTimeVal,1,ccc3(55,25,25)))
end

function FestivalRecostView:setData(menuVo)

	self.viewVo = menuVo
end

function FestivalRecostView:enter()

	local dp = FestivalDataProxy:getInstance()
	local rm = FestivalRenderMgr:getInstance()

	local tmpList = {}
	for k,v in pairs( dp:getRewardListById(self.viewVo.act_id)) do
		table.insert(tmpList,v)
	end

	table.sort(tmpList, function(a,b)
		return a.id < b.id
	end)

	local arr = CCArray:create()
	for i=1,#tmpList do
		local key = string.format("viewitem_%d_%d_%d",self.viewVo.festival_id,self.viewVo.act_id,tmpList[i].id)
 		local item = rm.dic:objectForKey(key)
 		if item == nil then
			arr:addObject(CCDelayTime:create(0.2))
		end
		arr:addObject(CCCallFunc:create(function()
	 		local item = rm.dic:objectForKey(key)
 			if item == nil then
				item = FestivalRecostItem:create( dp:getRewardListItemById(self.viewVo.act_id,tmpList[i].id),self.viewVo)
				rm.dic:setObject(item,key)
			end
			item:update()
			self.listView:pushBackCustomItem(item)
		end))
	end
	self.listView:removeAllItems()
	self.listView:stopAllActions()
	self.listView:runAction(CCSequence:create(arr))

	self.labTimeVal:stopAllActions()
	self.labTimeVal:runAction(CCRepeatForever:create(
		CCSequence:createWithTwoActions(CCDelayTime:create(1),
			CCCallFunc:create(function()
				local str,isRefresh = self.viewVo:getLeftTime()
				self.labTimeVal:setString(str)
				if isRefresh == false then
					self.labTimeVal:stopAllActions()
				end
			end))))
end


-----------------------------------------------------------------------------------
--循环 充值
FestivalCircRechargeView = class("FestivalCircRechargeView",function()
	return Layout:create()
end)

function FestivalCircRechargeView:create(id)
    local ret = FestivalCircRechargeView.new()
    ret:init(id)
    return ret
end

function FestivalCircRechargeView:init(id)

	self._widget = GUIReader:shareReader():widgetFromJsonFile("reward/RewardLoginView.ExportJson")
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	self.listView = tolua.cast(self._widget:getChildByName("list_view"),"ListView")

	self.viewVo = FestivalDataProxy:getInstance():getMenuItemVoById(id)

	self.labRegulationFix = CCLabelTTF:create("活動規則：","",22)
	self.labRegulationFix:setAnchorPoint(ccp(0,0.5))
	self.labRegulationFix:setPosition(ccp(520,479))
	self.labRegulationFix:setColor(ccc3(0xFE,0xE1,0x6B))
	-- self.labRegulationFix:enableStroke(ccc3(55,25,25),1,true)
	--self._widget:addNode( Utils.createStroke(self.labRegulationFix,1,ccc3(55,25,25)) )
	self._widget:addNode( Utils.createStrokeLabel(self.labRegulationFix,1,ccc3(55,25,25))) 

	self.labRegulation = CCLabelTTF:create(self.viewVo.desc,"",22)
	self.labRegulation:setDimensions(CCSize(254,195))
	self.labRegulation:setAnchorPoint(ccp(0,1))
	self.labRegulation:setHorizontalAlignment(kCCTextAlignmentLeft)
	self.labRegulation:setPosition(ccp(638,490))
	self.labRegulation:setColor(ccc3(0xFE,0xE1,0x6B))
	-- self.labRegulation:enableStroke(ccc3(55,25,25),1,true)
	--self._widget:addNode( Utils.createStroke(self.labRegulation,1,ccc3(55,25,25)) )
	self._widget:addNode( Utils.createStrokeLabel(self.labRegulation,1,ccc3(55,25,25)))

	self.labTimeValFix = CCLabelTTF:create("活動時間：","",22)
	self.labTimeValFix:setAnchorPoint(ccp(0,0.5))
	self.labTimeValFix:setPosition(ccp(521,392))
	self.labTimeValFix:setColor(ccc3(0xFE,0xE1,0x6B))
	-- self.labTimeValFix:enableStroke(ccc3(55,25,25),1,true)
	--self._widget:addNode( Utils.createStroke(self.labTimeValFix,1,ccc3(55,25,25)) )
	self._widget:addNode( Utils.createStrokeLabel(self.labTimeValFix,1,ccc3(55,25,25)))

	self.labTimeVal = CCLabelTTF:create("","",22)
	self.labTimeVal:setAnchorPoint(ccp(0,0.5))
	self.labTimeVal:setPosition(ccp(641,391))
	self.labTimeVal:setColor(ccc3(0xFE,0xE1,0x6B))
	-- self.labTimeVal:enableStroke(ccc3(55,25,25),1,true)
	--self._widget:addNode( Utils.createStroke(self.labTimeVal,1,ccc3(55,25,25)) )
	self._widget:addNode( Utils.createStrokeLabel(self.labTimeVal,1,ccc3(55,25,25)))
end

function FestivalCircRechargeView:setData(menuVo)

	self.viewVo = menuVo
end

function FestivalCircRechargeView:enter()

	local dp = FestivalDataProxy:getInstance()
	local rm = FestivalRenderMgr:getInstance()

	local tmpList = {}
	for k,v in pairs( dp:getRewardListById(self.viewVo.act_id)) do
		table.insert(tmpList,v)
	end

	table.sort(tmpList, function(a,b)
		return a.id < b.id
	end)

	local arr = CCArray:create()
	for i=1,#tmpList do
		local key = string.format("viewitem_%d_%d_%d",self.viewVo.festival_id,self.viewVo.act_id,tmpList[i].id)
 		local item = rm.dic:objectForKey(key)
 		if item == nil then
			arr:addObject(CCDelayTime:create(0.2))
		end
		arr:addObject(CCCallFunc:create(function()
	 		local item = rm.dic:objectForKey(key)
 			if item == nil then
				item = FestivalCircRechargeItem:create( dp:getRewardListItemById(self.viewVo.act_id,tmpList[i].id),self.viewVo)
				rm.dic:setObject(item,key)
			end
			item:update()
			self.listView:pushBackCustomItem(item)
		end))
	end
	self.listView:removeAllItems()
	self.listView:stopAllActions()
	self.listView:runAction(CCSequence:create(arr))

	self.labTimeVal:stopAllActions()
	self.labTimeVal:runAction(CCRepeatForever:create(
		CCSequence:createWithTwoActions(CCDelayTime:create(1),
			CCCallFunc:create(function()
				local str,isRefresh = self.viewVo:getLeftTime()
				self.labTimeVal:setString(str)
				if isRefresh == false then
					self.labTimeVal:stopAllActions()
				end
			end))))
end
