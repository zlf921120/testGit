--活动发放 数据读取类
FestivalLocalReader = class("FestivalLocalReader")

local __instance = nil
local _allowInstance = false
local _hasLoad = false

function FestivalLocalReader:ctor()
    if not _allowInstance then
		error("FestivalLocalReader is a singleton class")
	end
	self:init()
end

function FestivalLocalReader:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = FestivalLocalReader.new()
		_allowInstance = false
	end

	return __instance
end

function FestivalLocalReader:init()
	require "fnt_holiday_data_pb"
end

--获取 本地数据并创建值对象 
function FestivalLocalReader:loadInProxy()

	if _hasLoad then return end--只加载一次
	_hasLoad = true

	local dp = FestivalDataProxy:getInstance()

-----------------------------------------------------------
    local pbdata = FileUtils.readConfigFile("fnt_holiday_data.dat")
    local msg = fnt_holiday_data_pb.fnt_holiday_data()
    msg:ParseFromString(pbdata)

    local function makeRewardTbl(str,focus)
        local ret = {}
        local tblArr = Utils.split(str,",")
        for i,v in ipairs(tblArr) do
            local t = Utils.split(v,";")
            table.insert(ret,{base_id = tonumber(t[1]), num = tonumber(t[2]),focus = 0}) 
        end
        local focusArr = Utils.split(focus or "",";")
        for i,v in ipairs(ret) do
            for ii,vv in ipairs(focusArr) do
                if v.base_id == tonumber(vv) then
                    v.focus = 1
                end
            end
        end
        return ret
    end

    --显示配置
    local viewUnit = msg.all_holiday_cfg_rows
    local sortViewList = dp.viewSortList
    local idx = 0
    for i, v in pairs(viewUnit) do
        if v.view_sort ~= nil then
            idx = idx +1
            local menuItemVo = dp:createMenuItemVo()
            menuItemVo.id = idx
            menuItemVo.title = v.title
            menuItemVo.desc = v.desc
            menuItemVo.start_time = Helper.getNewTime(v.start_time)
            menuItemVo.end_time = Helper.getNewTime(v.end_time)
            menuItemVo.res_icon = v.res_icon
            menuItemVo.festival_id = v.festival_id
            menuItemVo.act_id = v.act_id
            dp:setMenuItemVo(menuItemVo)

            table.insert(sortViewList,{sort = v.view_sort, idx = idx, festival_id = v.festival_id, id = v.act_id })
        end
    end

    local voList = dp:getFestivalVoList()
    local festival_cfg_rows = msg.festival_cfg_rows
    for id,v in pairs(festival_cfg_rows) do
        if v.f_id then
            local festivalVo = dp:createFestivalVo()
            festivalVo.festival_id = v.f_id
            festivalVo.res_icon = v.icon_res
            festivalVo.start_time = Helper.getNewTime(v.start_time)
            festivalVo.end_time = Helper.getNewTime(v.end_time)
            voList[v.f_id] = festivalVo
        end
    end
-------------------------------------------------------------
    local rewardList = dp:getAllRewardList() --活动奖励类型总表
    rewardList[FestivalTypeItemCfg.Recharge] = {} --累计充值
    rewardList[FestivalTypeItemCfg.Enchant] = {} --附魔奖励
    rewardList[FestivalTypeItemCfg.Exchange] = {} --兑换
    rewardList[FestivalTypeItemCfg.FirstCharge] = {} --首充
    rewardList[FestivalTypeItemCfg.Physical] = {} --体力
    rewardList[FestivalTypeItemCfg.Recost] = {} --累计消费
    rewardList[FestivalTypeItemCfg.CirculRecharge] = {} --循环充值
    rewardList[FestivalTypeItemCfg.GemLevup] = {} --宝石升级 

    --充值
    local charge_total_cfg = msg.charge_total_cfg_rows
    for id,v in ipairs(charge_total_cfg) do
    	if v.charge ~= nil then
    		local itemVo = dp:createRechargeItemVo()
            itemVo.title = v.title
    		itemVo.id = id
    		itemVo.total = v.charge
    		itemVo.rewardList = makeRewardTbl(v.reward,v.focus_base_id)
            rewardList[FestivalTypeItemCfg.Recharge][id] = itemVo
    	end
    end
    --附魔
    local enchant_cfg_rows = msg.enchant_cfg_rows
    for id,v in ipairs(enchant_cfg_rows) do
    	if v.enchant_lev ~= nil then
    		local itemVo = dp:createEnchantItemVo()
            itemVo.title = v.title
    		itemVo.id = id
    		itemVo.enchant_lev = v.enchant_lev
    		itemVo.rewardList = makeRewardTbl(v.reward,v.focus_base_id)
    		rewardList[FestivalTypeItemCfg.Enchant][id] = itemVo
    	end
    end
    --兑换
    local exchange_cfg_rows = msg.exchange_cfg_rows
    for id,v in ipairs(exchange_cfg_rows) do
        if v.base_id ~= nil then
            local itemVo = dp:createExchangeItemVo()
            itemVo.title = v.title
            itemVo.id = v.base_id
            itemVo.cost = makeRewardTbl(v.cost,v.focus_base_id)
            itemVo.rewardList = makeRewardTbl(v.reward,v.focus_base_id)
            itemVo.exchange_num = v.exchange_num
            rewardList[FestivalTypeItemCfg.Exchange][v.base_id] = itemVo
        end
    end
    --首充
    local first_charge_cfg_rows = msg.first_charge_cfg_rows
    for k,v in pairs(first_charge_cfg_rows) do
        if v.base_id ~= nil then
            local itemVo = dp:createFirstChargeItemVo()
            itemVo.title = v.title
            itemVo.id = v.base_id
            itemVo.rewardList = makeRewardTbl(v.reward,v.focus_base_id)
            rewardList[FestivalTypeItemCfg.FirstCharge][v.base_id] = itemVo
        end
    end
    --显示配置
    local view_cfg_rows = msg.view_cfg_rows
    for k,v in pairs(view_cfg_rows) do
        if v.main_id then
            local itemVo = dp:createEmptyItemVo()
            itemVo.title = v.desc
            itemVo.id = v.sort_id
            itemVo.rewardList = makeRewardTbl(v.reward,v.focus_base_id)
            rewardList[v.act_id] = rewardList[v.act_id] or {}
            rewardList[v.act_id][v.sort_id] = itemVo
        end
    end

    --累计消费
    local loss_gold_cfg_rows = msg.loss_gold_cfg_rows
    for k,v in pairs(loss_gold_cfg_rows) do
        if v.loss_gold then
            local itemVo = dp:createRecostItemVo()
            itemVo.title = v.desc
            itemVo.id = v.loss_gold
            itemVo.cost = v.loss_gold
            itemVo.rewardList = makeRewardTbl(v.reward,v.focus_base_id)
            rewardList[FestivalTypeItemCfg.Recost][v.loss_gold] = itemVo
        end
    end

    --循环充值
    local for_charge_cfg_rows = msg.for_charge_cfg_rows
    for k,v in pairs(for_charge_cfg_rows) do
        if v.charge then
            local itemVo = dp:createCircChargeItemVo()
            itemVo.title = v.desc
            itemVo.id = v.charge
            itemVo.charge = v.charge
            itemVo.rewardList = makeRewardTbl(v.reward,v.focus_base_id)
            rewardList[FestivalTypeItemCfg.CirculRecharge][v.charge] = itemVo
        end
    end

    --宝石升级 
    local gem_upgrade_cfg_rows = msg.gem_upgrade_cfg_rows
    for k,v in pairs(gem_upgrade_cfg_rows) do
        if v.gem_id then
            local itemVo = dp:createGemLevupItemVo()
            itemVo.title = v.desc
            itemVo.id = v.gem_id
            itemVo.rewardList = makeRewardTbl(v.reward,v.focus_base_id)
            rewardList[FestivalTypeItemCfg.GemLevup][v.gem_id] = itemVo
        end
    end

    --节日活动 体力增量
    local holiday_limit_physical_cfg_rows = msg.holiday_limit_physical_cfg_rows
    for k,v in pairs(holiday_limit_physical_cfg_rows) do
        if v.id then
            dp.physical_addition = v.addition_phyiscal
        end
    end
end