-- 奖励发放 渲染器
FestivalRenderMgr = class("FestivalRenderMgr")
FestivalRenderMgr.dic = nil
FestivalRenderMgr.lastShowView = 0

local __instance = nil
local _allowInstance = false

function FestivalRenderMgr:ctor()
    if not _allowInstance then
		error("FestivalRenderMgr is a singleton class")
	end
	self:init()
end

function FestivalRenderMgr:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = FestivalRenderMgr.new()
		_allowInstance = false
	end

	return __instance
end

function FestivalRenderMgr:destoryInstance()

	self.dic:release()
	_allowInstance = false
	__instance = nil
end

function FestivalRenderMgr:init()

	self.dic = CCDictionary:create() --缓存
	self.dic:retain()

	Notifier.regist(FestivalEvent.UPDATE_ITEM,function(params) self:updateItem(params) end)
end

function FestivalRenderMgr:pushMenu(menuId)

	local view = self.dic:objectForKey(string.format("Festivalmenu_%d",menuId))
	if view == nil then
		view = FestivalMenuItem:create(menuId)
		self.dic:setObject(view,string.format("Festivalmenu_%d",menuId))
	end
	view:update( menuId )
	self.listMenu:pushBackCustomItem(view)
end

--检测需要显示的区域(若菜单项消失则 显示首个)
function FestivalRenderMgr:checkShowView(force)
	local dp = FestivalDataProxy:getInstance()
	local arr = self.listMenu:getItems()
	local hasCurMenu = false
	for i=0,arr:count() - 1 do
		if arr:objectAtIndex(i).key == dp.curShowViewKey then
			hasCurMenu = true
			break
		end
	end
	if hasCurMenu == false then
		local item = self.listMenu:getItem(0)
		if item ~= nil then
			print(" item.key ",item.key)
			self:showView(item.key,force)
		else --没有子菜单项了
			WindowCtrl:getInstance():close(CmdName.Festival_Scene)
		end
	else
		self:showView(dp.curShowViewKey,force)
	end
end

function FestivalRenderMgr:setViewContainer(container,menu)
	self.viewContainer = container
	self.listMenu = menu
end

function FestivalRenderMgr:clearMenu()
	self.listMenu:removeAllItems()
end

function FestivalRenderMgr:delMenu(key)
	
	local dp = FestivalDataProxy:getInstance()
	local menuVo = dp:getMenuItemVoById(key)
	local voList = dp:getRewardListById(menuVo.act_id)

	TimerManager.addTimer(500,function() --延时删除
		if voList then
			for k,v in pairs(voList) do
				self.dic:removeObjectForKey(string.format("viewitem_%d_%d_%d",menuVo.festival_id,menuVo.act_id,v.id))
			end
		end
		voList = nil
		self.dic:removeObjectForKey(string.format("Festivalview_%d",key))
	end)
end

function FestivalRenderMgr:showView(id,force)

	if self.lastShowView == id and force == nil then
		return
	else
		local lastMenu = self.dic:objectForKey(string.format("Festivalmenu_%d",self.lastShowView))
		if lastMenu ~= nil then
			lastMenu:setBright(false)
		end
		self.lastShowView = id
		local curMenu = self.dic:objectForKey(string.format("Festivalmenu_%d",id))
		curMenu:setBright(true)
	end

	local dp = FestivalDataProxy:getInstance()
	self.viewContainer:removeAllChildren()
	self.viewContainer:removeAllNodes()

	local menuVo = dp:getMenuItemVoById(id)
	local view = self.dic:objectForKey(string.format("Festivalview_%d",id))
	if view == nil then
		print(" menuVo.act_id ",menuVo.act_id)
		if menuVo.act_id == FestivalTypeItemCfg.Recharge then
			view = FestivalRechargeView:create(id)
		elseif menuVo.act_id == FestivalTypeItemCfg.Enchant then
			view = FestivalEnchantView:create(id)
		elseif menuVo.act_id == FestivalTypeItemCfg.FirstCharge then
			view = FestivalFirstChargeView:create(id)
		elseif menuVo.act_id == FestivalTypeItemCfg.Exchange then
			view = FestivalExchangeView:create(id)
		elseif menuVo.act_id == FestivalTypeItemCfg.Recost then
			view = FestivalRecostView:create(id)
		elseif menuVo.act_id == FestivalTypeItemCfg.CirculRecharge then
			view = FestivalCircRechargeView:create(id)
		elseif menuVo.act_id == FestivalTypeItemCfg.Physical or 
				menuVo.act_id == FestivalTypeItemCfg.DungeonExp2 or
				menuVo.act_id == FestivalTypeItemCfg.ArenaReward2 or
				menuVo.act_id == FestivalTypeItemCfg.TowerReward2 or
				menuVo.act_id == FestivalTypeItemCfg.GloryReward2 or
				menuVo.act_id == FestivalTypeItemCfg.SkyBattleReward2 or
				menuVo.act_id == FestivalTypeItemCfg.DungeonResReward2 or
				menuVo.act_id == FestivalTypeItemCfg.ResContentReward2 or
				menuVo.act_id == FestivalTypeItemCfg.GemLevup then

			view = FestivalEmptyView:create(id)
		end
		view:setData(menuVo)
		self.dic:setObject(view,string.format("Festivalview_%d",id))
	end
	view:enter()
	self.viewContainer:addChild(view)

	FestivalView:getInstance():updateView( menuVo )
end

--更新条目
function FestivalRenderMgr:updateItem(params)
	if params and params.id ~= nil then
		local key = string.format("viewitem_%d_%d_%d",params.festival_id,params.act_id,params.id)
		local itemView = self.dic:objectForKey(key)
		if itemView then
			itemView:update()
		end
	end
end