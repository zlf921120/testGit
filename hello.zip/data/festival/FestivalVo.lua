--节日 菜单 显示 条目
FestivalMenuVo = class("FestivalMenuVo")
FestivalMenuVo.id = 0
FestivalMenuVo.festival_id = 0
FestivalMenuVo.act_id = 0
FestivalMenuVo.title = ""
FestivalMenuVo.desc = ""
FestivalMenuVo.start_time = 0
FestivalMenuVo.end_time = 0
FestivalMenuVo.res_icon = ""
FestivalMenuVo.rewardInfos = nil --动态 活动状况
function FestivalMenuVo:ctor()
	self.rewardInfos = {total_charge = 0,is_charge = 0,finish_total_charge={},enchant={},exchange_num=0,total_cost=0,circle_charge=0,total_cost_arr={}}
end
function FestivalMenuVo:getLeftTime()
	local ret = ""
	local isRefresh = false
	local menuVo = FestivalDataProxy:getInstance():getMenuItemVoById(self.id)
	if menuVo then
		local nowTime = ServerTimerManager:getInstance():getCurTime()
		if nowTime >= menuVo.start_time and nowTime < menuVo.end_time then
			local leftTime = math.max(0,menuVo.end_time - nowTime)
			ret = Helper.getChCoutStringTime(leftTime)
			isRefresh = true
		elseif nowTime < menuVo.start_time then --未到期
			ret = "未開始"
			isRefresh = false
		elseif nowTime >= menuVo.end_time then --过期
			ret = "已過期"
			isRefresh = false
		end
	end
	return ret
end

FestivalVo = class("FestivalVo")
FestivalVo.res_icon = ""
FestivalVo.festival_id = 0
FestivalVo.start_time = 0
FestivalVo.end_time = 0
function FestivalVo:isVaild()
	local ret = false
	local nowTime = ServerTimerManager:getInstance():getCurTime()
	if nowTime >= self.start_time and nowTime < self.end_time then
		ret = true
	elseif nowTime < self.start_time then --未到期
		ret = false
	elseif nowTime >= self.end_time then --过期
		ret = false
	end
	return ret
end

--累计充值 奖励条目
FestivalRechargeItemVo = class("FestivalRechargeItemVo")
FestivalRechargeItemVo.id = 0
FestivalRechargeItemVo.total = 0
FestivalRechargeItemVo.title = ""
FestivalRechargeItemVo.rewardList = nil

 --附魔 奖励条目
FestivalEnchantItemVo = class("FestivalEnchantItemVo")
FestivalEnchantItemVo.id = 0
FestivalEnchantItemVo.title = ""
FestivalEnchantItemVo.enchant_lev = 0
FestivalEnchantItemVo.rewardList = nil

--兑换 奖励条目
FestivalExchangeItemVo = class("FestivalExchangeItemVo")
FestivalExchangeItemVo.id = 0
FestivalExchangeItemVo.title = ""
FestivalExchangeItemVo.cost = nil
FestivalExchangeItemVo.rewardList = nil

--累计消费 奖励条目
FestivalRecostItemVo = class("FestivalRecostItemVo")
FestivalRecostItemVo.id = 0 
FestivalRecostItemVo.total = 0
FestivalRecostItemVo.title = ""
FestivalRecostItemVo.rewardList = nil

--循环充值 奖励条目
FestivalCircChargeItemVo = class("FestivalCircChargeItemVo")
FestivalCircChargeItemVo.id = 0
FestivalCircChargeItemVo.title = ""
FestivalCircChargeItemVo.rewardList = nil
FestivalCircChargeItemVo.charge = 0

--宝石升级 奖励条目
FestivalGemLevupItemVo = class("FestivalGemLevupItemVo")
FestivalGemLevupItemVo.id = 0
FestivalGemLevupItemVo.title = ""
FestivalGemLevupItemVo.rewardList = nil
FestivalGemLevupItemVo.widgetLabel = true

--首充 奖励条目
FestivalFirstChargeItemVo = class("FestivalFirstChargeItemVo")
FestivalFirstChargeItemVo.id = 0
FestivalFirstChargeItemVo.title = ""
FestivalFirstChargeItemVo.rewardList = nil

--纯显示 奖励条目
FestivalEmptyItemVo = class("FestivalEmptyItemVo")
FestivalEmptyItemVo.id = 0
FestivalEmptyItemVo.title = ""
FestivalEmptyItemVo.rewardList = nil