--节日活动 网络助手
FestivalNetTask = class("FestivalNetTask")

local __instance = nil
local _allowInstance = false

function FestivalNetTask:ctor()
    if not _allowInstance then
		error("FestivalNetTask is a singleton class")
	end
	self:init()
end

function FestivalNetTask:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = FestivalNetTask.new()
		_allowInstance = false
	end

	return __instance
end

function FestivalNetTask:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function FestivalNetTask:init()
	require "activitie_pb"
	require "proto_cmd_2_pb"
	require "FestivalDataProxy"

	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.activitie_holiday_entrance_rsp,"handleFestivalInfos()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.activitie_holiday_charge_rsp,"handleFestivalFirstCharge()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.activitie_holiday_exchange_rsp,"handleFestivalExchange()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.activitie_holiday_total_charge_rsp,"handleFestivalTotalCharge()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.activitie_holiday_enchant_rsp,"handleFestivalEnchantReward()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.activitie_holiday_loss_gold_reward_rsp,"handleRecostReward()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.activitie_holiday_for_charge_reward_rsp,"handleCircRechargeReward()")
end
--请求节日活动信息
local _view_festival_id = 0
function FestivalNetTask:requestFestivalInfos(festival_id)
	print("------------------------requestFestivalInfos----------------------------",festival_id)
	local activitie_holiday_entrance_req = activitie_pb.activitie_holiday_entrance_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.activitie_holiday_entrance_req,activitie_holiday_entrance_req)
	_view_festival_id = festival_id
end
--响应节日活动信息
function handleFestivalInfos(pkg)
	local activitie_holiday_entrance_rsp = activitie_pb.activitie_holiday_entrance_rsp()
	activitie_holiday_entrance_rsp:ParseFromString(pkg)

	print("----------------------handleFestivalInfos------------------",activitie_holiday_entrance_rsp.ret)
	if activitie_holiday_entrance_rsp.ret == error_code_pb.msg_ret.success then
		local dp = FestivalDataProxy:getInstance()
		dp:makeFestivalInfos(activitie_holiday_entrance_rsp.holiday)

		ComSender:getInstance():dealExtInfo(activitie_holiday_entrance_rsp.ext)
		WindowCtrl:getInstance():open(CmdName.FestivalView,{festival_id = _view_festival_id})
	else
		Alert:show(Helper.getErrStr(activitie_holiday_entrance_rsp.ret))
	end
end

--请求领取 首充奖励
local _firstChargeItemId = 0
function FestivalNetTask:requestFirstCharge(festival_id,act_id,item_id)
	print("------------------------requestFirstCharge----------------------------")
	local activitie_holiday_charge_req = activitie_pb.activitie_holiday_charge_req()
	activitie_holiday_charge_req.holiday_id = festival_id
	activitie_holiday_charge_req.son_id = act_id
	_firstChargeItemId = item_id
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.activitie_holiday_charge_req,activitie_holiday_charge_req)
end

--响应领取 首充奖励
function handleFestivalFirstCharge(pkg)
	local activitie_holiday_charge_rsp = activitie_pb.activitie_holiday_charge_rsp()
	activitie_holiday_charge_rsp:ParseFromString(pkg)

	print("----------------------handleFestivalFirstCharge------------------",activitie_holiday_charge_rsp.ret)
	if activitie_holiday_charge_rsp.ret == error_code_pb.msg_ret.success then

		ItemManager:getInstance():addMultiItem(activitie_holiday_charge_rsp.items)  --更新背包 
    	CharacterManager:getInstance():updateRoleAssets(activitie_holiday_charge_rsp.assets) --更新资产
    	Alert:show("領取成功")

    	local dp = FestivalDataProxy:getInstance()
    	
  --   	local heroes_goods = activitie_holiday_charge_rsp.heroes_goods
  --   	local heroes_goods_len = #heroes_goods
  --   	require "RewardDataProxy"
  --   	local heroList = RewardDataProxy:getInstance():getFirstChargeGetHeroList()
  --   	require "LotteryDataProxy"
  --   	print(" activitie_holiday_charge_rsp.heroes_items ",#activitie_holiday_charge_rsp.heroes_items)
  --   	local items = activitie_holiday_charge_rsp.heroes_items
  --   	for i=1,#items do
		-- 	local heroItemVo = LotteryDataProxy:getInstance():getLotteryHeroItemVoById(items[i].base_id)
		-- 	local heroId = heroItemVo.heroId
		-- 	local heroStar = heroItemVo.heroStar
		-- 	local quality = items[i].quantity

		-- 	print(" t ","hero",itemBaseId,heroId,heroStar)  
		-- 	table.insert(heroList,
		-- 		{ t = "hero", baseId = itemBaseId , heroId = heroId , heroStar = heroStar, quality = quality })
		-- end

		-- local items = activitie_holiday_charge_rsp.heroes_goods
		-- print(" activitie_holiday_charge_rsp.heroes_goods ",#activitie_holiday_charge_rsp.heroes_goods)
  --   	for i=1,#items do
		-- 	local heroItemVo = LotteryDataProxy:getInstance():getLotteryHeroItemVoById(items[i].hero_id)
		-- 	local heroId = heroItemVo.heroId
		-- 	local heroStar = heroItemVo.heroStar
		-- 	local quality = items[i].num

		-- 	print(" t ","stone",itemBaseId,heroId,heroStar)  
		-- 	table.insert(heroList,
		-- 		{ t = "stone", baseId = itemBaseId , heroId = heroId , heroStar = heroStar, quality = quality })
		-- end

		-- if #heroList > 0 then
		-- 	print(" heroList[1].heroId ",heroList[1].heroId,heroList[1],GuideGetHeroArea.MainScene)
		-- 	WindowCtrl:getInstance():open(CmdName.GuideHeroAnimScene,
		-- 		{hero_id = heroList[1].heroId,heroItemVo = heroList[1],area = GuideGetHeroArea.MainScene})
		-- end

  --   	HeroManager:getInstance():refreshAllHero(activitie_holiday_charge_rsp.heroes) --刷新英雄数据

  		local menuVo = dp:getMenuItemVoByActId(activitie_holiday_charge_rsp.holiday_id,activitie_holiday_charge_rsp.son_id)
  		menuVo.rewardInfos["is_charge"] = activitie_holiday_charge_rsp.is_charge

    	Notifier.dispatchCmd(FestivalEvent.UPDATE_ITEM,
    		{festival_id=activitie_holiday_charge_rsp.holiday_id,
    			act_id=activitie_holiday_charge_rsp.son_id,
    			id=_firstChargeItemId})
    	Notifier.dispatchCmd(FestivalEvent.UPDATE_SCENE)

		ComSender:getInstance():dealExtInfo(activitie_holiday_charge_rsp.ext)
	else
		Alert:show(Helper.getErrStr(activitie_holiday_charge_rsp.ret))
	end
end

--请求领取 附魔奖励
local _enchatItemId = 0
function FestivalNetTask:requestEnchantReward(festival_id,act_id,lev,item_id)
	print("------------------------requestEnchantReward----------------------------")
	local activitie_holiday_enchant_req = activitie_pb.activitie_holiday_enchant_req()
	activitie_holiday_enchant_req.enchant_lev = lev
	activitie_holiday_enchant_req.holiday_id = festival_id
	activitie_holiday_enchant_req.son_id = act_id
	_enchatItemId = item_id
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.activitie_holiday_enchant_req,activitie_holiday_enchant_req)
end

--响应领取 附魔奖励
function handleFestivalEnchantReward(pkg)
	local activitie_holiday_enchant_rsp = activitie_pb.activitie_holiday_enchant_rsp()
	activitie_holiday_enchant_rsp:ParseFromString(pkg)

	print("----------------------handleFestivalEnchantReward------------------",activitie_holiday_enchant_rsp.ret)
	if activitie_holiday_enchant_rsp.ret == error_code_pb.msg_ret.success then
		local dp = FestivalDataProxy:getInstance()
		ItemManager:getInstance():addMultiItem(activitie_holiday_enchant_rsp.gain_items)  --更新背包 
    	CharacterManager:getInstance():updateRoleAssets(activitie_holiday_enchant_rsp.assets) --更新资产
    	Alert:show("領取成功")

    	local menuVo = dp:getMenuItemVoByActId(activitie_holiday_enchant_rsp.holiday_id,activitie_holiday_enchant_rsp.son_id)
  		menuVo.rewardInfos["enchant"] = menuVo.rewardInfos["enchant"] or {}
  		for i,v in ipairs(menuVo.rewardInfos["enchant"]) do
  			if v.lev == activitie_holiday_enchant_rsp.enchant_lev then
  				v.num = 0
  			end
  		end

    	Notifier.dispatchCmd(FestivalEvent.UPDATE_ITEM,
    		{festival_id=activitie_holiday_enchant_rsp.holiday_id,
    			act_id=activitie_holiday_enchant_rsp.son_id,
    			id=_enchatItemId})
    	Notifier.dispatchCmd(FestivalEvent.UPDATE_SCENE)

		ComSender:getInstance():dealExtInfo(activitie_holiday_enchant_rsp.ext)
	else
		Alert:show(Helper.getErrStr(activitie_holiday_enchant_rsp.ret))
	end
end

--请求领取 累计充值
local _reChargeItemId = 0
function FestivalNetTask:requestTotalChargeReward(festival_id,act_id,charge,item_id)
	print("------------------------requestTotalChargeReward----------------------------")
	local activitie_holiday_total_charge_req = activitie_pb.activitie_holiday_total_charge_req()
	activitie_holiday_total_charge_req.holiday_id = festival_id
	activitie_holiday_total_charge_req.son_id = act_id
	activitie_holiday_total_charge_req.charge = charge
	_reChargeItemId = item_id
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.activitie_holiday_total_charge_req,activitie_holiday_total_charge_req)
end

--响应领取 累计充值
function handleFestivalTotalCharge(pkg)
	local activitie_holiday_total_charge_rsp = activitie_pb.activitie_holiday_total_charge_rsp()
	activitie_holiday_total_charge_rsp:ParseFromString(pkg)

	print("----------------------handleFestivalTotalCharge------------------",activitie_holiday_total_charge_rsp.ret)
	if activitie_holiday_total_charge_rsp.ret == error_code_pb.msg_ret.success then
		local dp = FestivalDataProxy:getInstance()
		ItemManager:getInstance():addMultiItem(activitie_holiday_total_charge_rsp.gain_items)  --更新背包 
    	CharacterManager:getInstance():updateRoleAssets(activitie_holiday_total_charge_rsp.assets) --更新资产
    	Alert:show("領取成功")
    	
    	local menuVo = dp:getMenuItemVoByActId(activitie_holiday_total_charge_rsp.holiday_id,activitie_holiday_total_charge_rsp.son_id)
  		menuVo.rewardInfos["finish_total_charge"] = menuVo.rewardInfos["finish_total_charge"] or {}
  		table.insert(menuVo.rewardInfos["finish_total_charge"],activitie_holiday_total_charge_rsp.charge)

    	Notifier.dispatchCmd(FestivalEvent.UPDATE_ITEM,
    		{festival_id=activitie_holiday_total_charge_rsp.holiday_id,
    			act_id=activitie_holiday_total_charge_rsp.son_id,
    			id=_reChargeItemId})

    	Notifier.dispatchCmd(FestivalEvent.UPDATE_SCENE)

		ComSender:getInstance():dealExtInfo(activitie_holiday_total_charge_rsp.ext)
	else
		Alert:show(Helper.getErrStr(activitie_holiday_total_charge_rsp.ret))
	end
end

--请求兑换奖励
local _exchangeItemId = 0
function FestivalNetTask:requestExchangeReward(festival_id,act_id,item_id)
	print("------------------------requestExchangeReward----------------------------")
	local activitie_holiday_exchange_req = activitie_pb.activitie_holiday_exchange_req()
	activitie_holiday_exchange_req.holiday_id = festival_id
	activitie_holiday_exchange_req.son_id = act_id
	_exchangeItemId = item_id
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.activitie_holiday_exchange_req,activitie_holiday_exchange_req)
end
--响应兑换奖励
function handleFestivalExchange(pkg)
	local activitie_holiday_exchange_rsp = activitie_pb.activitie_holiday_exchange_rsp()
	activitie_holiday_exchange_rsp:ParseFromString(pkg)

	print("----------------------handleFestivalExchange------------------",activitie_holiday_exchange_rsp.ret)
	if activitie_holiday_exchange_rsp.ret == error_code_pb.msg_ret.success then
		local dp = FestivalDataProxy:getInstance()
		ItemManager:getInstance():addMultiItem(activitie_holiday_exchange_rsp.gain_items)  --更新背包 
    	CharacterManager:getInstance():updateRoleAssets(activitie_holiday_exchange_rsp.assets) --更新资产

    	local menuVo = dp:getMenuItemVoByActId(activitie_holiday_exchange_rsp.holiday_id,activitie_holiday_exchange_rsp.son_id)
  		menuVo.rewardInfos["exchange_num"] = activitie_holiday_exchange_rsp.exchange_num
  		
    	Notifier.dispatchCmd(FestivalEvent.UPDATE_ITEM,
    		{festival_id=activitie_holiday_exchange_rsp.holiday_id,
    			act_id=activitie_holiday_exchange_rsp.son_id,
    			id=_exchangeItemId})
    	Notifier.dispatchCmd(FestivalEvent.UPDATE_SCENE)

    	ItemManager:getInstance():updateOrDelMultiItems(activitie_holiday_exchange_rsp.del_items)--更新背包物品
		ComSender:getInstance():dealExtInfo(activitie_holiday_exchange_rsp.ext)

		Alert:show("領取成功")
	else
		Alert:show(Helper.getErrStr(activitie_holiday_exchange_rsp.ret))
	end
end

--请求累计消费 奖励
function FestivalNetTask:requestRecostReward(festival_id,act_id,gold)
	print("------------------------requestRecostReward----------------------------")
	local activitie_holiday_loss_gold_reward_req = activitie_pb.activitie_holiday_loss_gold_reward_req()
	activitie_holiday_loss_gold_reward_req.holiday_id = festival_id
	activitie_holiday_loss_gold_reward_req.son_id = act_id
	activitie_holiday_loss_gold_reward_req.gold = gold
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.activitie_holiday_loss_gold_reward_req,activitie_holiday_loss_gold_reward_req)
end

--响应累计消费 奖励
function handleRecostReward(pkg)
	local activitie_holiday_loss_gold_reward_rsp = activitie_pb.activitie_holiday_loss_gold_reward_rsp()
	activitie_holiday_loss_gold_reward_rsp:ParseFromString(pkg)

	print("----------------------handleRecostReward------------------",activitie_holiday_loss_gold_reward_rsp.ret)
	if activitie_holiday_loss_gold_reward_rsp.ret == error_code_pb.msg_ret.success then

		local dp = FestivalDataProxy:getInstance()
		ItemManager:getInstance():addMultiItem(activitie_holiday_loss_gold_reward_rsp.gain_items)  --更新背包 
    	CharacterManager:getInstance():updateRoleAssets(activitie_holiday_loss_gold_reward_rsp.assets) --更新资产

    	local menuVo = dp:getMenuItemVoByActId(activitie_holiday_loss_gold_reward_rsp.holiday_id,activitie_holiday_loss_gold_reward_rsp.son_id)
  		menuVo.rewardInfos["total_cost_arr"] = menuVo.rewardInfos["total_cost_arr"] or {}
  		table.insert(menuVo.rewardInfos["total_cost_arr"],activitie_holiday_loss_gold_reward_rsp.gold)
  		
    	Notifier.dispatchCmd(FestivalEvent.UPDATE_ITEM,
    		{festival_id=activitie_holiday_loss_gold_reward_rsp.holiday_id,
    			act_id=activitie_holiday_loss_gold_reward_rsp.son_id,
    			id=activitie_holiday_loss_gold_reward_rsp.gold})
    	Notifier.dispatchCmd(FestivalEvent.UPDATE_SCENE)

		ComSender:getInstance():dealExtInfo(activitie_holiday_loss_gold_reward_rsp.ext)

		Alert:show("領取成功")
	else
		Alert:show(Helper.getErrStr(activitie_holiday_loss_gold_reward_rsp.ret))
	end
end

--请求循环消费 奖励
local _circRechargeItemid = 0
function FestivalNetTask:requestCircRecharge(festival_id,act_id,item_id)
	print("------------------------requestCircRecharge----------------------------",festival_id,act_id,item_id)
	local activitie_holiday_for_charge_reward_req = activitie_pb.activitie_holiday_for_charge_reward_req()
	activitie_holiday_for_charge_reward_req.holiday_id = festival_id
	activitie_holiday_for_charge_reward_req.son_id = act_id
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.activitie_holiday_for_charge_reward_req,activitie_holiday_for_charge_reward_req)
	_circRechargeItemid = item_id
end

--请求循环消费 奖励
function handleCircRechargeReward(pkg)
	local activitie_holiday_for_charge_reward_rsp = activitie_pb.activitie_holiday_for_charge_reward_rsp()
	activitie_holiday_for_charge_reward_rsp:ParseFromString(pkg)

	print("----------------------handleCircRechargeReward------------------",activitie_holiday_for_charge_reward_rsp.ret)

	if activitie_holiday_for_charge_reward_rsp.ret == error_code_pb.msg_ret.success then
		local dp = FestivalDataProxy:getInstance()
		ItemManager:getInstance():addMultiItem(activitie_holiday_for_charge_reward_rsp.gain_items)  --更新背包 
    	CharacterManager:getInstance():updateRoleAssets(activitie_holiday_for_charge_reward_rsp.assets) --更新资产
    	Alert:show("領取成功")

    	local menuVo = dp:getMenuItemVoByActId(activitie_holiday_for_charge_reward_rsp.holiday_id,activitie_holiday_for_charge_reward_rsp.son_id)
  		menuVo.rewardInfos["circle_charge"] = activitie_holiday_for_charge_reward_rsp.for_charge - activitie_holiday_for_charge_reward_rsp.for_charge_finish_gold

    	Notifier.dispatchCmd(FestivalEvent.UPDATE_ITEM,
    		{festival_id=activitie_holiday_for_charge_reward_rsp.holiday_id,
    			act_id=activitie_holiday_for_charge_reward_rsp.son_id,
    			id=_circRechargeItemid})
    	Notifier.dispatchCmd(FestivalEvent.UPDATE_SCENE)

		ComSender:getInstance():dealExtInfo(activitie_holiday_for_charge_reward_rsp.ext)
	else
		Alert:show(Helper.getErrStr(activitie_holiday_for_charge_reward_rsp.ret))
	end
end