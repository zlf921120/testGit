local btn_effect_path = "ui/effects_ui/UI_jianglilingqu/UI_jianglilingqu.ExportJson"
local armPath = "ui/effects_ui/guizhongwuping/guizhongwuping.ExportJson"
require "ItemInfoPanel"
--------------------------------------------------------------------
-- 节日活动 菜单 条目
FestivalMenuItem = class("FestivalMenuItem", function() 
    return Layout:create()
end)
FestivalMenuItem.__index = FestivalMenuItem
FestivalMenuItem._widget = nil
FestivalMenuItem.key = nil
FestivalMenuItem.is_init = false

function FestivalMenuItem:create(key)
    local ret = FestivalMenuItem.new()
    ret:init(key)
    return ret
end

function FestivalMenuItem:init(key)

	self.key = key
	self._widget = FestivalDataProxy:getInstance():getWidgetMenuItem():clone()
	self:addChild(self._widget)
	self:setSize(CCSize(230,116))

	self.btnClick = self._widget:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	    	FestivalRenderMgr:getInstance():showView(key)

	    	FestivalDataProxy:getInstance().curShowViewKey = key
	    end
	end)

	self.imgBg = tolua.cast(self._widget:getChildByName("img_bg"),"ImageView")
	self.imgIcon = tolua.cast(self._widget:getChildByName("img_icon"),"ImageView")
	self.labTitle = tolua.cast(self._widget:getChildByName("lab_title"),"Label")
end

function FestivalMenuItem:update(id)
	local viewVo = FestivalDataProxy:getInstance():getMenuItemVoById(id)
	if self.is_init == false then
		self.is_init = true
		--繁体版特殊处理
		self.labTitle:setText( viewVo.title )
		self.imgIcon:loadTexture(viewVo.res_icon..".png",UI_TEX_TYPE_PLIST)
	end
	local isShowNewsTips = false
	local dp = FestivalDataProxy:getInstance()
	if viewVo.act_id == FestivalTypeItemCfg.FirstCharge then
		isShowNewsTips = dp:isCanGetFirstCharge(viewVo.id)
	elseif viewVo.act_id == FestivalTypeItemCfg.Recharge then
		isShowNewsTips = dp:isCanGetRecharge(viewVo.id) 
	elseif viewVo.act_id == FestivalTypeItemCfg.Enchant then
		isShowNewsTips = dp:isCanGetEnchant(viewVo.id)
	elseif viewVo.act_id == FestivalTypeItemCfg.Exchange then
		isShowNewsTips = dp:isCanGetExchange(viewVo.id) 
	elseif viewVo.act_id == FestivalTypeItemCfg.Recost then
		isShowNewsTips = dp:isCanGetRecost(viewVo.id)
	elseif viewVo.act_id == FestivalTypeItemCfg.CirculRecharge then
		isShowNewsTips = dp:isCanGetCircRecharge(viewVo.id)
	end
	if isShowNewsTips then
		self:showNewsTip()
	else
		self:hideNewsTip()
	end
end
------------------------------------------------------------------------------
-- 展示 新消息 提示
function FestivalMenuItem:showNewsTip()
    if self:getChildByTag(2866) == nil then
        local tips_img = ImageView:create()
        tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
        tips_img:setTag(2866)
        tips_img:setPosition(ccp(210,100))
        self:addChild(tips_img)
        self:tipsPointPlayAct(tips_img)
    elseif self:getChildByTag(2866) ~= nil then
        local tips_img = self:getChildByTag(2866)
        self:tipsPointPlayAct(tips_img)
    end
end

-- 隐藏 新消息 提示
function FestivalMenuItem:hideNewsTip()
    if self:getChildByTag(2866) ~= nil then
        self:removeChildByTag(2866,true)
    end
end

function FestivalMenuItem:tipsPointPlayAct(img)
	img:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    img:runAction(forever_seqAction)   
end
function FestivalMenuItem:setBright(v)
	if v then
		self.imgBg:loadTexture("bg_10.png",UI_TEX_TYPE_PLIST)
	else
		self.imgBg:loadTexture("btn_up_7.png",UI_TEX_TYPE_PLIST)
	end
end

-------------------------------------------------------------------
-- 累计充值 条目
FestivalRechargeItem = class("FestivalRechargeItem", function() 
    return Layout:create()
end)
FestivalRechargeItem.__index = FestivalRechargeItem
FestivalRechargeItem._widget = nil

function FestivalRechargeItem:create(rewardVo,menuVo)
    local ret = FestivalRechargeItem.new()
    ret:init(rewardVo,menuVo)
    return ret
end

function FestivalRechargeItem:init(rewardVo,menuVo)

	self.menuVo = menuVo
	self.rewardVo = rewardVo
	self._widget = FestivalDataProxy:getInstance():getWidgetLoginItem():clone()
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	local tipTxt = self.rewardVo.title

	self.labTitle = CCLabelTTF:create(tipTxt,"",22)
	self.labTitle:setAnchorPoint(ccp(0,0.5))
	self.labTitle:setPosition(ccp(20,114))
	self.labTitle:setColor(ccc3(0xFE,0xE1,0x6B))
	self._widget:addNode( Utils.createStrokeLabel(self.labTitle,1,ccc3(55,25,25)) )

	self.imgHasGet = tolua.cast(self._widget:getChildByName("img_hasget"),"ImageView")

	self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
	self.btnOk:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then

	    	FestivalNetTask:getInstance():requestTotalChargeReward(self.menuVo.festival_id,self.menuVo.act_id,rewardVo.total,rewardVo.id)
	    end
	end)

	require "ItemIcon"
	local baseX = 53  
	local baseY = 47
	for i=1,#rewardVo.rewardList do
		local v = rewardVo.rewardList[i]
		local icon = ItemIcon:create()
		icon:setScale(0.7)
		icon:setBaseId(v.base_id)
		icon:getClickImg():setTag( v.base_id )
		icon:setTouchEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                
                ItemInfoPanel:show(pSender:getTag())
            elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then
                ItemInfoPanel:hide()
            end
        end)
		icon:setItemNum(v.num)
		icon:setPosition(ccp( baseX + (i-1) * 75,baseY ))
		self._widget:addChild(icon)

		if v.focus == 1 then
	        local arm = AnimateManager:getInstance():getArmature(armPath, "guizhongwuping") 
	        arm:getAnimation():play("Animation1",-1,-1,1)
	        arm:setTag(5514)
	        icon:addNode(arm)
    	end
	end
end

function FestivalRechargeItem:update()
	local isGet = false
	for _,v in ipairs(self.menuVo.rewardInfos.finish_total_charge) do
		if v == self.rewardVo.total then
			isGet = true
			break
		end
	end

	if isGet then
		self.btnOk:setTouchEnabled(false)
		self.btnOk:setVisible(false)
		self.imgHasGet:setVisible(true)
		self:setBtnEffect(false)
	else
		if self.menuVo.rewardInfos.total_charge >= self.rewardVo.total then
			self:setBtnEffect(true)
		end
	end
end

function FestivalRechargeItem:setBtnEffect(is_visible)
    if is_visible then
        if self.btn_effect == nil then
            self.btn_effect = AnimateManager:getInstance():getArmature(btn_effect_path,"UI_jianglilingqu") 
        	self.btn_effect:setScale(1.2)
        	self.btn_effect:setPosition(ccp(-8,5))
        	self.btnOk:addNode(self.btn_effect)
        	self.btn_effect:getAnimation():playWithIndex(0)
        end
    else
        if self.btn_effect then
            self.btn_effect:getAnimation():stop()
            self.btn_effect:removeFromParentAndCleanup(true)
            self.btn_effect = nil
        end
    end
end
-------------------------------------------------------------------
-- 首充 条目
FestivalFirstchargeItem = class("FestivalFirstchargeItem", function() 
    return Layout:create()
end)
FestivalFirstchargeItem.__index = FestivalFirstchargeItem
FestivalFirstchargeItem._widget = nil

function FestivalFirstchargeItem:create(rewardVo,menuVo)
    local ret = FestivalFirstchargeItem.new()
    ret:init(rewardVo,menuVo)
    return ret
end

function FestivalFirstchargeItem:init(rewardVo,menuVo)

	self.menuVo = menuVo
	self.rewardVo = rewardVo
	self._widget = FestivalDataProxy:getInstance():getWidgetLoginItem():clone()
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	local tipTxt = self.rewardVo.title

	self.labTitle = CCLabelTTF:create(tipTxt,"",22)
	self.labTitle:setAnchorPoint(ccp(0,0.5))
	self.labTitle:setPosition(ccp(20,114))
	self.labTitle:setColor(ccc3(0xFE,0xE1,0x6B))
	self._widget:addNode( Utils.createStrokeLabel(self.labTitle,1,ccc3(55,25,25)) )

	self.imgHasGet = tolua.cast(self._widget:getChildByName("img_hasget"),"ImageView")

	self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
	self.btnOk:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then

	    	FestivalNetTask:getInstance():requestFirstCharge(self.menuVo.festival_id,self.menuVo.act_id,self.rewardVo.id)
	    end
	end)

	require "ItemIcon"
	local baseX = 53  
	local baseY = 47
	for i=1,#rewardVo.rewardList do
		local v = rewardVo.rewardList[i]
		local icon = ItemIcon:create()
		icon:setScale(0.7)
		icon:setBaseId(v.base_id)
		icon:getClickImg():setTag( v.base_id )
		icon:setTouchEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                
                ItemInfoPanel:show(pSender:getTag())
            elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then
                ItemInfoPanel:hide()
            end
        end)
		icon:setItemNum(v.num)
		icon:setPosition(ccp( baseX + (i-1) * 75,baseY ))
		self._widget:addChild(icon)

		if v.focus == 1 then
	        local arm = AnimateManager:getInstance():getArmature(armPath, "guizhongwuping") 
	        arm:getAnimation():play("Animation1",-1,-1,1)
	        arm:setTag(5514)
	        icon:addNode(arm)
    	end
	end
end

function FestivalFirstchargeItem:update()

	self:setBtnEffect(false)
	if self.menuVo.rewardInfos.is_charge == 2 then 

		self.btnOk:setTouchEnabled(false)
		self.btnOk:setVisible(false)
		self.imgHasGet:setVisible(true)
	elseif self.menuVo.rewardInfos.is_charge == 1 then

		self:setBtnEffect(true)
	end
end

function FestivalFirstchargeItem:setBtnEffect(is_visible)
    if is_visible then
        if self.btn_effect == nil then
            self.btn_effect = AnimateManager:getInstance():getArmature(btn_effect_path,"UI_jianglilingqu") 
        	self.btn_effect:setScale(1.2)
        	self.btn_effect:setPosition(ccp(-8,5))
        	self.btnOk:addNode(self.btn_effect)
        	self.btn_effect:getAnimation():playWithIndex(0)
        end
    else
        if self.btn_effect then
            self.btn_effect:getAnimation():stop()
            self.btn_effect:removeFromParentAndCleanup(true)
            self.btn_effect = nil
        end
    end
end
-------------------------------------------------------------------
-- 附魔 条目
FestivalEnchantItem = class("FestivalEnchantItem", function() 
    return Layout:create()
end)
FestivalEnchantItem.__index = FestivalEnchantItem
FestivalEnchantItem._widget = nil

function FestivalEnchantItem:create(rewardVo,menuVo)
    local ret = FestivalEnchantItem.new()
    ret:init(rewardVo,menuVo)
    return ret
end

function FestivalEnchantItem:init(rewardVo,menuVo)

	self.menuVo = menuVo
	self.rewardVo = rewardVo
	self._widget = FestivalDataProxy:getInstance():getWidgetLoginItem():clone()
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	local tipTxt = self.rewardVo.title

	self.labTitle = CCLabelTTF:create(tipTxt,"",22)
	self.labTitle:setAnchorPoint(ccp(0,0.5))
	self.labTitle:setPosition(ccp(20,114))
	self.labTitle:setColor(ccc3(0xFE,0xE1,0x6B))

	self._widget:addNode( Utils.createStrokeLabel(self.labTitle,1,ccc3(55,25,25)) )
	
	self.imgHasGet = tolua.cast(self._widget:getChildByName("img_hasget"),"ImageView")

	self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
	self.btnOk:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then

	    	FestivalNetTask:getInstance():requestEnchantReward(self.menuVo.festival_id,self.menuVo.act_id,rewardVo.enchant_lev,self.rewardVo.id)
	    end
	end)

	require "ItemIcon"
	local baseX = 53  
	local baseY = 47
	for i=1,#rewardVo.rewardList do
		local v = rewardVo.rewardList[i]
		local icon = ItemIcon:create()
		icon:setScale(0.7)
		icon:setBaseId(v.base_id)
		icon:getClickImg():setTag( v.base_id )
		icon:setTouchEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                
                ItemInfoPanel:show(pSender:getTag())
            elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then
                ItemInfoPanel:hide()
            end
        end)
		icon:setItemNum(v.num)
		icon:setPosition(ccp( baseX + (i-1) * 75,baseY ))
		self._widget:addChild(icon)

		if v.focus == 1 then
	        local arm = AnimateManager:getInstance():getArmature(armPath, "guizhongwuping") 
	        arm:getAnimation():play("Animation1",-1,-1,1)
	        arm:setTag(5514)
	        icon:addNode(arm)
    	end
	end
end

function FestivalEnchantItem:update()

	self:setBtnEffect(false)
	for _,v in ipairs(self.menuVo.rewardInfos["enchant"]) do
		if v.lev == self.rewardVo.enchant_lev and v.num > 0 then
			self:setBtnEffect(true,v.num)
			break
		end
	end
end

function FestivalEnchantItem:setBtnEffect(is_visible,num)
    if is_visible then
        if self.btn_effect == nil then
            self.btn_effect = AnimateManager:getInstance():getArmature(btn_effect_path,"UI_jianglilingqu") 
        	self.btn_effect:setScale(1.2)
        	self.btn_effect:setPosition(ccp(-8,5))
        	self.btnOk:addNode(self.btn_effect)
        	self.btn_effect:getAnimation():playWithIndex(0)
        end
        if self.img_circle == nil then
            self.img_circle = ImageView:create()
            self.img_circle:loadTexture("reward_circle.png", UI_TEX_TYPE_PLIST)
            self.img_circle:setPosition(ccp(360,65))
        	self._widget:addChild(self.img_circle,2)
        end
        if self.lab_num == nil then
            self.lab_num = Label:create()
            self.lab_num:setColor(ItemHelper.colors.white)
			self.lab_num:setFontSize(22)
			self.lab_num:setText(num)
            self.lab_num:setPosition(ccp(360,65))
        	self._widget:addChild(self.lab_num,3)
        end
    else
        if self.btn_effect then
            self.btn_effect:getAnimation():stop()
            self.btn_effect:removeFromParentAndCleanup(true)
            self.btn_effect = nil
        end
        if self.img_circle then
            self.img_circle:removeFromParentAndCleanup(true)
            self.img_circle = nil
        end
        if self.lab_num then 
        	self.lab_num:removeFromParentAndCleanup(true)
            self.lab_num = nil
        end
    end
end

-------------------------------------------------------------------
-- 兑换 条目
FestivalExchangeItem = class("FestivalExchangeItem", function() 
    return Layout:create()
end)
FestivalExchangeItem.__index = FestivalExchangeItem
FestivalExchangeItem._widget = nil

function FestivalExchangeItem:create(rewardVo,menuVo)
    local ret = FestivalExchangeItem.new()
    ret:init(rewardVo,menuVo)
    return ret
end

function FestivalExchangeItem:init(rewardVo,menuVo)

	self.menuVo = menuVo
	self.rewardVo = rewardVo
	self._widget = FestivalDataProxy:getInstance():getWidgetExchangeItem():clone()
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	local tipTxt = self.rewardVo.title

	self.labTitle = CCLabelTTF:create(tipTxt,"",22)
	self.labTitle:setAnchorPoint(ccp(0,0.5))
	self.labTitle:setPosition(ccp(20,114))
	self.labTitle:setColor(ccc3(0xFE,0xE1,0x6B))

	self._widget:addNode( Utils.createStrokeLabel(self.labTitle,1,ccc3(55,25,25)) )
	
	self.imgHasGet = tolua.cast(self._widget:getChildByName("img_hasget"),"ImageView")

	self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
	self.btnOk:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then

	    	if self.isEnought == false then
	    		local costVo = self.rewardVo.cost[1]
	    		local mode = ItemManager:getInstance():getItemModelByBaseId(costVo.base_id)
	    		Alert:show(string.format("您的%s不足%d個",mode.name,costVo.num))
	    		return
	    	end

	    	FestivalNetTask:getInstance():requestExchangeReward(self.menuVo.festival_id,self.menuVo.act_id,self.rewardVo.id)
	    end
	end)

	require "ItemIcon"
	local baseX = 190  
	local baseY = 66
	
	for i=1,#rewardVo.rewardList do
		local v = rewardVo.rewardList[i]
		local icon = ItemIcon:create()
		icon:setScale(0.7)
		icon:setBaseId(v.base_id)
		icon:getClickImg():setTag( v.base_id )
		icon:setTouchEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                
                ItemInfoPanel:show(pSender:getTag())
            elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then
                ItemInfoPanel:hide()
            end
        end)
		icon:setItemNum(v.num)
		icon:setPosition(ccp( baseX + (i-1) * 75,baseY ))
		self._widget:addChild(icon)

		if v.focus == 1 then
	        local arm = AnimateManager:getInstance():getArmature(armPath, "guizhongwuping") 
	        arm:getAnimation():play("Animation1",-1,-1,1)
	        arm:setTag(5514)
	        icon:addNode(arm)
    	end

	end
----------------------------------------------------------
	local baseX = 52  
	local baseY = 66
	self.icon_list = {}
	for i=1,#rewardVo.cost do
		local v = rewardVo.cost[i]
		local icon = ItemIcon:create()
		icon:setScale(0.7)
		icon:setBaseId(v.base_id)
		icon:getClickImg():setTag( v.base_id )
		icon:setTouchEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                
                ItemInfoPanel:show(pSender:getTag())
            elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then
                ItemInfoPanel:hide()
            end
        end)
		icon:setItemNum(v.num)
		icon:setPosition(ccp( baseX + (i-1) * 75,baseY ))
		self._widget:addChild(icon)
		table.insert(self.icon_list,icon)

		if v.focus == 1 then
	        local arm = AnimateManager:getInstance():getArmature(armPath, "guizhongwuping") 
	        arm:getAnimation():play("Animation1",-1,-1,1)
	        arm:setTag(5514)
	        icon:addNode(arm)
    	end
	end
end

function FestivalExchangeItem:update()

	local isVis = self.rewardVo.exchange_num > self.menuVo.rewardInfos.exchange_num
	
	self.btnOk:setTouchEnabled(isVis)
	self.btnOk:setVisible(isVis)
	self.imgHasGet:setVisible(not isVis)

	if ItemManager:getInstance():getQuantityByBaseId(self.rewardVo.cost[1].base_id) >= self.rewardVo.cost[1].num then
		self:setBtnEffect(true)
	else
		self:setBtnEffect(false)
	end

	local costVo = self.rewardVo.cost[1]
	local icon = self.icon_list[1]
	icon.numTxt:setText(string.format("%d/%d",ItemManager:getInstance():getQuantityByBaseId(costVo.base_id),costVo.num))

	self.isEnought = ItemManager:getInstance():getQuantityByBaseId(costVo.base_id) >= costVo.num
end

function FestivalExchangeItem:setBtnEffect(is_visible)
    if is_visible then
        if self.btn_effect == nil then
            self.btn_effect = AnimateManager:getInstance():getArmature(btn_effect_path,"UI_jianglilingqu") 
        	self.btn_effect:setScale(1.2)
        	self.btn_effect:setPosition(ccp(-8,5))
        	self.btnOk:addNode(self.btn_effect)
        	self.btn_effect:getAnimation():playWithIndex(0)
        end
    else
        if self.btn_effect then
            self.btn_effect:getAnimation():stop()
            self.btn_effect:removeFromParentAndCleanup(true)
            self.btn_effect = nil
        end
    end
end

-------------------------------------------------------------------
-- 体力奖励 条目
FestivalPhysicalItem = class("FestivalPhysicalItem", function() 
    return Layout:create()
end)
FestivalPhysicalItem.__index = FestivalPhysicalItem
FestivalPhysicalItem._widget = nil

function FestivalPhysicalItem:create(rewardVo,menuVo)
    local ret = FestivalPhysicalItem.new()
    ret:init(rewardVo,menuVo)
    return ret
end

function FestivalPhysicalItem:init(rewardVo,menuVo)

	self.menuVo = menuVo
	self.rewardVo = rewardVo
	self._widget = FestivalDataProxy:getInstance():getWidgetArenaItem():clone()
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	self._widget:getChildByName("Label_791"):setVisible(self.rewardVo.widgetLabel)

	local tipTxt = self.rewardVo.title

	self.labTitle = CCLabelTTF:create(tipTxt,"",22)
	self.labTitle:setAnchorPoint(ccp(0,0.5))
	self.labTitle:setPosition(ccp(20,114))
	self.labTitle:setColor(ccc3(0xFE,0xE1,0x6B))

	self._widget:addNode( Utils.createStrokeLabel(self.labTitle,1,ccc3(55,25,25)) )
	
	require "ItemIcon"
	local baseX = 53  
	local baseY = 47
	for i=1,#rewardVo.rewardList do
		local v = rewardVo.rewardList[i]
		local icon = ItemIcon:create()
		icon:setScale(0.7)
		icon:setBaseId(v.base_id)
		icon:getClickImg():setTag( v.base_id )
		icon:setTouchEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                
                ItemInfoPanel:show(pSender:getTag())
            elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then
                ItemInfoPanel:hide()
            end
        end)
		icon:setItemNum(v.num)
		icon:setPosition(ccp( baseX + (i-1) * 75,baseY ))
		self._widget:addChild(icon)

		if v.focus == 1 then
	        local arm = AnimateManager:getInstance():getArmature(armPath, "guizhongwuping") 
	        arm:getAnimation():play("Animation1",-1,-1,1)
	        arm:setTag(5514)
	        icon:addNode(arm)
    	end
	end
end

function FestivalPhysicalItem:update()


end

-------------------------------------------------------------------
-- 累计消费 条目
FestivalRecostItem = class("FestivalRecostItem", function() 
    return Layout:create()
end)
FestivalRecostItem.__index = FestivalRecostItem
FestivalRecostItem._widget = nil

function FestivalRecostItem:create(rewardVo,menuVo)
    local ret = FestivalRecostItem.new()
    ret:init(rewardVo,menuVo)
    return ret
end

function FestivalRecostItem:init(rewardVo,menuVo)

	self.menuVo = menuVo
	self.rewardVo = rewardVo
	self._widget = FestivalDataProxy:getInstance():getWidgetLoginItem():clone()
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	local tipTxt = self.rewardVo.title

	self.labTitle = CCLabelTTF:create(tipTxt,"",22)
	self.labTitle:setAnchorPoint(ccp(0,0.5))
	self.labTitle:setPosition(ccp(20,114))
	self.labTitle:setColor(ccc3(0xFE,0xE1,0x6B))
	self._widget:addNode( Utils.createStrokeLabel(self.labTitle,1,ccc3(55,25,25)) )

	self.imgHasGet = tolua.cast(self._widget:getChildByName("img_hasget"),"ImageView")

	self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
	self.btnOk:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then

	    	FestivalNetTask:getInstance():requestRecostReward(self.menuVo.festival_id,self.menuVo.act_id,rewardVo.cost,rewardVo.id)
	    end
	end)

	require "ItemIcon"
	local baseX = 53  
	local baseY = 47
	for i=1,#rewardVo.rewardList do
		local v = rewardVo.rewardList[i]
		local icon = ItemIcon:create()
		icon:setScale(0.7)
		icon:setBaseId(v.base_id)
		icon:getClickImg():setTag( v.base_id )
		icon:setTouchEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                
                ItemInfoPanel:show(pSender:getTag())
            elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then
                ItemInfoPanel:hide()
            end
        end)
		icon:setItemNum(v.num)
		icon:setPosition(ccp( baseX + (i-1) * 75,baseY ))
		self._widget:addChild(icon)

		if v.focus == 1 then
	        local arm = AnimateManager:getInstance():getArmature(armPath, "guizhongwuping") 
	        arm:getAnimation():play("Animation1",-1,-1,1)
	        arm:setTag(5514)
	        icon:addNode(arm)
    	end
	end
end

function FestivalRecostItem:update()
	local isGet = false
	for _,v in ipairs(self.menuVo.rewardInfos.total_cost_arr) do
		if v == self.rewardVo.cost then
			isGet = true
			break
		end
	end

	if isGet then
		self.btnOk:setTouchEnabled(false)
		self.btnOk:setVisible(false)
		self.imgHasGet:setVisible(true)
		self:setBtnEffect(false)
	else
		if self.menuVo.rewardInfos.total_cost >= self.rewardVo.cost then
			self:setBtnEffect(true)
		end
	end
end

function FestivalRecostItem:setBtnEffect(is_visible)
    if is_visible then
        if self.btn_effect == nil then
            self.btn_effect = AnimateManager:getInstance():getArmature(btn_effect_path,"UI_jianglilingqu") 
        	self.btn_effect:setScale(1.2)
        	self.btn_effect:setPosition(ccp(-8,5))
        	self.btnOk:addNode(self.btn_effect)
        	self.btn_effect:getAnimation():playWithIndex(0)
        end
    else
        if self.btn_effect then
            self.btn_effect:getAnimation():stop()
            self.btn_effect:removeFromParentAndCleanup(true)
            self.btn_effect = nil
        end
    end
end

-------------------------------------------------------------------
-- 循环充值 条目
FestivalCircRechargeItem = class("FestivalCircRechargeItem", function() 
    return Layout:create()
end)
FestivalCircRechargeItem.__index = FestivalCircRechargeItem
FestivalCircRechargeItem._widget = nil

function FestivalCircRechargeItem:create(rewardVo,menuVo)
    local ret = FestivalCircRechargeItem.new()
    ret:init(rewardVo,menuVo)
    return ret
end

function FestivalCircRechargeItem:init(rewardVo,menuVo)

	self.menuVo = menuVo
	self.rewardVo = rewardVo
	self._widget = FestivalDataProxy:getInstance():getWidgetLoginItem():clone()
	self:addChild(self._widget)
	self:setSize(self._widget:getSize())

	local tipTxt = self.rewardVo.title

	self.labTitle = CCLabelTTF:create(tipTxt,"",22)
	self.labTitle:setAnchorPoint(ccp(0,0.5))
	self.labTitle:setPosition(ccp(20,114))
	self.labTitle:setColor(ccc3(0xFE,0xE1,0x6B))
	self._widget:addNode( Utils.createStrokeLabel(self.labTitle,1,ccc3(55,25,25)) )

	self.imgHasGet = tolua.cast(self._widget:getChildByName("img_hasget"),"ImageView")

	self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
	self.btnOk:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then

	    	FestivalNetTask:getInstance():requestCircRecharge(self.menuVo.festival_id,self.menuVo.act_id,rewardVo.id)
	    end
	end)

	require "ItemIcon"
	local baseX = 53  
	local baseY = 47
	for i=1,#rewardVo.rewardList do
		local v = rewardVo.rewardList[i]
		local icon = ItemIcon:create()
		icon:setScale(0.7)
		icon:setBaseId(v.base_id)
		icon:getClickImg():setTag( v.base_id )
		icon:setTouchEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                
                ItemInfoPanel:show(pSender:getTag())
            elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then
                ItemInfoPanel:hide()
            end
        end)
		icon:setItemNum(v.num)
		icon:setPosition(ccp( baseX + (i-1) * 75,baseY ))
		self._widget:addChild(icon)

		if v.focus == 1 then
	        local arm = AnimateManager:getInstance():getArmature(armPath, "guizhongwuping") 
	        arm:getAnimation():play("Animation1",-1,-1,1)
	        arm:setTag(5514)
	        icon:addNode(arm)
    	end
	end
end

function FestivalCircRechargeItem:update()

	local ret = self.menuVo.rewardInfos.circle_charge >= self.rewardVo.charge
	local num = math.floor(self.menuVo.rewardInfos.circle_charge / self.rewardVo.charge )
	self:setBtnEffect(ret,num)
end

function FestivalCircRechargeItem:setBtnEffect(is_visible,num)
     if is_visible then
        if self.btn_effect == nil then
            self.btn_effect = AnimateManager:getInstance():getArmature(btn_effect_path,"UI_jianglilingqu") 
        	self.btn_effect:setScale(1.2)
        	self.btn_effect:setPosition(ccp(-8,5))
        	self.btnOk:addNode(self.btn_effect)
        	self.btn_effect:getAnimation():playWithIndex(0)
        end
        if self.img_circle == nil then
            self.img_circle = ImageView:create()
            self.img_circle:loadTexture("reward_circle.png", UI_TEX_TYPE_PLIST)
            self.img_circle:setPosition(ccp(360,65))
        	self._widget:addChild(self.img_circle,2)
        end
        if self.lab_num == nil then
            self.lab_num = Label:create()
            self.lab_num:setColor(ItemHelper.colors.white)
			self.lab_num:setFontSize(22)
			self.lab_num:setText(num)
            self.lab_num:setPosition(ccp(360,65))
        	self._widget:addChild(self.lab_num,3)
        else
        	self.lab_num:setText(num)
        end
    else
        if self.btn_effect then
            self.btn_effect:getAnimation():stop()
            self.btn_effect:removeFromParentAndCleanup(true)
            self.btn_effect = nil
        end
        if self.img_circle then
            self.img_circle:removeFromParentAndCleanup(true)
            self.img_circle = nil
        end
        if self.lab_num then 
        	self.lab_num:removeFromParentAndCleanup(true)
            self.lab_num = nil
        end
    end
end
