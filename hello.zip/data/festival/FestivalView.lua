-- 节日活动
FestivalView = class("FestivalView",WindowBase)
FestivalView.__index = FestivalView
FestivalView._widget = nil
FestivalView.uiLayer = nil

local __instance = nil

function FestivalView:create()
    local ret = FestivalView.new()
    __instance = ret
    return ret   
end

function FestivalView:getInstance()
    return __instance
end

function FestivalView:init()

    require "FestivalCfg"
    require "FestivalNetTask"
    require "FestivalRenderMgr"
    require "FestivalDataProxy"
    require "FestivalCommView"
    require "FestivalCommItem"
    require "FestivalLocalReader"

	--加载纹理
    ComResMgr:getInstance():loadOtherRes()
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/reward/activity.plist")

    self._widget = GUIReader:shareReader():widgetFromJsonFile("festival/FestivalView.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.listMenu = tolua.cast(self._widget:getChildByName("list_menu"),"ListView")
    self.labTitle = tolua.cast(self._widget:getChildByName("lab_title"),"Label")

    self.panelView = tolua.cast(self._widget:getChildByName("panel_view"),"Layout")

    self.btnClose = self.uiLayer:getWidgetByName("btn_close")
    self.btnClose:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():close(self.name)
        end
    end)

    local rm = FestivalRenderMgr:getInstance()
    rm:setViewContainer(self.panelView,self.listMenu)
end

function FestivalView:open()

	self.cur_festival_id = self.params["festival_id"]
    self:update(true)

    Notifier.regist(FestivalEvent.UPDATE_SCENE,function() self:update() end)    
end

function FestivalView:update(isForceRefresh)

    self.listMenu:removeAllItems()

    local dp = FestivalDataProxy:getInstance()
    local rm = FestivalRenderMgr:getInstance()

    local sortList = dp:getViewSortList(self.cur_festival_id)
    for i,v in ipairs(sortList) do
        local id = sortList[i].idx

        if dp:isValidFestival(id) then
            rm:pushMenu(id)
        else
            rm:delMenu(id)
        end
    end

    rm:checkShowView(isForceRefresh)

    dp:isShowNewsTips() --检查绿点情况
	dp:isShowFestivalIcon() --检查图标情况
end

function FestivalView:updateView(viewVo)

    self.labTitle:setText( viewVo.title )

end

function FestivalView:close()

    local rm = FestivalRenderMgr:getInstance()
    rm:clearMenu()

    FestivalDataProxy:getInstance().curShowViewKey = nil

    Notifier.removeByName(FestivalEvent.UPDATE_SCENE)
end