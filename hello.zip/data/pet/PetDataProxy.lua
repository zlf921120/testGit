--宠物 数据代理
PetDataProxy = class("PetDataProxy")
PetDataProxy.upgradeCostVoList = {}
PetDataProxy.levupCostVoList = {}
PetDataProxy.pet_act_list = {}
PetDataProxy.curPetVo = nil
PetDataProxy.isAutoLevup = 0 --是否正在自动升级喂养
PetDataProxy.isAutoUpgrade = 0 --是否正在自动进阶状态

local __instance = nil
local _allowInstance = false

function PetDataProxy:ctor()
    if not _allowInstance then
		error("PetDataProxy is a singleton class")
	end
	self:init()
end

function PetDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = PetDataProxy.new()
		_allowInstance = false
	end

	return __instance
end

function PetDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function PetDataProxy:init()
	require "PetVo"
	require "PetCfg"
end
--------------------当前侍宠----------------------------
function PetDataProxy:getCurPetVo()
	if self.curPetVo == nil then
		self.curPetVo = PetVo.new()
	end
	return self.curPetVo
end
-----------------升阶----------------------------------
function PetDataProxy:createUpgradeCostVo()
	return PetUpgradeCostVo.new()
end

function PetDataProxy:setUpgradeCostVo(vo)
	self.upgradeCostVoList[ vo.star ] = vo
end

function PetDataProxy:getUpgradeCostVoById( id )
	return self.upgradeCostVoList[ id ]
end
------------------升级---------------------------------
function PetDataProxy:createLevupCostVo()
	return PetLevupCostVo.new()
end

function PetDataProxy:setLevupCostVo(vo)
	self.levupCostVoList[ vo.lev ] = vo
end

function PetDataProxy:getLevupCostVoById( id )
	return self.levupCostVoList[ id ]
end
---------------------刷新数据----------------------------------
function PetDataProxy:makeRefreshPet(svr_pet)
	if svr_pet then
		if svr_pet.is_active == 0 then --未激活
			self:getCurPetVo().lev = 0 --当前等级 
			self:getCurPetVo().star = 0 --当前阶数
			self:getCurPetVo().curLevSche = 0 --当前等级 进度
			self:getCurPetVo().curStarSche = 0 --当前升阶 进度
			self:getCurPetVo().isAutoLevup = 0
			self:getCurPetVo().isAutoUpgrade = 0
			self:getCurPetVo().isActivate = 0
			self:getCurPetVo().name = "侍寵精靈"
		else
			self:getCurPetVo().lev = svr_pet.lev --当前等级 
			self:getCurPetVo().star = svr_pet.star --当前阶数
			self:getCurPetVo().curLevSche = svr_pet.exp --当前等级 进度
			self:getCurPetVo().curStarSche = svr_pet.lucky --当前升阶 进度
			self:getCurPetVo().isAutoLevup = svr_pet.auto_feed
			self:getCurPetVo().isAutoUpgrade = svr_pet.auto_upgrade
			self:getCurPetVo().isActivate = svr_pet.is_active
			if svr_pet.sprite_name == "" then
				self:getCurPetVo().name = "侍寵精靈"
			else
				self:getCurPetVo().name = svr_pet.sprite_name
			end
		end
	end
end

function PetDataProxy:initPet()
	self:getCurPetVo().lev = 1 --当前等级 
	self:getCurPetVo().star = 1 --当前阶数
	self:getCurPetVo().curLevSche = 0 --当前等级 进度
	self:getCurPetVo().curStarSche = 0 --当前升阶 进度
	self:getCurPetVo().isAutoLevup = 0
	self:getCurPetVo().isAutoUpgrade = 0
	self:getCurPetVo().isActivate = 1
	self:getCurPetVo().name = "侍寵精靈"
end
---------------------侍宠动作--------------------------------
function PetDataProxy:getPetActionList(star)
	return self.pet_act_list[ star ]
end
---------------------------------------------------------------
function PetDataProxy:getCurPetRes()
	local petVo = self:getCurPetVo()
	local costUpgradeVo = self:getUpgradeCostVoById(petVo.star)
    local actionVo = EffectManager:getInstance():getActionData(costUpgradeVo.action_id)
    return actionVo._fileFullPathName,actionVo:getFileName()
end

--获取侍宠 当前 进阶+升级 总加成
-- 默认 返回  { hp = 0, act = 0, def=0 }
function PetDataProxy:getAttrAddition(star,lev)
	local ret = { hp = 0, act = 0, def=0 }

	local petVo = self:getCurPetVo()
	local targetStar = petVo.star
	local targetLev = petVo.lev

	if star ~= nil then
		targetStar = star
	end
	if lev ~= nil then
		targetLev = lev
	end

	local levupVo = self:getLevupCostVoById( targetLev ) 
	local upgradeVo = self:getUpgradeCostVoById( targetStar ) 

	if levupVo then
		ret.hp = (levupVo.hp + upgradeVo.hp) * (upgradeVo.growup / 100)
		ret.act = (levupVo.act + upgradeVo.act) * (upgradeVo.growup / 100)
		ret.def = (levupVo.def + upgradeVo.def) * (upgradeVo.growup / 100)
	end
	return ret 
end

--获取技能 的战斗力 总加成
function PetDataProxy:getSkillFcAddition()
	local fc = 0
	local tm = TeamManager:getInstance()
	for k,team_skill_vo in pairs(tm:getSkillDataDict()) do
		if team_skill_vo.level > 0 then
			local tmp_local_skill_info = tm:getConfigSkillData(team_skill_vo.id, team_skill_vo.level)
			if tmp_local_skill_info then
				fc = fc + tmp_local_skill_info.team_fc_add		
			end
		end
	end
	return fc
end

--获取当前侍宠 新激活 技能名
function PetDataProxy:getCurActivateSkillName()

	local curPetVo = self:getCurPetVo()
	local tm = TeamManager:getInstance()
	local skillIdList = tm:getConfigSkillIdList()
	local skillName = nil
	for k1,skillId in pairs(skillIdList) do
		local v = tm:getConfigSkillData(skillId,1)
		if v.petLevel <= curPetVo.lev and tm:getTeamSkillData(v.id) == nil then
			skillName = v.name
			break
		end
	end
	return skillName
end

--获取当前侍宠 能升级的技能
function PetDataProxy:getCurUpgradeSkillId()
	local ret = {}
	local curPetVo = self:getCurPetVo()
	local tm = TeamManager:getInstance()
	local skillList = tm:getSkillDataDict()
	--检测已激活的技能
	for id,v in pairs(skillList) do
		local cfgList = tm:getConfigSkillList(id)
		local nextCfgSkill = tm:getConfigSkillData(id,v.level + 1)
		if v.level < #cfgList and nextCfgSkill.petLevel <= curPetVo.lev then --还没学完
			table.insert(ret , v.id)
		end
	end
	--检测未激活的技能
	local skillIdList = tm:getConfigSkillIdList()
	for k1,skillId in pairs(skillIdList) do
		local v = tm:getConfigSkillData(skillId,1)
		if v.petLevel <= curPetVo.lev and tm:getTeamSkillData(v.id) == nil then
			table.insert(ret , v.id)
		end
	end
	return ret
end

--当前侍宠是否激活
function PetDataProxy:isCurPetActivate()
	return self:getCurPetVo().isActivate
end
-- -------------------技能描述信息----------------------------
-- function PetDataProxy:getConfigSkillList(id)
-- 	return self._teamSkillConfigDict[id]
-- end
-- --[[
--     获取配置战队技能数据
--     @param id 技能ID
--     @param level 技能等级
--     @return TeamSkillVO
-- ]]
-- function PetDataProxy:getConfigSkillData(id, level)

-- 	local list = self._teamSkillConfigDict[id]
-- 	if not list then
-- 		return nil
-- 	end
-- 	return list[level]
-- end

-- --[[
--     获取技能ID列表
-- ]]
-- function PetDataProxy:getConfigSkillIdList()
-- 	return self._teamSkillIdConfigList
-- end
-- --[[
--     获取所有助阵的数据列表
-- ]]
-- function PetDataProxy:getAllAssistHeroList()
-- 	return self._allAssistHeroList
-- end