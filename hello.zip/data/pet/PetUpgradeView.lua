--宠物 升阶 面板
PetUpgradeView = class("PetUpgradeView",WindowBase)
PetUpgradeView._widget = nil
PetUpgradeView.uiLayer = nil
PetUpgradeView.is_dispose = true

function PetUpgradeView:create()
    local ret = PetUpgradeView.new()
    return ret   
end

function PetUpgradeView:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
    Notifier.removeByName(PetEvent.Show_Upgrade_Anim)
    -- Notifier.removeByName(PetEvent.Update_Pet_Star)
end

function PetUpgradeView:init()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("pet/PetUpgrade.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then
		    self:addCloseAnim()
		end
    end)

    self.labGrowupBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_growup_before"),"Label")
    self.labActBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_act_before"),"Label")
    self.labDefBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_def_before"),"Label")
    self.labHpBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_hp_before"),"Label")
    self.labStarBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_star_before"),"Label")

    self.labGrowupAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_growup_after"),"Label")
    self.labActAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_act_after"),"Label")
    self.labDefAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_def_after"),"Label")
    self.labHpAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_hp_after"),"Label")
    self.labStarAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_star_after"),"Label")
    self.labCoin = tolua.cast(self.uiLayer:getWidgetByName("lab_coin"),"Label")
    self.labPercCost = tolua.cast(self.uiLayer:getWidgetByName("lab_perc_cost"),"Label")
    self.progCost = tolua.cast(self.uiLayer:getWidgetByName("prog_cost"),"LoadingBar")
    self.labTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips"),"Label")
    self.labLeft = tolua.cast(self.uiLayer:getWidgetByName("lab_left"),"Label")
    self.labCostTip = tolua.cast(self.uiLayer:getWidgetByName("Label_5961"),"Label")

    self.panelLeft = tolua.cast(self.uiLayer:getWidgetByName("panel_left"),"Layout")
    self.panelRight = tolua.cast(self.uiLayer:getWidgetByName("panel_right"),"Layout")
    self.panelCost = tolua.cast(self.uiLayer:getWidgetByName("panel_cost"),"Layout")
    self.panelCostItem = tolua.cast(self.uiLayer:getWidgetByName("panel_cost_item"),"Layout")

    require "ItemIcon"
    require "ItemInfoPanel"
    self.itemIcon = ItemIcon:create()
    self.itemIcon:setPosition(ccp(43,65))
    self.itemIcon:setScale(0.9)
    self.itemIcon:setTouchEvent(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.began then
                ItemInfoPanel:show(pSender:getTag())

        elseif eventType == ComConstTab.TouchEventType.ended or
                eventType == ComConstTab.TouchEventType.canceled then

            ItemInfoPanel:hide()
        end
    end)
    self.panelCostItem:addChild(self.itemIcon)

    local dp = PetDataProxy:getInstance()

    self.btnAutoUpgrade = tolua.cast(self.uiLayer:getWidgetByName("btn_auto_upgrade"),"Button")
    self.btnAutoUpgrade:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then
			WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()

                local costVo = dp:getUpgradeCostVoById( dp:getCurPetVo().star + 1 )
                PetNetTask:getInstance():requestPetUpgrade(PetUpgradeType.Auto,costVo.base_id)
            end, txt = PetCfg.UpgradeTips})
		end
    end)

	self.btnUpgrade = tolua.cast(self.uiLayer:getWidgetByName("btn_upgrade"),"Button")
	self.btnUpgrade:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then

			local costVo = dp:getUpgradeCostVoById( dp:getCurPetVo().star + 1 )
            PetNetTask:getInstance():requestPetUpgrade(PetUpgradeType.Confirm,costVo.base_id)
		end
    end)

    self.btnAdd = tolua.cast(self.uiLayer:getWidgetByName("btn_add"),"Button")
    self.btnAdd:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then

            self.btnAdd:setBright(false)
            self.btnAdd:setTouchEnabled(false)

			local costVo = dp:getUpgradeCostVoById( dp:getCurPetVo().star + 1 )
            PetNetTask:getInstance():requestPetUpgrade(PetUpgradeType.Normal,costVo.base_id)
		end
    end)

    self.btnFind = tolua.cast(self.uiLayer:getWidgetByName("btn_find"),"Button")
    self.btnFind:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            local param = {}
            param.res_baseid = self.costAfterVo.base_id
            param.find_type = ItemHelper.find_type.pet_res
            param.eqm_type = ItemHelper.itemType.Normal
            WindowCtrl:getInstance():open(CmdName.FindEqmView,param)
        end
    end)

    self._update_btn = function()
        self:update_btn()
    end

    self._update = function()
        self:update()
    end

    self._update_star = function(params)
        if params.type == PetUpgradeType.Normal then
            self:playAnimFeed(params.param.cirType)
            self:update()
        elseif params.type == PetUpgradeType.Confirm then
            self:update()
            WindowCtrl:getInstance():close(self.name)
        elseif params.type == PetUpgradeType.Auto then
            PetRenderMgr:getInstance():playProgressAnim(self._widget,params.param,
                function() self:update() end)
        end
    end

end

function PetUpgradeView:update_btn()
    self.btnAdd:setBright(true)
    self.btnAdd:setTouchEnabled(true)
end

--侍宠喂养特效
function PetUpgradeView:playAnimFeed(cirType)

    if self.armFeed then
        self._widget:removeNode(self.armFeed)
        self.armFeed = nil
    end
    if self.armFeedX2 then
        self._widget:removeNode(self.armFeedX2)
        self.armFeedX2 = nil
    end
    if self.armFeedX4 then
        self._widget:removeNode(self.armFeedX4)
        self.armFeedX4 = nil
    end
    if self.armSuccess then
        self._widget:removeNode(self.armSuccess)
        self.armSuccess = nil
    end
    
---------------------------------------------------------------------------------
    local dp = PetDataProxy:getInstance()
    local petVo = dp:getCurPetVo()
    local costAfterVo = dp:getUpgradeCostVoById( petVo.star + 1 )
    if (costAfterVo and petVo.curStarSche >= costAfterVo.lucky) 
        or costAfterVo == nil then --进度已满

        self.armSuccess_path = "ui/effects_ui/jinjiechenggong/jinjiechenggong.ExportJson"
        self.armSuccess = AnimateManager:getInstance():getArmature(self.armSuccess_path,"jinjiechenggong")
        self.armSuccess:getAnimation():play("Animation1",-1,-1,0)
        self.armSuccess:setPosition(ccp(480,252))
        self._widget:addNode(self.armSuccess,10)

    else
        if cirType == 1 then --2倍暴击
            self.armFeedX2_path = "ui/effects_ui/baojiX2/baojiX2.ExportJson"
            self.armFeedX2 = AnimateManager:getInstance():getArmature(self.armFeedX2_path,"baojiX2")
            self.armFeedX2:getAnimation():play("Animation1",-1,-1,0)
            self.armFeedX2:setPosition(ccp(480,252 + 40))
            self._widget:addNode(self.armFeedX2,10)

        elseif cirType == 2 then --4倍暴击
            self.armFeedX4_path = "ui/effects_ui/dabaojiX4/dabaojiX4.ExportJson"
            self.armFeedX4 = AnimateManager:getInstance():getArmature(self.armFeedX4_path,"dabaojiX4")
            self.armFeedX4:getAnimation():play("Animation1",-1,-1,0)
            self.armFeedX4:setPosition(ccp(480,252 + 40))
            self._widget:addNode(self.armFeedX4,10)

        else
            self.armFeed_path = "ui/effects_ui/shichongweiyang/shichongweiyang.ExportJson"
            self.armFeed = AnimateManager:getInstance():getArmature(self.armFeed_path,"shichongweiyang")
            self.armFeed:getAnimation():play("Animation1",-1,-1,0)
            self.armFeed:setPosition(ccp(480,252))
            self._widget:addNode(self.armFeed,10)
        end
    end

end

--侍宠 进度满 特效
function PetUpgradeView:playAnimUpgradeFull()

    if self.armUpgradeFull then
        self._widget:removeNode(self.armUpgradeFull)
        self.armUpgradeFull = nil
    end
    

    self.armUpgradeFull_path = "ui/effects_ui/jinjiemanzhi/jinjiemanzhi.ExportJson"
    self.armUpgradeFull = AnimateManager:getInstance():getArmature(self.armUpgradeFull_path,"jinjiemanzhi")
    self.armUpgradeFull:getAnimation():play("Animation1",-1,-1,1)
    self.armUpgradeFull:setScaleX(1.21)
    self.armUpgradeFull:setScaleY(1.05)
    self.armUpgradeFull:setPosition(ccp(480,252))
    self._widget:addNode(self.armUpgradeFull,2)
end

--侍宠 变身按钮 特效
function PetUpgradeView:playAnimBtnUpgrade()
    if self.armUpgrade then
        self._widget:removeNode(self.armUpgrade)
        self.armUpgrade = nil 
    end

    self.armUpgrade_path = "ui/effects_ui/shichongbianshen/shichongbianshen.ExportJson"
    self.armUpgrade = AnimateManager:getInstance():getArmature(self.armUpgrade_path,"shichongbianshen")
    self.armUpgrade:getAnimation():play("Animation1",-1,-1,1)
    self.armUpgrade:setPosition(ccp(481,75))
    self._widget:addNode(self.armUpgrade,10)
end


function PetUpgradeView:update()

    local dp = PetDataProxy:getInstance()
    local petVo = dp:getCurPetVo() 

    local addition = dp:getAttrAddition()
    local levupVo = dp:getLevupCostVoById( petVo.lev ) 
    local costBeforeVo = dp:getUpgradeCostVoById( petVo.star )
    local costAfterVo = dp:getUpgradeCostVoById( petVo.star + 1 )
    self.costAfterVo = costAfterVo

    self.labGrowupBefore:setText( costBeforeVo.growup .. "%")
    self.labActBefore:setText( "+".. math.floor(addition.act - levupVo.act) )
    self.labDefBefore:setText( "+".. math.floor(addition.def - levupVo.def) )
    self.labHpBefore:setText( "+".. math.floor(addition.hp - levupVo.hp) )
    self.labActBefore:setColor( ItemHelper:getColorByQuality( costBeforeVo.color) )
    self.labDefBefore:setColor( ItemHelper:getColorByQuality( costBeforeVo.color) )
    self.labHpBefore:setColor( ItemHelper:getColorByQuality( costBeforeVo.color) )
    self.labStarBefore:setText( "第"..petVo.star.."階" )

    self.btnAdd:setBright(true)
    self.btnAdd:setVisible(true)
    self.btnAdd:setTouchEnabled(true)
    self.btnAutoUpgrade:setBright(true)
    self.btnAutoUpgrade:setVisible(true)
    self.btnAutoUpgrade:setTouchEnabled(true)
    self.btnUpgrade:setVisible(false)
    self.btnUpgrade:setTouchEnabled(false)
    self.panelCost:setVisible(false)
    self.panelCostItem:setVisible(true)

    if costAfterVo then
        local additionNext = dp:getAttrAddition(petVo.star + 1, petVo.lev)
        self.labGrowupAfter:setText( costAfterVo.growup .. "%")
        self.labActAfter:setText( "+".. math.floor(additionNext.act - levupVo.act) )
        self.labDefAfter:setText( "+".. math.floor(additionNext.def - levupVo.def) )
        self.labHpAfter:setText( "+".. math.floor(additionNext.hp - levupVo.hp) )
        self.labActAfter:setColor( ItemHelper:getColorByQuality( costAfterVo.color) )
        self.labDefAfter:setColor( ItemHelper:getColorByQuality( costAfterVo.color) )
        self.labHpAfter:setColor( ItemHelper:getColorByQuality( costAfterVo.color) )
        self.labStarAfter:setText( "第"..(petVo.star + 1).."階" )

        self.labPercCost:setText( string.format("%d/%d",petVo.curStarSche,costAfterVo.lucky) )
        self.progCost:setPercent( petVo.curStarSche / costAfterVo.lucky * 100 )
        self.labCoin:setText( costAfterVo.coin )
        
        local isVis = petVo.curStarSche ~= costAfterVo.lucky
        self.btnAutoUpgrade:setBright(isVis)
        self.btnAutoUpgrade:setTouchEnabled(isVis)

        if petVo.curStarSche >= costAfterVo.lucky then --进度已满
            self.btnAdd:setVisible(false)
            self.btnAdd:setTouchEnabled(false)
            self.btnAutoUpgrade:setVisible(false)
            self.btnAutoUpgrade:setTouchEnabled(false)
            self.btnUpgrade:setVisible(true)
            self.btnUpgrade:setTouchEnabled(true)
            self.panelCostItem:setVisible(false)
            self.panelCost:setVisible(true)

            self:playAnimUpgradeFull()
            self:playAnimBtnUpgrade()
        end

        self.itemIcon:setBaseId(costAfterVo.base_id)
        self.itemIcon:getClickImg():setTag(costAfterVo.base_id)
        local num = ItemManager:getInstance():getQuantityByBaseId(costAfterVo.base_id)
        self.itemIcon:setItemNum(num)
        self.labLeft:setText("(剩餘"..num..")")
        self.labCostTip:setText(string.format("進階每次消耗%d個",costAfterVo.step_num))
    else --满阶了
        self.panelLeft:setPositionX(392)
        self.panelRight:setVisible(false)
        self.btnAdd:setBright(false)
        self.btnAdd:setTouchEnabled(false)
        self.btnUpgrade:setBright(false)
        self.btnUpgrade:setTouchEnabled(false)
        self.btnAutoUpgrade:setBright(false)
        self.btnAutoUpgrade:setTouchEnabled(false)
        self.btnFind:setTouchEnabled(false)

        self.labPercCost:setText(string.format("%d/%d",costBeforeVo.lucky,costBeforeVo.lucky) )
        self.progCost:setPercent( 100 )
        self.labTips:setVisible(true)
        self.panelCost:setVisible(false)
        self.panelCostItem:setVisible(false)
    end
end

function PetUpgradeView:open()
	self:addOpenAnim()
    self:update()

    Notifier.regist(PetEvent.Update_items,self._update)
    Notifier.regist(PetEvent.Update_Pet_Star,self._update_star)
    Notifier.regist(PetEvent.Update_Pet_Star_Btn,self._update_btn)
end

function PetUpgradeView:close()
    if self.armUpgrade then
        self._widget:removeNode(self.armUpgrade)
        self.armUpgrade = nil
    end
    if self.armUpgradeFull then
        self._widget:removeNode(self.armUpgradeFull)
        self.armUpgradeFull = nil
    end
    if self.armFeed then
        self._widget:removeNode(self.armFeed)
        self.armFeed = nil
    end
    if self.armFeedX2 then
        self._widget:removeNode(self.armFeedX2)
        self.armFeedX2 = nil
    end
    if self.armFeedX4 then
        self._widget:removeNode(self.armFeedX4)
        self.armFeedX4 = nil
    end
    if self.armSuccess then
        self._widget:removeNode(self.armSuccess)
        self.armSuccess = nil
    end
    if self.armUpgrade_path then
        AnimateManager:getInstance():clear(self.armUpgrade_path)
    end
    if self.armUpgradeFull_path then
        AnimateManager:getInstance():clear(self.armUpgradeFull_path)
    end
    if self.armFeed_path then
        AnimateManager:getInstance():clear(self.armFeed_path)
    end
    if self.armFeedX4_path then
        AnimateManager:getInstance():clear(self.armFeedX4_path)
    end
    if self.armFeedX2_path then
        AnimateManager:getInstance():clear(self.armFeedX2_path)
    end
    if self.armSuccess_path then
        AnimateManager:getInstance():clear(self.armSuccess_path)
    end

    Notifier.remove(PetEvent.Update_items,self._update)
    Notifier.remove(PetEvent.Update_Pet_Star_Btn,self._update_btn)
    Notifier.remove(PetEvent.Update_Pet_Star,self._update_star)
end