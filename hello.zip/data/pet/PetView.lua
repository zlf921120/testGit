--宠物 主面板
PetView = class("PetView",WindowBase)
PetView._widget = nil
PetView.uiLayer = nil

local _choiceId = 0
local __instance = nil
local _lastLeftPanel = nil
local cur_action_idx = 1

function PetView:create()
    local ret = PetView.new()
    __instance = ret
    return ret   
end

local function event_choice_skill(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then 
        if _choiceId == pSender:getTag() then return end

        --新手引导
        if GuideDataProxy:getInstance().nowMainTutroialEventId == 10705 then
            Notifier.dispatchCmd(GuideEvent.StepFinish,"click_spriteskill_11000")
        end

        __instance:changeLeftViewAnim(__instance.panelSkill)

        _choiceId = pSender:getTag()
        
        __instance:updateSkillPanel()
    end
end

function PetView:init()
	require "PetLocalReader"
	require "PetDataProxy"
	require "PetNetTask"
    require "PetRenderMgr"
    require "PetEvent"
    require "PetSkillIcon"

	--加载纹理
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/pet/pet.plist")
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/hero/hero.plist")
    ComResMgr:getInstance():loadOtherRes()
    
    self._widget = GUIReader:shareReader():widgetFromJsonFile("pet/PetView.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnUpgrade = tolua.cast(self.uiLayer:getWidgetByName("btn_upgrade"),"Button")
    self.btnUpgrade:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	        WindowCtrl:getInstance():open(CmdName.Pet_View_Upgrade)
	    end
    end)

    self.btnLevup = tolua.cast(self.uiLayer:getWidgetByName("btn_levup"),"Button")
    self.btnLevup:addTouchEventListener(function(pSender,eventType)
	    if eventType == ComConstTab.TouchEventType.ended then
	        WindowCtrl:getInstance():open(CmdName.Pet_View_Levup)
	    end
    end)

    self.labHp = tolua.cast(self.uiLayer:getWidgetByName("lab_hp"),"Label")
    self.labAct = tolua.cast(self.uiLayer:getWidgetByName("lab_act"),"Label")
    self.labDef = tolua.cast(self.uiLayer:getWidgetByName("lab_def"),"Label")

    self.labHpAdd = tolua.cast(self.uiLayer:getWidgetByName("lab_hp_add"),"Label")
    self.labActAdd = tolua.cast(self.uiLayer:getWidgetByName("lab_act_add"),"Label")
    self.labDefAdd = tolua.cast(self.uiLayer:getWidgetByName("lab_def_add"),"Label")

    self.panelMain = tolua.cast(self.uiLayer:getWidgetByName("panel_main"),"Layout")
    self.panelCard = tolua.cast(self.uiLayer:getWidgetByName("panel_card"),"Layout")
    self.panelSkill = tolua.cast(self.uiLayer:getWidgetByName("panel_skill"),"Layout")
    self.panelNextView = tolua.cast(self.uiLayer:getWidgetByName("panel_view"),"Layout")
    self.labSkilName = tolua.cast(self.uiLayer:getWidgetByName("lab_skill_name"),"Label")
    self.labSkillLev = tolua.cast(self.uiLayer:getWidgetByName("lab_lev"),"Label")
    self.labSkillDesc = tolua.cast(self.uiLayer:getWidgetByName("lab_desc"),"Label")
    self.labNextDesc = tolua.cast(self.uiLayer:getWidgetByName("lab_desc_next"),"Label")
    self.labTeamLev = tolua.cast(self.uiLayer:getWidgetByName("lab_team_lev"),"Label")
    self.labCost = tolua.cast(self.uiLayer:getWidgetByName("lab_cost"),"Label")
    self.labName = tolua.cast(self.uiLayer:getWidgetByName("lab_name"),"Label")

    self.panelClose = tolua.cast(self.uiLayer:getWidgetByName("panel_close"),"Layout")
    self.panelOpen = tolua.cast(self.uiLayer:getWidgetByName("panel_open"),"Layout")

    _lastLeftPanel = self.panelSkill

    self.btnShowCard = tolua.cast(self.uiLayer:getWidgetByName("btn_showcard"),"Button")
    self.btnShowCard:addTouchEventListener(function(pSender,eventType)
        _choiceId = 0

        self:changeLeftViewAnim(self.panelCard)
    end)

    self.btnLearn = tolua.cast(self.uiLayer:getWidgetByName("btn_learn"),"Button")
    self.btnLearn:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            if self.isPetLevEnough == false then
                Alert:show("侍寵等級不足")
                return
            end
            if self.isCoinEnough == false then
                Alert:show("金幣不足")
                return
            end
            TeamManager:getInstance():reqUpgradeTeamSkill(_choiceId)
        end
    end)

    self.btnEdit = tolua.cast(self.uiLayer:getWidgetByName("btn_editname"),"Button")
    self.btnEdit:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            WindowCtrl:getInstance():open(CmdName.Pet_View_EidtName)
        end
    end)

    self.btnActivate = tolua.cast(self.uiLayer:getWidgetByName("btn_activate"),"Button")
    self.btnActivate:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Elf, function()
                PetNetTask:getInstance():requestPetActivate()
            end)
        end
    end)

    self.imgPetBg = tolua.cast(self.uiLayer:getWidgetByName("ImageView_23"),"ImageView")
    self.imgPetBg:setTouchEnabled(true)
    self.imgPetBg:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            self.imgPetBg:setTouchEnabled(false)
            self:playAnim()
        end
    end)

    self.imgPetView = tolua.cast(self.uiLayer:getWidgetByName("img_pet"),"ImageView")

    self.scrollSkill = tolua.cast(self.uiLayer:getWidgetByName("scrol_skill"),"ScrollView")
    self.labPetLev = tolua.cast(self.uiLayer:getWidgetByName("lab_pet_lev"),"Label")

    self.labAtlasLev = LabelAtlas:create()
    self.labAtlasLev:setProperty(0,"ui/digit/bui_stone_3_num.png",32,40,"0")
    self.labAtlasLev:setPosition(ccp(67,72))
    self.panelCard:addChild(self.labAtlasLev)

    self.labAtlasFc = LabelAtlas:create()
    self.labAtlasFc:setAnchorPoint(ccp(0,0.5))
    self.labAtlasFc:setProperty(0,"ui/digit/fc_addition_num.png",24,34,"0")
    self.labAtlasFc:setPosition(ccp(15,460))
    self.panelOpen:addChild(self.labAtlasFc)

    self.labAtlasStar = LabelAtlas:create()
    self.labAtlasStar:setProperty(0,"ui/digit/buy_coin_num.png",28,49,"0")
    self.labAtlasStar:setPosition(ccp(324,434))
    self.panelCard:addChild(self.labAtlasStar)

    self.skillIcon = PetSkillIcon:create()
    self.skillIcon:setPosition(ccp(77,459))
    self.panelSkill:addChild(self.skillIcon)

    TeamManager:getInstance():parseTeamData()
    PetLocalReader:getInstance():loadInProxy()

    self.heroPanel = CCLayer:create()
    self.heroBottomPanel = CCLayer:create()
    self.heroPanel:setPosition(ccp(168,314))
    self.heroBottomPanel:setPosition(ccp(168,314))
    self.panelMain:addNode(self.heroPanel,10)
    self.panelMain:addNode(self.heroBottomPanel,10)

    Notifier.regist(PetEvent.Update_PetScene,function() self:update() end)
    Notifier.regist(CmdName.TEAM_UPGRADE_SKILL_RSP,function() self:update() end)
    Notifier.regist(PetEvent.Update_Pet_Lev,function() self:updateSkillPanel() end)
    Notifier.regist(PetEvent.Upgrade_Success,function(cirType) self:playAnimUpgrade(cirType) end)
    Notifier.regist(PetEvent.Activate_Success,function() 
        self:updateSkillPanel()
        self:playAnimActivate() 
        --新手引导
        if GuideDataProxy:getInstance().nowMainTutroialEventId == 10904 then
            Notifier.dispatchCmd(GuideEvent.StepFinish,"finish_spriteactivate")
        end
    end)
    Notifier.regist(CmdName.TEAM_UPGRADE_SKILL_RSP, function(skillId) 
        --新手引导
        if GuideDataProxy:getInstance().nowMainTutroialEventId == 10706 then
            Notifier.dispatchCmd(GuideEvent.StepFinish,"finish_spriteskill")
        end
        self:updateSkillPanel() 
        self:playSkillAnim(skillId)
    end)

    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function PetView:playAnim()

    local stard_act_list = PetDataProxy:getInstance():getPetActionList(self.action_id) 

    --英雄随即动作播放完成后
    local function playCallBack(armature, movementType, movementID)
        if movementType == AnimationMovementType.COMPLETE then 
            --播放一个动作后，移除关联特效
            if stard_act_list[cur_action_idx] and 
                stard_act_list[cur_action_idx][2] ~= nil then
                EffectManager:getInstance():removeEffect(self.heroPanel,stard_act_list[cur_action_idx][2], nil, 0)
            end

            if stard_act_list[cur_action_idx] and 
                stard_act_list[cur_action_idx][3] ~= nil and
                stard_act_list[cur_action_idx][3] >0 then
                    EffectManager:getInstance():removeEffect(self.heroBottomPanel,stard_act_list[cur_action_idx][3], nil, 0)
            end

            cur_action_idx = cur_action_idx +1
            if cur_action_idx>#stard_act_list then
                self.petArm:getAnimation():play("stand01")

                self.imgPetBg:setTouchEnabled(true)
            else
                self.petArm:getAnimation():play(stard_act_list[cur_action_idx][1],-1,-1,0)
                if stard_act_list[cur_action_idx][2] ~= nil then
                    EffectManager:getInstance():playEffect(self.heroPanel,stard_act_list[cur_action_idx][2], nil, 0)
                end

                if stard_act_list[cur_action_idx][3] ~= nil and stard_act_list[cur_action_idx][3]>0 then
                    EffectManager:getInstance():playEffect(self.heroBottomPanel,stard_act_list[cur_action_idx][3], nil, 0)
                end
            end
        end
    end

    cur_action_idx = 1

    self.petArm:getAnimation():setMovementEventCallFunc(playCallBack)
    self.petArm:getAnimation():play(stard_act_list[cur_action_idx][1],-1,-1,0)

    if stard_act_list[cur_action_idx][2] ~= nil then
        EffectManager:getInstance():playEffect(self.heroPanel,stard_act_list[cur_action_idx][2], nil, 0)
    end
end

function PetView:showStepAnim(param)
    if param.target == "sprite_skill_11000" then
        local btn = PetRenderMgr:getInstance():getSkillIcon(11000)
        GuideRenderMgr:getInstance():renderMainFlag(btn,param.id,param.target)
    elseif param.target == "sprite_btnlearn" then
        GuideRenderMgr:getInstance():renderMainFlag(self.btnLearn,param.id,param.target)
    elseif param.target == "sprite_btnactivate" then
        GuideRenderMgr:getInstance():renderMainFlag(self.btnActivate,param.id,param.target)
    elseif param.target == "sprite_btnlevup" then
        GuideRenderMgr:getInstance():renderMainFlag(self.btnLevup,param.id,param.target)
    end
end

--激活成功 动画
function PetView:playAnimActivate()
    
    if self.armActivate then
        self._widget:removeNode(self.armActivate)
        self.armActivate = nil 
    end

    self.armActivate_path = "ui/effects_ui/zhaohuanchenggong/zhaohuanchenggong.ExportJson"
    self.armActivate = AnimateManager:getInstance():getArmature(self.armActivate_path,"zhaohuanchenggong")
    self.armActivate:getAnimation():setMovementEventCallFunc(function(armature, movementType, movementID)
        if movementType == AnimationMovementType.COMPLETE then 
            self._widget:removeNode(self.armActivate)
            self.armActivate = nil 
        end
    end)
    self.armActivate:getAnimation():play("Animation1",-1,-1,0)
    self.armActivate:setPosition(ccp(534,373))
    self._widget:addNode(self.armActivate,30)
end

--精灵进阶
function PetView:playAnimUpgrade()

    if self.armUpgrade then
        self._widget:removeNode(self.armUpgrade)
        self.armUpgrade = nil
    end

    self.armUpgrade_path = "ui/effects_ui/jinglingjinjie/jinglingjinjie.ExportJson"
    self.armUpgrade = AnimateManager:getInstance():getArmature(self.armUpgrade_path,"jinglingjinjie")
    self.armUpgrade:getAnimation():play("Animation1",-1,-1,0)
    self.armUpgrade:setPosition(ccp(537,373))
    self._widget:addNode(self.armUpgrade,30)
end

function PetView:update()

    local dp = PetDataProxy:getInstance()
    local petVo = dp:getCurPetVo()

    local addition = dp:getAttrAddition()
    local levupVo = dp:getLevupCostVoById( petVo.lev ) 
    local upgradeVo = dp:getUpgradeCostVoById( petVo.star )

    self.labPetLev:setText(string.format("Lv.%d",petVo.lev))
    self.labName:setText(petVo.name)

    self.labHp:setText( levupVo.hp )
    self.labAct:setText( levupVo.act )
    self.labDef:setText( levupVo.def )

    if petVo.star > 1 then
        self.labHpAdd:setText( "+"..math.floor(addition.hp - levupVo.hp))
        self.labActAdd:setText( "+"..math.floor(addition.act - levupVo.act))
        self.labDefAdd:setText( "+"..math.floor(addition.def - levupVo.def))
        self.labHpAdd:setColor(ItemHelper:getColorByQuality( upgradeVo.color) )
        self.labActAdd:setColor(ItemHelper:getColorByQuality( upgradeVo.color) )
        self.labDefAdd:setColor(ItemHelper:getColorByQuality( upgradeVo.color) )
    else
        self.labHpAdd:setText("")
        self.labActAdd:setText("")
        self.labDefAdd:setText("")
    end

    self.labAtlasLev:setStringValue(petVo.lev)
    self.labAtlasStar:setStringValue(petVo.star)
    self.labAtlasFc:setStringValue(TeamManager:getInstance():getPetExtFc())

    if petVo.isActivate == 1 then
        self.panelOpen:setZOrder(4)
        self.panelOpen:setVisible(true)
        self.panelClose:setZOrder(2)
        self.panelClose:setVisible(false)
    else
        self.panelOpen:setZOrder(2)
        self.panelOpen:setVisible(false)
        self.panelClose:setZOrder(4)
        self.panelClose:setVisible(true)
    end

    local costUpgradeVo = dp:getUpgradeCostVoById(petVo.star)
    self.imgPetView:loadTexture(string.format("pet_card_%s.png",costUpgradeVo.pet_img),UI_TEX_TYPE_PLIST)

    self:updateArm()

    PetRenderMgr:getInstance():showLearnIconEffect()
end

function PetView:updateArm()

    local dp = PetDataProxy:getInstance()
    local petVo = dp:getCurPetVo()
    local costUpgradeVo = dp:getUpgradeCostVoById(petVo.star)
    local actionVo = EffectManager:getInstance():getActionData(costUpgradeVo.action_id)
    if self.action_id ~= costUpgradeVo.action_id then
        self.action_id = costUpgradeVo.action_id

        if self.petArm ~= nil then
            self.petArm:getAnimation():stop()
            self.petArm:getAnimation():setMovementEventCallFunc(function() end)
            self.heroPanel:removeChild(self.petArm,true)
            self.petArm = nil
            AnimateManager:getInstance():clear(self.petArmPath)
        end

        self.petArmPath = actionVo._fileFullPathName

        CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(actionVo._fileFullPathName)
        self.petArm = CCArmature:create(actionVo:getFileName())
        self.petArm:getAnimation():play("stand01")
        self.heroPanel:addChild(self.petArm,10)
    end
end

function PetView:changeLeftViewAnim(choicePanel)

    if _lastLeftPanel == choicePanel then return end
    _lastLeftPanel:setZOrder(1)
    _lastLeftPanel:setPositionY(1532)
    _lastLeftPanel:setVisible(false)

    choicePanel:setZOrder(4)
    choicePanel:setPosition(ccp(432,0))
    choicePanel:setVisible(true)

    _lastLeftPanel = choicePanel

    local arr = CCArray:create()
    arr:addObject(CCMoveTo:create(0.3,ccp(0,0)))
    choicePanel:stopAllActions()
    choicePanel:runAction(CCSequence:create(arr))
end

function PetView:updateSkillPanel()

    if _choiceId == 0 then return end

    local function checkPetLev(lab,checkLev) --检查战队等级
        local petLev = PetDataProxy:getInstance():getCurPetVo().lev
        local ret = petLev >= checkLev
        if ret then
            lab:setColor(ItemHelper.colors.yellow)
        else
            lab:setColor(ItemHelper.colors.red)
        end
        return ret
    end
    local function checkCostCoin(lab,checkCoin) --检查金币
        local coin = CharacterManager:getInstance():getAssetData():getGold()
        local ret = coin >= checkCoin
        if ret then
            lab:setColor(ItemHelper.colors.yellow)
        else
            lab:setColor(ItemHelper.colors.red)
        end
        return ret
    end

    self.skillIcon:setId(_choiceId)

    local tm = TeamManager:getInstance()
    local skillMeVo = tm:getTeamSkillData(_choiceId)

    self.panelNextView:setVisible(true)
    self.btnLearn:setTouchEnabled(true)
    self.btnLearn:setBright(true)
    self.isPetLevEnough = true
    self.isCoinEnough = true

    if skillMeVo ~= nil then --已学过

        local skillDescVo = tm:getConfigSkillData(skillMeVo.id,skillMeVo.level)
        local skillNextVo = tm:getConfigSkillData(skillMeVo.id,skillMeVo.level + 1)

        self.labSkilName:setText(skillDescVo.name)
        -- self.labSkillDesc:setText(Helper.insertnl(skillDescVo.desc,15))
        self.labSkillDesc:setText(skillDescVo.desc)
        self.labSkillLev:setText("Lv."..skillDescVo.level)
        --self.skillIcon:setLev(skillMeVo.level)

        if skillNextVo ~= nil then 

            -- self.labNextDesc:setText(Helper.insertnl(skillNextVo.desc,9))
            self.labNextDesc:setText(skillNextVo.desc)
            self.labCost:setText(skillNextVo.goldCost)
            self.isCoinEnough = checkCostCoin(self.labCost,skillNextVo.goldCost)
            self.labTeamLev:setText(skillNextVo.petLevel.."級")
            self.isPetLevEnough = checkPetLev(self.labTeamLev,skillNextVo.petLevel)
        else --最高了
            self.panelNextView:setVisible(false)
            self.btnLearn:setTouchEnabled(false)
            self.btnLearn:setBright(false)
            self.labNextDesc:setText("當前已是最高等級")
        end

        self.btnLearn:setTitleText("升級")
    else --未学过

        local skillDescVo = tm:getConfigSkillData(_choiceId,1)
        local skillNextVo = tm:getConfigSkillData(_choiceId,1)

        self.labSkilName:setText(skillDescVo.name)
        -- self.labSkillDesc:setText(Helper.insertnl(skillDescVo.desc,15))
        self.labSkillDesc:setText(skillDescVo.desc)
        self.labSkillLev:setText("未學習")
        --self.skillIcon:setLev(0)

        if skillNextVo ~= nil then 

            -- self.labNextDesc:setText(Helper.insertnl(skillNextVo.desc,9))
            self.labNextDesc:setText(skillNextVo.desc)
            self.labCost:setText(skillNextVo.goldCost)
            self.isCoinEnough = checkCostCoin(self.labCost,skillNextVo.goldCost)
            self.labTeamLev:setText(skillNextVo.petLevel.."級")
            self.isPetLevEnough = checkPetLev(self.labTeamLev,skillNextVo.petLevel)
        else --最高了
            self.panelNextView:setVisible(false)
            self.btnLearn:setTouchEnabled(false)
            self.btnLearn:setBright(false)
            self.labNextDesc:setText("當前已是最高等級")
        end

        self.btnLearn:setTitleText("學習")
    end
end
--播放升级完成特效
function PetView:playSkillAnim(skillId)

    local tm = TeamManager:getInstance()
    local skillMeVo = tm:getTeamSkillData(skillId)

    PetRenderMgr:getInstance():updateSkillItem(skillId,skillMeVo.level)

    self.skillIcon:showAnim()
end

function PetView:open()
    PetRenderMgr:getInstance():renderSkillList(self.scrollSkill,event_choice_skill)
    self:update()
    --新手引导
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10704 or
        GuideDataProxy:getInstance().nowMainTutroialEventId == 10903 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"open_spriteview")
    end

    self:changeLeftViewAnim(self.panelCard) --注！ 默认一定是侍宠卡牌

    if self.params then
        _choiceId = self.params["skill_id"]
        self:updateSkillPanel()
        self:changeLeftViewAnim(self.panelSkill)
    end
end

function PetView:close()

    if self.armActivate then
        self._widget:removeNode(self.armActivate)
        self.armActivate = nil
    end
    if self.armActivate_path then
        AnimateManager:getInstance():clear(self.armActivate_path)
    end

    if self.armUpgrade then
        self._widget:removeNode(self.armUpgrade)
        self.armUpgrade = nil
    end
    if self.armUpgrade_path then
        AnimateManager:getInstance():clear(self.armUpgrade_path)
    end

    _choiceId = 0
    _lastLeftPanel = self.panelSkill
end