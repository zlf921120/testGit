--宠物 网络助手
PetNetTask = class("PetNetTask")

local __instance = nil
local _allowInstance = false

function PetNetTask:ctor()
    if not _allowInstance then
		error("PetNetTask is a singleton class")
	end
	self:init()
end

function PetNetTask:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = PetNetTask.new()
		_allowInstance = false
	end

	return __instance
end

function PetNetTask:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function PetNetTask:init()
	require "PetDataProxy"
	require "team_pb"
	--注册网络事件
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.team_sprite_levup_rsp,"handlePetLevup()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.team_sprite_upgrade_rsp,"handlePetUpgrade()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.team_sprite_rename_rsp,"handlePetEditName()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.team_sprite_active_rsp,"handlePetActivate()")
end

--请求 升阶喂养
function PetNetTask:requestPetUpgrade(type,base_id)
	print("-----------requestPetUpgrade-------------",type,base_id)
	local team_sprite_upgrade_req = team_pb.team_sprite_upgrade_req()
	team_sprite_upgrade_req.upgrade_type = type
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.team_sprite_upgrade_req,team_sprite_upgrade_req)
end

--响应 升阶喂养
function handlePetUpgrade(pkg)
	local team_sprite_upgrade_rsp = team_pb.team_sprite_upgrade_rsp()
	team_sprite_upgrade_rsp:ParseFromString(pkg)

	Notifier.dispatchCmd(PetEvent.Update_Pet_Star_Btn)

	print("-----------handlePetUpgrade-------------",team_sprite_upgrade_rsp.ret)
	if team_sprite_upgrade_rsp.ret == error_code_pb.msg_ret.success then

		CharacterManager:getInstance():updateRoleAssets(team_sprite_upgrade_rsp.assets) --更新资产

		if team_sprite_upgrade_rsp.auto_upgrade ~= PetUpgradeType.Confirm then
    		ItemManager:getInstance():updateOrDelMultiItems(team_sprite_upgrade_rsp.items)--更新背包物品
    	else
    		Notifier.dispatchCmd(PetEvent.Upgrade_Success)
    		WindowCtrl:getInstance():close(CmdName.Pet_View_Upgrade)
    	end

    	local dp = PetDataProxy:getInstance()
    	local petVo = dp:getCurPetVo()
    	
    	print(" 暴擊值 ",team_sprite_upgrade_rsp.is_crit)

    	local param = {}
		param.oldValue = petVo.curStarSche
		param.oldLimit = petVo.star
		param.type = PetCfg.Upgrade
		param.cirType = team_sprite_upgrade_rsp.is_crit

    	petVo.star = team_sprite_upgrade_rsp.star
    	petVo.curStarSche = team_sprite_upgrade_rsp.lucky

    	Notifier.dispatchCmd(PetEvent.Update_Pet_Star,{ type = team_sprite_upgrade_rsp.auto_upgrade,param = param })
    	Notifier.dispatchCmd(PetEvent.Update_PetScene)

		ComSender:getInstance():dealExtInfo(team_sprite_upgrade_rsp.ext)
	elseif team_sprite_upgrade_rsp.ret == error_code_pb.msg_ret.err_lev_max then
		Alert:show("侍寵精靈的等級不能超過戰隊等級")
	else
		Alert:show(Helper.getErrStr(team_sprite_upgrade_rsp.ret))
	end
end

--请求 升级喂养
function PetNetTask:requestPetLevup(type,base_id)
	print("-----------requestPetLevup-------------",type,base_id)
	local team_sprite_levup_req = team_pb.team_sprite_levup_req()
	team_sprite_levup_req.item_id = base_id
	team_sprite_levup_req.auto_feed = type
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.team_sprite_levup_req,team_sprite_levup_req)
end

--响应 升级喂养
function handlePetLevup(pkg)
	
	local team_sprite_levup_rsp = team_pb.team_sprite_levup_rsp()
	team_sprite_levup_rsp:ParseFromString(pkg)

	Notifier.dispatchCmd(PetEvent.Update_Pet_Lev_Btn)

	print("-----------handlePetLevup-------------",team_sprite_levup_rsp.ret)
	if team_sprite_levup_rsp.ret == error_code_pb.msg_ret.success then
			
		CharacterManager:getInstance():updateRoleAssets(team_sprite_levup_rsp.assets) --更新资产
    	ItemManager:getInstance():updateOrDelMultiItems(team_sprite_levup_rsp.items)--更新背包物品

    	local dp = PetDataProxy:getInstance()
    	local petVo = dp:getCurPetVo()

    	local param = {}
		param.oldValue = petVo.curLevSche
		param.oldLimit = petVo.lev
		param.type = PetCfg.Levup

    	petVo.lev = team_sprite_levup_rsp.lev
    	petVo.curLevSche = team_sprite_levup_rsp.exp

		Notifier.dispatchCmd(PetEvent.Update_Pet_Lev,{ type = team_sprite_levup_rsp.auto_feed, param = param })
		Notifier.dispatchCmd(PetEvent.Update_PetScene)

		ComSender:getInstance():dealExtInfo(team_sprite_levup_rsp.ext)
	elseif team_sprite_levup_rsp.ret == error_code_pb.msg_ret.err_lev_max then
		Alert:show("侍寵精靈的等級不能超過戰隊等級")
	else
		Alert:show(Helper.getErrStr(team_sprite_levup_rsp.ret))
	end
end

--请求 激活侍宠
function PetNetTask:requestPetActivate()
	print("-----------requestPetActivate-------------")
	local team_sprite_active_req = team_pb.team_sprite_active_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.team_sprite_active_req,team_sprite_active_req)
end

--响应 激活侍宠
function handlePetActivate(pkg)
	local team_sprite_active_rsp = team_pb.team_sprite_active_rsp()
	team_sprite_active_rsp:ParseFromString(pkg)

	print("-----------handlePetActivate-------------",team_sprite_active_rsp.ret)
	if team_sprite_active_rsp.ret == error_code_pb.msg_ret.success then
		
		PetDataProxy:getInstance():initPet()
		Notifier.dispatchCmd(PetEvent.Update_PetScene)
		Notifier.dispatchCmd(PetEvent.Activate_Success)

		ComSender:getInstance():dealExtInfo(team_sprite_active_rsp.ext)
	else
		Alert:show(Helper.getErrStr(team_sprite_active_rsp.ret))
	end
end

--请求侍宠 修改名字
function PetNetTask:requestPetEditName(name)
	print("-----------requestPetEditName-------------",name)
	local team_sprite_rename_req = team_pb.team_sprite_rename_req()
	team_sprite_rename_req.sprite_name = name
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.team_sprite_rename_req,team_sprite_rename_req)
end

--响应侍宠 修改名字
function handlePetEditName(pkg)

	local team_sprite_rename_rsp = team_pb.team_sprite_rename_rsp()
	team_sprite_rename_rsp:ParseFromString(pkg)

	print("-----------handlePetEditName-------------",team_sprite_rename_rsp.ret)
	if team_sprite_rename_rsp.ret == error_code_pb.msg_ret.success then

		local dp = PetDataProxy:getInstance()
		local petVo = dp:getCurPetVo()
		petVo.name = team_sprite_rename_rsp.sprite_name
		
		Notifier.dispatchCmd(PetEvent.Update_PetScene)
		WindowCtrl:getInstance():close(CmdName.Pet_View_EidtName)

		ComSender:getInstance():dealExtInfo(team_sprite_rename_rsp.ext)
	else
		Alert:show(Helper.getErrStr(team_sprite_rename_rsp.ret))
	end
end