--宠物 升级 面板
PetLevupView = class("PetLevupView",WindowBase)
PetLevupView._widget = nil
PetLevupView.uiLayer = nil
-- PetLevupView.is_dispose = true --不能删除！ 因为新手引导

function PetLevupView:create()
    local ret = PetLevupView.new()
    return ret   
end

-- function PetLevupView:dispose()
--     if self._widget then
--         self._widget:removeFromParentAndCleanup(true)
--     end
--     Notifier.removeByName(PetEvent.Show_Upgrade_Anim)
--     Notifier.removeByName(PetEvent.Update_Pet_Lev)
-- end

function PetLevupView:init()
	
    self._widget = GUIReader:shareReader():widgetFromJsonFile("pet/PetLevup.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.labLevBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_lev_before"),"Label")
    self.labGrowupBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_growup_before"),"Label")
    self.labActBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_act_before"),"Label")
    self.labDefBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_def_before"),"Label")
    self.labHpBefore = tolua.cast(self.uiLayer:getWidgetByName("lab_hp_before"),"Label")
    
    self.labLevAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_lev_after"),"Label")
    self.labGrowupAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_growup_after"),"Label")
    self.labActAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_act_after"),"Label")
    self.labDefAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_def_after"),"Label")
    self.labHpAfter = tolua.cast(self.uiLayer:getWidgetByName("lab_hp_after"),"Label")
    self.labPercCost = tolua.cast(self.uiLayer:getWidgetByName("lab_perc_cost"),"Label")
    self.labCoin = tolua.cast(self.uiLayer:getWidgetByName("lab_coin"),"Label")
    self.progCost = tolua.cast(self.uiLayer:getWidgetByName("prog_cost"),"LoadingBar")
    self.labTips = tolua.cast(self.uiLayer:getWidgetByName("lab_tips"),"Label")
    self.labLeft = tolua.cast(self.uiLayer:getWidgetByName("lab_left"),"Label")
    self.labCostTip = tolua.cast(self.uiLayer:getWidgetByName("Label_5969"),"Label")

    self.panelLeft = tolua.cast(self.uiLayer:getWidgetByName("panel_left"),"Layout")
    self.panelRight = tolua.cast(self.uiLayer:getWidgetByName("panel_right"),"Layout")
    self.panelCost = tolua.cast(self.uiLayer:getWidgetByName("panel_cost"),"Layout")
    self.panelCostItem = tolua.cast(self.uiLayer:getWidgetByName("panel_cost_item"),"Layout")

    self.panelSkill = tolua.cast(self.uiLayer:getWidgetByName("panel_skill"),"Layout")

    self.labSkill = tolua.cast(self.uiLayer:getWidgetByName("lab_skill"),"Label")

    local dp = PetDataProxy:getInstance()

	self.btnClose = tolua.cast(self.uiLayer:getWidgetByName("btn_close"),"Button")
    self.btnClose:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then
		    self:addCloseAnim()
		end
    end)

    self.btnAdd = tolua.cast(self.uiLayer:getWidgetByName("btn_add"),"Button")
    self.btnAdd:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            self.btnAdd:setBright(false)
            self.btnAdd:setTouchEnabled(false)

            local costVo = dp:getLevupCostVoById( dp:getCurPetVo().lev + 1 )
            PetNetTask:getInstance():requestPetLevup(PetLevupType.Normal,costVo.base_id)
        end
    end)

    self.btnAuto = tolua.cast(self.uiLayer:getWidgetByName("btn_ok"),"Button")
    self.btnAuto:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()

                local costVo = dp:getLevupCostVoById( dp:getCurPetVo().lev + 1 )
                PetNetTask:getInstance():requestPetLevup(PetLevupType.Auto,costVo.base_id)

            end, txt = PetCfg.LevupTips})

        end
    end)

    self.btnFind = tolua.cast(self.uiLayer:getWidgetByName("btn_find"),"Button")
    self.btnFind:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then

            local param = {}
            param.res_baseid = self.costAfterVo.base_id
            param.find_type = ItemHelper.find_type.pet_res
            param.eqm_type = ItemHelper.itemType.Normal
            WindowCtrl:getInstance():open(CmdName.FindEqmView,param)
        end
    end)

    require "ItemIcon"
    require "ItemInfoPanel"
    self.itemIcon = ItemIcon:create()
    self.itemIcon:setPosition(ccp(49,62))
    self.itemIcon:setScale(0.9)
    self.itemIcon:setTouchEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                    ItemInfoPanel:show(pSender:getTag())

            elseif eventType == ComConstTab.TouchEventType.ended or
                    eventType == ComConstTab.TouchEventType.canceled then

                ItemInfoPanel:hide()
            end
        end)
    self.panelCostItem:addChild(self.itemIcon)

    Notifier.regist(PetEvent.Update_Pet_Lev,function(params)
        if params.type == PetLevupType.Normal then
            self:update()
            self:playAnimFeed()

            --新手引导
            if GuideDataProxy:getInstance().nowMainTutroialEventId == 10908 then
                Notifier.dispatchCmd(GuideEvent.StepFinish,"finish_spritefeedlevup")
            end

        elseif params.type == PetLevupType.Auto then
            PetRenderMgr:getInstance():playProgressAnim(self._widget,params.param,
                function() self:update() end,
                function(tmpLev) self:updateAnimByLev(tmpLev) end)
        end
    end)

    self._update = function()
        self:update()
    end

    self._update_btn = function()
        self:update_btn()
    end
    Notifier.regist(PetEvent.Update_Pet_Lev_Btn,self._update_btn)

    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function PetLevupView:update_btn()
    self.btnAdd:setBright(true)
    self.btnAdd:setTouchEnabled(true)
end

function PetLevupView:update()

    local dp = PetDataProxy:getInstance()
    local petVo = dp:getCurPetVo() 

    if self.lastLev == nil then
        self.lastLev = petVo.lev
    else
        if self.lastLev ~= petVo.lev then --升级了
            self.lastLev = petVo.lev

            self:playAnimLevup() 
        end
    end

    local costBeforeVo = dp:getLevupCostVoById( petVo.lev )
    local costAfterVo = dp:getLevupCostVoById( petVo.lev + 1 )
    self.costAfterVo = costAfterVo

    self.labLevBefore:setText("Lv.".. petVo.lev)
    self.labActBefore:setText( costBeforeVo.act )
    self.labDefBefore:setText( costBeforeVo.def )
    self.labHpBefore:setText( costBeforeVo.hp )

    self.btnAdd:setBright(true)
    self.btnAdd:setTouchEnabled(true)
    self.btnAuto:setBright(true)
    self.btnAuto:setTouchEnabled(true)
    self.panelCost:setVisible(false)
    self.panelSkill:setVisible(false)

    local activateSkillName = dp:getCurActivateSkillName()  --开启新技能
    if activateSkillName ~= nil then
        self.panelSkill:setVisible(true)
        self.labSkill:setText(activateSkillName)
    end

    if costAfterVo then
        self.labLevAfter:setText("Lv.".. (petVo.lev + 1)) 
        self.labActAfter:setText( costAfterVo.act )
        self.labDefAfter:setText( costAfterVo.def )
        self.labHpAfter:setText( costAfterVo.hp )

        self.labPercCost:setText(string.format("%d/%d",petVo.curLevSche,costAfterVo.expMax) )
        self.progCost:setPercent( petVo.curLevSche / costAfterVo.expMax * 100 )
        self.labCoin:setText( costAfterVo.coin )

        self.itemIcon:setBaseId(costAfterVo.base_id)
        self.itemIcon:getClickImg():setTag(costAfterVo.base_id)
        local num = ItemManager:getInstance():getQuantityByBaseId(costAfterVo.base_id)
        self.itemIcon:setItemNum(num)
        self.labLeft:setText("(剩餘"..num..")")
        self.labCostTip:setText(string.format("升級每次消耗%d個",costAfterVo.step_num))
    else --满了
        self.panelLeft:setPositionX(357)
        self.panelRight:setVisible(false)
        self.btnAdd:setBright(false)
        self.btnAdd:setTouchEnabled(false)
        self.btnAuto:setBright(false)
        self.btnAuto:setTouchEnabled(false)
        -- self.panelCost:setVisible(false)
        self.btnFind:setTouchEnabled(false)

        self.labPercCost:setText(string.format("%d/%d",costBeforeVo.expMax,costBeforeVo.expMax) )
        self.progCost:setPercent( 100 )
        self.labTips:setVisible(true)
    end
end

--侍宠升级特效
function PetLevupView:playAnimLevup()
    if self.armLevup then
        self._widget:removeNode(self.armLevup)
        self.armLevup = nil
    end

    self.armLevup_path = "ui/effects_ui/shichongshengji/shichongshengji.ExportJson"
    self.armLevup = AnimateManager:getInstance():getArmature(self.armLevup_path,"shichongshengji")
    self.armLevup:getAnimation():play("Animation1",-1,-1,0)
    self.armLevup:setPosition(ccp(459,310))
    self._widget:addNode(self.armLevup,10)
end

--侍宠喂养特效
function PetLevupView:playAnimFeed()
    if self.armFeed then
        self._widget:removeNode(self.armFeed)
        self.armFeed = nil
    end

    self.armFeed_path = "ui/effects_ui/shichongweiyang/shichongweiyang.ExportJson"
    self.armFeed = AnimateManager:getInstance():getArmature(self.armFeed_path,"shichongweiyang")
    self.armFeed:getAnimation():play("Animation1",-1,-1,0)
    self.armFeed:setPosition(ccp(459,310))
    self._widget:addNode(self.armFeed,10)
end

function PetLevupView:updateAnimByLev(lev)

    local dp = PetDataProxy:getInstance()
    local costBeforeVo = dp:getLevupCostVoById( lev )
    local costAfterVo = dp:getLevupCostVoById( lev )

    self.labLevBefore:setText("Lv.".. lev)
    self.labActBefore:setText( costBeforeVo.act )
    self.labDefBefore:setText( costBeforeVo.def )
    self.labHpBefore:setText( costBeforeVo.hp )

    self.btnAdd:setBright(false)
    self.btnAdd:setTouchEnabled(false)
    self.btnAuto:setBright(false)
    self.btnAuto:setTouchEnabled(false)

    if costAfterVo then
        self.labLevAfter:setText("Lv.".. (lev + 1)) 
        self.labActAfter:setText( costAfterVo.act )
        self.labDefAfter:setText( costAfterVo.def )
        self.labHpAfter:setText( costAfterVo.hp )

        self.labCoin:setText( costAfterVo.coin )
    else --满了
        self.panelLeft:setPositionX(357)
        self.panelRight:setVisible(false)
        
        self.labTips:setVisible(true)
    end
end

function PetLevupView:open()
	self:addOpenAnim()
    self:update()

    --新手引导
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10907 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"open_spritelevup")
    end

    Notifier.regist(PetEvent.Update_items,self._update)
end

--新手引导
function PetLevupView:showStepAnim(param)
    if param.target == "sprite_btnlevupfeed" then
        GuideRenderMgr:getInstance():renderMainFlag(self.btnAdd,param.id,param.target)
    end
end

function PetLevupView:close()
    if self.armFeed then
        self._widget:removeNode(self.armFeed)
        self.armFeed = nil
    end
    if self.armLevup then
        self._widget:removeNode(self.armLevup)
        self.armLevup = nil
    end
    if self.armLevup_path then
        AnimateManager:getInstance():clear(self.armLevup_path)
    end
    if self.armFeed_path then
        AnimateManager:getInstance():clear(self.armFeed_path)
    end
    Notifier.remove(PetEvent.Update_items,self._update)
    Notifier.remove(PetEvent.Update_Pet_Lev_Btn,self._update_btn)
end