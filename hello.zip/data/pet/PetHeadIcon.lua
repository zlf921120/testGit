--
-- Author: lvgansheng
-- Date: 2015-04-28 12:00:34
-- 侍宠精灵头像，角色信息面板时使用

PetHeadIcon = class("PetHeadIcon", DisplayUtil.newWidget)

PetHeadIcon.icon_img = nil

PetHeadIcon.face_id = 0

function PetHeadIcon:init(bg_type)

	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/pet/pet_head_icon.plist", "ui/pet/pet_head_icon.pvr.ccz")

	--图标背景框,根据精灵阶数改变颜色
	self.iconBg = ImageView:create()
	self.iconBg:setTouchEnabled(false)
	-- self.iconBg:loadTexture(bg_img_name,UI_TEX_TYPE_PLIST)
	self:addChild(self.iconBg)	
	
    self.icon_img = ImageView:create()
    self.icon_img:setTouchEnabled(false)
    self:addChild(self.icon_img)

 --    local icon_border = ImageView:create()
 --    icon_border:loadTexture("head_icon_border.png",UI_TEX_TYPE_PLIST)
	-- self:addChild(icon_border)	

	-- self:setSize(self.iconBg:getSize())
end

function PetHeadIcon:create()
	local icon = PetHeadIcon.new()
	icon:init()
	return icon
end

function PetHeadIcon:setPetStar(pet_star)

	if pet_star==nil or pet_star==0 then
		self:setVisible(false)
		return 
	else
		self:setVisible(true)
	end

	-- 特殊处理，大于5阶的用5阶资源
	if pet_star>5 then
		pet_star=5
	end

	self.pet_star = pet_star --暂时写死，等头像功能完善后去掉
	local bg_res_name = string.format("pet_head_bg_%d.png",pet_star)
	local icon_res_name = string.format("pet_head_%d.png",pet_star)

	if self.res_name == icon_res_name then
		return
	end

	self.res_name = icon_res_name

	self.iconBg:loadTexture(bg_res_name,UI_TEX_TYPE_PLIST)
	self.icon_img:loadTexture(icon_res_name,UI_TEX_TYPE_PLIST)
end

