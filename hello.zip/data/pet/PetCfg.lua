--宠物配置
PetCfg = {
	Levup = 1,  --升级 
	Upgrade = 2,--进阶
	LevupTips = "將自動使用背包中所有精靈升級道具，是否確定？",
	UpgradeTips = "將自動使用背包中所有精靈進階道具，是否確定？",
}

--进阶类型
PetUpgradeType = {
	Normal = 0,  --普通
	Auto = 1,    --自动
	Confirm = 2, --确认
}

--升级类型
PetLevupType = {
	Normal = 0,  --普通
	Auto = 1,    --自动
}