--消息框 
PetEditNamePanel = class("PetEditNamePanel",WindowBase)
PetEditNamePanel.__index = PetEditNamePanel
PetEditNamePanel._widget 	= nil
PetEditNamePanel.uiLayer = nil
PetEditNamePanel.is_dispose = true

local __instance = nil

function PetEditNamePanel:create(txt)
    local ret = PetEditNamePanel.new()
    __instance = ret
    return ret
end

function PetEditNamePanel:dispose()
	if self._widget then
        self._widget:removeFromParentAndCleanup(true)
        self._widget = nil
    end
end

local function checkName(txt)
    if Helper.lenEnCn(txt) > 12 then
        Alert:show("侍寵名稱超過了限制")
        return false
    end
	if string.len(txt) == 0 then
		Alert:show("名字不能為空")
		return false
	end
	if Helper.hasSensitiveWord(txt) then
 		Alert:show("名字含有非法字元")
 		return false
 	end
	return true
end

---------------初始化-----------------------------------------------------
function PetEditNamePanel:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/pet/PetEditNamePanel.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
	self:addChild(self.uiLayer)

    self.btnOk = tolua.cast(self.uiLayer:getWidgetByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(function(pSender,eventType)
    	if eventType == ComConstTab.TouchEventType.ended then 
    		if checkName( self.inputName:getText() ) then
    			PetNetTask:getInstance():requestPetEditName(self.inputName:getText())
    		end
    	end
    end)

    self.btnCancel = tolua.cast(self.uiLayer:getWidgetByName("btn_cancel"),"Button")
    self.btnCancel:addTouchEventListener(function(pSender,eventType)
    	if eventType == ComConstTab.TouchEventType.ended then 
    		WindowCtrl:getInstance():close(self.name)
    	end
    end)

    self.inputName = CCEditBox:create(CCSize(250,35),CCScale9Sprite:create("ui/login/resource/img/img_empty.png"))
    self.inputName:setMaxLength(12)
    self.inputName:setPosition(ccp(480 + 30,299))
    self.inputName:setPlaceHolder("請輸入侍寵名稱")
    self.inputName:setInputMode(kEditBoxInputModeSingleLine)
    self.inputName:setFontSize(24) 
    self._widget:addNode(self.inputName,10)

end

function PetEditNamePanel:extTouchPriority(value)
    self.inputName:setTouchPriority(value)
end

function PetEditNamePanel:open()

end