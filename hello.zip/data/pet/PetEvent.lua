--宠物事件
PetEvent = {
	Update_PetScene = "pet_Update_PetScene",
	Show_Levup_Anim = "pet_Show_Levup_Anim",
	Show_Upgrade_Anim = "pet_Show_Upgrade_Anim",
	Update_Pet_Lev = "pet_update_lev",
	Update_Pet_Lev_Btn = "pet_update_lev_btn",
	Update_Pet_Star_Btn = "pet_update_star_btn",
	Update_Pet_Star = "pet_update_star",
	Upgrade_Success = "pet_Upgrade_Success",
	Activate_Success = "pet_Activate_Success",
	Update_items = "pet_update_items",
}
