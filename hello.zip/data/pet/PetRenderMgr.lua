-- 宠物系统 渲染器
PetRenderMgr = class("PetRenderMgr")
PetRenderMgr.dic = nil

local __instance = nil
local _allowInstance = false

function PetRenderMgr:ctor()
    if not _allowInstance then
		error("PetRenderMgr is a singleton class")
	end
	self:init()
end

function PetRenderMgr:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = PetRenderMgr.new()
		_allowInstance = false
	end

	return __instance
end

function PetRenderMgr:destoryInstance()

	self.dic:release()
	_allowInstance = false
	__instance = nil
end

function PetRenderMgr:init()
	
	require "PetDataProxy"
	require "PetSkillIcon"

	self.dic = CCDictionary:create() --缓存
	self.dic:retain()
end

--渲染技能
function PetRenderMgr:renderSkillList(scroll,func)
	
	local function createPosArr(len)
		local col = 2
		local row = math.ceil(len / col)
		local ret = {}

		local baseX = 55
		local baseY = 45

		local idx = 0
		for i=0,row - 1 do

			for j=0,col - 1 do
				idx = idx + 1

				local height = 110
				local width = 110

				table.insert(ret, { x = baseX + j * width , y = baseY + (row - i - 1) * height })
			end
		end
		return ret
	end

	local tm = TeamManager:getInstance()
	local tmpList = tm:getConfigSkillIdList()

	-- local innerHeight = math.max( math.ceil(#tmpList / 2) * 110 , 420)
	-- scroll:setInnerContainerSize(CCSize(220,innerHeight))
	scroll:setInnerContainerSize(scroll:getSize())
	scroll:removeAllChildrenWithCleanup(true)

	local posArr = createPosArr(#tmpList)

	-- local arr = CCArray:create()
	for i=1,#tmpList do

		local key = string.format("skillitem_%d",tmpList[i])
 		local item = self.dic:objectForKey(key)
 		-- if item == nil then
			-- arr:addObject(CCDelayTime:create(0.1))
		-- end
		-- arr:addObject(CCCallFunc:create(function()
	 		-- local item = self.dic:objectForKey(key)
	 		local lev = 0
			if tm:getTeamSkillData(tmpList[i]) ~= nil then
				lev = tm:getTeamSkillData(tmpList[i]).level
			end
 			if item == nil then
				item = PetSkillIcon:create() 
				item:setScale(0.9)
				item:setId(tmpList[i])
				item:setPosition(ccp(posArr[i].x,posArr[i].y))
				item:setClickEvent(func)
				self.dic:setObject(item,key)
			end
			item:setLev(lev)
			scroll:addChild(item)
		-- end))
	end
	-- scroll:stopAllActions()
	-- scroll:runAction(CCSequence:create(arr))
end

--更新技能图标
function PetRenderMgr:updateSkillItem(skillId,lev)

	local key = string.format("skillitem_%d",skillId)
 	local item = self.dic:objectForKey(key)
 	if item then
 		item:setLev(lev)
 	end
 	self:showLearnIconEffect()
end

function PetRenderMgr:showLearnIconEffect()

	local dp = PetDataProxy:getInstance()
	local skillIdList = TeamManager:getInstance():getConfigSkillIdList()
	for k,id in pairs(skillIdList) do
		local icon = self:getSkillIcon(id)
		icon:hideLearnAnim()
	end
	local learnList = dp:getCurUpgradeSkillId()
    for k,id in pairs(learnList) do
        local icon = self:getSkillIcon(id)
        icon:showLearnAnim()
    end
end

function PetRenderMgr:getSkillIcon(skillId)
	return self.dic:objectForKey(string.format("skillitem_%d",skillId))
end

--渲染升阶 增加消耗物品/进度条 动画
function PetRenderMgr:playProgressAnim(container,params,func,funcShow)

	local progCost = tolua.cast(container:getChildByName("prog_cost"),"LoadingBar")
	local labPerc = tolua.cast(container:getChildByName("lab_perc_cost"),"Label")

	local dp = PetDataProxy:getInstance()
	local max = 0
	local costVo = nil
	local nowLimit = 0
	local nowSche = 0

	if params.type == PetCfg.Levup then --升级
		nowLimit = dp:getCurPetVo().lev
		costVo = dp:getLevupCostVoById( params.oldLimit + 1 )
		max = costVo.expMax
		if nowLimit > params.oldLimit then
			nowSche = max
		else
			nowSche = dp:getCurPetVo().curLevSche
		end
	elseif params.type == PetCfg.Upgrade then --进阶
		nowLimit = dp:getCurPetVo().star
		costVo = dp:getUpgradeCostVoById( params.oldLimit + 1 )
		max = costVo.lucky
		nowSche = dp:getCurPetVo().curStarSche
	end

	local arr = CCArray:create()

	local step = (nowSche - params.oldValue) / 5 -- 5等份动画
	for i=1,5 do
		arr:addObject(CCCallFunc:create(function()
			labPerc:setText(string.format("%d/%d", params.oldValue + i*step,max))
			progCost:setPercent( (params.oldValue + i*step) / max * 100)

		end))
		arr:addObject(CCDelayTime:create(0.15))
	end

	arr:addObject(CCCallFunc:create(func)) -- 刷新最新状态

	container:stopAllActions()
	container:runAction(CCSequence:create(arr))
end
