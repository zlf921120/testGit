
--当前宠物值(当前只有1只)
PetVo = class("PetVo")
PetVo.lev = 0 --当前等级 
PetVo.star = 0 --当前阶数
PetVo.curLevSche = 0 --当前等级 进度
PetVo.curStarSche = 0 --当前升阶 进度
PetVo.isActivate = 0 --是否已激活
PetVo.name = "侍寵精靈"

--升阶 消耗
PetUpgradeCostVo = class("PetUpgradeCostVo")
PetUpgradeCostVo.star = 0
PetUpgradeCostVo.coin = 0
PetUpgradeCostVo.base_id = 0
PetUpgradeCostVo.step_num = 0
PetUpgradeCostVo.growup = 0 --成长 加成比
PetUpgradeCostVo.lucky = 0 --暴击 幸运值
PetUpgradeCostVo.act = 0 --攻击增加
PetUpgradeCostVo.def = 0 --防御增加
PetUpgradeCostVo.hp = 0 --血增加
PetUpgradeCostVo.action_id = 0 --模型id
PetUpgradeCostVo.color = 0 --颜色

--升级 消耗
PetLevupCostVo = class("PetLevupCostVo")
PetLevupCostVo.lev = 0
PetLevupCostVo.coin = 0
PetLevupCostVo.expMax = 0
PetLevupCostVo.step_num = 0
PetLevupCostVo.base_id = 0
PetLevupCostVo.act = 0 --攻击增加
PetLevupCostVo.def = 0 --防御增加
PetLevupCostVo.hp = 0 --血增加

--侍宠技能
PetSkillVo = class("PetSkillVo")
PetSkillVo.id = 0
PetSkillVo.name = ""
PetSkillVo.desc = ""
PetSkillVo.short_desc = ""
PetSkillVo.lev = 0 
PetSkillVo.petLev = 0