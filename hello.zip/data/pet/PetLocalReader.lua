--宠物系统 本地文件读取
PetLocalReader = class("PetLocalReader")

local __instance = nil
local _allowInstance = false
local _hasLoad = false

function PetLocalReader:ctor()
    if not _allowInstance then
		error("PetLocalReader is a singleton class")
	end
	self:init()
end

function PetLocalReader:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = PetLocalReader.new()
		_allowInstance = false
	end

	return __instance
end

function PetLocalReader:init()
    require "fnt_pet_data_pb"
    require "PetCfg"
    require "PetDataProxy"
end

function PetLocalReader:loadInProxy()

    if _hasLoad then return end--只加载一次
    _hasLoad = true

    local dp = PetDataProxy:getInstance()
	
    local pbdata = FileUtils.readConfigFile("fnt_pet_data.dat")
    
    local msg = fnt_pet_data_pb.fnt_pet_data()
    msg:ParseFromString(pbdata)

---------------进阶-------------------------
    local upgradeArr = msg.upgrade_cost_rows
    for k,v in pairs(upgradeArr) do
        if v.star ~= nil then
            local costVo = dp:createUpgradeCostVo()
            costVo.star = v.star
            costVo.base_id = v.base_id
            costVo.step_num = v.num
            costVo.coin = v.coin
            costVo.act = v.act
            costVo.def = v.defense
            costVo.hp = v.hp
            costVo.lucky = v.lucky --上限
            costVo.growup = v.growup
            costVo.action_id = v.action_id
            costVo.pet_img = v.pet_img
            costVo.color = v.pet_color
            dp:setUpgradeCostVo(costVo)
        end
    end
---------------升级-------------------------
    local levupArr = msg.levup_cost_rows
    for k,v in pairs(levupArr) do
        if v.lev ~= nil then
            local costVo = dp:createLevupCostVo()
            costVo.lev = v.lev
            costVo.expMax = v.exp --上限
            costVo.base_id = v.base_id
            costVo.step_num = v.num
            costVo.coin = v.coin
            costVo.act = v.atk
            costVo.def = v.defense
            costVo.hp = v.hp
            dp:setLevupCostVo(costVo)
        end
    end
--------------侍宠动作-----------------------
    local pet_act_list_rows = msg.pet_act_list_rows
    local one_act_data = nil
    for i, v in pairs(pet_act_list_rows) do
        if v.action_id~=nil then 
             one_act_data = {}
             one_act_data = Helper.stringToTable("{"..v.act_list.."}")
             dp.pet_act_list[v.action_id] = one_act_data
        end
    end


end