require "GloryCfg"

--副本 介绍 面板
DungeonPerpare = class("DungeonPerpare",WindowBase)
DungeonPerpare.__index = DungeonPerpare
DungeonPerpare._widget    = nil
DungeonPerpare.uiLayer    = nil

local __instance = nil

function DungeonPerpare:create()
    local ret = DungeonPerpare.new()
    __instance = ret
    return ret   
end
-------------------------------------------------------------------
local function checkCanRaids(num)
    if __instance._currentDungeonData then

        if __instance._currentDungeonData._score >= 3 then
            -- print(" __instance._currentDungeonData._remainTimes ",__instance._currentDungeonData._remainTimes)
            if __instance._currentDungeonData._remainTimes >= num then
                return true
            else
                Alert:show("本關卡的剩餘戰鬥次數不足")
                return false
            end
        end
        Alert:show(string.format("本關卡需要三星通過才能進行掃蕩",__instance._currentDungeonData._id))
    end
    return false
end

local function reqRadis(num,sender)

    if checkCanRaids(num) == false then
        return
    end

    if not __instance._currentDungeonData then
        return
    end
    sender:setEnabled(false)
    print(" 開始掃蕩 ",os.clock())
    __instance._dm:reqRaids(__instance._currentDungeonData._id, __instance._currentDiff, num)

end

local function reqBuyDungeonNum()
    local num = __instance._dm:getScheduleDungeonDataBuyLimit(__instance._currentDungeonData._id, __instance._currentDiff)  --购买上限
    local hasBeenBuyNum = __instance._currentDungeonData._hasBeenBuyNum
    if num > hasBeenBuyNum then
        if __instance._currentDungeonData._remainTimes == 0 then

            WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()
                    __instance._dm:requestDungeonBuyBattleNum(__instance._currentDungeonData._id, __instance._currentDiff)
                end, txt = string.format("您要花費%d鑽石重置副本次數嗎",
                    __instance._dm:getBuyBattleCost(__instance._currentDungeonData._id, __instance._currentDiff))})
        end
    else
        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()
        --     require "VipNetTask"
        --      VipNetTask:getInstance():requestVipInfo()
        -- --发送充值请求
            WindowCtrl:getInstance():open(CmdName.Vip_View)
            
        end, txt = BuyAssetCfg.UpLevelVipTip,
        okBtnName = "查看"})
    end
end
-------------------------------------------------------------------
local function event_ten_radius(pSender,event)
	if event == TOUCH_EVENT_ENDED then
        VipDataProxy:getInstance():isCanOpen(VipPrivilegeType.DungeonDiff1Dadius,function()
            reqRadis(10,pSender)
        end)
	end
end

local function event_three_radius(pSender,event)
	if event == TOUCH_EVENT_ENDED then
        VipDataProxy:getInstance():isCanOpen(VipPrivilegeType.DungeonDiff2Dadius,function()
		    reqRadis(3,pSender)
        end)
	end
end

local function event_one_radius(pSender,event)
	if event == TOUCH_EVENT_ENDED then
		reqRadis(1,pSender)
	end
end

local function event_desc_view(pSender,event)
	if event == TOUCH_EVENT_ENDED then
        WindowCtrl:getInstance():open(CmdName.Comm_DescPanel,
           {title="寶藏副本",content=DungeonCfg.DescContent,
            rewardArr = {{img="diamond.png",lab="鑽石"},
                         {img="gold.png",lab="金幣"},
                         {img="reward_hero_exp.png",lab="經驗藥"}}})
	end
end

local function event_team_setting(pSender,event)
	if event == TOUCH_EVENT_ENDED then
		WindowCtrl:getInstance():close(CmdName.DungeonPerpare)
        WindowCtrl:getInstance():open(CmdName.Team_View,
            {id = __instance._currentDungeonData._id, subId = __instance._currentDiff , btnOkTitle = "挑戰"}
        )
	end
end

local function event_btn_add(pSender,event)
	if event == TOUCH_EVENT_ENDED then
		reqBuyDungeonNum(__instance._currentDungeonData._id,__instance._currentDiff)
	end
end

local function event_btn_start(pSender,event)
	if event == TOUCH_EVENT_ENDED then
		if table.maxn(TeamManager:getInstance():getBattleHeroList()) == 0 then
            WindowCtrl:getInstance():open(CmdName.Team_View, 
                {id = __instance._currentDungeonData._id, subId = __instance._currentDiff , btnOkTitle = "挑戰"}
            )
        else
            BattleManager:getInstance():reqBattleStart(
                __instance._currentDungeonData._id, 
                __instance._currentDiff,
                TeamType.Normal
            )
        end
        --预加载剧情
        require "GuideDungeon"
        GuideDungeon:getInstance()
	end
end

function DungeonPerpare:init()

    require "VipNetTask"
    
	self._widget = GUIReader:shareReader():widgetFromJsonFile("dungeon/DungeonDesc.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)
    
	self._tenTimesButton = tolua.cast(self._widget:getChildByName("btn_radius_ten"),"Button")
	self._threeTimesButton = tolua.cast(self._widget:getChildByName("btn_radius_three"),"Button")
    self._raidsButton = tolua.cast(self._widget:getChildByName("btn_radius"),"Button")
	self._descButton = tolua.cast(self._widget:getChildByName("btn_desc"),"Button")
	self._settingButton = tolua.cast(self._widget:getChildByName("btn_setting"),"Button")
	self._remainAddBtn = tolua.cast(self._widget:getChildByName("btn_add"),"Button")
	self._startButton = tolua.cast(self._widget:getChildByName("btn_start"),"Button")

	self._tenTimesButton:addTouchEventListener(event_ten_radius)
	self._threeTimesButton:addTouchEventListener(event_three_radius)
	self._raidsButton:addTouchEventListener(event_one_radius)
	self._descButton:addTouchEventListener(event_desc_view)
	self._settingButton:addTouchEventListener(event_team_setting)
	self._startButton:addTouchEventListener(event_btn_start)
	self._remainAddBtn:addTouchEventListener(event_btn_add)

	self._descLabel = tolua.cast(self._widget:getChildByName("lab_title"),"Label")
	self._remainTimesLabel = tolua.cast(self._widget:getChildByName("lab_battlecout"),"Label")
    self._fixRemainTimesLabel = tolua.cast(self._widget:getChildByName("lab_fixbattlecout"),"Label")
	self._physicalLabel = tolua.cast(self._widget:getChildByName("lab_phycost"),"Label")
    self._labWave = tolua.cast(self._widget:getChildByName("lab_wave"),"Label")

	Notifier.regist(CmdName.DUNGEON_UPDATE_DESC,function() self:update() end)
    Notifier.regist(CmdName.RSP_UPDATE_ROLE_ASSET,function() self:update() end)
	Notifier.regist(CmdName.DUNGEON_UPDATE_RAIDS, function(rewardData)
        self:onUpdateRaidsFunc(rewardData) 
        self:update()
    end)
    Notifier.regist(CmdName.DUNGEON_UPDATE_ONE_SCHEDULE,function() self:update() end)

    -- self:addCloseBtn()
    self:isShowBg(false)

    CombatDataStorage:getInstance():parseConfigData()
end

function DungeonPerpare:update(dungeonVo)

	if dungeonVo ~= nil then
		self._currentDungeonData = dungeonVo
	end
	self._dm = DungeonManager:getInstance()
	self._currentDiff = self._currentDungeonData._diff
	local rawData = self._currentDungeonData._rawData

	self._descLabel:setText("　　"..rawData._desc)
    self._remainTimesLabel:setText(string.format("%d/%d",self._currentDungeonData._remainTimes,self._currentDungeonData._rawData._maxTimes))
    self._physicalLabel:setText(self._currentDungeonData._rawData._physicalCost)
    self._labWave:setText(CombatDataStorage:getInstance():getCombatInitData(
        self._currentDungeonData._id,self._currentDiff).totalWave)

    local p_2 = ccp(245,125)
    for i=1,6 do
        local child = self._widget:getChildByTag(1500 + i)
        if child ~= nil then
            child:removeFromParentAndCleanup(true)
        end
    end
    require "ItemInfoPanel"
    for i, v in ipairs(rawData._rewardList) do
 
        local itemIcon = ItemIcon:create()
        self._widget:addChild(itemIcon)
        itemIcon:getClickImg():setTag(v)
        itemIcon:setTag(1500 + i)
        itemIcon:setTouchEvent(function(pSender,eventType)
            if eventType == ComConstTab.TouchEventType.began then
                    ItemInfoPanel:show(pSender:getTag())

            elseif eventType == ComConstTab.TouchEventType.ended or
                    eventType == ComConstTab.TouchEventType.canceled then

                ItemInfoPanel:hide()
            end
        end)
        itemIcon:setScale(0.8)
        itemIcon:setBaseId(v)
        itemIcon:setItemNum(1)
        itemIcon:setPosition(ccp( p_2.x + (i - 1) * 100, p_2.y))
    end

    -- local p_1 = self._widget:getChildByName("p_1")
    local p_1 = ccp(245,237)
    for i=1,6 do
        local child = self._widget:getChildByTag(1600 + i)
        if child ~= nil then
            child:removeFromParentAndCleanup(true)
        end
    end

    for i, v in ipairs(rawData._monsterList) do
        -- local monsterIcon = self._maybeMonsterIconList[i]
        -- if monsterIcon == nil then
        local monsterIcon = MonsterIcon:create()
           -- self._maybeMonsterIconList[i] = monsterIcon
            self._widget:addChild(monsterIcon)
        -- end
        monsterIcon.icon_img:setTag(v)
        monsterIcon:setTag(1600 + i)
        monsterIcon:setClickEvent(function(pSender,eventType)
             if eventType == ComConstTab.TouchEventType.began then

                    require "MonsterInfoPanel"
                    MonsterInfoPanel:show(pSender:getTag())

            elseif eventType == ComConstTab.TouchEventType.ended or
                    eventType == ComConstTab.TouchEventType.canceled then

                MonsterInfoPanel:hide()
            end
        end)

        local monsterVo = MonsterManager:getInstance():getBaseInfo(v)
        monsterIcon:setScale(0.8)
        monsterIcon:setAnchorPoint(ccp(0.5,0))
        local isBoss = monsterVo.monsterType == Helper.monsterType.BOSS or monsterVo.monsterType == Helper.monsterType.SUPER_BOSS
        monsterIcon:setIsBoss(isBoss)
        if isBoss then
            monsterIcon:setPosition(ccp( p_1.x - 14 + (i - 1) * 115, p_1.y + 10 - 3))
        else
            monsterIcon:setPosition(ccp( p_1.x + (i - 1) * 105, p_1.y - 3))
        end
        -- monsterIcon:setPosition(ccp( p_1:getPositionX() + ((i - 1) % 3) * 75, p_1:getPositionY() - math.floor((i-1)/3) * 75))
        monsterIcon:setMonsterId(v)
    end

    --判断是否宝藏副本 改变状态
    if rawData._type == DungeonEnumType.Treasure then --宝藏本
        self._tenTimesButton:setEnabled(false)
        self._tenTimesButton:setVisible(false)
        self._raidsButton:setEnabled(false)
        self._raidsButton:setVisible(false)
        self._threeTimesButton:setEnabled(false)
        self._threeTimesButton:setVisible(false)
        self._descButton:setEnabled(true)
        self._descButton:setVisible(true)
        self._remainAddBtn:setEnabled(false)
        self._remainAddBtn:setVisible(false)

    elseif rawData._type == DungeonEnumType.Normal then --普通本
        self._descButton:setEnabled(false)
        self._descButton:setVisible(false)

        local offsetX = 50 --偏移量
        if rawData._maxTimes > 900000 then  --无限次数
            self._remainTimesLabel:setText("無限制") 
            self._remainTimesLabel:setPositionX(836)
            self._fixRemainTimesLabel:setPositionX(615)
            self._remainAddBtn:setEnabled(false)
            self._remainAddBtn:setVisible(false)
            self._threeTimesButton:setEnabled(false)
        	self._threeTimesButton:setVisible(false)

            if self._currentDungeonData._score == 3 then --三星通关
                self._raidsButton:setEnabled(true)
                self._raidsButton:setVisible(true)

                self._tenTimesButton:setEnabled(true)
                self._tenTimesButton:setVisible(true)
            else
                self._raidsButton:setEnabled(false)
                self._raidsButton:setVisible(false)

                self._tenTimesButton:setEnabled(false)
                self._tenTimesButton:setVisible(false)
            end

        else   --有限次数
            local isShowAddBtn = self._currentDungeonData._remainTimes == 0
            self._remainAddBtn:setEnabled(isShowAddBtn)
            self._remainAddBtn:setVisible(isShowAddBtn)
            if isShowAddBtn then
                self._remainTimesLabel:setPositionX(836 - offsetX)
                self._fixRemainTimesLabel:setPositionX(615 - offsetX)
            else
                self._remainTimesLabel:setPositionX(836)
                self._fixRemainTimesLabel:setPositionX(615)
            end

    		self._tenTimesButton:setEnabled(false)
            self._tenTimesButton:setVisible(false)
            self._threeTimesButton:setEnabled(false)
            self._threeTimesButton:setVisible(false)

            if self._currentDungeonData._remainTimes >= 1 and self._currentDungeonData._score == 3 then --三星通关且次数大于1
                self._raidsButton:setEnabled(true)
                self._raidsButton:setVisible(true)

                if self._currentDungeonData._remainTimes >= 3 then
                	self._threeTimesButton:setEnabled(true)
                	self._threeTimesButton:setVisible(true)
                end
                
            else
                self._raidsButton:setEnabled(false)
                self._raidsButton:setVisible(false)
            end
           
        end
    end

    if self._currentDungeonData._remainTimes < 3 then  -- 偏移多次扫荡 的按钮
        self._raidsButton:setPosition(ccp(self._tenTimesButton:getPosition()))
    else
        self._raidsButton:setPosition(ccp(811,269))
    end

    if rawData._type == DungeonEnumType.Treasure then --宝藏本 不显示星级
        for i=1,3 do
            self._widget:getChildByName(string.format("img_star%d",i)):setVisible( false )
        end
    else  --普通本要显示星级
        for i=1,3 do
            self._widget:getChildByName(string.format("img_star%d",i)):setVisible(  i <= self._currentDungeonData._score )
        end
    end

    local imgDiff = tolua.cast(self._widget:getChildByName("img_diff"),"ImageView")
    imgDiff:loadTexture(string.format("i18n_dugeno_diff%d.png",self._currentDiff),UI_TEX_TYPE_PLIST)
end

function DungeonPerpare:open()
	local id = self.params["id"]
	local diff = self.params["diff"]
    local isForceView = self.params["isForceView"]

    if isForceView == 1 then
        self.close_btn:setTouchEnabled(false)
    end

    DungeonView:getInstance():setTurnBtnView(false)

	local dungeonVo = DungeonManager:getInstance():getScheduleDungeonData(id,diff)
	
    self:update(dungeonVo)
    
    --指引装备面板 正打开
    if WindowCtrl:getInstance():hasOpeningWinByName(CmdName.FindEqmView) or  
        WindowCtrl:getInstance():hasOpeningWinByName(CmdName.Task_View) or 
        WindowCtrl:getInstance():hasOpeningWinByName(CmdName.FindSoulGemView) then
        self.containerType = WindowHelper.containerType.only_middle
    else
        self.containerType = WindowHelper.containerType.left 
    end

    --新手引导
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 10001 or 
        GuideDataProxy:getInstance().nowMainTutroialEventId == 10202 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"open_dungeondesc")
    end
end

function DungeonPerpare:onUpdateRaidsFunc(rewardData)

	if not rewardData then
        return
    end
    
    rewardData.dungeonId = self._currentDungeonData._id
    rewardData.diff = self._currentDungeonData._diff
    WindowCtrl:getInstance():open(CmdName.Dungeon_Raids_View, rewardData)
end

function DungeonPerpare:close()
	DungeonView:getInstance():_setChapterTitle()
    self.close_btn:setTouchEnabled(true)
    DungeonView:getInstance().close_btn:setTouchEnabled(true)
    DungeonView:getInstance():setTurnBtnView(true)
    DungeonView:getInstance()._panel_lock:setTouchEnabled(false) --解锁锁屏
end