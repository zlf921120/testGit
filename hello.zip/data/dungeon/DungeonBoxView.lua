--副本宝箱 奖励 面板
DungeonBoxView = class("DungeonBoxView",WindowBase)
DungeonBoxView.__index = DungeonBoxView
DungeonBoxView._widget    = nil
DungeonBoxView.uiLayer    = nil

local __instance = nil
local _diff = 0
local _chapter = 0
local _boxType = 0
local _isCanGet = false

function DungeonBoxView:create()
    local ret = DungeonBoxView.new()
    __instance = ret
    return ret
end
------------------------------------------------------
local function event_btn_ok(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		if _isCanGet then
			DungeonManager:getInstance():requestDungeonBox(_diff,_chapter,_boxType)
		else
			__instance:addCloseAnim()
		end
	end
end

local function event_cb_close()
	__instance:addCloseAnim()

	if GuideDataProxy:getInstance().nowMainTutroialEventId == 10603 then
	    Notifier.dispatchCmd(GuideEvent.StepFinish,"click_boxbtn1")
	end
end
-------------------------------------------------------

local itemIcon = nil

function DungeonBoxView:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("dungeon/dungeon_box.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

   	self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
    self.btnOk:addTouchEventListener(event_btn_ok)

    Notifier.regist(CmdName.DUNGEON_CB_CLOSE_BOX,event_cb_close)
    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

--新手引导动画
function DungeonBoxView:showStepAnim(param)
    if param.target == "dungeon_boxbtn1" then
        GuideRenderMgr:getInstance():renderMainFlag(self.btnOk,param.id,param.target)
    end
end

function DungeonBoxView:open()

	self:isShowBg(false)
	self:isShowReturnBtn(false)

    self:update(self.params)

    self:addOpenAnim()
end

function DungeonBoxView:update(params)

	local btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
	-- btnOk:setBright(params[4])
    -- btnOk:setTouchEnabled(params[4])

	local dm = DungeonManager:getInstance()
	_diff = params[1]
	_chapter = params[2]
	_boxType = params[3]
	_isCanGet = params[4]

	local labTitle = tolua.cast(self._widget:getChildByName("lab_title"),"Label")
	if _boxType == DungeonBoxType.Perfect then
		labTitle:setText("三星獎勵")
	elseif _boxType == DungeonBoxType.Unperfect then
		labTitle:setText("通關獎勵")
	end
    
	if _isCanGet then
		btnOk:setTitleText("領取")
		btnOk:setSize(CCSize(150,76))
	else
		btnOk:setSize(CCSize(200,76))
		if _boxType == DungeonBoxType.Perfect then
			btnOk:setTitleText("三星後領取")
		elseif _boxType == DungeonBoxType.Unperfect then
			btnOk:setTitleText("通關後領取")
		end
	end

	local tbl = dm:getDungeonBoxReward(_diff,_chapter,_boxType)
	for i=500,520 do
		local child = self._widget:getChildByTag(i)
		if child ~= nil then
			child:removeFromParentAndCleanup(true)
		end
	end

	local p_1 = self._widget:getChildByName("p_1")  
	local idx = 0
	local function createItem(id ,num,name)
		local itemIcon = ItemIcon:create()
		itemIcon:setBaseId( id )
		itemIcon:setTag( idx + 500)
		itemIcon:setPosition(ccp( p_1:getPositionX() + idx * 160 ,p_1:getPositionY() ))
		itemIcon:setItemNum(num)
		self._widget:addChild(itemIcon)
		idx = idx + 1

		local label = Label:create()
		label:setTag( idx + 510)
		label:setFontSize(24)
		label:setText(name)
		label:setColor(ccc3(251,241,160))
		-- label:setAnchorPoint(ccp(0,0.5))
		label:setPosition(ccp( itemIcon:getPositionX() ,p_1:getPositionY() - 70 ))
		self._widget:addChild(label)
	end
	
	if tbl.goods ~= "" then
		local goodsTbl = Utils.split(tbl.goods,",")
		local itemMode = ItemManager:getInstance():getItemModelByBaseId(tonumber(goodsTbl[1]),tonumber(goodsTbl[2]))
		createItem(itemMode.base_id,tonumber(goodsTbl[2]),itemMode.name)
	end

	if tbl.coin ~= 0 then
		createItem( 50002 ,tbl.coin,"金幣")
	elseif tbl.diamond ~= 0 then
		createItem( 50003 ,tbl.diamond,"鑽石")
	end
end

function DungeonBoxView:close()


end