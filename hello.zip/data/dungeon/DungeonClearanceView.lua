--
-- Author: thisgf
-- Date: 2014-06-28 10:10:16
-- 副本通关界面

require "error_code_pb"

require "CharacterManager"
require "AbstView"
require "combatConfig"


DungeonClearanceView = class("DungeonClearanceView", AbstView.create)

DungeonClearanceView._bm = nil
DungeonClearanceView._cm = nil

--数据
DungeonClearanceView._freeAwardList = nil
DungeonClearanceView._payAwardList = nil

DungeonClearanceView._freeAwardIndex = 1
DungeonClearanceView._payAwardIndex = 1


--免费抽奖列表(显示)
DungeonClearanceView._freeLotteryList = nil

--收费抽奖列表(显示)
DungeonClearanceView._payLotteryList = nil

DungeonClearanceView._tempPayLotteryList = nil

--延迟播放动画函数
DungeonClearanceView._delayPlayAnimationFunc = nil

--移动卡牌回调函数
DungeonClearanceView._moveCardFunc = nil

--显示免费卡牌函数
DungeonClearanceView._showFreeCardFunc = nil

--显示付费卡牌函数
DungeonClearanceView._showPayCardFunc = nil

DungeonClearanceView._moveCardIndex = 0
--移动卡牌完成
DungeonClearanceView._isMoveCardComplete = false

--点击卡牌回调
DungeonClearanceView._touchCardFunc = nil

--抽奖回调
DungeonClearanceView._onPayRspFunc = nil


DungeonClearanceView._titleImage = nil

DungeonClearanceView._starImageList = nil

DungeonClearanceView._levelLabel = nil
DungeonClearanceView._expLabel = nil
DungeonClearanceView._goldLabel = nil

DungeonClearanceView._freeAwardLabel = nil
DungeonClearanceView._payAwardLabel = nil


DungeonClearanceView._freeLotteryLayer = nil
DungeonClearanceView._payLotteryLayer = nil

DungeonClearanceView._confirmBtn = nil


--最大抽奖卡
local MAX_LOTTERY = 4

local MAX_STAR = 3

local _widgetPath = "ui/dungeon/dungeon_ui_clearance.json"

function DungeonClearanceView:ctor()

	-- self:_initData()
	-- self:_initUI()

	-- Notifier.regist(CmdName.BATTLE_PAY_LOTTERY_RSP, self._onPayRspFunc)

	self:init()

end

function DungeonClearanceView:init()

	self:_initData()
	self:_initUI()

	Notifier.regist(CmdName.BATTLE_PAY_LOTTERY_RSP, self._onPayRspFunc)

end

function DungeonClearanceView:_initData()

	self._cm = CharacterManager:getInstance()
	self._bm = BattleManager:getInstance()
	
	self._starImageList = {}
	self._freeLotteryList = {}
	self._payLotteryList = {}
	self._tempPayLotteryList = {}

	self._delayPlayAnimationFunc = function()
	    
	    self:playAnimation()
	end

	self._moveCardFunc = function(cardView)

	    self._moveCardIndex = self._moveCardIndex + 1

	    if self._moveCardIndex > MAX_LOTTERY * 2 then

	    	self:_moveCardComplete()
	    end

	end

	self._showFreeCardFunc = function(params)

	    local awardList = params[1]
	    local cardList = params[2]

		for _, award in ipairs(awardList) do

    		if award.isAward == BattleCardAwardType.SHOW then

    			for i, v in ipairs(cardList) do

	        		if v:getItemData() == nil then

	    				v:setItemData(award.itemData)
				        v:playAction()
				        v:setEnabled(false)

				        break
	        		end
	        	end
    		end
		end 
	end

	self._showPayCardFunc = function(params)
		local awardList = params[1]
	    local cardList = params[2]

		for _, award in ipairs(awardList) do

    		if award.isAward == BattleCardAwardType.SHOW then

    			for i, v in ipairs(cardList) do

	        		if v:getItemData() == nil then

	    				v:setItemData(award.itemData)
				        v:playAction()
				        v:setEnabled(false)

				        break
	        		end
	        	end
    		end
		end 
	end

	--点击卡牌
	self._touchCardFunc = function(sender)

		local item
		local awardData
		local awardCount = 0

	    if sender._lotteryType == BattleAwardType.FREE then

	        self:_showCardAward(sender)

	    elseif sender._lotteryType == BattleAwardType.PAY then

	        for k, v in pairs(self._tempPayLotteryList) do
	        	if v == sender then
	        	    return
	        	end
	        end

	        table.insert(self._tempPayLotteryList, sender)
	        self._bm:reqLotteryPayCard()

	    end
	end

	self._onPayRspFunc = function(ret)

	    if ret ~= error_code_pb.msg_ret.success then
	    	return
	    end

	    if not self._tempPayLotteryList or #self._tempPayLotteryList == 0 then
	    	return
	    end

	    local sender = table.remove(self._tempPayLotteryList, 1)
	    self:_showCardAward(sender)

	    self._bm:reqAddAwardToBackpack(BattleAwardType.PAY)

	    -- if not self._payAwardList or #self._payAwardList then
	    -- 	return
	    -- end

	    -- item = table.remove(self._payAwardList, 1)
     --    card:setItemData(item)
     --    card:playAction()
     --    card:setEnabled(false)

	end

end

function DungeonClearanceView:_initUI()

	self:_initWidget(_widgetPath)

	self._titleImage = self:_getWidget("image_title", ComponentType.IMAGE_VIEW)

	self._levelLabel = self:_getWidget("label_level", ComponentType.LABEL)
	self._expLabel = self:_getWidget("label_exp", ComponentType.LABEL)
	self._goldLabel = self:_getWidget("label_gold", ComponentType.LABEL)

	self._freeLotteryLayer = self:_getWidget("panel_free_lottery", ComponentType.LAYOUT)
	self._payLotteryLayer = self:_getWidget("panel_pay_lottery", ComponentType.LAYOUT)

	self._confirmBtn = self:_getWidget("btn_confirm", ComponentType.BUTTON)
	self._confirmBtn:addTouchEventListener(function(sender, event)
		self:onButtonTouch(sender, event)
	end)


    local cardView
	for i = 1, MAX_LOTTERY do

		cardView = DungeonClearanceCardView:create(BattleAwardType.FREE, i)
		cardView:setTargetPos(110 + (i - 1) * 225, 54)

		self._freeLotteryLayer:addNode(cardView)

		self._freeLotteryList[#self._freeLotteryList + 1] = cardView
		cardView:addTouchEventListener(self._touchCardFunc)

	end

	for i = 1, MAX_LOTTERY do

		cardView = DungeonClearanceCardView:create(BattleAwardType.PAY, i)
		cardView:setTargetPos(110 + (i - 1) * 225, 54)

		self._payLotteryLayer:addNode(cardView)

		self._payLotteryList[#self._payLotteryList + 1] = cardView
		cardView:addTouchEventListener(self._touchCardFunc)

	end

	for i = 1, MAX_STAR do

		self._starImageList[i] = self:_getWidget(string.format("image_star_%d", i), ComponentType.IMAGE_VIEW)
	end

	self._freeAwardLabel = self:_getWidget("label_free_award", ComponentType.LABEL)
	self._payAwardLabel = self:_getWidget("label_pay_award", ComponentType.LABEL)

end

function DungeonClearanceView:open()

	if self.params then

		self._levelLabel:setText(string.format("LV : %d", self._cm:getTeamData():getLev()))
		self._expLabel:setText(string.format("EXP : +%d", self.params.exp))
		self._goldLabel:setText(string.format("+%d", self.params.gold))

		self._freeAwardList = self.params.freeAwardList
		self._payAwardList = self.params.payAwardList

		for i, v in ipairs(self._starImageList) do
			v:setVisible(false)
		end

		local width_dist = 244 / (self.params.numStars + 1)
		local starImage
		for i = 1, self.params.numStars do

			starImage = self._starImageList[i]

			starImage:setVisible(true)
			starImage:setPosition(ccp(width_dist * i, 61))

		end

		if self.params.numStars == MAX_STAR then
			self._titleImage:loadTexture("dgui_prefect_clearance_title.png", UI_TEX_TYPE_PLIST)
		else
			self._titleImage:loadTexture("dgui_clearance_title.png", UI_TEX_TYPE_PLIST)
		end

	end

	self:reset()

	--延迟播放动画
	TimerManager.addTimer(100, self._delayPlayAnimationFunc, false)

end

function DungeonClearanceView:close()

	TimerManager.removeTimer(self._delayPlayAnimationFunc)
	TimerManager.removeTimer(self._showFreeCardFunc)
	TimerManager.removeTimer(self._showPayCardFunc)

end

function DungeonClearanceView:reset()

	self._tempPayLotteryList = {}
	self._freeAwardIndex = 1
	self._payAwardIndex = 1
	
	for i, v in ipairs(self._freeLotteryList) do

		v:stopAllActions()
		
		v:setPosition(ccp(445, 53))
		v:reset()
		v:setEnabled(false)

	end

	for i, v in ipairs(self._payLotteryList) do

		v:stopAllActions()
		
		v:setPosition(ccp(445, 53))
		v:reset()
		v:setEnabled(false)

	end

end

--显示卡牌奖励
function DungeonClearanceView:_showCardAward(sender)

    local awardList
    local awardIndex

    local cardList

    local lotteryType = sender._lotteryType
    if lotteryType == BattleAwardType.FREE then

    	awardList = self._freeAwardList
    	awardIndex = self._freeAwardIndex

    	cardList = self._freeLotteryList

    else
     	awardList = self._payAwardList
     	awardIndex = self._payAwardIndex

     	cardList = self._payLotteryList

    end

    if not awardList or #awardList == 0 then
    	return
    end

    if awardIndex > #awardList then
    	return
    end

    awardCount = 0
    for i = awardIndex, #awardList do

    	awardData = awardList[i]

    	if awardData.isAward == BattleCardAwardType.AWARD then

    		awardCount = awardCount + 1
    		if awardCount == 2 then
    			break
    		end

    		if lotteryType == BattleAwardType.FREE then
	    		self._freeAwardIndex = i + 1
	    	else
	    		self._payAwardIndex = i + 1
	    	end

    		sender:setItemData(awardData.itemData)
	        sender:playAction()
	        sender:setEnabled(false)

	        self._bm:reqAddAwardToBackpack(BattleAwardType.FREE)

    	end
    end

    --没有奖励的卡牌显示非奖励的
    if awardCount ~= 2 then

    	awardIndex = #awardList + 1

    	if lotteryType == BattleAwardType.FREE then
    		self._freeAwardIndex = awardIndex
	        TimerManager.addTimer(1100, self._showFreeCardFunc, false, {awardList, cardList})
    	else
    		self._payAwardIndex = awardIndex
    		TimerManager.addTimer(1100, self._showPayCardFunc, false, {awardList, cardList})
    	end
	end

end

--播放卡牌移动动画
function DungeonClearanceView:playAnimation()

	self._moveCardIndex = 1
	self._isMoveCardComplete = false

	for i, v in ipairs(self._freeLotteryList) do
		
		v:moveToTargetPos(self._moveCardFunc)

	end

	for i, v in ipairs(self._payLotteryList) do
		
		v:moveToTargetPos(self._moveCardFunc)

	end

end

function DungeonClearanceView:_moveCardComplete()
	
	self._isMoveCardComplete = true

	for i, v in ipairs(self._freeLotteryList) do
		
		v:setEnabled(true)
	end

	for i, v in ipairs(self._payLotteryList) do
		
		v:setEnabled(true)
	end

end

function DungeonClearanceView:onButtonTouch(sender, event)
    
    if event == TOUCH_EVENT_ENDED then

		self._bm:reqBattleEnd()

    end

end

function DungeonClearanceView:_getWidget(name, comType)

	return tolua.cast(self._widgetGroup:getWidgetByName(name), comType)

end

function DungeonClearanceView:create()
	
	local dcv = DungeonClearanceView.new()

	return dcv

end


require "component/ItemIcon"

DungeonClearanceCardView = class("DungeonClearanceCardView", DisplayUtil.newLayer)
-- DungeonClearanceCardView = class("DungeonClearanceCardView", function() return CCLayerColor:create(ccc4(0xff, 0xff, 0, 0xff)) end)

--抽奖类型(免费和付费)
DungeonClearanceCardView._lotteryType = 0

--第几张牌
DungeonClearanceCardView._index = 1
--是否播放动作中
DungeonClearanceCardView._isAction = false
DungeonClearanceCardView._targetPos = nil
--显示结果动作
DungeonClearanceCardView._resultAction = nil
DungeonClearanceCardView._moveAction = nil
DungeonClearanceCardView._moveCallFunc = nil

DungeonClearanceCardView._isEnabled = true

DungeonClearanceCardView._touchFunc = nil

DungeonClearanceCardView._itemData = nil

DungeonClearanceCardView._lockCardSprite = nil
DungeonClearanceCardView._openCardSprite = nil

DungeonClearanceCardView._itemIcon = nil


function DungeonClearanceCardView:ctor(lotteryType, index)

    self._lotteryType = lotteryType
	self._index = index

	self._targetPos = ccp(0, 0)

	local size = CCSizeMake(210, 97)

	self:setContentSize(size)
	self:ignoreAnchorPointForPosition(false)
	self:setAnchorPoint(ccp(0.5, 0.5))

	if self._lotteryType == BattleAwardType.FREE then
		self._lockCardSprite = CCSprite:createWithSpriteFrameName("dgui_free_lottery_card.png")
	else
		self._lockCardSprite = CCSprite:createWithSpriteFrameName("dgui_pay_lottery_card.png")
	end
	self:addChild(self._lockCardSprite)
	self._lockCardSprite:setAnchorPoint(ccp(0, 0))

	self._openCardSprite = CCSprite:createWithSpriteFrameName("dgui_lottery_open_card.png")
	self._openCardSprite:setVisible(false)
	self._openCardSprite:setAnchorPoint(ccp(0, 0))
	self:addChild(self._openCardSprite)

	self._itemIcon = ItemIcon:create()
	self._itemIcon:setPosition(ccp(size.width * 0.5, size.height * 0.5))
	self._itemIcon:setVisible(false)
	self:addChild(self._itemIcon)

	local function touchHandler(event, x, y)

		if DisplayUtil.isTouch(self, x, y) then

			if event == "ended" then
				if self._touchFunc ~= nil then
					self._touchFunc(self)
				end
			end
		end

		return true

	end

	self:setTouchEnabled(true)
	self:registerScriptTouchHandler(touchHandler, false, 0)


end

function DungeonClearanceCardView:reset()

	self._itemData = nil
	self:setRotation(0)
	self:setScale(1)
	self:stopAllActions()
	self:_changeStatus(false)
	self:setEnabled(true)

end

function DungeonClearanceCardView:_changeStatus(isOpen)

	if isOpen then
		self._openCardSprite:setVisible(true)
		self._lockCardSprite:setVisible(false)
		self._itemIcon:setVisible(true)
	else
		self._openCardSprite:setVisible(false)
		self._lockCardSprite:setVisible(true)
		self._itemIcon:setVisible(false)
	end

end

function DungeonClearanceCardView:playAction()

	if self._isAction then
		return
	end


	self._isAction = true

	if not self._resultAction then

		local actionCallFunc = function()
		    self._isAction = false
		end

		local middleCallFunc = function()

		    self:_changeStatus(true)

		end

		
		local rotateAction1 = CCRotateBy:create(0.3, 720)
		local scaleAction1 = CCScaleBy:create(0.2, 0.2)

		local spawnAction1 = CCSpawn:createWithTwoActions(rotateAction1, scaleAction1)

		local rotateAction2 = CCRotateBy:create(0.3, 360)
		local scaleAction2 = CCScaleTo:create(0.3, 1)

		local spawnAction2 = CCSpawn:createWithTwoActions(rotateAction2, scaleAction2)

		local middleAction = CCCallFunc:create(middleCallFunc)
		local callAction = CCCallFunc:create(actionCallFunc)

		local actionArray = CCArray:create()
		actionArray:addObject(spawnAction1)
		actionArray:addObject(middleAction)
		actionArray:addObject(spawnAction2)
		actionArray:addObject(callAction)

		local seqAction = CCSequence:create(actionArray)

		self._resultAction = seqAction
		self._resultAction:retain()

	end

	self:runAction(self._resultAction)

end

function DungeonClearanceCardView:moveToTargetPos(callFunc)

	self._moveCallFunc = callFunc

	if not self._moveAction then

		local onMoveComplete = function()
		    if self._moveCallFunc then
		    	self._moveCallFunc(self)
		    end
		end

		local moveAction = CCMoveTo:create(0.15, self._targetPos)
		local easeAction = CCEaseIn:create(moveAction, 0.5)
		local callAction = CCCallFunc:create(onMoveComplete)

		self._moveAction = CCSequence:createWithTwoActions(easeAction, callAction)
		self._moveAction:retain()

	end

	self:runAction(self._moveAction)

end

--[[
    设置物品数据
]]
function DungeonClearanceCardView:setItemData(itemData)

	self._itemData = itemData
	self._itemIcon:setBaseId(itemData.mode.base_id)
end

function DungeonClearanceCardView:getItemData()

	return self._itemData
end

function DungeonClearanceCardView:setEnabled(value)

	if self._isEnabled == value then
		return
	end

	self._isEnabled = value

	if self._isEnabled then
		self:setTouchEnabled(true)
	else
		self:setTouchEnabled(false)
	end

end

function DungeonClearanceCardView:setTargetPos(x, y)
	self._targetPos.x = x
	self._targetPos.y = y
end

function DungeonClearanceCardView:getTargetPos()
	return self._targetPos
end

function DungeonClearanceCardView:getLotteryType()
	return self._lotteryType
end

function DungeonClearanceCardView:getIndex()
	return self._index
end

function DungeonClearanceCardView:addTouchEventListener(func)

	self._touchFunc = func

end

function DungeonClearanceCardView:dispose()
	
	if self._resultAction then
		self._resultAction:release()
	end

	if self._moveAction then
		self._moveAction:release()
	end

end

function DungeonClearanceCardView:create(lotteryType, index)
	
	local dccv = DungeonClearanceCardView.new(lotteryType, index)

	return dccv

end