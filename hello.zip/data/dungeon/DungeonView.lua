--
-- Author: thisgf
-- Date: 2014-06-24 14:36:44
-- 副本页面

require "AbstView"
require "RadioGroup"
require "ItemIcon"
require "MonsterIcon"
require "BattleManager"

local DungeonItem

DungeonView = class("DungeonView", AbstView.create)

DungeonView._dm = nil

DungeonView._openTime = 0

--第几章
DungeonView._currentChapterIndex = 1

--各难度第几章
DungeonView._diffChapterList = nil

--副本项字典,根据原来的image做key
DungeonView._totalItemDict = nil

--当前显示的项字典
DungeonView._currentItemDict = nil

--副本项点击函数
DungeonView._itemTouchFunc = nil

--难度单项组
DungeonView._diffRadioGroup = nil

--当前选中的难度
DungeonView._currentDiff = 1

--当前选中的副本数据
DungeonView._currentDungeonData = nil

--初始化进度回调
DungeonView._onInitScheduleFunc = nil

--更新单个副本进度
DungeonView._onUpdateOneScheduleFunc = nil

DungeonView._onUpdateResScheduleFunc = nil

--更新扫荡
DungeonView._onUpdateRaidsFunc = nil

--战斗开始通知
DungeonView._onBattleRspStartFunc = nil

--章节容器字典
DungeonView._chapterWidgetDict = nil

--是否已经获取到数据
DungeonView._isGetData = nil

--更新所有资源本数据
DungeonView._onRspAllResDungeon = nil


--总的组件组
DungeonView._widgetGroup = nil

--标题文本
DungeonView._titleLabel = nil

--左翻页按钮
DungeonView._turnLeftButton = nil
--右翻页按钮
DungeonView._turnRightButton = nil

--副本场景滚动页面
DungeonView._sceneScrollView = nil

--章节容器
DungeonView._chapterWidget = nil

--新副本的箭头
DungeonView._newDungeonArrowImage = nil
--箭头动作
DungeonView._dungeonArrowAction = nil
--新副本特效
DungeonView._newDungeonArmature = nil
--副本锁层 
DungeonView._panel_lock = nil

--星星图标面板
DungeonView._starIconPanel = nil
--星星图标
DungeonView._starIconList = nil

--当前最新的副本项
DungeonView._lastDungeonItem = nil
DungeonView._historyLastItem = nil --上一个副本项
DungeonView._fightLastItem = nil --打过的副本项

local __dungeonView = nil

local _widgetPath = "ui/dungeon/dungeon_ui_1.ExportJson"
local _chapterPathPrefix = "ui/dungeon/chapter/chapter_%d.json"

DungeonView.dungeonResMapTbl = {"10000.jpg","10001.jpg","10002.jpg","10003.jpg","10002.jpg","10000.jpg","10001.jpg"}

local function getChapterPath(index)
    return string.format(_chapterPathPrefix, index)
end

function DungeonView:ctor()

    -- self:_initData()
    -- self:_initUI()

    -- self._diffRadioGroup:setFocusedWithIndex(1)

    -- self:registerScriptHandler(function(event)

    --  print("==========================", event, self._sceneScrollView:getInnerContainer():getPosition())
    --  end)

end

function DungeonView:getInstance()
    return __dungeonView
end

function DungeonView:init()

    self:_initData()
    self:_initUI()
    
    self:_updateDiffButton()
    Notifier.regist(CmdName.DUNGEON_UPDATE_REARDBOX,function() self:_updateDungeonBox() end)

    require "GuideEvent" --新手引导
    Notifier.regist(GuideEvent.Force,function(params)
        if params == "dungeondesc" then
            self:forceOpenDescPanel()
        elseif params == "startbattle" then
            self:forceOpenStarBattle()
        end
    end)
    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,function(param) self:showStepAnim(param) end)
end

function DungeonView:_initData()

    self._dm = DungeonManager:getInstance()
    self._dm:parseDungeonData()
    self._dm:parseDropData()
    
    self._diffRadioGroup = RadioGroup:create()

    self._chapterWidgetDict = {}

    --初始化第几章节
    self._diffChapterList = {}
    self._diffChapterList[DungeonDiffType.NORMAL] = {chapter = 1, percent = 0}
    self._diffChapterList[DungeonDiffType.HARD] = {chapter = 1, percent = 0}
    self._diffChapterList[DungeonDiffType.NIGHTMARE] = {chapter = 1, percent = 0}


    self._totalItemDict = {}
    self._dungeonBoxDict = {}
    self._maybeFallItemIconList = {}

    self._maybeMonsterIconList = {}

    self._onInitScheduleFunc = function()
        self:_initScheduleFunc()
    end

    self._onUpdateOneScheduleFunc = function(oneScheduleData)

        self:_updateOneScheduleFunc(
            oneScheduleData[1], 
            oneScheduleData[2], 
            oneScheduleData[3], 
            oneScheduleData[4], 
            oneScheduleData[5], 
            oneScheduleData[6], 
            oneScheduleData[7]
        )
    end

    self._onUpdateResScheduleFunc = function()
        self:_updateResScheduleFunc()
    end

    self._onShowDungeonDesc = function()
        self._dm:setCurrentHandleDungeonData(self._currentDungeonData._rawData)

        WindowCtrl:getInstance():open(
            CmdName.DungeonPerpare, 
            {
                diff = self._currentDungeonData._diff, 
                id =self._currentDungeonData._id
            }
        )
        self._titleLabel:setText(self._currentDungeonData._rawData._name)
    end

    self._onBattleRspStartFunc = function()
        if BattleManager:getInstance():getStartData().battleType == BattleType.DUNGEON then
            -- self:closeDescPanel()
            WindowCtrl:getInstance():close(CmdName.DungeonPerpare)
        end
    end

    self._dungeonHandleBattleEnd = function()
        self._panel_lock:setTouchEnabled(false) --解锁锁屏
        local batResData = BattleManager:getInstance():getBattleResultData()
        if BattleManager:getInstance():getIsOB() or batResData == nil then
            return
        end
        
        local isWin = batResData and batResData.resultType == BattleResultType.VICTORY
        if not isWin then 
            self:_jumpToItem(self._currentDungeonData._id,self._currentDiff)
        end
        self:checkShowNewItem() --检查New图显示状况
    end

    self._onRspAllResDungeon = function()
        self:_rspAllResDungeon()
    end

end

function DungeonView:_initUI()
    ComResMgr:getInstance():loadOtherRes()

    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/dungeon/chapter/dgui_build.plist")

    self:_initWidget(_widgetPath)

    self._titleLabel = self:_getWidget("label_title", ComponentType.LABEL)

    self._panel_lock = self:_getWidget("panel_lock",ComponentType.LAYOUT)

    self._sceneScrollView = self:_getWidget("scene_scroll_view", ComponentType.SCROLL_VIEW)

    local buttonNormal = self._widgetGroup:getWidgetByName("button_level_normal")
    local buttonHard = self._widgetGroup:getWidgetByName("button_level_hard")
    local buttonNightmard = self._widgetGroup:getWidgetByName("button_level_nightmare")
    
    local imgTip2 = self._widgetGroup:getWidgetByName("img_tip2") --难度提示
    imgTip2:setTouchEnabled(true)
    imgTip2:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Diff2,function()
                imgTip2:setTouchEnabled(false)
            end)
        end
    end)
    local imgTip3 = self._widgetGroup:getWidgetByName("img_tip3") --难度提示
    imgTip3:setTouchEnabled(true)
    imgTip3:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Diff3,function()
                imgTip3:setTouchEnabled(false)
            end)
        end
    end)
    --设置单选项
    self._diffRadioGroup:addRadio(buttonNormal, buttonHard, buttonNightmard)
    self._diffRadioGroup:setFocusedWithIndex(1)
    self._diffRadioGroup:addChangeEventListener(function() self:_onChangeDiff() end)

    local function onPageButtonTouch(sender, event)

        -- if self._isGetData == false then
        --  return
        -- end
        
        if event == TOUCH_EVENT_ENDED then

            if sender == self._turnLeftButton then
                self:turnPreviousPage()
            elseif sender == self._turnRightButton then
                self:turnNextPage()
            end
        end
    end

    self._handleLayer = self._widgetGroup:getWidgetByName("panel_handle")

    self._turnLeftButton = self:_getWidget("button_turn_left", ComponentType.BUTTON)
    self._turnRightButton = self:_getWidget("button_turn_right", ComponentType.BUTTON)
    self._turnLeftButton:addTouchEventListener(onPageButtonTouch)
    self._turnRightButton:addTouchEventListener(onPageButtonTouch)
    DisplayUtil.setNodeExist(self._turnLeftButton, false)
    DisplayUtil.setNodeExist(self._turnRightButton, false)

    -- self._newDungeonArrowImage = CCSprite:createWithSpriteFrameName("dgui_arrow.png")
    -- self._newDungeonArrowImage = ImageView:create()
    -- self._newDungeonArrowImage:loadTexture("down_sign.png", UI_TEX_TYPE_PLIST)
    -- self._newDungeonArrowImage:setAnchorPoint(ccp(0.5, 0))
    -- self._newDungeonArrowImage:retain()
    -- self._newDungeonArrowImage:setTouchEnabled(false)
    -- self._newDungeonArrowImage:setVisible(false) --箭头不显示

    local heroVo = HeroManager:getInstance():getHeroInfoByBaseId(10000) --写死 黑骑士
    local action_data = EffectManager:getInstance():getActionData(heroVo:getModelId())
    self.model_id = heroVo:getModelId()
    self._armatureHero = AnimateManager:getInstance():getArmature(action_data._fileFullPathName, action_data._fileName)
    
    self._armatureHero:setScaleY(0.65)
    self._armatureHero:setScaleX(-0.65)
    self._armatureHero:setVisible(false)
    self._sceneScrollView:addNode(self._armatureHero,11)

    self._armBox1 = AnimateManager:getInstance():getArmature("ui/effects_ui/fubenbaoxiang_zi/fubenbaoxiang_zi.ExportJson", "fubenbaoxiang_zi")
    self._armBox1:setVisible(false)
    -- self._armBox1:getAnimation():play("texiao",0,-1,1)
    self._sceneScrollView:addNode(self._armBox1,1)
    self._armBox2 = AnimateManager:getInstance():getArmature("ui/effects_ui/fubenbaoxiang_huang/fubenbaoxiang_huang.ExportJson", "fubenbaoxiang_huang")
    self._armBox2:setVisible(false)
    -- self._armBox2:getAnimation():play("texiao",0,-1,1)
    self._sceneScrollView:addNode(self._armBox2,1)

    -- local arrowAction1 = CCMoveBy:create(0.8, ccp(0, -10))
    -- local arrowAction2 = CCMoveBy:create(0.8, ccp(0, 10))

    -- self._dungeonArrowAction = CCRepeatForever:create(
    --     CCSequence:createWithTwoActions(
    --         arrowAction1, 
    --         arrowAction2
    --         )
    --     )
    -- self._dungeonArrowAction:retain()

    self._newDungeonArmature = AnimateManager:getInstance():getArmature("ui/effects_ui/fubenrukouzhiyin/fubenrukouzhiyin.ExportJson", "fubenrukouzhiyin")
    self._newDungeonArmature:setVisible(false)
    -- self._newDungeonArmature:getAnimation():play("Animation1",0,-1,1)
    -- self._newDungeonArrowImage:runAction(self._dungeonArrowAction)
    self._sceneScrollView:addNode(self._newDungeonArmature,1)
    -- self._sceneScrollView:addChild(self._newDungeonArrowImage, 10)
end

-------------------------------------------------
function DungeonView:forceOpenStarBattle()
    BattleManager:getInstance():reqBattleStart(10001, 1,TeamType.Normal)
end

--新手引导动画
function DungeonView:showStepAnim(param)
    if param.target == "dungeon_view" then
        local tbl = {}
        table.insert(tbl,{target = "dungeon_view",container = self._sceneScrollView})
        GuideDataProxy:getInstance():checkGuideLazyShowAnim(tbl)
    elseif param.target == "dungeon_dungeonbox1" then
        for k,v in pairs(self._dungeonBoxDict) do
            v:showStepAnim(param)
        end
    end
end
-------------------------------------------------
function DungeonView:open()

    Notifier.regist(CmdName.DUNGEON_INIT_SCHEDULE, self._onInitScheduleFunc)
    Notifier.regist(CmdName.DUNGEON_UPDATE_ONE_SCHEDULE, self._onUpdateOneScheduleFunc)
    Notifier.regist(CmdName.BATTLE_RSP_START, self._onBattleRspStartFunc)
    Notifier.regist(CmdName.BATTLE_RSP_END,self._dungeonHandleBattleEnd) --战斗结束
    Notifier.regist(CmdName.DUNGEON_UPDATE_RES_SCHEDULE, self._onUpdateResScheduleFunc)
    Notifier.regist(CmdName.RES_CT_RSP_ALL_DUNGEON, self._onRspAllResDungeon)
    self:_setGetData(false)
    -- self._dm:reqScheduleInfo()

    self:_initScheduleFunc()

    ResContendManager:getInstance():reqAllBrifeInfo()

    -- self:_runArrowAction()  
    self._widgetGroup:runAction(CCSequence:createWithTwoActions(
        CCDelayTime:create(0.5),
        CCCallFunc:create(function()

        --新手引导动画
        local tbl = {}
        table.insert(tbl,{target = "dungeon_view",container = self._sceneScrollView})
        GuideDataProxy:getInstance():checkGuideLazyShowAnim(tbl)
    end)))

    self._panel_lock:setTouchEnabled(false) --解锁锁屏

    self:checkShowNewItem() --检查New图显示状况

    --指引装备面板 正打开
    if WindowCtrl:getInstance():hasOpeningWinByName(CmdName.FindEqmView)  or  
        WindowCtrl:getInstance():hasOpeningWinByName(CmdName.Task_View) or 
        WindowCtrl:getInstance():hasOpeningWinByName(CmdName.FindSoulGemView)  then
        self.containerType = WindowHelper.containerType.only_middle
    else
        self.containerType = WindowHelper.containerType.left 
    end

    self:checkUpdateArm()
end

--检测模型变化
function DungeonView:checkUpdateArm()
    local heroVo = HeroManager:getInstance():getHeroInfoByBaseId(10000) --写死 黑骑士
    if self.model_id and self.model_id ~= heroVo:getModelId() then --模型发生变化
        local pos = ccp(self._armatureHero:getPosition())
        self._armatureHero:getAnimation():stop()
        self._armatureHero:getAnimation():setMovementEventCallFunc(function() end)
        self._armatureHero:removeFromParentAndCleanup(true)
        self._armatureHero = nil

        local action_data = EffectManager:getInstance():getActionData(heroVo:getModelId())
        self._armatureHero = AnimateManager:getInstance():getArmature(action_data._fileFullPathName, action_data._fileName)
        self._armatureHero:getAnimation():play("stand",-1,-1,1)
        self._armatureHero:setScaleY(0.65)
        self._armatureHero:setScaleX(-0.65)
        self._armatureHero:setPosition(pos)
        self._sceneScrollView:addNode(self._armatureHero,11)
    end
end

--检测New图显示状况
function DungeonView:checkShowNewItem()
    local dp = ActivateDataProxy:getInstance()
    dp:showDungeonNewImg(function(key) self:showNewsImg(key) end)
end

--展示 新开启 图
function DungeonView:showNewsImg(key)
    local target = nil
    local pos = nil
    if key == NewImgEnum.dungeon_diff2 then
        target = self._widgetGroup:getWidgetByName("button_level_hard")
        pos = ccp(20+10,20+10) 
    elseif key == NewImgEnum.dungeon_diff3 then
        target = self._widgetGroup:getWidgetByName("button_level_nightmare")
        pos = ccp(20+10,20+10) 
    end
    if target and target:getNodeByTag(4152) == nil then
        local tips_img = AnimateManager:getInstance():getArmature("ui/effects_ui/new/new.ExportJson","new")
        tips_img:getAnimation():play("Animation1",-1,-1,1)
        tips_img:setTag(4152)
        tips_img:setPosition(pos)
        target:addNode(tips_img,10)

    elseif target and target:getNodeByTag(4152) ~= nil then
        local tips_img = target:getNodeByTag(4152)
        -- self:tipsPointPlayAct(tips_img)
    end
end

-- 隐藏 新开启 图
function DungeonView:hideNewsImg(key)
    local target = nil
    if key == NewImgEnum.dungeon_diff2 then
        target = self._widgetGroup:getWidgetByName("button_level_hard")
    elseif key == NewImgEnum.dungeon_diff3 then
        target = self._widgetGroup:getWidgetByName("button_level_nightmare")
    end
    if target and target:getNodeByTag(4152) ~= nil then
        target:removeNodeByTag(4152)
    end
end

function DungeonView:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

function DungeonView:enter()

    -- self:_runArrowAction()

    -- self:_jumpToLastItem()

    -- self:_updateHeroArmature()
    -- self:_updateNewDungeonArmature()
    -- self:_updateDungeonBox()

    -- self:_jumpPage()
    self:_turnPage()
    self:_setGetData(true)
end

function DungeonView:close()

    TimerManager.removeTimer(self._onShowDungeonDesc)

    self._fightLastItem = nil

    for k,v in pairs(self._chapterWidgetDict) do
        CCTextureCache:sharedTextureCache():removeTextureForKey("ui/dungeon/chapter/" .. self.dungeonResMapTbl[k])
    end

    Notifier.remove(CmdName.BATTLE_RSP_START, self._onBattleRspStartFunc)
    Notifier.remove(CmdName.BATTLE_RSP_END, self._dungeonHandleBattleEnd)
    
    WindowCtrl:getInstance():close(CmdName.DungeonPerpare)
end

function DungeonView:turnPreviousPage()

    local chapterIndex = self._diffChapterList[self._currentDiff].chapter
    if chapterIndex == 1 then
        return
    end

    chapterIndex = chapterIndex - 1
    self._diffChapterList[self._currentDiff].chapter = chapterIndex

    self._currentChapterIndex = chapterIndex
    self._diffChapterList[self._currentDiff].percent = 0

    self:_turnPage()

    self:_getLastDungeon()
    self:_updateDirectArrow()
    self:_updateHeroArmature()
    self:_updateNewDungeonArmature()
    self:_jumpToLastItem()
    self:_updateDungeonBox()

end

function DungeonView:turnNextPage()

    local chapterIndex = self._diffChapterList[self._currentDiff].chapter

    if chapterIndex >= self._dm:getMaxChapter() then
        return
    end

    local teamLev = CharacterDataProxy:getInstance():getTeamLev()
    local checkTeamLev = self._dm:getChapterData(chapterIndex + 1)._teamLev
    if teamLev < checkTeamLev then
        Alert:show(string.format("戰隊等級達到%d級開啟第%s章副本",checkTeamLev,Helper.converNumToChinese(chapterIndex + 1)))
        return
    end

    chapterIndex = chapterIndex + 1
    self._diffChapterList[self._currentDiff].chapter = chapterIndex

    self._currentChapterIndex = chapterIndex
    self._diffChapterList[self._currentDiff].percent = 0

    self:_turnPage()
    self:_getLastDungeon()
    self:_updateDirectArrow()
    self:_updateHeroArmature()
    self:_updateNewDungeonArmature()
    self:_jumpToLastItem()
    self:_updateDungeonBox()
end

--跳至对应的章节
function DungeonView:_jumpPage()

    local checkChapterId = 1
    local scheduleData = self._dm:getScheduleData(self._currentDiff) --最新章节情况
    if scheduleData then
        checkChapterId = scheduleData._chapterId
    end

    local function checkOpenChapter(checkChapterId) --根据战队等级 检测是否开放该章节
        while true do
            local teamLev = CharacterDataProxy:getInstance():getTeamLev()
            local checkTeamLev = self._dm:getChapterData(checkChapterId)._teamLev
            if teamLev < checkTeamLev then
                checkChapterId = checkChapterId - 1
                checkOpenChapter(checkChapterId)
            else
                return checkChapterId
            end
        end
    end
    
    local currCanOpenChapterId = checkOpenChapter(checkChapterId)

    self._currentChapterIndex = currCanOpenChapterId
    self._diffChapterList[self._currentDiff].chapter = checkChapterId

    self:_turnPage()
    self:_getLastDungeon()
    self:_updateDirectArrow()
    self:_updateHeroArmature()
    self:_updateNewDungeonArmature()
    self:_jumpToLastItem()
    self:_updateDungeonBox()
end

--翻页
function DungeonView:_turnPage()

    if self._currentChapterIndex == 1 then
        DisplayUtil.setNodeExist(self._turnLeftButton, false)
    else
        DisplayUtil.setNodeExist(self._turnLeftButton, true)
    end

    local scheduleData = self._dm:getScheduleData(self._currentDiff)
    if scheduleData and self._currentChapterIndex >= scheduleData._chapterId then
        DisplayUtil.setNodeExist(self._turnRightButton, false)
    elseif scheduleData then
        DisplayUtil.setNodeExist(self._turnRightButton, true)
    else
        DisplayUtil.setNodeExist(self._turnRightButton, false)
    end

    self:_setChapterTitle()

    if self._chapterWidget then

        self._chapterWidget:removeFromParentAndCleanup(false)
        self._chapterWidget = nil
    end
    self._chapterWidget = self:_getChapterWidget(self._currentChapterIndex)

    self._sceneScrollView:addChild(self._chapterWidget, 0)

    --容器列表
    local itemPanel = self._chapterWidget:getChildByName("panel_dungeon")
    
    if not self._itemTouchFunc then
        self._itemTouchFunc = function(sender, event)

            self:onDungeonItemTouch(sender, event)
        end
    end

    local children = itemPanel:getChildren()

    local child

    local dungeonItem
    local dungeonData

    local scheduleDungeon = nil
    -- local resScheduleList = self._dm:getResDunScheduleList(
    --     self._currentDiff, 
    --     self._currentChapterIndex
    -- )
    local scheduleChapterList = self._dm:getScheduleDungeonList(
        self._currentDiff, 
        self._currentChapterIndex
    )
    local lastItem = nil

    self._currentItemDict = {}
    -- self._totalItemDict = {}

    for i = 1, children:count() do

        child = children:objectAtIndex(i - 1)
        local name = tolua.cast(child,"Widget"):getName()
        local t = Utils.split(name,"_")[1]
        if name == "UnperfectBox" or name == "PerfectBox" then --两个宝箱
            self._dungeonBoxDict[child] = DungeonBox:create(child)
        elseif t == "entry" then
            tolua.cast(child,"Button"):addTouchEventListener(self._itemTouchFunc)
            dungeonItem = self._totalItemDict[child]
            if not dungeonItem then
                dungeonItem = DungeonItem:create(child)

                self._totalItemDict[child] = dungeonItem
            end
            -- dungeonItem:setDiff(self._currentDiff)

            local beforeItem = self._currentItemDict[ #self._currentItemDict ]
            -- print(" #self._currentItemDict ",#self._currentItemDict,beforeItem)
            if #self._currentItemDict == 0 then --一头一尾是特殊
                dungeonItem._beforeItem = dungeonItem
            else
                dungeonItem._beforeItem = beforeItem
            end
            table.insert(self._currentItemDict, dungeonItem)

            dungeonData = self._dm:getDungeonData(
                dungeonItem._dungeonId, 
                self._currentDiff
            )

            if scheduleChapterList then
                scheduleDungeon = nil
                for i,v in ipairs(scheduleChapterList) do

                    if v._id == dungeonItem._dungeonId then
                        
                        scheduleDungeon = v
                        break
                    end
                end
                if scheduleDungeon then

                    dungeonItem:setOpen(true)
                    dungeonItem:setDungeonEnumType(scheduleDungeon._rawData._type)
                    dungeonItem:setScore(scheduleDungeon._score)
                    dungeonItem:setTreatureCout(
                        scheduleDungeon._remainTimes,
                        scheduleDungeon._rawData._maxTimes
                    )

                else
                    dungeonItem:setOpen(false)
                end
            else
                dungeonItem:setOpen(false)
            end

            if dungeonData then
                dungeonItem:setEnabled(true)
                if dungeonData:getType() == DungeonEnumType.Treasure then
                    local treasureTexture
                    if dungeonData.treasureData.treasureType == DungeonEnum.treasureType.GOLD then
                        treasureTexture = "dg_treasure_gold.png"
                    elseif dungeonData.treasureData.treasureType == DungeonEnum.treasureType.ITEM then
                        treasureTexture = "dg_treasure_item.png"
                    else
                        treasureTexture = "dg_treasure_diamond.png"
                    end
                    dungeonItem:updateTreasureTexture(treasureTexture)
                    dungeonItem:showTreasure(true)
                    local treasureBuild = dungeonItem:getTreasureBuild()
                    if not self._totalItemDict[treasureBuild] then
                        tolua.cast(treasureBuild,"Button"):addTouchEventListener(self._itemTouchFunc)
                        self._totalItemDict[treasureBuild] = dungeonItem
                    end
                else
                    dungeonItem:showTreasure(false)
                    if dungeonData:getType() == DungeonEnumType.Resource then
                        local resData = self._dm:getResDungeonData(dungeonData._id)
                        local armatureName = ""
                        if resData.produceType == ResContendEnum.REWARD_TYPE.GOLD then
                            armatureName = "zyqdjinbi"
                        elseif resData.produceType == ResContendEnum.REWARD_TYPE.DIAMOND then
                            armatureName = "zyqdzuanshi"
                        else
                            armatureName = "zyzdyaoshui"
                        end
                        dungeonItem:setResArmature(armatureName)
                    end
                end
            else
                dungeonItem:setEnabled(false)
            end

        end
    end

    self:_rspAllResDungeon()

    -- self:_getLastDungeon()

    -- self:_updateDirectArrow()
    -- self:_updateHeroArmature()
    -- self:_updateNewDungeonArmature()
    -- self:_jumpToLastItem()
    -- self:_updateDungeonBox()
end

function DungeonView:_setChapterTitle()

    local chapterData = self._dm:getChapterData(self._currentChapterIndex)
    self._titleLabel:setText( string.format("第%s章 %s", Utils.toChineseNum(self._currentChapterIndex), chapterData._name))

end

function DungeonView:_getLastDungeon()
    local scheduleData = self._dm:getScheduleData(self._currentDiff)
    if not scheduleData then
        self._lastDungeonItem = nil
        return
    end

    local lastItem = nil
    
    for k,v in pairs(self._currentItemDict) do

        if v._dungeonId == scheduleData._dungeonId then
            
            lastItem = v
            lastItem:setEnabled(true)

            break
        end
    end

    self._historyLastItem = self._lastDungeonItem
    self._lastDungeonItem = lastItem

end

--更新指引箭头
function DungeonView:_updateDirectArrow()
    --箭头不显示
    -- local item = self._lastDungeonItem

    -- if item then
        
    --     local size = item:getSize()
    --     local ix, iy = item:getPosition()

    --     self._newDungeonArrowImage:setVisible(true)
    --     self._newDungeonArrowImage:setPosition(ccp(ix, iy + size.height * 0.5))

    --     -- print(self._newDungeonArrowImage:getPosition())

    -- else
    --     self._newDungeonArrowImage:setVisible(false)

    -- end

end

function DungeonView:_updateNewDungeonArmature()
    for i=1,#self._currentItemDict do
        self._currentItemDict[i]:setVisibleTipTitle(false)
    end

    self._newDungeonArmature:setVisible( self._lastDungeonItem ~= nil )
    local item = self._lastDungeonItem
    if item then
        local size = item:getSize()
        local ix, iy = item:getPosition()
        self._newDungeonArmature:setPosition(ccp(ix,iy - size.height * 0.35))
        if self._currentDiff == DungeonDiffType.NORMAL then
            item:setVisibleTipTitle(true)
        end
        --最后一章  最后一个副本  特殊处理(不显示 特效)
        if item._dungeonId == self._dm:getChapterData(self._dm:getMaxChapter()):getLastDungeonDataByDiff(DungeonDiffType.NIGHTMARE)._id  then 
            self._newDungeonArmature:setVisible(false) 
            item:setVisibleTipTitle(false)
        end
    end
end

function DungeonView:_updateHeroArmature()

    local nowDungeonItem = self._lastDungeonItem
    local historyLastItem = self._historyLastItem
    self._armatureHero:setVisible( self._lastDungeonItem ~= nil )

    if historyLastItem == nil and nowDungeonItem == nil then
        local item = self._currentItemDict[ #self._currentItemDict ]
        local scheduleChapterList = self._dm:getScheduleDungeonList(self._currentDiff, self._currentChapterIndex)
        self._armatureHero:setVisible( scheduleChapterList ~= nil )
        self:_jumpToItem(item._dungeonId,self._currentDiff)

    elseif historyLastItem == nowDungeonItem or historyLastItem == nil and nowDungeonItem then
        local size = nowDungeonItem:getSize()
        local ix, iy = nowDungeonItem:getBeforeItem():getPosition()
        self._armatureHero:setPosition(ccp(ix, iy - size.height * 0.2))
        if nowDungeonItem:getBeforeItem():getDungeonEnumType() == DungeonEnumType.Resource then--蛋疼的资源本
            local ix, iy = nowDungeonItem:getBeforeItem():getBeforeItem():getPosition()
            self._armatureHero:setPosition(ccp(ix, iy - size.height * 0.2))
            self._armatureHero:setVisible( nowDungeonItem:getBeforeItem():getBeforeItem():getScore() ~= 0 )
        else
            self._armatureHero:setVisible( nowDungeonItem:getBeforeItem():getScore() ~= 0 ) --站在第一个副本上
        end
    elseif historyLastItem and nowDungeonItem == nil then
        local item = self._currentItemDict[ #self._currentItemDict ]
        local scheduleChapterList = self._dm:getScheduleDungeonList(self._currentDiff, self._currentChapterIndex)
        self._armatureHero:setVisible( scheduleChapterList ~= nil )
        self:_jumpToItem(item._dungeonId,self._currentDiff)

    elseif historyLastItem ~= nowDungeonItem then

        local size = nowDungeonItem:getSize()
        local ix, iy = nowDungeonItem:getBeforeItem():getPosition()
        self._armatureHero:setPosition(ccp(ix, iy - size.height * 0.2))

        if nowDungeonItem:getBeforeItem():getDungeonEnumType() == DungeonEnumType.Resource then--蛋疼的资源本
            local ix, iy = nowDungeonItem:getBeforeItem():getBeforeItem():getPosition()
            self._armatureHero:setPosition(ccp(ix, iy - size.height * 0.2))
            self._armatureHero:setVisible( nowDungeonItem:getBeforeItem():getBeforeItem():getScore() ~= 0 )
        else
            self._armatureHero:setVisible( nowDungeonItem:getBeforeItem():getScore() ~= 0 ) --站在第一个副本上
        end
    end

    self._armatureHero:getAnimation():stop()
    self._armatureHero:getAnimation():play("stand",-1,-1,1)
end

--更新动画人物的位置 以上一次点击的副本为主
function DungeonView:_updateHeroArmatureByFightItem()
    local dungeonItem = self._fightLastItem
    local size = dungeonItem:getSize()
    local ix, iy = dungeonItem:getPosition()
    self._armatureHero:setPosition(ccp(ix, iy - size.height * 0.2))

    local percent = DisplayUtil.getScrollViewPercentWithPos(self._sceneScrollView, 
        ccp(dungeonItem:getPosition()))

    self._sceneScrollView:stopAllActions()
    self._sceneScrollView:runAction(CCSequence:createWithTwoActions(
        CCDelayTime:create(0.5),
        CCCallFunc:create(function()
            self._sceneScrollView:scrollToPercentHorizontal(percent,0.2,true)
        end)))
end

--播放进去副本前的动画
function DungeonView:_playPrepareAnim(func)

    local nowDungeonItem = self._lastDungeonItem
    local size = nowDungeonItem:getSize()
    local ix, iy = nowDungeonItem:getPosition()
    local nx, ny = self._armatureHero:getPosition()
    local arr = CCArray:create()

    if Helper.isSamePos(ccp(ix,iy),ccp(nx,ny + size.height * 0.2)) == false then
        arr:addObject(CCCallFunc:create(function()
            self._armatureHero:getAnimation():stop()
            self._armatureHero:getAnimation():play("run",-1,-1,1)
        end))
        arr:addObject(CCMoveTo:create(0.4,ccp(ix, iy - size.height * 0.2)))
    end
    arr:addObject(CCCallFunc:create(function()
        self._armatureHero:getAnimation():stop()
        self._armatureHero:getAnimation():play("attack01",-1,-1,0)
    end))
    arr:addObject(CCDelayTime:create(1))
    arr:addObject(CCCallFunc:create(function()
        
        self._armatureHero:getAnimation():play("stand",-1,-1,1)
    end))
    self._armatureHero:setVisible(true)
    self._armatureHero:stopAllActions()
    self._armatureHero:runAction(CCSequence:create(arr))

    TimerManager.addTimer((0.4 + 1) * 1000 ,self._onShowDungeonDesc) --强制触发
end
--打完胜利后播放庆祝动画
function DungeonView:_playHeroCelebrateAnim(func)
    self._armatureHero:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCCallFunc:create(function()
        self._armatureHero:getAnimation():stop()
        self._armatureHero:getAnimation():play("celebrate01",-1,-1,0)
    end))
    arr:addObject(CCDelayTime:create(0.65))
    arr:addObject(CCCallFunc:create(function()
        self._armatureHero:getAnimation():play("celebrate02",-1,-1,1)
    end))
    arr:addObject(CCDelayTime:create(0.6))
    arr:addObject(CCCallFunc:create(function()
        if func ~= nil then func() end
        self._armatureHero:getAnimation():play("stand",-1,-1,1)
    end))
    self._armatureHero:runAction(CCSequence:create(arr))
end

function DungeonView:_updateDungeonBox()
    for k,v in pairs(self._dungeonBoxDict) do
        v:update()
    end 
end

function DungeonView:_runArrowAction()
    -- self._newDungeonArrowImage:stopAllActions()
    -- self._newDungeonArrowImage:runAction(self._dungeonArrowAction)
end
--初始化章节容器
function DungeonView:_getChapterWidget(chapterId)
    local ret = nil
    local widget = self._chapterWidgetDict[chapterId]
    if widget then
        ret = widget 
    else
        self._chapterWidgetDict[chapterId] = tolua.cast(
            GUIReader:shareReader():widgetFromJsonFile(getChapterPath(chapterId)),
            ComponentType.LAYOUT
        )

        widget = self._chapterWidgetDict[chapterId]
        widget:retain()
        
        local panel = widget:getChildByName("panel_dungeon")
        local pBoxX1,pBoxY1 = panel:getChildByName("p_box01"):getPosition()
        local pBoxX2,pBoxY2 = panel:getChildByName("p_box02"):getPosition()

        local imgBox1 = ImageView:create()
        imgBox1:setTouchEnabled(true)
        imgBox1:setScaleX(2)
        imgBox1:setScaleY(2.5)
        imgBox1:setName("UnperfectBox") --非完美宝箱
        imgBox1:setVisible(false) --占位用的
        imgBox1:loadTexture("ui/guide/guide/guide_img_mask.png")
        imgBox1:setPosition(ccp(pBoxX1,pBoxY1))
        panel:addChild(imgBox1)

        local imgBox2 = ImageView:create()
        imgBox2:setTouchEnabled(true)
        imgBox2:setScaleX(2)
        imgBox2:setScaleY(2.5)
        imgBox2:setName("PerfectBox") --完美宝箱
        imgBox2:loadTexture("ui/guide/guide/guide_img_mask.png")
        imgBox2:setVisible(false) --占位用的
        imgBox2:setPosition(ccp(pBoxX2,pBoxY2))
        panel:addChild(imgBox2)
        
        ret = widget
    end
    --手动 加载地图
    tolua.cast(ret:getChildByName("image_scene"),"ImageView"):loadTexture("ui/dungeon/chapter/" .. self.dungeonResMapTbl[chapterId]) 
    return ret
end

function DungeonView:onDungeonItemTouch(sender, event)
    if event ~= TOUCH_EVENT_ENDED then
        return
    end

    local dungeonItem = self._totalItemDict[sender]
    if not dungeonItem then
        return
    end

    self:_openDungeonItem(dungeonItem)
end

function DungeonView:_openDungeonItem(dungeonItem)

    if dungeonItem._isOpen == false then 

        local str = "打通上一關卡即可挑戰本關卡哦"
        if self._currentDiff ~= DungeonDiffType.NORMAL then

            local dm = DungeonManager:getInstance()
            local listVo = dm:getScheduleDungeonList( self._currentDiff -1 , self._currentChapterIndex)
            local isPass = false
            for i=1,#listVo do
                if listVo[i]._id == dungeonItem._dungeonId and listVo[i]._score ~= 0 then
                    isPass = true
                end
            end
            if isPass == false then
                str = string.format("本關卡%s難度打通即可開啟%s難度",DungeonType[self._currentDiff-1],DungeonType[self._currentDiff])
            end
        end

        Alert:show(str)
        return
    end

    self._currentDungeonData = self._dm:getScheduleDungeonData(dungeonItem._dungeonId, self._currentDiff)

    if not self._currentDungeonData then
        return
    end


    self._panel_lock:setTouchEnabled(true) --锁屏
    self._fightLastItem = dungeonItem -- 记录这次战斗的副本项

    local function showPreparePanel()
        self._dm:setCurrentHandleDungeonData(self._currentDungeonData._rawData)

        if self._currentDungeonData._rawData:getType() == DungeonEnumType.Resource then
           WindowCtrl:getInstance():open(
               CmdName.RES_CONTEND_DESC_VIEW, 
               {
                   diff = self._currentDungeonData._diff, 
                   dunId = self._currentDungeonData._id
               }
           )
        else
            WindowCtrl:getInstance():open(
                CmdName.DungeonPerpare,
                {
                    diff = self._currentDungeonData._diff, 
                    id =self._currentDungeonData._id
                }
            )
        end

        -- WindowCtrl:getInstance():open(CmdName.DungeonPerpare,{diff = self._currentDungeonData._diff, id =self._currentDungeonData._id})
        self._titleLabel:setText(self._currentDungeonData._rawData._name)

    end
    if dungeonItem:getScore() ~= 0 or 
        self._currentDungeonData._rawData:getType() == DungeonEnumType.Resource then
        self._armatureHero:setPosition(ccp(dungeonItem:getPosition()))
        local arr = CCArray:create()
        arr:addObject(CCCallFunc:create(function()
            self._armatureHero:getAnimation():stop()
            self._armatureHero:getAnimation():play("attack01",-1,-1,0)
        end))
        arr:addObject(CCDelayTime:create(1))
        arr:addObject(CCCallFunc:create(function()
             self._armatureHero:getAnimation():play("stand",-1,-1,1)
        end))
        arr:addObject(CCCallFunc:create(showPreparePanel))
        self._armatureHero:stopAllActions()
        self._armatureHero:runAction(CCSequence:create(arr))
    else
        self:_playPrepareAnim(showPreparePanel)--播放动画 延时
    end

end

-------新手引导-----------------------------------------------------------
function DungeonView:forceOpenDescPanel(dungeonId,diff)
    self.close_btn:setTouchEnabled(false)
    self._currentDungeonData = self._dm:getScheduleDungeonData(10001, 1)
    local function showPreparePanel()
        self._dm:setCurrentHandleDungeonData(self._currentDungeonData._rawData)
        WindowCtrl:getInstance():open(CmdName.DungeonPerpare,{id=10001,diff=1,isForceView=1})
        self._titleLabel:setText(self._currentDungeonData._rawData._name)
    end
    self:_playPrepareAnim(showPreparePanel)--播放动画 延时
end
------------------------------------------------------------------
function DungeonView:_onChangeDiff()

    local index = self._diffRadioGroup:getSelectedIndex()

    local lastDiff = self._currentDiff

    self._currentDiff = index
    
    local tmpMap = {}
    tmpMap[2] = NewImgEnum.dungeon_diff2
    tmpMap[3] = NewImgEnum.dungeon_diff3
    ActivateDataProxy:getInstance():setEventVoDoneViewNew(tmpMap[ index ])
    self:hideNewsImg(tmpMap[ index ])

    if self._currentDiff == 0 then
        self._currentDiff = DungeonDiffType.NORMAL
    end

    local checkChapterId = 1
    local scheduleData = self._dm:getScheduleData(self._currentDiff) --最新章节情况
    if scheduleData ~= nil then
        checkChapterId = scheduleData._chapterId
    end
    
    -- local checkChapterId = self._diffChapterList[self._currentDiff].chapter

    local function checkOpenChapter(checkChapterId) --根据战队等级 检测是否开放该章节
        while true do
            local teamLev = CharacterDataProxy:getInstance():getTeamLev()
            local checkTeamLev = self._dm:getChapterData(checkChapterId)._teamLev
            if teamLev < checkTeamLev then
                checkChapterId = checkChapterId - 1
                checkOpenChapter(checkChapterId)
            else
                return checkChapterId
            end
        end
    end
    
    local currCanOpenChapterId = checkOpenChapter(checkChapterId)
    self._currentChapterIndex = currCanOpenChapterId
    self._diffChapterList[self._currentDiff].chapter = self._currentChapterIndex

    -- self._currentChapterIndex = currCanOpenChapterId

    self:_turnPage()

    self:_getLastDungeon()
    self:_updateDirectArrow()
    self:_updateHeroArmature()
    self:_updateNewDungeonArmature()
    self:_jumpToLastItem()
    self:_updateDungeonBox()
end

function DungeonView:_updateDiffButton()

    local offsetX = 0
    local function checkIsPass(diff,chapterId) --是否通关章节

        local dm = DungeonManager:getInstance()
        local listVo = dm:getScheduleDungeonList( diff, chapterId)
        if not listVo then
            return false
        end
        local num = 0
        for k,v in pairs(listVo) do
            if v._score ~= 0 and v._rawData._type == DungeonEnumType.Normal then
                num = num + 1
            end
        end
        return num == dm:getChapterData( chapterId ):getNumDungeon() --通关
    end

    local imgTip1 = self._widgetGroup:getWidgetByName(string.format("img_tip%d",1))
    local imgTip2 = self._widgetGroup:getWidgetByName(string.format("img_tip%d",2))
    local btn1and2IsVisible = checkIsPass(DungeonDiffType.NORMAL,1) 
    self._diffRadioGroup:getRadioWithIndex(1):setVisible(btn1and2IsVisible)
    self._diffRadioGroup:setRadioEnabled(i, btn1and2IsVisible)
    self._diffRadioGroup:getRadioWithIndex(2):setVisible(btn1and2IsVisible)
    self._diffRadioGroup:setRadioEnabled(i, btn1and2IsVisible)
    imgTip1:setTouchEnabled(not btn1and2IsVisible)
    imgTip2:setTouchEnabled(not btn1and2IsVisible)
    self._handleLayer:getChildByName("view_diffmenu"):setVisible(btn1and2IsVisible) --底层阴影
    if btn1and2IsVisible then
        offsetX = offsetX + 2
    end

    local imgTip = self._widgetGroup:getWidgetByName(string.format("img_tip%d",3))
    local dm = DungeonManager:getInstance()
    local isCanOpenDiff3 = checkIsPass( DungeonDiffType.NORMAL, 2 )
    if isCanOpenDiff3 then
        self._diffRadioGroup:getRadioWithIndex(3):setVisible(true)
        self._diffRadioGroup:setRadioEnabled(3, true)
         imgTip:setTouchEnabled(false)
        offsetX = offsetX + 1
    else
        self._diffRadioGroup:getRadioWithIndex(3):setVisible(false)
        self._diffRadioGroup:setRadioEnabled(3, false)
        imgTip:setTouchEnabled(true)
    end
--------偏移按钮---------------------------
    local btnXTbl = {-126,31,192}
    for i=1,3 do
        local imgTip = self._widgetGroup:getWidgetByName(string.format("img_tip%d",i))
        imgTip:setPositionX( btnXTbl[i] + (3 - offsetX) * 160 )
        local button = self._diffRadioGroup:getRadioWithIndex(i)
        button:setPositionX( btnXTbl[i] + (3 - offsetX) * 160 )
    end
end 

function DungeonView:_initScheduleFunc()

    self:_setGetData(true)

    self:_updateDiffButton()

    if self.params and (self.params["diff"] ~= nil or self.params["dungeonId"] ~= nil) then
        local diff = self.params["diff"]            --强制跳转diff
        local dungeonId = self.params["dungeonId"]  --强制跳转dungeonId
        self._currentDiff = diff

        local retTbl = DungeonManager:getInstance():isCanOpenDungeon(dungeonId,diff)
        if dungeonId == 0 and diff ~= nil then
            self:_jumpPage()
            self._diffRadioGroup:setFocusedWithIndex(diff)
        elseif retTbl.isOpen == false then
            self:_jumpPage()
            if diff ~= nil then
                self._diffRadioGroup:setFocusedWithIndex(diff)
            end
        else
            self:_jumpPage()
            self._diffRadioGroup:setFocusedWithIndex(diff)
            local dungeonItem = self:_jumpToItem(dungeonId, diff)

            self:_openDungeonItem(dungeonItem)
        end
    else
        self:_jumpPage()
    end

    self:_updateDungeonBox()
end

function DungeonView:_updateOneScheduleFunc(diff, chapterId, dungeonId, score,teatureCout,maxCount,type)

    print("-------------------_updateOneScheduleFunc------------------------  ")
    -- self:_updateDiffButton()

    if self._currentDiff ~= diff then
        return
    end

    local scheduleData = self._dm:getScheduleData(self._currentDiff)

    -- print( " zzzz scheduleData._chapterId ", scheduleData._chapterId,scheduleData,scheduleData._dungeonId )

    if scheduleData and self._currentChapterIndex >= scheduleData._chapterId then
        DisplayUtil.setNodeExist(self._turnRightButton, false)
    else
        DisplayUtil.setNodeExist(self._turnRightButton, true)
    end

    -- print("=========================更新副本", self._currentChapterIndex, diff, chapterId, dungeonId, score)

    if self._currentChapterIndex == chapterId then

        for k,v in pairs(self._totalItemDict) do
            if v._dungeonId == dungeonId then

                v:setEnabled(true)
                v:setOpen(true)
                v:setDungeonEnumType(type)
                v:setScore(score,v:getScore() ~= score)
                v:setTreatureCout(teatureCout,maxCount)

                break
            end
        end
    end

    self:_getLastDungeon()

    if self._fightLastItem == nil then
        self:_updateHeroArmature()
    else
        self:_updateHeroArmatureByFightItem()
    end

    self:_updateNewDungeonArmature()
    self:_updateDungeonBox()

    self:_setGetData(true)
    self:_updateDiffButton()

end

function DungeonView:_updateResScheduleFunc()

    local resScheduleList = self._dm:getResDunScheduleList(
        self._currentDiff, 
        self._currentChapterIndex
    )

    if not resScheduleList then
        return
    end

    for k,v in pairs(self._totalItemDict) do

        for _, dd in ipairs(resScheduleList) do
            if v._dungeonId == dd._id then

                v:setEnabled(true)
                v:setOpen(true)
                v:setDungeonEnumType(dd._type)
                v:setScore(0, true)
                v:setTreatureCout(1, 999999)

                break
            end
        end
    end

    self:_getLastDungeon()
    self:_updateHeroArmature()
    
end

function DungeonView:_setGetData(value)

    self._isGetData = value

    if self._isGetData then
        self:setTouchEnabled(true)
    else
        self:setTouchEnabled(false)
    end

end

--滚动到最后一个副本入口
function DungeonView:_jumpToLastItem()

    if not self._lastDungeonItem then
        return
    end

    local percent = DisplayUtil.getScrollViewPercentWithPos(self._sceneScrollView, 
        ccp(self._lastDungeonItem:getPosition()))

    self._sceneScrollView:stopAllActions()
    self._sceneScrollView:runAction(CCSequence:createWithTwoActions(
        CCDelayTime:create(0.3),
        CCCallFunc:create(function()
            self._sceneScrollView:scrollToPercentHorizontal(percent,0.2,true)
        end)))
    -- self._sceneScrollView:jumpToPercentHorizontal(percent)
end

--滑动到指定的副本项
function DungeonView:_jumpToItem(dungeonId,diff)
    local dungeonData = self._dm:getDungeonData(dungeonId,diff)
    if dungeonData == nil then return end
    self._currentDiff = diff
    self._currentChapterIndex = dungeonData._chapterId
    self._diffChapterList[self._currentDiff].chapter = self._currentChapterIndex

    self:_turnPage()

    local dungeonItem = nil
    for k,v in pairs(self._currentItemDict) do
        if v._dungeonId == dungeonId then
            dungeonItem = v
            break
        end
    end
    self._armatureHero:setPosition(ccp( dungeonItem:getPosition() ))

    local percent = DisplayUtil.getScrollViewPercentWithPos(self._sceneScrollView, 
        ccp(dungeonItem:getPosition()))

    self._sceneScrollView:stopAllActions()
    self._sceneScrollView:runAction(CCSequence:createWithTwoActions(
        CCDelayTime:create(0.5),
        CCCallFunc:create(function()
            self._sceneScrollView:scrollToPercentHorizontal(percent,0.2,true)
        end)))
    return dungeonItem
end

function DungeonView:lockPanel(value)
    self._panel_lock:setTouchEnabled(value)
end

function DungeonView:_rspAllResDungeon()

    local dungeonList = ResContendManager:getInstance():getAllDungeonInfoList()

    for _, v in pairs(self._totalItemDict) do
        if v:isOpen() then
            for _, dd in ipairs(dungeonList) do
                if v._dungeonId == dd.baseId then
                    v:setContentStatus(dd.status)
                    if dd.status == ResContendEnum.STATUS.NONE then
                        v:setContendText("當前可掠奪")
                    elseif dd.status == ResContendEnum.STATUS.OUR then
                        v:setContendText("我方佔領中")
                    elseif dd.status == ResContendEnum.STATUS.ENEMY then
                        v:setContendText(string.format("%s", dd.ownerName))
                    end
                    break
                end
            end
        end
    end

end

function DungeonView:create()

    local view = DungeonView.new()
    __dungeonView = view
    return view
end

function DungeonView:setTurnBtnView(value)
    if value then
        self._turnLeftButton:setPosition(ccp(-20,224))
        self._turnRightButton:setPosition(ccp(868,224))
    else
        self._turnLeftButton:setPosition(ccp(-20 - 500,224))
        self._turnRightButton:setPosition(ccp(868 + 500,224))
    end
end

--副本项
DungeonItem = class("DungeonItem")

DungeonItem._build = nil

--宝藏副本
DungeonItem._treasureBuild = nil
DungeonItem._treasureTextureName = nil
DungeonItem._isShowTreasure = false

DungeonItem._dungeonId = 0
DungeonItem._iconId = 0

DungeonItem._starList = nil

DungeonItem._enabled = true
DungeonItem._isOpen = true
DungeonItem._score = 0

DungeonItem._contendStatus = -1

DungeonItem._scoreBgSprite = nil

DungeonItem._starNode = nil
DungeonItem._teasureCount = nil
DungeonItem._beforeItem = nil

DungeonItem._resArmature = nil
DungeonItem._resCLContainer = nil
DungeonItem._resContendNameLabel = nil
DungeonItem._resContendLabel = nil
DungeonItem._contendFlagArmature = nil

function DungeonItem:ctor(build)

    self._build = build
    self._build:setTouchEnabled(true)

    local name = self._build:getName()
    local list = Utils.split(name, "_")
    self._dungeonId = tonumber(list[2])
    self._iconId = tonumber(list[3])

    local buildSize = self._build:getContentSize()

    local scoreBgSize = CCSizeMake(100, 35)
    self._starNode = CCNode:create()
    self._starNode:setContentSize(scoreBgSize)
    self._starNode:setPosition(ccp(-(scoreBgSize.width)*0.5, -buildSize.height*0.5))

    self._build:addNode(self._starNode)
    self._starList = {}

    local star
    for i = 1, 3 do
        star = CCSprite:createWithSpriteFrameName("golden_star.png")
        star:setScale(0.4)
        self._starNode:addChild(star)

        self._starList[#self._starList + 1] = star

    end

    local x,y = self._build:getPosition()
    --剩余次数背景
    self._imgMaskBg = ImageView:create()
    self._imgMaskBg:setVisible(false)
    self._imgMaskBg:setPosition(ccp( x + 0, y -buildSize.height*0.6))
    self._imgMaskBg:loadTexture("bg_19.png",UI_TEX_TYPE_PLIST)
    self._build:getParent():addChild(self._imgMaskBg,3)

    --初始化剩余次数
    self._teasureCount = Label:create()
    self._teasureCount:setVisible(false)
    self._teasureCount:setFontSize(22)
    self._teasureCount:setColor(ItemHelper.colors.yellow)
    self._teasureCount:setPosition(ccp(x + 0, y -buildSize.height*0.6))
    self._build:getParent():addChild(self._teasureCount,3)

    --资源抢夺文本
    self._resCLContainer = DisplayUtil.newWidget()
    self._resCLContainer:setPosition(ccp(x, y-buildSize.height*0.6))
    self._resCLContainer:setVisible(false)
    self._build:getParent():addChild(self._resCLContainer, 3)

    self._resContendNameLabel = Label:create()
    self._resContendNameLabel:setFontSize(18)
    self._resContendNameLabel:setColor(ccc3(0xf5, 0xcc, 0x55))
    self._resCLContainer:addChild(self._resContendNameLabel)

    self._resContendLabel = Label:create()
    self._resContendLabel:setVisible(false)
    self._resContendLabel:setFontSize(18)
    self._resContendLabel:setColor(ItemHelper.colors.yellow)
    -- self._resContendLabel:setPosition(ccp(x+0, y-buildSize.height*0.6))
    self._resContendLabel:setText("佔領中")
    self._resContendLabel:setAnchorPoint(ccp(0, 0.5))
    self._resCLContainer:addChild(self._resContendLabel)

    --初始化难度标题
    self._imgTip = ImageView:create()
    self._imgTip:setVisible(false)
    self._imgTip:loadTexture("i18n_dui_maintask.png",UI_TEX_TYPE_PLIST)
    self._imgTip:setPosition(ccp(0,-buildSize.height*0.6))
    self._build:addChild(self._imgTip)

    self:setOpen(false)
end

function DungeonItem:setEnabled(value)
    self._build:setEnabled(value)
end

--[[
    设置是否开启
]]
function DungeonItem:setOpen(value)

    self._isOpen = value

    if self._isOpen then
        self._starNode:setVisible(true)
        self._build:setColor(ccc3(255,255,255))
        if self._treasureBuild then
            self._treasureBuild:setColor(ccc3(255, 255, 255))
        end
    else
        self._starNode:setVisible(false)
        self._build:setColor(ccc3(170,170,170))
        if self._treasureBuild then
            self._treasureBuild:setColor(ccc3(170,170,170))
        end
        -- self:setEnabled(false)
    end

    self._imgMaskBg:setVisible(self._isOpen)
    self._teasureCount:setVisible(self._isOpen)
    self._resCLContainer:setVisible(self._isOpen)

end

function DungeonItem:isOpen()
    return self._isOpen
end

function DungeonItem:setScore(score,isAnim)
    local isAnim = isAnim or false
    local historyScore = self._score
    self._score = score
    local function progress()
        if score == 0 or self._t == DungeonEnumType.Treasure then --宝藏本项 不显示星级
            self._starNode:setVisible(false)
        else
            self._starNode:setVisible(true)
            for i = 1, #self._starList do
                self._starList[i]:setVisible(false)
            end

            local scoreBgSize = self._starNode:getContentSize()

            for i = 1, score do
                self._starList[i]:setVisible(true)
                self._starList[i]:setPosition(ccp(scoreBgSize.width * 1*i/(score+1), scoreBgSize.height*0.5))
            end
        end
        ----------清理动画------------
        for i=1,score do
            local node = self._build:getChildByTag(1000 + i)
            if node ~= nil then
                node:removeFromParentAndCleanup(true)
            end
        end
        ------------------------------
    end
    if isAnim then
        self._build:runAction(CCCallFunc:create(function() --延时机制
            if WindowCtrl:getInstance():getWaitWinNum() > 0 then
                Notifier.regist(CmdName.LastWaitWinClosed,function()
                    Notifier.removeByName(CmdName.LastWaitWinClosed)
                    self:showStarAnim(score,historyScore,progress)
                    __dungeonView._panel_lock:setTouchEnabled(false)
                end)
            else
                self:showStarAnim(score,historyScore,progress)
            end
        end))
    else
        progress()
    end
end
--播放动画
function DungeonItem:showStarAnim(score,historyScore,func)
    self._starNode:setVisible(false)
    for i = 1, #self._starList do
        self._starList[i]:setVisible(false)
    end
    ----------清理动画------------
    for i=1,score do
        local node = self._build:getChildByTag(1000 + i)
        if node ~= nil then
            node:removeFromParentAndCleanup(true)
        end
    end
-------------------------------------------------------    
    local x,y = self._starNode:getPosition()
    local scoreBgSize = self._starNode:getContentSize()
    for i=1,score do
        local img = ImageView:create()
        img:setTag(1000 + i)
        
        self._build:addChild(img)
        img:loadTexture("golden_star.png",UI_TEX_TYPE_PLIST)
        img:setPosition( ccp( x + scoreBgSize.width * 1*i/(score+1), y + scoreBgSize.height*0.5 ) )
        local arr = CCArray:create()
        arr:addObject(CCHide:create())
        arr:addObject(CCDelayTime:create( (i-1) * 0.2 ))
        arr:addObject(CCShow:create())
        if i > historyScore then
            img:setScale(2)
            arr:addObject(CCEaseBackOut:create(CCScaleTo:create(0.4,0.4)))
            arr:addObject(CCCallFunc:create(function() 
                if i == score then
                    func()
                    self._score = score
                    __dungeonView:_playHeroCelebrateAnim()
                end
            end))
        else
            img:setScale(0.4)
        end
        img:runAction(CCSequence:create(arr))
    end
end

function DungeonItem:getScore()
    return self._score
end

--获取上一个副本项
function DungeonItem:getBeforeItem()
    local ret = self._beforeItem
    if ret._dungeonId == 15011 then ret = self end --最后一章最后一个副本
    return ret
end

--副本剩余次数
function DungeonItem:setTreatureCout(cout,maxCount)
    local vis = maxCount < 900000 and self._isOpen
    self._imgMaskBg:setVisible(vis)
    self._teasureCount:setVisible(vis)
    self._teasureCount:setText(string.format("%d/%d",cout,maxCount))
end

--设置副本项 类型(宝藏副本/普通本)
function DungeonItem:setDungeonEnumType(t)
    self._t = t
end

function DungeonItem:getDungeonEnumType()
    return self._t
end

function DungeonItem:setVisibleTipTitle(value)
    self._imgTip:setVisible(value)
end

function DungeonItem:getSize()
    return self._build:getSize()
end

function DungeonItem:getPosition()
    return self._build:getPosition()
end

function DungeonItem:updateTreasureTexture(textureName)

    if self._treasureBuild == nil then
        local child = self._build:getParent():getChildByTag(2781)
        if child then
            child:removeFromParentAndCleanup(true)
        end

        self._treasureBuild = tolua.cast(self._build:clone(), "Button")
        self._treasureBuild:setName("treasure")
        self._treasureBuild:setPosition(ccp(self._build:getPosition()))
        self._treasureBuild:setTag(2781)
        self._build:getParent():addChild(self._treasureBuild)
    end

    if self._treasureTextureName ~= textureName then
        self._treasureTextureName = textureName
        self._treasureBuild:loadTextureNormal(
            self._treasureTextureName, 
            UI_TEX_TYPE_PLIST
        )
    end
end

function DungeonItem:getTreasureBuild()
    return self._treasureBuild
end

function DungeonItem:showTreasure(value)

    if self._isShowTreasure == value then
        return
    end

    self._isShowTreasure = value
    
    if value then
        if self._treasureBuild then
            self._build:setEnabled(false)
            self._build:setVisible(false)
            self._treasureBuild:setEnabled(true)
            self._treasureBuild:setVisible(true)
        end
    else
        self._build:setEnabled(true)
        self._build:setVisible(true)
        if self._treasureBuild then
            self._treasureBuild:setEnabled(false)
            self._treasureBuild:setVisible(false)
        end
    end
end

--[[
    设置占领文本
]]
function DungeonItem:setContendText(value)
    self._imgMaskBg:setVisible(true)
    -- self._resContendLabel:setText(value)
    self._resContendNameLabel:setText(value)
    if self._contendStatus == ResContendEnum.STATUS.ENEMY then
        self._resContendLabel:setVisible(true)
        self._resContendLabel:setPositionX(
            self._resContendNameLabel:getSize().width*0.5 
            - self._resContendLabel:getSize().width*0.5 
            + 3
        )

        self._resContendNameLabel:setPositionX(
            -self._resContendLabel:getSize().width*0.5
        )

    else
        self._resContendLabel:setVisible(false)
        self._resContendNameLabel:setPosition(ccp(0, 0))
    end

end

--[[
    设置占领状态
]]
function DungeonItem:setContentStatus(value)

    if self._contendStatus == value then
        return
    end

    self._contendStatus = value

    if self._contendFlagArmature then
        self._contendFlagArmature:removeFromParentAndCleanup(true)
    end

    local flagName = nil
    if self._contendStatus == ResContendEnum.STATUS.OUR then
        flagName = "zyqdlanqi"
    else
        flagName = "zyqdhongqi"
    end

    self._contendFlagArmature = EffectManager:getInstance():createUIAnimate(flagName)
    self._contendFlagArmature:getAnimation():playWithIndex(0)
    self._build:addNode(self._contendFlagArmature)

end

--[[
    设置资源本动画
]]
function DungeonItem:setResArmature(armatureName)
    if self._resArmature then
        return
    end

    self._resArmature = EffectManager:getInstance():createUIAnimate(armatureName)
    self._resArmature:getAnimation():playWithIndex(0)
    self._build:addNode(self._resArmature)

end

function DungeonItem:create(build)
    return DungeonItem.new(build)
end


--奖励宝箱
DungeonBox = class("DungeonBox")
DungeonBox.__index = DungeonBox
DungeonBox._build      = nil
DungeonBox._boxType    = 0
DungeonBox._status     = 0 --领取状态
DungeonBox._armature   = nil

function DungeonBox:ctor(build)
    if build:getName() == "UnperfectBox" then
        self._boxType = DungeonBoxType.Unperfect
        self._armature = __dungeonView._armBox1
    elseif build:getName() == "PerfectBox" then
        self._boxType = DungeonBoxType.Perfect
        self._armature = __dungeonView._armBox2
    end

    local dm = DungeonManager:getInstance()
    self._build = build
    self._armature:setPosition(ccp(build:getPosition()))
    tolua.cast(build,"ImageView"):addTouchEventListener(function(pSender,event)
        if event == TOUCH_EVENT_ENDED then
            --当前章节副本数据值
            if self:checkIsPass() then
                if dm:isHasGetBox(__dungeonView._currentDiff, __dungeonView._currentChapterIndex, self._boxType) == false then  --还没领

                    if self._boxType == DungeonBoxType.Perfect then --完美通关宝箱

                        WindowCtrl:getInstance():open(CmdName.Dungeon_Box_View,{__dungeonView._currentDiff, __dungeonView._currentChapterIndex, self._boxType,self:isPerfect()})

                    elseif self._boxType == DungeonBoxType.Unperfect then --非完美通关宝箱
                        -- print(" 領取非完美通關寶箱 ")
                        WindowCtrl:getInstance():open(CmdName.Dungeon_Box_View,{__dungeonView._currentDiff, __dungeonView._currentChapterIndex, self._boxType,true})
                        --新手引导事件
                        if GuideDataProxy:getInstance().nowMainTutroialEventId == 10602 then
                            Notifier.dispatchCmd(GuideEvent.StepFinish,"click_dungeonbox1")
                            __dungeonView._diffRadioGroup:setEnabled(true)
                            __dungeonView._turnRightButton:setTouchEnabled(true)
                        end
                         
                    end
                else
                    Alert:show("您已領取通關獎勵")
                end
            else
                WindowCtrl:getInstance():open(CmdName.Dungeon_Box_View,{__dungeonView._currentDiff, __dungeonView._currentChapterIndex, self._boxType,false})
            end

            self._armature:setScale(1)
        end
        if event == TOUCH_EVENT_BEGAN then
            self._armature:setScale(1.1)
        end
        if event == TOUCH_EVENT_CANCELED then
            self._armature:setScale(1)
        end
    end)
end

function DungeonBox:checkStatus()
    local dm = DungeonManager:getInstance()
    if self:checkIsPass() then
        if dm:isHasGetBox(__dungeonView._currentDiff, __dungeonView._currentChapterIndex, self._boxType) == false then
            if self._boxType == DungeonBoxType.Perfect then --完美通关宝箱
                if self:isPerfect() then
                    self._status = DungeonBoxStatus.Ok
                else
                    self._status = DungeonBoxStatus.Forbid
                end
            elseif self._boxType == DungeonBoxType.Unperfect then --非完美通关宝箱 
                self._status = DungeonBoxStatus.Ok
            end
        else
            self._status = DungeonBoxStatus.HasGet
        end
    else
        self._status = DungeonBoxStatus.Forbid
    end
end

function DungeonBox:update()
    self._armature:setVisible(true)
    self:checkStatus()
    self._armature:getAnimation():stop()
    if self._status == DungeonBoxStatus.Ok then
        self._armature:getAnimation():play("texiao",0,-1,1)
    elseif self._status == DungeonBoxStatus.Forbid then
        self._armature:getAnimation():play("weikai")
    elseif self._status == DungeonBoxStatus.HasGet then
        self._armature:getAnimation():play("dakai")
    end
end

function DungeonBox:checkIsPass()
    local dm = DungeonManager:getInstance()
    local listVo = dm:getScheduleDungeonList( __dungeonView._currentDiff, __dungeonView._currentChapterIndex)
    if not listVo then
        return false
    end
    local num = 0
    for k,v in pairs(listVo) do
        if v._score ~= 0 and v._rawData._type == DungeonEnumType.Normal then
            num = num + 1
        end
    end
    return num == dm:getChapterData( __dungeonView._currentChapterIndex ):getNormalNumDungeon(__dungeonView._currentDiff) --通关
end

function DungeonBox:isPerfect()
    local dm = DungeonManager:getInstance()
    local listVo = dm:getScheduleDungeonList( __dungeonView._currentDiff, __dungeonView._currentChapterIndex)
    if not listVo then
        return false
    end
    local num = 0
    for k,v in pairs(listVo) do
        if v._score == 3 and v._rawData._type == DungeonEnumType.Normal then --三星通关 的普通副本数
            num = num + 1
        end
    end
    return num == dm:getChapterData( __dungeonView._currentChapterIndex ):getNormalNumDungeon(__dungeonView._currentDiff) --完美通关
end

function DungeonBox:create(build)
   return DungeonBox.new(build)
end
--新手引导动画
function DungeonBox:showStepAnim(param)
    if param.target == "dungeon_dungeonbox1" then
        if self._boxType == DungeonBoxType.Unperfect then
            __dungeonView._diffRadioGroup:setFocusedWithIndex(1)
            __dungeonView._currentDiff = 1 
            __dungeonView._currentChapterIndex = 1
            __dungeonView._diffRadioGroup:setEnabled(false) --不能切换难度..因为..
            __dungeonView._turnRightButton:setTouchEnabled(false)

            local panel = __dungeonView._sceneScrollView
            GuideRenderMgr:getInstance():renderMainFlag(panel,param.id,param.target)
        end
    end
end