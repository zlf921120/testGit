--
-- Author: thisgf
-- Date: 2014-06-23 16:35:05
-- 副本章节数据

DungeonChapterVO = class("DungeonChapterVO")

--章节ID
DungeonChapterVO._id = 0

--章节名字
DungeonChapterVO._name = nil

--战队等级要求
DungeonChapterVO._teamLev = 99 

--包含的副本数据列表
DungeonChapterVO._dungeonDataList = nil

--根据难度分类的副本数据列表
DungeonChapterVO._diffDungeonDataList = nil

--包含的副本数量
DungeonChapterVO._numDungeon = 0


function DungeonChapterVO:ctor(id, name,teamLev)

	self._id = id
	self._name = name
	self._teamLev = teamLev
	
	self._dungeonDataList = {}
	self._diffDungeonDataList = {}
	self._diffDungeonDataList[DungeonDiffType.NORMAL] = {}
	self._diffDungeonDataList[DungeonDiffType.HARD] = {}
	self._diffDungeonDataList[DungeonDiffType.NIGHTMARE] = {}

end

function DungeonChapterVO:pushDungeon(dungeonData)

	self._dungeonDataList[#self._dungeonDataList + 1] = dungeonData

	table.insert(self._diffDungeonDataList[dungeonData._diff], dungeonData)
	local cout = 0
	local cout1 = 0
	for i=1,#self._diffDungeonDataList[dungeonData._diff] do
		local v = self._diffDungeonDataList[dungeonData._diff][i]
		if v._type == DungeonEnumType.Normal then
			cout = cout + 1
		end
		if v._type == DungeonEnumType.Treasure then
			cout1 = cout1 + 1
		end
	end
	self._numDungeon = cout
	self._numDungeonTreasure = cout1
end

function DungeonChapterVO:getNumDungeon()
	return self._numDungeon
end

function DungeonChapterVO:getNumDungeonWithTreasure()
	return self._numDungeonTreasure
end

function DungeonChapterVO:getNormalNumDungeon(diff)
	-- local num = 0
	-- for i=1,self._numDungeon do
	-- 	if self._diffDungeonDataList[diff][i]._type == DungeonEnumType.Normal then
	-- 		num = num + 1
	-- 	end
	-- end
	-- return num

	local num = 0
	for k, v in ipairs(self._diffDungeonDataList[diff]) do
		if v._type == DungeonEnumType.Normal then
			num = num + 1
		end
	end

	return num

end

function DungeonChapterVO:getDungeonList(diff)
	return self._diffDungeonDataList[dungeonData._diff]
end

--根据难度获取 该章节最后 一个副本配置数据
function DungeonChapterVO:getLastDungeonDataByDiff(diff)
	return self._diffDungeonDataList[ diff ][ #self._diffDungeonDataList[ diff ] ]
end

function DungeonChapterVO:create(id, name,teamLev)
	
	local dcData = DungeonChapterVO.new(id, name,teamLev)

	return dcData

end
