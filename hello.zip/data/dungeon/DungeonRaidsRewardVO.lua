--
-- Author: thisgf
-- Date: 2014-06-27 16:52:33

--副本扫荡条目
DungeonRaidsRewardVO = class("DungeonRaidsRewardVO")

DungeonRaidsRewardVO.index = 0 

DungeonRaidsRewardVO.exp = 0 --战队经验

DungeonRaidsRewardVO.coin = 0 --扫荡固定金币

DungeonRaidsRewardVO.itemTbl = nil --物品列表

function DungeonRaidsRewardVO:ctor()

end

function DungeonRaidsRewardVO:create()
	
	local drrData = DungeonRaidsRewardVO.new()
	drrData.itemTbl = {}
	return drrData
	
end

--每次扫荡的值
DungeonRaidsVO = class("DungeonRaidsVO")
DungeonRaidsVO.rewardTbl = nil
DungeonRaidsVO.dungeonId = 0
DungeonRaidsVO.diff = 0

function DungeonRaidsVO:ctor()

end

function DungeonRaidsVO:create()
	local ret = DungeonRaidsVO.new()
	ret.rewardTbl = {}
	return ret
end