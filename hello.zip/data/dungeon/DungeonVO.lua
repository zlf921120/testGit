--
-- Author: thisgf
-- Date: 2014-06-23 15:14:55
-- 副本数据

DungeonVO = class("DungeonVO")

--副本ID
DungeonVO._id = 0

--配置表中的位置
DungeonVO._index = 1

--副本名字
DungeonVO._name = nil

--所属章节
DungeonVO._chapterId = 0

--难度
DungeonVO._diff = 0

--描述
DungeonVO._desc = nil

--体力消耗
DungeonVO._physicalCost = 0

--失败体力消耗
DungeonVO._physicalCostFail = 0

--剩余次数
DungeonVO._remainTimes = 0

--进入最低等级
DungeonVO._joinLevel = 0

--分数(1-3)
DungeonVO._score = 0

--附带的原数据, 如果本身是原数据则为nil
DungeonVO._rawData = nil

--奖励ID列表
DungeonVO._rewardList = nil

--出现的怪物列表
DungeonVO._monsterList = nil

--每天刷的最大次数
DungeonVO._maxTimes = 0

--上一个副本的数据
DungeonVO._previousData = nil

--下一个副本的数据
DungeonVO._nextData = nil

--副本类型(普通/宝藏/资源)
DungeonVO._type = 0

DungeonVO._buyBattleTbl = nil --副本战斗 的可购买次数表 

DungeonVO._hasBeenBuyNum = 0 --已经购买过的次数

DungeonVO._hasBeenPassTime = 0 --已打过的次数

DungeonVO.treasureData = nil

DungeonVO.status = 0 --状态 [未开启/已打/刚开启]

function DungeonVO:ctor(id)
	
	self._id = id

	self._rewardList = {}
	self._monsterList = {}

	self.treasureData = DungeonTreasureVO:create()
	
end

function DungeonVO:getType()
	return self._type
end

function DungeonVO:create(id)

	local dungeonData = DungeonVO.new(id)

	return dungeonData
end


DungeonScheduleVO = class("DungeonScheduleVO")

--最大章节ID
DungeonScheduleVO._chapterId = 0

--最大副本ID
DungeonScheduleVO._dungeonId = 0

function DungeonScheduleVO:ctor(chapterId, dungeonId)
	self._chapterId = chapterId
	self._dungeonId = dungeonId
end

function DungeonScheduleVO:create(cid, did)
	
	local dsData = DungeonScheduleVO.new(cid, did)

	return dsData
end


--宝藏副本数据
DungeonTreasureVO = class("DungeonTreasureVO")

--奖励类型
DungeonTreasureVO.treasureType = nil

function DungeonTreasureVO:ctor()
end

function DungeonTreasureVO:create()
	local dtData = DungeonTreasureVO.new()
	return dtData
end


------------------------------------------------------------------------------


DungeonVo = class("DungeonVo")
