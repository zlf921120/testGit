--
-- Author: thisgf
-- Date: 2014-06-27 14:53:11
-- 副本扫荡页面

require "DungeonManager"
require "DungeonRaidsRewardVO"

DungeonRaidsView = class("DungeonRaidsView", AbstView.create)

--奖励项列表
DungeonRaidsView._itemList = nil

DungeonRaidsView._widgetGroup = nil

DungeonRaidsView._onTimerScrollFunc = nil


--扫荡面板
DungeonRaidsView._raidsPanel = nil

--抽奖10次面板
DungeonRaidsView._lotteryPanel = nil

--扫荡项列表
DungeonRaidsView._itemListView = nil
--扫荡奖励项种子
DungeonRaidsView._itemRaidsSeed = nil
--扫荡完成面板
DungeonRaidsView._completePanel = nil
--抽奖按钮
DungeonRaidsView._lotteryButton = nil
--扫荡界面退出按钮
DungeonRaidsView._raidsQuitButton = nil

--抽奖界面退出按钮
DungeonRaidsView._lotteryQuitButton = nil

DungeonRaidsView._diff = 0
DungeonRaidsView._dungeonId = 0

--副本扫荡项
local DungeonRaidsItem


local _widgetPath = "ui/dungeon/dungeon_ui_raids.ExportJson"

function DungeonRaidsView:ctor()

end

function DungeonRaidsView:init()

	self:_initData()
	self:_initUI()
end

function DungeonRaidsView:_initData()

	self._itemList = {}

	self._onTimerScrollFunc = function()
	    self:_timerScrollFunc()
	end

end

function DungeonRaidsView:_initUI()

	self:_initWidget(_widgetPath)

	self._itemListView = self:_getWidget("listview_raids", ComponentType.LIST_VIEW)
	self._itemListView:setTouchEnabled(false)

	self._lotteryPanel = self:_getWidget("panel_lottery_ten", ComponentType.LAYOUT)
	self._lotteryPanel:setVisible(true)

	self._lotteryTitle = self:_getWidget("lab_title","Label")

    self._itemRaidsSeed = self:_getWidget("image_raids_item", ComponentType.IMAGE_VIEW)
    -- self._itemRaidsSeed:setVisible(false)
    self._itemRaidsSeed:setEnabled(false)
    DungeonRaidsItem._seed = self._itemRaidsSeed

    self._completePanel = self:_getWidget("panel_raids_complete", ComponentType.LAYOUT)
    self._completePanel:retain()

    local function onButtonTouch(sender, event)

        if event == TOUCH_EVENT_ENDED then
	        if sender == self._raidsQuitButton or 
		       sender == self._lotteryQuitButton then
		        self:closeBySelf()
		    elseif sender == self._lotteryButton then
		    	--请求抽奖
		    	local dm = DungeonManager:getInstance()
		    	local costVo = dm:getDungeonDropCost(self._dungeonId,self._diff)
		    	if costVo.currency == 2 then --钻石
			    	require "ShopCfg"
			    	
			    	local params = {}
			    	local costVo = dm:getDungeonDropCost(self._dungeonId,self._diff)
			    	params.txt = string.format("確定要花費%d%s抽獎%d次抽獎嗎？",costVo.price * dm:getCurrentRaidsNum(),  CurrencyName[costVo.currency], dm:getCurrentRaidsNum())
			    	params.okFunc = function()
				    	dm:requestRaidsPayCard(self._dungeonId,self._diff)
			    	end
			    	WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
		    	else --金币
		    		dm:requestRaidsPayCard(self._dungeonId,self._diff)
		   		end
	        end
        end

    end 

    self._lotteryButton = self:_getWidget("button_raids_lottery", ComponentType.BUTTON)
    self._raidsQuitButton = self:_getWidget("button_raids_quit", ComponentType.BUTTON)
    self._lotteryCostLab = self:_getWidget("lab_cost","Label")
    self._lotteryCurrencyImg = self:_getWidget("img_unit","ImageView")
    self._lotteryLotteyNumLab = self:_getWidget("lab_lotterynum","Label")
    self._lotteryButton:addTouchEventListener(onButtonTouch)
    self._raidsQuitButton:addTouchEventListener(onButtonTouch)

    self._lotteryQuitButton = self:_getWidget("button_lottery_quit", ComponentType.BUTTON)
    self._lotteryQuitButton:addTouchEventListener(onButtonTouch)


    local raidsReward
    local raidsRewardData
    -- for i = 1, DungeonManager.MAX_RAIDS_NUM do

    -- 	raidsReward = DungeonRaidsItem:create(i)
    -- 	raidsReward:retain()

    -- 	table.insert(self._itemList, raidsReward)

    -- end

    self._completePanel:removeFromParentAndCleanup(false)

    Notifier.regist(CmdName.DUNGEON_SHOW_LOTTERY,function(tbl) 
    	self:_renderLotteryTenPanel(tbl)
    	self:_openLotteryTenPanel(true) 
    end)
end

function DungeonRaidsView:_timerScrollFunc()

	self._itemListView:setTouchEnabled(true)
end

function DungeonRaidsView:_openLotteryTenPanel(value)

	if value then
		self._itemListView:setEnabled(false)

		self._lotteryPanel:setEnabled(true)
	else
		self._itemListView:setEnabled(true)

		self._lotteryPanel:setEnabled(false)

		local dm = DungeonManager:getInstance()
		local costData = dm:getDungeonDropCost(self._dungeonId,self._diff)
		require "ShopCfg"
		self._lotteryCostLab:setText(costData.price * dm:getCurrentRaidsNum())
		if costData.currency == MoneyType.Diamond then 
        	self._lotteryCurrencyImg:loadTexture("diamond.png",UI_TEX_TYPE_PLIST)  --默认是钻石
    	elseif costData.currency == MoneyType.Coin then
       		self._lotteryCurrencyImg:loadTexture("gold.png",UI_TEX_TYPE_PLIST)
   		end
   		self._lotteryLotteyNumLab:setText(string.format("抽獎%d次",dm:getCurrentRaidsNum()))
	end
end

--渲染抽奖面板
function DungeonRaidsView:_renderLotteryTenPanel(tbl)
	local p_icon = self._lotteryPanel:getChildByName("p_icon")

	for i=701,721 do
		local child = self._lotteryPanel:getChildByTag(i)
		if child ~= nil then
			child:removeFromParentAndCleanup(true)
		end
	end

	local function playAnim(itemIconList)
		for i=1,#itemIconList do
			local arr = CCArray:create()
	        arr:addObject(CCDelayTime:create( i * 0.1 ))
	        arr:addObject(CCShow:create())
	        arr:addObject(CCEaseBackOut:create(CCScaleTo:create(0.2,0.7)))
	        arr:addObject(CCDelayTime:create( 0.1 ))
			local icon = itemIconList[i]
			icon:setScale(2)
			icon:runAction(CCSequence:create(arr))
		end
	end

	local idx = 0
	local num = #tbl
	local itemIconList = {}
	if num == 1 then
		idx = idx + 1
		local itemIcon = ItemIcon:create()
		itemIcon:setVisible(false)
		itemIcon:setBaseId( tbl[1].base_id )
		itemIcon:setItemNum( tbl[1].quantity )
		itemIcon:setTag(idx + 700)
		itemIcon:setPosition(ccp(195,276))
		self._lotteryPanel:addChild(itemIcon)

		table.insert(itemIconList,itemIcon)
	else
		local col = 5
		local row = 2

		for i=0,row - 1 do

			for j=0,col - 1 do
				idx = idx + 1
				if tbl[idx] ~= nil then
					local itemIcon = ItemIcon:create()
					itemIcon:setVisible(false)
					itemIcon:setBaseId( tbl[idx].base_id )
					itemIcon:setScale(0.7)
					itemIcon:setTag(idx + 700)
					itemIcon:setItemNum( tbl[idx].quantity )
					itemIcon:setPosition( ccp(p_icon:getPositionX() + j * 75 ,p_icon:getPositionY() - i * 90 ) )
					self._lotteryPanel:addChild(itemIcon)

					table.insert(itemIconList,itemIcon)
				end
			end
		end
	end

	playAnim(itemIconList)

	self._lotteryTitle:setText(string.format("抽獎%d次獎勵",num))
end

--扫荡物品动画
local function playAnimByTarget(target)

	local arr = CCArray:create()
    arr:addObject(CCDelayTime:create( 0.1 ))
    arr:addObject(CCEaseBackOut:create(CCScaleTo:create(0.3,1)))
	target:setScale(2)
	target:runAction(CCSequence:create(arr))
end

function DungeonRaidsView:open()

	print(" 打開掃蕩面板 ",os.clock())

	local num = DungeonManager:getInstance():getCurrentRaidsNum()
	local rewardData = self.params

	self._diff = rewardData.diff
	self._dungeonId = rewardData.dungeonId
	self._itemListView:removeAllItems()
	self._itemListView:refreshView()

	-- for i = 1, num do

	-- 	raidsItem = self._itemList[i]

	-- 	raidsItem:setData(rewardData.rewardTbl[i])

	-- end

-- TimerManager.addTimer(500,function()  --延时

	-- local t1 = os.clock()
	-- local tmpViewItemList = {}
	-- for i=1,num do
	-- 	local raidsItem = self._itemList[i]
	-- 	raidsItem:setData(rewardData.rewardTbl[i])
	-- 	table.insert( tmpViewItemList , raidsItem )
	-- end
	-- table.insert( tmpViewItemList, self._completePanel )
	-- print(" 設置掃蕩物品耗時 ", os.clock() - t1)

	if num == 10 or num == 3 or num == 1 then
		self._itemListView:setTouchEnabled(false)

		local idx = 0
		local function step_create()
			idx = idx + 1
			-- local item = tmpViewItemList[ idx ]
			-- if item ~= nil then
			if idx <= num + 1 then 
				
				local item = nil
				if idx == num + 1 then
					item = self._completePanel
				else
					item = self._itemList[idx]
					if item == nil then
						item = DungeonRaidsItem:create(idx)
				    	item:retain()
				    	table.insert(self._itemList, item)
					end
					item:setData(rewardData.rewardTbl[idx])
				end
				item:setEnabled(true) --一定要打开!!

				self._itemListView:pushBackCustomItem(item)
				self._itemListView:refreshView()
				if item ~= self._completePanel then
					item:playAnim(idx) --播放物品动画
				else
					playAnimByTarget(self._completePanel:getChildByName("ImageView_82"))
				end
				TimerManager.addTimer(100,function()
					self._itemListView:scrollToBottom(0.1,false)
				end)
			else
				--延时等 结算
				self._itemListView:stopAllActions()
				self._onTimerScrollFunc() --开启触摸
				self._itemListView:scrollToBottom(0.1,false)
			end
		end

		self._itemListView:stopAllActions()
		self._itemListView:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
			CCCallFunc:create(step_create),
			CCDelayTime:create(1))))
	end

-- end)

	self:_openLotteryTenPanel(false)

	print(" 打開掃蕩面板 結束 ",os.clock())
end

function DungeonRaidsView:close()

	-- self._itemListView:jumpToTop()
	-- TimerManager.removeTimer(self._onTimerScrollFunc)

end

function DungeonRaidsView:create()
	
	local drv = DungeonRaidsView.new()
	return drv

end

DungeonRaidsItem = class("DungeonRaidsItem", function() return DungeonRaidsItem._seed:clone() end)

DungeonRaidsItem._seed = nil
DungeonRaidsItem.itemIconList = nil
DungeonRaidsItem._titleLabel = nil
DungeonRaidsItem._expLabel = nil
DungeonRaidsItem._goldLabel = nil

function DungeonRaidsItem:ctor(index)

	self:setVisible(true)
	self:setEnabled(true)

	self._titleLabel = DisplayUtil.getWidgetByName(self, "label_raids_item_title", "Label")
	self._expLabel = DisplayUtil.getWidgetByName(self, "label_raids_item_exp", "Label")
	self._coinLabel = DisplayUtil.getWidgetByName(self,"lab_radis_gold","Label")

	self._titleLabel:setText(string.format("第%s戰", Utils.toChineseNum(index)))

	self.itemIconList = {}
end

function DungeonRaidsItem:setData(vo)

	for i=301,310 do
		local child = self:getChildByTag(i)
		if child ~= nil then
			child:removeFromParentAndCleanup(true)
		end
	end
	self.itemIconList = {}

	self._expLabel:setText(string.format("+%d", vo.exp))
	self._coinLabel:setText(string.format("+%d", vo.coin))

	local p_icon = DisplayUtil.getWidgetByName(self, "p_icon", "Label")
	for i=1,#vo.itemTbl do
		local itemVo = vo.itemTbl[i]
		local itemIcon = ItemIcon:create()
		itemIcon:setVisible(false)
		itemIcon:setBaseId(itemVo[1])
		itemIcon:setItemNum(itemVo[2])
		itemIcon:setTag(300 + i)
		itemIcon:setScale(0.8)
		itemIcon:setPosition(ccp(p_icon:getPositionX() + (i-1) * 100, p_icon:getPositionY() ))
		table.insert( self.itemIconList, itemIcon )
		self:addChild(itemIcon)
	end

end

function DungeonRaidsItem:create(index)

	local item = DungeonRaidsItem.new(index)

	return item

end

function DungeonRaidsItem:playAnim(idx)

	local function progress()
		for i=1,#self.itemIconList do
			local arr = CCArray:create()
	        arr:addObject(CCDelayTime:create( i * 0.1 ))
	        arr:addObject(CCShow:create())
	        arr:addObject(CCEaseBackOut:create(CCScaleTo:create(0.2,0.8)))
	        arr:addObject(CCDelayTime:create( 0.1 ))
			local icon = self.itemIconList[i]
			icon:setScale(2)
			icon:runAction(CCSequence:create(arr))
		end
	end

	-- self:runAction(CCSequence:createWithTwoActions(
	-- 	CCDelayTime:create(0.6),
	-- 	CCCallFunc:create(func)))
	

	if idx > 3 then
		local arr = CCArray:create()
		arr:addObject(CCMoveBy:create(0,ccp(0,35)))
		arr:addObject(CCMoveBy:create(0.2,ccp(0,-35)))
		arr:addObject(CCCallFunc:create(progress))
		self:runAction(CCSequence:create(arr))
	else
		progress()
	end
end
