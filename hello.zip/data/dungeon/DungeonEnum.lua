--
-- Author: thisgf
-- Date: 2014-11-15 15:46:07
-- 副本相关枚举

DungeonEnum = {}

DungeonEnum.treasureType = 
{
    GOLD = 1,
    ITEM = 2,
    DIAMOND = 3
}

DungeonDiffType = {
    --普通
    NORMAL = 1,
    --困难
    HARD = 2,
    --噩梦
    NIGHTMARE = 3   
}

--困难对应
DungeonType = 
{
    "普通",
    "困難",
    "噩夢",   
}

--副本类型
DungeonEnumType = {

    Normal = 0,  --普通副本
    Treasure = 1, --宝藏副本
    Resource = 2  --资源副本
}
