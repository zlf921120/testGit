DungeonDropVO = class("DungeonDropVO")
DungeonDropVO.id = 0
DungeonDropVO.currency = 0
DungeonDropVO.price = 0
