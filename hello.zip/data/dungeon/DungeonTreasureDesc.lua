require "DungeonCfg"

--宝藏副本 说明 面板
DungeonTreasureDesc = class("DungeonTreasureDesc",WindowBase)
DungeonTreasureDesc.__index = DungeonTreasureDesc
DungeonTreasureDesc._widget    = nil
DungeonTreasureDesc.uiLayer    = nil

local __instance = nil

function DungeonTreasureDesc:create()
    local ret = DungeonTreasureDesc.new()
    __instance = ret
    return ret   
end

local function event_btn_close(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		__instance:addCloseAnim()
	end
end

function DungeonTreasureDesc:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("dungeon/DungeonTeasureDesc.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)
    
	local btnClose = tolua.cast(self._widget:getChildByName("btn_close"),"Button")
	btnClose:addTouchEventListener(event_btn_close)
end

function DungeonTreasureDesc:open()

	local txt = self.params["txt"]

	local labDesc = tolua.cast(self._widget:getChildByName("lab_desc"),"Label")
	labDesc:setText(txt)

	self:addOpenAnim()
end

