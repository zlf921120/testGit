--
-- Author: thisgf
-- Date: 2014-06-23 15:06:42
-- 副本管理器

require "DungeonEnum"

DungeonManager = class("DungeonManager", IManager:create())

--最大扫荡次数
DungeonManager.MAX_RAIDS_NUM = 10


--配置的章节数据字典
DungeonManager._chapterDataDict = nil

--配置的副本数据字典
DungeonManager._dungeonDataDict = nil

--配置的副本数据列表
DungeonManager._dungeonDataList = nil

--配置的副本扫荡奖励数据列表
DungeonManager._raidsRewardDataList = nil

--配置的总章数
DungeonManager._maxChapter = 0
--配置的通关宝箱奖励
DungeonManager._dungeonBoxRewardDataList = nil
--配置的扫荡付费抽奖花费
DungeonManager._dungeonRadiPayDataList = nil

--章节进度返回的数据字典
DungeonManager._scheduleChapterDict = nil

--各难度进度的数据字典
DungeonManager._scheduleDict = nil

--进度副本数据字典
DungeonManager._scheduleDungeonDataDict = nil

--当前扫荡的次数
DungeonManager._currentRaidsNum = 0

--当前操作的副本数据
DungeonManager._currentHandleDungeonData = nil

--请求记录的时间
DungeonManager._requestRecordTime = 0

--奖励宝箱领取记录
DungeonManager._dungeonBoxList = nil
--副本章节元件
DungeonManager._chapterWidgetDict = nil

--资源本基础数据
DungeonManager._resDungeonBaseData = nil
--资源本进度数据
DungeonManager._resScheduleChapterDict = nil

--资源本开启的id列表
DungeonManager._resOpenDunIds = nil


local _instance = nil
local _allowInstance = false
local _hasLoad = false

function DungeonManager:ctor()

	self._logPrefix = "副本調試"

	self:_requireFile()

	self._chapterDataDict = {}
	self._dungeonDataDict = {}
	self._dungeonDataList = {}
	self._raidsRewardDataList = {}
	self._dungeonBoxRewardDataList = {}
	self._dungeonRadiPayDataList = {}

	self._scheduleChapterDict = {}
	self._scheduleDict = {}
	self._scheduleDungeonDataDict = {}
	self._dungeonBoxList = {}
	self._chapterWidgetDict = {}

	self._dungeonVoDic = {}
	self._dungeonVoDic[DungeonDiffType.NORMAL] = {}
    self._dungeonVoDic[DungeonDiffType.HARD] = {}
    self._dungeonVoDic[DungeonDiffType.NIGHTMARE] = {}
	self._dungeonVoTbl = {}
	self._dungeonVoTbl[DungeonDiffType.NORMAL] = {}
    self._dungeonVoTbl[DungeonDiffType.HARD] = {}
    self._dungeonVoTbl[DungeonDiffType.NIGHTMARE] = {}

    self._resDungeonBaseData = {}
    self._resScheduleChapterDict = {}

	-- self:_testDungeonData()

	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.dungeon_schedule_rsp, "onScheduleRsp()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.dungeon_schedule_one_rsp, "onUpdateScheduleOneRsp()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.dungeon_chapter_clearance_reward_rsp, "onGetDungeonBox()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.dungeon_pay_card_rsp, "onRaidsPayCard()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.dungeon_buy_num_rsp,"onDungeonBuyBattleNum()")
end

function DungeonManager:getInstance()
	
	if not _instance then
		_allowInstance = true
		_instance = DungeonManager.new()
		_allowInstance = false
	end

	return _instance

end

function DungeonManager:_requireFile()

	require "dungeon_pb"
	require "fnt_dungeon_data_pb"
	-- require "fnt_dungeon_drop_data_pb"
	require "fnt_drop_data_pb"

	require "DungeonCfg"
	require "DungeonVO"
	require "DungeonChapterVO"
	require "DungeonRaidsRewardVO"

	require "DungeonEnum"

	require "ResContendData"

end

--解析副本配置数据
function DungeonManager:parseDungeonData()

	--只加载一次
	if _hasLoad then 
		return 
	end
	_hasLoad = true

	local file = FileUtils.readConfigFile("fnt_dungeon_data.dat")

	local dungeon_data_pb = fnt_dungeon_data_pb.fnt_dungeon_data()
	dungeon_data_pb:ParseFromString(file)

	local chapterData = nil
	for k, v in pairs(dungeon_data_pb.chapter_data_rows) do
		
		if v and v.id then

			chapterData = DungeonChapterVO:create(v.id, v.name ,v.teamlev)

			self._chapterDataDict[v.id] = chapterData

			self._maxChapter = self._maxChapter + 1

		end
	end

	local lastDungeonData = nil
	local lastDungeonDict = nil
	local dungeonData = nil
	local index = 1

	local rewardList

	local diffDict = {}
	local lastId = 0
	local linkLastId = 0

	for k, v in pairs(dungeon_data_pb.base_data_rows) do
		
		if v and v.id then

			dungeonData = DungeonVO:create(v.id)
			dungeonData._diff = v.diff
			dungeonData._name = v.name
			dungeonData._chapterId = v.chapter_id
			dungeonData._desc = v.desc
			dungeonData._physicalCost = v.physical_cost
			dungeonData._physicalCostFail = v.physical_cost_fail
			dungeonData._joinLevel = v.join_level
			dungeonData._maxTimes = v.remaining_number
			-- dungeonData._type = v.box
			dungeonData._type = v.dun_type
			dungeonData._icon_name = v.icon_name

			if dungeonData._maxTimes == 0 then
				dungeonData._maxTimes = 99999999
			end
			dungeonData._remainTimes = dungeonData._maxTimes

			if v.reward_list and #v.reward_list > 0 then
				local rewardList = Utils.split(v.reward_list, ",")

				for reI, reId in ipairs(rewardList) do
					dungeonData._rewardList[reI] = tonumber(reId)
				end
			end

			if v.monster_list and #v.monster_list > 0 then
				local monsterList = Utils.split(v.monster_list, ",")

				for mI, mId in ipairs(monsterList) do
					dungeonData._monsterList[mI] = tonumber(mId)
				end
			end

			self._dungeonVoDic[v.diff][v.id] = dungeonData
			table.insert(self._dungeonVoTbl[v.diff],dungeonData)
			dungeonData._rawData = dungeonData

			if lastId ~= v.id then

				linkLastId = lastId

				dungeonData._index = index

				diffDict = {}
				self._dungeonDataDict[v.id] = diffDict
				self._dungeonDataList[index] = diffDict
				index = index + 1

				lastId = v.id
			end

			lastDungeonDict = self._dungeonDataDict[linkLastId]

			if lastDungeonDict then

				dungeonData._previsouData = lastDungeonDict[v.diff]
				lastDungeonDict[v.diff]._nextData = dungeonData

			end

			diffDict[v.diff] = dungeonData

			chapterData = self._chapterDataDict[v.chapter_id]
			
			if chapterData then
				chapterData:pushDungeon(dungeonData)
			end

		end
	end
----------通关物品----------------------------------------------------------------
	for k,v in pairs(dungeon_data_pb.chapter_clearance_reward_rows) do
		if v and v.chapter then
			table.insert(self._dungeonBoxRewardDataList,{chapter = v.chapter , difficulty = v.difficulty, type = v.reward_type , coin = v.coin, diamond = v.gold , goods = v.base_id })
		end
	end
-------副本购买通关次数-------------------------------------------------------------
	for k,v in pairs(dungeon_data_pb.buy_dungeon_num_rows) do
		if v and v.diff then
			for k,diffDict in pairs(self._dungeonDataDict) do
				dungeonData = diffDict[ v.diff ]
				if dungeonData ~= nil then
					if dungeonData._buyBattleTbl == nil then
						dungeonData._buyBattleTbl = {}
					end
					dungeonData._buyBattleTbl[ v.buy_num ] = { buy_num = v.buy_num,cost = v.loss_gold }
				end
			end
		end
	end

	for k, v in pairs(dungeon_data_pb.box_dungeon_reward_rows) do
		if v.id then
			dungeonData = self:getDungeonData(v.id, v.diff)
			dungeonData.treasureData.treasureType = v.type
		end
	end

	local resDungeonData
	for k, v in pairs(dungeon_data_pb.res_dungeon_rows) do
		if v.id then
			resDungeonData = ResDungeonBaseData:create()
			resDungeonData.baseId = v.id
			resDungeonData.monsterName = v.monster_name
			resDungeonData.monsterLevel = v.monster_level
			resDungeonData.monsterList = {}
			local monsters = loadstring("return {"..v.monsters.."}")()
			for _, md in ipairs(monsters) do
				resDungeonData.monsterList[md[2]] = md[1]
			end

			resDungeonData.produceType = v.produce_type
			resDungeonData.produceHour = v.produce_num
			resDungeonData.firstRewardType = v.first_reward_type
			resDungeonData.firstRewardQty = v.first_reward_num
			resDungeonData.fixRewardType = v.reward_type
			resDungeonData.fixRewardQty = v.reward_num

			self._resDungeonBaseData[v.id] = resDungeonData
		end
	end


end

--掉落物品配置表
function DungeonManager:parseDropData()

	local file = FileUtils.readConfigFile("fnt_drop_data.dat")

	local drop_data_pb = fnt_drop_data_pb.fnt_drop_data()
	drop_data_pb:ParseFromString(file)

	for k, v in pairs(drop_data_pb.pay_card_rows) do
		if v and v.id then
			table.insert(self._dungeonRadiPayDataList,{id = v.id , diff = v.diff, currency = v.currency,price = v.price})
		end
	end
end

function DungeonManager:setCurrentHandleDungeonData(data)
	self._currentHandleDungeonData = data
end

function DungeonManager:getCurrentHandleDungeonData()
	return self._currentHandleDungeonData
end

function DungeonManager:getBuyBattleCost(diff,dungeonId)

	local dungeonVo = self:getScheduleDungeonData(diff,dungeonId)
	local dungeonData = self:getDungeonData(diff,dungeonId)
	return dungeonData._buyBattleTbl[ dungeonVo._hasBeenBuyNum ].cost
end

--[[
    请求副本进度信息
]]
function DungeonManager:reqScheduleInfo()

	print("---------------------reqScheduleInfo-----------------------------")

	if self._requestRecordTime == 0 then

		-- self._requestRecordTime = os.clock()

	end

	local scheduleReq = dungeon_pb.dungeon_schedule_req()

	self:sendProto(scheduleReq)
end

--[[
    请求扫荡副本
    @param id 副本ID
    @param diff 副本难度
    @param num 扫荡次数
]]
function DungeonManager:reqRaids(id, diff, num)

	print("---------請求掃蕩副本------------------------",id, diff,num)

	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.dungeon_sweep_rsp, "onUpdateRaids()")

	local raidsReq = dungeon_pb.dungeon_sweep_req()
	raidsReq.id = id
	raidsReq.difficulty = diff
	raidsReq.sweep_number = num

	self._currentRaidsNum = num

	self:sendProto(raidsReq)

end

--[[
    请求单个副本进度
]]
function DungeonManager:reqOneSchedule(id, diff)

	print("---------請求單個副本進度------------------------",id, diff)

	local oneReq = dungeon_pb.dungeon_schedule_one_req()
	oneReq.id_difficulty.dungeon_id = id
	oneReq.id_difficulty.dungeon_difficulty = diff

	self:sendProto(oneReq)

end

--[[
    请求当前操作副本的进度
]]
function DungeonManager:reqCurrentOneSchedule()

	if not self._currentHandleDungeonData then
		return
	end

	self:reqOneSchedule(
		self._currentHandleDungeonData._id, 
		self._currentHandleDungeonData._diff
	)
	
end

--更新副本进度
function DungeonManager:_updateOneSchedule(dunId, diff, grade, passTimes)

	local dungeonVo = self:getDungeonData(dunId, diff)
	dungeonVo._score = grade
	dungeonVo._hasBeenPassTime = passTimes
	dungeonVo._remainTimes = dungeonVo._maxTimes - passTimes

	self:refreshDungeonVoList()
	self:refreshDiffSchedule()
end

----------------------------------------------
function DungeonManager:makeDungeonScheVoList(normalList,hardList,nightList)
	for i=1,#normalList do
		local v = normalList[i]
		if v.dunid ~= 0 then
			local dungeonVo = self:getDungeonData(v.dunid,DungeonDiffType.NORMAL)
			if dungeonVo then
				dungeonVo._score = v.grade
				dungeonVo._hasBeenPassTime = v.num
				dungeonVo.status = DungeonItemStatus.HasFight
				dungeonVo._remainTimes = dungeonVo._maxTimes - dungeonVo._hasBeenPassTime
			end
		end
	end
	for i=1,#hardList do
		local v = hardList[i]
		if v.dunid ~= 0 then
			local dungeonVo = self:getDungeonData(v.dunid,DungeonDiffType.HARD)
			dungeonVo._score = v.grade
			dungeonVo._hasBeenPassTime = v.num
			dungeonVo.status = DungeonItemStatus.HasFight
			dungeonVo._remainTimes = dungeonVo._maxTimes - dungeonVo._hasBeenPassTime
		end
	end
	for i=1,#nightList do
		local v = nightList[i]
		if v.dunid ~= 0 then
			local dungeonVo = self:getDungeonData(v.dunid,DungeonDiffType.NIGHTMARE)
			dungeonVo._score = v.grade
			dungeonVo._hasBeenPassTime = v.num
			dungeonVo.status = DungeonItemStatus.HasFight
			dungeonVo._remainTimes = dungeonVo._maxTimes - dungeonVo._hasBeenPassTime
		end
	end
end

function DungeonManager:refreshDungeonVoList()
	local normalLastIdx = 0 --最近已打关卡
	for i,dungeonVo in ipairs(self._dungeonVoTbl[DungeonDiffType.NORMAL]) do
		if dungeonVo._score ~= 0 or 
			dungeonVo._type == DungeonEnumType.Resource then
			normalLastIdx = normalLastIdx + 1
		else
			break
		end
	end
	if normalLastIdx + 1 < #self._dungeonVoTbl[DungeonDiffType.NORMAL] then
		local normalDungeonVo = self:getDungeonDataByIdx(DungeonDiffType.NORMAL,normalLastIdx + 1)
		normalDungeonVo.status = DungeonItemStatus.Open
	elseif normalLastIdx == 0 then --开启首个
		normalDungeonVo = self:getDungeonDataByIdx(DungeonDiffType.NORMAL,1)
		normalDungeonVo.status = DungeonItemStatus.Open
	end
-----------------------------------------------------------------------------------
	local hardLastIdx = 0 --最近已打关卡
	for i,dungeonVo in ipairs(self._dungeonVoTbl[DungeonDiffType.HARD]) do
		if dungeonVo._score ~= 0 then
			hardLastIdx = hardLastIdx + 1
		else
			break
		end
	end
	local hardDungeonVo = nil
	if normalLastIdx > hardLastIdx then
		if hardLastIdx ~= #self._dungeonVoTbl[DungeonDiffType.HARD] then
			hardDungeonVo = self:getDungeonDataByIdx(DungeonDiffType.HARD,hardLastIdx + 1)
			hardDungeonVo.status = DungeonItemStatus.Open
		end
	end
-----------------------------------------------------------------------------------
	local nightLastIdx = 0 --最近已打关卡
	for i,dungeonVo in ipairs(self._dungeonVoTbl[DungeonDiffType.NIGHTMARE]) do
		if dungeonVo._score ~= 0 then
			nightLastIdx = nightLastIdx + 1
		else
			break
		end
	end
	local nightDungeonVo = nil
	if hardLastIdx > nightLastIdx then
		if nightLastIdx ~= #self._dungeonVoTbl[DungeonDiffType.NIGHTMARE] then
			nightDungeonVo = self:getDungeonDataByIdx(DungeonDiffType.NIGHTMARE,nightLastIdx + 1)
			nightDungeonVo.status = DungeonItemStatus.Open
		end
	end

	--测试开启资源本
	-- for i, dungeonVo in ipairs(self._dungeonVoTbl[DungeonDiffType.NORMAL]) do
	-- 	if dungeonVo._type == DungeonEnumType.Resource then
	-- 		dungeonVo.status = DungeonItemStatus.Open
	-- 	end
	-- end

end

function DungeonManager:refreshDiffSchedule()
	--清空数据
	self._scheduleChapterDict[DungeonDiffType.NORMAL] = {}
	self._scheduleChapterDict[DungeonDiffType.HARD] = {}
	self._scheduleChapterDict[DungeonDiffType.NIGHTMARE] = {}

	for i=1,#self._dungeonVoTbl[DungeonDiffType.NORMAL] do
		local v = self._dungeonVoTbl[DungeonDiffType.NORMAL][i]
		if v.status == DungeonItemStatus.Open or v.status == DungeonItemStatus.HasFight then
			self._scheduleChapterDict[DungeonDiffType.NORMAL][v._chapterId] = self._scheduleChapterDict[DungeonDiffType.NORMAL][v._chapterId] or {}
			table.insert(self._scheduleChapterDict[DungeonDiffType.NORMAL][v._chapterId],v)
		end
	end

	for i=1,#self._dungeonVoTbl[DungeonDiffType.HARD] do
		local v = self._dungeonVoTbl[DungeonDiffType.HARD][i]
		if v.status == DungeonItemStatus.Open or v.status == DungeonItemStatus.HasFight then
			self._scheduleChapterDict[DungeonDiffType.HARD][v._chapterId] = self._scheduleChapterDict[DungeonDiffType.HARD][v._chapterId] or {}
			table.insert(self._scheduleChapterDict[DungeonDiffType.HARD][v._chapterId],v)
		end
	end
	for i=1,#self._dungeonVoTbl[DungeonDiffType.NIGHTMARE] do
		local v = self._dungeonVoTbl[DungeonDiffType.NIGHTMARE][i]
		if v.status == DungeonItemStatus.Open or v.status == DungeonItemStatus.HasFight then
			self._scheduleChapterDict[DungeonDiffType.NIGHTMARE][v._chapterId] = self._scheduleChapterDict[DungeonDiffType.NIGHTMARE][v._chapterId] or {}
			table.insert(self._scheduleChapterDict[DungeonDiffType.NIGHTMARE][v._chapterId],v)
		end
	end

	--测试添加资源本进度
	-- self._resScheduleChapterDict[DungeonDiffType.NORMAL] = {}
	-- for k, v in ipairs(self._dungeonVoTbl[DungeonDiffType.NORMAL]) do
	-- 	if v.status == DungeonItemStatus.Open and 
	-- 		v._type == DungeonEnumType.Resource then
	-- 		v._score = 0
	-- 		if not self._resScheduleChapterDict[DungeonDiffType.NORMAL][v._chapterId] then
	-- 			self._resScheduleChapterDict[DungeonDiffType.NORMAL][v._chapterId] = {}
	-- 		end
	-- 		table.insert(self._resScheduleChapterDict[DungeonDiffType.NORMAL][v._chapterId],v)
	-- 	end
	-- end

end

--更新难度的进度信息
function DungeonManager:_updateDiffSchedule(diff, chapterId)
	local scheduleDungeonList = self:getScheduleDungeonList(diff, chapterId)
	local dungeonLen = #scheduleDungeonList

	local chapterData = self:getChapterData(chapterId)

	local openChapter = 0
	local openDungeon = 0
	
	table.sort( scheduleDungeonList, function(a,b)
		return a._id > b._id
	end)
	--已经打到当前章节最后的副本
	local isHasFight = scheduleDungeonList[1].status == DungeonItemStatus.HasFight

	if dungeonLen == chapterData:getNumDungeonWithTreasure() and isHasFight then
		--已经打通当前难度所有副本
		-- print(" 通當前難度 ",chapterId,self._maxChapter,dungeonLen)
		if chapterId == self._maxChapter then
			openChapter = chapterId
		else
			openChapter = chapterId + 1
		end
	else
		openChapter = chapterId
	end
	
	for i, v in pairs(scheduleDungeonList) do
		if v._type ~= DungeonEnumType.Resource and 
			v._id > openDungeon then
			openDungeon = v._id
		end
	end

	local scheduleData = self._scheduleDict[diff]
	if not scheduleData then
		scheduleData = DungeonScheduleVO:create(openChapter, openDungeon)
		self._scheduleDict[diff] = scheduleData
	else
		scheduleData._chapterId = openChapter
		scheduleData._dungeonId = openDungeon
	end

end

function onScheduleRsp(protoData)

	print("---------------------------onScheduleRsp----------------------------------- ")

	local scheduleRsp = dungeon_pb.dungeon_schedule_rsp()
	scheduleRsp:ParseFromString(protoData)

	if scheduleRsp.ret ~= error_code_pb.msg_ret.success then
		_instance:log("查詢副本進度失敗:%d",  scheduleRsp.ret)
		return
	end

	_instance:initDungeonSchedule(scheduleRsp.progs_normal, scheduleRsp.progs_hard,
		scheduleRsp.progs_nightmare, scheduleRsp.chapter_info, scheduleRsp.buy_dungeon)

	ComSender:getInstance():dealExtInfo(scheduleRsp.ext)

end

--初始化副本进度
function DungeonManager:initDungeonSchedule(srv_progs_normal ,srv_progs_hard ,
									srv_progs_nightmare ,srv_chapter_info ,srv_buy_dungeon)

	_instance._scheduleDict = {}

	_instance._scheduleDungeonDataDict = {}
	_instance._scheduleDungeonDataDict[DungeonDiffType.NORMAL] = {}
	_instance._scheduleDungeonDataDict[DungeonDiffType.HARD] = {}
	_instance._scheduleDungeonDataDict[DungeonDiffType.NIGHTMARE] = {}

	local scheduleBase = nil
	local dungeonData = nil

	local function createDungeonVo(id,diff,score,passTimes)
		local dungeonVo = DungeonVO:create(id)
		dungeonVo._diff = diff
		dungeonVo._score = score
		dungeonVo._hasBeenPassTime = passTimes
	end

	self:makeDungeonScheVoList(srv_progs_normal,srv_progs_hard,srv_progs_nightmare)
	self:refreshDungeonVoList()
	self:refreshDiffSchedule()

	_instance._dungeonBoxList = {} --清空
	local chapter_info_num = #srv_chapter_info
	for i = 1, chapter_info_num do
		table.insert(_instance._dungeonBoxList,srv_chapter_info[i])
	end
	--------------------------已购买次数---------------------------------------------------
	local buyDungeonTbl = srv_buy_dungeon
	local buyDungeonTblNum = #buyDungeonTbl
	for i=1,buyDungeonTblNum do
		local v = buyDungeonTbl[i]
		local dungeonVo = _instance:getScheduleDungeonData(v.id,v.diff)
		dungeonVo._hasBeenBuyNum = v.num

		print(" 副本 已購買次數 ！！ ",v.id,v.diff,dungeonVo._hasBeenBuyNum)
	end
	
	_instance:_countDiffSchedule()

	Notifier.dispatchCmd(CmdName.DUNGEON_INIT_SCHEDULE)
end

--[[
    初始化资源本进度
]]
function DungeonManager:initResDungeonSchedule(openDungeonIds)

	self._resScheduleChapterDict[DungeonDiffType.NORMAL] = {}

	local isUpdateRes = false

	if self._resOpenDunIds then
		for i, v in ipairs(openDungeonIds) do
			if not self._resOpenDunIds[v] then
				isUpdateRes = true
				break
			end
		end
	end
	self._resOpenDunIds = openDungeonIds

	local dd
	for i, v in ipairs(openDungeonIds) do
		-- print("=============更新資源本", v)
		dd = self:getDungeonData(v, DungeonDiffType.NORMAL)
		if dd._type == DungeonEnumType.Resource then
			dd._score = 0
			dd.status = DungeonItemStatus.Open

			if not self._resScheduleChapterDict[DungeonDiffType.NORMAL][dd._chapterId] then
				self._resScheduleChapterDict[DungeonDiffType.NORMAL][dd._chapterId] = {}
			end
			table.insert(
				self._resScheduleChapterDict[DungeonDiffType.NORMAL][dd._chapterId],
				dd
			)
		end
	end

	if isUpdateRes then
		ResContendManager:getInstance():reqAllBrifeInfo()
	end

	Notifier.dispatchCmd(CmdName.DUNGEON_UPDATE_RES_SCHEDULE)

end

--统计各难度的进度
function DungeonManager:_countDiffSchedule()

	--统计进度
	local openMaxChapter = 0
	local openMaxChapterDL = nil

	for k,v in pairs(_instance._scheduleChapterDict) do

		openMaxChapter = 0
		openMaxChapterDL = nil

		for k1, v1 in pairs(v) do

			repeat
				local onlyRes = true
				for _, dunData in pairs(v1) do
					if dunData._type ~= DungeonEnumType.Resource then
						onlyRes = false
						break
					end
				end

				--资源本不用做判断进度
				if onlyRes then
					break
				end

				if k1 > openMaxChapter then

					openMaxChapter = k1
					openMaxChapterDL = v1
				end
			until true
		end

		if openMaxChapter ~= 0 then

			_instance:_updateDiffSchedule(k, openMaxChapter)

		end
		
	end

end


function onUpdateScheduleOneRsp(protoData)

	local scheduleOneRsp = dungeon_pb.dungeon_schedule_one_rsp()
	scheduleOneRsp:ParseFromString(protoData)

	if scheduleOneRsp.ret ~= error_code_pb.msg_ret.success then
		_instance:log("更新副本單個進度失敗:%d", scheduleOneRsp.ret)
		return
	end

	_instance:updateOneScheduleBySrv(scheduleOneRsp.base, 
				scheduleOneRsp.grade, scheduleOneRsp.number)

	ComSender:getInstance():dealExtInfo(scheduleOneRsp.ext)
end

function DungeonManager:updateOneScheduleBySrv(srv_base, srv_grade, srv_num)
	
	local baseData = srv_base	
	local dunId = baseData.dungeon_id
	local diff = baseData.dungeon_difficulty

	self:_updateOneSchedule(dunId, diff, srv_grade, srv_num)	

	_instance:_countDiffSchedule()

	local dungeonVo = self:getDungeonData(dunId,diff)

	-- print(" 更新副本單個進度 ------ >",diff, dungeonVo._chapterId, dunId, 
	-- 	srv_grade ,dungeonVo._remainTimes,dungeonVo._type)
	
	Notifier.dispatchCmd(CmdName.DUNGEON_UPDATE_ONE_SCHEDULE, 
		{diff, dungeonVo._chapterId, dunId, srv_grade
		,dungeonVo._remainTimes, dungeonVo._maxTimes, 
		dungeonVo._type})

end

--更新副本扫荡
function onUpdateRaids(protoData)

	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.dungeon_sweep_rsp, "onUpdateRaids()")

	local raidsRsp = dungeon_pb.dungeon_sweep_rsp()
	raidsRsp:ParseFromString(protoData)
	print("-----------------------onUpdateRaids-----------------------------------",raidsRsp.ret)

	if raidsRsp.ret ~= error_code_pb.msg_ret.success then
		if error_code_pb.msg_ret.err_not_physical == raidsRsp.ret then --体力不足直接弹面板
			CharacterNetTask:getInstance():requestCheckBuyPhysical() --请求购买体力
			Notifier.dispatchCmd(CmdName.DUNGEON_UPDATE_RAIDS, nil)
		else
			Alert:show(Helper.getErrStr(raidsRsp.ret))
			Notifier.dispatchCmd(CmdName.DUNGEON_UPDATE_RAIDS, nil)
		end
		return
	end

	local raidsVo = DungeonRaidsVO:create()

	for i=1,#raidsRsp.number_reward do
		local v = raidsRsp.number_reward[i]

		local rewardVo = DungeonRaidsRewardVO:create()
		rewardVo.index = v.sweep_number
		rewardVo.coin = v.mustcoin

		for j=1,#v.info do
			-- print(" v.info[j].base_id ",v.info[j].base_id)
			local itemModel = ItemManager:getInstance():getItemModelByBaseId(v.info[j].base_id)
			if itemModel.item_type == ItemHelper.itemType.team_exp then
				rewardVo.exp = v.info[j].num
			else
				table.insert(rewardVo.itemTbl, {v.info[j].base_id,v.info[j].num})
			end
		end
		table.insert(raidsVo.rewardTbl, rewardVo)
	end

	local items = raidsRsp.items
	local assets = raidsRsp.assets
	print(" 掃蕩物品！！ ",#items)
	ItemManager:getInstance():addMultiItem(items) --更新背包
	CharacterManager:getInstance():updateRoleAssets(assets) --更新资产

	--更新英雄信息
	local hero_upgrades = raidsRsp.hero_upgrades
	local hero_num = #raidsRsp.hero_upgrades
	for i=1,hero_num do
		HeroManager:getInstance():updateHeroInfoByClient(hero_upgrades[i].id, hero_upgrades[i].lev,
					 									hero_upgrades[i].exp)
		-- print("英雄ID~~~",hero_upgrades[i].id,"~~~~等級~~~", hero_upgrades[i].lev,"~~~經驗~~~",hero_upgrades[i].exp)
	end

	Notifier.dispatchCmd(CmdName.DUNGEON_UPDATE_RAIDS, raidsVo)

	TeamManager:getInstance():_initBaseData(raidsRsp.team_base)

	ComSender:getInstance():dealExtInfo(raidsRsp.ext)

	print(" 結束請求掃蕩開始展示！!!! ",os.clock())
end

local _tmpDiff = 0
local _tmpChapter = 0
local _tmpBoxType = 0 --记录已领取过的宝箱
function DungeonManager:requestDungeonBox(diff,chapterId,boxType)
	_tmpDiff = diff
	_tmpChapter = chapterId
	_tmpBoxType = boxType
	print("-----------requestDungeonBox------------------------ ",diff,chapterId,boxType)
	local oneReq = dungeon_pb.dungeon_chapter_clearance_reward_req()
	oneReq.chapter_info.chapter = chapterId
	oneReq.chapter_info.difficulty = diff
	oneReq.chapter_info.type = boxType

	self:sendProto(oneReq)
end

function onGetDungeonBox(protoData)

	local dungeon_chapter_clearance_reward_rsp = dungeon_pb.dungeon_chapter_clearance_reward_rsp()
	dungeon_chapter_clearance_reward_rsp:ParseFromString(protoData)

	print("-----------onGetDungeonBox-------------",dungeon_chapter_clearance_reward_rsp.ret)
	if dungeon_chapter_clearance_reward_rsp.ret == error_code_pb.msg_ret.success then

		local items = dungeon_chapter_clearance_reward_rsp.items
		local assets = dungeon_chapter_clearance_reward_rsp.assets

		ItemManager:getInstance():addMultiItem(items) --更新背包
		CharacterManager:getInstance():updateRoleAssets(assets) --更新资产

		table.insert(_instance._dungeonBoxList,{ difficulty = _tmpDiff,chapter = _tmpChapter ,type = _tmpBoxType})

		ComSender:getInstance():dealExtInfo(dungeon_chapter_clearance_reward_rsp.ext)

		Notifier.dispatchCmd(CmdName.DUNGEON_CB_CLOSE_BOX)
		Notifier.dispatchCmd(CmdName.DUNGEON_UPDATE_REARDBOX)
	else
		Alert:show(Helper.getErrStr(dungeon_chapter_clearance_reward_rsp.ret))
	end
end
---------------------------------------------------------------------------------------
function DungeonManager:requestRaidsPayCard(dungeonId,difficulty)

	print("-----------requestRaidsPayCard------------------------ ",dungeonId,difficulty,self._currentRaidsNum)
	local oneReq = dungeon_pb.dungeon_pay_card_req()
	oneReq.id = dungeonId
	oneReq.difficulty = difficulty
	oneReq.sweep_number = self._currentRaidsNum

	self:sendProto(oneReq)
end

function onRaidsPayCard(protoData)

	local dungeon_pay_card_rsp = dungeon_pb.dungeon_pay_card_rsp()
	dungeon_pay_card_rsp:ParseFromString(protoData)

	print("-----------onRaidsPayCard-------------",dungeon_pay_card_rsp.ret)
	if dungeon_pay_card_rsp.ret == error_code_pb.msg_ret.success then

		local items = dungeon_pay_card_rsp.items
		local assets = dungeon_pay_card_rsp.assets

		ItemManager:getInstance():addMultiItem(items) --更新背包
		CharacterManager:getInstance():updateRoleAssets(assets) --更新资产

		ComSender:getInstance():dealExtInfo(dungeon_pay_card_rsp.ext)

		Notifier.dispatchCmd(CmdName.DUNGEON_SHOW_LOTTERY,items)

	else
		Alert:show(Helper.getErrStr(dungeon_pay_card_rsp.ret))
	end
end
---------------------------------------------------------------------------------------
-- 请求副本购买战斗次数
local _tmpBuyBattleDungeonId = 0
local _tmpBuyBattleDungeonDiff = 0
function DungeonManager:requestDungeonBuyBattleNum(dungeonId,difficulty)
	print("-----------requestDungeonBuyBattleNum------------------------ ",dungeonId,difficulty)
	local oneReq = dungeon_pb.dungeon_buy_num_rep()
	oneReq.id = dungeonId
	oneReq.diff = difficulty

	_tmpBuyBattleDungeonId = dungeonId
	_tmpBuyBattleDungeonDiff = difficulty

	self:sendProto(oneReq)
end

-- 响应副本购买战斗次数
function onDungeonBuyBattleNum(pkg)
	local dungeon_buy_num_rsp = dungeon_pb.dungeon_buy_num_rsp()
	dungeon_buy_num_rsp:ParseFromString(pkg)

	print("-----------onDungeonBuyBattleNum-------------",dungeon_buy_num_rsp.ret)
	if dungeon_buy_num_rsp.ret == error_code_pb.msg_ret.success then

		local assets = dungeon_buy_num_rsp.assets
		CharacterManager:getInstance():updateRoleAssets(assets) --更新资产
		
		Alert:show("購買成功")

		local dungeonVo = _instance:getScheduleDungeonData(_tmpBuyBattleDungeonId ,_tmpBuyBattleDungeonDiff )
		dungeonVo._remainTimes = dungeonVo._rawData._maxTimes
		dungeonVo._hasBeenBuyNum = dungeon_buy_num_rsp.num

		-- print(" _tmpBuyBattleDungeonId ,_tmpBuyBattleDungeonDiff ",_tmpBuyBattleDungeonId ,_tmpBuyBattleDungeonDiff,dungeonVo._remainTimes)

		ComSender:getInstance():dealExtInfo(dungeon_buy_num_rsp.ext)

		Notifier.dispatchCmd(CmdName.DUNGEON_UPDATE_DESC)
		Notifier.dispatchCmd(CmdName.DUNGEON_UPDATE_ONE_SCHEDULE, 
		{dungeonVo._diff, dungeonVo._chapterId, dungeonVo._id, dungeonVo._score
		,dungeonVo._remainTimes, dungeonVo._maxTimes, 
			dungeonVo._type})

	else
		Alert:show(Helper.getErrStr(dungeon_buy_num_rsp.ret))
	end
end

--------------------------------------------------------------------------------------

--[[
    最大章节数
]]
function DungeonManager:getMaxChapter()
	return self._maxChapter
end

--[[
    获取配置的章节数据
]]
function DungeonManager:getChapterData(id)

	return self._chapterDataDict[id]
end

--[[
    获取配置的副本数据
    @param dungeonId
    @param diff 难度
]]
function DungeonManager:getDungeonData(dungeonId, diff)

	local diffDict = self._dungeonVoDic[diff]

	if diffDict == nil then
		return nil
	end

	return diffDict[dungeonId]
end

--[[
    通过位置获取配置副本数据
    @param index
    @param diff 难度
]]
function DungeonManager:getDungeonDataByIdx(diff,index)
	return self._dungeonVoTbl[diff][index]
end

--[[
    获取配置的扫荡数据
]]
function DungeonManager:getRaidsRewardData(index)
	return self._raidsRewardDataList[index]
end

--[[
    获取副本进度概况数据
    @return DungeonScheduleVO
]]
function DungeonManager:getScheduleData(diff)
	return self._scheduleDict[diff]
end

--[[
    获取副本进度章的副本数据列表
    @param diff 难度
    @param chapterId 章ID
    @return table {DungeonVO...}
]]
function DungeonManager:getScheduleDungeonList(diff, chapterId)
	local ret = nil
	for i=1,#self._dungeonVoTbl[ diff ] do
		local dungeonVo = self._dungeonVoTbl[ diff ][i]
		if dungeonVo._chapterId == chapterId then
			if dungeonVo.status == DungeonItemStatus.Open or 
				dungeonVo.status == DungeonItemStatus.HasFight then
				ret = ret or {}
				table.insert(ret,dungeonVo)
			end
		end
	end
	return ret
end

--[[
    获取进度的副本数据
    @return DungeonVO
]]
function DungeonManager:getScheduleDungeonData(dungeonId, diff)
	if dungeonId == nil or diff == nil then
		return nil
	end
	local dungeonVo = self._dungeonVoDic[diff][dungeonId]
	if dungeonVo == nil then
		return nil
	elseif dungeonVo.status == DungeonItemStatus.Open or 
		dungeonVo.status == DungeonItemStatus.HasFight then
		return dungeonVo
	else
		return nil
	end
end

--该副本 最多能购买多少次
function DungeonManager:getScheduleDungeonDataBuyLimit(dungeonId, diff)
	local dp = VipDataProxy:getInstance()
	local num = 0
	if diff == 2 then
		num = num + dp:getPrivilegeValue(VipPrivilegeType.DungeonDiff2)  --vip动态次数
	elseif diff == 3 then
		num = num + dp:getPrivilegeValue(VipPrivilegeType.DungeonDiff3)
	end
	return num
end

--[[
    副本进度字典
]]
function DungeonManager:getScheduleDict()
	return self._scheduleDict
end

--获取副本所有数据
function DungeonManager:getDungeonDataDic()
	return self._dungeonVoDic
end

--当前扫荡的次数
function DungeonManager:getCurrentRaidsNum()
	return self._currentRaidsNum
end

--获取该章节是否已经领取过宝箱
function DungeonManager:isHasGetBox(diff,chapterId,boxType)
	local ret = false
	for i=1,#self._dungeonBoxList do
		local item = self._dungeonBoxList[i]
		if item.chapter == chapterId and item.difficulty == diff and item.type == boxType then
			ret = true
			break
		end
	end
	return ret
end

--获取宝箱数据
function DungeonManager:getDungeonBoxReward(diff,chapterId,boxType)
	local ret = nil
	for i=1,#self._dungeonBoxRewardDataList do
		local item = self._dungeonBoxRewardDataList[i]
		if item.chapter == chapterId and item.difficulty == diff and item.type == boxType then
			ret = { coin = item.coin, diamond = item.diamond, goods = item.goods }
			break
		end
	end
	return ret
end

--获取抽奖花费
function DungeonManager:getDungeonDropCost(dungeonId,diff)
	-- print(" dungeonId,diff ",dungeonId,diff)
	local ret = nil
	for i=1,#self._dungeonRadiPayDataList do
		local item = self._dungeonRadiPayDataList[i]
		if item.id == dungeonId and item.diff == diff then
			ret = {currency = item.currency, price = item.price}
			break
		end
	end
	return ret
end

--该副本项是否开启
-- 返回剩余次数/是否开启
function DungeonManager:isCanOpenDungeon(dungeonId,diff)
	local retTbl = {}
	retTbl.isOpen = true
	retTbl.is_unlimit = false --是否无次数限制
	if dungeonId == nil or diff == nil then
		retTbl.isOpen = false
		return retTbl
	end

	local dungeonVo = self:getScheduleDungeonData(dungeonId,diff)
	if dungeonVo == nil then
		retTbl.isOpen = false
	else
		local teamlev = CharacterManager:getInstance():getTeamData():getLev()
		if self:getChapterData(dungeonVo._chapterId)._teamLev > teamlev then
			retTbl.isOpen = false
		end
	end

	if dungeonVo then
		retTbl.remainTimes = dungeonVo._remainTimes
		retTbl.maxTimes = dungeonVo._rawData._maxTimes
	else
		local rawData = self:getDungeonData(dungeonId,diff) --配置数据
		if rawData then
			retTbl.remainTimes = rawData._maxTimes
			retTbl.maxTimes = rawData._maxTimes
		end
	end

	if retTbl.maxTimes==99999999 then
		retTbl.is_unlimit =true
	end

	return retTbl
end

--获取副本元件
function DungeonManager:getChapterWidget(chapterId)
	local widget = self._chapterWidgetDict[ chapterId ]
	if widget == nil then
		CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGB565)
		widget = GUIReader:shareReader():widgetFromJsonFile(string.format("ui/dungeon/chapter/chapter_%d.json",chapterId))
		CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_Default)
		widget:retain()
		self._chapterWidgetDict[ chapterId ] = widget
	end
	return widget
end

function DungeonManager:cleanChapterWidget()

	for k,v in pairs(self._chapterWidgetDict) do
		v:removeFromParentAndCleanup(true)
		v:release()
		self._chapterWidgetDict[ k ] = nil
	end
end

--(凌晨5点)刷新副本
function DungeonManager:refreshDungeon(info)
	for diff,dungeonVoDic in pairs(self._dungeonVoDic) do
		for k,dungeonVo in pairs(dungeonVoDic) do
			dungeonVo._hasBeenBuyNum = 0
		end
	end
	for i,v in ipairs(info.buy) do
		local vo = self:getDungeonData(v.id,v.diff)
		if vo then
			vo._hasBeenBuyNum = v.num
		end
	end
	for i,v in ipairs(info.progs_normal) do
		local vo = self:getDungeonData(v.dunid,DungeonDiffType.NORMAL)
		if vo then
			vo._remainTimes = vo._rawData._maxTimes - v.num
		end
	end
	for i,v in ipairs(info.progs_hard) do
		local vo = self:getDungeonData(v.dunid,DungeonDiffType.HARD)
		if vo then
			vo._remainTimes = vo._rawData._maxTimes - v.num
		end
	end
	for i,v in ipairs(info.progs_nightmare) do
		local vo = self:getDungeonData(v.dunid,DungeonDiffType.NIGHTMARE)
		if vo then
			vo._remainTimes = vo._rawData._maxTimes - v.num
		end
	end
end

function DungeonManager:getResDungeonData(id)
	return self._resDungeonBaseData[id]
end

--[[
    获取资源副本进度列表
]]
function DungeonManager:getResDunScheduleList(diff, chapterId)
	if self._resScheduleChapterDict[diff] then
		return self._resScheduleChapterDict[diff][chapterId]
	end

	return nil
end

--[[
    获取资源本进度的副本数据
]]
-- function DungeonManager:getResScheduleDunData(diff, dungeonId)

-- end
