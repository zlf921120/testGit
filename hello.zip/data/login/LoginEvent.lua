
--登录事件

LoginEvent = 
{
	CB_PER_QUICK_LOGIN = "per_quick_login",     --准备 快速登录 面板
	CB_PER_NORMAL_LOGIN = "per_normal_login",	--准备 普通登录 面板
	CB_SHOW_ZONE_LIST = "login_show_zone_list", --展示 区域列表 
	CB_GET_SERVER_LIST = "login_get_server_lsit", --获取 服务器列表
	CB_FINISH_LOGIN = "login_CB_FINISH_LOGIN", --完成登录

	SHOW_ALERT = "login_show_alert",	--提示
	SHOW_LOADING = "login_show_loading", 
	HIDE_LOADING = "login_hide_loading",
	SHOW_MSGBOX = "login_show_msgbox",

	LOADING_NEXT_RES = "login_loading_next_res",
}