require "LoginZoneVo"

--登录 数据代理

LoginDataProxy = class("LoginDataProxy")
LoginDataProxy.voZoneList = {}
LoginDataProxy.voZoneMapList = {}
LoginDataProxy.loadingCout = 0
LoginDataProxy.loadingTotal = 0
LoginDataProxy.loadingResTotal = 0
LoginDataProxy.techTipList = {}
LoginDataProxy._isFinishLogin = 0

LoginDataProxy._acctId = 0
LoginDataProxy._acctName = "" 
LoginDataProxy.token = ""  --访问令牌
LoginDataProxy._channelId = 1 --先写死 1
LoginDataProxy._zoneId = 0
LoginDataProxy._zoneName = ""
LoginDataProxy._session = ""
LoginDataProxy._deviceId = 1

LoginDataProxy._isGetSrvZoneList = false --是否拿到区列表
LoginDataProxy.first_open_time = 0 --首服开启时间

local __instance = nil
local _allowInstance = false

function LoginDataProxy:ctor()
    if not _allowInstance then
		error("LoginDataProxy is a singleton class")
	end
	self:init()
end

function LoginDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = LoginDataProxy.new()
		_allowInstance = false
	end

	return __instance
end

function LoginDataProxy:isGetSrvZoneList()
	return self._isGetSrvZoneList
end

function LoginDataProxy:setIsGetZoneList(is_get)
	self._isGetSrvZoneList = is_get
end

function LoginDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function LoginDataProxy:init()
	self._channelId = SdkManager:getSdkPlatform() 
end

function LoginDataProxy:getChannelId()
	return self._channelId
end

function LoginDataProxy:getZoneVoList()
	return self.voZoneList
end

function LoginDataProxy:isFinishLogin()
	return self._isFinishLogin
end

--如果本地没有区的记录，则随机挑一个
function LoginDataProxy:getRdZoneId()
	local max_zone_id = 0
	for i,zone_vo in pairs(self.voZoneList) do
		if zone_vo and i>max_zone_id then
			max_zone_id = i
		end
	end
	return max_zone_id
end

function LoginDataProxy:getZoneVoById(zoneId)
	return self.voZoneList[zoneId]
end

function LoginDataProxy:setZoneVo(vo)	
	self.voZoneList[vo.zoneId] = vo	
end
-------------------------------------------------
function LoginDataProxy:createZoneVo()
	return ZoneVo.new()
end

function LoginDataProxy:getRandTechTip()
	return self.techTipList[ math.random(1,#self.techTipList) ]
end

function LoginDataProxy:setFirstOpenTime(srv_time_value)
	self.first_open_time = srv_time_value
end

function LoginDataProxy:getFirstOpenTime()
	return self.first_open_time
end