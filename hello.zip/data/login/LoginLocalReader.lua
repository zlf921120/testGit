
----------------------------------------------------------------------------
-- 登录 本地xls数据读取类
LoginLocalReader = class("LoginLocalReader")

local __instance = nil
local _allowInstance = false
local _hasLoad = false

function LoginLocalReader:ctor()
    if not _allowInstance then
		error("LoginLocalReader is a singleton class")
	end
	self:init()
end

function LoginLocalReader:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = LoginLocalReader.new()
		_allowInstance = false
	end

	return __instance
end

function LoginLocalReader:init()
	-- require "fnt_zone_data_pb"
	require "fnt_tip_data_pb"
	require "LoginDataProxy"
	--print("-------------LoginLocalReader init finish--------------")
end

--获取 本地数据并创建值对象 
function LoginLocalReader:loadInProxy()

	if _hasLoad then return end--只加载一次
	_hasLoad = true

	 local dp = LoginDataProxy:getInstance()
 --    local pbdata = FileUtils.readConfigFile("fnt_zone_data.dat")
    
 --    local msg = fnt_zone_data_pb.fnt_zone_data()
 --    msg:ParseFromString(pbdata)
  
	-- ------------区------------------------
 --    local zoneUnit = msg.zone_server_rows
 --    for i=1, #zoneUnit do    	
 --    	local zoneVo = dp:createZoneVo()
	-- 	local v = zoneUnit[i]
 --    	zoneVo.zoneId = v.zone_id
 --    	zoneVo.zoneName = v.name
 --    	dp:setZoneMapVo(zoneVo)
 --    end
    ---------------游戏 技巧 提示------------
    local pbData = FileUtils.readConfigFile("fnt_tip_data.dat")

    local msg = fnt_tip_data_pb.fnt_tip_data()
    msg:ParseFromString(pbData)
    
    local tipUnit = msg.tech_tip_rows
    for i=1,#tipUnit do
    	local v = tipUnit[i]
    	if v.content and v.content ~= "" then
    		table.insert( dp.techTipList ,v.content )
    	end
    end

end