--登录配置

LoginCfg = 
{
	Normal = 0, --正常登录
	Update = 1, --热更
}

-- 区 状态
ZoneStatus =
{
	Normal = 1,	--正常
	Full = 2,	--满员
}

-- 区状态颜色
ZoneStatusColor =
{
	ccc3(126,239,65),
	ccc3(0,147,243)
}

-- 区 状态 名字
ZoneStatusName = 
{
	"新服",
	"火爆",
}

--区真实状态
ZoneRealStatus = {}
ZoneRealStatus.st_stop = 0;    --停服维护
ZoneRealStatus.st_normal = 1;  --负载一般
ZoneRealStatus.st_busy = 2;    --繁忙
ZoneRealStatus.st_full = 3;    --满载，不能进入
