require "LoginCfg"
--服务区 值对象

ZoneVo = class("ZoneVo")
ZoneVo.id = 0
ZoneVo.name = ""
ZoneVo.status = 1 --服务器显示的状态，用来在区后面显示"火爆/暢通"这些字眼
ZoneVo.real_status = 1 --服务器真实的状态