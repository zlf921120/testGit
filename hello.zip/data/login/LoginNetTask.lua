
--登录网络代理
LoginNetTask = class("LoginNetTask")
LoginNetTask._isQuickLogin = true

local __instance = nil
local _allowInstance = false

function LoginNetTask:ctor()
    if not _allowInstance then
		error("LoginNetTask is a singleton class")
	end
	self:init()
end

function LoginNetTask:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = LoginNetTask.new()
		_allowInstance = false
	end

	return __instance
end

function LoginNetTask:destoryInstance()
	_allowInstance = false
	__instance = nil
end

-------------初始化---------------------------
local _accout = ""
local _passwd = ""

function LoginNetTask:init()
	require "proto_cmd_pb"
	require "proto_cmd_2_pb"
	require "zone_center_pb"
	require "zone_pb"
	require "ComSender"
	require "LoginCfg"
	require "LoginDataProxy"
	require "GmManager"
	
	--注册事件
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.acct_quick_register_rsp, "handleQuickLogin()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.acct_login_rsp, "handleManualLogin()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.acct_manual_register_rsp,"handleManualRegist()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.zone_login_rsp, "handleLoginZone()")
end

--请求快速登录
function LoginNetTask:requestQuickLogin()

	print("----------------------requestQuickLogin---------------------------")
	-- Notifier.dispatchCmd(LoginEvent.SHOW_LOADING)

	self._isQuickLogin = true

	-- local channelId = 1 --先写死 1
	local deviceId = 1 	--先写死 1
	
	local dp = LoginDataProxy:getInstance()
	-- dp._channelId = channelId
	dp._deviceId = deviceId

	local acct_quick_register_req = zone_center_pb.acct_quick_register_req()
	acct_quick_register_req.channel_id =  LoginDataProxy:getInstance()._channelId
	acct_quick_register_req.device_id = deviceId

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.acct_quick_register_req,acct_quick_register_req)
end

--响应快速登录
function handleQuickLogin(protoData)

	Notifier.dispatchCmd(LoginEvent.HIDE_LOADING)
	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.acct_quick_register_rsp, "handleQuickLogin()")

	local quickLoginRsp = zone_center_pb.acct_quick_register_rsp()
	quickLoginRsp:ParseFromString(protoData)

	local dp = LoginDataProxy:getInstance()
	dp._acctId = Global:getAcctId()

	dp._acctName = quickLoginRsp.acct_name
	dp._password = quickLoginRsp.password
	dp.token = quickLoginRsp.token

	Global:setStringForKey( "username", dp._acctName )
	Global:setStringForKey( "passwd", dp._password )

	print("----------------------handleQuickLogin-------------------------------------",quickLoginRsp.ret)

	if quickLoginRsp.ret == error_code_pb.msg_ret.success then
		-- Global:setSessionID()
		
  		__instance:setZoneData()

       	if __instance._isQuickLogin then  
			Notifier.dispatchCmd(LoginEvent.CB_PER_QUICK_LOGIN)
		else
			Notifier.dispatchCmd(LoginEvent.CB_PER_NORMAL_LOGIN)
		end

	else
		__instance:showAlert(Helper.getErrStr(quickLoginRsp.ret))
	end
end

--请求登录区
--zoneId已经无效，每次点击下拉选项时，会设置协议头的值，
--服务端用这个值判断具体登陆的区
function LoginNetTask:requestLoginZone(zoneId)

	print("--------------------requestLoginZone----------------------------")
	local dp = LoginDataProxy:getInstance()
	local zone_login_req = zone_pb.zone_login_req()

	local zone_data = dp:getZoneVoById(zoneId)
	-- cclog("去zoneId=%d",zoneId)
	--如果该区的状态是未开服，则显示二次确认框，并且点击确认后重新请求区列表
	if zone_data.real_status == ZoneRealStatus.st_stop then
		local params = {}
		params["okBtnName"] = "確定"
		params["isSingleBtn"] = 1
		params["okFunc"] = function()
			Global:reLogin()
			LoginNetTask:getInstance():requestZoneList(true)
		end

		if dp:getFirstOpenTime()>0 then
			local open_time_str =  Helper.unixTime2DateStr(dp:getFirstOpenTime())
			 params["rtf"]={{txt="不刪檔內測服將於", color=ItemHelper.colors.yellow, fontSize=22},
                				{txt=open_time_str, color=ItemHelper.colors.light_blue, fontSize=22},
                				{txt="開啟，敬請期待", color=ItemHelper.colors.yellow, fontSize=22}}
		else
			 params["rtf"]={{txt="伺服器正在維護,請稍後。", color=ItemHelper.colors.yellow, fontSize=22}}
		end

		Notifier.dispatchCmd(LoginEvent.SHOW_MSGBOX,params)
		return 
	end

	-- zone_login_req.acct_name = dp._acctName
	-- zone_login_req.acct_id = dp._acctId

	-- if Global:getTargetPlatform() == Helper.TargetPlatForms.ANDROID then
	if SdkLuaMgr:isAndroid() then
		zone_login_req.token = SdkManager:getSid()
		cclog("註冊返回的sid是%s",zone_login_req.token)
	else
		zone_login_req.token = dp.token
	end
	-- Global:setAcctId(dp._acctId)

	local one_srv_ext_info = nil
    local client_ext_login_infos = SdkLuaMgr:getInstance().ext_login_infos
    if client_ext_login_infos~=nil then
	    for client_key,client_value in pairs(client_ext_login_infos) do
	    	one_srv_ext_info = zone_login_req.ext_infos:add()
	    	one_srv_ext_info.key = client_key
	    	one_srv_ext_info.value = client_value
	    	cclog("ext_login_infos~~~~key=%s~~~~value=%s",client_key,client_value)
	    end
	end   

	if zone_data then
		Global:setServerInfo(zone_data.zoneIP, zone_data.zonePort)
		Global:setZoneID( zone_data.zoneId )
    	print("發送登陸協議前，重新設置區 ip 埠",zone_data.zoneIP, zone_data.zonePort)
    	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.zone_login_req,zone_login_req)
	end
end

--响应登录区
function handleLoginZone(protoData)
	-- Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.zone_login_rsp, "handleLoginZone()")

	local zone_login_rsp = zone_pb.zone_login_rsp()
	zone_login_rsp:ParseFromString(protoData)

	print("--------------handleLoginZone-----------------",zone_login_rsp.ret)

	if zone_login_rsp.ret == error_code_pb.msg_ret.success then  --登录部分 结束
		
		Global:setSessionID()

		local dp = LoginDataProxy:getInstance()
		dp._acctId = Global:getAcctId()

		GmManager:getInstance():init()  --初始化监听报错信息

		Notifier.dispatchCmd(LoginEvent.CB_FINISH_LOGIN)
		Notifier.dispatchCmd(LoginEvent.LOADING_NEXT_RES) --加载资源
		LoginScene:getInstance():removeArmatureInfo()

		SdkManager:setJavakeyValue("acct_id",dp._acctId)
	else
		__instance:showAlert(Helper.getErrStr(zone_login_rsp.ret))
	end
end

--请求手动登录
function LoginNetTask:requestManualLogin(accout,passwd)
	self._isQuickLogin = false
	
	print(" -----------------requestManualLogin--------------------  ",accout,passwd)
	-- Notifier.dispatchCmd(LoginEvent.SHOW_LOADING)

	local acct_login_req = zone_center_pb.acct_login_req()
	acct_login_req.acct_name = accout
	acct_login_req.password = passwd

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.acct_login_req,acct_login_req)

	local dp = LoginDataProxy:getInstance()
	dp._acctName = accout
	dp._password = passwd
end

--响应手动登录
function handleManualLogin(protoData)

	-- Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.acct_login_rsp, "handleManualLogin()")

	local loginRsp = zone_center_pb.acct_login_rsp()
	loginRsp:ParseFromString(protoData)

	print("------------------------handleManualLogin---------------------------",loginRsp.ret)
	Notifier.dispatchCmd(LoginEvent.HIDE_LOADING)

	local dp = LoginDataProxy:getInstance()
	dp._acctId = Global:getAcctId()
	dp.token = loginRsp.token
	
	if loginRsp.ret == error_code_pb.msg_ret.success then
		Global:setStringForKey( "username", dp._acctName )
		Global:setStringForKey( "passwd", dp._password )

		-- Global:setSessionID()
		
		__instance:setZoneData()

       	-- __instance:requireLoginZone(zoneVo.zoneId)
       	if __instance._isQuickLogin then  
			Notifier.dispatchCmd(LoginEvent.CB_PER_QUICK_LOGIN)
		else
			Notifier.dispatchCmd(LoginEvent.CB_PER_NORMAL_LOGIN)
		end

	else
		__instance:showAlert(Helper.getErrStr(loginRsp.ret))
	end

end

--请求 手动注册
function LoginNetTask:requestManualRegist(accout,passwd)

	print("--------------requestManualRegist-------------------")
	local acct_manual_register_req = zone_center_pb.acct_manual_register_req()
	acct_manual_register_req.channel_id = LoginDataProxy:getInstance()._channelId
	acct_manual_register_req.device_id = 1
	acct_manual_register_req.acct_name = accout
	acct_manual_register_req.password = passwd
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.acct_manual_register_req,acct_manual_register_req)

	_accout = accout
	_passwd = passwd
end
--响应 手动注册
function handleManualRegist(pkg)
	
	local acct_manual_register_rsp = zone_center_pb.acct_manual_register_rsp()
	acct_manual_register_rsp:ParseFromString(pkg)

	print("--------------handleManualRegist-------------------",acct_manual_register_rsp.ret)

	if acct_manual_register_rsp.ret == error_code_pb.msg_ret.success then
		local accoutName = acct_manual_register_rsp.acct_name

		local acct_id = Global:getAcctId()
		local dp = LoginDataProxy:getInstance()
		dp._acctId = acct_id
		dp._acctName = accoutName
		
		--注册完 手动登录
		__instance:requestManualLogin(_accout,_passwd)
	else
		__instance:showAlert(Helper.getErrStr(acct_manual_register_rsp.ret))
	end
end

--请求 服务器列表
function LoginNetTask:requestZoneList(reqServer)	
	
	local zoneinfo_req = zone_center_pb.zc_zone_list_req()
	zoneinfo_req.channel_id = 1
	
	local handleZoneListInner = function(pkg)		
		self:handleZoneList(pkg)
	end
	
	Notifier.regist( CmdName.REQ_ZONE_LIST, handleZoneListInner )
	
	--发送获取大区请求
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.zc_zone_list_rsp, "handleZoneListBridge()")

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.zc_zone_list_req, zoneinfo_req)
	--Global:sendPkg( proto_cmd_pb.msg_cmd.zc_zone_list_req, zoneinfo_req:SerializeToString(), zoneinfo_req:ByteSize() )	
end

function handleZoneListBridge(pkg)
	local dp = LoginDataProxy:getInstance()
	dp:setIsGetZoneList(true)

	Global:UnregisterNetworkCmd(proto_cmd_pb.msg_cmd.zc_zone_list_rsp, "handleZoneListBridge()")
	Notifier.dispatchCmd( CmdName.REQ_ZONE_LIST, pkg )
end

--响应 服务器列表
function LoginNetTask:handleZoneList(pkg)
	print(" ------------------handleZoneList-------------------  ")

	Notifier.removeByName( CmdName.REQ_ZONE_LIST )
	local zoneRsp = zone_center_pb.zc_zone_list_rsp()
	zoneRsp:ParseFromString(pkg)	
	
	if zoneRsp.ret == error_code_pb.msg_ret.success then
		local zoneListNum = #(zoneRsp.zones)
		local dp = LoginDataProxy:getInstance()

		for k=1, zoneListNum do
			local zone_info = zoneRsp.zones[k]
			local itemVo = dp:createZoneVo()
			
			itemVo.zoneId = zone_info.zone_id
			itemVo.zoneIP = zone_info.ip
			itemVo.zonePort = zone_info.port
			itemVo.status = zone_info.show_status
			itemVo.real_status = zone_info.real_status
			itemVo.zoneName = zone_info.zone_name
			dp:setZoneVo(itemVo)
			cclog( "get zone info,id:%d, ip:%s, port:%d, status:%d, zone_name:%s", 
				itemVo.zoneId, itemVo.zoneIP, itemVo.zonePort, itemVo.status, itemVo.zoneName)
		end
		dp:setFirstOpenTime(zoneRsp.first_open_time)
		Notifier.dispatchCmd( LoginEvent.CB_GET_SERVER_LIST )
	else
		cclog( "Req zones list fail:%d", zoneRsp.ret )
	end	
end
--------------------------------------------------------------
function handleSocketErr(strErr)
	print(" handleSocketErr --  strErr -- ",strErr)

	if ComSender:getInstance():isHeartBeatCMD() then
		cclog("心跳包，不需要二次確認")
		return
	end

	Notifier.dispatchCmd(LoginEvent.HIDE_LOADING)
	Notifier.dispatchCmd(CmdName.ERR_SERVER,strErr)

	-- if SceneCtrl:getInstance()._currentSceneName ~= CmdName.LOGIN_SCENE then--非登录场景
	-- 	Alert:show(strErr)
	-- else --登录场景
	-- 	Notifier.dispatchCmd(LoginEvent.SHOW_ALERT,strErr)
	-- end
	
	--if strErr == "SEND_FAIL" then --发包失败
		if SceneCtrl:getInstance()._currentSceneName ~= CmdName.LOGIN_SCENE then --非登录场景
			local isSingle = 0
			if BattleManager:getInstance():isBattle() then
				isSingle = 1
			end
			WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {txt = "您的網路連接延時，\n請點擊重試。",
				okBtnName = "重試",
				isSingleBtn = isSingle,
				okFunc = function()
				    if BattleManager:getInstance():isBattle() then
				    	BattleManager:getInstance():sendLastPkg()
				    else
						ComSender:getInstance():sendLastPkg()
				    end
				end})
		else --登录场景
			Notifier.dispatchCmd(LoginEvent.SHOW_MSGBOX,
			{txt = "您的網路連接延時，\n請點擊重試。",
				okBtnName = "重試",
				okFunc = function()
					ComSender:getInstance():sendLastPkg()
				end})
		end
	--end
end

function handleLoadingStatus(loading_status)

	print("============================收到網路載入狀態", loading_status)

	if loading_status=="1" then
		--区分是否登录场景
		if ComSender:getInstance():isHeartBeatCMD() then
			cclog("心跳包，不需要轉圈圈鎖屏")
			return
		end
		if SceneCtrl:getInstance()._currentSceneName ~= CmdName.LOGIN_SCENE then
			Loading:show()
		else
			Notifier.dispatchCmd(LoginEvent.SHOW_LOADING)
		end
		Global:setLoadingStatus(1)
	else
		if SceneCtrl:getInstance()._currentSceneName ~= CmdName.LOGIN_SCENE then
			Loading:hide()
		else
			Notifier.dispatchCmd(LoginEvent.HIDE_LOADING)
		end
		Global:setLoadingStatus(0)
	end

end

--------------------------------------------------------------
function LoginNetTask:showAlert(txt)
    Notifier.dispatchCmd(LoginEvent.SHOW_ALERT,txt) --提示信息
end


function LoginNetTask:setZoneData()

	--默认选区
	local dp = LoginDataProxy:getInstance()
	local zoneId = tonumber(Global:getStringForKey( "zoneId" ))
	local zoneVo = LoginDataProxy:getInstance():getZoneVoById( zoneId or dp:getRdZoneId() )   
	
	--如果区不存在，则再随机一次
	if zoneVo == nil then
		zoneVo = LoginDataProxy:getInstance():getZoneVoById( dp:getRdZoneId() )
	end

	Global:setStringForKey( "zoneId",zoneVo.zoneId )
	Global:setServerInfo(zoneVo.zoneIP, zoneVo.zonePort)
	Global:setZoneID( zoneVo.zoneId )
	
    print("設置區 ip 埠",zoneVo.zoneIP, zoneVo.zonePort)
    
    dp._zoneId = zoneVo.zoneId
    dp._zoneName = zoneVo.zoneName
end