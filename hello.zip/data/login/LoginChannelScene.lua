require "SceneCtrl"
require "SdkHelper"

--渠道 图标 过度 场景
ChannelScene = class("ChannelScene",function()
    return CCScene:create()
end)
ChannelScene.__index = ChannelScene
ChannelScene._widget = nil
ChannelScene._uiLayer = nil

local __instance = nil

function ChannelScene:create(func)
    local ret = ChannelScene.new(func)
    ret:init(func)
    __instance = ret
    return ret
end

local ChannelLogoType = {}
ChannelLogoType.None = 0 --没渠道、公司闪屏
ChannelLogoType.Only_Cp = 1 --只有公司闪屏
ChannelLogoType.Only_Channel = 2 --只有渠道闪屏
ChannelLogoType.Both_cp_channel = 3 --公司和渠道都闪屏

--闪屏项列表
local channelLogoList = {}
channelLogoList[SdkHelper.channel.downjoy] = ChannelLogoType.Only_Channel
channelLogoList[SdkHelper.channel.lunplay] = ChannelLogoType.Only_Channel
channelLogoList[SdkHelper.channel.lunplay_ios] = ChannelLogoType.Only_Channel

function ChannelScene:init(func)
    local channelType = channelLogoList[ SdkManager:getSdkPlatform() ] or ChannelLogoType.Only_Cp
    local param = {}
    local arr = CCArray:create()

    local function showCp(container,param)--显示公司logo
        CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/login/img_company.plist")
        container.imgCompany = ImageView:create()
        container.imgCompany:loadTexture("img_company.png",UI_TEX_TYPE_PLIST)
        container.imgCompany:setPosition(ccp(480,320))
        container:addChild(container.imgCompany)

        local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
        local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()

        container.imgCompany:setScaleX(1/globa_scalx*DisplayUtil.min_scale)
        container.imgCompany:setScaleY(1/globa_scaly*DisplayUtil.min_scale)
    end

    local function showChannel(container,param)--显示渠道logo
        local bgColor = CCLayerColor:create( param.bgColor or ccc4(255,255,255,255))
        container:addChild(bgColor)

        container.imgChannel = ImageView:create()
        -- 时间关系，特殊处理
        if SdkLuaMgr:getInstance():getSdkPlatform()==SdkHelper.channel.lunplay or 
         SdkLuaMgr:getInstance():getSdkPlatform()==SdkHelper.channel.lunplay_ios then
            container.imgChannel:loadTexture("ui/login/img_channel_lunplay.png")
        else
            container.imgChannel:loadTexture("ui/login/img_channel.png")
        end    

        container.imgChannel:setPosition(ccp(480,320))
        container:addChild(container.imgChannel)
    end

    if channelType == ChannelLogoType.None then


    elseif channelType == ChannelLogoType.Only_Cp then

        showCp(self,param)
        
    elseif channelType == ChannelLogoType.Only_Channel then

        showChannel(self,param)

    elseif channelType == ChannelLogoType.Both_cp_channel then

        showCp(self,param)

        arr:addObject(CCDelayTime:create( param.delay or 0.2))
        arr:addObject(CCCallFuncN:create(function()
            showChannel(self,param)
        end))
    end

    if func then
        arr:addObject(CCCallFuncN:create(func))
    else
        arr:addObject(CCDelayTime:create(0.1)) --延时
        arr:addObject(CCCallFuncN:create(function() 
            SceneCtrl:getInstance():goToScene(CmdName.LOGIN_SCENE)
        end))
    end
    self:runAction(CCSequence:create(arr))
end
