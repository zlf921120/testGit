
--登录 场景 
LoginScene = class("LoginScene",function()
	return DisplayUtil.newFitLayer()
end)
LoginScene.__index = LoginScene
LoginScene._widget = nil
LoginScene._uiLayer = nil
LoginScene._armaturePathMap = nil

local __instance = nil

function LoginScene:create(type)
    local ret = LoginScene.new()
    ret:init(type)
    __instance = ret
    return ret
end

-------------响应事件-----------------------------------------------
local lastPanel = nil

local panelOpening = nil 		--开场面板
local panelQuicklogin = nil 	--快速登录 面板
local panelNormallogin = nil 	--普通登录 面板
local panelServer = nil		 	--服务器面板
local panelRegist = nil 		--注册面板
local panelAccout = nil 		--账号面板
local panelLoading = nil 		--进度条面板
---------------开场面板-----------------------------------------------
local btnQuicklogin = nil
local btnAccoutlogin = nil
----------------快速登录 面板--------------------
local btnQuickGo = nil
local btnQuickChangeZone = nil
local labQuickZoneId = nil
local labQuickZoneName = nil
local btnQuickBack = nil
----------------普通登录 面板--------------------
local btnAccountGo = nil
local btnAccoutChangeZone = nil
local btnAccoutChangeAccout = nil
local labAccoutZoneId = nil
local labAccoutZoneName = nil
local labAccoutNickName = nil
----------------输入账号 面板-----------------------
local btnAccoutOk = nil
local btnAgainRegist = nil
local inputAccout = nil
local inputPasswd = nil
-- local btnBackAccout = nil
----------------注册账号 面板--------------------
local btnRegistOk = nil
local inputAccoutRegist = nil
local inputPasswdRegist = nil
local btnBackRegist = nil
local ckbShowpasswd = nil
-----------------服务器 面板----------------------
local listZone = nil
local btnLastZone = nil
-- local btnBackServer = nil
------------------进度条面板----------------------
local progLoading = nil
local labLoadingTip = nil
local labLoadingPerc = nil

local function event_btn_quicklogin(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		
		if SdkLuaMgr:getInstance():isAndroid() then
			if SdkLuaMgr:getInstance():isSdkInit() and
			LoginDataProxy:getInstance():isGetSrvZoneList() then
				SdkLuaMgr:getInstance():login()
			end
		else
			-- local seq = CCSequence:createWithTwoActions(
			-- 	CCScaleTo:create(0.1,0.01),
			-- 	CCCallFuncN:create(function(node)
					LoginNetTask:getInstance():requestQuickLogin()
				-- end))
		  -- 	pSender:runAction(seq)
	      	
	      	-- btnAccoutlogin:runAction(CCScaleTo:create(0.1,0.01))
		end
    end
end

local function event_btn_accoutlogin(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then

		if SdkLuaMgr:getInstance():isAndroid() then
			if SdkLuaMgr:getInstance():isSdkInit() and
				LoginDataProxy:getInstance():isGetSrvZoneList() then
				SdkLuaMgr:getInstance():login()
			end
		else
			lastPanel:setVisible(false)
			lastPanel:setZOrder(1)

			panelAccout:setVisible(true)
	        panelAccout:setZOrder(4)
	        lastPanel = panelAccout

	        local username = Global:getStringForKey("username")
	        if username ~= nil then
	        	local passwd = Global:getStringForKey("passwd")
	        	inputAccout:setText(username)
				inputPasswd:setText(passwd)
	        end
    	end
        
	end
end

---------------账号面板-----------------------------------------------
local function event_btn_back_accout(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		lastPanel:setVisible(false)
		lastPanel:setZOrder(1)

		panelOpening:setVisible(true)
        panelOpening:setZOrder(4)
        lastPanel = panelOpening
        print(" Global:reLogin()  ")
        Global:reLogin()
	end
end

local function event_btn_regist_accout(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then

		lastPanel:setVisible(false)
		lastPanel:setZOrder(1)

		panelRegist:setVisible(true)
        panelRegist:setZOrder(4)
        lastPanel = panelRegist
	end
end

local function event_btn_ok_accout(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		if string.len(inputAccout:getText()) == 0 then
			return Notifier.dispatchCmd(LoginEvent.SHOW_ALERT,"帳號不能為空")
		end
		LoginNetTask:getInstance():requestManualLogin(inputAccout:getText(),inputPasswd:getText())
	end
end

---------------快速登录 面板----和 普通 登录面板-------------------------------
local function event_btn_go(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then

		if SdkLuaMgr:getInstance():isAndroid() and 
			SdkLuaMgr:getInstance():isLogin() == false then
			SdkLuaMgr:getInstance():login()
			return
		end
		
		local zoneId = tonumber(Global:getStringForKey( "zoneId" ))
		LoginNetTask:getInstance():requestLoginZone(zoneId)
	end
end

local function event_goto_loading()

	lastPanel:setVisible(false)
	lastPanel:setZOrder(1)

	panelLoading:setVisible(true)
    panelLoading:setZOrder(4)
    lastPanel = panelLoading
end

local function event_btn_change_zone(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		Notifier.dispatchCmd(LoginEvent.CB_SHOW_ZONE_LIST)
	end
end

local function event_btn_change_accout(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		
		if SdkLuaMgr:getInstance():isAndroid() then --如果是sdk，则弹出sdk用户登陆界面
			-- 
			if SdkLuaMgr:getInstance():isLogin() then
				SdkLuaMgr:getInstance():logout()
			else
				SdkLuaMgr:getInstance():login()
			end
			
		else
			lastPanel:setVisible(false)
			lastPanel:setZOrder(1)

			panelAccout:setVisible(true)
	        panelAccout:setZOrder(4)
	        lastPanel = panelAccout
		end
		
        print(" Global:reLogin()  ")
        Global:reLogin()

        btnBackAccout:setEnabled( not (Global:getStringForKey("username") ~= nil) )
	end
end

-- local function event_btn_quick_back(pSender,eventType)
-- 	if eventType == ComConstTab.TouchEventType.ended then
-- 		lastPanel:setVisible(false)
-- 		lastPanel:setZOrder(1)

-- 		panelOpening:setVisible(true)
--         panelOpening:setZOrder(4)
--         lastPanel = panelOpening

--         print(" Global:reLogin()  ")
--         Global:reLogin()
-- 	end
-- end
-----------------------注册 面板------------------------------------------
local function event_btn_back_regist(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		lastPanel:setVisible(false)
		lastPanel:setZOrder(1)

		panelAccout:setVisible(true)
        panelAccout:setZOrder(4)
        lastPanel = panelAccout
	end
end

local function event_btn_regist_ok(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		if string.len(inputAccoutRegist:getText()) == 0 then
			return Notifier.dispatchCmd(LoginEvent.SHOW_ALERT,"帳號不能為空")
		end
		if string.len(inputPasswdRegist:getText()) == 0 then
			return Notifier.dispatchCmd(LoginEvent.SHOW_ALERT,"密碼不能為空")
		end
		LoginNetTask:getInstance():requestManualRegist(inputAccoutRegist:getText(),inputPasswdRegist:getText())
	end
end

local function event_ckb_showpasswd(pSender,eventType)
	if eventType == ComConstTab.CheckBoxEventType.selected then
        inputPasswdRegist:setInputFlag(kEditBoxInputFlagInitialCapsAllCharacters)
    elseif eventType == ComConstTab.CheckBoxEventType.unselected then
        inputPasswdRegist:setInputFlag(kEditBoxInputFlagPassword)
    end
    local lastTxt = inputPasswdRegist:getText() --刷新
    inputPasswdRegist:setText(lastTxt.."x")
 	inputPasswdRegist:setText(lastTxt)
end
------------------------服务器 列表-----------------------------------------
local function event_btn_lastzone(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		--debug
		lastPanel:setVisible(false)
		lastPanel:setZOrder(1)

		panelAccout:setVisible(true)
        panelAccout:setZOrder(4)
        lastPanel = panelAccout
	end
end

-------------------------------------------------------------------------
--跳转 快速登录面板
local function event_cb_quick_login()
	lastPanel:setVisible(false)
	lastPanel:setZOrder(1)

	panelQuicklogin:setVisible(true)
    panelQuicklogin:setZOrder(4)
    lastPanel = panelQuicklogin

    --渲染预备入口
    LoginRenderMgr.renderQuickLogin(labQuickZoneId,labQuickZoneName)
------------------------------------------------------------------------------
    --直接进入游戏
    -- LoginNetTask:getInstance():requestRoleInfo()
end

--跳转 普通登录面板
local function event_cb_normal_login()

	lastPanel:setVisible(false)
	lastPanel:setZOrder(1)

	panelNormallogin:setVisible(true)
    panelNormallogin:setZOrder(4)
    lastPanel = panelNormallogin

    LoginRenderMgr.renderNormalLogin(labAccoutZoneId,labAccoutZoneName,labAccoutNickName)
end

--跳转 服务器列表
local function event_cb_show_zonelist()

	lastPanel:setVisible(false)
	lastPanel:setZOrder(1)

	panelServer:setVisible(true)
	panelServer:setZOrder(4)
	lastPanel = panelServer

	LoginRenderMgr.renderZoneList(listZone)
end
---------------------------------------------------------------------
--更新进度条
local function event_update_progloading(cout,total)

	local value = 0
	if cout >= total then 
		value = 100

		progLoading:setPercent(value)
		labLoadingPerc.lab:setText(string.format("%d%%",value))
	else
		value = cout / total * 100

		progLoading:setPercent(value)
		labLoadingPerc.lab:setText(string.format("%d%%",value))
	end

	__instance.armLoading:setPositionX( __instance.armLoading_x + cout/total * progLoading:getSize().width)
end

function LoginScene:updateProgloading(cout,total)
	event_update_progloading(cout,total)
end

local function execute_loaded_data()

	local idxData = LoginDataProxy:getInstance().loadingResTotal
    local function dataLoaded()
    	idxData = idxData + 1 
    	event_update_progloading(idxData, LoginDataProxy:getInstance().loadingResTotal + LoginDataProxy:getInstance().loadingTotal)
    	if idxData == LoginDataProxy:getInstance().loadingResTotal + LoginDataProxy:getInstance().loadingTotal then

        	__instance:runAction(CCCallFunc:create(function()
				SceneCtrl:getInstance():goToScene(CmdName.MAIN_SCENE)
        	end))
    	end
    end

    local arr = CCArray:create()
    for i=1,LoginDataProxy:getInstance().loadingTotal do
    	arr:addObject(CCDelayTime:create(0.05))
    	arr:addObject(CCCallFunc:create(function()
    		SceneInit:getInstance().loadFuncMap[i]()
    	end))
    	arr:addObject(CCDelayTime:create(0.05))
    	arr:addObject(CCCallFunc:create(function()
    		dataLoaded()
    	end))
    	-- arr:addObject(CCDelayTime:create(0.1))
    end
    __instance:runAction(CCSequence:create(arr))
end

local function event_execute_loading()
	--初始化 表数据 加载队列
	SceneInit:getInstance()

	local idxImage = 0
	
	local loadFuncMap = {}
	execute_loaded_data()
	-- local function imageLoaded(pObj)
 --        idxImage = idxImage + 1
 --        event_update_progloading(idxImage,#loadFuncMap + LoginDataProxy:getInstance().loadingTotal)
 --        if idxImage == #loadFuncMap then

 --        	__instance:runAction(CCCallFunc:create(function()
	-- 			execute_loaded_data()
 --        	end))
 --        end
 --    end

 --    local function getRealFullPath(short_path)
 --    	return CCFileUtils:sharedFileUtils():fullPathForFilename(short_path)
 --    end

 -- --    table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/common/common.png"), imageLoaded) end)
	-- -- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/common/other.pvr.ccz"), imageLoaded) end)
	-- -- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/main_scene0.pvr.ccz"), imageLoaded) end)
	-- -- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/main_scene1.png"), imageLoaded) end)
	-- -- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/main_scene2.png"), imageLoaded)			end)
	-- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/butterfly/butterfly0.png"), imageLoaded)	end)
	-- -- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/danjinbi/danjinbi0.png"), imageLoaded)		end)
	-- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/duanweisai/duanweisai0.png"), imageLoaded)	end)
	-- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/duplicate/duplicate0.png"), imageLoaded)	end)
	-- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/forever_tower/forever_tower0.png"), imageLoaded)	end)
	-- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/forge/forge0.png"), imageLoaded)			end)
	-- -- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/goumaijinbi/goumaijinbi0.png"), imageLoaded)	end)
	-- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/guild/guild0.png"), imageLoaded)	end)
	-- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/honour_road/honour_road0.png"), imageLoaded)	end)
	-- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/mystery_trader/mystery_trader0.png"), imageLoaded)	end)
	-- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/sea/sea0.png"), imageLoaded)	end)
	-- -- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/sea/sea1.png"), imageLoaded)	end)
	-- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/shop/shop0.png"), imageLoaded)	end)
	-- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/treasure/treasure0.png"), imageLoaded)	end)
	-- table.insert(loadFuncMap,function() Global:getInstance():addImageAsync(getRealFullPath("ui/main_scene/water/water0.png"), imageLoaded)	end)	
	-- for i=1,#loadFuncMap do 
	-- 	loadFuncMap[i]()
	-- end
	LoginDataProxy:getInstance().loadingResTotal = #loadFuncMap
end

------------------------------------------------------------------------
local function event_show_alert(txt)
	--弹出提示信息
	local child = __instance._uiLayer:getChildByTag(1005)
	if child ~= nil then
		__instance._uiLayer:removeChildByTag(1005,true)
	end

	local alert = Alert:create()
	alert:setText(txt)
	alert:setTag(1005)
	alert:animate()
	alert:setPosition(ccp(480,320))
	__instance._uiLayer:addChild(alert)
end

local function event_hide_loading()
	local loading = __instance._uiLayer:getChildByTag(1006)
	if loading ~= nil then
		__instance._uiLayer:removeChildByTag(1006,true)
	end
end

local function event_show_loading()
	local loading = __instance._uiLayer:getChildByTag(1006)
	if loading ~= nil then return end
	require "Loading"
	local loading = Loading:getInstance()
	loading:playAnim()
	loading:setTag(1006)
	__instance._uiLayer:addChild(loading)
end

local function event_show_msgbox(params)
	local msgBox = __instance._uiLayer:getChildByTag(1007)
	if msgBox ~= nil then return end
	require "MsgBox"
	local msgBox = WarningBox:getInstance()
	msgBox:setTag(1007)
	msgBox:open(params)
	if params and params.is_double_btn then
		msgBox:isSingleBtn(false)
	else
		msgBox:isSingleBtn(true)
	end
	__instance._uiLayer:addChild(msgBox)
end

---------------------------------------------------------------
local function event_cb_get_serverlist()
	panelServer:removeChildByTag(3352,true)

	local dp = LoginDataProxy:getInstance()
	local zoneId = tonumber(Global:getStringForKey( "zoneId" ))
	local zoneVo = dp:getZoneVoById( zoneId ) or dp:getZoneVoById( dp:getRdZoneId() )
	local zoneItem = ZoneItem:create(zoneVo)
	zoneItem:setTag(3352)
	panelServer:addChild(zoneItem)
	zoneItem:setPosition( ccp(panelServer:getChildByName("p_lastzone"):getPosition()) )

	--如果是安卓端，而且不是更新类型，则执行sdk相关流程，否则执行正常游戏流程
	if __instance.view_type == 0 and SdkLuaMgr:getInstance():isAndroid() then
		-- if SdkLuaMgr:getInstance():isSdkInit() then
			SdkLuaMgr:getInstance():login()
		-- end
	else
		local username = Global:getStringForKey("username")
		local passwd = Global:getStringForKey( "passwd" )
		if username ~= nil then --已有账号
			inputAccout:setText( username )
			inputPasswd:setText( passwd or "" )
			LoginNetTask:getInstance():requestManualLogin(username,passwd)
		end
	end
end

local function event_finish_login()

end
--------------------初始化-------------------------------------------

function LoginScene:dispose(t)
	if self._widget  then
		self._widget:removeFromParentAndCleanup(true)
	end
	self:removeNotifier()
	self:removeFromParentAndCleanup(true)
	__instance = nil
end

function LoginScene:init(t)

	require "LoginDataProxy"
	require "LoginEvent"
	require "Alert"
	require "SoundLocalReader"
	require("ItemHelper")
	self.view_type = t or 0
	if t == 0 then --0正常登录  1热更用(无逻辑)
		require "LoginNetTask"
		require "LoginRenderMgr"
		require "LoginLocalReader"
		require "LoginZoneItem"
		Global:reLogin()
		
		LoginLocalReader:getInstance():loadInProxy()
	end
----------------加载本地数据---------------------------------------------
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/login/ZoneItem0.plist")
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/login/login.plist")
	SoundLocalReader:getInstance():loadInProxy()

	self._armaturePathMap = {}

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/login/loginScene.ExportJson")
	self._uiLayer = TouchGroup:create()
	self._uiLayer:addWidget(self._widget)
	self:addChild(self._uiLayer)

	self._widget:getChildByName("panel_hero"):setVisible(true)

	TimerManager.addTimer(100,function()

		local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
	 	local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()
		local imgBg = ImageView:create()
		imgBg:setPosition(ccp(480,320))
		imgBg:setScaleX(1/DisplayUtil.min_scale*globa_scalx)
	 	imgBg:setScaleY(1/DisplayUtil.min_scale*globa_scaly)
		imgBg:loadTexture("ui/login/resource/img/login_bg.png")
		self._widget:getChildByName("panel_bg"):addChild(imgBg)
	end)

	TimerManager.addTimer(300,function()

		local armaturePath = "ui/login/resource/effect/dljm_lizi_xia/dljm_lizi_xia.ExportJson"
		table.insert(self._armaturePathMap,armaturePath)
		CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(armaturePath)
		local armYun = CCArmature:create("dljm_lizi_xia")
		armYun:setPosition(ccp(313,0))
		armYun:getAnimation():play("Animation1",0,-1,1)
		self._widget:getChildByName("panel_bg"):addNode(armYun,1)
		self.yun = armYun
	end)

	TimerManager.addTimer(500,function()

		armaturePath = "ui/login/resource/effect/dljm_lizi_shang/dljm_lizi_shang.ExportJson"
		table.insert(self._armaturePathMap,armaturePath)
		CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(armaturePath)
		local armWeapeon = CCArmature:create("dljm_lizi_shang")
		armWeapeon:setPosition(ccp(313,0))
		armWeapeon:getAnimation():play("Animation1",0,-1,1)
		self._widget:getChildByName("panel_hero"):addNode(armWeapeon,6)
	end)

	TimerManager.addTimer(600,function()

		armaturePath = "ui/login/resource/effect/dljm_hongqiu/dljm_hongqiu.ExportJson"
		table.insert(self._armaturePathMap,armaturePath)
		CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(armaturePath)
		local armHeroPifeng = CCArmature:create("dljm_hongqiu")
		armHeroPifeng:setPosition(ccp(109,477+50))
		armHeroPifeng:getAnimation():play("Animation1",0,-1,1)
		self._widget:getChildByName("panel_hero"):addNode(armHeroPifeng,5)

		armaturePath = "ui/login/resource/effect/dljm_lanqiu/dljm_lanqiu.ExportJson"
		table.insert(self._armaturePathMap,armaturePath)
		CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(armaturePath)
		local armHeroFazhang = CCArmature:create("dljm_lanqiu")
		armHeroFazhang:setPosition(ccp(566,537+30))
		armHeroFazhang:getAnimation():play("Animation1",0,-1,1)
		self._widget:getChildByName("panel_hero"):addNode(armHeroFazhang,4)
	end)

	TimerManager.addTimer(800,function()

		armaturePath = "ui/login/resource/effect/dljm_ziqiu/dljm_ziqiu.ExportJson"
		table.insert(self._armaturePathMap,armaturePath)
		CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(armaturePath)
		local armHeroFazhang = CCArmature:create("dljm_ziqiu")
		armHeroFazhang:setPosition(ccp(480-140+1,320+3))
		armHeroFazhang:getAnimation():play("Animation1",0,-1,1)
		self._widget:getChildByName("panel_hero"):addNode(armHeroFazhang,3)

	end)

	panelOpening = tolua.cast(self._uiLayer:getWidgetByName("panel_opening"),"Layout")
	panelQuicklogin = tolua.cast(self._uiLayer:getWidgetByName("panel_quicklogin"),"Layout")
	panelNormallogin = tolua.cast(self._uiLayer:getWidgetByName("panel_normallogin"),"Layout")
	panelServer = tolua.cast(self._uiLayer:getWidgetByName("panel_server"),"Layout")
	panelRegist = tolua.cast(self._uiLayer:getWidgetByName("panel_regist"),"Layout")
	panelAccout = tolua.cast(self._uiLayer:getWidgetByName("panel_accout"),"Layout")
	panelLoading = tolua.cast(self._widget:getChildByName("panel_loading"),"Layout")
	lastPanel = panelOpening
---------------开场面板-----------------------------------------------
	btnQuicklogin = tolua.cast(panelOpening:getChildByName("btn_quick"),"Button")
  	btnQuicklogin:addTouchEventListener(event_btn_quicklogin)
  	btnQuicklogin:setScale(1)
  	-- btnQuicklogin:setScale(0.01)
  	-- btnQuicklogin:runAction(CCSequence:createWithTwoActions(
  	-- 	CCDelayTime:create(1.5),
  	-- 	CCEaseBounceOut:create(CCScaleTo:create(0.5,1))))
    btnAccoutlogin = tolua.cast(panelOpening:getChildByName("btn_accout"),"Button")
    btnAccoutlogin:addTouchEventListener(event_btn_accoutlogin)
    btnAccoutlogin:setScale(1)
    -- btnAccoutlogin:setScale(0.01)
    -- btnAccoutlogin:runAction(CCSequence:createWithTwoActions(CCDelayTime:create(1.5),
  		-- CCEaseBounceOut:create(CCScaleTo:create(0.5,1))))
---------------快速登录 面板-----------------------------------------------
	btnQuickGo = tolua.cast(panelQuicklogin:getChildByName("btn_login"),"Button")
	btnQuickGo:addTouchEventListener(event_btn_go)
	btnQuickChangeZone = tolua.cast(panelQuicklogin:getChildByName("btn_server"),"Button")
	btnQuickChangeZone:addTouchEventListener(event_btn_change_zone)
	labQuickZoneId = tolua.cast(panelQuicklogin:getChildByName("lab_zone"),"Label")
	labQuickZoneName = tolua.cast(panelQuicklogin:getChildByName("lab_zone_name"),"Label")
	
---------------普通登录 面板-----------------------------------------------
	btnAccountGo = tolua.cast(panelNormallogin:getChildByName("btn_login"),"Button")
	btnAccountGo:setScale(1)
	btnAccountGo:addTouchEventListener(event_btn_go)
	-- btnAccountGo:runAction(CCSequence:createWithTwoActions(
 --  		CCDelayTime:create(1.5),
 --  		CCEaseBounceOut:create(CCScaleTo:create(0.5,1))))
	btnAccoutChangeZone = tolua.cast(panelNormallogin:getChildByName("btn_change_zone"),"Button")
	btnAccoutChangeZone:setScale(1)
	btnAccoutChangeZone:addTouchEventListener(event_btn_change_zone)
	-- btnAccoutChangeZone:runAction(CCSequence:createWithTwoActions(
 --  		CCDelayTime:create(1.5),
 --  		CCEaseBounceOut:create(CCScaleTo:create(0.5,1))))
	btnAccoutChangeAccout = tolua.cast(panelNormallogin:getChildByName("btn_change_accout"),"Button")
	btnAccoutChangeAccout:setScale(1)
	btnAccoutChangeAccout:addTouchEventListener(event_btn_change_accout)
	-- btnAccoutChangeAccout:runAction(CCSequence:createWithTwoActions(
 --  		CCDelayTime:create(1.5),
 --  		CCEaseBounceOut:create(CCScaleTo:create(0.5,1))))
	labAccoutZoneId = tolua.cast(btnAccoutChangeZone:getChildByName("lab_zoneid"),"Label")
	labAccoutZoneName = tolua.cast(btnAccoutChangeZone:getChildByName("lab_zonename"),"Label")
	labAccoutNickName = tolua.cast(btnAccoutChangeAccout:getChildByName("lab_nickname"),"Label")
--------------账号 面板 -----------------------------------------------------
	inputAccout = CCEditBox:create(CCSize(250,35),CCScale9Sprite:create("ui/login/resource/img/img_empty.png"))
	local x,y = panelAccout:getChildByName("img_inputbg1"):getPosition()
	inputAccout:setPosition(ccp(x + 78 ,y))
	inputAccout:setTouchPriority(-1)
	inputAccout:setMaxLength(12)
	inputAccout:setPlaceHolder("請輸入帳號")
	inputAccout:setFontColor(ccc3(245,204,85))
	inputAccout:setPlaceholderFontColor(ccc3(245,204,85))
    inputAccout:setInputMode(kEditBoxInputModeSingleLine)
	inputAccout:setFontSize(24)	
	panelAccout:addNode(inputAccout,2)

	inputPasswd = CCEditBox:create(CCSize(250,35),CCScale9Sprite:create("ui/login/resource/img/img_empty.png"))
	local x,y =  panelAccout:getChildByName("img_inputbg2"):getPosition()
	inputPasswd:setPosition(ccp(x + 78,y))
	inputPasswd:setTouchPriority(-1)
	inputPasswd:setMaxLength(12)
	inputPasswd:setPlaceHolder("請輸入密碼")
	inputPasswd:setFontColor(ccc3(245,204,85))
	inputPasswd:setPlaceholderFontColor(ccc3(245,204,85))
    inputPasswd:setInputFlag(kEditBoxInputFlagPassword)
    inputPasswd:setInputMode(kEditBoxInputModeSingleLine)
	inputPasswd:setFontSize(24)
	panelAccout:addNode(inputPasswd,2)

	btnBackAccout = tolua.cast(panelAccout:getChildByName("btn_back"),"Button")
	btnBackAccout:addTouchEventListener(event_btn_back_accout)

	btnAccoutOk = tolua.cast(panelAccout:getChildByName("btn_ok"),"Button")
	btnAccoutOk:addTouchEventListener(event_btn_ok_accout)
	btnRegistAccout = tolua.cast(panelAccout:getChildByName("btn_regist"),"Button")
	btnRegistAccout:addTouchEventListener(event_btn_regist_accout)
---------------注册 面板--------------------------------------------------
	inputAccoutRegist = CCEditBox:create(CCSize(250,35),CCScale9Sprite:create("ui/login/resource/img/img_empty.png"))
	local x,y = panelRegist:getChildByName("img_inputbg1"):getPosition()
	inputAccoutRegist:setPosition(ccp(x + 78,y))
	inputAccoutRegist:setTouchPriority(-1)
	inputAccoutRegist:setMaxLength(12)
	inputAccoutRegist:setPlaceHolder("請輸入帳號")
	inputAccoutRegist:setFontColor(ccc3(245,204,85))
	inputAccoutRegist:setPlaceholderFontColor(ccc3(245,204,85))
    inputAccoutRegist:setInputMode(kEditBoxInputModeSingleLine)
	inputAccoutRegist:setFontSize(22)
	panelRegist:addNode(inputAccoutRegist,2)

	inputPasswdRegist = CCEditBox:create(CCSize(250,35),CCScale9Sprite:create("ui/login/resource/img/img_empty.png"))
	local x,y = panelRegist:getChildByName("img_inputbg2"):getPosition()
	inputPasswdRegist:setPosition(ccp( x + 78,y))
	inputPasswdRegist:setTouchPriority(-1)
	inputPasswdRegist:setPlaceHolder("請輸入密碼")
	inputPasswdRegist:setFontColor(ccc3(245,204,85))
	inputPasswdRegist:setPlaceholderFontColor(ccc3(245,204,85))
	inputPasswdRegist:setMaxLength(12)
    inputPasswdRegist:setInputFlag(kEditBoxInputFlagPassword)
    inputPasswdRegist:setInputMode(kEditBoxInputModeSingleLine)
	inputPasswdRegist:setFontSize(22)
	panelRegist:addNode(inputPasswdRegist,2)

	btnBackRegist = tolua.cast(panelRegist:getChildByName("btn_back"),"Button")
	btnBackRegist:addTouchEventListener(event_btn_back_regist)
	btnRegistOk = tolua.cast(panelRegist:getChildByName("btn_ok"),"Button")
	btnRegistOk:addTouchEventListener(event_btn_regist_ok)
	ckbShowpasswd = tolua.cast(panelRegist:getChildByName("ckb_showpasswd"),"CheckBox")
	ckbShowpasswd:addEventListenerCheckBox(event_ckb_showpasswd)
----------------服务器 列表---------- ----------------------------------
	listZone = tolua.cast(panelServer:getChildByName("list_server"),"ListView")
	-- btnBackServer = tolua.cast(panelServer:getChildByName("btn_back"),"Button")
	-- btnBackServer:addTouchEventListener(event_btn_back_server)
----------------进度条 面板------------------------------------------------
	progLoading = tolua.cast(panelLoading:getChildByName("prog_loading"),"LoadingBar")
	labLoadingPerc = panelLoading:getChildByName("p_1")
	local sp = Utils.createStrokeLab({label = labLoadingPerc,outlineColor = ccc3(48,29,28)})
	sp:setPosition(ccp(0,0))
	labLoadingPerc:addNode(sp)
	labLoadingPerc.lab = sp
	-- labLoadingTip = panelLoading:getChildByName("p_2")
	
	-- self._prog_loading_tips = Utils.createStrokeLab({label = labLoadingTip,txt="正在努力載入資源，不會消耗您的流量哦",outlineColor = ccc3(48,29,28)})
	-- self._prog_loading_tips:setPosition(ccp(0,0))
	-- labLoadingTip:addNode(self._prog_loading_tips)
	local labLoadingTipTTF = CCLabelTTF:create("正在努力載入資源，不會消耗您的流量哦","",22)
	labLoadingTipTTF:setAnchorPoint(ccp(0.5,0.5))
	labLoadingTipTTF:setPosition(ccp(480,35))
	labLoadingTipTTF:setColor(ccc3(0xFB,0xF1,0xA0))
	self._prog_loading_tips = Utils.createStrokeLabel(labLoadingTipTTF,1,ccc3(48,29,28))
	panelLoading:addNode( self._prog_loading_tips )

	local armaturePath = "ui/login/resource/effect/denglujiemianjiazai/denglujiemianjiazai.ExportJson"
	table.insert(self._armaturePathMap,armaturePath)
	CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(armaturePath)
	self.armLoading = CCArmature:create("denglujiemianjiazai")
	self.armLoading:getAnimation():play("Animation1",0,-1,1)
	self.armLoading:setPosition(ccp(87,74))
	self.armLoading_x = 87
	panelLoading:addNode(self.armLoading,10)

	self.game_version_label = Label:create()
	self.game_version_label:setFontSize(22)
	self.game_version_label:setColor(ItemHelper.colors.yellow)
	self.game_version_label:setAnchorPoint(ccp(0,0))
	self.game_version_label:setPosition(ccp(813,10))
	self.game_version_label:setText(string.format("版本號:%s",
				CCUserDefault:sharedUserDefault():getStringForKey("current-version-code")))
	self._uiLayer:addWidget(self.game_version_label)

	local labTechTip = panelLoading:getChildByName("p_3")
	local sp = Utils.createStrokeLab({label = labTechTip,txt=LoginDataProxy:getInstance():getRandTechTip(),outlineColor = ccc3(48,29,28)})
	sp:setPosition(ccp(0,0))
	labTechTip:addNode(sp)

	-- local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()
	-- local offsetY = (640 - self:getScaleY() * 640 ) / 2
	-- self._widget:getChildByName("panel_land"):setPositionY(-math.max(offsetY,0))
	-- self._widget:getChildByName("panel_hero"):setPositionY(-math.max(offsetY,0))
	
	-- local frame_size = CCEGLView:sharedOpenGLView():getFrameSize()
	-- if frame_size.width==1024 and frame_size.height==768 or
	--     frame_size.width==1024*2 and frame_size.height==768*2 then
	--     self._widget:getChildByName("panel_land"):setPositionY(-35)
	--     self._widget:getChildByName("panel_hero"):setPositionY(-35)
	-- end
	if self.view_type == 0 then --0正常登录  1热更用(无逻辑)
	---------------注册事件------------------------------------------------
		Notifier.regist(LoginEvent.CB_PER_QUICK_LOGIN,event_cb_quick_login)
		Notifier.regist(LoginEvent.CB_PER_NORMAL_LOGIN,event_cb_normal_login)
		
		Notifier.regist(LoginEvent.CB_SHOW_ZONE_LIST,event_cb_show_zonelist)
		Notifier.regist(LoginEvent.CB_GET_SERVER_LIST,event_cb_get_serverlist)
		
		Notifier.regist(LoginEvent.LOADING_NEXT_RES,event_execute_loading)
		
		---------------------------------获取大区列表------------------------------------
		LoginNetTask:getInstance():requestZoneList(true)
		---------------------------------------------------------------------------
	end
	Notifier.regist(LoginEvent.SHOW_ALERT,event_show_alert)
	Notifier.regist(LoginEvent.SHOW_LOADING,event_show_loading)
	Notifier.regist(LoginEvent.HIDE_LOADING,event_hide_loading)
	Notifier.regist(LoginEvent.SHOW_MSGBOX,event_show_msgbox)
	Notifier.regist(LoginEvent.CB_FINISH_LOGIN,event_goto_loading)

	AudioEngine.playMusic(SoundCfg.MainBgMusic,true)

	--发送第四个流失率统计节点
	if t == 0 then
    	SysSettingMgr:getInstance():sendWasteageCount(4)
    end
end

function LoginScene:update()

end

function LoginScene:getInstance()
	return __instance
end

function LoginScene:getPanelByName(name)
	return tolua.cast(self._uiLayer:getWidgetByName(name),"Layout")
end

function LoginScene:setProgLoadingTxt(tips_str)
	self._prog_loading_tips:setString(tips_str)
end

function LoginScene:removeNotifier()
	Notifier.remove(LoginEvent.CB_PER_QUICK_LOGIN,event_cb_quick_login)
	Notifier.remove(LoginEvent.CB_PER_NORMAL_LOGIN,event_cb_normal_login)
	Notifier.remove(LoginEvent.SHOW_ALERT,event_show_alert)
	Notifier.remove(LoginEvent.CB_SHOW_ZONE_LIST,event_cb_show_zonelist)
	Notifier.remove(LoginEvent.CB_GET_SERVER_LIST,event_cb_get_serverlist)
	Notifier.remove(LoginEvent.SHOW_LOADING,event_show_loading)
	Notifier.remove(LoginEvent.HIDE_LOADING,event_hide_loading)
	Notifier.remove(LoginEvent.LOADING_NEXT_RES,event_execute_loading)
	Notifier.remove(LoginEvent.SHOW_MSGBOX,event_show_msgbox)
	Notifier.remove(LoginEvent.CB_FINISH_LOGIN,event_goto_loading)
end

function LoginScene:removeArmatureInfo()
	for i=1,#self._armaturePathMap do
		local path = self._armaturePathMap[i]
		CCArmatureDataManager:sharedArmatureDataManager():removeArmatureFileInfo(path)
	end
end