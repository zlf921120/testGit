
--登录页面 渲染器

LoginRenderMgr = {}

--渲染快速登录 面板
LoginRenderMgr.renderQuickLogin = function(labZoneId,labZoneName)
		
	local dp = LoginDataProxy:getInstance()
	labZoneId:setText(string.format("S%d",dp._zoneId))
	labZoneName:setText(dp._zoneName)
end

--渲染普通登录 面板
LoginRenderMgr.renderNormalLogin = function(labZoneId,labZoneName,labQuickZoneName)
	
	local dp = LoginDataProxy:getInstance()
	labZoneId:setText(string.format("S%d",dp._zoneId))
	-- print(" loginData:getAcctName() ",loginData:getAcctName(),loginData:getAcctId())
	labQuickZoneName:setText(dp._acctName)
	labZoneName:setText(dp._zoneName)

	SdkManager:setJavakeyValue("acct_name",dp._acctName)	
	SdkManager:setJavakeyValue("zone_id",dp._zoneId)
end

--渲染服务器 列表 面板
LoginRenderMgr.renderZoneList = function(listView)

	listView:removeAllItems() --先清理

	local dp = LoginDataProxy:getInstance()
	local voList = dp:getZoneVoList()

	for id,itemVo in pairs(voList) do
		local item = ZoneItem:create(itemVo)
		listView:pushBackCustomItem(item)
	end
end

