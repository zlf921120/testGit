
--区 条目
ZoneItem = class("ZoneItem",function()
    return Layout:create()
end)
ZoneItem.__index = ZoneItem
ZoneItem._widget 	= nil
ZoneItem._uiLayer = nil

function ZoneItem:create(zoneVo)
    local ret = ZoneItem.new()
    ret:init(zoneVo)
    return ret
end

--------------------------响应事件---------------------------------------------
local function event_btn_click(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		local zoneVo = LoginDataProxy:getInstance():getZoneVoById( pSender:getTag())   
		
		Global:setServerInfo(zoneVo.zoneIP, zoneVo.zonePort)
		Global:setZoneID( zoneVo.zoneId )
		
        print("設置區 ip 埠",zoneVo.zoneIP, zoneVo.zonePort)
        
        local dp = LoginDataProxy:getInstance()
        dp._zoneId = zoneVo.zoneId
        dp._zoneName = zoneVo.zoneName

        Global:setStringForKey( "zoneId" , dp._zoneId )

        -- LoginNetTask:getInstance():requireLoginZone(zoneVo.zoneId)

        if LoginNetTask:getInstance()._isQuickLogin then  
            Notifier.dispatchCmd(LoginEvent.CB_PER_QUICK_LOGIN)
        else
            Notifier.dispatchCmd(LoginEvent.CB_PER_NORMAL_LOGIN)
        end
	end
end

--------------------------初始化----------------------------------------------
function ZoneItem:init(zoneVo)
    require "LoginCfg"

	self._widget = GUIReader:shareReader():widgetFromJsonFile("ui/login/ZoneItem.ExportJson")
    self:setSize(self._widget:getSize())
    self:addChild(self._widget)

    local btnClick = tolua.cast(self._widget:getChildByName("btn_click"),"Button")
    btnClick:addTouchEventListener(event_btn_click)
    btnClick:setTag(zoneVo.zoneId)

    self:update(zoneVo)
end

function ZoneItem:update(zoneVo)

	local labId = tolua.cast(self._widget:getChildByName("lab_zoneid"),"Label")
    labId:setText("S"..zoneVo.zoneId)

    local labName = tolua.cast(self._widget:getChildByName("lab_zonename"),"Label")
    labName:setText(zoneVo.zoneName)

    local labStatus = tolua.cast(self._widget:getChildByName("lab_status"),"Label")
    labStatus:setText(ZoneStatusName[zoneVo.status ])
    labStatus:setColor(ZoneStatusColor[zoneVo.status ])

end
