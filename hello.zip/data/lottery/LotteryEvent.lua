--抽奖事件

LotteryEvent = 
{
	RENDER_UPDATE_SCENE = "lottery_update_scene",
	RENDER_UPDATE_ITEM = "lottery_update_item",
	SHOW_LEFT_PANEL = "lottery_show_box",
	HIDE_LEFT_PANEL = "lottery_HIDE_LEFT_PANEL",
	-- SHOW_ALERT = "lotterty_show_alert",
	MSG_BOX_CLICK = "lottery_box_click",
	MSG_BOX_LONG_CLICK = "lottery_box_long_click", --长按
	INIT_SCENE = "lottery_init_scene", --初始化场景
}