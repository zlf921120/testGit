
--宝箱 抽奖场景
LotteryScene = class("LotteryScene",WindowBase)
LotteryScene.__index = LotteryScene
LotteryScene._listBox1 = nil
--LotteryScene._listBox2 = nil
LotteryScene._widget = nil
LotteryScene.uiLayer = nil
-- LotteryScene.is_dispose = true

local __instance = nil

function LotteryScene:create()
    local ret = LotteryScene.new()
    __instance = ret
    return ret
end

function LotteryScene:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
    AnimateManager:getInstance():clear(self.armBgPath)
    LotteryRenderMgr:getInstance():clearBoxList()

    Notifier.removeByName(LotteryEvent.RENDER_UPDATE_SCENE)
    Notifier.removeByName(LotteryEvent.SHOW_LEFT_PANEL)
    Notifier.removeByName(LotteryEvent.HIDE_LEFT_PANEL)
    Notifier.removeByName(LotteryEvent.INIT_SCENE)
    Notifier.remove(GuideEvent.ShowStepAnim,self._showStepAnim)
end

--单抽
local function event_btn_one(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
        local dp = LotteryDataProxy:getInstance()
        local buyType = tolua.cast(pSender,"Button"):getTag()
        local viewVo = dp:getBoxViewVoById(  dp:getLotterySceneVo().choiceType )
        local boxType = dp:getBoxVoById(viewVo.boxId).type

        --黄金首次(新手抽奖) 要特殊处理
        if dp:getLotterySceneVo().isHasGetFreashMan == 0 and buyType == LotteryBuyType.BuyOneFree and boxType == LotteryBoxType.Gold then
            buyType = LotteryBuyType.GuideBuy
            boxType = 5 --特殊处理 这里是id  不是类型
        end
        print("  buyType ",buyType, "  boxType ",boxType," choiceType ",dp:getLotterySceneVo().choiceType)
        if dp:isCostDiamon(viewVo.boxId) and buyType == LotteryBuyType.BuyOne and __instance.labOne:getStringValue() ~= "免費" then

            WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()

               LotteryNetTask:getInstance():requestBuyLotteryBox(boxType,buyType)

            end, txt = string.format("花費%s鑽石購買該寶箱\n是否繼續?",__instance.labOne:getStringValue())})
        else
            LotteryNetTask:getInstance():requestBuyLotteryBox(boxType,buyType)
        end
    end
end

--十连抽
local function event_btn_ten(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
        local dp = LotteryDataProxy:getInstance()
        local buyType = tolua.cast(pSender,"Button"):getTag()
        local viewVo = dp:getBoxViewVoById(  dp:getLotterySceneVo().choiceType )
        local boxType = dp:getBoxVoById(viewVo.boxId).type
        print("  buyType ",buyType, "  boxType ",boxType," choiceType ",dp:getLotterySceneVo().choiceType)
        if dp:isCostDiamon(viewVo.boxId) and buyType == LotteryBuyType.BuyTen then

            WindowCtrl:getInstance():open(CmdName.Comm_MsgBox, {okFunc = function()

               LotteryNetTask:getInstance():requestBuyLotteryBox(boxType,buyType)

            end, txt = string.format("花費%s鑽石購買該寶箱\n是否繼續?",__instance.labTen:getStringValue())})
        else
            LotteryNetTask:getInstance():requestBuyLotteryBox(boxType,buyType)
        end
    end
end

-- --切换
-- local function event_btn_exchange(pSender,eventType)
--     if eventType == ComConstTab.TouchEventType.ended then
--         --__instance._listBox2:setEnabled(false)
--         __instance._listBox1:setEnabled(true)
--         __instance.btnExchange:setEnabled(false)

--         LotteryRenderMgr:getInstance():playAnimsInto({1,2,3})
--     end
-- end

function LotteryScene:init()
    require "LotteryRenderMgr"
    require "LotteryLocalReader"
    require "LotteryNetTask"
    require "LotteryResult"
    require "LotteryCfg"
    require "LotteryDrop"
    require "ItemIcon"
    --加载纹理
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/lottery/lottery.plist")
    ComResMgr:getInstance():loadOtherRes()

	self.uiLayer = TouchGroup:create()
    self._widget = GUIReader:shareReader():widgetFromJsonFile("lottery/lotteryScene.ExportJson")
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
    local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()
    self.imgBg = ImageView:create()
    self.imgBg:setPosition(ccp(480,320))
    self.imgBg:setScaleX(1/DisplayUtil.min_scale*globa_scalx)
    self.imgBg:setScaleY(1/DisplayUtil.min_scale*globa_scaly)
    self._widget:addChild(self.imgBg)

    self.armBgPath = "ui/effects_ui/zhaohuanfazhen_02/zhaohuanfazhen_02.ExportJson"
    CCArmatureDataManager:sharedArmatureDataManager():addArmatureFileInfo(self.armBgPath)
    local arm = CCArmature:create("zhaohuanfazhen_02")
    arm:setPosition(ccp(235,228))
    arm:getAnimation():play("Animation1",0,-1,1)
    self._widget:addNode(arm)

    self.panelView = self._widget:getChildByName("panel_view")
    self.panelUi = self._widget:getChildByName("panel_ui")
    self.new_type_img = self._widget:getChildByName("lottery_new_type")
    if Global:getStringForKey("newLotteryTypeTips") == nil then
       Global:setStringForKey("newLotteryTypeTips","done")
       self.new_type_img:setVisible(true)
       self:playArrowAnim(self.new_type_img)
    else
       self.new_type_img:setVisible(false)
    end
    -- self._listBox1 = tolua.cast(self._widget:getChildByName("list_goods"),"ListView")
    --self._listBox2 = tolua.cast(self._widget:getChildByName("list_goods2"),"ListView")
    --self._listBox2:setEnabled(false)
    self.panelList = tolua.cast(self._widget:getChildByName("panel_list"),"Layout")
    self.panelInner = tolua.cast(self.panelList:getChildByName("panelInner"),"Layout")
    self.list_view = tolua.cast(self.panelInner:getChildByName("lottery_list_view"), "ListView")
    -- cclog("listview success")
    --上下箭头
    self.arrow_up = tolua.cast(self.panelList:getChildByName("arrow_up"),"ImageView")
    self.arrow_down = tolua.cast(self.panelList:getChildByName("arrow_down"),"ImageView")
    
    self.arrow_down:setTouchEnabled(true)
    self.arrow_down:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            self.list_view:scrollToBottom(0.2,false)
        end
    end)
    self.arrow_up:setTouchEnabled(true)
    self.arrow_up:addTouchEventListener(function(pSender,eventType)
        if eventType == ComConstTab.TouchEventType.ended then
            self.list_view:scrollToTop(0.2,false)
        end
    end)
    self.arrow_up:setVisible(false)
    self.arrow_down:setVisible(false)
    self.imgOnetype = tolua.cast(self.panelUi:getChildByName("img_onetype"),"ImageView")
    self.imgTentype = tolua.cast(self.panelUi:getChildByName("img_tentype"),"ImageView")

    local btnOne = tolua.cast(self.panelUi:getChildByName("btn_one"),"Button")
    btnOne:addTouchEventListener(event_btn_one)

    local btnTen = tolua.cast(self.panelUi:getChildByName("btn_ten"),"Button")
    btnTen:addTouchEventListener(event_btn_ten)

    self.labOne = tolua.cast(self.panelUi:getChildByName("lab_cost1"),"Label")
    self.labTen = tolua.cast(self.panelUi:getChildByName("lab_cost2"),"Label")

    self.panelView:setEnabled(false)
    self.panelUi:setEnabled(false)
    --加载xls数据
    LotteryLocalReader:getInstance():loadInProxy()

    LotteryRenderMgr:getInstance():renderBoxList(self.list_view)
    self.list_view:addEventListenerScrollView(function(sender,event_type)
        require("DisplayUtil")
        vp = DisplayUtil.getScrollViewPercent(sender)
        -- print("is scrolling to...",vp)
        if vp > 0 then
            self.new_type_img:setVisible(false)
            self.new_type_img:stopAllActions()
        end
        if vp < 55 and vp > 0 then
        self.arrow_up:setVisible(true)
        self:playArrowAnim(self.arrow_up)
        self.arrow_down:setVisible(false)
        elseif vp > 55 then
            self.arrow_down:setVisible(true)
            self:playArrowAnim(self.arrow_down)
            self.arrow_up:setVisible(false)
        end
    end)

    Notifier.regist(LotteryEvent.RENDER_UPDATE_SCENE,function() self:update() end)
    Notifier.regist(LotteryEvent.SHOW_LEFT_PANEL,function() self:showBox() end)
    Notifier.regist(LotteryEvent.HIDE_LEFT_PANEL,function() self:hideBox() end)
    Notifier.regist(LotteryEvent.INIT_SCENE,function() LotteryRenderMgr:getInstance():playAnimsInto({1,2,3,4}) end)

    self._progressSchedule = function()
        self:progressSchedule()
    end

    self._showStepAnim = function(param)
        self:showStepAnim(param)
    end
    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,self._showStepAnim)
end

--新手引导动画
function LotteryScene:showStepAnim(param)
    if param.target == "lottery_lotterybox2" then
        local item = LotteryRenderMgr:getInstance().dic:objectForKey(string.format("box_%d",2)) 
        GuideRenderMgr:getInstance():renderMainFlag(item,param.id,param.target)
    elseif param.target == "lottery_buyone1" then
        local btnOne = tolua.cast(self.panelUi:getChildByName("btn_one"),"Button")
        GuideRenderMgr:getInstance():renderMainFlag(btnOne,param.id,param.target)
    elseif param.target == "lottery_btnexit" then
        GuideRenderMgr:getInstance():renderMainFlag(self.close_btn,param.id,param.target)
    end
end

function LotteryScene:getInstance()
    return __instance
end

function LotteryScene:showBox()
    self.panelView:setEnabled(true)
    self.panelView:setVisible(true)

    self.panelUi:setEnabled(false)
    self.panelUi:setVisible(false)

    LotteryRenderMgr:getInstance():playAnimIntoWithPanel(self.panelView,function()
        self.panelUi:setEnabled(true)
        self.panelUi:setVisible(true)
    end)
end

function LotteryScene:hideBox()
	
    self.panelView:setEnabled(false)
    self.panelView:setVisible(false)

    self.panelUi:setEnabled(false)
    self.panelUi:setVisible(false)
end

function LotteryScene:update()

    local dp = LotteryDataProxy:getInstance()
    local sceneVo = dp:getLotterySceneVo()
    
    local viewVo = dp:getBoxViewVoById(sceneVo.choiceType) --当前选择的宝箱类型

    if sceneVo == nil or viewVo == nil then return end
    
    -- local labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")
    -- local labTimeFix = tolua.cast(self._widget:getChildByName("lab_fixtime"),"Label")
    local btnOne = tolua.cast(self.panelUi:getChildByName("btn_one"),"Button")
    local btnTen = tolua.cast(self.panelUi:getChildByName("btn_ten"),"Button")
    local imgOneUnit = tolua.cast(self.panelUi:getChildByName("img_unit1"),"ImageView")
    local imgTenUnit = tolua.cast(self.panelUi:getChildByName("img_unit2"),"ImageView")
    -- local imgTitle = tolua.cast(self._widget:getChildByName("img_title"),"ImageView")

-------------单抽--------------------------------------------- 
    local boxType = dp:getBoxVoById(viewVo.boxId).type
    local tenBox = nil
    local oneBox = nil
    local freeBox = nil
    local voListBox = dp:getBoxVoList()
    for id,v in pairs(voListBox) do
        if v.type == boxType and v.buyType == LotteryBuyType.BuyTen then --十连抽
            tenBox = v
        elseif v.type == boxType and v.buyType == LotteryBuyType.BuyOne then --单抽
            oneBox = v
        end
    end

    self.labOne:setText(oneBox.cost)

    local function updateUnit(imgUnit,boxVo)
        if boxVo.currency == MoneyType.Diamond then 
            imgUnit:loadTexture("diamond.png",UI_TEX_TYPE_PLIST)  --默认是钻石
        elseif boxVo.currency == MoneyType.Coin then
            imgUnit:loadTexture("gold.png",UI_TEX_TYPE_PLIST)
        end
    end

    updateUnit(imgOneUnit,oneBox)
    updateUnit(imgTenUnit,tenBox)
    
    if viewVo.freeUse < viewVo.freeMax or boxType == LotteryBoxType.Gold then --还可以免费领 (黄金宝箱除外，因为超过24小时)
        if viewVo.lastFreeTime <= 0 then --冷却时间没了
            -- labTime:setVisible(false)
            -- labTimeFix:setVisible(false)
            btnOne:setTag(LotteryBuyType.BuyOneFree)
            self.labOne:setText("免費") --免费购买
        else
            -- labTime:setVisible(true)
            -- labTimeFix:setVisible(true)
            -- labTime:setText(Helper.sec2TimeStr(viewVo.lastFreeTime))
            btnOne:setTag(LotteryBuyType.BuyOne)
        end
    else --不能免费领了
        -- labTime:setVisible(false)
        -- labTimeFix:setVisible(false)
        btnOne:setTag(LotteryBuyType.BuyOne)
    end

   -- print(" boxType ~= LotteryBoxType.Eqmuip or viewVo.isFirstBuy == 0 ",boxType ~= LotteryBoxType.Eqmuip, viewVo.isFirstBuy == 0)
    -- print("選擇寶箱類型.....viewVo",boxType)
    if boxType ~= LotteryBoxType.Eqmuip and viewVo.isFirstBuy == 0 and boxType ~= LotteryBoxType.Rare then --首抽提示
    	self.imgOnetype:setVisible(true)
   		self.imgOnetype:loadTexture(string.format("i18n_lottery_onetype%d.png",boxType),UI_TEX_TYPE_PLIST)
   	else
   		self.imgOnetype:setVisible(false)
	end
------------十连抽---------------------------------------------
    btnTen:setTag(LotteryBuyType.BuyTen)
    self.labTen:setText(tenBox.cost)
    if boxType == LotteryBoxType.Rare then  --珍藏宝箱没有十连抽固定奖励
        self.imgTentype:setVisible(false)
    else 
        self.imgTentype:loadTexture(string.format("i18n_lottery_tentype%d.png",boxType),UI_TEX_TYPE_PLIST)
        self.imgTentype:setVisible(true)
    end
----------------------------------------------------------------
    local p_1 = self.panelView:getChildByName("p_1")
    for i=1,4 do
        local child = self.panelView:getChildByTag(1500 + i)
        if child ~= nil then
            child:removeFromParentAndCleanup(true)
        end
    end
    require "ItemInfoPanel"
    for i=1,#viewVo.rewards do
        local itemIcon = LotteryRenderMgr:getInstance().dic:objectForKey(string.format("reward_%d_%d",i,viewVo.id)) 
        if itemIcon == nil then
            itemIcon = ItemIcon:create()
            itemIcon:setBaseId( tonumber( viewVo.rewards[i]) )
            itemIcon:setPosition(ccp( p_1:getPositionX() + (i-1) * 100,p_1:getPositionY() ))
            itemIcon:setTag(1500 + i)
            itemIcon:setScale(0.8)
            itemIcon:setItemNum(1)
            itemIcon:getClickImg():setTag(tonumber( viewVo.rewards[i]))
            itemIcon:setTouchEvent(function(pSender,eventType)
                if eventType == ComConstTab.TouchEventType.began then

                    ItemInfoPanel:show(pSender:getTag(),ccp(197,211 - 100))

                elseif eventType == ComConstTab.TouchEventType.ended or
                        eventType == ComConstTab.TouchEventType.canceled then

                    ItemInfoPanel:hide()
                end
            end)
            LotteryRenderMgr:getInstance().dic:setObject(itemIcon,string.format("reward_%d_%d",i,viewVo.id)) 
        end
        self.panelView:addChild(itemIcon)
    end
end

function LotteryScene:open()
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/lottery/lottery.plist")
    LotteryNetTask:getInstance():requestLotteryInfo()
    self:startSchedule()

    self.imgBg:loadTexture("ui/lottery/lottery_bg.jpg")

    self.panelView:setEnabled(false)
    self.panelUi:setEnabled(false)

    self.arrow_down:setVisible(true)
    self:playArrowAnim(self.arrow_down)
    
    LotteryRenderMgr:getInstance():clearBoxList() --先清理
    LotteryRenderMgr:getInstance():renderBoxList(self.list_view)
end

function LotteryScene:close()
    self:clearSchedule()
    self.panelView:setEnabled(false)
    self.panelUi:setEnabled(false)

    -- self.panelInner:setPositionY(-170 * 2 - 20) --改用listview不需要调整位置

    LotteryRenderMgr:getInstance():cleanBoxSelect()
    --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 11105 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"click_lottery_exit")
    end
    --CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile("ui/lottery/lottery.plist")
    CCTextureCache:sharedTextureCache():removeTextureForKey("ui/lottery/lottery_bg.jpg")
end

function LotteryScene:progressSchedule()
     --倒计时
        local nowTime = ServerTimerManager:getInstance():getCurTime()
        local dp = LotteryDataProxy:getInstance()
        local viewVoCopper = dp:getBoxViewVoById(LotteryBoxType.Copper)
        if viewVoCopper.startFreeTime == 0 then
            viewVoCopper.lastFreeTime = 0

        else
            viewVoCopper.lastFreeTime =  10 * 60 - ( nowTime - viewVoCopper.startFreeTime )
            if viewVoCopper.lastFreeTime < 0 then 
                viewVoCopper.lastFreeTime = 0 

                Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.lottery) --显示新消息提示
            end
        end
        
        -- if viewVoCopper.lastFreeTime > 0 then
        --     viewVoCopper.lastFreeTime = viewVoCopper.lastFreeTime - 1
        -- end
        local viewVoGold = dp:getBoxViewVoById(LotteryBoxType.Gold)

        if viewVoGold.startFreeTime == 0 then
            viewVoGold.lastFreeTime = 0
        else
            viewVoGold.lastFreeTime = 48 * 60 * 60 - ( nowTime - viewVoGold.startFreeTime )
            if viewVoGold.lastFreeTime < 0 then 
                viewVoGold.lastFreeTime = 0 

                Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.lottery) --显示新消息提示
            end
            -- print(" viewVoGold.lastFreeTime  ",nowTime,viewVoGold.startFreeTime, viewVoGold.lastFreeTime)
        end
        -- if viewVoGold.lastFreeTime > 0 then
        --     viewVoGold.lastFreeTime = viewVoGold.lastFreeTime - 1
        -- end

       self:update()
       LotteryRenderMgr:getInstance():scheduleBoxs() --更新宝箱条目
end

local entrySchedule = nil
function LotteryScene:startSchedule()
    self:clearSchedule()
    -- -- progress(0) --立即触发 一次
    TimerManager.addTimer(1000,self._progressSchedule,true)
end

--清理定时器
function LotteryScene:clearSchedule()
    TimerManager.removeTimer(self._progressSchedule)
end

-- --监听listview的滚动
-- function LotteryScene:event_scroll_listview(pSender,eventType)
--     require("DisplayUtil")
--     vp = DisplayUtil.getScrollViewPercent(pSender)
--     print("is scrolling to...",vp)
--     if vp < 55 then
--         print("小於55啦。。。。。")
--         self.arrow_up:setVisible(true)
--         -- self:playArrowAnim(self.arrow_up)
--     end
-- end

--箭头动画
function LotteryScene:playArrowAnim(imageview)

    local idx = 0
    local flag = 1
    imageview:stopAllActions()
    imageview:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
        CCCallFunc:create(function()
            idx = idx + flag
            local value = 255 * (idx / 10)
            imageview:setOpacity(value)
            if idx == 10 then 
                flag = -1
            elseif idx == 6 then
                flag = 1
            end
        end),
        CCDelayTime:create(0.1))))
end