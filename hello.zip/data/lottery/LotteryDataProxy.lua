
--宝箱 抽奖 数据代理
LotteryDataProxy = class("LotteryDataProxy")
LotteryDataProxy.boxVoList = {} --宝箱映射表
LotteryDataProxy.boxViewVoList = {} --显示列表
LotteryDataProxy.itemHeroVoList = {} --物品英雄映射表
LotteryDataProxy.stoneHeroVoList = {} --英雄武魂 映射 英雄整卡
LotteryDataProxy.resultVo = nil --抽奖结果
LotteryDataProxy.sceneVo = nil --场景值对象
-- --新消息提示
-- LotteryDataProxy.newsTipBox1 = nil --青铜
-- LotteryDataProxy.newsTipBox2 = nil --黄金
LotteryDataProxy.newsTipBoxList = {}

local __instance = nil
local _allowInstance = false

function LotteryDataProxy:ctor()
    if not _allowInstance then
		error("LotteryDataProxy is a singleton class")
	end
	self:init()
end

function LotteryDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = LotteryDataProxy.new()
		_allowInstance = false
	end

	return __instance
end

function LotteryDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function LotteryDataProxy:init()
	require "LotteryCfg"
	require "LotteryVo"
end

function LotteryDataProxy:createBoxVo()
	return LotteryBoxVo.new()
end

function LotteryDataProxy:getBoxVoById(id)
	return self.boxVoList[id]
end

function LotteryDataProxy:setBoxVo(vo)
	self.boxVoList[ vo.id ] = vo
end

function LotteryDataProxy:getBoxVoList()
	return self.boxVoList
end
----------------------------------------
function LotteryDataProxy:createBoxViewVo()
	return LotteryBoxViewVo.new()
end

function LotteryDataProxy:getBoxViewVoById(id)
	return self.boxViewVoList[id]
end

function LotteryDataProxy:setBoxViewVo(vo)
	self.boxViewVoList[ vo.id ] = vo
end

function LotteryDataProxy:getBoxViewVoList()
	return self.boxViewVoList
end
----------------------------------------
function LotteryDataProxy:createResultVo()
	if self.resultVo ~= nil then
		local cout = #self.resultVo.rewards
		for i=1,cout do
			table.remove(self.resultVo.rewards)
		end
	else
		self.resultVo = LotteryResultVo.new()
	end
	return self.resultVo
end

function LotteryDataProxy:getResultVo()
	return self.resultVo
end
---------------------------------------
function LotteryDataProxy:getLotterySceneVo()
	if self.sceneVo == nil then
		self.sceneVo = LotterySceneVo.new()
	end
	return self.sceneVo
end
----------------------------------------------------
function LotteryDataProxy:createLotteryHeroItemVo()
	return LotteryHeroItemVo.new()
end

function LotteryDataProxy:getLotteryHeroItemVoById(id)
	return self.itemHeroVoList[id]
end

function LotteryDataProxy:setLotteryHeroItemVo(vo)
	self.itemHeroVoList[vo.itemId] = vo
end
----------------------------------------------------
function LotteryDataProxy:createLotteryStoneHeroVo()
	return LotteryStoneHeroVo.new()
end

function LotteryDataProxy:getLotteryStoneHeroById(id)
	return self.stoneHeroVoList[id]
end

function LotteryDataProxy:setLotteryStoneHeroVo(vo)
	self.stoneHeroVoList[vo.baseId] = vo
end

-----------------------------------------------------
function LotteryDataProxy:createLotteryTipsBoxVo()
	return LotteryTipsBoxVo.new()
end

function LotteryDataProxy:getLotteryTipsBoxVoList()
	return self.newsTipBoxList
end

function LotteryDataProxy:getLotteryTipsBoxVoById(id)
	return self.newsTipBoxList[id]
end

function LotteryDataProxy:setNewsTipBoxs(box1,box2)
	local function progress(type,box1)
		if self.newsTipBoxList[type] == nil then
			local tipBox1 = LotteryTipsBoxVo.new()
			tipBox1.startFreeTime = box1.time 
			tipBox1.freeMax = box1.num_max
			tipBox1.freeUse = box1.num
			self.newsTipBoxList[type] = tipBox1
		end
	end
	progress(1,box1)
	progress(2,box2)
end

--抽奖类型是否消耗钻石
function LotteryDataProxy:isCostDiamon(boxType)
	local voBox = self:getBoxVoById(boxType)
	return voBox.currency == MoneyType.Diamond 
end

function LotteryDataProxy:getNewsTipBox()
	return self.newsTipBoxList[1],self.newsTipBoxList[2]
end

--获取 抽奖 48小时免费 目标时间
function LotteryDataProxy:getLottery48HTargetTime()
	local ret = 0
	local box = self.newsTipBoxList[2]
	local nowTime = ServerTimerManager:getInstance():getCurTime()
	box.lastFreeTime = 48 * 60 * 60 - ( nowTime - box.startFreeTime )
    if box.lastFreeTime < 0 then 
        box.lastFreeTime = 0 
        ret = nowTime
    else
    	ret = box.lastFreeTime + nowTime
    end
    return ret
end

--是否能通知 系统设置
function LotteryDataProxy:isCanAddOneOffNotice()
	local nowTime = ServerTimerManager:getInstance():getCurTime()
	local targetTime = self:getLottery48HTargetTime()
	if targetTime ~= nowTime then
		SysSettingMgr:getInstance():addOneOffNoticeByUnixTime(SysSettingMgr.TipsNameList.LOTTERY_48H_TIPS,targetTime)
	end
end

function LotteryDataProxy:getLotteryBoxWidget()
	if self.lotteryBoxWidget == nil then
		self.lotteryBoxWidget = GUIReader:shareReader():widgetFromJsonFile("lottery/LotteryBox.ExportJson")
		self.lotteryBoxWidget:retain()
	end
	return self.lotteryBoxWidget
end

--刷新 宝箱绿点
function LotteryDataProxy.progressSchedule()
      --宝箱相关
        local nowTime = ServerTimerManager:getInstance():getCurTime()
        local dp = LotteryDataProxy:getInstance()
        local box1,box2 = dp:getNewsTipBox()
        local function progress(box,countTime)
          local ret = false
          -- print(" box.startFreeTime ",box.startFreeTime,box.lastFreeTime, box.freeUse , box.freeMax)
            if box.freeUse < box.freeMax then --还有免费次数
                if box.startFreeTime == 0 then
                    box.lastFreeTime = 0
                    ret = true
                else
                    box.lastFreeTime = countTime * 60 - ( nowTime - box.startFreeTime )
                    if box.lastFreeTime < 0 then 
                        box.lastFreeTime = 0 
                        ret = true
                    else
                        ret = false
                    end
                end
            else --超过免费次数
               ret = false
            end
            return ret
        end

        if ActivateDataProxy:getInstance():isCanOpen(ActivateCfg.Altar,nil,false) then --需要开启后才显示
            local isShowTip2 = progress(box2,48 * 60)
            local isShowTip1 = progress(box1,10)
            if isShowTip2 or isShowTip1 then --两个宝箱 其中有一个能有免费获取就显示

                Notifier.dispatchCmd(CmdName.MAIN_SHOW_NEWS_TIP,NewTipsEnum.lottery) --显示新消息提示
            else
                Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.lottery) --取消新消息提示
            end
        end
        --公告相关
        NoticeDataProxy:getInstance():checkRemoveNotice()
end

function LotteryDataProxy:refreshLottery(info)
	local viewVo1 = self:getBoxViewVoById(LotteryBoxType.Copper)
	if viewVo1 ~= nil then
		viewVo1.freeUse = info.bronze_num
	end
	local viewVo2 = self:getBoxViewVoById(LotteryBoxType.Gold)
	if viewVo2 ~= nil then
		viewVo2.freeUse = info.gold_num
	end
end