
-- 抽奖配置
LotteryCfg =
{


}

--宝箱类型
LotteryBoxType = 
{
	Copper = 1 ,  	--青铜宝箱
	Gold = 2 , 		--黄金宝箱
	Dead = 3 ,		--亡灵宝箱
	Eqmuip = 4, 	--装备宝箱
	Rare = 6,		--珍藏宝箱,5为新手宝箱
}
--抽奖类型
LotteryBuyType = 
{
	BuyOne = 1,  --单抽
	BuyOneFree = 2, --每日免费单抽
	BuyTen = 3,  --十连抽
	GuideBuy = 4, --新手引导买
	-- FirstBuy = 3, --账号首次买
}


--宝箱名字
LotteryBoxTypeName =
{
	"青銅寶箱",
	"黃金寶箱",
	"亡靈寶箱",
	"珍藏寶箱"
}