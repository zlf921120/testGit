
-- 宝箱 抽奖 渲染器
LotteryRenderMgr = class("LotteryRenderMgr")
LotteryRenderMgr.fixPosArr = nil
LotteryRenderMgr.stard_act_list = nil
LotteryRenderMgr.renderRewardIdx = 0 --渲染下标
LotteryRenderMgr.containerResule = nil
LotteryRenderMgr.dic = nil

LotteryRenderMgr.toggleBoxFlag = true

local __instance = nil
local _allowInstance = false

function LotteryRenderMgr:ctor()
    if not _allowInstance then
		error("LotteryRenderMgr is a singleton class")
	end
	self:init()
end

function LotteryRenderMgr:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = LotteryRenderMgr.new()
		_allowInstance = false
	end

	return __instance
end

function LotteryRenderMgr:destoryInstance()
	self.dic:release()
	_allowInstance = false
	__instance = nil
end

local function updateBoxItem(id)
	-- print(" updateBoxItem ",id)
	local item = __instance.dic:objectForKey(string.format("box_%d",id)) 
	local dp = LotteryDataProxy:getInstance()
	local viewVo = dp:getBoxViewVoById(id)
	item:update(viewVo)
end

local _lastClickBoxId = 0
local function event_box_click(id)
	-- if _lastClickBoxId == id then return end
	for i=1,6 do
		local item = __instance.dic:objectForKey(string.format("box_%d",i))
		local img_bgframe = tolua.cast(item._widget:getChildByName("img_bgframe"),"ImageView")
		if i == id then
			if i < 5 then
	        	img_bgframe:loadTexture("lottery_boxbgselect.png", UI_TEX_TYPE_PLIST)
	    	else
	        	img_bgframe:loadTexture("lottery_boxbgselect3.png", UI_TEX_TYPE_PLIST)
	        end
        else
        	if i < 5 then
	        	img_bgframe:loadTexture("lottery_boxbg.png", UI_TEX_TYPE_PLIST)
	    	else
	        	img_bgframe:loadTexture("lottery_boxbg3.png", UI_TEX_TYPE_PLIST)
	        end 
    	end
		-- if id == i then --3号要特殊处理
		-- 	if i == 4 or i == 5 then --装备宝箱要特殊区分
		-- 		img:loadTexture("lottery_boxbgselect2.png",UI_TEX_TYPE_PLIST)
		-- 	elseif i==6 then
		-- 		img:loadTexture("lottery_boxbgselect3.png",UI_TEX_TYPE_PLIST)
		-- 	else
		-- 		img:loadTexture("lottery_boxbgselect.png",UI_TEX_TYPE_PLIST)
		-- 	end
		-- else
		-- 	if i == 4 or i == 5 then --装备宝箱要特殊区分
		-- 		img:loadTexture("lottery_boxbg2.png",UI_TEX_TYPE_PLIST)
			
		-- 	elseif i == 6 then
		-- 		img:loadTexture("lottery_boxbg3.png",UI_TEX_TYPE_PLIST)
		-- 	else
		-- 		img:loadTexture("lottery_boxbg.png",UI_TEX_TYPE_PLIST)
		-- 	end
		-- end
	end

	_lastClickBoxId = id
	-- --更新当前选择的宝箱类型
	LotteryDataProxy:getInstance():getLotterySceneVo().choiceType = _lastClickBoxId

	Notifier.dispatchCmd(LotteryEvent.RENDER_UPDATE_SCENE)
	if id == 3 and CharacterDataProxy:getInstance():getTeamLev() >= 40 then --点击第三个箱 并战队等级超过40
		--清空选中状态 --3号要特殊处理
		local item = __instance.dic:objectForKey(string.format("box_%d",3))
		tolua.cast(item._widget:getChildByName("img_bgframe"),"ImageView"):loadTexture("lottery_boxbg.png",UI_TEX_TYPE_PLIST)

		__instance.toggleBoxFlag = not __instance.toggleBoxFlag
		__instance:panelScrol( __instance.toggleBoxFlag )

		-- LotteryScene:getInstance().btnExchange:setEnabled(true)

		-- __instance:playAnimsInto({4,5})
		
		Notifier.dispatchCmd( LotteryEvent.HIDE_LEFT_PANEL )
	else
		Notifier.dispatchCmd( LotteryEvent.SHOW_LEFT_PANEL )
	end
	--新手引导事件
	if id == 2 then
		if GuideDataProxy:getInstance().nowMainTutroialEventId == 11102 then
            Notifier.dispatchCmd(GuideEvent.StepFinish,"click_lotterybox2")
        end
	end
end

function LotteryRenderMgr:cleanBoxSelect()
	_lastClickBoxId = LotteryBoxType.Copper
	for i=1,6 do
		local item = __instance.dic:objectForKey(string.format("box_%d",i))
		local img = tolua.cast(item._widget:getChildByName("img_bgframe"),"ImageView")
		if i == 4 or i == 5 then --装备宝箱要特殊区分
			img:loadTexture("lottery_boxbg2.png",UI_TEX_TYPE_PLIST)
		else
			img:loadTexture("lottery_boxbg.png",UI_TEX_TYPE_PLIST)
		end
	end

	local item = __instance.dic:objectForKey(string.format("box_%d",3))
	item:showUp()
	self.toggleBoxFlag = true
end


--进场动画
function LotteryRenderMgr:playAnimsInto(target)
	for i=1,#target do
		local item = self.dic:objectForKey(string.format("box_%d",target[i]))
		item:setVisible(false)
	end

	local scene = LotteryScene:getInstance()
	local arr = CCArray:create()
	arr:addObject(CCDelayTime:create(0.1))
	for i=1,#target do  --这里动画只需显示前三个，因为第三个为原来的点击控件，不需要显示，所以是4个。
		arr:addObject(CCCallFunc:create(function()
			local item = self.dic:objectForKey(string.format("box_%d",target[i]))
			item:playAnimInto()
		end))
		if i ~= #target then 
			arr:addObject(CCDelayTime:create(0.1))
		end
	end
	scene:runAction(CCSequence:create(arr))
end

function LotteryRenderMgr:playAnimsOut(target)

end

--进场动画 块
function LotteryRenderMgr:playAnimIntoWithPanel(panel,func)
	
	panel:setScale(0.3)
	local arr = CCArray:create()
	arr:addObject(CCScaleTo:create(0.12,1.1))
	arr:addObject(CCScaleTo:create(0.1,1))
	arr:addObject(CCCallFunc:create(func))
	panel:stopAllActions()
	panel:runAction(CCSequence:create(arr))
end

function LotteryRenderMgr:init()
	
	require "LotteryBox"
	require "LotteryEvent"

	self.dic = CCDictionary:create() --缓存
	self.dic:retain()

	for i=1,10 do
		local itemicon = ItemIcon:create()
		self.dic:setObject(itemicon,string.format("itemicon_cache%d",i))
	end

	Notifier.regist(LotteryEvent.RENDER_UPDATE_ITEM,updateBoxItem)
	Notifier.regist(LotteryEvent.MSG_BOX_CLICK,event_box_click)
end

--渲染 抽奖宝箱
function LotteryRenderMgr:renderBoxList(listview)

	-- panel:removeAllChildren() --先清理
	listview:removeAllItems()

	local dp = LotteryDataProxy:getInstance()
	-- local viewTbl = {5,4,3,2,1}
	local viewTbl = {1,2,3,4,5,6}
	for i=1,#viewTbl do
		local viewVo = dp:getBoxViewVoById(viewTbl[i])
		item = LotteryBox:create( viewVo )
		
			self.dic:setObject(item,string.format("box_%d",viewVo.id))
			-- print(viewVo.id)
			-- if viewVo.id == 3 then --特殊处理坐标
			-- 	item:setPosition(ccp(0,170 * (i-1) + 10 ))
			-- else
			-- 	item:setPosition(ccp(0,170 * (i-1)))
			-- end
		
			-- panel:addChild(item)
			-- if i < 3 then
			-- 	listview:pushBackCustomItem(item)
			-- end


			if i == 5 then
				if CharacterDataProxy:getInstance():getTeamLev() >= 40 then
					listview:pushBackCustomItem(item)
				end
			else
				if i ~= 3 then
					listview:pushBackCustomItem(item)
				end
			end


			-- if i == 4 or i then
			-- 	listview:pushBackCustomItem(item)
			-- end
			
	end
	-- listview:setDirection(SCROLLVIEW_DIR_NONE)
	-- panel:setPositionY(-170 * 2 - 20)
end

function LotteryRenderMgr:panelScrol(t)
	-- local item = __instance.dic:objectForKey(string.format("box_%d",3))
	-- if t then --向下滑
	-- 	item:showUp()
	-- 	LotteryScene:getInstance().panelInner:runAction(CCMoveTo:create(0.17,ccp(0,-170 * 2 - 20)))
	-- else --向上滑
	-- 	item:showDown()
	-- 	LotteryScene:getInstance().panelInner:runAction(CCMoveTo:create(0.17,ccp(0,0)))
	-- end
end

--清理缓存
function LotteryRenderMgr:clearBoxList()
	local voList = LotteryDataProxy:getInstance():getBoxViewVoList()
	for i=1,#voList do
		self.dic:removeObjectForKey(string.format("box_%d",voList[i].id))
	end
end

function LotteryRenderMgr:createFixPosArr(startX,startY)

	self.fixPosArr = {}

	local col = 5
	local row = 2

	local idx = 0
	for i=0,row - 1 do

		for j=0,col - 1 do
			idx = idx + 1

			local height = 150
			local width = 150

			table.insert(self.fixPosArr, { x = j * width + startX, y = (row - i - 1) * height + startY })
		end
	end
end

--渲染 抽奖结果
function LotteryRenderMgr:renderResuleBox(container)
	--先清理
	for i=101,110 do
		local child = container:getChildByTag(i)
		if child ~= nil then
			container:removeChildByTag(i,true)
		end
	end
	for i=201,210 do
		local child = container:getChildByTag(i)
		if child ~= nil then
			container:removeChildByTag(i,true)
		end
	end
-----------------------------------------------------------
	local idx = 0
	local voList = LotteryDataProxy:getInstance():getResultVo().rewards
	local function step_create_result()
		idx = idx + 1

		if voList[idx] ~= nil then 
			
			local itemHeroVo = voList[idx]

			-- print(" t ",itemHeroVo.t)
			local item = ItemIcon:create()   --物品图标
			item:setBaseId(itemHeroVo.baseId)
			if idx == 1 and #voList == 1 then --单抽
				item:setPosition(ccp( 480, 320 ))
			else --十连抽
				item:setPosition(ccp( self.fixPosArr[ idx ].x , self.fixPosArr[ idx ].y ))
			end
			item:setTag(100 + idx)
			container:addChild(item)

			local itemVo = ItemManager:getInstance():getItemModelByBaseId(itemHeroVo.baseId)
			local labName = Label:create()  --物品名称
			labName:setText(itemVo.name)
			labName:setFontSize(22)
			labName:setPosition(ccp( item:getPositionX() , item:getPositionY() - 80 ))
			labName:setTag(200 + idx)
			labName:setColor(ccc3(251,241,160))
			container:addChild(labName)
		else
			-- TimerManager.removeTimer(step_create_result)
			container:stopAllActions()
		end
	end

	container:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
		CCCallFunc:create(step_create_result),
		CCDelayTime:create(0.05))))
	-- TimerManager.addTimer(50, step_create_result,true)
end

function LotteryRenderMgr:cleanResuleItem(container)
	--先清理
	for i=101,110 do
		local child = container:getChildByTag(i)
		if child ~= nil then
			container:removeChildByTag(i,true)
		end
	end
	for i=201,210 do
		local child = container:getChildByTag(i)
		if child ~= nil then
			container:removeChildByTag(i,true)
		end
	end
	for i=301,310 do
		local child = container:getChildByTag(i)
		if child ~= nil then
			container:removeChildByTag(i,true)
		end
	end
	local child = container:getChildByTag(1358)
	if child ~= nil then
		child:removeFromParentAndCleanup(true)
	end
end

--检测下一个要渲染的奖励
function LotteryRenderMgr:checkRenderReward(container) --传入resuleScene容器

	self.containerResule = container

	local voList = LotteryDataProxy:getInstance():getResultVo().rewards
	self.renderRewardIdx = self.renderRewardIdx + 1
	local itemHeroVo = voList[self.renderRewardIdx]
-----------------结束---------------------------------------------
	-- print(" 檢測結束  ",itemHeroVo,self.renderRewardIdx)
	if itemHeroVo == nil or self.renderRewardIdx > 10 then
		self.renderRewardIdx = 0 
		LotteryResult:getInstance():ableBtn()  
		return 
	end
--------------------------------------------------------------
	local idx = self.renderRewardIdx
	local item = self.dic:objectForKey(string.format("itemicon_cache%d",idx)) --物品图标
	-- local item = ItemIcon:create()   --物品图标
	item:setBaseId(itemHeroVo.baseId)
	
	if itemHeroVo.t == "normal" then
		item:setItemNum(itemHeroVo.quality or 1)
	else
		item:setItemNum(1)
	end

	if idx == 1 and #voList == 1 then --单抽
		item:setPosition(ccp( 480, 320 ))
	else --十连抽
		item:setPosition(ccp( self.fixPosArr[ idx ].x , self.fixPosArr[ idx ].y ))
	end
	item:setTag(100 + idx)
	self:playIconAnim(item)
	container:addChild(item,1)
	local itemVo = ItemManager:getInstance():getItemModelByBaseId(itemHeroVo.baseId)

	if itemVo.quality > 0 then
		local itemLight = ImageView:create()
		itemLight:loadTexture(string.format("lottery_quality%d.png",itemVo.quality),UI_TEX_TYPE_PLIST)
		itemLight:setPosition(ccp( item:getPosition() )) 
		itemLight:setTag(300 + idx) 
		container:addChild(itemLight)
		self:playIconLightAnim(itemLight)
	end

	local labName = Label:create()  --物品名称
	labName:setText(itemVo.name)
	labName:setFontSize(22)
	labName:setPosition(ccp( item:getPositionX() , item:getPositionY() - 80 ))
	labName:setTag(200 + idx)
	labName:setColor(ccc3(251,241,160))
	container:addChild(labName,1)

	if itemHeroVo.t == "normal" then
		container:runAction(CCSequence:createWithTwoActions(
			CCDelayTime:create(0.4),
			CCCallFunc:create(function()
				self:checkRenderReward(container)  --继续检测下一个
			end)))
	elseif itemHeroVo.t == "hero" then
		CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/hero/hero.plist","ui/hero/hero.pvr.ccz")
		container:runAction(CCSequence:createWithTwoActions(
			CCDelayTime:create(1),
			CCCallFunc:create(function()

			local animLayer = Layout:create()
			animLayer:setTag(1358)
		    container:addChild(animLayer,10)
		    require "GuideDataProxy"
		   	require "GuideCfg"
		    GuideDataProxy:getInstance().showGetHeroArea = GuideGetHeroArea.Lottery --记录展示区域
			self:renderShowCard(animLayer,itemHeroVo.heroId)
			print(" itemHeroVo.heroStar ",itemHeroVo.heroStar)

		end)))
	elseif itemHeroVo.t == "stone" then
		CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/hero/hero.plist","ui/hero/hero.pvr.ccz")
		container:runAction(CCSequence:createWithTwoActions(
			CCDelayTime:create(1),
			CCCallFunc:create(function()

			local animLayer = Layout:create()
			animLayer:setTag(1358)
		    container:addChild(animLayer,10)
		    require "GuideDataProxy"
		   	require "GuideCfg"
		    GuideDataProxy:getInstance().showGetHeroArea = GuideGetHeroArea.Lottery --记录展示区域
			self:renderShowCard(animLayer,itemHeroVo.heroId,itemHeroVo)
			print(" itemHeroVo.heroStar ",itemHeroVo.heroStar,itemHeroVo.heroId)
		end)))
	end
end

--播放图标动画
function LotteryRenderMgr:playIconAnim(target)
	local arr = CCArray:create()
    arr:addObject(CCEaseBackOut:create(CCScaleTo:create(0.3,1)))
	target:setScale(2)
	target:runAction(CCSequence:create(arr))
end

--播放图标光圈动画
function LotteryRenderMgr:playIconLightAnim(target)
	target:runAction(CCRepeatForever:create(CCRotateBy:create(3,360)))
end

--青铜和黄金宝箱倒计时
function LotteryRenderMgr:scheduleBoxs()

    for i=1,2 do --青铜和黄金
		local item = __instance.dic:objectForKey(string.format("box_%d",i))
		local viewVo = LotteryDataProxy:getInstance():getBoxViewVoById(i)
		item:update(viewVo)
	end
end

--展示卡牌
function LotteryRenderMgr:renderShowCard(container,heroId,itemHeroVo)
	
	ComResMgr:getInstance():loadOtherRes()
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/lottery/lottery_round.plist")
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/hero/hero.plist")
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/lottery/lottery.plist")
    CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/lottery/img_resultbg.plist")

    local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
 	local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()

 	local imgBg = nil
    local arr = CCArray:create()
    arr:addObject(CCCallFuncN:create(function(node)  --初始化
       -- CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA8888)

    	imgBg = ImageView:create()
    	imgBg:loadTexture("img_resultbg.png",UI_TEX_TYPE_PLIST)
    	imgBg:setScaleX(1/DisplayUtil.min_scale*globa_scalx)
    	imgBg:setScaleY(1/DisplayUtil.min_scale*globa_scaly)
		imgBg:setPosition(ccp(480,320))
		container:addChild(imgBg)
		-- CCTexture2D:setDefaultAlphaPixelFormat(kCCTexture2DPixelFormat_RGBA4444)

		local armRotate = ImageView:create()
		armRotate:loadTexture("lottery_fazheng.png",UI_TEX_TYPE_PLIST)
	    armRotate:setPosition(ccp(480,320))
	    armRotate:setScale(0)
	    local arr = CCArray:create()
	    arr:addObject(CCEaseIn:create(CCRotateBy:create(1.2,360),1))  --旋转
	    arr:addObject(CCRotateBy:create(0.9,360))
	    arr:addObject(CCRepeat:create(CCRotateBy:create(1.7,360),500))
	    armRotate:runAction(CCSequence:create(arr))
	    container:addChild(armRotate)

	    local arr1 = CCArray:create()
	    arr1:addObject(CCScaleTo:create(1.5,2.2)) --缩放
	    arr1:addObject(CCScaleTo:create(1.5,1.8))
	    -- arr1:addObject(CCScaleTo:create(1.5,1.5))
	    armRotate:runAction(CCSequence:create(arr1))

    end))
    arr:addObject(CCCallFuncN:create(function(node) --渐淡 然后消失
        	
        local imgWrite = CCLayerColor:create(ccc4(255, 255, 255, 255))
        imgWrite:setScaleX(1/DisplayUtil.min_scale*globa_scalx)
        imgWrite:setScaleY(1/DisplayUtil.min_scale*globa_scaly)
		container:addNode(imgWrite)
		local arr = CCArray:create()
	    -- arr:addObject(CCFadeIn:create(0.5)) --闪光 然后消失
	    arr:addObject(CCFadeOut:create(1.7))
	    arr:addObject(CCCallFuncN:create(function(node) 
	       	node:removeFromParentAndCleanup(true)
	    end))
		imgWrite:runAction(CCSequence:create(arr))

    end))
    arr:addObject(CCDelayTime:create(1))
    arr:addObject(CCCallFuncN:create(function(node) --初始化卡牌
    	require "HeroImgView"
    	local imgCard = HeroImgView:create()
    	-- print(" 英雄整卡id  ",heroId)
    	if itemHeroVo and itemHeroVo.t == "stone" then
    		imgCard:setData(heroId,itemHeroVo.heroStar)
    	else
    		imgCard:setData(heroId)
    	end
    	imgCard:setAnchorPoint(ccp(0.5,0.5))
    	imgCard:setPosition(ccp(480,320))
    	imgCard:setScale(0.56)
    	container:addChild(imgCard,1)
	    	
    	local imgWrite = ImageView:create()
    	imgWrite:loadTexture("lottery_light.png",UI_TEX_TYPE_PLIST)
    	imgWrite:setScale(2.45)
    	imgWrite:setAnchorPoint(ccp(0.5,0.5))
    	imgWrite:setPosition(ccp(0,0))
		imgCard:addChild(imgWrite,1)
    	local actFade = CCSequence:createWithTwoActions( --渐淡 然后消失
	        CCFadeOut:create(2),
	        CCCallFuncN:create(function(node) 
	        	node:removeFromParentAndCleanup(false)
	        end))
		imgWrite:runAction(actFade)

		-- local actScale = CCScaleTo:create(0.86,0.6) --卡牌旋转
		-- imgCard:runAction(actScale)

		local arr = CCArray:create()
		arr:addObject(CCEaseOut:create(CCRotateBy:create(1.5,360 * 2),2.5))
		arr:addObject(CCDelayTime:create(0.2))
		arr:addObject(CCCallFuncN:create(function(node) 
			local imgHeroCard = CCSprite:create("ui/lottery/faguang.png")
	    	imgHeroCard:setScaleX(1.945)
	    	imgHeroCard:setScaleY(1.93)
	    	imgCard:addNode(imgHeroCard)
	    	local arr = CCArray:create()
	    	arr:addObject(CCEaseOut:create(CCFadeOut:create(2.5),0.8))
	    	arr:addObject(CCCallFuncN:create(function(n)
	    			n:removeFromParentAndCleanup(false)
	    		end))
			imgHeroCard:runAction(CCSequence:create(arr))
		end))
		arr:addObject(CCDelayTime:create(2.5))
		if itemHeroVo and itemHeroVo.t == "stone" then
			arr:addObject(CCMoveBy:create(0.2,ccp(0,-30)))
		end
		arr:addObject(CCCallFuncN:create(function(n)
			if itemHeroVo and itemHeroVo.t == "stone" then
				local labTitle = Label:create()
				local heroVo = HeroManager:getInstance():getHeroInfoByBaseId(tonumber(heroId))
				labTitle:setText(string.format("你已獲得該英雄，將轉化為%d個英雄武魂",itemHeroVo.quality))
				labTitle:setPosition(ccp(480,600))
				labTitle:setColor(ccc3(251,241,160))
				labTitle:setFontSize(22)
				container:addChild(labTitle,1)
			end

			imgBg:setTouchEnabled(true)
	    	imgBg:addTouchEventListener(function(pSender,eventType)
	    		if eventType == ComConstTab.TouchEventType.ended then 
	    			imgBg:setTouchEnabled(false)
	    			imgCard:getClickWidget():setTouchEnabled(false)
	    			imgCard:close()
	    			imgCard:setPositionY(1000) --移出屏幕
	    			imgCard:setVisible(false)
	    			imgBg:setVisible(false)
	    			self:renderShowHero(container,heroId,itemHeroVo)
	    		end
	    	end)
	    	imgCard:setClickHandler(function(pSender,eventType)
	    		if eventType == ComConstTab.TouchEventType.ended then 
	    			imgBg:setTouchEnabled(false)
	    			imgCard:getClickWidget():setTouchEnabled(false)
	    			imgCard:close()
	    			imgCard:setPositionY(1000) --移出屏幕
	    			imgCard:setVisible(false)
	    			imgBg:setVisible(false)
	    			self:renderShowHero(container,heroId,itemHeroVo)
	    		end
	    	end)
		end))
		imgCard:runAction(CCSequence:create(arr))
    end))
    container:runAction(CCSequence:create(arr))
end

--展示英雄动画
function LotteryRenderMgr:renderShowHero(container,heroId,itemHeroVo)
	-- container:removeAllChildren()
	
	local heroVo = HeroManager:getInstance():getHeroInfoByBaseId(tonumber(heroId))

    local imgBg = ImageView:create()
    local globa_scalx = CCEGLView:sharedOpenGLView():getScaleX()
	local globa_scaly = CCEGLView:sharedOpenGLView():getScaleY()
	imgBg:setScaleX(1/DisplayUtil.min_scale*globa_scalx)
	imgBg:setScaleY(1/DisplayUtil.min_scale*globa_scaly)
	imgBg:setPosition(ccp(480,320))
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("ui/lottery/img_resultbg.plist")
    imgBg:loadTexture("img_resultbg.png",UI_TEX_TYPE_PLIST)
    container:addChild(imgBg)

	local widget = GUIReader:shareReader():widgetFromJsonFile("lottery/LotteryGetHero.ExportJson")
	container:addChild(widget)

	local imgRotate = tolua.cast(widget:getChildByName("img_round"),"ImageView")
	imgRotate:setScale(0.3)
	imgRotate:runAction(CCRepeatForever:create(CCRotateBy:create(3,360)))
	
	local imgRotate1 = tolua.cast(widget:getChildByName("img_rotate1"),"ImageView")
	imgRotate1:runAction(CCRepeatForever:create(CCRotateBy:create(5,360)))

	local imgRotate2 = tolua.cast(widget:getChildByName("img_rotate2"),"ImageView")
	imgRotate2:runAction(CCRepeatForever:create(CCRotateBy:create(2,360)))

	local imgRotate3 = tolua.cast(widget:getChildByName("img_rotate3"),"ImageView")
	imgRotate3:runAction(CCRepeatForever:create(CCRotateBy:create(8,360)))

	local labName = tolua.cast(widget:getChildByName("lab_name"),"Label")
	labName:setText(heroVo.name)

	local labTitle = tolua.cast(widget:getChildByName("lab_title"),"Label")
	if itemHeroVo and itemHeroVo.t == "stone" then
		labTitle:setVisible(false)
	else
		labTitle:setVisible(true)
	end

	local arr = CCArray:create()
	arr:addObject(CCScaleTo:create(0.12,1.1))
	arr:addObject(CCScaleTo:create(0.1,1))
	imgRotate:runAction(CCSequence:create(arr))

	local imgClick = tolua.cast(widget:getChildByName("img_click"),"ImageView") --点击区

	local action_data = EffectManager:getInstance():getActionData(heroVo:getModelId())
	local armHero = AnimateManager:getInstance():getArmature(action_data._fileFullPathName, action_data._fileName)
	local heroPanel = CCLayer:create()
	local heroBottomPanel = CCLayer:create()

	armHero:setScale(0.3)
	local arr = CCArray:create()
	arr:addObject(CCScaleTo:create(0.12,1.4))
	arr:addObject(CCScaleTo:create(0.1,1.3))
	armHero:runAction(CCSequence:create(arr))

	widget:addNode(heroBottomPanel)
	widget:addNode(heroPanel)
	heroPanel:setPosition(ccp(widget:getChildByName("p_1"):getPosition()))
	heroBottomPanel:setPosition(ccp(widget:getChildByName("p_1"):getPosition()))
	heroPanel:addChild(armHero)
	armHero:getAnimation():play("stand")

	local stard_act_list = HeroManager:getInstance():getHeroActListById(tonumber(heroId)) 
	local cur_action_idx = 0

	--英雄随即动作播放完成后
    local function playCallBack(armature, movementType, movementID)
		if movementType == AnimationMovementType.COMPLETE then 
			--播放一个动作后，移除关联特效
			if stard_act_list[cur_action_idx] and 
				stard_act_list[cur_action_idx][2] ~= nil then
			 	EffectManager:getInstance():removeEffect(heroPanel,stard_act_list[cur_action_idx][2], nil, 0)
			end

			if stard_act_list[cur_action_idx] and 
				stard_act_list[cur_action_idx][3] ~= nil and
				stard_act_list[cur_action_idx][3] >0 then
			 		EffectManager:getInstance():removeEffect(heroBottomPanel,stard_act_list[cur_action_idx][3], nil, 0)
			end

			cur_action_idx = cur_action_idx +1
			if cur_action_idx>#stard_act_list then
				armHero:getAnimation():play("stand")
				-- TimerManager.addTimer(10000, playCallBack,true)

				imgClick:setTouchEnabled(true)
			else
				armHero:getAnimation():play(stard_act_list[cur_action_idx][1],-1,-1,0)
				if stard_act_list[cur_action_idx][2] ~= nil then
			 		EffectManager:getInstance():playEffect(heroPanel,stard_act_list[cur_action_idx][2], nil, 0)
				end

				if stard_act_list[cur_action_idx][3] ~= nil and stard_act_list[cur_action_idx][3]>0 then
			 		EffectManager:getInstance():playEffect(heroBottomPanel,stard_act_list[cur_action_idx][3], nil, 0)
				end
			end
		end
	end

	local function startAnim()
		cur_action_idx = 1

		armHero:getAnimation():setMovementEventCallFunc(playCallBack)
		armHero:getAnimation():play(stard_act_list[cur_action_idx][1],-1,-1,0)

		if stard_act_list[cur_action_idx][2] ~= nil then
		 	EffectManager:getInstance():playEffect(heroPanel,stard_act_list[cur_action_idx][2], nil, 0)
		end
	end

	startAnim() --开始播放
--------------------------------------------------------------------------------------
	local btnOk = tolua.cast(widget:getChildByName("btn_ok"),"Button")
	btnOk:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then 
			container:removeFromParentAndCleanup(true)

			if GuideDataProxy:getInstance().showGetHeroArea == GuideGetHeroArea.Battle then
				Notifier.dispatchCmd(GuideEvent.ShowResuleView)
			elseif GuideDataProxy:getInstance().showGetHeroArea == GuideGetHeroArea.Lottery then
				self:checkRenderReward(self.containerResule)
			elseif GuideDataProxy:getInstance().showGetHeroArea == GuideGetHeroArea.MainScene or
			 		GuideDataProxy:getInstance().showGetHeroArea == GuideGetHeroArea.HeroListView then
				WindowCtrl:getInstance():close(CmdName.GuideHeroAnimScene)
			end
			-- CCTextureCache:sharedTextureCache():removeTextureForKey("ui/lottery/img_card1.png")
			CCTextureCache:sharedTextureCache():removeTextureForKey("ui/lottery/img_resultbg.png")
			CCTextureCache:sharedTextureCache():removeTextureForKey("ui/lottery/faguang.png")
			CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile("ui/lottery/img_resultbg.plist")
			CCSpriteFrameCache:sharedSpriteFrameCache():removeSpriteFramesFromFile("ui/lottery/lottery_round.plist")
		end
	end)
--------------------------------------------------------------------------------------
	imgClick:setTouchEnabled(false)
	imgClick:addTouchEventListener(function(pSender,eventType)
		if eventType == ComConstTab.TouchEventType.ended then 
			imgClick:setTouchEnabled(false)
			startAnim()
		end
	end)
end

--获得[英雄转化得来]的灵魂石
function LotteryRenderMgr:renderShowStone(container)

end

--渲染所购买物品即是必定得到物品
function LotteryRenderMgr:renderMustbox(layerout)

	layerout:removeAllChildren() --先清理
	local mustVoList = LotteryDataProxy:getInstance():getResultVo().must
	local mustItem = mustVoList[1] --过滤后的必定得到物品只有一种
	local baseId = mustItem.baseId
	local quality = mustItem.quality --这个是指数量而不是品质
	local itemVo = ItemManager:getInstance():getItemModelByBaseId(baseId)

	if quality > 0 then
		local itemLight = ImageView:create()
		itemLight:loadTexture(string.format("lottery_quality%d.png",itemVo.quality),UI_TEX_TYPE_PLIST)
		-- itemLight:setPosition(ccp( item:getPosition() )) 
		-- itemLight:setTag(300 + idx)
		layerout:addChild(itemLight)
		self:playIconLightAnim(itemLight) 
	end
	local item = ItemIcon:create()
	item:setBaseId(baseId)
	item:setItemNum(quality)
	-- self:playIconAnim(item)  --不再需要图标砸下去的动画
    layerout:addChild(item)

    local labName = Label:create()  --物品名称
	labName:setText(itemVo.name.."*"..quality)
	labName:setFontSize(22)
	labName:setPosition(ccp( item:getPositionX() , item:getPositionY() - 80 ))
	labName:setColor(ccc3(251,241,160))
	layerout:addChild(labName,1)
end