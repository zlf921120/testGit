--抽奖箱子详细数据
LotteryBoxVo = class("LotteryBoxVo")
LotteryBoxVo.id = 0
LotteryBoxVo.isDiscount = 0 -- 是否限时优惠
LotteryBoxVo.currency = 0 -- 货币单位
LotteryBoxVo.cost = 0 --消耗值(金币,钻石等)
LotteryBoxVo.titleType = 0  --标题类型
LotteryBoxVo.rewardType = 0 --获得的奖品类型
LotteryBoxVo.type = 0 --箱子类型(青铜,黄金等)
LotteryBoxVo.buyType = 0 --购买类型(单抽,十连抽)

--抽奖宝箱显示item
LotteryBoxViewVo = class("LotteryViewVo")
LotteryBoxViewVo.id = 0  --顺序
LotteryBoxViewVo.boxId = 0
LotteryBoxViewVo.rewards = nil
LotteryBoxViewVo.isFirstBuy = 0 --是否第一次首抽
LotteryBoxViewVo.lastFreeTime = 0 --XX分钟后免费
LotteryBoxViewVo.startFreeTime = 0 --免费开始计时
LotteryBoxViewVo.freeMax = 0 --今天总共免费次数
LotteryBoxViewVo.freeUse = 0 --今天使用过的免费次数

--抽奖结果页面
LotteryResultVo = class("LotteryResultVo")
LotteryResultVo.rewards = {} --奖励列表
LotteryResultVo.buyType = 0  --购买类型(单抽,十连抽)
LotteryResultVo.type = 0 --箱子类型(青铜,黄金等)
LotteryResultVo.must = {} --必定得到物品

--宝箱场景
LotterySceneVo = class("LotterySceneVo")
LotterySceneVo.choiceType = 0 --当前选择的箱子类型(青铜,黄金等)
LotterySceneVo.isHasGetFreashMan = 0 --是否已经拿过新手 的黄金宝箱

--抽奖英雄映射表值
LotteryHeroItemVo = class("LotteryHeroItemVo")
LotteryHeroItemVo.baseId = 0
LotteryHeroItemVo.heroId = 0
LotteryHeroItemVo.heroStar = 0 --英雄对应的星级

--英雄武魂 映射 英雄整卡
LotteryStoneHeroVo = class("LotteryStoneHeroVo")

--新消息提示 宝箱值对象
LotteryTipsBoxVo = class("LotteryTipsBoxVo")
LotteryTipsBoxVo.lastFreeTime = 0  --XX分钟后免费
LotteryTipsBoxVo.startFreeTime = 0 --免费开始计时
LotteryTipsBoxVo.freeMax = 0 --今天总共免费次数
LotteryTipsBoxVo.freeUse = 0 --今天使用过的免费次数
