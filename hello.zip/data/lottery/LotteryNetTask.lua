
--抽奖 宝箱 网络助手
LotteryNetTask = class("LotteryNetTask")

local __instance = nil
local _allowInstance = false

function LotteryNetTask:ctor()
    if not _allowInstance then
		error("LotteryNetTask is a singleton class")
	end
	self:init()
end

function LotteryNetTask:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = LotteryNetTask.new()
		_allowInstance = false
	end

	return __instance
end

function LotteryNetTask:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function LotteryNetTask:init()
	require "boxdraw_pb"
	require "LotteryDataProxy"
	require "proto_cmd_2_pb"
	require("ItemHelper")
	--注册网络事件
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.boxdraw_icon_click_rsp,"handleLotteryInfo()")
	Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.boxdraw_get_rsp,"handleBuyLotteryBox()")
end

--请求 宝箱抽奖 页面信息
function LotteryNetTask:requestLotteryInfo()

	print("-----------requestLotteryInfo-------------")
	local boxdraw_icon_click_req = boxdraw_pb.boxdraw_icon_click_req()
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.boxdraw_icon_click_req,boxdraw_icon_click_req)

end

--响应 宝箱抽奖 页面信息
function handleLotteryInfo(pkg)

	local boxdraw_icon_click_rsp = boxdraw_pb.boxdraw_icon_click_rsp()
	boxdraw_icon_click_rsp:ParseFromString(pkg)

	print("-----------handleLotteryInfo-------------",boxdraw_icon_click_rsp.ret)
	if boxdraw_icon_click_rsp.ret == error_code_pb.msg_ret.success then
		local nowTime = ServerTimerManager:getInstance():getCurTime()
		-- print(" boxdraw_icon_click_rsp.time , boxdraw_icon_click_rsp.bronze.time ",nowTime, boxdraw_icon_click_rsp.bronze.time)

		local dp = LotteryDataProxy:getInstance()

		local viewVoCopper = dp:getBoxViewVoById(LotteryBoxType.Copper) --青铜宝箱
		viewVoCopper.freeMax = boxdraw_icon_click_rsp.bronze.num_max
		viewVoCopper.freeUse = boxdraw_icon_click_rsp.bronze.num
		viewVoCopper.isFirstBuy = boxdraw_icon_click_rsp.bronze.state
		-- print( " viewVoCopper.isFirstBuy ",viewVoCopper.isFirstBuy)
		-- print("  boxdraw_icon_click_rsp.bronze.time ",boxdraw_icon_click_rsp.bronze.time)
		if viewVoCopper.freeUse < viewVoCopper.freeMax then --还可以免费领
			-- print(" boxdraw_icon_click_rsp.bronze.time ",boxdraw_icon_click_rsp.bronze.time)

			-- if boxdraw_icon_click_rsp.bronze.time > nowTime then  --注：上一次领取时间 大于 当前时间
			-- 	viewVoCopper.lastFreeTime = 0
			-- 	boxdraw_icon_click_rsp.bronze.time = 0
			-- else
			if boxdraw_icon_click_rsp.bronze.time == 0 then
				viewVoCopper.lastFreeTime = 0
			else
				viewVoCopper.lastFreeTime = 10 * 60 - ( nowTime - boxdraw_icon_click_rsp.bronze.time )  --冷却时间为10分钟
				if viewVoCopper.lastFreeTime < 0 then 
                	viewVoCopper.lastFreeTime = 0 
            	end
			end

			viewVoCopper.startFreeTime = boxdraw_icon_click_rsp.bronze.time
		end
		
		local viewVoGold = dp:getBoxViewVoById(LotteryBoxType.Gold) 	--黄金宝箱
		viewVoGold.freeMax = boxdraw_icon_click_rsp.gold.num_max
		viewVoGold.freeUse = boxdraw_icon_click_rsp.gold.num
		viewVoGold.isFirstBuy = boxdraw_icon_click_rsp.gold.state
		-- print( " viewVoGold.isFirstBuy ",viewVoCopper.isFirstBuy,viewVoGold.freeMax,viewVoGold.freeUse)
		-- if viewVoGold.freeUse < viewVoGold.freeMax then --还可以免费领
			-- if boxdraw_icon_click_rsp.gold.time > nowTime then

			-- else
			if boxdraw_icon_click_rsp.gold.time == 0 then --注：上一次领取时间 大于 当前时间
				viewVoGold.lastFreeTime = 0
			else
				viewVoGold.lastFreeTime = 48 * 60 * 60 - ( nowTime - boxdraw_icon_click_rsp.gold.time ) --冷却时间为48小时
				if viewVoGold.lastFreeTime < 0 then 
                	viewVoGold.lastFreeTime = 0 
            	end
			end

			viewVoGold.startFreeTime = boxdraw_icon_click_rsp.gold.time
		-- end

		local viewVoDead = dp:getBoxViewVoById(LotteryBoxType.Dead) 	--死灵宝箱
		viewVoDead.isFirstBuy = boxdraw_icon_click_rsp.dead_state
		local viewVoDeadClone = dp:getBoxViewVoById(4) --死灵宝箱  复本
		viewVoDeadClone.isFirstBuy = boxdraw_icon_click_rsp.dead_state

		local sceneVo = dp:getLotterySceneVo()
		sceneVo.choiceType = LotteryBoxType.Copper
		sceneVo.isHasGetFreashMan = boxdraw_icon_click_rsp.new_people_status

		Notifier.dispatchCmd(LotteryEvent.RENDER_UPDATE_SCENE)
		Notifier.dispatchCmd(LotteryEvent.RENDER_UPDATE_ITEM,1)
		Notifier.dispatchCmd(LotteryEvent.RENDER_UPDATE_ITEM,2)
		Notifier.dispatchCmd(LotteryEvent.RENDER_UPDATE_ITEM,3)
		Notifier.dispatchCmd(LotteryEvent.RENDER_UPDATE_ITEM,4)
		Notifier.dispatchCmd(LotteryEvent.RENDER_UPDATE_ITEM,5)
		Notifier.dispatchCmd(LotteryEvent.RENDER_UPDATE_ITEM,6)
		Notifier.dispatchCmd(LotteryEvent.INIT_SCENE)

		ComSender:getInstance():dealExtInfo(boxdraw_icon_click_rsp.ext)
	else
		Alert:show(Helper.getErrStr(boxdraw_icon_click_rsp.ret))
	end
end

--请求 抽奖
local _lastBoxType = nil --上一次购买宝箱的类型
local _lastBuyType = nil --上一次购买的方式
function LotteryNetTask:requestBuyLotteryBox(type,buyType)

	print("-----------requestBuyLotteryBox-------------",type,buyType)
	local boxdraw_get_req = boxdraw_pb.boxdraw_get_req()
	boxdraw_get_req.box.box_type = type
	boxdraw_get_req.box.type = buyType

	if type == 5 then --新手礼包特殊处理
		_lastBoxType = LotteryBoxType.Gold
		_lastBuyType = LotteryBuyType.BuyOneFree
		--新手引导(如果拿过 就不要播放)
		CharacterManager:getInstance():getBaseData()._isGetGuideLotteryBox = 1
	else
		_lastBoxType = type
		_lastBuyType = buyType
	end
	ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.boxdraw_get_req,boxdraw_get_req)
end

--响应 抽奖
function handleBuyLotteryBox(pkg)

	local boxdraw_get_rsp = boxdraw_pb.boxdraw_get_rsp()
	boxdraw_get_rsp:ParseFromString(pkg)

	print("-----------handleBuyLotteryBox-------------",boxdraw_get_rsp.ret)
	if boxdraw_get_rsp.ret == error_code_pb.msg_ret.success then

		local dp = LotteryDataProxy:getInstance()
		local resultVo = dp:createResultVo()

		local items = boxdraw_get_rsp.items
		local must_items = boxdraw_get_rsp.must_items

		resultVo.rewards = {} --清空
		resultVo.must = {} --清空必定得到物品table
		print("must_items",#must_items)
		for i,v in ipairs(must_items) do
			if (ItemHelper:isSoulStone(v.base_id) == false) then
				table.insert(resultVo.must,{ t = "must",baseId = v.base_id ,quality = v.quantity })
			end
		end
		print("過濾後的must_items",#resultVo.must)
		LotteryRenderMgr:getInstance().renderRewardIdx = 0
		ItemManager:getInstance():addMultiItem(items)  --更新背包
		ItemManager:getInstance():addMultiItem(must_items) --必得物品

		HeroManager:getInstance():refreshAllHero(boxdraw_get_rsp.heroes) --刷新英雄数据

		MathUtil.shuffleList(items) --打乱数组

		local items = boxdraw_get_rsp.items
		for i,v in ipairs(items) do
			print(" t ","normal",v.base_id)
			table.insert(resultVo.rewards,{ t = "normal", sortIdx = 1, baseId = v.base_id ,quality = v.quantity })
		end

		local items = boxdraw_get_rsp.heroes_items
    	for i=1,#items do
			local heroItemVo = LotteryDataProxy:getInstance():getLotteryHeroItemVoById(items[i].base_id)
			local heroId = heroItemVo.heroId
			local heroStar = heroItemVo.heroStar
			local quality = items[i].quantity

			print(" t ","hero",heroId,heroStar)  
			table.insert(resultVo.rewards,
				{ t = "hero" ,sortIdx = 2, baseId = items[i].base_id , heroId = heroId , heroStar = heroStar, quality = quality })
		end

		local items = boxdraw_get_rsp.heroes_goods
    	for i=1,#items do
			local heroItemVo = LotteryDataProxy:getInstance():getLotteryHeroItemVoById(items[i].hero_id)
			local heroId = heroItemVo.heroId
			local heroStar = heroItemVo.heroStar
			local quality = items[i].num

			print(" t ","stone",heroId,heroStar)  
			table.insert(resultVo.rewards,
				{ t = "stone" , sortIdx = 3, baseId = items[i].hero_id , heroId = heroId , heroStar = heroStar, quality = quality })
		end
		
		table.sort( resultVo.rewards, function(a,b)
			if a.sortIdx > 1 and b.sortIdx > 1 then
				return a.sortIdx < b.sortIdx
			else
				return false
			end
		end )

		local assets = boxdraw_get_rsp.assets
		CharacterManager:getInstance():updateRoleAssets(assets) --更新资产

		local _nextBuyType = _lastBuyType --更新下一次购买类型
		if _lastBuyType == LotteryBuyType.BuyOneFree then --如果是免费 单抽
			if _lastBoxType == LotteryBoxType.Copper or _lastBoxType == LotteryBoxType.Gold then --青铜宝箱或黄金宝箱(特殊处理 5是新手引导id 当黄金宝箱一样处理 )
----------------------------------------------------------------------------------------------	
				--更新宝箱绿点数据			
				local boxTip = dp:getLotteryTipsBoxVoById(_lastBoxType)
				if boxTip.freeUse < boxTip.freeMax or _lastBoxType == LotteryBoxType.Gold then --黄金宝箱特48小时
					boxTip.freeUse = boxTip.freeUse + 1 --更新已使用的免费次数
					boxTip.startFreeTime = ServerTimerManager:getInstance():getCurTime()
				end
				-- print(" boxTip.freeUse , boxTip.freeMax ",boxTip.freeUse , boxTip.freeMax)
--------------------------------------------------------------------------------------------
				local viewVo = dp:getBoxViewVoById(_lastBoxType) 
				-- print(" viewVo.freeUse , viewVo.freeMax ",viewVo.freeUse , viewVo.freeMax)
				if viewVo.freeUse < viewVo.freeMax or _lastBoxType == LotteryBoxType.Gold then --黄金宝箱特48小时
					viewVo.freeUse = viewVo.freeUse + 1  --更新已使用的免费次数
					viewVo.startFreeTime = ServerTimerManager:getInstance():getCurTime()

					_nextBuyType = LotteryBuyType.BuyOne --如果上一次是免费 那么这次就要收费了
				end
			end
		else
			local viewVo = dp:getBoxViewVoById(_lastBoxType) 
			viewVo.isFirstBuy = 1
			if _lastBoxType == LotteryBoxType.Dead then  --3和4一样。。
				dp:getBoxViewVoById(4).isFirstBuy = 1
			end
		end

		--特殊渲染条目...
		Notifier.dispatchCmd(LotteryEvent.RENDER_UPDATE_ITEM,_lastBoxType)
		if _lastBoxType == LotteryBoxType.Dead then  --3和4一样。。
			Notifier.dispatchCmd(LotteryEvent.RENDER_UPDATE_ITEM,4)
		elseif _lastBoxType == LotteryBoxType.Eqmuip then --装备项
			Notifier.dispatchCmd(LotteryEvent.RENDER_UPDATE_ITEM,5)
		end
		Notifier.dispatchCmd(LotteryEvent.RENDER_UPDATE_SCENE)

		WindowCtrl:getInstance():open(CmdName.Lottery_Result ,{ boxType = _lastBoxType, buyType = _nextBuyType })
		
		if _lastBuyType == LotteryBuyType.GuideBuy then --
			dp:getLotterySceneVo().isHasGetFreashMan = 1 
		end

		ComSender:getInstance():dealExtInfo(boxdraw_get_rsp.ext)
		--检测是否更新 系统设置时间
		dp:isCanAddOneOffNotice()
		dp.progressSchedule()

		--新手引导事件
		if GuideDataProxy:getInstance().nowMainTutroialEventId == 11103 then
            Notifier.dispatchCmd(GuideEvent.StepFinish,"click_lotterybuyone1")
        end
	else
		Alert:show(Helper.getErrStr(boxdraw_get_rsp.ret))
	end
end