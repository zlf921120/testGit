-- 抽奖结果页面

LotteryResult = class("LotteryResult",WindowBase)
LotteryResult.__index = LotteryResult
LotteryResult._widget    = nil
LotteryResult.uiLayer    = nil
-- LotteryResult.is_dispose = true

local __instance = nil
local _buyType = nil
local _boxType = nil

function LotteryResult:create()
    local ret = LotteryResult.new()
    __instance = ret
    return ret   
end

function LotteryResult:dispose()
    if self._widget then
        self._widget:removeFromParentAndCleanup(true)
    end
    Notifier.remove(GuideEvent.ShowStepAnim,self._showStepAnim)
end

local function event_btn_ok(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
		WindowCtrl:getInstance():close(CmdName.Lottery_Result)
	end
end

local function event_btn_again(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then

		local buyType = tolua.cast(pSender,"Button"):getTag()
        print("  buyType ",buyType, "  boxType ",_boxType)
		LotteryNetTask:getInstance():requestBuyLotteryBox(_boxType,buyType)
	end
end

function LotteryResult:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("lottery/LotteryResule.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    self.btnOk = tolua.cast(self._widget:getChildByName("btn_ok"),"Button")
	self.btnOk:addTouchEventListener(event_btn_ok)

	self.btnAgain = tolua.cast(self._widget:getChildByName("btn_ten"),"Button")
	self.btnAgain:addTouchEventListener(event_btn_again)

    self.img_box = self._widget:getChildByName("img_box")
    self.img_box:setVisible(true)

	local p_icon = self._widget:getChildByName("p_icon")
	LotteryRenderMgr:getInstance():createFixPosArr(p_icon:getPosition())

    self.must_icon = self._widget:getChildByName("must_icon")

    self._showStepAnim = function(param)
        self:showStepAnim(param)
    end
    --新手引导
    Notifier.regist(GuideEvent.ShowStepAnim,self._showStepAnim)
end

function LotteryResult:showStepAnim(param)
    if param.target == "lottery_btnresultok" then
        GuideRenderMgr:getInstance():renderMainFlag(self.btnOk,param.id,param.target)
    end
end

function LotteryResult:open()


	_boxType = self.params["boxType"]
	_buyTpye = self.params["buyType"]

    print(" 抽獎類型: ",_boxType,_buyTpye)

	local dp = LotteryDataProxy:getInstance()
    local viewVo = dp:getBoxViewVoById(_boxType) --当前选择的宝箱类型
    local btnAgain = tolua.cast(self._widget:getChildByName("btn_ten"),"Button")
    local labCost = tolua.cast(self._widget:getChildByName("lab_cost"),"Label")
    local imgUnit = tolua.cast(self._widget:getChildByName("img_unit"),"ImageView")
----------------------------------------------------------
    local checkBox = nil
    local voListBox = dp:getBoxVoList()
    for id,v in pairs(voListBox) do
        if v.type == _boxType and v.buyType == _buyTpye then --十连抽
            checkBox = v
        end
    end

    labCost:setText(checkBox.cost)

    local function updateUnit(imgUnit,boxVo)
        if boxVo.currency == MoneyType.Diamond then 
            imgUnit:loadTexture("diamond.png",UI_TEX_TYPE_PLIST)  --默认是钻石
        elseif boxVo.currency == MoneyType.Coin then
            imgUnit:loadTexture("gold.png",UI_TEX_TYPE_PLIST)
        end
    end
    updateUnit(imgUnit,checkBox)
----------------------------------------------------------

    if _boxType == LotteryBoxType.Copper or 
    	_boxType == LotteryBoxType.Gold then --青铜或黄金宝箱

    	if _buyTpye == LotteryBuyType.BuyOne or _buyTpye == LotteryBuyType.BuyOneFree then --单抽

	    	-- if viewVo.freeUse < viewVo.freeMax then --还可以免费领
		        -- if viewVo.lastFreeTime == 0 then --冷却时间没了
		        --     --免费购买
		        --     btnAgain:setTitleText("免費購買")
		        --     btnAgain:setTag(LotteryBuyType.BuyOneFree)
		        --     labCost:setText("0") --免费购买
		        -- else
		           	-- btnAgain:setTitleText("再來一次")
		           	-- btnAgain:setTag(LotteryBuyType.BuyOne)
		        -- end
		    -- else --不能免费领了
		        btnAgain:setTitleText("再來一次")
		        btnAgain:setTag(LotteryBuyType.BuyOne)
		    -- end

    	elseif _buyTpye == LotteryBuyType.BuyTen then --十连抽
    		btnAgain:setTitleText("再抽10次")
    		btnAgain:setTag(LotteryBuyType.BuyTen)
    	end

    elseif _boxType == LotteryBoxType.Dead or _boxType == LotteryBoxType.Eqmuip  then --亡灵/装备宝箱

    	if _buyTpye == LotteryBuyType.BuyOne then
    		btnAgain:setTitleText("再來一次")
    		btnAgain:setTag(LotteryBuyType.BuyOne)
    	elseif _buyTpye == LotteryBuyType.BuyTen then
    		btnAgain:setTitleText("再抽10次")
    		btnAgain:setTag(LotteryBuyType.BuyTen)
    	end
    end
    ----------------开始渲染-------------------
	-- LotteryRenderMgr:getInstance():renderResuleBox(self._widget)
    -- local animLayer = Layout:create()
    -- self._widget:addChild(animLayer,10)
    -- GuideDataProxy:getInstance().showGetHeroArea = GuideGetHeroArea.Lottery --记录展示区域
    -- LotteryRenderMgr:getInstance():renderShowCard(animLayer,10000)
    LotteryRenderMgr:getInstance():cleanResuleItem(self._widget)
    LotteryRenderMgr:getInstance():checkRenderReward(self._widget)
    LotteryRenderMgr:getInstance():renderMustbox(self.img_box)
    -- LotteryRenderMgr:getInstance():renderMustbox(self.must_icon)

    self:disableBtn()
end

function LotteryResult:close()
    --新手引导事件
    if GuideDataProxy:getInstance().nowMainTutroialEventId == 11104 then
        Notifier.dispatchCmd(GuideEvent.StepFinish,"click_lottery_btnresultok")
    end
end

function LotteryResult:getInstance()
    return __instance
end

function LotteryResult:disableBtn()
    self.btnAgain:setBright(false)
    self.btnAgain:setTouchEnabled(false)
    self.btnOk:setBright(false)
    self.btnOk:setTouchEnabled(false)
end

function LotteryResult:ableBtn()
    self.btnAgain:setBright(true)
    self.btnAgain:setTouchEnabled(true)
    self.btnOk:setBright(true)
    self.btnOk:setTouchEnabled(true)
end

