
LotteryLocalReader = class("LotteryLocalReader")

local __instance = nil
local _allowInstance = false
local _hasLoad = false

function LotteryLocalReader:ctor()
    if not _allowInstance then
		error("LotteryLocalReader is a singleton class")
	end
	self:init()
end

function LotteryLocalReader:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = LotteryLocalReader.new()
		_allowInstance = false
	end

	return __instance
end

function LotteryLocalReader:init()

	require "fnt_boxdraw_data_pb"
	require "LotteryDataProxy"
	require "ShopCfg"

end

function LotteryLocalReader:loadInProxy()

	if _hasLoad then return end--只加载一次
	_hasLoad = true

	local dp = LotteryDataProxy:getInstance()
    local pbdata = FileUtils.readConfigFile("fnt_boxdraw_data.dat")
    
    local msg = fnt_boxdraw_data_pb.fnt_boxdraw_data()
    msg:ParseFromString(pbdata)
  
	local item = nil
	------------宝箱映射------------------------
    local enumUnit = msg.reward_type_rows
    for i, v in pairs(enumUnit) do
        if v.id ~= nil then

			item = dp:createBoxVo()
			item.id = v.id
			item.type = v.box_type
			item.buyType = v.type
			item.isDiscount = 0 --临时
			
			item.currency = v.loss_type
			if v.loss_type == MoneyType.None then
				item.cost = 0
			elseif v.loss_type == MoneyType.Coin then
				item.cost = v.loss_coin
			elseif v.loss_type == MoneyType.Diamond then
				item.cost = v.loss_gold
			end
			dp:setBoxVo(item)
        end
    end

    --------------宝箱显示列表------------------------
    local viewUnit = msg.view_box_rows
    for j, v in pairs(viewUnit) do
    	if v.box_id ~= nil then
			item = dp:createBoxViewVo()
			item.id = v.sort
			item.boxId = v.box_id
			item.rewards = Utils.split(v.rewards,",")
			if item.id == 5 then
				item.isFirstBuy = 1 --没有首抽
			end
			dp:setBoxViewVo(item)
		end
    end
    ---------------英雄武魂 映射 英雄整卡------------------------------------
    local heroStoneUnit = msg.have_hero_id_rows
    for j, v in pairs(heroStoneUnit) do
    	if v.goods_id ~= nil then
    		item = dp:createLotteryStoneHeroVo()
    		item.baseId = v.base_id
    		item.goodsId = v.goods_id
    		dp:setLotteryStoneHeroVo(item)
    	end
    end
end