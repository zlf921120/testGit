--抽奖 可能掉落物品 面板

LotteryDrop = class("LotteryDrop",WindowBase)
LotteryDrop.__index = LotteryDrop
LotteryDrop._widget     = nil
LotteryDrop.uiLayer    = nil

local __instance = nil

function LotteryDrop:create()
    local ret = LotteryDrop.new()
    ret:init()
    return ret   
end

local function event_img_shadow(pSender,eventType)
	if eventType == ComConstTab.TouchEventType.ended then
        __instance:removeFromParentAndCleanup(true)
	end
end

function LotteryDrop:init()

	self._widget = GUIReader:shareReader():widgetFromJsonFile("lottery/LotteryDrop.ExportJson")
    __instance = self._widget

    -- local imgShadow = tolua.cast(self._widget:getChildByName("img_shadow"),"ImageView")
    -- imgShadow:addTouchEventListener(event_img_shadow)
end

function LotteryDrop:open()

    local id = self.params["id"]
    local viewVo = LotteryDataProxy:getInstance():getBoxViewVoById(id)
    local dropTbl = viewVo.rewards

    local startX,startY = self._widget:getChildByName("p_icon"):getPosition()

    local col = 5
    local row = 2

    local idx = 0
    for i=0,row - 1 do

        for j=0,col - 1 do
            idx = idx + 1

            local height = 100
            local width = 100

            if dropTbl[idx] ~= nil then
                local item = ItemIcon:create()
                item:setBaseId(tonumber(dropTbl[idx]))
                item:setPosition( ccp(j * width + startX, (row - i - 1) * height + startY ) )
                item:setTag(100 + idx)
                self._widget:addChild(item,2)
            end
        end
    end

end

function LotteryDrop:close()

end