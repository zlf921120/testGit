
--获取英雄整卡 动画层
LotteryGetCard = class("LotteryGetCard",WindowBase)
LotteryGetCard.__index = LotteryGetCard
LotteryGetCard._widget = nil
LotteryGetCard.uiLayer = nil

local __instance = nil

function LotteryGetCard:create()
    local ret = LotteryGetCard.new()
    __instance = ret
    return ret
end

function LotteryGetCard:init()

	require "LotteryRenderMgr"

	self._widget = GUIReader:shareReader():widgetFromJsonFile("lottery/LotteryGetCard.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)


end

function LotteryGetCard:open()
	local heroId = self.params["heroId"]
	-- local 

	
	
end

