--宝箱 条目

LotteryBox = class("LotteryBox",function()
    return Layout:create()
end)
LotteryBox.__index = LotteryBox
LotteryBox._widget 		= nil
LotteryBox.uiLayer 	= nil
LotteryBox.viewId = 0

function LotteryBox:create(viewVo)
    local ret = LotteryBox.new()
    ret:init(viewVo)
    return ret
end

local function event_img_click(pSender,eventType)
    if eventType == ComConstTab.TouchEventType.began then
        local id = tolua.cast(pSender,"ImageView"):getTag()
        Notifier.dispatchCmd(LotteryEvent.MSG_BOX_CLICK,id)
    end
end

function LotteryBox:init(viewVo)

	self._widget = LotteryDataProxy:getInstance():getLotteryBoxWidget():clone()
	if viewVo.id == 1 then --特殊处理尺寸
		self:setSize(CCSize(558,180))
	else
    	self:setSize(CCSize(558,180))
	end
    self:addChild(self._widget)

    local boxVo = LotteryDataProxy:getInstance():getBoxVoById(viewVo.boxId)

    -- local imgDiscount = self._widget:getChildByName("img_discount")
    -- imgDiscount:setVisible( boxVo.isDiscount == 1 )

    local imgUnit = tolua.cast(self._widget:getChildByName("img_unit"),"ImageView")
    if boxVo.currency == MoneyType.Diamond then 
        imgUnit:loadTexture("diamond.png",UI_TEX_TYPE_PLIST)  --默认是钻石
    elseif boxVo.currency == MoneyType.Coin then
        imgUnit:loadTexture("gold.png",UI_TEX_TYPE_PLIST)
    end

    local imgClick = tolua.cast(self._widget:getChildByName("img_bg"),"ImageView")
    imgClick:addTouchEventListener(event_img_click)

    if viewVo.id == 4 or viewVo.id == 5 then
    	imgClick:loadTexture("lottery_bg3_2.png",UI_TEX_TYPE_PLIST)
    else
    	imgClick:loadTexture(string.format("lottery_bg%d.png",math.min(boxVo.type,3)),UI_TEX_TYPE_PLIST)
	end

    --初始化BOX边框图片
    local img_bgframe = tolua.cast(self._widget:getChildByName("img_bgframe"),"ImageView")
    if viewVo.id < 5 then
        img_bgframe:loadTexture("lottery_boxbg.png", UI_TEX_TYPE_PLIST)
    else
        img_bgframe:loadTexture("lottery_boxbg3.png", UI_TEX_TYPE_PLIST)
    end

    imgClick:setTag(viewVo.id)

    local labTime = tolua.cast(self._widget:getChildByName("lab_lasttime"),"Label")
    labTime:setVisible(not (boxVo.type >= LotteryBoxType.Dead) )

    local labTimeFix = tolua.cast(self._widget:getChildByName("lab_fixtime"),"Label")
    labTimeFix:setVisible(not (boxVo.type >= LotteryBoxType.Dead) )

    local imgTitle = tolua.cast(self._widget:getChildByName("img_title"),"ImageView")
    if viewVo.id == 6 then
        imgTitle:loadTexture(string.format("i18n_lottery_box_title%d.png",2),UI_TEX_TYPE_PLIST) --新增宝箱也是购买极品经验药水
    else
        imgTitle:loadTexture(string.format("i18n_lottery_box_title%d.png",math.min(boxVo.type,3)),UI_TEX_TYPE_PLIST)
    end
    local imgBox = tolua.cast(self._widget:getChildByName("img_box"),"ImageView")
    imgBox:loadTexture(string.format("lottery_box%d.png", viewVo.id),UI_TEX_TYPE_PLIST)
    if viewVo.id == 6 then --美术资源给的珍藏宝箱头像太大，要特殊调整
        imgBox:setPosition(ccp(imgBox:getPositionX()+10,imgBox:getPositionY()+5))
    end

    local imgFirst = tolua.cast(self._widget:getChildByName("img_first"),"ImageView")
    imgFirst:setVisible( viewVo.isFirstBuy == 0  ) --是否首抽

    self.imgArrow = tolua.cast(self._widget:getChildByName("img_arrow"),"ImageView")
    self.imgMask = tolua.cast(self._widget:getChildByName("img_mask"),"ImageView")

    self.viewId = viewVo.id
end

function LotteryBox:update(viewVo)

    local imgUnit = tolua.cast(self._widget:getChildByName("img_unit"),"ImageView")
    imgUnit:setVisible(true)
    local imgFirst = tolua.cast(self._widget:getChildByName("img_first"),"ImageView")
    local boxVo = LotteryDataProxy:getInstance():getBoxVoById(viewVo.boxId)

    local labCost = tolua.cast(self._widget:getChildByName("lab_price"),"Label")
    labCost:setVisible(true)
    labCost:setText(boxVo.cost)

    local isVis = viewVo.id == 3 and CharacterDataProxy:getInstance():getTeamLev() >= 40
   	-- self.imgArrow:setVisible( isVis ) --特殊处理
    self.imgArrow:setVisible(false)

    if isVis then
        self:playArrowAnim()
    end

    self.imgMask:setVisible(not isVis)
    imgUnit:setVisible(not isVis)
    labCost:setVisible(not isVis)

    imgFirst:setVisible( viewVo.isFirstBuy == 0 ) --是否首抽

    local imgRewardType = tolua.cast(self._widget:getChildByName("img_rewardtype"),"ImageView")
    if boxVo.type ==6 then  --珍藏宝箱的奖励文字过长超出边框，所以调整位置
        imgRewardType:setPosition(ccp(imgRewardType:getPositionX() - 10,imgRewardType:getPositionY()))
    end
    -- print("boxVo.type ===  viewVo",boxVo.type,viewVo.id)
    if boxVo.type ~= LotteryBoxType.Eqmuip and boxVo.type~= LotteryBoxType.Rare then --装备宝箱特殊处理

        -- print(" boxVo.type ",boxVo.type)
        
        if viewVo.isFirstBuy == 0 then
            imgRewardType:loadTexture( string.format("i18n_lottery_reward%d.png",boxVo.type),UI_TEX_TYPE_PLIST )
        else
            imgRewardType:loadTexture( string.format("i18n_lottery_reward%d_1.png",boxVo.type),UI_TEX_TYPE_PLIST )
        end
    elseif boxVo.type == LotteryBoxType.Rare then
            imgRewardType:loadTexture("i18n_lottery_reward5.png",UI_TEX_TYPE_PLIST ) --珍藏宝箱
            imgFirst:setVisible(false)
        else        
            imgRewardType:loadTexture("i18n_lottery_reward4.png",UI_TEX_TYPE_PLIST )
    end
   
    local labFinish = self._widget:getChildByName("lab_finish")
    local labTime = tolua.cast(self._widget:getChildByName("lab_lasttime"),"Label")
    local labFixTime = tolua.cast(self._widget:getChildByName("lab_fixtime"),"Label")

    -- print(" viewVo.lastFreeTime ",viewVo.lastFreeTime)

    if boxVo.type == LotteryBoxType.Copper --[[or boxVo.type == LotteryBoxType.Gold]]  then --青铜 

        if viewVo.freeUse < viewVo.freeMax then --还没用完免费次数
            labFinish:setVisible(false)
            if viewVo.lastFreeTime == 0 then --冷却时间没了
                labTime:setVisible(false)
                labFixTime:setVisible(false)

                labCost:setText("免費") --免费购买
            else
                labTime:setVisible(true)
                labFixTime:setVisible(true)
            end
            labTime:setText(Helper.sec2TimeStr(viewVo.lastFreeTime))
        else
            labFinish:setVisible(true)
            labTime:setVisible(false)
            labFixTime:setVisible(false)
        end
        
    end
------------------------------------------------------------------
    if boxVo.type == LotteryBoxType.Gold then -- 黄金
        -- print(" viewVo.lastFreeTime ",viewVo.lastFreeTime)
        if viewVo.lastFreeTime == 0 then
            labTime:setVisible(false)
            labFixTime:setVisible(false)

            labCost:setText("免費") --免费购买
        else
            labTime:setVisible(true)
            labFixTime:setVisible(true)
            labTime:setText(Helper.sec2TimeStr(viewVo.lastFreeTime))
        end
    end
end

--箭头动画
function LotteryBox:playArrowAnim()

    local idx = 0
    local flag = 1
    self.imgArrow:stopAllActions()
    self.imgArrow:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
        CCCallFunc:create(function()
            idx = idx + flag
            local value = 255 * (idx / 10)
            self.imgArrow:setOpacity(value)
            if idx == 10 then 
                flag = -1
            elseif idx == 6 then
                flag = 1
            end
        end),
        CCDelayTime:create(0.1))))
end

--进场动画
function LotteryBox:playAnimInto()

    local arr = CCArray:create()
    arr:addObject(CCShow:create())
    arr:addObject(CCPlace:create(ccp(558,self:getPositionY())))
    -- arr:addObject(CCEaseBackOut:create(CCMoveTo:create(0.2,ccp(0,self:getPositionY()))))
    arr:addObject(CCMoveTo:create(0.06,ccp(0,self:getPositionY())))
    self:stopAllActions()
    self:runAction(CCSequence:create(arr))
end

function LotteryBox:showUp()
	self.imgArrow:setScaleX(0.70)
end

function LotteryBox:showDown()
	self.imgArrow:setScaleX(-0.70)
end

-- --退场动画
-- function LotteryBox:playAnimOut()

--     local arr = CCArray:create()
--     arr:addObject(CCShow:create())
--     arr:addObject(CCPlace:create(ccp(0,self:getPositionY())))
--     arr:addObject(CCMoveTo:create(0.15,ccp(0,self:getPositionY())))
--     self:stopAllActions()
--     self:runAction(CCSequence:create(arr))
-- end