--
-- Author: lvgansheng
-- Date: 2014-08-06 16:51:31
-- 竞技场管理器


ArenaManager = class("ArenaManager")

local _instance = nil
local _allowInstance = false

ArenaManager.remain_num = 0 --剩余可挑战次数
ArenaManager.end_cold_date = 0 --倒计时结束的时间
ArenaManager.arena_point = 0 --竞技积分
ArenaManager.arena_rank = 0 --竞技排名

--常量定义
ArenaManager.total_num = 5 --每天可挑战总次数
ArenaManager.total_cold_secs = 600 --总共倒计时的秒数

ArenaManager.enemy_list = nil -- 主界面刷新出来的三个可挑战敌人信息
ArenaManager.rank_list = nil -- 排行榜信息列表	
ArenaManager.battle_record_list = nil -- 对战记录列表	

ArenaManager.day_rewards = nil --竞技场每日排名奖励
ArenaManager.rank_list = nil --竞技场排行榜数据
ArenaManager.record_list = nil --竞技场对战记录
ArenaManager.arena_reset_num = 0 --重置次数
ArenaManager.history_rank = 0 --重置次数

ArenaManager.send_reset_role_id = 0--发送重置协议的对象,0表示总的重置按钮，>0表示EnemyItem的挑战按钮

function ArenaManager:ctor()
    if not _allowInstance then
        error("ArenaManager is a singleton class,please call getInstance method")
    end

    require("OtherRoleInfo")
    -- require("character/RoleId")
    require("RoleId")
    require("arena_pb")
    require("fnt_arena_data_pb")
    require("ArenaRecordData")

    self.enemy_list = {}
    self.day_rewards = {}
    self.rank_list = {}
    self.record_list = {}

    --相应需要监听的事件
    self:addListens()
end

function ArenaManager:getInstance()
    if _instance == nil then
        _allowInstance = true
        _instance = ArenaManager.new()
        _allowInstance = false
    end
    return _instance
end

--读取竞技场数据
function ArenaManager:readArenaData()

    if self.read_arena_data == true then
        return
    end

    local pbdata = Global:getAssetFileData("fnt_arena_data.dat", "rb")

    local msg = fnt_arena_data_pb.fnt_arena_data()
    msg:ParseFromString(pbdata)

    --名次奖励信息
    local day_reward_rows = msg.day_reward_rows
    local day_reward_data_one = nil

    for i, v in pairs(day_reward_rows) do
        if v.rank_from~=nil then 
           day_reward_data_one = {}
           day_reward_data_one.rank_from = v.rank_from
           day_reward_data_one.rank_to = v.rank_to
           day_reward_data_one.diamond = v.diamond
           day_reward_data_one.coin = v.coin
           day_reward_data_one.arena_point = v.arena_point
           day_reward_data_one.items = v.items
           self.day_rewards[i] =  day_reward_data_one
        end
    end

    self.read_arena_data = true
 
end

--[[
通过竞技场排名获取相应奖励数据
@arena_rank 当前竞技场排名
--]]
function ArenaManager:getDayRewardData(arena_rank)
    for i,v in pairs(self.day_rewards) do
        if arena_rank>=v.rank_from and arena_rank<=v.rank_to then
            return v
        end
    end    
end

--竞技场相关事件
function ArenaManager:addListens()
    
   
   
    
end

--请求竞技场基础信息
function ArenaManager:sendArenaInfoReq()
    Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.arena_info_rsp, "onGetArenaInfoRsp()")
    local arena_info_req = arena_pb.arena_info_req()
    ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.arena_info_req,arena_info_req)       
end

--发送重置协议
function ArenaManager:sendArenaResetReq(reset_type)

    Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.arena_reset_challenge_req+1, "onGetResetRsp()")
    local reset_req = arena_pb.arena_reset_challenge_req()
    reset_req.type = reset_type
    ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.arena_reset_challenge_req,reset_req)       
end

function onGetArenaInfoRsp(pbPkgData)
    Global:UnregisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.arena_info_rsp, "onGetArenaInfoRsp()")
    local arena_info_rsp = arena_pb.arena_info_rsp()
    arena_info_rsp:ParseFromString(pbPkgData)
    
    if arena_info_rsp.ret ~= error_code_pb.msg_ret.success then
        local params = {}
        params["txt"] = Helper.getErrStr(arena_info_rsp.ret)
        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
        return 
    end 

    _instance:refreshArenaInfoBySrv(arena_info_rsp.left_num, arena_info_rsp.cooldown_time, 
                                    arena_info_rsp.rank, arena_info_rsp.targets, arena_info_rsp.reset_num, 
                                    arena_info_rsp.history_rank)

    ComSender:getInstance():dealExtInfo(arena_info_rsp.ext)
end

function ArenaManager:getRestNum()
    -- cclog("已經刷新次數yyyyy~~~%d",self.arena_reset_num)

    return self.arena_reset_num
end

function ArenaManager:refreshArenaInfoBySrv(srv_left_num, srv_cd_time, srv_rank, srv_targets, srv_reset_num, history_rank)

    self.remain_num = srv_left_num
    self.end_cold_date = srv_cd_time
    self.arena_rank = srv_rank
    self.arena_reset_num = srv_reset_num
    self.history_rank = history_rank
    cclog("競技場歷史最高記錄~~~%d",history_rank)
    local server_role_info = nil
    local client_role_info = nil
    for i=1,#srv_targets do
        client_role_info = OtherRoleInfo:create()
        server_role_info = srv_targets[i]

        client_role_info:setBaseInfo(server_role_info.id, server_role_info.name, 
                                server_role_info.team_lev,server_role_info.fc, 
                                server_role_info.face_id, server_role_info.rank, 
                                server_role_info.win_num, server_role_info.guild_name,
                                server_role_info.sex)

        client_role_info:setPetAttr(server_role_info.sprite_lev, server_role_info.sprite_stars)
         -- 竞技场cclog("覺醒222名稱=%s,性別=%s",server_role_info.name,server_role_info.sex)

        client_role_info:setHeros(server_role_info.heroes)
        self.enemy_list[i] = client_role_info
    end

    --收到信息后,主动刷新
    _instance:sendArenaResetReq(ArenaHelper.Reset.enemy_list)
 

    --通知界面更新
    Notifier.dispatchCmd(CmdName.Arena_init)  
end

--返回重置的结果
function onGetResetRsp(pbPkgData)
    Global:UnregisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.arena_reset_challenge_req+1, "onGetResetRsp()")
    local reset_rsp = arena_pb.arena_reset_challenge_rsp()
    reset_rsp:ParseFromString(pbPkgData)
    
    if reset_rsp.ret ~= error_code_pb.msg_ret.success then
        local params = {}
        params["txt"] = Helper.getErrStr(reset_rsp.ret)
        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
        return 
    end

    local arena_mgr = ArenaManager:getInstance()
    
    if reset_rsp.reset_num then
        arena_mgr.arena_reset_num = reset_rsp.reset_num
        cclog("這裡的次數返回~~%d",reset_rsp.reset_num)
        cclog("這裡的次數返回~~%d",reset_rsp.reset_num)
        cclog("這裡的次數返回~~%d",reset_rsp.reset_num)
        cclog("這裡的次數返回~~%d",reset_rsp.reset_num)
        cclog("這裡的次數返回~~%d",reset_rsp.reset_num)
    end

    if reset_rsp.type == ArenaHelper.Reset.total_num then
        arena_mgr.remain_num = reset_rsp.left_num
        CharacterManager:getInstance():updateRoleAssets(reset_rsp.assets)
        --通知界面更新
        Notifier.dispatchCmd(CmdName.Arena_Base_Update) 
        
        Alert:show("重置挑戰次數成功")
        if ArenaManager.send_reset_role_id~=nil then
            WindowCtrl:getInstance():open(CmdName.Team_View,
                {team_type = TeamType.Arena_atk,id = BattleIDType.ARENA,
                subId = 1,roleId = ArenaManager.send_reset_role_id})
        end
    elseif reset_rsp.type == ArenaHelper.Reset.wait_time then
        arena_mgr.end_cold_date = reset_rsp.cooldown_time
        CharacterManager:getInstance():updateRoleAssets(reset_rsp.assets)
        --通知界面更新
        Notifier.dispatchCmd(CmdName.Arena_Base_Update) 
        
        Alert:show("刷新挑戰CD成功")
        if ArenaManager.send_reset_role_id~=nil then
            WindowCtrl:getInstance():open(CmdName.Team_View,
                {team_type = TeamType.Arena_atk,id = BattleIDType.ARENA,
                subId = 1,roleId = ArenaManager.send_reset_role_id})
        end
    elseif reset_rsp.type == ArenaHelper.Reset.enemy_list then
        --刷新敌人列表
        local server_role_info = nil
        local client_role_info = nil
        for i=1,#reset_rsp.targets do
            client_role_info = OtherRoleInfo:create()
            server_role_info = reset_rsp.targets[i]

            client_role_info:setBaseInfo(server_role_info.id, server_role_info.name, 
                                    server_role_info.team_lev,server_role_info.fc, 
                                    server_role_info.face_id, server_role_info.rank, 
                                    server_role_info.win_num, server_role_info.guild_name,
                                    server_role_info.sex)
            client_role_info:setPetAttr(server_role_info.sprite_lev, server_role_info.sprite_stars)
            -- cclog("競技場角色名稱=%s,性別=%s",server_role_info.name,  server_role_info.sex)
            client_role_info:setHeros(server_role_info.heroes)
            _instance.enemy_list[i] = client_role_info
        end
        --通知界面更新
        Notifier.dispatchCmd(CmdName.Arena_Enemy_Update) 
    end

    ComSender:getInstance():dealExtInfo(reset_rsp.ext)
    
end

--向服务端请求竞技场排行榜信息
local last_rank_req_time = 0
function ArenaManager:sendArenaRankReq()
        local dif_time = os.clock() - last_rank_req_time
    -- if dif_time>6 then --
        Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.arena_rank_rsp, "onGetArenaRankRsp()")
        last_rank_req_time = os.clock()
        local arena_rank_req = arena_pb.arena_rank_req()
        ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.arena_rank_req,arena_rank_req)  
        cclog("請求競技場排行榜資訊")
    -- end
end

--返回竞技场排行榜列表
function onGetArenaRankRsp(pbPkgData)
    Global:UnregisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.arena_rank_rsp, "onGetArenaRankRsp()")
    local arena_rank_rsp = arena_pb.arena_rank_rsp()
    arena_rank_rsp:ParseFromString(pbPkgData)
    
    if arena_rank_rsp.ret ~= error_code_pb.msg_ret.success then
        cclog("請求競技場排行榜失敗%d",arena_rank_rsp.ret)
        return 
    end

    local server_role_info = nil
    local client_role_info = nil
    _instance.rank_list = {}
    for i=1,#arena_rank_rsp.ranks do
        client_role_info = OtherRoleInfo:create()
        server_role_info = arena_rank_rsp.ranks[i]

        client_role_info:setBaseInfo(server_role_info.id, server_role_info.name, 
                                server_role_info.team_lev,server_role_info.fc, 
                                server_role_info.face_id, server_role_info.rank, 
                                server_role_info.win_num, server_role_info.guild_name,
                                server_role_info.sex)
        client_role_info:setPetAttr(server_role_info.sprite_lev, server_role_info.sprite_stars)
        -- cclog("覺醒名稱=%s,性別=%s",server_role_info.name,server_role_info.sex)
        client_role_info:setHeros(server_role_info.heroes)
        _instance.rank_list[server_role_info.rank] = client_role_info
    end

    --通知界面更新
    Notifier.dispatchCmd(CmdName.Arena_rank_update)

    ComSender:getInstance():dealExtInfo(arena_rank_rsp.ext)
end

--向服务端请求竞技场战斗记录
local last_record_req_time = 0
function ArenaManager:sendArenaRecordReq()
    local dif_time = os.clock() - last_record_req_time
    -- if dif_time>6 then 
        Global:RegisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.arena_combat_rsp, "onGetArenaRecordRsp()")
        last_record_req_time = os.clock()
        local arena_combat_req = arena_pb.arena_combat_req()
        ComSender:getInstance():send(proto_cmd_2_pb.msg_cmd2.arena_combat_req,arena_combat_req)  
        cclog("請求競技場戰鬥記錄")
    -- end
end

--返回竞技场战斗记录
function onGetArenaRecordRsp(pbPkgData)
    Global:UnregisterNetworkCmd(proto_cmd_2_pb.msg_cmd2.arena_combat_rsp, "onGetArenaRecordRsp()")
    local arena_combat_rsp = arena_pb.arena_combat_rsp()
    arena_combat_rsp:ParseFromString(pbPkgData)
    
    if arena_combat_rsp.ret ~= error_code_pb.msg_ret.success then
        cclog("請求競技場戰鬥記錄失敗%d",arena_combat_rsp.ret)
        return
    end

    local server_combat_info = nil
    local client_combat_info = nil
    _instance.record_list = {}
    for i=1,#arena_combat_rsp.combats do
        client_combat_info = ArenaRecordData:create()
        server_combat_info = arena_combat_rsp.combats[i]

        client_combat_info:setData(server_combat_info.combat_result, server_combat_info.rank_changed,
                                    server_combat_info.time, server_combat_info.target, 
                                    server_combat_info.record_key)

        _instance.record_list[i] = client_combat_info
    end

    --通知界面更新
    Notifier.dispatchCmd(CmdName.Arena_record_update)

    ComSender:getInstance():dealExtInfo(arena_combat_rsp.ext)
end

--通过roleid获取相应敌人
function ArenaManager:getEnemyInfo(role_id)
    local temp_role_id = nil

    for _,role_info in pairs(self.enemy_list) do
        temp_role_id = role_info.role_id
        if temp_role_id.uin == role_id.uin and 
            temp_role_id.channel_id == role_id.channel_id and 
            temp_role_id.zone_id == role_id.zone_id then
            return role_info
        end
    end
end

function ArenaManager:cleanCdTimeByClient()
    self.end_cold_date = 0
    Notifier.dispatchCmd(CmdName.Arena_Base_Update) 
end

function ArenaManager:getWidgetRankItem()
    self.rank_item_seed =  GUIReader:shareReader():widgetFromJsonFile("ui/arena/arena_rank_item/arena_rank_item.ExportJson")
    self.rank_item_seed:retain()
    return self.rank_item_seed
end

function ArenaManager:refreshNewDayData(srv_left_num, srv_cd_time, srv_reset_num)
    self.remain_num = srv_left_num
    self.end_cold_date = srv_cd_time
    self.arena_reset_num = srv_reset_num
end