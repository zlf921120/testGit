--
-- Author: lvgansheng
-- Date: 2014-08-08 11:29:25
-- 竞技场排行榜元件

require "BattleManager"

ArenaRecordItem = class("ArenaRecordItem", DisplayUtil.newLayout)

function ArenaRecordItem:init(widget_seed)
	-- self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/arena/arena_record_item/arena_record_item.ExportJson")
	self.widget = widget_seed:clone()
    self:addChild(self.widget)

    self.result_txt_img = tolua.cast(self.widget:getChildByName("result_txt_img"), "ImageView") 
	self.result_arrows_img = tolua.cast(self.widget:getChildByName("result_arrows_img"), "ImageView") 
	self.rank_change_label = tolua.cast(self.widget:getChildByName("rank_change_label"), "Label") 
	self.lev_label = tolua.cast(self.widget:getChildByName("lev_label"), "Label") 
	self.guild_label = tolua.cast(self.widget:getChildByName("guild_label"), "Label") 
	self.name_label = tolua.cast(self.widget:getChildByName("name_label"), "Label") 
	
	self.time_label = tolua.cast(self.widget:getChildByName("time_label"), "Label") 
	-- self.time_label:ignoreContentAdaptWithSize(false)
	-- self.time_label:setSize(CCSize(110,110))

    self.head_icon = HeadIcon:create()
    self.head_icon:setScale(0.75)
    self.head_icon:setPosition(ccp(168,56))
    self.widget:addChild(self.head_icon,10)

    --录像按钮
    local record_btn = self.widget:getChildByName("record_btn")
    record_btn:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
    		-- cclog("錄影按鈕")	
            BattleManager:getInstance():reqHandleRecord(
                2, 
                self.one_record_data.record_key
            )
        end
    end)

    local bg_img = tolua.cast(self.widget:getChildByName("record_item_bg"), "ImageView")
    bg_img:setTouchEnabled(true)
    bg_img:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
    		WindowCtrl:getInstance():open(CmdName.OtherRoleInfoView, 
    				{role_info=self.one_record_data.role_info,view_type=ArenaHelper.enemyInfoView.Combat_Record})
        end
    end)

    self:setSize(self.widget:getSize())
end

function ArenaRecordItem:create(widget_seed)
	local rank_item = ArenaRecordItem.new()
	rank_item:init(widget_seed)
	return rank_item
end

function ArenaRecordItem:setData(one_record_data)

	self.one_record_data = one_record_data

	self.head_icon:setFaceId(self.one_record_data.role_info.face_id, self.one_record_data.role_info.sex)

	if one_record_data.combat_result == 0 then
 		self.result_txt_img:loadTexture("i18n_arena_lost.png", UI_TEX_TYPE_PLIST)
	elseif one_record_data.combat_result == 1 then
 		self.result_txt_img:loadTexture("i18n_arena_win.png", UI_TEX_TYPE_PLIST)
	end

	if one_record_data.rank_changed >0 then
		self.result_arrows_img:loadTexture("btn_up_12.png", UI_TEX_TYPE_PLIST)
		self.rank_change_label:setText(one_record_data.rank_changed)
	elseif one_record_data.rank_changed == 0 then
		self.result_arrows_img:loadTexture("sub_sign_2.png", UI_TEX_TYPE_PLIST)
		self.rank_change_label:setText("")
	else
		self.result_arrows_img:loadTexture("down_sign.png", UI_TEX_TYPE_PLIST)
		self.rank_change_label:setText(-one_record_data.rank_changed)
	end

	local time_tab = os.date("*t",one_record_data.time)
	self.time_label:setText(string.format("%d-%d-%d\n%d:%d:%d",time_tab.year,time_tab.month,time_tab.day,
							time_tab.hour,time_tab.min,time_tab.sec))

	self.lev_label:setText(string.format("Lv.%d",one_record_data.role_info.team_lev))
	self.guild_label:setText(one_record_data.role_info.guild_name)
	self.name_label:setText(one_record_data.role_info.role_name)
end