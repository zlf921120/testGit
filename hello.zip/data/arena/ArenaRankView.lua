--
-- Author: lvgansheng 
-- Date: 2014-08-08 11:29:15
-- 竞技场排行榜界面

ArenaRankView = class("ArenaRankView",WindowBase)
local max_ranking = 50 -- 最大名次，即要排的最多个数

ArenaRankView.rank_item_dic = nil 

function ArenaRankView:init()

	require("ArenaRankItem")

	self.rank_item_dic = CCDictionary:create()
	self.rank_item_dic:retain()

	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/arena/arena_rank/arena_rank.ExportJson")
    self.uiLayer:addWidget(self.widget)

    self.list_view = tolua.cast( self.uiLayer:getWidgetByName("rank_list_view"), "ListView")

    local close_btn = self.uiLayer:getWidgetByName("close_btn")
    close_btn:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
    		WindowCtrl:getInstance():close(self.name)
    	end
    end)

	local cur_idx = 0
    local function setp_show()
    	local rank_item = nil
		local rank_list =  ArenaManager:getInstance().rank_list
		local one_role_info = nil
		local temp_idx = cur_idx+1
		local step = 0
		if temp_idx>max_ranking then
			cur_idx = 0
			TimerManager.removeTimer(setp_show)
		end

		for i = temp_idx,max_ranking do
			rank_item = self.rank_item_dic:objectForKey(i)
			one_role_info = rank_list[i]
			if one_role_info then
				if rank_item == nil then
					rank_item = ArenaRankItem:create(ArenaManager:getInstance():getWidgetRankItem():clone())
					self.list_view:pushBackCustomItem(rank_item)	
					self.rank_item_dic:setObject(rank_item, i)
				end		
				rank_item:setData(one_role_info)
				step = step +1
			else
				cur_idx = 0
				TimerManager.removeTimer(setp_show)
				break
			end

			cur_idx=cur_idx+1
			
			if step == 5 then
				break
			end
		end
    end


    self._onRankInfoUpdate = function()
    	-- self:showRankList()
    	TimerManager.addTimer(250, setp_show,true)
    end

    self._cleanStepTimer = function()
    	TimerManager.removeTimer(setp_show)
   	end
end

function ArenaRankView:create()
	local rank_view = ArenaRankView.new()
	return rank_view
end

function ArenaRankView:open()
	Notifier.regist(CmdName.Arena_rank_update,self._onRankInfoUpdate)
	ArenaManager:getInstance():sendArenaRankReq()
end

function ArenaRankView:close()
	Notifier.remove(CmdName.Arena_rank_update,self._onRankInfoUpdate)
	self._cleanStepTimer()
end

function ArenaRankView:showRankList()
	local rank_item = nil
	local rank_list =  ArenaManager:getInstance().rank_list
	local one_role_info = nil
	for i =1,max_ranking do
		rank_item = self.rank_item_dic:objectForKey(i)
		one_role_info = rank_list[i]
		if one_role_info then
			if rank_item == nil then
				rank_item = ArenaRankItem:create(ArenaManager:getInstance():getWidgetRankItem():clone())
				self.list_view:pushBackCustomItem(rank_item)	
				self.rank_item_dic:setObject(rank_item, i)
			end		
			rank_item:setData(one_role_info)
		else
			break
		end
	end
end
