--
-- Author: lvgansheng
-- Date: 2014-08-07 16:12:05
-- 竞技场敌人信息

ArenaEnemyInfo = class("ArenaEnemyInfo")

ArenaEnemyInfo.name = nil --角色名称
ArenaEnemyInfo.team_lev = 0 --战队等级
ArenaEnemyInfo.ranking = 0 --竞技场排名
ArenaEnemyInfo.fight_capacity = 0 --角色战力
ArenaEnemyInfo.hero_infos = nil --角色所拥有的英雄信息
ArenaEnemyInfo.guild_name = nil --角色所在的帮会名称