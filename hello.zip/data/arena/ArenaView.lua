--
-- Author: lvgansheng
-- Date: 2014-08-06 16:49:59
-- 竞技场主界面

ArenaView = class("ArenaView",WindowBase)
ArenaView.defend_hero_icons = nil
ArenaView.enemy_items = nil --可挑战敌人
ArenaView.cold_time_num = 10 -- 剩余秒数

ArenaView.cold_time_label = nil --冷却倒计时
ArenaView.remain_num_label = nil --剩余次数

local is_arena_bg_init = false

function ArenaView:init()
    require("ArenaEnemyItem")
    require("ArenaManager")
    require("ArenaHelper")
    require("TeamEnum")
    require("HeroIcon")
    require("TeamManager")
    require("ShopCfg")
    require("ArenaDefIcon")

	self.enemy_items ={}

    ComResMgr:getInstance():loadResByName("ui/arena/arena_bg.plist","ui/arena/arena_bg.pvr.ccz")

	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/arena/arena_view/arena_view.ExportJson")
    self.uiLayer:addWidget(self.widget)

    self.cold_time_label = tolua.cast(self.uiLayer:getWidgetByName("cold_time_label"), "Label")
    self.remain_num_label = tolua.cast(self.uiLayer:getWidgetByName("remain_num_label"), "Label")

    self.self_rank = LabelAtlas:create()
    self.self_rank:setProperty(0000,"ui/digit/bui_stone_blue_num.png",20,26,"0")
    self.self_rank:setPosition(ccp(400,546))
    self.uiLayer:addChild(self.self_rank)

    self.self_max_rank = LabelAtlas:create()
    self.self_max_rank:setProperty(0000,"ui/digit/bui_stone_blue_num.png",20,26,"0")
    self.self_max_rank:setPosition(ccp(677,546))
    self.uiLayer:addChild(self.self_max_rank)

    local diamon_num_label = tolua.cast(self.uiLayer:getWidgetByName("diamon_num_label"), "Label")
    diamon_num_label:setText(10)    

    --可挑战敌人
    local enemy_x = 100
    local enemy_y = 90
    local enemy_step_x = 250
    local enemy_one = ArenaEnemyItem:create()
    enemy_one:setPosition(ccp(enemy_x,enemy_y))
    self.uiLayer:addWidget(enemy_one)

    enemy_x = enemy_x + enemy_step_x
    local enemy_two = ArenaEnemyItem:create()
    enemy_two:setPosition(ccp(enemy_x,enemy_y))
    self.uiLayer:addWidget(enemy_two)

    enemy_x = enemy_x + enemy_step_x
    local enemy_three = ArenaEnemyItem:create()
    enemy_three:setPosition(ccp(enemy_x,enemy_y))
    self.uiLayer:addWidget(enemy_three)

    self.enemy_items[1] = enemy_one
    self.enemy_items[2] = enemy_two
    self.enemy_items[3] = enemy_three

    local function getVipBuyNumTips(reset_num)
        if reset_num==0 then
            return "VIP1每天可重置競技場挑戰機會1次"
        elseif reset_num==1 then
            return "VIP4每天可重置競技場挑戰機會2次"
             elseif reset_num==2 then
            return "VIP7每天可重置競技場挑戰機會3次"
             elseif reset_num==3 then
            return "VIP9每天可重置競技場挑戰機會4次"
             elseif reset_num==4 then
            return "VIP11每天可重置競技場挑戰機會5次"
         elseif reset_num==5 then
            return "VIP12每天可重置競技場挑戰機會6次"
         elseif reset_num==6 then
            return "VIP13每天可重置競技場挑戰機會7次"
         elseif reset_num==7 then
            return "VIP14每天可重置競技場挑戰機會8次"
          elseif reset_num==8 then
            return "VIP15每天可重置競技場挑戰機會9次"               
        end
    end

     --相关按钮事件
    local function onClickBtn(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            local widgetName = sender:getName()
            if widgetName == "defend_btn" then
                 WindowCtrl:getInstance():open(CmdName.Team_View,{team_type = TeamType.Arena_def})
            elseif widgetName == "rule_desc_btn" then
                 WindowCtrl:getInstance():open(CmdName.Arena_Rule_View)     
            elseif widgetName == "rank_btn" then
                print("排行榜")
                WindowCtrl:getInstance():open(CmdName.Arena_Rank_View)
            elseif widgetName == "battle_record_btn" then
                WindowCtrl:getInstance():open(CmdName.Arena_Record_View)
                self:hideNewsTip(NewTipsEnum.arena)
            elseif widgetName == "exch_award_btn" then
                WindowCtrl:getInstance():open(CmdName.Shop_View ,{ area = BuyArea.Arena })
            elseif widgetName == "reset_btn" then
                if ArenaManager:getInstance().remain_num==0 then
                    local params = {}
                   local vip_buy_num =  VipDataProxy:getInstance():getPrivilegeValue(VipPrivilegeType.BuyArenaReset)
                   if ArenaManager:getInstance().arena_reset_num<vip_buy_num then
                       params.txt = "今日免費挑戰次數已用完，花費10鑽石可購買1次挑戰機會哦。"
                        params.okFunc = function()
                            ArenaManager.send_reset_role_id = nil
                            ArenaManager:getInstance():sendArenaResetReq(ArenaHelper.Reset.total_num)
                        end
                        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
                    else
                        Alert:show(getVipBuyNumTips(ArenaManager:getInstance().arena_reset_num))
                    end
                elseif ServerTimerManager:getInstance():getTimeDiff(ArenaManager:getInstance().end_cold_date)>0 then
                    
                        local params = {}
                        if CharacterManager:getInstance():getBaseData():getVipLv()<6 then
                            params["txt"] = "冷卻中，花費10鑽石可立即發起戰鬥"
                        else
                            params["isSingleBtn"] = 1
                            params["txt"] = "您當前擁有立即消除挑戰冷卻時間的VIP特權，可立即消除挑戰冷卻時間。"
                        end

                        params.okFunc = function()
                            --发送立即发起战斗的协议
                            ArenaManager.send_reset_role_id = nil
                            ArenaManager:getInstance():sendArenaResetReq(ArenaHelper.Reset.wait_time)
                        end
                        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
                    
                else
                     --刷新敌人列表
                     ArenaManager:getInstance():sendArenaResetReq(ArenaHelper.Reset.enemy_list)
                end
            end 
        end
    end

    local defend_btn = self.uiLayer:getWidgetByName("defend_btn") --防守阵营调整按钮
    local rule_desc_btn = self.uiLayer:getWidgetByName("rule_desc_btn")
    local rank_btn = self.uiLayer:getWidgetByName("rank_btn")
    local battle_record_btn = self.uiLayer:getWidgetByName("battle_record_btn")
    local exch_award_btn = self.uiLayer:getWidgetByName("exch_award_btn")
    self.reset_btn = tolua.cast(self.uiLayer:getWidgetByName("reset_btn"), "Button")  --重置/刷新按钮

    rule_desc_btn:addTouchEventListener(onClickBtn)
    rank_btn:addTouchEventListener(onClickBtn)
    battle_record_btn:addTouchEventListener(onClickBtn)
    exch_award_btn:addTouchEventListener(onClickBtn)
    defend_btn:addTouchEventListener(onClickBtn)
    self.reset_btn:addTouchEventListener(onClickBtn)

    --每1s执行的方法
    self.showColdTime = function()
        self.cold_time_num =  self.cold_time_num  -1 
        self.cold_time_label:setText(Helper.sec2TimeStr(self.cold_time_num))
        if self.cold_time_num <= 0 then
            TimerManager.removeTimer(self.showColdTime)
            self:changeContent()
        end
    end

    self._onInitContent = function()
       self:initContent()
    end

    self._onChangeContent = function()
       self:changeContent()
    end

    self._onUpdateEnemyHero = function()
       self:updateEnemyHero()
    end

    if self.win_base_bg then
        self.win_base_bg:loadTexture("arena_bg.png",UI_TEX_TYPE_PLIST)
        -- self.win_base_bg:setScaleX(1/globa_scaly*globa_scalx*1.875)
        -- self.win_base_bg:setScaleX(1/1.875/globa_scalx*globa_scaly)
        -- self.win_base_bg:setScaleY(1/2.56)
        -- self.win_base_bg:setScaleY(1)
    end

end

function ArenaView:create()
    local arena = ArenaView.new()
    return arena
end

function ArenaView:open()  
    --监听相应事件
    Notifier.regist(CmdName.Arena_Base_Update, self._onChangeContent) -- 竞技场相关基础信息改变时
    Notifier.regist(CmdName.Arena_init, self._onInitContent ) -- 初始化
    Notifier.regist(CmdName.Arena_Enemy_Update, self._onUpdateEnemyHero) -- 竞技场可挑战列表变化
    ArenaManager:getInstance():sendArenaInfoReq() --请求竞技场相关信息

    if self.win_base_bg and is_arena_bg_init==false then
    
        self.win_base_bg:loadTexture("arena_bg.png",UI_TEX_TYPE_PLIST)
        self.win_base_bg:setScaleX(1/self:getScaleX())
        -- self.win_base_bg:setScaleY(2.56)
        self.win_base_bg:setScaleY(1/self:getScaleY())
        is_arena_bg_init = true
    end
   
    self:checkNewsTips()
end

function ArenaView:checkNewsTips()
    local status = CharacterManager:getInstance():getBaseData():getNewsTipList().arena
    if status == 0 then -- 0 显示 1 不显示
        self:showNewsTip(NewTipsEnum.arena)
    end
end

function ArenaView:close()
    for i=1,#self.enemy_items do
        enemy_item = self.enemy_items[i]
        enemy_item:close()
    end

    TimerManager.removeTimer(self.showColdTime)
    Notifier.remove(CmdName.Arena_Base_Update, self._onChangeContent)
    Notifier.remove(CmdName.Arena_Enemy_Update, self._onUpdateEnemyHero)
    Notifier.remove(CmdName.Arena_init, self._onInitContent ) -- 初始化
    AnimateManager:getInstance():_startGC()
end

function ArenaView:initContent()
    self:changeContent()
    self:updateEnemyHero()
end

function ArenaView:changeContent()
    self.cold_time_num = ServerTimerManager:getInstance():getTimeDiff(ArenaManager:getInstance().end_cold_date)
    local again_battle_txt_label = tolua.cast(self.uiLayer:getWidgetByName("again_battle_txt_label"), "Label")
    local diamon_num_label = tolua.cast(self.uiLayer:getWidgetByName("diamon_num_label"), "Label")
    local diamon_img = self.uiLayer:getWidgetByName("diamon_img")
    local diamon_bg = self.uiLayer:getWidgetByName("diamon_bg")

    if self.cold_time_num>0 then
        self.cold_time_label:setVisible(true)
        again_battle_txt_label:setVisible(true)
        TimerManager.addTimer(1000,self.showColdTime,true)
        diamon_num_label:setVisible(true)
        diamon_img:setVisible(true)
        diamon_bg:setVisible(true)
        self.reset_btn:setTitleText("立即刷新")
    else
        self.cold_time_label:setVisible(false)
        again_battle_txt_label:setVisible(false)
        diamon_num_label:setVisible(false)
        diamon_img:setVisible(false)
        diamon_bg:setVisible(false)
        self.reset_btn:setTitleText("換一批")
    end

    if ArenaManager:getInstance().remain_num == 0 then
        diamon_num_label:setVisible(true)
        diamon_img:setVisible(true)
        diamon_bg:setVisible(true)
        self.reset_btn:setTitleText("購買次數")
    end

    self:changeBaseInfo()
end

function ArenaView:changeBaseInfo()
    self.remain_num_label:setText(string.format("%d/%d",
        ArenaManager:getInstance().remain_num,
        ArenaManager:getInstance().total_num))

    self.self_rank:setStringValue(ArenaManager:getInstance().arena_rank)
    self.self_max_rank:setStringValue(ArenaManager:getInstance().history_rank)

    self:updateEnemyHero()
end

-- 展示 新消息 提示
function ArenaView:showNewsTip(key)
    local target = nil
    local pos = nil
    if key == NewTipsEnum.arena then
        target = self.uiLayer:getWidgetByName("battle_record_btn")
        pos = ccp(28,31)
    end
    if target and target:getChildByTag(2866) == nil then
        local tips_img = ImageView:create()
        tips_img:loadTexture("tips_point.png", UI_TEX_TYPE_PLIST)
        tips_img:setTag(2866)
        tips_img:setPosition(pos)
        target:addChild(tips_img)
        self:tipsPointPlayAct(tips_img)
    elseif target and target:getChildByTag(2866) ~= nil then
        local tips_img = target:getChildByTag(2866)
        self:tipsPointPlayAct(tips_img)
    end
end

-- 隐藏 新消息 提示
function ArenaView:hideNewsTip(key)
    local target = nil
    if key == NewTipsEnum.arena then
        target = self.uiLayer:getWidgetByName("battle_record_btn")
    end
    if target and target:getChildByTag(2866) ~= nil then
        CharacterManager:getInstance():getBaseData():setNewsTipStatus(key,1) --0 显示  1 不显示
        target:removeChildByTag(2866,true)
         Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.arena) --消除绿点
    end
end

function ArenaView:tipsPointPlayAct(act_bn)
    act_bn:stopAllActions()
    local arr = CCArray:create()
    arr:addObject(CCScaleTo:create(0.6,1.1))
    arr:addObject(CCScaleTo:create(0.6,0.9))
    local forever_seqAction = CCRepeatForever:create(CCSequence:create(arr))
    act_bn:runAction(forever_seqAction)   
end

--设置可挑战的英雄
function ArenaView:updateEnemyHero()
    local enemy_item = nil
    local role_info = nil
    local role_list = ArenaManager:getInstance().enemy_list
    for i=1,#self.enemy_items do
        enemy_item = self.enemy_items[i]
        role_info = role_list[i]
        if role_info then
            enemy_item:setRoleInfo(role_info)
        end
    end
end
