--
-- Author: lvgansheng
-- Date: 2014-08-08 10:41:29
-- 竞技场规则说明

ArenaRuleView = class("ArenaRuleView", WindowBase)
ArenaRuleView.ext_desc_label = nil

local arena_mgr = nil
local rule_txt = "　　1.戰隊等級達到15級開啟競技場功能，英雄等級達到15級即可參加競技場；\n\n"..
                 "　　2.玩家每日可免費參與競技5次；\n\n"..
                 "　　3.競技場中進攻方可手動操作，防守方自動戰鬥；\n\n"..
                 "　　4.若戰鬥勝利，且防守方的排名高於進攻方，則雙方排名對調；\n\n"..
                 "　　5.若戰鬥超時則進攻方失敗；\n\n"..
                 "　　6.每日淩晨5點重置競技次數；\n\n"..
                 "　　7.每日晚上9點發放競技場排名獎勵，玩家可通過競技場商店使用競技功勳兌換珍\n\n稀道具哦。"

function ArenaRuleView:init()

    require("MathUtil")

    arena_mgr =  ArenaManager:getInstance()
    --第一次打开，加载奖励数据
    arena_mgr:readArenaData()

    --加载物品图标,一般来说已经加载过了
    ItemManager:getInstance():loadItemIconPlist()

	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/arena/arena_rule/arena_rule.ExportJson")
    self.uiLayer:addWidget(self.widget)

    local close_btn = self.uiLayer:getWidgetByName("close_btn")
    close_btn:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
    		WindowCtrl:getInstance():close(self.name)
    	end
    end)

    self.rank_label =  tolua.cast(self.uiLayer:getWidgetByName("rank_label"), "Label")
    -- self.coin_label = tolua.cast(self.uiLayer:getWidgetByName("coin_label"), "Label")
    self.diamond_label = tolua.cast(self.uiLayer:getWidgetByName("diamond_label"), "Label")
    self.arena_point_label = tolua.cast(self.uiLayer:getWidgetByName("arena_point_label"), "Label")

    local rule_txt_label = tolua.cast(self.uiLayer:getWidgetByName("rule_txt_label"), "Label")
    rule_txt_label:setText(rule_txt)

end

function ArenaRuleView:create()
	local rule_view = ArenaRuleView.new()
	return rule_view
end

function ArenaRuleView:open()
    self:setRewards()
end

function ArenaRuleView:setRewards()

    -- local day_reward_data = arena_mgr:getDayRewardData(arena_mgr.arena_rank)
    if arena_mgr.arena_rank>10000 then
        self.rank_label:setText("您的排名在10000名之外，暫無獎勵，繼續加油哦。")
        -- self.coin_label:setText(0)
        self.diamond_label:setText("x0")
        self.arena_point_label:setText("x0")
        return
    else
        local ranl_desc = string.format("保持當前的排名（第%d名），可領取獎勵為:",arena_mgr.arena_rank)
        self.rank_label:setText(ranl_desc)
        -- self.coin_label:setText(day_reward_data.coin)
        local base_num = math.pow(arena_mgr.arena_rank,0.25)
        local reward_diamond = MathUtil.round(300/base_num)
        self.diamond_label:setText(string.format("x%d",reward_diamond))
        
        local reward_point = MathUtil.round(1500/base_num) 
        self.arena_point_label:setText(string.format("x%d",reward_point))
    end
end