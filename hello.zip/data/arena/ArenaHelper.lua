--
-- Author: Your Name
-- Date: 2014-08-13 17:56:48
-- 竞技场帮助类

ArenaHelper = {}

ArenaHelper.Reset = {}
ArenaHelper.Reset.total_num = 1 --重置总次数
ArenaHelper.Reset.wait_time = 2 --重置等待时间
ArenaHelper.Reset.enemy_list = 3 --重置敌人列表

ArenaHelper.enemyInfoView = {}
ArenaHelper.enemyInfoView.Normal = 1 
ArenaHelper.enemyInfoView.Combat_Record = 2 

function ArenaHelper.getRankImg(rank)
	if rank == 1 then
		return "first_num.png"
	elseif rank==2 then
		return "second_num.png"
	elseif rank==3 then
		return "third_num.png"
	end
end