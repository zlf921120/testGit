--
-- Author: lvgansheng
-- Date: 2014-08-08 14:48:52
-- 竞技场挑战者详细信息

ArenaEnemyInfoView = class("ArenaEnemyInfoView", WindowBase)
ArenaEnemyInfoView.hero_icons = nil
ArenaEnemyInfoView.role_info = nil

function ArenaEnemyInfoView:init()
    self.hero_icons = {} 

	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/arena/arena_enemy_info/arena_enemy_info.ExportJson")
    self.uiLayer:addWidget(self.widget)

    self.head_icon = HeadIcon:create()
    self.head_icon:setScale(0.8)
    self.head_icon:setPosition(ccp(250,450))
    self.widget:addChild(self.head_icon,10)

    local panel = tolua.cast(self.uiLayer:getWidgetByName("Panel_326"), "Layout")
    panel:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
    		WindowCtrl:getInstance():close(self.name)
        end
    end)

    local icon_x = 249
    local icon_y = 236
    local setp_x = 90
    local hero_icon_one = HeroIcon:create()
    hero_icon_one:setScale(0.8)
    hero_icon_one:setPosition(ccp(icon_x,icon_y))
    self.uiLayer:addWidget(hero_icon_one)

    icon_x = icon_x + setp_x
    local hero_icon_two = HeroIcon:create()
    hero_icon_two:setScale(0.8)
    hero_icon_two:setPosition(ccp(icon_x,icon_y))
    self.uiLayer:addWidget(hero_icon_two)

    icon_x = icon_x + setp_x
    local hero_icon_three = HeroIcon:create()
    hero_icon_three:setScale(0.8)
    hero_icon_three:setPosition(ccp(icon_x,icon_y))
    self.uiLayer:addWidget(hero_icon_three)

    icon_x = icon_x + setp_x
    local hero_icon_four = HeroIcon:create()
    hero_icon_four:setScale(0.8)
    hero_icon_four:setPosition(ccp(icon_x,icon_y))
    self.uiLayer:addWidget(hero_icon_four)

    icon_x = icon_x + setp_x
    local hero_icon_five = HeroIcon:create()
    hero_icon_five:setScale(0.8)
    hero_icon_five:setPosition(ccp(icon_x,icon_y))
    self.uiLayer:addWidget(hero_icon_five)

    icon_x = icon_x + setp_x
    local hero_icon_six = HeroIcon:create()
    hero_icon_six:setScale(0.8)
    hero_icon_six:setPosition(ccp(icon_x,icon_y))
    self.uiLayer:addWidget(hero_icon_six)

    self.hero_icons[1] = hero_icon_one
    self.hero_icons[2] = hero_icon_two
    self.hero_icons[3] = hero_icon_three
    self.hero_icons[4] = hero_icon_four
    self.hero_icons[5] = hero_icon_five
    self.hero_icons[6] = hero_icon_six
end

function ArenaEnemyInfoView:create()
    local enemy_info_view = ArenaEnemyInfoView.new()
    return enemy_info_view
end

function ArenaEnemyInfoView:open()
    self.role_info = self.params
    self.params = nil

    self:changeContent()
end

function ArenaEnemyInfoView:close()
    self.params = nil
    self.role_info = nil
end

--改变显示内容
function ArenaEnemyInfoView:changeContent()
    self.head_icon:setFaceId(self.role_info.face_id)
    
    local name_label = tolua.cast(self.uiLayer:getWidgetByName("name_label"), "Label") 
    name_label:setText(self.role_info.role_name)

    local lev_label = tolua.cast(self.uiLayer:getWidgetByName("lev_label"), "Label") 
    lev_label:setText(string.format("Lv.%d",self.role_info.team_lev))

    local rank_label = tolua.cast(self.uiLayer:getWidgetByName("rank_label"), "Label") 
    rank_label:setText(self.role_info.rank)

    local win_num_label = tolua.cast(self.uiLayer:getWidgetByName("win_num_label"), "Label") 
    win_num_label:setText(self.role_info.win_num)

    local fc_label = tolua.cast(self.uiLayer:getWidgetByName("fc_label"), "Label") 
    fc_label:setText(self.role_info.fight_capacity)

    local hero_icon = nil
    local hero_info = nil
    local heros = self.role_info.battle_data
    for i=1,#self.hero_icons do
        hero_icon = self.hero_icons[i]
        hero_info = heros[i]

        if hero_info ~= nil then
            hero_icon:setVisible(true)
            hero_icon:setOtherHeroInfo(hero_info)
        else
            hero_icon:setOtherHeroInfo(nil)
        end
    end
end