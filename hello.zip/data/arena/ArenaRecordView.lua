--
-- Author: lvgansheng 
-- Date: 2014-08-08 11:29:15
-- 竞技场排行榜界面

ArenaRecordView = class("ArenaRecordView",WindowBase)
local max_ranking = 15 -- 最大名次，即要排的最多个数

ArenaRecordView.record_item_dic = nil 

function ArenaRecordView:init()
	require("ArenaRecordItem")

	self.record_item_dic = CCDictionary:create()
	self.record_item_dic:retain()

	self.uiLayer = TouchGroup:create() 
    self:addChild(self.uiLayer)
		
	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/arena/arena_record/arena_record.ExportJson")
    self.uiLayer:addWidget(self.widget)

    self.widget_seed = GUIReader:shareReader():widgetFromJsonFile("ui/arena/arena_record_item/arena_record_item.ExportJson")
    self.widget_seed:retain()

    self.list_view = tolua.cast( self.uiLayer:getWidgetByName("record_list_view"), "ListView")

    local close_btn = self.uiLayer:getWidgetByName("close_btn")
    close_btn:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
    		WindowCtrl:getInstance():close(self.name)
    	end
    end)

    -- self:showRankList() --测试用
    self._onRecordInfoUpdate = function()
    	self:showRankList()
    end

end

function ArenaRecordView:create()
	local rank_view = ArenaRecordView.new()
	return rank_view
end

function ArenaRecordView:open()
	Notifier.regist(CmdName.Arena_record_update,self._onRecordInfoUpdate)
	ArenaManager:getInstance():sendArenaRecordReq()
end

function ArenaRecordView:close()
	Notifier.remove(CmdName.Arena_record_update,self._onRecordInfoUpdate)
end

function ArenaRecordView:showRankList()
	local rank_item = nil
	local record_list =  ArenaManager:getInstance().record_list
	local one_record_data = nil
	for i =1,max_ranking do
		rank_item = self.record_item_dic:objectForKey(i)
		one_record_data = record_list[i]
		if one_record_data then
			if rank_item == nil then
				rank_item = ArenaRecordItem:create(self.widget_seed)
				self.list_view:pushBackCustomItem(rank_item)
				self.record_item_dic:setObject(rank_item, i)		
			end
			rank_item:setData(one_record_data)
		end
	end
end