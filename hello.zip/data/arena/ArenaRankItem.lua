--
-- Author: lvgansheng
-- Date: 2014-08-08 11:29:25
-- 竞技场排行榜元件

ArenaRankItem = class("ArenaRankItem", DisplayUtil.newLayout)

function ArenaRankItem:init(widget_seed)
    -- self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/arena/arena_rank_item/arena_rank_item.ExportJson")
	self.widget = widget_seed:clone()
    self:addChild(self.widget)

    self:setSize(self.widget:getSize())

    self.head_icon = HeadIcon:create()
    self.head_icon:setScale(0.65)
    self.head_icon:setPosition(ccp(168,70))
    self.widget:addChild(self.head_icon,10)

    -- local num_txure = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName("digit_4.png"):getTexture()
    -- local rank_label_atlas_xx = CCLabelAtlas:initWithTexture(num_txure,24,32)

    self.rank_img = tolua.cast(self.widget:getChildByName("ranking_img"), "ImageView") 
    self.rank_label_atlas = LabelAtlas:create()
    self.rank_label_atlas:setProperty(0000,"ui/digit/digit_4.png",24,32,"0")
    self.rank_label_atlas:setPosition(ccp(56,55))
    self.rank_label_atlas:setScale(0.8)
    self.widget:addChild(self.rank_label_atlas)

    local bg_img = tolua.cast(self.widget:getChildByName("bg_img"), "ImageView")
    bg_img:setTouchEnabled(true)
    bg_img:addTouchEventListener(function(sender,event_type)
    	if event_type == ComConstTab.TouchEventType.ended then
    		WindowCtrl:getInstance():open(CmdName.OtherRoleInfoView, {role_info=self.one_role_info})
        end
    end)
end

function ArenaRankItem:create(widget_seed)
	local rank_item = ArenaRankItem.new()
	rank_item:init(widget_seed)
	return rank_item
end

function ArenaRankItem:setData(one_role_info)

    self.one_role_info = one_role_info

    self.head_icon:setFaceId(self.one_role_info.face_id, self.one_role_info.sex)

    local role_name_label =  tolua.cast(self.widget:getChildByName("name_label"), "Label")
    role_name_label:setText(one_role_info.role_name)

    local team_lv_label =  tolua.cast(self.widget:getChildByName("lev_label"), "Label")
    team_lv_label:setText(string.format("Lv.%d",one_role_info.team_lev))

    local guild_name_label =  tolua.cast(self.widget:getChildByName("guild_label"), "Label")
    guild_name_label:setText(one_role_info.guild_name)

    if one_role_info.rank>3 then
         self.rank_img:setVisible(false)
         self.rank_label_atlas:setVisible(true)
          self.rank_label_atlas:setStringValue(one_role_info.rank)
    else
         self.rank_img:setVisible(true)
         self.rank_label_atlas:setVisible(false)
         self.rank_img:loadTexture(ArenaHelper.getRankImg(one_role_info.rank), UI_TEX_TYPE_PLIST)
    end
end