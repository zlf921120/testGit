--
-- Author: Your Name
-- Date: 2014-09-22 19:55:41
--

ArenaDefIcon = class("ArenaDefIcon", DisplayUtil.newWidget)

function ArenaDefIcon:init()
	--背景图
	self._iconBgImage = ImageView:create()
	self._iconBgImage:loadTexture("hero_normal_border.png", UI_TEX_TYPE_PLIST)
	self:addChild(self._iconBgImage)

	self._hero_icon = HeroIcon:create()
	self._hero_icon:setScale(0.8)
	self:addChild(self._hero_icon)
end

function ArenaDefIcon:create()
	local arena_def_icon = ArenaDefIcon.new()
	arena_def_icon:init()
	return arena_def_icon
end

function ArenaDefIcon:setHeroId(hero_id)
	self._hero_icon:setHeroId(hero_id)
end