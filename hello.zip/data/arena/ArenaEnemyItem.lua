--
-- Author: lvgansheng
-- Date: 2014-08-07 16:08:56
-- 可调整敌人元件

ArenaEnemyItem = class("ArenaEnemyItem", WidgetBase)
ArenaEnemyItem.role_info = nil --角色信息
ArenaEnemyItem.head_icon = nil
ArenaEnemyItem.hero_animation = nil
ArenaEnemyItem.hero_anim_path = nil

ArenaEnemyItem.spr_animation = nil
ArenaEnemyItem.spr_anim_path = nil

local HERO_ANIM_TAG = 118
local SPRITE_ANIM_TAG = 119

function ArenaEnemyItem:init()

    self._hero_mgr = HeroManager:getInstance()
    self._efc_mgr = EffectManager:getInstance()

	self.widget = GUIReader:shareReader():widgetFromJsonFile("ui/arena/arena_enemy_item/arena_enemy_item.ExportJson")
    self:addChild(self.widget)

    self.widget:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
           if self.role_info then
              WindowCtrl:getInstance():open(CmdName.OtherRoleInfoView,{role_info=self.role_info})
            end
        end
    end)

    self.rank_num = LabelAtlas:create()
    self.rank_num:setProperty(0000,"ui/digit/bui_stone_blue_num.png",20,26,"0")
    self.rank_num:setPosition(ccp(118,122))
    self.widget:addChild(self.rank_num)

    self.fc_num = LabelAtlas:create()
    self.fc_num:setProperty(0000,"ui/digit/bui_stone_red_num.png",20,26,"0")
    self.fc_num:setPosition(ccp(142,191))
    self.fc_num:setScale(0.9)
    self.widget:addChild(self.fc_num)

    self.arena_enemy_down_bg = self.widget:getChildByName("arena_enemy_down_bg")

    local function getVipBuyNumTips(reset_num)
        if reset_num==0 then
            return "VIP1每天可重置競技場挑戰機會1次"
        elseif reset_num==1 then
            return "VIP4每天可重置競技場挑戰機會2次"
             elseif reset_num==2 then
            return "VIP7每天可重置競技場挑戰機會3次"
             elseif reset_num==3 then
            return "VIP9每天可重置競技場挑戰機會4次"
             elseif reset_num==4 then
            return "VIP11每天可重置競技場挑戰機會5次"
         elseif reset_num==5 then
            return "VIP12每天可重置競技場挑戰機會6次"
         elseif reset_num==6 then
            return "VIP13每天可重置競技場挑戰機會7次"
         elseif reset_num==7 then
            return "VIP14每天可重置競技場挑戰機會8次"
          elseif reset_num==8 then
            return "VIP15每天可重置競技場挑戰機會9次"               
        end
    end

    local challenge_btn = self.widget:getChildByName("challenge_btn")
    challenge_btn:addTouchEventListener(function(sender,event_type)
        if event_type == ComConstTab.TouchEventType.ended then
            
            if ArenaManager:getInstance().remain_num==0 then
              local params = {}
               local vip_buy_num =  VipDataProxy:getInstance():getPrivilegeValue(VipPrivilegeType.BuyArenaReset)
               if ArenaManager:getInstance().arena_reset_num<vip_buy_num then
                    params.txt = "今日免費挑戰次數已用完，花費10鑽石可購買1次挑戰機會哦"
                    params.okFunc = function()
                        ArenaManager.send_reset_role_id = nil
                        ArenaManager:getInstance():sendArenaResetReq(ArenaHelper.Reset.total_num)
                    end
                    WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
                else
                    Alert:show(getVipBuyNumTips(ArenaManager:getInstance().arena_reset_num))
                end

            elseif ServerTimerManager:getInstance():getTimeDiff(ArenaManager:getInstance().end_cold_date)>0 then

                    local params = {}
                    if CharacterManager:getInstance():getBaseData():getVipLv()<6 then
                        params["txt"] = "親，花費10鑽石即可立即發起挑戰哦。"
                    else
                        params["isSingleBtn"] = 1
                        params["txt"] = "您當前擁有立即消除挑戰冷卻時間的VIP特權，可立即消除挑戰冷卻時間。"
                    end
                   
                    params.okFunc = function()
                        ArenaManager.send_reset_role_id = self.role_info.role_id
                        --发送立即发起战斗的协议
                        ArenaManager:getInstance():sendArenaResetReq(ArenaHelper.Reset.wait_time)
                    end
                    WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,params)
                
            else
                WindowCtrl:getInstance():open(CmdName.Team_View,{
                    team_type = TeamType.Arena_atk,
                    id = BattleIDType.ARENA,
                    subId = 1,
                    roleId = self.role_info.role_id
                    })
            end

        end
    end)

end

function ArenaEnemyItem:create()
	local enemy_item = ArenaEnemyItem.new()
	enemy_item:init()
	return enemy_item
end

--设置元件关联的角色信息
function ArenaEnemyItem:setRoleInfo(role_info)
    self.role_info = role_info
    self:changeContent()
end

--改变相应显示
function ArenaEnemyItem:changeContent()

	local name_label = tolua.cast(self.widget:getChildByName("name_label"), "Label")
    name_label:setText(self.role_info.role_name)

    local lev_label = tolua.cast(self.widget:getChildByName("lev_label"), "Label")
    lev_label:setText(string.format("%d",self.role_info.team_lev))

    self.rank_num:setStringValue(self.role_info.rank)
    self.fc_num:setStringValue(self.role_info.fight_capacity)

    --该玩家的侍宠精灵星级大于1才显示
    cclog("這個玩家=%s,精靈結束=%s",self.role_info.role_name,self.role_info.pet_star)
    if self.role_info.pet_star>1 then
        local costUpgradeVo = PetDataProxy:getInstance():getUpgradeCostVoById(self.role_info.pet_star)
        local spr_action_data = EffectManager:getInstance():getActionData(costUpgradeVo.action_id)

        if self.spr_anim_path ~= spr_action_data._fileFullPathName then
            if self.spr_animation then
                self.spr_animation:getAnimation():stop()
                self.spr_animation:removeFromParentAndCleanup(true)
                self.arena_enemy_down_bg:removeNodeByTag(SPRITE_ANIM_TAG)
                self.spr_animation = nil
                AnimateManager:getInstance():clear(self.spr_anim_path)
            end

            self.spr_anim_path = spr_action_data._fileFullPathName
            self.spr_animation = AnimateManager:getInstance():getArmature(spr_action_data._fileFullPathName, spr_action_data._fileName)
            self.spr_animation:setPosition(ccp(-70,140))
            self.spr_animation:setTag(SPRITE_ANIM_TAG)
            self.arena_enemy_down_bg:addNode(self.spr_animation)
            self.spr_animation:getAnimation():play("stand02")
            self.spr_animation:setScale(0.8)
        end
    else
        if self.spr_animation then
            self.spr_animation:getAnimation():stop()
            self.spr_animation:removeFromParentAndCleanup(true)
            self.arena_enemy_down_bg:removeNodeByTag(SPRITE_ANIM_TAG)
            self.spr_animation = nil
            AnimateManager:getInstance():clear(self.spr_anim_path)
        end
        self.spr_anim_path = "" 
    end

    local max_hero_id = self.role_info:getMaxCharmHero()
    local action_data = self._efc_mgr:getActionData(self.role_info:getHeroById(max_hero_id):getModelId(), self.role_info.sex)
    if self.hero_anim_path~=action_data._fileFullPathName then
        if self.hero_animation then
            self.hero_animation:getAnimation():stop()
            self.hero_animation:removeFromParentAndCleanup(true)
            self.arena_enemy_down_bg:removeNodeByTag(HERO_ANIM_TAG)
            self.hero_animation = nil
            AnimateManager:getInstance():clear(self.hero_anim_path)
        end
        self.hero_anim_path = action_data._fileFullPathName
        self.hero_animation = AnimateManager:getInstance():getArmature(action_data._fileFullPathName, action_data._fileName)
        self.hero_animation:setTag(HERO_ANIM_TAG)
        self.hero_animation:setPosition(ccp(0,71))
        self.arena_enemy_down_bg:addNode(self.hero_animation)
        self.hero_animation:getAnimation():play("stand")
    end
end

function ArenaEnemyItem:close()
    if self.hero_animation then
        self.hero_animation:getAnimation():stop()
        self.hero_animation:removeFromParentAndCleanup(true)
        self.arena_enemy_down_bg:removeNodeByTag(HERO_ANIM_TAG)
        self.hero_animation = nil
        AnimateManager:getInstance():clear(self.hero_anim_path)
    end
    self.hero_anim_path = ""

    if self.spr_animation then
        self.spr_animation:getAnimation():stop()
        self.spr_animation:removeFromParentAndCleanup(true)
        self.arena_enemy_down_bg:removeNodeByTag(SPRITE_ANIM_TAG)
        self.spr_animation = nil
        AnimateManager:getInstance():clear(self.spr_anim_path)
    end
    self.spr_anim_path = "" 
end