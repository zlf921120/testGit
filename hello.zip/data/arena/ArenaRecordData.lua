--
-- Author: lvgansheng
-- Date: 2014-09-01 16:41:48
-- 竞技场战斗记录数据项

ArenaRecordData = class("ArenaRecordData")

ArenaRecordData.combat_result = 0
ArenaRecordData.rank_changed = 0
ArenaRecordData.time = 0
ArenaRecordData.role_info = nil
ArenaRecordData.record_key = nil

function ArenaRecordData:init()
	
end

function ArenaRecordData:create()
	local one_data = ArenaRecordData.new()
	one_data:init()
	return one_data
end

function ArenaRecordData:setData( combat_result, rank_changed, time, server_role_info, record_key )
	self.combat_result = combat_result
	self.rank_changed = rank_changed
	self.time = time
    self.record_key = record_key

	self.role_info = OtherRoleInfo:create()
	self.role_info:setBaseInfo(server_role_info.id, server_role_info.name, 
                                server_role_info.team_lev,server_role_info.fc, 
                                server_role_info.face_id, server_role_info.rank, 
                                server_role_info.win_num, server_role_info.guild_name,
                                server_role_info.sex)

    self.role_info:setHeros(server_role_info.heroes)
end