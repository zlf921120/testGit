--信函 助手

MailHelper = {}

--获取下一封 信件
MailHelper.getNextLettleItem = function(lastIdx,listView)

	local ret = nil

	local nowIdx = lastIdx

	local item = listView:getItem(nowIdx)
	if item ~= nil then		
		ret = item 			--获取下一封
	else 
		nowIdx = nowIdx - 1 --获取上一封
		ret = listView:getItem(nowIdx)
	end

	return ret
end