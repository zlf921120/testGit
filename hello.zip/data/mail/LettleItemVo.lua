--信件条目 值对象

LettleItemVo = class("LettleItemVo")

LettleItemVo.id = 0
LettleItemVo.title = ""
LettleItemVo.from = ""							--发送者
LettleItemVo.content = ""						--内容
LettleItemVo.time = 9999999999					--时间
LettleItemVo.reward = ""						--奖励
LettleItemVo.status	= 0		--状态
LettleItemVo.channelId = 0						--渠道ID
LettleItemVo.zoneId = 0						--区ID
-- LettleItemVo.isExt = 0 --是否拓展信件
LettleItemVo.hasFeedback = 0 --是否已经回赠
LettleItemVo.mailType = 0 --邮件类型