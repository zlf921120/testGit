
--渲染逻辑
MailRenderMgr = class("MailRenderMgr")
MailRenderMgr.fixPosArr = nil
MailRenderMgr.dic = nil

local __instance = nil
local _allowInstance = false

function MailRenderMgr:ctor()
    if not _allowInstance then
		error("MailRenderMgr is a singleton class")
	end
	self:init()
end

function MailRenderMgr:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = MailRenderMgr.new()
		_allowInstance = false
	end

	return __instance
end

function MailRenderMgr:destoryInstance()
	self.dic:release()
	_allowInstance = false
	__instance = nil
end

function MailRenderMgr:init()
	require "MailDataProxy"
	require "MailCfg"
	require "MailHelper"
	require "LettleGrid"
	
	self.dic = CCDictionary:create() --缓存
	self.dic:retain()
end

--渲染信件列表
function MailRenderMgr.renderListLettle(listLettle,callBack)
	--listLettle:removeAllItems()

	if not __instance.dic then
		--__instance.dic:release()                                  
    	--__instance.dic = nil
		__instance.dic = CCDictionary:create() --缓存
		__instance.dic:retain()
	end

	------------开始渲染------------------
	local voList = MailDataProxy:getInstance():getLettleItemVos()
	local tmpList = {}
	for k,v in pairs(voList) do
		if not __instance.dic:objectForKey(string.format("lettle_%d",v.id)) then
			--todo
			table.insert(tmpList,v)
		end		
	end
	table.sort(tmpList,function(a,b)
		return a.time < b.time
	end)

	local idx = 0
	while true do
	-- local function step_create()
		idx = idx + 1
		local itemVo = tmpList[idx]
		if itemVo ~= nil then
			local grid = MailLettleGrid:create(itemVo)

			local ckb = tolua.cast(grid._widget:getChildByName("ckb_item"),"ImageView")		
			ckb:addTouchEventListener(callBack)

			__instance.dic:setObject(grid,string.format("lettle_%d",itemVo.id))
			grid._widget:setTag(itemVo.id)--记录信件id

			listLettle:insertCustomItem(grid._widget,0)
		else
			-- listLettle:stopAllActions()
			--如果有数据 则查看第一封
			if listLettle:getItems():count() > 0 then
				callBack(listLettle:getItem(0):getChildByName("ckb_item"),ComConstTab.TouchEventType.ended)
			end
			break
		end
	end

	-- listLettle:runAction(CCRepeatForever:create(CCSequence:createWithTwoActions(
	-- 	CCCallFunc:create(step_create),
	-- 	CCDelayTime:create(0.01))))
end

--渲染信件列表
function MailRenderMgr:renderMailList(listView)
	
	local voList = MailDataProxy:getInstance():getLettleItemVos()
	local tmpList = {}
	for k,v in pairs(voList) do
		table.insert(tmpList,v)
	end
	table.sort(tmpList,function(a,b)
		return a.time < b.time
	end)

	local arr = CCArray:create()
	for i=1,#tmpList do
		local key = string.format("lettle_%d",tmpList[i].id)
 		local item = self.dic:objectForKey(key)
 		if item == nil then
			arr:addObject(CCDelayTime:create(0.1))
		end
		arr:addObject(CCCallFunc:create(function()
	 		local item = self.dic:objectForKey(key)
 			if item == nil then
				item = MailLettleGrid:create()
				item:setData( dp:getLettleItemVoById(tmpList[i].id) )
				self.dic:setObject(item,key)
			end
			item:update()
			listView:insertCustomItem(item,0)
		end))
	end
	listView:removeAllItems()
	listView:stopAllActions()
	listView:runAction(CCSequence:create(arr))
	
end

--展示信件内容
function MailRenderMgr.showLettleContent(scrolContent,id,btnGet,imgNothingTips)

 	-- print(" showLettleContent == >",id)
	scrolContent:setInnerContainerSize(CCSize(500,350))
	--清理奖励 格子
	for i=1000,1005 do
		scrolContent:getParent():removeChild(scrolContent:getParent():getChildByTag(i))
	end
	for i = 0, scrolContent:getChildrenCount() - 1 do
        local child = tolua.cast(scrolContent:getChildren():objectAtIndex(i),"CCNode")
        child:setVisible(true) --显示内容
    end
    imgNothingTips:setVisible(false)
--------------------------初始化--------------------------------------------------------------
	local itemVo = MailDataProxy:getInstance():getLettleItemVoById(id)
	if itemVo == nil then return end

	--更新状态
	if string.len(itemVo.reward) ~= 0 then
		itemVo.status = LettleType.HAS_REWARD_UN_GET	--有奖励
	else 	
		itemVo.status = LettleType.HAS_READ 			--没奖励
	end
	--本地缓存
	Global:setStringForKey(string.format("mailId%d",id),itemVo.status)

	local labFixFrom = tolua.cast(scrolContent:getChildByName("lab_fixfrom"),"Label")
	labFixFrom:setPosition(ccp(4,326))
	local labFrom = tolua.cast(scrolContent:getChildByName("lab_from"),"Label")
	labFrom:setPosition(ccp(115,325))
	labFrom:setText(itemVo.from)

	local labFixTitle = tolua.cast(scrolContent:getChildByName("lab_fixtitle"),"Label")
	labFixTitle:setPosition(ccp(4,281))
	local labTitle = tolua.cast(scrolContent:getChildByName("lab_title"),"Label")
	labTitle:setPosition(ccp(115,280))
	labTitle:setText(itemVo.title)
	
	local labFixContent = tolua.cast(scrolContent:getChildByName("lab_fixcontent"),"Label")
	labFixContent:setPosition(ccp(3,236))
	local labContent = tolua.cast(scrolContent:getChildByName("lab_content"),"Label")
	labContent:setPosition(ccp(5,205))
	labContent:setText("　　"..itemVo.content)
	
	local labTime = tolua.cast(scrolContent:getChildByName("lab_time"),"Label")
	labTime:setText(os.date("%Y.%m.%d %H:%M",itemVo.time))
	
	local p_reward = tolua.cast(scrolContent:getParent():getChildByName("p_reward"),"Label")
	---渲染奖励
	if string.len(itemVo.reward) ~= 0 then
		local idx = 0
		local itemRewardArr = Utils.Split(itemVo.reward,",")

		-- print(" itemVo.reward ",itemVo.reward)
		for k,v in pairs(itemRewardArr) do
			local itemReward = Utils.Split(v,"x")
			local goodsId = itemReward[1]
			local num = itemReward[2]

			local itemIcon = ItemIcon:create()
			itemIcon:setBaseId(tonumber(goodsId))
			itemIcon:isShowNumLabel(true)
			itemIcon:setScale(0.8)
			itemIcon:setItemNum(tonumber(num))
			itemIcon:setPosition(ccp(p_reward:getPositionX() + idx * (-95),p_reward:getPositionY()))
			scrolContent:getParent():addChild(itemIcon,5,1000 + idx)
			idx = idx + 1
		end
	end
-------------------------动态调整滑块----------------------------------------------------------------------
	local nlCount = Helper.nlCount(itemVo.content) --获取换行符个数
	local contentHeight = string.len("　　  "..itemVo.content)  / 2 + 25 + nlCount * 25 --根据字数约取高度
	labContent:setSize(CCSize(labContent:getSize().width,contentHeight))
	
	labTime:setPositionY(labContent:getPositionY() - contentHeight)

	local offsetY = 0						--计算超出部分的偏移量
	if labTime:getPositionY() < 0 then
		offsetY = labTime:getPositionY() * -1 + 70

		scrolContent:setInnerContainerSize(CCSize(scrolContent:getSize().width,scrolContent:getSize().height + offsetY))
	    --偏移所有
	    for i = 0, scrolContent:getChildrenCount() - 1 do
	        local child = tolua.cast(scrolContent:getChildren():objectAtIndex(i),"CCNode")
	        child:setPositionY(child:getPositionY() + offsetY)
	    end
	end
-----------------------回赠按钮调整--------------------------------------------
	btnGet:setBright(true)
    btnGet:setTouchEnabled(true)
	if string.len(itemVo.reward) == 0 then  --没物品 
		if itemVo.mailType == MailType.Organiz or itemVo.mailType == 4 then --看看是否 公会 拓展邮件
			if itemVo.hasFeedback == 0 then
				btnGet:setTitleText("回贈")
			else
				btnGet:setTitleText("已回贈")
				btnGet:setBright(false)
       			btnGet:setTouchEnabled(false)
			end
		else
			btnGet:setTitleText("領取")
		end
	else --有物品先领取

		btnGet:setTitleText("領取")
	end
	
	--检测是否去掉新提示绿点
	MailDataProxy:getInstance():checkHasUnreadLettle()
end

--更新信件列表状态
MailRenderMgr.updateListLettle = function(id)
	
	local itemVo = MailDataProxy:getInstance():getLettleItemVoById(id)
	if itemVo == nil then return end

	local item = __instance.dic:objectForKey(string.format("lettle_%d",id)) 
	item:update(itemVo)
end

function MailRenderMgr:updateLettleView(id,t)
	local itemVo = MailDataProxy:getInstance():getLettleItemVoById(id)
	if itemVo == nil then return end

	local item = __instance.dic:objectForKey(string.format("lettle_%d",id)) 
	item:colorChange(t)
end

--清理已完成的信件
MailRenderMgr.clearListLettle = function(listLettle,scrolContent,id,imgNothingTips)
	
	local isDirty = false

	local itemVo = MailDataProxy:getInstance():getLettleItemVoById(id)

	if itemVo.status == LettleType.HAS_READ then	--查看了信件 并获取了奖励

		local arr = listLettle:getChildren()	--记录清理数据
		local i = 0
		while i < arr:count() do
			local widget = tolua.cast(arr:objectAtIndex(i),"Widget")
			if widget:getTag() == id then 
				local idx = listLettle:getIndex(widget)
				MailDataProxy:getInstance():removeLettleItemVo(id)	--执行清理
				listLettle:removeItem(idx)
				__instance.dic:removeObjectForKey(string.format("lettle_%d",id)) 
				isDirty = true
			else 
				i = i + 1
			end
		end

	end

	--清理奖励 格子
	for i=1000,1005 do
		if scrolContent:getParent():getChildByTag(i) ~= nil then
			scrolContent:getParent():removeChild(scrolContent:getParent():getChildByTag(i))
		end
	end
----------------清除信件内容-------------------------------------------------------------
	if isDirty then 
		for i = 0, scrolContent:getChildrenCount() - 1 do
	        local child = tolua.cast(scrolContent:getChildren():objectAtIndex(i),"CCNode")
	        child:setVisible(false) --隐藏内容
	    end
	    imgNothingTips:setVisible(true)
	end
end
