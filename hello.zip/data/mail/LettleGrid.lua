
--信件条目 格子
MailLettleGrid = class("MailLettleGrid",function()
    return Layout:create()
end)
MailLettleGrid.__index = MailLettleGrid
MailLettleGrid._widget      = nil

--@parem lettleItemVo 信件值
function MailLettleGrid:create(lettleItemVo)
    local layer = MailLettleGrid.new()
    layer:init(lettleItemVo)
    return layer   
end

---------------初始化-----------------------------------------------------
function MailLettleGrid:init(lettleItemVo)

    require "MailCfg"
    
    self._widget = MailDataProxy:getInstance():getWidgetLettleItem():clone()
    -- self:addChild(self._widget)
    -- self:setSize(CCSize(301,145))

    self:update(lettleItemVo)
end

function MailLettleGrid:update(lettleItemVo)

    local labFrom = tolua.cast(self._widget:getChildByName("lab_from"),"Label")
    labFrom:setText(lettleItemVo.from)

    local labTitle = tolua.cast(self._widget:getChildByName("lab_title"),"Label")
    labTitle:setText(lettleItemVo.title)

    local labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")
    labTime:setText(os.date("%Y.%m.%d",lettleItemVo.time))

    local imgStatus = tolua.cast(self._widget:getChildByName("img_status"),"ImageView")

    local status = lettleItemVo.status
    
    if status == LettleType.UN_READ then
        imgStatus:loadTexture("mail_unread.png",UI_TEX_TYPE_PLIST)
    elseif status == LettleType.HAS_REWARD_UN_GET then 
        imgStatus:loadTexture("mail_read.png",UI_TEX_TYPE_PLIST)    
    elseif status == LettleType.HAS_READ then 
        imgStatus:loadTexture("mail_read.png",UI_TEX_TYPE_PLIST)
    end

    --显示/隐藏 奖励图标
    local hasReward = ( string.len(lettleItemVo.reward) ~= 0 )
    local imgReward = tolua.cast(imgStatus:getChildByName("img_reward"),"ImageView")
    imgReward:setVisible(hasReward)
end

function MailLettleGrid:colorChange(t)
    local labFrom = tolua.cast(self._widget:getChildByName("lab_from"),"Label")
    local labTitle = tolua.cast(self._widget:getChildByName("lab_title"),"Label")
    local labTime = tolua.cast(self._widget:getChildByName("lab_time"),"Label")
    local imgBg = tolua.cast(self._widget:getChildByName("ckb_item"),"ImageView")

    if t == ComConstTab.CheckBoxEventType.unselected then
        labFrom:setColor(ccc3(255,225,207))
        labTitle:setColor(ccc3(238,98,30))
        labTime:setColor(ccc3(238,98,30))
        imgBg:loadTexture("btn_up_7.png",UI_TEX_TYPE_PLIST)
    elseif t == ComConstTab.CheckBoxEventType.selected then
        labFrom:setColor(ccc3(210,253,238))
        labTitle:setColor(ccc3(49,226,174))
        labTime:setColor(ccc3(49,226,174))
        imgBg:loadTexture("bg_10.png",UI_TEX_TYPE_PLIST)
    end
end