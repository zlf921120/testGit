--信件配置

LettleType = 
{
	UN_READ 			= 0,		--未查看
	HAS_REWARD_UN_GET  	= 1,		--已打开但未领奖励
	HAS_READ 			= 2,		--已查看(完成)
}

------------------邮件类型--------------------------
MailType =
{
	Organiz = 1, --公会互赠体力
	Friend = 4,  --好友互赠体力
	AutoRemove = 3, --邮件 自动删除
}