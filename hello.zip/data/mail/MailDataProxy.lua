--信件数据代理
MailDataProxy = class("MailDataProxy")
MailDataProxy.voList = {}
MailDataProxy.initMailList = nil --初始化列表邮件id

local __instance = nil
local _allowInstance = false

function MailDataProxy:ctor()
    if not _allowInstance then
		error("MailDataProxy is a singleton class")
	end
	self:init()
    return node   
end

function MailDataProxy:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = MailDataProxy.new()
		_allowInstance = false
	end

	return __instance
end

function MailDataProxy:destoryInstance()
	_allowInstance = false
	__instance = nil
end

function MailDataProxy:init()
	require "LettleItemVo"
end

----------------GET/SET/IS-----------------------------------
function MailDataProxy:getLettleItemVos()
	return self.voList
end

function MailDataProxy:getLettleItemVoById(id)
	return self.voList[id]
end

function MailDataProxy:setLettleItemVo(vo)
	self.voList[vo.id] = vo
end

function MailDataProxy:createLettleItemVo()
	return LettleItemVo.new()
end

function MailDataProxy:removeLettleItemVo(id)
	self.voList[id] = nil
end

function MailDataProxy:getWidgetLettleItem()
	if self.widgetLettleItem == nil then
		self.widgetLettleItem = GUIReader:shareReader():widgetFromJsonFile("mail/LettleItem.ExportJson")
		self.widgetLettleItem:retain()
	end
	return self.widgetLettleItem
end

function MailDataProxy:getCanCleanItemList()
	local ret = {}
	for k,v in pairs(self.voList) do
		if string.len(v.reward) == 0 and Global:getStringForKey(string.format("mailId%d",v.id)) ~= nil then --已读 没附件
			table.insert(ret,v.id)
		end
	end
	return ret
end

--是否有未读邮件(初始化登录时候检测一次)
function MailDataProxy:isHasUnreadLettle()
	local ret = 1 --0 显示  1 不显示
	local list = self.initMailList
	for i=1,#list do
		if Global:getStringForKey(string.format("mailId%d",list[i].sess_id)) == nil then
			ret = 0
			break
		end
	end
	return ret
end
--是否有未读邮件(每查看一封信都检测一次)
function MailDataProxy:checkHasUnreadLettle()
	local ret = true
	for id,v in pairs(self.voList) do
		if Global:getStringForKey(string.format("mailId%d",id)) == nil then
			ret = false
			break
		end
	end
	if ret then
		Notifier.dispatchCmd(CmdName.MAIN_HIDE_NEWS_TIP,NewTipsEnum.mail)
	end
end

function MailDataProxy:setInitMailList(list)
	self.initMailList = list
end

function MailDataProxy:clear()
	for id,v in pairs(self.voList) do
		self.voList[id] = nil
	end
	self.voList = {}
end