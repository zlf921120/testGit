

--信函网络代理
MailNetTask = class("MailNetTask")

local _isClear = false		--是否 获取奖励后删除信件
local __instance = nil
local _allowInstance = false

local prev_last_id = nil  --上一次 最后获取的信件id
local left_num = 99 -- 还有多少封信件 没拉取

function MailNetTask:ctor()
    if not _allowInstance then
		error("MailNetTask is a singleton class")
	end
	self:init()
end

function MailNetTask:getInstance()
	if not __instance then
		_allowInstance = true
		__instance = MailNetTask.new()
		_allowInstance = false
	end

	return __instance
end

function MailNetTask:destoryInstance()
	_allowInstance = false
	__instance = nil
end


function MailNetTask:init()
	require "MailCfg"
	require "ItemManager"
	require "mail_pb"
	--注册网络事件
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.mail_fetch_rsp,"handleLettleData()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.mail_pick_rsp,"handleMailReward()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.mail_del_rsp,"handleDeleteLettle()")
	Global:RegisterNetworkCmd(proto_cmd_pb.msg_cmd.mail_feedback_rsp,"handleOrganizFeedBack()")
end

--请求数据
function MailNetTask:requestLettleData()
	print("----------requestLettleData---------  ")
	local mail_fetch_req = mail_pb.mail_fetch_req()
	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.mail_fetch_req,mail_fetch_req)
end

local _feedback_data = {}

--获取网络数据
function handleLettleData(pkg)

	local mail_fetch_rsp = mail_pb.mail_fetch_rsp()
	mail_fetch_rsp:ParseFromString(pkg)

	print("-------handleLettleData---------",mail_fetch_rsp.ret)
	if mail_fetch_rsp.ret == error_code_pb.msg_ret.success then

		ComSender:getInstance():dealExtInfo(mail_fetch_rsp.ext)

		local mails = mail_fetch_rsp.mails
		left_num = mail_fetch_rsp.left_num

		for i=1,table.getn(mails) do
			local v = mails[i]
			-- 奖励
			local rewardTbl = {}

			for i=1,table.getn(v.items) do
				local vv = v.items[i]
				table.insert(rewardTbl,vv.item_base_id .. "x" ..vv.quantity) --"30001x1,30002x2"
			end

			--获取本地 信件状态
			local status = tonumber(Global:getStringForKey(string.format("mailId%d",v.id.sess_id)))
			--拼凑奖励
			local rewardStr = Utils.Join(",",rewardTbl)
			print("--------------- rewardStr ---------------",rewardStr)

			local dp = MailDataProxy:getInstance()
			local vo = dp:createLettleItemVo()

			vo.id = v.id.sess_id
			print("the uid=",vo.id)
			print("the uid=",vo.id)
			print("the uid=",vo.id)
			print("the uid=",vo.id)

			print("my uid=",CharacterManager:getInstance():getLoginData():getAcctId())
			print("my uid=",CharacterManager:getInstance():getLoginData():getAcctId())
			print("my uid=",CharacterManager:getInstance():getLoginData():getAcctId())
			
			vo.channelId = v.id.channel_id
			vo.zoneId = v.id.zone_id
			vo.title = v.title
			vo.from = v.from_name
			vo.content = v.content
			vo.time = v.send_time
			vo.reward = rewardStr
			vo.status = status

			vo.mailType = v.ext.ext_type
			if v.ext.ext_type == MailType.Organiz or v.ext.ext_type == MailType.Friend then --公会拓展
				if v.ext.ext_type == MailType.Friend then
					_feedback_data = {}
					_feedback_data.uin = vo.id
					_feedback_data.channel_id = vo.channelId
					_feedback_data.zone_id = vo.zoneId
				end
				vo.hasFeedback = v.ext.is_feedback
			elseif v.ext.ext_type == MailType.AutoRemove then --看完后自动删除的邮件
			end

			dp:setLettleItemVo(vo)	--更新数据
		end

		if table.getn(mails) > 0 then 
			--开始渲染场景
			Notifier.dispatchCmd(MailEvent.GETITEM_SUCCESS)
		end
	end

end

--发送获取 附件的请求
function MailNetTask:requestReward(itemId)

	local itemVo = MailDataProxy:getInstance():getLettleItemVoById(itemId)
	if itemVo == nil then return end

	local mail_pick_req = mail_pb.mail_pick_req()
	mail_pick_req.id.sess_id = itemVo.id
	mail_pick_req.id.channel_id = itemVo.channelId
	mail_pick_req.id.zone_id = itemVo.zoneId

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.mail_pick_req,mail_pick_req)
end

-- 获取 附件
function handleMailReward(pkg)
	print("---------------handleMailReward---------------")

	--附件 进背包操作
	local mail_pick_rsp = mail_pb.mail_pick_rsp()
	mail_pick_rsp:ParseFromString(pkg)

	if mail_pick_rsp.ret == error_code_pb.msg_ret.success then
		
		ComSender:getInstance():dealExtInfo(mail_pick_rsp.ext)

		local itemId = mail_pick_rsp.id.sess_id
		local items = mail_pick_rsp.items
		local assets = mail_pick_rsp.assets

		local itemVo = MailDataProxy:getInstance():getLettleItemVoById(itemId)
		itemVo.reward = ""
		itemVo.status = LettleType.HAS_READ

		-- for i=1,table.getn(items) do
		-- 	ItemManager:getInstance():changeDataByClient(items[i].id,items[i].base_id,items[i].quantity,ItemHelper.change_type.add) --更新背包
		-- end
		
		ItemManager:getInstance():addMultiItem(items)  --更新背包 
		CharacterManager:getInstance():updateRoleAssets(assets) --更新资产

		if _isClear then
			__instance:requestDeleteLettle(itemId)
		else
			--领取奖励后刷新界面
			Notifier.dispatchCmd(MailEvent.MSG_UPDATE_LIST)--通知场景更新
		end
		if itemVo.mailType == MailType.AutoRemove then
			Notifier.dispatchCmd(MailEvent.MSG_CLEAR_ITEM,itemId)--通知场景删除信件
		end
		_isClear = false	--还原
		Alert:show("領取成功")	
	else
		Alert:show(Helper.getErrStr(mail_pick_rsp.ret))	
	end
	
end

-- 请求 (公会)回赠
function MailNetTask:requestOrganizFeedBack(itemId)

	print("------------------requestOrganizFeedBack---------------------------")

	local itemVo = MailDataProxy:getInstance():getLettleItemVoById(itemId)
	if itemVo == nil then return end

	local mail_feedback_req = mail_pb.mail_feedback_req()
	print("id=", itemVo.id)
	print("channel_id=", itemVo.channelId)
	print("zone_id=", itemVo.zoneId)
	mail_feedback_req.id.sess_id = itemVo.id
	mail_feedback_req.id.channel_id = itemVo.channelId
	mail_feedback_req.id.zone_id = itemVo.zoneId

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.mail_feedback_req,mail_feedback_req)
end

-- 响应 (公会)回赠
function handleOrganizFeedBack(pkg)

	local mail_feedback_rsp = mail_pb.mail_feedback_rsp()
	mail_feedback_rsp:ParseFromString(pkg)
	
	print("------------------handleOrganizFeedBack---------------------------",mail_feedback_rsp.ret)

	if mail_feedback_rsp.ret == error_code_pb.msg_ret.success then

		ComSender:getInstance():dealExtInfo(mail_feedback_rsp.ext)

		local itemId = mail_feedback_rsp.id.sess_id

		local itemVo = MailDataProxy:getInstance():getLettleItemVoById(itemId)
		itemVo.hasFeedback = 1 --标记已回赠

		Notifier.dispatchCmd(MailEvent.MSG_UPDATE_LIST)--通知场景更新
		Alert:show("回贈成功")
	else
		if error_code_pb.msg_ret.err_not_enough_num == mail_feedback_rsp.ret then
			Alert:show("今日回贈次數已滿")
		else
			Alert:show(Helper.getErrStr(mail_feedback_rsp.ret))
		end
	end
end

--请求 删除邮件
function MailNetTask:requestDeleteLettle(itemIdList)

	print(" --------------requestDeleteLettle----------------------  ")

	local mail_del_req = mail_pb.mail_del_req()
	for i=1,#itemIdList do
		local itemVo = MailDataProxy:getInstance():getLettleItemVoById(itemIdList[i])
		local mail_id = common_pb.mail_id()
		mail_id.sess_id = itemVo.id
		mail_id.channel_id = itemVo.channelId
		mail_id.zone_id = itemVo.zoneId
		table.insert(mail_del_req.ids,mail_id)
	end

	ComSender:getInstance():send(proto_cmd_pb.msg_cmd.mail_del_req,mail_del_req)
end

--响应 删除邮件 
function handleDeleteLettle(pkg)

	local mail_del_rsp = mail_pb.mail_del_rsp()
	mail_del_rsp:ParseFromString(pkg)

	print(" --------------handleDeleteLettle---------------------- ",mail_del_rsp.ret)

	if mail_del_rsp.ret == error_code_pb.msg_ret.success then

		local list = mail_del_rsp.ids
		for i=1,#list do
			local itemId = list[i].sess_id
			Notifier.dispatchCmd(MailEvent.MSG_CLEAR_ITEM,itemId)--通知场景删除信件
		end
		
		ComSender:getInstance():dealExtInfo(mail_del_rsp.ext)

		Alert:show("操作成功")
	else
		Alert:show(Helper.getErrStr(mail_del_rsp.ret))	
	end
end

function MailNetTask:getFeedData()
	return _feedback_data
end