--信件事件

MailEvent = 
{
	SHOW_ALERT	= "mail_show_alert" , --提示信息

	ERR_SERVER		= "mail_err_server",				--服务器有误

	GETITEM_SUCCESS = "mail_getitem_success",		--获取数据成功

	MSG_UPDATE_LIST = "msg_update_list",		--更新列表

	MSG_CLEAR_ITEM = "msg_clear_item",			--删除某条信件
}