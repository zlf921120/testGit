
--信函场景
MailScene = class("MailScene",WindowBase)
MailScene.__index = MailScene
MailScene._widget = nil
MailScene.uiLayer = nil

local __instance = nil

function MailScene:create()
    local ret = MailScene.new()
    __instance = ret
    return ret   
end

-------------控件响应事件-----------------------------------------------
local curLettleIdx = 0 
local curMailId = 0

local listLettle = nil
local scrolContent = nil
local btnBack = nil
local btnClear = nil
local btnGet = nil

local lastCbk = nil
--点击信件
local function event_cbk_click(sender,eventType)
    
    if eventType == ComConstTab.TouchEventType.ended then

        if lastCbk == nil then
            lastCbk = sender
        elseif lastCbk ~= sender then
            MailRenderMgr:getInstance():updateLettleView(lastCbk:getParent():getTag(),ComConstTab.CheckBoxEventType.unselected)
            lastCbk = sender
        else
            return
        end

        curMailId = sender:getParent():getTag()  --记录当前信件id
        curLettleIdx = listLettle:getIndex(lastCbk:getParent()) --记录当前信件的下标

        --更新信件内容
        MailRenderMgr.showLettleContent(scrolContent,curMailId,btnGet,__instance.imgNothingTips)
        --更新信件列表
        MailRenderMgr.updateListLettle(curMailId)
        --更新信件外观
        MailRenderMgr:getInstance():updateLettleView(curMailId,ComConstTab.CheckBoxEventType.selected)
    end
end

local function event_btn_clear(sender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        if lastCbk == nil then return end

        WindowCtrl:getInstance():open(CmdName.Comm_MsgBox,{okFunc = function()
            local voList = MailDataProxy:getInstance():getCanCleanItemList()
            if #voList > 0 then 
                MailNetTask:getInstance():requestDeleteLettle(voList)
            end
        end, txt = "是否要將已讀且無附件的信函清理"})
    end
end

local function event_btn_get(sender,eventType)
    if eventType == ComConstTab.TouchEventType.ended then
        if lastCbk == nil then return end
        --请求获取单项奖励
        local id = curMailId
        local lettleVo = MailDataProxy:getLettleItemVoById(id)
        
        if string.len(lettleVo.reward) ~= 0 then --有奖励则要发请求
            MailNetTask:getInstance():requestReward(id) 
        else
            if lettleVo.mailType == MailType.Organiz or lettleVo.mailType == MailType.Friend then --公会互赠体力 回赠
                
                MailNetTask:getInstance():requestOrganizFeedBack(id)
            -- elseif lettleVo.mailType == MailType.Friend then
            --     require "FriendMgr"
            --     local send_data = {}
            --     send_data.type = 2
            --     send_data.id =  MailNetTask:getInstance():getFeedData()
            --     FriendMgr:getInstance():sendGiveProto(send_data)
            else --普通邮件
                MailNetTask:getInstance():requestReward(id)
            end
        end
        
    end
end
------------------服务端响应--------------------------------------------
local function event_render_item(itemVoArr)
    MailRenderMgr.renderListLettle(listLettle,event_cbk_click,itemVoArr) --开始渲染场景
end

--更新信件列表
local function event_update_list() --获得奖励

    if lastCbk == nil then return end
    local id = curMailId
    MailRenderMgr.showLettleContent(scrolContent,id,btnGet,__instance.imgNothingTips)
     --更新信件列表
    MailRenderMgr.updateListLettle(id)
end
--删除某条信件
local function event_delete_item(id) 
    MailRenderMgr.clearListLettle(listLettle,scrolContent,id,__instance.imgNothingTips)
    lastCbk = nil
    curMailId = 0
    ----主动点击下一封信件------
    local item = MailHelper.getNextLettleItem(curLettleIdx,listLettle)
    if item ~= nil then 
        event_cbk_click(item:getChildByName("ckb_item"),ComConstTab.TouchEventType.ended)
    end
    ----------------------------
end
---------------初始化-----------------------------------------------------
function MailScene:init()
    require "MailEvent"
    require "MailRenderMgr"
    require "MailNetTask"
    require "ItemIcon"
    require "LettleGrid"

    --加载纹理
    ComResMgr:getInstance():loadOtherRes()

    self._widget = GUIReader:shareReader():widgetFromJsonFile("mail/MailView.ExportJson")
    self.uiLayer = TouchGroup:create()
    self.uiLayer:addWidget(self._widget)
    self:addChild(self.uiLayer)

    listLettle = tolua.cast(self.uiLayer:getWidgetByName("list_lettle"),"ListView")

    scrolContent = tolua.cast(self.uiLayer:getWidgetByName("scrol_content"),"ScrollView")
    self.imgNothingTips = tolua.cast(self.uiLayer:getWidgetByName("img_nothingtips"),"ImageView")

    btnClear = tolua.cast(self.uiLayer:getWidgetByName("btn_clear"),"Button")
    btnClear:addTouchEventListener(event_btn_clear)

    btnGet = tolua.cast(self.uiLayer:getWidgetByName("btn_get"),"Button")
    btnGet:addTouchEventListener(event_btn_get)
    --初始化
    MailRenderMgr:getInstance()
    --注册事件
    Notifier.regist(MailEvent.GETITEM_SUCCESS,event_render_item)    --获取信件数据并渲染
    Notifier.regist(MailEvent.MSG_UPDATE_LIST,event_update_list)    --更新列表数据
    Notifier.regist(MailEvent.MSG_CLEAR_ITEM,event_delete_item)      --删除某条信件
end

function MailScene:open()
    --主动 拉取 服务端数据
    MailNetTask:getInstance():requestLettleData()
end

function MailScene:close()

    if lastCbk then
        MailRenderMgr:getInstance():updateLettleView(lastCbk:getParent():getTag(),ComConstTab.CheckBoxEventType.unselected)
    end

    lastCbk = nil
    curMailId = 0
end